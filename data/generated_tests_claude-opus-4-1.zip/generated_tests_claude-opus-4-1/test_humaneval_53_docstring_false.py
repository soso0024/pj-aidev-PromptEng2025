# Test cases for HumanEval/53
# Generated using Claude API



def add(x: int, y: int):
    """Add two numbers x and y
    >>> add(2, 3)
    5
    >>> add(5, 7)
    12
    """

    return x + y


# Generated test cases:
import pytest

def add(x: int, y: int):
    return x + y

class TestAdd:
    @pytest.mark.parametrize("x,y,expected", [
        (2, 3, 5),
        (5, 7, 12),
        (0, 0, 0),
        (1, 0, 1),
        (0, 1, 1),
        (-1, 1, 0),
        (1, -1, 0),
        (-5, -3, -8),
        (100, 200, 300),
        (-100, 50, -50),
        (999999, 1, 1000000),
        (-999999, -1, -1000000),
    ])
    def test_add_normal_cases(self, x, y, expected):
        assert add(x, y) == expected

    def test_add_large_numbers(self):
        assert add(10**10, 10**10) == 2 * 10**10
        assert add(10**15, 10**15) == 2 * 10**15

    def test_add_commutative(self):
        assert add(5, 3) == add(3, 5)
        assert add(-10, 20) == add(20, -10)

    def test_add_identity(self):
        assert add(42, 0) == 42
        assert add(0, 42) == 42

    def test_add_inverse(self):
        assert add(10, -10) == 0
        assert add(-25, 25) == 0

    def test_add_associative(self):
        a, b, c = 5, 10, 15
        assert add(add(a, b), c) == add(a, add(b, c))

    def test_add_with_strings(self):
        with pytest.raises(TypeError):
            add("5", 3)
        with pytest.raises(TypeError):
            add(5, "3")
        with pytest.raises(TypeError):
            add("5", "3")
    
    def test_add_with_floats(self):
        assert add(5.5, 3) == 8.5
        assert add(5, 3.5) == 8.5
    
    def test_add_with_none(self):
        with pytest.raises(TypeError):
            add(None, 5)
        with pytest.raises(TypeError):
            add(5, None)
    
    def test_add_with_collections(self):
        with pytest.raises(TypeError):
            add([], 5)
        with pytest.raises(TypeError):
            add(5, {})