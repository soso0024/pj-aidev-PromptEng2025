# Test cases for HumanEval/24
# Generated using Claude API



def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    >>> largest_divisor(15)
    5
    """

    for i in reversed(range(n)):
        if n % i == 0:
            return i


# Generated test cases:
import pytest

@pytest.mark.parametrize("n,expected", [
    (15, 5),
    (12, 6),
    (10, 5),
    (9, 3),
    (8, 4),
    (7, 1),
    (6, 3),
    (5, 1),
    (4, 2),
    (3, 1),
    (2, 1),
    (24, 12),
    (36, 18),
    (48, 24),
    (60, 30),
    (72, 36),
    (84, 42),
    (96, 48),
    (120, 60),
    (144, 72),
    (180, 90),
    (210, 105),
    (240, 120),
    (360, 180),
    (420, 210),
    (1000, 500),
    (999, 333),
    (512, 256),
    (1024, 512),
    (2048, 1024),
    (81, 27),
    (64, 32),
    (128, 64),
    (256, 128),
    (343, 49),
    (625, 125),
    (1001, 143),
    (2310, 1155),
    (30030, 15015),
    (100, 50),
    (49, 7),
    (25, 5),
    (17, 1),
    (13, 1),
    (11, 1),
])
def test_largest_divisor(n, expected):
    assert largest_divisor(n) == expected

def test_largest_divisor_prime_numbers():
    primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]
    for prime in primes:
        assert largest_divisor(prime) == 1

def test_largest_divisor_perfect_squares():
    perfect_squares = [(4, 2), (9, 3), (16, 8), (25, 5), (36, 18), (49, 7), (64, 32), (81, 27), (100, 50), (121, 11), (144, 72), (169, 13)]
    for square, expected in perfect_squares:
        assert largest_divisor(square) == expected

def test_largest_divisor_powers_of_two():
    powers = [(2, 1), (4, 2), (8, 4), (16, 8), (32, 16), (64, 32), (128, 64), (256, 128), (512, 256), (1024, 512)]
    for power, expected in powers:
        assert largest_divisor(power) == expected

def test_largest_divisor_even_numbers():
    even_numbers = [(2, 1), (4, 2), (6, 3), (8, 4), (10, 5), (12, 6), (14, 7), (16, 8), (18, 9), (20, 10)]
    for num, expected in even_numbers:
        assert largest_divisor(num) == expected

def test_largest_divisor_factorials():
    factorials = [(6, 3), (24, 12), (120, 60), (720, 360), (5040, 2520)]
    for factorial, expected in factorials:
        assert largest_divisor(factorial) == expected