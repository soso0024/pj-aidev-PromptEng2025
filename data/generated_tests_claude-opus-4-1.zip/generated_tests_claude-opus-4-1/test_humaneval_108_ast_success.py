# Test cases for HumanEval/108
# Generated using Claude API


def count_nums(arr):
    """
    Write a function count_nums which takes an array of integers and returns
    the number of elements which has a sum of digits > 0.
    If a number is negative, then its first signed digit will be negative:
    e.g. -123 has signed digits -1, 2, and 3.
    >>> count_nums([]) == 0
    >>> count_nums([-1, 11, -11]) == 1
    >>> count_nums([1, 1, 2]) == 3
    """

    def digits_sum(n):
        neg = 1
        if n < 0: n, neg = -1 * n, -1 
        n = [int(i) for i in str(n)]
        n[0] = n[0] * neg
        return sum(n)
    return len(list(filter(lambda x: x > 0, [digits_sum(i) for i in arr])))


# Generated test cases:
import pytest

@pytest.mark.parametrize("arr,expected", [
    # Empty array
    ([], 0),
    
    # Single positive number
    ([123], 1),
    
    # Single negative number with positive digit sum
    ([-12], 1),  # -1 + 2 = 1 > 0
    
    # Single negative number with negative digit sum
    ([-123], 1),  # -1 + 2 + 3 = 4 > 0
    
    # Zero
    ([0], 0),
    
    # Mix of positive and negative numbers
    ([1, -2, 3, -4], 2),
    
    # All positive numbers
    ([1, 2, 3, 4, 5], 5),
    
    # All negative numbers
    ([-1, -2, -3, -4, -5], 0),
    
    # Numbers with digit sum equal to zero
    ([-10, -100, -1000], 0),
    
    # Large positive numbers
    ([999, 888, 777], 3),
    
    # Large negative numbers
    ([-999, -888, -777], 3),  # All have positive digit sums
    
    # Mixed with zeros
    ([0, 1, 0, -1, 0], 1),
    
    # Single digit positive
    ([1, 2, 3, 4, 5, 6, 7, 8, 9], 9),
    
    # Single digit negative
    ([-1, -2, -3, -4, -5, -6, -7, -8, -9], 0),
    
    # Numbers where negative has positive digit sum after processing
    ([-11], 0),  # -1 + 1 = 0
    
    # Positive number with multiple digits
    ([111], 1),  # 1 + 1 + 1 = 3 > 0
    
    # Negative number examples
    ([-21], 0),  # -2 + 1 = -1 < 0
    ([-12], 1),  # -1 + 2 = 1 > 0
    
    # Edge case with -10
    ([-10], 0),  # -1 + 0 = -1 < 0
    
    # Multiple same numbers
    ([1, 1, 1, 1], 4),
    
    # Mix including zero sum results
    ([10, -10, 20, -20], 2),
    
    # Very large number
    ([123456789], 1),
    
    # Very small (large negative) number
    ([-123456789], 1),  # -1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 = 44 > 0
])
def test_count_nums(arr, expected):
    assert count_nums(arr) == expected

def test_count_nums_with_specific_cases():
    # Test that -12 gives digit sum of 1 (which is > 0)
    assert count_nums([-12]) == 1
    
    # Test multiple negative numbers with varying digit sums
    # -111 has digit sum -1 + 1 + 1 = 1 > 0
    assert count_nums([-1, -11, -111]) == 1
    
    # Test positive multi-digit numbers
    assert count_nums([11, 22, 33]) == 3
    
    # Test edge case with -1
    assert count_nums([-1]) == 0
    
    # Test with only zero
    assert count_nums([0]) == 0