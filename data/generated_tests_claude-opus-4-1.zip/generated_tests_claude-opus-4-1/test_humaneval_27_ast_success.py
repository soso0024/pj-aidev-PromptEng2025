# Test cases for HumanEval/27
# Generated using Claude API



def flip_case(string: str) -> str:
    """ For a given string, flip lowercase characters to uppercase and uppercase to lowercase.
    >>> flip_case('Hello')
    'hELLO'
    """

    return string.swapcase()


# Generated test cases:
import pytest


@pytest.mark.parametrize("input_string,expected", [
    ("Hello World", "hELLO wORLD"),
    ("", ""),
    ("ABC", "abc"),
    ("abc", "ABC"),
    ("123", "123"),
    ("Hello123World", "hELLO123wORLD"),
    ("MiXeD CaSe", "mIxEd cAsE"),
    ("UPPERCASE", "uppercase"),
    ("lowercase", "LOWERCASE"),
    ("!@#$%^&*()", "!@#$%^&*()"),
    ("a", "A"),
    ("A", "a"),
    ("aA", "Aa"),
    ("Aa", "aA"),
    ("The Quick BROWN fox", "tHE qUICK brown FOX"),
    ("   spaces   ", "   SPACES   "),
    ("\t\n\r", "\t\n\r"),
    ("CamelCase", "cAMELcASE"),
    ("snake_case", "SNAKE_CASE"),
    ("SCREAMING_SNAKE_CASE", "screaming_snake_case"),
    ("kebab-case", "KEBAB-CASE"),
    ("PascalCase", "pASCALcASE"),
    ("αβγ", "ΑΒΓ"),
    ("Test\nMultiple\nLines", "tEST\nmULTIPLE\nlINES"),
    ("1234567890", "1234567890"),
    ("a1B2c3D4", "A1b2C3d4"),
    ("_underscore_", "_UNDERSCORE_"),
    (".", "."),
    ("'single quotes'", "'SINGLE QUOTES'"),
    ('"double quotes"', '"DOUBLE QUOTES"'),
    ("Mixed123CAPS456lower", "mIXED123caps456LOWER"),
    ("aBcDeFgHiJkLmNoPqRsTuVwXyZ", "AbCdEfGhIjKlMnOpQrStUvWxYz"),
    ("ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"),
    ("abcdefghijklmnopqrstuvwxyz", "ABCDEFGHIJKLMNOPQRSTUVWXYZ"),
    ("0123456789", "0123456789"),
    ("Hello, World!", "hELLO, wORLD!"),
    ("Python3.9", "pYTHON3.9"),
    ("test@email.com", "TEST@EMAIL.COM"),
    ("http://www.EXAMPLE.com", "HTTP://WWW.example.COM"),
    ("File_Name_2023.txt", "fILE_nAME_2023.TXT"),
    ("$100.00", "$100.00"),
    ("C:\\Users\\Test", "c:\\uSERS\\tEST"),
    ("/home/user/documents", "/HOME/USER/DOCUMENTS"),
    ("True", "tRUE"),
    ("False", "fALSE"),
    ("None", "nONE"),
    (" leading", " LEADING"),
    ("trailing ", "TRAILING "),
    ("  both  ", "  BOTH  "),
])
def test_flip_case(input_string, expected):
    assert flip_case(input_string) == expected


def test_flip_case_idempotent():
    test_string = "Hello World 123"
    assert flip_case(flip_case(test_string)) == test_string


def test_flip_case_preserves_length():
    test_strings = ["abc", "ABC", "Hello World", "123", "!@#$%"]
    for s in test_strings:
        assert len(flip_case(s)) == len(s)


def test_flip_case_type_return():
    result = flip_case("test")
    assert isinstance(result, str)