# Test cases for HumanEval/160
# Generated using Claude API


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and 
    the second list is a list of integers. Use the two given lists to build the algebric 
    expression and return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + ) 
    Subtraction ( - ) 
    Multiplication ( * ) 
    Floor division ( // ) 
    Exponentiation ( ** ) 

    Example:
    operator['+', '*', '-']
    array = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9

    Note:
        The length of operator list is equal to the length of operand list minus one.
        Operand is a list of of non-negative integers.
        Operator list has at least one operator, and operand list has at least two operands.

    """

    expression = str(operand[0])
    for oprt, oprn in zip(operator, operand[1:]):
        expression+= oprt + str(oprn)
    return eval(expression)


# Generated test cases:
import pytest

@pytest.mark.parametrize("operator,operand,expected", [
    (['+'], [1, 2], 3),
    (['-'], [5, 3], 2),
    (['*'], [4, 5], 20),
    (['//'], [10, 3], 3),
    (['**'], [2, 3], 8),
    (['+', '*', '-'], [2, 3, 4, 5], 9),
    (['*', '+'], [2, 3, 4], 10),
    (['-', '-'], [10, 3, 2], 5),
    (['*', '*'], [2, 3, 4], 24),
    (['//', '//'], [100, 10, 3], 3),
    (['**', '*'], [2, 3, 4], 32),
    (['+', '-', '*'], [1, 2, 3, 4], -9),
    (['*', '//', '+'], [5, 4, 2, 3], 13),
    (['+'], [0, 0], 0),
    (['*'], [0, 5], 0),
    (['**'], [0, 5], 0),
    (['**'], [5, 0], 1),
    (['-'], [0, 5], -5),
    (['//'], [0, 5], 0),
    (['+', '+', '+'], [1, 1, 1, 1], 4),
    (['-', '-', '-'], [10, 1, 1, 1], 7),
    (['*', '*', '*'], [2, 2, 2, 2], 16),
    (['//', '//', '//'], [100, 5, 2, 2], 5),
    (['**', '**'], [2, 2, 3], 256),
    (['*', '+', '-', '//'], [10, 2, 5, 3, 4], 25),
    (['+', '*'], [100, 200, 3], 700),
    (['//'], [7, 2], 3),
    (['//'], [8, 3], 2),
    (['**'], [10, 2], 100),
    (['**', '-'], [3, 2, 5], 4),
    (['-', '+'], [100, 50, 25], 75),
    (['*', '-', '+'], [2, 5, 3, 1], 8),
    (['+', '-', '*', '//'], [1, 2, 3, 4, 2], -3),
])
def test_do_algebra(operator, operand, expected):
    assert do_algebra(operator, operand) == expected

def test_single_operand_edge_cases():
    assert do_algebra(['+'], [100, 0]) == 100
    assert do_algebra(['*'], [100, 1]) == 100
    assert do_algebra(['//'], [100, 1]) == 100
    assert do_algebra(['**'], [100, 1]) == 100
    assert do_algebra(['-'], [100, 100]) == 0

def test_large_numbers():
    assert do_algebra(['+'], [999999, 1]) == 1000000
    assert do_algebra(['*'], [1000, 1000]) == 1000000
    assert do_algebra(['**'], [10, 6]) == 1000000

def test_operator_precedence():
    assert do_algebra(['+', '*'], [2, 3, 4]) == 14
    assert do_algebra(['*', '+'], [2, 3, 4]) == 10
    assert do_algebra(['-', '*'], [10, 2, 3]) == 4
    assert do_algebra(['*', '-'], [10, 2, 3]) == 17
    assert do_algebra(['**', '*'], [2, 3, 2]) == 16
    assert do_algebra(['*', '**'], [2, 3, 2]) == 18

def test_floor_division_specifics():
    assert do_algebra(['//'], [5, 2]) == 2
    assert do_algebra(['//'], [10, 3]) == 3
    assert do_algebra(['//'], [15, 4]) == 3
    assert do_algebra(['//'], [20, 6]) == 3
    assert do_algebra(['//'], [100, 100]) == 1

def test_exponentiation_specifics():
    assert do_algebra(['**'], [2, 10]) == 1024
    assert do_algebra(['**'], [3, 3]) == 27
    assert do_algebra(['**'], [5, 2]) == 25
    assert do_algebra(['**'], [1, 100]) == 1