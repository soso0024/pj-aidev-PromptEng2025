# Test cases for HumanEval/2
# Generated using Claude API



def truncate_number(number: float) -> float:
    """ Given a positive floating point number, it can be decomposed into
    and integer part (largest integer smaller than given number) and decimals
    (leftover part always smaller than 1).

    Return the decimal part of the number.
    >>> truncate_number(3.5)
    0.5
    """

    return number % 1.0


# Generated test cases:
import pytest
import math

def truncate_number(number: float) -> float:
    return number % 1.0

@pytest.mark.parametrize("number,expected", [
    (3.5, 0.5),
    (1.25, 0.25),
    (10.7, 0.7),
    (0.123, 0.123),
    (5.0, 0.0),
    (100.0, 0.0),
    (0.999, 0.999),
    (1.0, 0.0),
    (2.0, 0.0),
    (0.0, 0.0),
    (0.1, 0.1),
    (0.01, 0.01),
    (0.001, 0.001),
    (999.999, 0.999),
    (1234.5678, 0.5678),
    (7.89, 0.89),
    (42.42, 0.42),
    (3.14159, 0.14159),
    (2.71828, 0.71828),
    (9.99999, 0.99999),
])
def test_truncate_number_normal_cases(number, expected):
    result = truncate_number(number)
    assert abs(result - expected) < 1e-10

@pytest.mark.parametrize("number", [
    1e-10,
    1e-15,
    1e-20,
])
def test_truncate_number_very_small(number):
    result = truncate_number(number)
    assert abs(result - number) < 1e-20

@pytest.mark.parametrize("number", [
    1e10,
    1e15,
    1e20,
])
def test_truncate_number_very_large(number):
    result = truncate_number(number)
    assert result == 0.0

def test_truncate_number_float_precision():
    number = 1.1 + 0.1 + 0.1
    result = truncate_number(number)
    assert 0.29 < result < 0.31

def test_truncate_number_pi():
    result = truncate_number(math.pi)
    assert abs(result - (math.pi - 3.0)) < 1e-10

def test_truncate_number_e():
    result = truncate_number(math.e)
    assert abs(result - (math.e - 2.0)) < 1e-10
