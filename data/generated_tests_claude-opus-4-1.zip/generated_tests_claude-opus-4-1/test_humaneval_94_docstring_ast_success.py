# Test cases for HumanEval/94
# Generated using Claude API



def skjkasdkd(lst):
    """You are given a list of integers.
    You need to find the largest prime value and return the sum of its digits.

    Examples:
    For lst = [0,3,2,1,3,5,7,4,5,5,5,2,181,32,4,32,3,2,32,324,4,3] the output should be 10
    For lst = [1,0,1,8,2,4597,2,1,3,40,1,2,1,2,4,2,5,1] the output should be 25
    For lst = [1,3,1,32,5107,34,83278,109,163,23,2323,32,30,1,9,3] the output should be 13
    For lst = [0,724,32,71,99,32,6,0,5,91,83,0,5,6] the output should be 11
    For lst = [0,81,12,3,1,21] the output should be 3
    For lst = [0,8,1,2,1,7] the output should be 7
    """

    def isPrime(n):
        for i in range(2,int(n**0.5)+1):
            if n%i==0:
                return False

        return True
    maxx = 0
    i = 0
    while i < len(lst):
        if(lst[i] > maxx and isPrime(lst[i])):
            maxx = lst[i]
        i+=1
    result = sum(int(digit) for digit in str(maxx))
    return result



# Generated test cases:
import pytest

def skjkasdkd(lst):
    def isPrime(n):
        if n < 2:
            return False
        for i in range(2,int(n**0.5)+1):
            if n%i==0:
                return False
        return True
    maxx = 0
    i = 0
    while i < len(lst):
        if(lst[i] > maxx and isPrime(lst[i])):
            maxx = lst[i]
        i+=1
    result = sum(int(digit) for digit in str(maxx))
    return result


@pytest.mark.parametrize("lst,expected", [
    ([0,3,2,1,3,5,7,4,5,5,5,2,181,32,4,32,3,2,32,324,4,3], 10),
    ([1,0,1,8,2,4597,2,1,3,40,1,2,1,2,4,2,5,1], 25),
    ([1,3,1,32,5107,34,83278,109,163,23,2323,32,30,1,9,3], 13),
    ([0,724,32,71,99,32,6,0,5,91,83,0,5,6], 11),
    ([0,81,12,3,1,21], 3),
    ([0,8,1,2,1,7], 7),
])
def test_given_examples(lst, expected):
    assert skjkasdkd(lst) == expected


@pytest.mark.parametrize("lst,expected", [
    ([2], 2),
    ([3], 3),
    ([5], 5),
    ([7], 7),
    ([11], 2),
    ([13], 4),
    ([17], 8),
    ([19], 10),
    ([23], 5),
    ([29], 11),
])
def test_single_prime(lst, expected):
    assert skjkasdkd(lst) == expected


@pytest.mark.parametrize("lst,expected", [
    ([2, 3, 5, 7, 11], 2),
    ([7, 5, 3, 2], 7),
    ([13, 11, 7, 5, 3, 2], 4),
    ([97, 89, 83, 79, 73, 71], 16),
])
def test_multiple_primes(lst, expected):
    assert skjkasdkd(lst) == expected


@pytest.mark.parametrize("lst,expected", [
    ([0], 0),
    ([1], 0),
    ([4], 0),
    ([6], 0),
    ([8], 0),
    ([9], 0),
    ([10], 0),
])
def test_no_primes(lst, expected):
    assert skjkasdkd(lst) == expected


@pytest.mark.parametrize("lst,expected", [
    ([0, 1, 4, 6, 8, 9, 10], 0),
    ([100, 200, 300, 400], 0),
    ([15, 21, 25, 27, 33], 0),
])
def test_only_composite_numbers(lst, expected):
    assert skjkasdkd(lst) == expected


@pytest.mark.parametrize("lst,expected", [
    ([2, 4, 6, 8], 2),
    ([3, 6, 9, 12], 3),
    ([5, 10, 15, 20], 5),
    ([7, 14, 21, 28], 7),
])
def test_prime_with_multiples(lst, expected):
    assert skjkasdkd(lst) == expected


@pytest.mark.parametrize("lst,expected", [
    ([101], 2),
    ([103], 4),
    ([107], 8),
    ([109], 10),
    ([113], 5),
    ([127], 10),
    ([131], 5),
    ([137], 11),
    ([139], 13),
    ([149], 14),
])
def test_three_digit_primes(lst, expected):
    assert skjkasdkd(lst) == expected


@pytest.mark.parametrize("lst,expected", [
    ([997], 25),
    ([991], 19),
    ([983], 20),
    ([977], 23),
    ([971], 17),
    ([967], 22),
    ([953], 17),
    ([947], 20),
    ([941], 14),
    ([937], 19),
])
def test_large_three_digit_primes(lst, expected):
    assert skjkasdkd(lst) == expected


@pytest.mark.parametrize("lst,expected", [
    ([1009], 10),
    ([1013], 5),
    ([1019], 11),
    ([1021], 4),
    ([1031], 5),
    ([1033], 7),
    ([1039], 13),
    ([1049], 14),
    ([1051], 7),
    ([1061], 8),
])
def test_four_digit_primes(lst, expected):
    assert skjkasdkd(lst) == expected


@pytest.mark.parametrize("lst,expected", [
    ([2, 2, 2, 2], 2),
    ([3, 3, 3, 3], 3),
    ([5, 5, 5, 5], 5),
    ([7, 7, 7, 7], 7),
])
def test_duplicate_primes(lst, expected):
    assert skjkasdkd(lst) == expected


@pytest.mark.parametrize("lst,expected", [
    ([-1, -2, -3, -5, -7], 0),
    ([-11, -13, -17, -19], 0),
    ([0, -2, -3, -5], 0),
])
def test_negative_numbers(lst, expected):
    assert skjkasdkd(lst) == expected


@pytest.mark.parametrize("lst,expected", [
    ([2, -3, 5, -7, 11], 2),
    ([-2, 3, -5, 7, -11], 7),
    ([13, -13, 17, -17], 8),
])
def test_mixed_positive_negative(lst, expected):
    assert skjkasdkd(lst) == expected


def test_empty_list():
    assert skjkasdkd([]) == 0


@pytest.mark.parametrize("lst,expected", [
    ([9973], 28),
    ([9967], 31),
    ([9949], 31),
    ([9941], 23),
    ([9931], 22),
    ([9929], 29),
    ([9923], 23),
    ([9907], 25),
    ([9901], 19),
    ([9887], 32),
])
def test_large_four_digit_primes(lst, expected):
    assert skjkasdkd(lst) == expected