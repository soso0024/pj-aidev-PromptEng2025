# Test cases for HumanEval/45
# Generated using Claude API



def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """

    return a * h / 2.0


# Generated test cases:
import pytest
import math

def triangle_area(a, h):
    return a * h / 2.0

class TestTriangleArea:
    
    @pytest.mark.parametrize("a,h,expected", [
        (10, 5, 25.0),
        (6, 8, 24.0),
        (3, 4, 6.0),
        (1, 1, 0.5),
        (100, 50, 2500.0),
    ])
    def test_normal_cases(self, a, h, expected):
        assert triangle_area(a, h) == expected
    
    @pytest.mark.parametrize("a,h,expected", [
        (0, 5, 0.0),
        (5, 0, 0.0),
        (0, 0, 0.0),
    ])
    def test_zero_values(self, a, h, expected):
        assert triangle_area(a, h) == expected
    
    @pytest.mark.parametrize("a,h,expected", [
        (0.5, 0.5, 0.125),
        (1.5, 2.5, 1.875),
        (3.14, 2.71, 4.2547),
        (0.1, 0.1, 0.005),
    ])
    def test_decimal_values(self, a, h, expected):
        assert pytest.approx(triangle_area(a, h), rel=1e-4) == expected
    
    @pytest.mark.parametrize("a,h", [
        (-5, 10),
        (10, -5),
        (-10, -5),
    ])
    def test_negative_values(self, a, h):
        result = triangle_area(a, h)
        assert result == a * h / 2.0
    
    def test_large_values(self):
        a = 1000000
        h = 2000000
        expected = 1000000000000.0
        assert triangle_area(a, h) == expected
    
    def test_very_small_values(self):
        a = 0.000001
        h = 0.000002
        expected = 0.000000000001
        assert pytest.approx(triangle_area(a, h), abs=1e-15) == expected
    
    @pytest.mark.parametrize("a,h", [
        (float('inf'), 1),
        (1, float('inf')),
        (float('inf'), float('inf')),
    ])
    def test_infinity_values(self, a, h):
        result = triangle_area(a, h)
        assert math.isinf(result)
    
    def test_nan_values(self):
        result = triangle_area(float('nan'), 5)
        assert math.isnan(result)
        
        result = triangle_area(5, float('nan'))
        assert math.isnan(result)
        
        result = triangle_area(float('nan'), float('nan'))
        assert math.isnan(result)
