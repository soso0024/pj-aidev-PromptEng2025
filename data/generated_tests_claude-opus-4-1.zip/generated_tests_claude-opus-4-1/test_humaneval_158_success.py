# Test cases for HumanEval/158
# Generated using Claude API


def find_max(words):
    """Write a function that accepts a list of strings.
    The list contains different words. Return the word with maximum number
    of unique characters. If multiple strings have maximum number of unique
    characters, return the one which comes first in lexicographical order.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb" ,"cc"]) == ""aaaaaaa"
    """

    return sorted(words, key = lambda x: (-len(set(x)), x))[0]


# Generated test cases:
import pytest

def find_max(words):
    return sorted(words, key = lambda x: (-len(set(x)), x))[0]

@pytest.mark.parametrize("words,expected", [
    (["hello", "world", "python"], "python"),
    (["abc", "def", "ghi"], "abc"),
    (["aaa", "bbb", "ccc"], "aaa"),
    (["abcdef", "ghijkl", "mnopqr"], "abcdef"),
    (["a", "b", "c"], "a"),
    (["aa", "ab", "ac"], "ab"),
    (["xyz", "abc", "def"], "abc"),
    (["programming", "python", "java"], "programming"),
    (["test", "best", "rest"], "best"),
    (["apple", "banana", "cherry"], "cherry"),
    (["zzz", "aaa", "bbb"], "aaa"),
    (["abcd", "efgh", "ijkl"], "abcd"),
    (["single"], "single"),
    (["a"], "a"),
    (["aabbcc", "abcdef", "ghijkl"], "abcdef"),
    (["xyzzyx", "abccba", "defghi"], "defghi"),
    (["mississippi", "programming", "development"], "development"),
    (["aaa", "aaab", "aabc"], "aabc"),
    (["xyz", "xyzw", "xyzwv"], "xyzwv"),
    (["abcdefghij", "klmnopqrst", "uvwxyzabcd"], "abcdefghij"),
])
def test_find_max_normal_cases(words, expected):
    assert find_max(words) == expected

@pytest.mark.parametrize("words,expected", [
    ([""], ""),
    (["", "a"], "a"),
    (["", "", ""], ""),
    (["a", ""], "a"),
])
def test_find_max_empty_strings(words, expected):
    assert find_max(words) == expected

@pytest.mark.parametrize("words", [
    ["123", "456", "789"],
    ["!@#", "$%^", "&*()"],
    ["a1b2", "c3d4", "e5f6"],
    ["hello123", "world456", "test789"],
    [" ", "  ", "   "],
    ["a b", "c d", "e f"],
])
def test_find_max_special_characters(words):
    result = find_max(words)
    assert result in words

def test_find_max_unicode():
    words = ["café", "naïve", "résumé"]
    result = find_max(words)
    assert result in words

def test_find_max_mixed_case():
    words = ["ABC", "abc", "AbC"]
    result = find_max(words)
    assert result == "ABC"

def test_find_max_duplicate_unique_counts():
    words = ["abc", "def", "ghi", "jkl"]
    result = find_max(words)
    assert result == "abc"

def test_find_max_all_same_word():
    words = ["test", "test", "test"]
    result = find_max(words)
    assert result == "test"

def test_find_max_increasing_unique_chars():
    words = ["a", "ab", "abc", "abcd"]
    result = find_max(words)
    assert result == "abcd"

def test_find_max_decreasing_unique_chars():
    words = ["abcd", "abc", "ab", "a"]
    result = find_max(words)
    assert result == "abcd"

def test_find_max_with_numbers():
    words = ["12345", "67890", "13579"]
    result = find_max(words)
    assert result == "12345"

def test_find_max_long_strings():
    words = ["a" * 100, "ab" * 50, "abc" * 33]
    result = find_max(words)
    assert result == "abc" * 33

def test_find_max_type_error():
    with pytest.raises(TypeError):
        find_max(None)
    
    with pytest.raises(TypeError):
        find_max(123)

def test_find_max_empty_list():
    with pytest.raises(IndexError):
        find_max([])

def test_find_max_non_string_elements():
    with pytest.raises(TypeError):
        find_max([1, 2, 3])
    
    with pytest.raises(TypeError):
        find_max([None, None])