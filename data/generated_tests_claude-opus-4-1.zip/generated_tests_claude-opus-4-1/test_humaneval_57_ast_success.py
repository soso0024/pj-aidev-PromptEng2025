# Test cases for HumanEval/57
# Generated using Claude API



def monotonic(l: list):
    """Return True is list elements are monotonically increasing or decreasing.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """

    if l == sorted(l) or l == sorted(l, reverse=True):
        return True
    return False


# Generated test cases:
import pytest

@pytest.mark.parametrize("input_list,expected", [
    # Empty list
    ([], True),
    
    # Single element
    ([1], True),
    
    # Two elements - increasing
    ([1, 2], True),
    
    # Two elements - decreasing
    ([2, 1], True),
    
    # Two elements - equal
    ([1, 1], True),
    
    # Increasing sequences
    ([1, 2, 3, 4, 5], True),
    ([0, 1, 2, 3], True),
    ([-5, -3, -1, 0, 2], True),
    
    # Decreasing sequences
    ([5, 4, 3, 2, 1], True),
    ([10, 5, 0, -5], True),
    ([0, -1, -2, -3], True),
    
    # All equal elements
    ([1, 1, 1, 1], True),
    ([0, 0, 0], True),
    
    # Non-decreasing (with duplicates)
    ([1, 1, 2, 2, 3], True),
    ([1, 2, 2, 3, 3, 3], True),
    
    # Non-increasing (with duplicates)
    ([5, 5, 4, 3, 3, 1], True),
    ([10, 10, 10, 5, 5, 0], True),
    
    # Not monotonic
    ([1, 3, 2], False),
    ([1, 2, 1], False),
    ([3, 1, 2], False),
    ([1, 2, 3, 2, 4], False),
    ([5, 4, 3, 4, 2], False),
    
    # Mixed positive and negative - monotonic
    ([-3, -1, 0, 2, 5], True),
    ([5, 2, 0, -1, -3], True),
    
    # Mixed positive and negative - not monotonic
    ([-1, 2, -3], False),
    ([1, -1, 2], False),
    
    # Float values
    ([1.1, 2.2, 3.3], True),
    ([3.3, 2.2, 1.1], True),
    ([1.1, 3.3, 2.2], False),
    
    # Large numbers
    ([1000000, 2000000, 3000000], True),
    ([3000000, 2000000, 1000000], True),
    
    # Negative numbers only
    ([-1, -2, -3], True),
    ([-3, -2, -1], True),
    ([-1, -3, -2], False),
])
def test_monotonic(input_list, expected):
    assert monotonic(input_list) == expected

def test_monotonic_large_list_increasing():
    large_list = list(range(10000))
    assert monotonic(large_list) == True

def test_monotonic_large_list_decreasing():
    large_list = list(range(10000, 0, -1))
    assert monotonic(large_list) == True

def test_monotonic_large_list_not_monotonic():
    large_list = list(range(5000)) + list(range(5000, 0, -1))
    assert monotonic(large_list) == False