# Test cases for HumanEval/163
# Generated using Claude API


def generate_integers(a, b):
    """
    Given two positive integers a and b, return the even digits between a
    and b, in ascending order.

    For example:
    generate_integers(2, 8) => [2, 4, 6, 8]
    generate_integers(8, 2) => [2, 4, 6, 8]
    generate_integers(10, 14) => []
    """

    lower = max(2, min(a, b))
    upper = min(8, max(a, b))

    return [i for i in range(lower, upper+1) if i % 2 == 0]


# Generated test cases:
import pytest

def generate_integers(a, b):
    lower = max(2, min(a, b))
    upper = min(8, max(a, b))
    return [i for i in range(lower, upper+1) if i % 2 == 0]

@pytest.mark.parametrize("a,b,expected", [
    # Normal cases
    (2, 8, [2, 4, 6, 8]),
    (8, 2, [2, 4, 6, 8]),
    (1, 10, [2, 4, 6, 8]),
    (10, 1, [2, 4, 6, 8]),
    
    # Edge cases with boundaries
    (2, 2, [2]),
    (8, 8, [8]),
    (4, 4, [4]),
    (3, 3, []),
    (5, 5, []),
    (7, 7, []),
    
    # Cases where range is limited by 2 and 8
    (0, 10, [2, 4, 6, 8]),
    (-5, 15, [2, 4, 6, 8]),
    (0, 5, [2, 4]),
    (5, 10, [6, 8]),
    
    # Cases with negative numbers
    (-10, -1, []),
    (-5, 3, [2]),
    (3, -5, [2]),
    
    # Cases with one parameter below 2
    (1, 5, [2, 4]),
    (5, 1, [2, 4]),
    (0, 8, [2, 4, 6, 8]),
    (8, 0, [2, 4, 6, 8]),
    
    # Cases with one parameter above 8
    (3, 10, [4, 6, 8]),
    (10, 3, [4, 6, 8]),
    (2, 9, [2, 4, 6, 8]),
    (9, 2, [2, 4, 6, 8]),
    
    # Cases with both parameters outside [2, 8]
    (0, 1, []),
    (1, 0, []),
    (9, 10, []),
    (10, 9, []),
    (-10, 0, []),
    (15, 20, []),
    
    # Cases with odd number ranges
    (3, 7, [4, 6]),
    (7, 3, [4, 6]),
    (3, 5, [4]),
    (5, 3, [4]),
    
    # Cases with even number ranges
    (2, 6, [2, 4, 6]),
    (6, 2, [2, 4, 6]),
    (4, 8, [4, 6, 8]),
    (8, 4, [4, 6, 8]),
    
    # Same values
    (6, 6, [6]),
    (1, 1, []),
    (9, 9, []),
    
    # Large positive numbers
    (100, 200, []),
    (2, 100, [2, 4, 6, 8]),
    
    # Large negative numbers
    (-100, -50, []),
    (-100, 5, [2, 4]),
])
def test_generate_integers(a, b, expected):
    assert generate_integers(a, b) == expected

def test_generate_integers_type():
    result = generate_integers(2, 8)
    assert isinstance(result, list)
    assert all(isinstance(x, int) for x in result)

def test_generate_integers_even_only():
    result = generate_integers(1, 10)
    assert all(x % 2 == 0 for x in result)

def test_generate_integers_range_limits():
    result = generate_integers(-100, 100)
    assert all(2 <= x <= 8 for x in result)
