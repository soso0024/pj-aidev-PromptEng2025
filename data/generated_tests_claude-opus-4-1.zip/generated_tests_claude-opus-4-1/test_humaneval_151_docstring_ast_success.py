# Test cases for HumanEval/151
# Generated using Claude API


def double_the_difference(lst):
    '''
    Given a list of numbers, return the sum of squares of the numbers
    in the list that are odd. Ignore numbers that are negative or not integers.
    
    double_the_difference([1, 3, 2, 0]) == 1 + 9 + 0 + 0 = 10
    double_the_difference([-1, -2, 0]) == 0
    double_the_difference([9, -2]) == 81
    double_the_difference([0]) == 0  
   
    If the input list is empty, return 0.
    '''

    return sum([i**2 for i in lst if i > 0 and i%2!=0 and "." not in str(i)])


# Generated test cases:
import pytest

def double_the_difference(lst):
    return sum([i**2 for i in lst if i > 0 and i%2!=0 and "." not in str(i)])

@pytest.mark.parametrize("lst,expected", [
    # Basic test cases from docstring
    ([1, 3, 2, 0], 10),
    ([-1, -2, 0], 0),
    ([9, -2], 81),
    ([0], 0),
    
    # Empty list
    ([], 0),
    
    # Only positive odd integers
    ([1, 3, 5, 7], 84),
    ([1], 1),
    ([3], 9),
    
    # Only positive even integers
    ([2, 4, 6, 8], 0),
    ([2], 0),
    
    # Only negative numbers
    ([-1, -3, -5], 0),
    ([-2, -4, -6], 0),
    
    # Mixed positive and negative
    ([1, -1, 3, -3, 5, -5], 35),
    ([2, -2, 4, -4], 0),
    
    # Floats (should be ignored)
    ([1.5, 2.5, 3.5], 0),
    ([1.0, 3.0, 5.0], 0),
    ([1, 2.5, 3, 4.5, 5], 35),
    
    # Mixed integers and floats
    ([1, 1.5, 2, 2.5, 3, 3.5], 10),
    
    # Large numbers
    ([99, 101], 9801 + 10201),
    ([100, 200], 0),
    
    # Single elements
    ([5], 25),
    ([4], 0),
    ([-3], 0),
    ([2.5], 0),
    
    # Zero handling
    ([0, 0, 0], 0),
    ([0, 1, 0, 3, 0], 10),
    
    # Negative floats
    ([-1.5, -2.5, -3.5], 0),
    
    # Mixed types with zero
    ([0, -1, 1, -2, 2, -3, 3], 10),
    
    # All same odd number
    ([7, 7, 7], 147),
    
    # All same even number  
    ([4, 4, 4], 0),
    
    # Very small positive odd numbers
    ([1, 1, 1, 1], 4),
])
def test_double_the_difference(lst, expected):
    assert double_the_difference(lst) == expected

def test_double_the_difference_type_preservation():
    # Test that function handles different numeric types correctly
    assert double_the_difference([1, 3, 5]) == 35
    assert double_the_difference([1.0, 3.0, 5.0]) == 0
    
def test_double_the_difference_no_mutation():
    # Test that original list is not modified
    original = [1, 3, 2, 0]
    original_copy = original.copy()
    double_the_difference(original)
    assert original == original_copy
