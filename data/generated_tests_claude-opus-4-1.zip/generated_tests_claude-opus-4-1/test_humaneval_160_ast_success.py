# Test cases for HumanEval/160
# Generated using Claude API


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and 
    the second list is a list of integers. Use the two given lists to build the algebric 
    expression and return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + ) 
    Subtraction ( - ) 
    Multiplication ( * ) 
    Floor division ( // ) 
    Exponentiation ( ** ) 

    Example:
    operator['+', '*', '-']
    array = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9

    Note:
        The length of operator list is equal to the length of operand list minus one.
        Operand is a list of of non-negative integers.
        Operator list has at least one operator, and operand list has at least two operands.

    """

    expression = str(operand[0])
    for oprt, oprn in zip(operator, operand[1:]):
        expression+= oprt + str(oprn)
    return eval(expression)


# Generated test cases:
import pytest

@pytest.mark.parametrize("operator,operand,expected", [
    (['+'], [1, 2], 3),
    (['-'], [5, 3], 2),
    (['*'], [4, 3], 12),
    (['/'], [10, 2], 5.0),
    (['//'], [10, 3], 3),
    (['%'], [10, 3], 1),
    (['**'], [2, 3], 8),
    (['+', '*'], [2, 3, 4], 14),
    (['*', '+'], [2, 3, 4], 10),
    (['-', '+'], [10, 5, 3], 8),
    (['*', '/', '+'], [6, 2, 2, 1], 7.0),
    (['+', '-', '*'], [1, 2, 3, 4], -9),
    (['*', '*'], [2, 3, 2], 12),
    (['//', '%'], [17, 5, 2], 1),
    (['**', '-'], [2, 3, 5], 3),
    (['+', '+', '+'], [1, 2, 3, 4], 10),
    (['-', '-', '-'], [10, 1, 2, 3], 4),
    (['*', '*', '*'], [2, 2, 2, 2], 16),
    (['/', '/', '/'], [100, 2, 5, 2], 5.0),
    (['+'], [0, 0], 0),
    (['*'], [0, 100], 0),
    (['/'], [0, 1], 0.0),
    (['-'], [0, 5], -5),
    (['+', '*', '-'], [1, 2, 3, 4], 3),
    (['*', '+', '/'], [4, 3, 6, 2], 15.0),
    (['-'], [-5, -3], -2),
    (['+'], [-5, 3], -2),
    (['*'], [-2, -3], 6),
    (['/'], [-10, 2], -5.0),
    (['**'], [-2, 2], -4),
    (['+', '-'], [-1, 2, 3], -2),
    (['*', '+'], [-2, 3, 4], -2),
    (['/'], [1, 2], 0.5),
    (['/'], [3, 2], 1.5),
    (['//'], [7, 2], 3),
    (['%'], [7, 3], 1),
    (['**'], [10, 0], 1),
    (['**'], [0, 10], 0),
    (['+'], [1.5, 2.5], 4.0),
    (['*'], [2.5, 2], 5.0),
    (['-'], [5.5, 2.5], 3.0),
    (['/'], [7.5, 2.5], 3.0),
])
def test_do_algebra_normal_cases(operator, operand, expected):
    assert do_algebra(operator, operand) == expected

def test_do_algebra_single_operand():
    assert do_algebra([], [42]) == 42
    assert do_algebra([], [0]) == 0
    assert do_algebra([], [-5]) == -5
    assert do_algebra([], [3.14]) == 3.14

def test_do_algebra_division_by_zero():
    with pytest.raises(ZeroDivisionError):
        do_algebra(['/'], [5, 0])
    with pytest.raises(ZeroDivisionError):
        do_algebra(['//'], [5, 0])
    with pytest.raises(ZeroDivisionError):
        do_algebra(['%'], [5, 0])

def test_do_algebra_complex_expressions():
    assert do_algebra(['*', '+', '-', '/'], [2, 3, 4, 5, 2]) == 7.5
    assert do_algebra(['**', '*', '+'], [2, 2, 3, 4]) == 16
    assert do_algebra(['+', '*', '**'], [1, 2, 3, 2]) == 19

def test_do_algebra_operator_precedence():
    assert do_algebra(['+', '*'], [2, 3, 4]) == 14
    assert do_algebra(['*', '+'], [2, 3, 4]) == 10
    assert do_algebra(['**', '*'], [2, 3, 2]) == 16
    assert do_algebra(['*', '**'], [2, 3, 2]) == 18