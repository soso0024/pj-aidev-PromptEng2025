# Test cases for HumanEval/73
# Generated using Claude API


def smallest_change(arr):
    """
    Given an array arr of integers, find the minimum number of elements that
    need to be changed to make the array palindromic. A palindromic array is an array that
    is read the same backwards and forwards. In one change, you can change one element to any other element.

    For example:
    smallest_change([1,2,3,5,4,7,9,6]) == 4
    smallest_change([1, 2, 3, 4, 3, 2, 2]) == 1
    smallest_change([1, 2, 3, 2, 1]) == 0
    """

    ans = 0
    for i in range(len(arr) // 2):
        if arr[i] != arr[len(arr) - i - 1]:
            ans += 1
    return ans


# Generated test cases:
import pytest

def smallest_change(arr):
    ans = 0
    for i in range(len(arr) // 2):
        if arr[i] != arr[len(arr) - i - 1]:
            ans += 1
    return ans


@pytest.mark.parametrize("arr,expected", [
    # Examples from docstring
    ([1, 2, 3, 5, 4, 7, 9, 6], 4),
    ([1, 2, 3, 4, 3, 2, 2], 1),
    ([1, 2, 3, 2, 1], 0),
    
    # Empty array
    ([], 0),
    
    # Single element
    ([1], 0),
    
    # Two elements - same
    ([1, 1], 0),
    
    # Two elements - different
    ([1, 2], 1),
    
    # Already palindromic arrays
    ([1, 1, 1, 1], 0),
    ([1, 2, 2, 1], 0),
    ([5, 4, 3, 4, 5], 0),
    ([7, 7, 7, 7, 7], 0),
    
    # Arrays needing changes
    ([1, 2], 1),
    ([1, 2, 3], 1),
    ([1, 2, 3, 4], 2),
    ([1, 2, 3, 4, 5], 2),
    ([1, 2, 3, 4, 5, 6], 3),
    
    # Arrays with negative numbers
    ([-1, -2, -3, -2, -1], 0),
    ([-1, 2, -3, 2, -1], 0),
    ([-1, -2, -3, -4], 2),
    
    # Arrays with zeros
    ([0, 0, 0, 0], 0),
    ([0, 1, 2, 0], 1),
    ([0, 1, 1, 0], 0),
    
    # Large numbers
    ([1000000, 999999, 999999, 1000000], 0),
    ([1000000, 999999, 888888, 777777], 2),
    
    # Mixed positive and negative
    ([1, -1, 0, -1, 1], 0),
    ([1, -1, 0, 1, -1], 2),
    
    # Odd length arrays
    ([1, 2, 3, 2, 1], 0),
    ([1, 2, 3, 4, 5], 2),
    ([5, 4, 3, 2, 1], 2),
    
    # Even length arrays
    ([1, 2, 2, 1], 0),
    ([1, 2, 3, 4], 2),
    ([1, 2, 3, 4, 5, 6], 3),
    
    # Arrays with duplicates
    ([1, 1, 1, 2], 1),
    ([2, 2, 2, 2], 0),
    ([1, 2, 2, 2, 2, 1], 0),
    ([1, 2, 2, 2, 2, 3], 1),
    
    # Long arrays
    ([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 5),
    ([1] * 100, 0),
    (list(range(50)) + list(range(49, -1, -1)), 0),
])
def test_smallest_change(arr, expected):
    assert smallest_change(arr) == expected


def test_smallest_change_does_not_modify_input():
    arr = [1, 2, 3, 4, 5]
    original = arr.copy()
    smallest_change(arr)
    assert arr == original


def test_smallest_change_with_mutable_elements():
    # Test that function works correctly even if array contains same references
    arr = [1, 2, 3, 2, 1]
    assert smallest_change(arr) == 0
