# Test cases for HumanEval/109
# Generated using Claude API


def move_one_ball(arr):
    """We have an array 'arr' of N integers arr[1], arr[2], ..., arr[N].The
    numbers in the array will be randomly ordered. Your task is to determine if
    it is possible to get an array sorted in non-decreasing order by performing 
    the following operation on the given array:
        You are allowed to perform right shift operation any number of times.
    
    One right shift operation means shifting all elements of the array by one
    position in the right direction. The last element of the array will be moved to
    the starting position in the array i.e. 0th index. 

    If it is possible to obtain the sorted array by performing the above operation
    then return True else return False.
    If the given array is empty then return True.

    Note: The given list is guaranteed to have unique elements.

    For Example:
    
    move_one_ball([3, 4, 5, 1, 2])==>True
    Explanation: By performin 2 right shift operations, non-decreasing order can
                 be achieved for the given array.
    move_one_ball([3, 5, 4, 1, 2])==>False
    Explanation:It is not possible to get non-decreasing order for the given
                array by performing any number of right shift operations.
                
    """

    if len(arr)==0:
      return True
    sorted_array=sorted(arr)
    my_arr=[]
    
    min_value=min(arr)
    min_index=arr.index(min_value)
    my_arr=arr[min_index:]+arr[0:min_index]
    for i in range(len(arr)):
      if my_arr[i]!=sorted_array[i]:
        return False
    return True


# Generated test cases:
import pytest

@pytest.mark.parametrize("arr,expected", [
    # Empty array
    ([], True),
    
    # Single element
    ([1], True),
    
    # Already sorted
    ([1, 2, 3, 4, 5], True),
    
    # Rotated sorted arrays (should return True)
    ([3, 4, 5, 1, 2], True),
    ([2, 3, 4, 5, 1], True),
    ([5, 1, 2, 3, 4], True),
    ([4, 5, 1, 2, 3], True),
    
    # Not sortable by rotation
    ([3, 5, 4, 1, 2], False),
    ([1, 3, 2, 4, 5], False),
    ([5, 4, 3, 2, 1], False),
    
    # Arrays with duplicates
    ([2, 2, 3, 1, 1], True),
    ([3, 1, 1, 2, 2], True),
    ([1, 1, 1, 1], True),
    ([2, 1, 2, 1], False),
    
    # Two elements
    ([1, 2], True),
    ([2, 1], True),
    
    # Three elements
    ([1, 2, 3], True),
    ([2, 3, 1], True),
    ([3, 1, 2], True),
    ([1, 3, 2], False),
    ([2, 1, 3], False),
    ([3, 2, 1], False),
    
    # Negative numbers
    ([-3, -2, -1, 0, 1], True),
    ([0, 1, -3, -2, -1], True),
    ([-1, 0, 1, -3, -2], True),
    ([0, -1, 1, -2, 2], False),
    
    # Mixed positive and negative
    ([-5, -3, 0, 2, 4], True),
    ([2, 4, -5, -3, 0], True),
    ([4, -5, -3, 0, 2], True),
    
    # Large arrays
    ([10, 20, 30, 40, 50, 1, 2, 3, 4, 5], True),
    ([6, 7, 8, 9, 10, 1, 2, 3, 4, 5], True),
    
    # Arrays where minimum appears multiple times
    ([1, 2, 3, 1, 4], False),
    ([2, 3, 4, 1, 1], True),  # This is actually sortable: [1, 1, 2, 3, 4]
    
    # Arrays with all same elements
    ([5, 5, 5, 5, 5], True),
    ([0, 0, 0], True),
    
    # Arrays with floating point (if supported)
    ([1.5, 2.5, 3.5, 0.5], True),
    ([2.5, 3.5, 0.5, 1.5], True),
])
def test_move_one_ball(arr, expected):
    assert move_one_ball(arr) == expected

def test_move_one_ball_does_not_modify_input():
    original = [3, 4, 5, 1, 2]
    copy = original.copy()
    move_one_ball(original)
    assert original == copy

def test_move_one_ball_with_large_rotated_array():
    arr = list(range(50, 100)) + list(range(0, 50))
    assert move_one_ball(arr) == True

def test_move_one_ball_with_large_unsortable_array():
    arr = list(range(50, 100)) + [0] + list(range(1, 50))
    arr[75] = 200  # Break the rotation property
    assert move_one_ball(arr) == False