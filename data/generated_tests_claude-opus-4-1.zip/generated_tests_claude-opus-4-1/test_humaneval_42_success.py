# Test cases for HumanEval/42
# Generated using Claude API



def incr_list(l: list):
    """Return list with elements incremented by 1.
    >>> incr_list([1, 2, 3])
    [2, 3, 4]
    >>> incr_list([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [6, 4, 6, 3, 4, 4, 10, 1, 124]
    """

    return [(e + 1) for e in l]


# Generated test cases:
import pytest


def incr_list(l: list):
    return [(e + 1) for e in l]


class TestIncrList:
    def test_empty_list(self):
        assert incr_list([]) == []
    
    def test_single_element(self):
        assert incr_list([5]) == [6]
    
    def test_multiple_positive_integers(self):
        assert incr_list([1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]
    
    def test_negative_integers(self):
        assert incr_list([-5, -3, -1]) == [-4, -2, 0]
    
    def test_mixed_positive_negative(self):
        assert incr_list([-2, -1, 0, 1, 2]) == [-1, 0, 1, 2, 3]
    
    def test_zero_values(self):
        assert incr_list([0, 0, 0]) == [1, 1, 1]
    
    def test_large_numbers(self):
        assert incr_list([999999, 1000000]) == [1000000, 1000001]
    
    def test_floats(self):
        assert incr_list([1.5, 2.7, 3.0]) == [2.5, 3.7, 4.0]
    
    def test_mixed_int_float(self):
        assert incr_list([1, 2.5, 3]) == [2, 3.5, 4]
    
    @pytest.mark.parametrize("input_list,expected", [
        ([10], [11]),
        ([0, 1, 2], [1, 2, 3]),
        ([-10, -5, 0, 5, 10], [-9, -4, 1, 6, 11]),
        ([0.1, 0.2, 0.3], [1.1, 1.2, 1.3])
    ])
    def test_parametrized_cases(self, input_list, expected):
        assert incr_list(input_list) == expected
    
    def test_very_large_list(self):
        input_list = list(range(1000))
        expected = list(range(1, 1001))
        assert incr_list(input_list) == expected
    
    def test_negative_floats(self):
        result = incr_list([-1.5, -2.5, -3.5])
        assert result == [-0.5, -1.5, -2.5]
    
    def test_scientific_notation(self):
        assert incr_list([1e10, 2e10]) == [1e10 + 1, 2e10 + 1]
    
    def test_does_not_modify_original(self):
        original = [1, 2, 3]
        result = incr_list(original)
        assert original == [1, 2, 3]
        assert result == [2, 3, 4]
