# Test cases for HumanEval/57
# Generated using Claude API



def monotonic(l: list):
    """Return True is list elements are monotonically increasing or decreasing.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """

    if l == sorted(l) or l == sorted(l, reverse=True):
        return True
    return False


# Generated test cases:
import pytest


def monotonic(l: list):
    if l == sorted(l) or l == sorted(l, reverse=True):
        return True
    return False


@pytest.mark.parametrize("input_list,expected", [
    # Increasing sequences
    ([1, 2, 4, 20], True),
    ([1, 2, 3, 4, 5], True),
    ([0, 1, 2, 3], True),
    ([-5, -3, -1, 0, 2], True),
    ([1, 1, 2, 3], True),
    
    # Decreasing sequences
    ([4, 1, 0, -10], True),
    ([5, 4, 3, 2, 1], True),
    ([10, 5, 0, -5], True),
    ([3, 2, 2, 1], True),
    
    # Non-monotonic sequences
    ([1, 20, 4, 10], False),
    ([1, 3, 2, 4], False),
    ([5, 1, 3, 2], False),
    ([1, 2, 1, 2], False),
    
    # Edge cases
    ([], True),  # Empty list
    ([1], True),  # Single element
    ([5, 5], True),  # Two equal elements
    ([1, 1, 1, 1], True),  # All equal elements
    
    # With duplicates
    ([1, 2, 2, 3, 4], True),  # Increasing with duplicates
    ([5, 4, 4, 3, 2], True),  # Decreasing with duplicates
    ([1, 2, 2, 1], False),  # Non-monotonic with duplicates
    
    # Negative numbers
    ([-1, -2, -3], True),  # Decreasing negatives
    ([-3, -2, -1], True),  # Increasing negatives
    ([-1, -3, -2], False),  # Non-monotonic negatives
    
    # Mixed positive and negative
    ([-2, -1, 0, 1, 2], True),
    ([2, 1, 0, -1, -2], True),
    ([-1, 2, -3, 4], False),
    
    # Float values
    ([1.1, 2.2, 3.3], True),
    ([3.3, 2.2, 1.1], True),
    ([1.1, 3.3, 2.2], False),
])
def test_monotonic(input_list, expected):
    assert monotonic(input_list) == expected


def test_monotonic_with_large_lists():
    # Large increasing list
    assert monotonic(list(range(1000))) == True
    
    # Large decreasing list
    assert monotonic(list(range(1000, 0, -1))) == True
    
    # Large non-monotonic list
    large_list = list(range(500)) + list(range(499, -1, -1))
    assert monotonic(large_list) == False


def test_monotonic_with_special_values():
    # With None should raise error (if function doesn't handle it)
    # Uncomment if you want to test error handling
    # with pytest.raises(TypeError):
    #     monotonic([1, None, 3])
    
    # Test with infinity
    assert monotonic([float('-inf'), -1, 0, 1, float('inf')]) == True
    assert monotonic([float('inf'), 1, 0, -1, float('-inf')]) == True
