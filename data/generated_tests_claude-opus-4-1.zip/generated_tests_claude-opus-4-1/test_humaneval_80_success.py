# Test cases for HumanEval/80
# Generated using Claude API


def is_happy(s):
    """You are given a string s.
    Your task is to check if the string is happy or not.
    A string is happy if its length is at least 3 and every 3 consecutive letters are distinct
    For example:
    is_happy(a) => False
    is_happy(aa) => False
    is_happy(abcd) => True
    is_happy(aabb) => False
    is_happy(adb) => True
    is_happy(xyy) => False
    """

    if len(s) < 3:
      return False

    for i in range(len(s) - 2):
      
      if s[i] == s[i+1] or s[i+1] == s[i+2] or s[i] == s[i+2]:
        return False
    return True


# Generated test cases:
import pytest


@pytest.mark.parametrize("input_str,expected", [
    # Edge cases - strings too short
    ("", False),
    ("a", False),
    ("ab", False),
    
    # Minimum valid length - all different
    ("abc", True),
    ("xyz", True),
    
    # Minimum valid length - with repeats
    ("aab", False),
    ("abb", False),
    ("aba", False),
    ("aaa", False),
    
    # Longer strings - happy cases
    ("abcdef", True),
    ("abcabcabc", True),
    ("xyzxyz", True),
    
    # Longer strings - unhappy cases (adjacent repeats)
    ("aabcd", False),
    ("abccd", False),
    ("abcdd", False),
    
    # Longer strings - unhappy cases (repeats with one gap)
    ("abacde", False),
    ("abcaca", False),
    ("xyzxzx", False),
    
    # Mixed cases
    ("abcdabcd", True),
    ("abcdefghijk", True),
    ("aabbcc", False),
    ("ababab", False),
    
    # Special characters and numbers
    ("123", True),
    ("112", False),
    ("121", False),
    ("!@#", True),
    ("!@!", False),
    
    # Longer test cases
    ("abcdefghijklmnop", True),
    ("abcdefghijklmmnop", False),
    ("abcabcabcabcabc", True),
    ("abcabcabcabcaabc", False),
])
def test_is_happy(input_str, expected):
    assert is_happy(input_str) == expected


def test_is_happy_empty_string():
    assert is_happy("") == False


def test_is_happy_single_char():
    assert is_happy("x") == False


def test_is_happy_two_chars():
    assert is_happy("xy") == False
    assert is_happy("xx") == False


def test_is_happy_three_chars_all_same():
    assert is_happy("aaa") == False
    assert is_happy("111") == False


def test_is_happy_three_chars_two_same():
    assert is_happy("aab") == False
    assert is_happy("aba") == False
    assert is_happy("baa") == False


def test_is_happy_three_chars_all_different():
    assert is_happy("abc") == True
    assert is_happy("xyz") == True
    assert is_happy("123") == True


def test_is_happy_four_chars():
    assert is_happy("abcd") == True
    assert is_happy("abca") == True  # 'a' at positions 0 and 3 are not within 2 positions
    assert is_happy("abac") == False
    assert is_happy("aabc") == False
    assert is_happy("abcc") == False


def test_is_happy_repeating_pattern():
    assert is_happy("abcabc") == True
    assert is_happy("xyzxyzxyz") == True


def test_is_happy_with_spaces():
    assert is_happy("a b c") == False  # ' ' at positions 1 and 3 are within 2 positions
    assert is_happy("a a b") == False
    assert is_happy("a b a") == False