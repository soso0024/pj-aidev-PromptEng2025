# Test cases for HumanEval/48
# Generated using Claude API



def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """

    for i in range(len(text)):
        if text[i] != text[len(text) - 1 - i]:
            return False
    return True


# Generated test cases:
import pytest


@pytest.mark.parametrize("text,expected", [
    ("", True),
    ("a", True),
    ("aa", True),
    ("aba", True),
    ("abba", True),
    ("racecar", True),
    ("A man a plan a canal Panama", False),
    ("race a car", False),
    ("hello", False),
    ("ab", False),
    ("abc", False),
    ("abcd", False),
    ("noon", True),
    ("level", True),
    ("radar", True),
    ("madam", True),
    ("kayak", True),
    ("rotator", True),
    ("121", True),
    ("12321", True),
    ("123321", True),
    ("1234321", True),
    ("123", False),
    ("1234", False),
    ("12345", False),
    ("AAA", True),
    ("ABA", True),
    ("ABC", False),
    ("AbA", True),
    ("   ", True),
    ("  a  ", True),
    ("a b a", True),
    ("a b c", False),
    ("!@#@!", True),
    ("!@#$%", False),
    ("🙂🙂", True),
    ("🙂😊🙂", True),
    ("🙂😊", False),
])
def test_is_palindrome(text, expected):
    assert is_palindrome(text) == expected


def test_is_palindrome_empty_string():
    assert is_palindrome("") == True


def test_is_palindrome_single_character():
    assert is_palindrome("x") == True
    assert is_palindrome("Z") == True
    assert is_palindrome("5") == True
    assert is_palindrome("!") == True


def test_is_palindrome_two_characters():
    assert is_palindrome("xx") == True
    assert is_palindrome("xy") == False


def test_is_palindrome_odd_length():
    assert is_palindrome("aba") == True
    assert is_palindrome("abc") == False
    assert is_palindrome("12321") == True
    assert is_palindrome("12345") == False


def test_is_palindrome_even_length():
    assert is_palindrome("abba") == True
    assert is_palindrome("abcd") == False
    assert is_palindrome("1221") == True
    assert is_palindrome("1234") == False


def test_is_palindrome_case_sensitive():
    assert is_palindrome("Aa") == False
    assert is_palindrome("AaA") == True
    assert is_palindrome("aAa") == True


def test_is_palindrome_with_spaces():
    assert is_palindrome("a a") == True
    assert is_palindrome("a b a") == True
    assert is_palindrome("ab ba") == True
    assert is_palindrome("a bc") == False


def test_is_palindrome_special_characters():
    assert is_palindrome("!@!") == True
    assert is_palindrome("#$#") == True
    assert is_palindrome("!@#") == False


def test_is_palindrome_numbers():
    assert is_palindrome("121") == True
    assert is_palindrome("1221") == True
    assert is_palindrome("123") == False
    assert is_palindrome("1234") == False


def test_is_palindrome_long_strings():
    assert is_palindrome("a" * 1000 + "a" * 1000) == True
    assert is_palindrome("a" * 1000 + "b" + "a" * 1000) == True
    assert is_palindrome("a" * 1000 + "b" * 1000) == False