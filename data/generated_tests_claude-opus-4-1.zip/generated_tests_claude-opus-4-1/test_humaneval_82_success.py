# Test cases for HumanEval/82
# Generated using Claude API


def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise
    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """

    l = len(string)
    if l == 0 or l == 1:
        return False
    for i in range(2, l):
        if l % i == 0:
            return False
    return True


# Generated test cases:
import pytest

@pytest.mark.parametrize("input_string,expected", [
    # Prime length strings
    ("ab", True),  # length 2
    ("abc", True),  # length 3
    ("abcde", True),  # length 5
    ("abcdefg", True),  # length 7
    ("abcdefghijk", True),  # length 11
    ("abcdefghijklm", True),  # length 13
    ("abcdefghijklmnopq", True),  # length 17
    ("abcdefghijklmnopqrs", True),  # length 19
    ("abcdefghijklmnopqrstu", False),  # length 22 (not prime)
    
    # Non-prime length strings
    ("", False),  # length 0
    ("a", False),  # length 1
    ("abcd", False),  # length 4
    ("abcdef", False),  # length 6
    ("abcdefgh", False),  # length 8
    ("abcdefghi", False),  # length 9
    ("abcdefghij", False),  # length 10
    ("abcdefghijkl", False),  # length 12
    ("abcdefghijklmno", False),  # length 15
    
    # Special characters and spaces
    ("  ", True),  # length 2 with spaces
    ("   ", True),  # length 3 with spaces
    ("    ", False),  # length 4 with spaces
    ("!@#$%", True),  # length 5 with special chars
    ("123456", False),  # length 6 with numbers
    
    # Unicode characters
    ("αβ", True),  # length 2 with Greek letters
    ("你好世", True),  # length 3 with Chinese characters
    ("😀😁😂😃", False),  # length 4 with emojis
    
    # Mixed content
    ("a b", True),  # length 3 with space
    ("test123", True),  # length 7 mixed alphanumeric
    ("\n\t", True),  # length 2 with escape characters
    ("hello\nworld", True),  # length 11 with newline
])
def test_prime_length(input_string, expected):
    assert prime_length(input_string) == expected

def test_prime_length_edge_cases():
    # Test with very long prime length string (29 characters)
    assert prime_length("a" * 29) == True
    
    # Test with very long non-prime length string (30 characters)
    assert prime_length("a" * 30) == False
    
    # Test with length 31 (prime)
    assert prime_length("a" * 31) == True
    
    # Test with length 32 (non-prime, power of 2)
    assert prime_length("a" * 32) == False

def test_prime_length_with_none_type():
    with pytest.raises(TypeError):
        prime_length(None)

def test_prime_length_with_non_string_types():
    # The function doesn't check for type, it just calls len() on the input
    # len() works on lists and dicts, so these won't raise TypeError
    assert prime_length([1, 2, 3]) == True  # length 3 is prime
    assert prime_length({'key': 'value'}) == False  # length 1 is not prime
    
    # This will raise TypeError because len() doesn't work on integers
    with pytest.raises(TypeError):
        prime_length(123)