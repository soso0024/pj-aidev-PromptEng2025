# Test cases for HumanEval/141
# Generated using Claude API


def file_name_check(file_name):
    """Create a function which takes a string representing a file's name, and returns
    'Yes' if the the file's name is valid, and returns 'No' otherwise.
    A file's name is considered to be valid if and only if all the following conditions 
    are met:
    - There should not be more than three digits ('0'-'9') in the file's name.
    - The file's name contains exactly one dot '.'
    - The substring before the dot should not be empty, and it starts with a letter from 
    the latin alphapet ('a'-'z' and 'A'-'Z').
    - The substring after the dot should be one of these: ['txt', 'exe', 'dll']
    Examples:
    file_name_check("example.txt") # => 'Yes'
    file_name_check("1example.dll") # => 'No' (the name should start with a latin alphapet letter)
    """

    suf = ['txt', 'exe', 'dll']
    lst = file_name.split(sep='.')
    if len(lst) != 2:
        return 'No'
    if not lst[1] in suf:
        return 'No'
    if len(lst[0]) == 0:
        return 'No'
    if not lst[0][0].isalpha():
        return 'No'
    t = len([x for x in lst[0] if x.isdigit()])
    if t > 3:
        return 'No'
    return 'Yes'


# Generated test cases:
import pytest

def file_name_check(file_name):
    suf = ['txt', 'exe', 'dll']
    lst = file_name.split(sep='.')
    if len(lst) != 2:
        return 'No'
    if not lst[1] in suf:
        return 'No'
    if len(lst[0]) == 0:
        return 'No'
    if not lst[0][0].isalpha():
        return 'No'
    t = len([x for x in lst[0] if x.isdigit()])
    if t > 3:
        return 'No'
    return 'Yes'


@pytest.mark.parametrize("file_name,expected", [
    # Valid cases
    ("example.txt", "Yes"),
    ("Example.exe", "Yes"),
    ("TEST.dll", "Yes"),
    ("a.txt", "Yes"),
    ("Z.exe", "Yes"),
    ("file123.txt", "Yes"),
    ("a1b2c3.dll", "Yes"),
    ("Test123.exe", "Yes"),
    
    # Invalid: doesn't start with letter
    ("1example.dll", "No"),
    ("123.txt", "No"),
    ("_test.exe", "No"),
    ("-file.dll", "No"),
    (" test.txt", "No"),
    
    # Invalid: more than 3 digits
    ("file1234.txt", "No"),
    ("a1b2c3d4.exe", "No"),
    ("test12345.dll", "No"),
    
    # Invalid: no dot or multiple dots
    ("filetxt", "No"),
    ("file.txt.exe", "No"),
    ("file..txt", "No"),
    ("test.file.dll", "No"),
    
    # Invalid: empty before dot
    (".txt", "No"),
    (".exe", "No"),
    (".dll", "No"),
    
    # Invalid: wrong extension
    ("file.doc", "No"),
    ("test.pdf", "No"),
    ("example.TXT", "No"),
    ("file.EXE", "No"),
    ("test.DLL", "No"),
    ("file.tx", "No"),
    ("file.txtx", "No"),
    
    # Edge cases
    ("a000.txt", "Yes"),
    ("file999.exe", "Yes"),
    ("ABC123.dll", "Yes"),
    ("zZ9z9z9.txt", "Yes"),
    
    # Special characters
    ("file@.txt", "Yes"),
    ("test#123.exe", "Yes"),
    ("a_b-c.dll", "Yes"),
    ("file!@#.txt", "Yes"),
    
    # Empty string
    ("", "No"),
    
    # Just extension
    ("txt", "No"),
    ("exe", "No"),
    ("dll", "No"),
    
    # Just dot
    (".", "No"),
    
    # Mixed case in name part
    ("AbCdEf123.txt", "Yes"),
    ("zYxWvU.exe", "Yes"),
])
def test_file_name_check(file_name, expected):
    assert file_name_check(file_name) == expected


def test_file_name_check_digit_boundary():
    assert file_name_check("a111.txt") == "Yes"
    assert file_name_check("a1111.txt") == "No"
    assert file_name_check("abc1d2e3.exe") == "Yes"
    assert file_name_check("abc1d2e3f4.exe") == "No"


def test_file_name_check_case_sensitivity():
    assert file_name_check("a.txt") == "Yes"
    assert file_name_check("A.txt") == "Yes"
    assert file_name_check("z.exe") == "Yes"
    assert file_name_check("Z.dll") == "Yes"


def test_file_name_check_special_names():
    assert file_name_check("a.txt.txt") == "No"
    assert file_name_check("exe.exe") == "Yes"
    assert file_name_check("dll.dll") == "Yes"
    assert file_name_check("txt.txt") == "Yes"
