# Test cases for HumanEval/27
# Generated using Claude API



def flip_case(string: str) -> str:
    """ For a given string, flip lowercase characters to uppercase and uppercase to lowercase.
    >>> flip_case('Hello')
    'hELLO'
    """

    return string.swapcase()


# Generated test cases:
import pytest


@pytest.mark.parametrize("input_string,expected", [
    ("Hello World", "hELLO wORLD"),
    ("ABC", "abc"),
    ("abc", "ABC"),
    ("123", "123"),
    ("", ""),
    ("HeLLo WoRLD!", "hEllO wOrld!"),
    ("Python3.9", "pYTHON3.9"),
    ("MiXeD CaSe", "mIxEd cAsE"),
    ("UPPERCASE", "uppercase"),
    ("lowercase", "LOWERCASE"),
    ("1234567890", "1234567890"),
    ("!@#$%^&*()", "!@#$%^&*()"),
    ("a", "A"),
    ("Z", "z"),
    ("aB3#xY", "Ab3#Xy"),
    ("   spaces   ", "   SPACES   "),
    ("\t\n", "\t\n"),
    ("CamelCase", "cAMELcASE"),
    ("snake_case", "SNAKE_CASE"),
    ("SCREAMING_SNAKE_CASE", "screaming_snake_case"),
    ("kebab-case", "KEBAB-CASE"),
    ("PascalCase", "pASCALcASE"),
    ("αβγ", "ΑΒΓ"),
    ("Hello\nWorld", "hELLO\nwORLD"),
    ("Test\tCase", "tEST\tcASE"),
    ("Mixed123Numbers456", "mIXED123nUMBERS456"),
    ("a1B2c3D4", "A1b2C3d4"),
    ("___", "___"),
    ("A B C", "a b c"),
    ("x" * 1000, "X" * 1000),
    ("X" * 1000, "x" * 1000),
    ("aBc" * 100, "AbC" * 100),
])
def test_flip_case(input_string, expected):
    assert flip_case(input_string) == expected


def test_flip_case_idempotent():
    test_string = "Hello World 123!"
    assert flip_case(flip_case(test_string)) == test_string


def test_flip_case_preserves_length():
    test_strings = ["Hello", "WORLD", "123abc", "", "!@#$%"]
    for s in test_strings:
        assert len(flip_case(s)) == len(s)


def test_flip_case_with_special_characters():
    assert flip_case("Hello, World!") == "hELLO, wORLD!"
    assert flip_case("user@example.com") == "USER@EXAMPLE.COM"
    assert flip_case("Price: $99.99") == "pRICE: $99.99"


def test_flip_case_unicode():
    assert flip_case("Café") == "cAFÉ"
    assert flip_case("ÑOÑO") == "ñoño"


def test_flip_case_type():
    result = flip_case("test")
    assert isinstance(result, str)