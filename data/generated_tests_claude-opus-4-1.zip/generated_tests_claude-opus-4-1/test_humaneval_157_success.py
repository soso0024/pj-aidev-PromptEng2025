# Test cases for HumanEval/157
# Generated using Claude API


def right_angle_triangle(a, b, c):
    '''
    Given the lengths of the three sides of a triangle. Return True if the three
    sides form a right-angled triangle, False otherwise.
    A right-angled triangle is a triangle in which one angle is right angle or 
    90 degree.
    Example:
    right_angle_triangle(3, 4, 5) == True
    right_angle_triangle(1, 2, 3) == False
    '''

    return a*a == b*b + c*c or b*b == a*a + c*c or c*c == a*a + b*b


# Generated test cases:
import pytest
import math

@pytest.mark.parametrize("a,b,c,expected", [
    # Classic Pythagorean triples
    (3, 4, 5, True),
    (5, 12, 13, True),
    (8, 15, 17, True),
    (7, 24, 25, True),
    (20, 21, 29, True),
    (9, 40, 41, True),
    (11, 60, 61, True),
    (12, 35, 37, True),
    (13, 84, 85, True),
    
    # Different order of parameters (should still work)
    (5, 3, 4, True),
    (4, 5, 3, True),
    (13, 5, 12, True),
    (12, 13, 5, True),
    
    # Not right triangles
    (1, 2, 3, False),
    (2, 3, 4, False),
    (5, 5, 5, False),
    (10, 10, 10, False),
    (1, 1, 3, False),
    
    # Edge cases with zeros
    (0, 0, 0, True),
    (0, 1, 1, True),
    (1, 0, 1, True),
    (1, 1, 0, True),
    (0, 3, 4, False),
    (3, 0, 4, False),
    (3, 4, 0, False),
    
    # Negative numbers (should still work mathematically)
    (-3, 4, 5, True),
    (3, -4, 5, True),
    (3, 4, -5, True),
    (-3, -4, 5, True),
    (-3, -4, -5, True),
    
    # Floating point numbers
    (1.5, 2.0, 2.5, True),
    (0.3, 0.4, 0.5, True),
    (6.0, 8.0, 10.0, True),
    
    # Large numbers
    (300, 400, 500, True),
    (3000, 4000, 5000, True),
    
    # Small decimal differences (not right triangles)
    (3.01, 4, 5, False),
    (3, 4.01, 5, False),
    (3, 4, 5.01, False),
    
    # Equal sides (isosceles but not right)
    (2, 2, 3, False),
    (5, 5, 7, False),
    
    # Special case: degenerate triangles
    (5, 0, 5, True),
    (0, 5, 5, True),
    (5, 5, 0, True),
])
def test_right_angle_triangle(a, b, c, expected):
    assert right_angle_triangle(a, b, c) == expected

def test_right_angle_triangle_with_very_large_numbers():
    assert right_angle_triangle(30000, 40000, 50000) == True
    assert right_angle_triangle(99999, 99999, 99999) == False

def test_right_angle_triangle_with_very_small_decimals():
    # Due to floating point precision issues, these may not be exact
    assert abs(0.003**2 + 0.004**2 - 0.005**2) < 1e-10
    assert abs(0.0003**2 + 0.0004**2 - 0.0005**2) < 1e-10
    # The function uses exact equality, so 0.003, 0.004, 0.005 will be False due to precision
    assert right_angle_triangle(0.003, 0.004, 0.005) == False
    # But 0.0003, 0.0004, 0.0005 happens to work with exact equality
    assert right_angle_triangle(0.0003, 0.0004, 0.0005) == True

def test_right_angle_triangle_floating_point_precision():
    a = 3
    b = 4
    c = math.sqrt(a*a + b*b)
    # c is exactly 5.0, which works with exact equality
    assert right_angle_triangle(a, b, c) == True