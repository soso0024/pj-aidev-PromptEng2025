# Test cases for HumanEval/105
# Generated using Claude API


def by_length(arr):
    """
    Given an array of integers, sort the integers that are between 1 and 9 inclusive,
    reverse the resulting array, and then replace each digit by its corresponding name from
    "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine".

    For example:
      arr = [2, 1, 1, 4, 5, 8, 2, 3]   
            -> sort arr -> [1, 1, 2, 2, 3, 4, 5, 8] 
            -> reverse arr -> [8, 5, 4, 3, 2, 2, 1, 1]
      return ["Eight", "Five", "Four", "Three", "Two", "Two", "One", "One"]
    
      If the array is empty, return an empty array:
      arr = []
      return []
    
      If the array has any strange number ignore it:
      arr = [1, -1 , 55] 
            -> sort arr -> [-1, 1, 55]
            -> reverse arr -> [55, 1, -1]
      return = ['One']
    """

    dic = {
        1: "One",
        2: "Two",
        3: "Three",
        4: "Four",
        5: "Five",
        6: "Six",
        7: "Seven",
        8: "Eight",
        9: "Nine",
    }
    sorted_arr = sorted(arr, reverse=True)
    new_arr = []
    for var in sorted_arr:
        try:
            new_arr.append(dic[var])
        except:
            pass
    return new_arr


# Generated test cases:
import pytest


@pytest.mark.parametrize("input_arr,expected", [
    # Normal cases with valid numbers
    ([1, 2, 3], ["Three", "Two", "One"]),
    ([9, 8, 7, 6, 5], ["Nine", "Eight", "Seven", "Six", "Five"]),
    ([4], ["Four"]),
    
    # Mixed valid and invalid numbers
    ([1, 10, 2], ["Two", "One"]),
    ([0, 1, 2, 3], ["Three", "Two", "One"]),
    ([-1, 5, 3], ["Five", "Three"]),
    ([11, 12, 1, 2], ["Two", "One"]),
    
    # Empty array
    ([], []),
    
    # All invalid numbers
    ([10, 11, 12], []),
    ([0, -1, -2], []),
    ([100, 200], []),
    
    # Duplicates
    ([1, 1, 2, 2], ["Two", "Two", "One", "One"]),
    ([5, 5, 5], ["Five", "Five", "Five"]),
    
    # Unsorted input
    ([3, 1, 2], ["Three", "Two", "One"]),
    ([9, 1, 5, 3, 7], ["Nine", "Seven", "Five", "Three", "One"]),
    
    # Edge cases with boundary values
    ([9, 1], ["Nine", "One"]),
    ([1, 9, 5], ["Nine", "Five", "One"]),
    
    # Negative numbers (should be ignored)
    ([-5, -3, 3, 5], ["Five", "Three"]),
    
    # Floating point numbers (should be ignored)
    ([1.5, 2, 3.7, 4], ["Four", "Two"]),
    
    # Large numbers outside range
    ([1000, 2, 3], ["Three", "Two"]),
    
    # All numbers 1-9
    ([1, 2, 3, 4, 5, 6, 7, 8, 9], 
     ["Nine", "Eight", "Seven", "Six", "Five", "Four", "Three", "Two", "One"]),
    
    # Reverse order input
    ([9, 8, 7, 6, 5, 4, 3, 2, 1],
     ["Nine", "Eight", "Seven", "Six", "Five", "Four", "Three", "Two", "One"]),
])
def test_by_length(input_arr, expected):
    assert by_length(input_arr) == expected


def test_by_length_does_not_modify_input():
    original = [3, 1, 2]
    copy = original.copy()
    by_length(original)
    assert original == copy


def test_by_length_with_non_integer_types():
    # String numbers that can't be used as dict keys
    assert by_length(["1", "2", "3"]) == []
    
    # Boolean values (True=1, False=0)
    assert by_length([True, False, 2]) == ["Two", "One"]


def test_by_length_with_mixed_types():
    # Mix of valid integers and strings
    assert by_length([1, 3, 5]) == ["Five", "Three", "One"]