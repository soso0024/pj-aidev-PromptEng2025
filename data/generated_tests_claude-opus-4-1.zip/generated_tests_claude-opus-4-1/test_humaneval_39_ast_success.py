# Test cases for HumanEval/39
# Generated using Claude API



def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """

    import math

    def is_prime(p):
        if p < 2:
            return False
        for k in range(2, min(int(math.sqrt(p)) + 1, p - 1)):
            if p % k == 0:
                return False
        return True
    f = [0, 1]
    while True:
        f.append(f[-1] + f[-2])
        if is_prime(f[-1]):
            n -= 1
        if n == 0:
            return f[-1]


# Generated test cases:
import pytest

def prime_fib(n: int):
    import math

    def is_prime(p):
        if p < 2:
            return False
        for k in range(2, min(int(math.sqrt(p)) + 1, p - 1)):
            if p % k == 0:
                return False
        return True
    f = [0, 1]
    while True:
        f.append(f[-1] + f[-2])
        if is_prime(f[-1]):
            n -= 1
        if n == 0:
            return f[-1]


@pytest.mark.parametrize("n,expected", [
    (1, 2),      # First prime Fibonacci number
    (2, 3),      # Second prime Fibonacci number
    (3, 5),      # Third prime Fibonacci number
    (4, 13),     # Fourth prime Fibonacci number
    (5, 89),     # Fifth prime Fibonacci number
    (6, 233),    # Sixth prime Fibonacci number
    (7, 1597),   # Seventh prime Fibonacci number
    (8, 28657),  # Eighth prime Fibonacci number
])
def test_prime_fib_basic(n, expected):
    assert prime_fib(n) == expected


def test_prime_fib_first_few():
    # Test the first few prime Fibonacci numbers
    assert prime_fib(1) == 2
    assert prime_fib(2) == 3
    assert prime_fib(3) == 5
    assert prime_fib(4) == 13


def test_prime_fib_sequence():
    # Test that the sequence is increasing
    results = [prime_fib(i) for i in range(1, 6)]
    assert results == sorted(results)
    assert len(results) == len(set(results))  # All unique


def test_prime_fib_larger_values():
    # Test with slightly larger n values
    result = prime_fib(6)
    assert result == 233
    assert result > 0


def test_prime_fib_consistency():
    # Test that calling the function multiple times gives same result
    n = 5
    result1 = prime_fib(n)
    result2 = prime_fib(n)
    assert result1 == result2


def test_prime_fib_is_actually_prime():
    # Verify that returned values are actually prime
    def is_prime_check(p):
        if p < 2:
            return False
        for i in range(2, int(p**0.5) + 1):
            if p % i == 0:
                return False
        return True
    
    for n in range(1, 6):
        result = prime_fib(n)
        assert is_prime_check(result), f"prime_fib({n}) = {result} is not prime"


def test_prime_fib_is_fibonacci():
    # Verify that returned values are actually Fibonacci numbers
    def is_fibonacci(num):
        a, b = 0, 1
        while b < num:
            a, b = b, a + b
        return b == num or num == 0
    
    for n in range(1, 6):
        result = prime_fib(n)
        assert is_fibonacci(result), f"prime_fib({n}) = {result} is not a Fibonacci number"
