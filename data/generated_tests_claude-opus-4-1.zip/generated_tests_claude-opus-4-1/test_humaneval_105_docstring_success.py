# Test cases for HumanEval/105
# Generated using Claude API


def by_length(arr):
    """
    Given an array of integers, sort the integers that are between 1 and 9 inclusive,
    reverse the resulting array, and then replace each digit by its corresponding name from
    "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine".

    For example:
      arr = [2, 1, 1, 4, 5, 8, 2, 3]   
            -> sort arr -> [1, 1, 2, 2, 3, 4, 5, 8] 
            -> reverse arr -> [8, 5, 4, 3, 2, 2, 1, 1]
      return ["Eight", "Five", "Four", "Three", "Two", "Two", "One", "One"]
    
      If the array is empty, return an empty array:
      arr = []
      return []
    
      If the array has any strange number ignore it:
      arr = [1, -1 , 55] 
            -> sort arr -> [-1, 1, 55]
            -> reverse arr -> [55, 1, -1]
      return = ['One']
    """

    dic = {
        1: "One",
        2: "Two",
        3: "Three",
        4: "Four",
        5: "Five",
        6: "Six",
        7: "Seven",
        8: "Eight",
        9: "Nine",
    }
    sorted_arr = sorted(arr, reverse=True)
    new_arr = []
    for var in sorted_arr:
        try:
            new_arr.append(dic[var])
        except:
            pass
    return new_arr


# Generated test cases:
import pytest

def by_length(arr):
    dic = {
        1: "One",
        2: "Two",
        3: "Three",
        4: "Four",
        5: "Five",
        6: "Six",
        7: "Seven",
        8: "Eight",
        9: "Nine",
    }
    sorted_arr = sorted(arr, reverse=True)
    new_arr = []
    for var in sorted_arr:
        try:
            new_arr.append(dic[var])
        except:
            pass
    return new_arr


@pytest.mark.parametrize("input_arr,expected", [
    # Basic example from docstring
    ([2, 1, 1, 4, 5, 8, 2, 3], ["Eight", "Five", "Four", "Three", "Two", "Two", "One", "One"]),
    
    # Empty array
    ([], []),
    
    # Array with strange numbers
    ([1, -1, 55], ["One"]),
    
    # Single valid element
    ([5], ["Five"]),
    
    # All valid numbers 1-9
    ([1, 2, 3, 4, 5, 6, 7, 8, 9], ["Nine", "Eight", "Seven", "Six", "Five", "Four", "Three", "Two", "One"]),
    
    # Only invalid numbers
    ([0, 10, -5, 100], []),
    
    # Mix of valid and invalid
    ([0, 1, 10, 2, -3, 9], ["Nine", "Two", "One"]),
    
    # Duplicates of same number
    ([3, 3, 3, 3], ["Three", "Three", "Three", "Three"]),
    
    # Numbers at boundaries
    ([0, 1, 9, 10], ["Nine", "One"]),
    
    # Negative numbers only
    ([-1, -2, -3], []),
    
    # Large numbers only
    ([100, 200, 300], []),
    
    # Float-like integers
    ([1.0, 2.0, 3.0], ["Three", "Two", "One"]),
    
    # Single invalid element
    ([10], []),
    
    # Mix with zero
    ([0, 5, 0, 3], ["Five", "Three"]),
])
def test_by_length(input_arr, expected):
    assert by_length(input_arr) == expected


def test_by_length_preserves_input():
    original = [2, 1, 1, 4, 5, 8, 2, 3]
    original_copy = original.copy()
    by_length(original)
    assert original == original_copy


def test_by_length_type_consistency():
    result = by_length([1, 2, 3])
    assert isinstance(result, list)
    assert all(isinstance(item, str) for item in result)
