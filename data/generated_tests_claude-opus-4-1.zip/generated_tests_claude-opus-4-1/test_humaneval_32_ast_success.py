# Test cases for HumanEval/32
# Generated using Claude API

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


def find_zero(xs: list):
    """ xs are coefficients of a polynomial.
    find_zero find x such that poly(x) = 0.
    find_zero returns only only zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.
    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0
    """

    begin, end = -1., 1.
    while poly(xs, begin) * poly(xs, end) > 0:
        begin *= 2.0
        end *= 2.0
    while end - begin > 1e-10:
        center = (begin + end) / 2.0
        if poly(xs, center) * poly(xs, begin) > 0:
            begin = center
        else:
            end = center
    return begin


# Generated test cases:
import pytest
import math

def poly(xs, x):
    """Evaluate polynomial with coefficients xs at point x."""
    return sum(coeff * (x ** i) for i, coeff in enumerate(xs))

class TestFindZero:
    
    def test_linear_polynomial(self):
        # f(x) = 2x + 1, zero at x = -0.5
        xs = [1, 2]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-8
        assert abs(result - (-0.5)) < 1e-8
    
    def test_quadratic_polynomial(self):
        # f(x) = x^2 - 1, zeros at x = ±1
        xs = [-1, 0, 1]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-8
        # Should find one of the zeros
        assert abs(result - 1) < 1e-8 or abs(result - (-1)) < 1e-8
    
    def test_cubic_polynomial(self):
        # f(x) = x^3 - 2x + 1
        xs = [1, -2, 0, 1]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-8
    
    def test_simple_linear(self):
        # f(x) = x, zero at x = 0
        xs = [0, 1]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-8
        assert abs(result) < 1e-8
    
    def test_shifted_linear(self):
        # f(x) = x - 3, zero at x = 3
        xs = [-3, 1]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-8
        assert abs(result - 3) < 1e-8
    
    def test_higher_degree_polynomial(self):
        # f(x) = x^4 - 5x^2 + 4
        xs = [4, 0, -5, 0, 1]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-8
    
    def test_polynomial_with_zero_at_origin(self):
        # f(x) = x^2 + x = x(x+1), zeros at 0 and -1
        xs = [0, 1, 1]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-8
    
    def test_negative_leading_coefficient(self):
        # f(x) = -x^2 + 4, zeros at ±2
        xs = [4, 0, -1]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-8
    
    def test_large_coefficients(self):
        # f(x) = 100x - 200, zero at x = 2
        xs = [-200, 100]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-8
        assert abs(result - 2) < 1e-8
    
    def test_small_coefficients(self):
        # f(x) = 0.01x - 0.02, zero at x = 2
        xs = [-0.02, 0.01]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-8
        assert abs(result - 2) < 1e-8
    
    def test_polynomial_with_multiple_zeros(self):
        # f(x) = (x-1)(x+1)(x-2) = x^3 - 2x^2 - x + 2
        xs = [2, -1, -2, 1]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-8
        # Should find one of the zeros: -1, 1, or 2
        assert any(abs(result - z) < 1e-8 for z in [-1, 1, 2])