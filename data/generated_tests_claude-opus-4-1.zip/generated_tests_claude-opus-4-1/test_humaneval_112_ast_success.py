# Test cases for HumanEval/112
# Generated using Claude API


def reverse_delete(s,c):
    """Task
    We are given two strings s and c, you have to deleted all the characters in s that are equal to any character in c
    then check if the result string is palindrome.
    A string is called palindrome if it reads the same backward as forward.
    You should return a tuple containing the result string and True/False for the check.
    Example
    For s = "abcde", c = "ae", the result should be ('bcd',False)
    For s = "abcdef", c = "b"  the result should be ('acdef',False)
    For s = "abcdedcba", c = "ab", the result should be ('cdedc',True)
    """

    s = ''.join([char for char in s if char not in c])
    return (s,s[::-1] == s)


# Generated test cases:
import pytest

def reverse_delete(s,c):
    s = ''.join([char for char in s if char not in c])
    return (s,s[::-1] == s)

@pytest.mark.parametrize("s,c,expected", [
    # Basic test cases
    ("abcde", "ae", ("bcd", False)),
    ("abcdef", "b", ("acdef", False)),
    ("abcdedcba", "ab", ("cdedc", True)),
    
    # Palindrome cases
    ("racecar", "ae", ("rccr", True)),
    ("madam", "a", ("mdm", True)),
    ("hello", "l", ("heo", False)),
    
    # Empty string cases
    ("", "abc", ("", True)),
    ("", "", ("", True)),
    
    # No characters to delete
    ("hello", "xyz", ("hello", False)),
    ("aba", "xyz", ("aba", True)),
    
    # Delete all characters
    ("abc", "abc", ("", True)),
    ("hello", "helo", ("", True)),
    
    # Single character strings
    ("a", "a", ("", True)),
    ("a", "b", ("a", True)),
    ("b", "a", ("b", True)),
    
    # Case sensitivity
    ("Hello", "h", ("Hello", False)),
    ("Hello", "H", ("ello", False)),
    
    # Special characters
    ("a!b!c", "!", ("abc", False)),
    ("a@b@a", "@", ("aba", True)),
    ("123321", "2", ("1331", True)),
    
    # Repeated characters
    ("aaabbbccc", "b", ("aaaccc", False)),
    ("aabbaa", "b", ("aaaa", True)),
    
    # Mixed alphanumeric
    ("a1b2c3", "123", ("abc", False)),
    ("1a2b2a1", "12", ("aba", True)),
    
    # Whitespace
    ("a b c", " ", ("abc", False)),
    ("a b a", " ", ("aba", True)),
    
    # Long palindrome after deletion
    ("xabcbax", "x", ("abcba", True)),
    
    # Multiple characters to delete
    ("programming", "aeiou", ("prgrmmng", False)),
    ("aeiouoiea", "bcdfg", ("aeiouoiea", True)),
    
    # Edge case with all same characters
    ("aaaa", "b", ("aaaa", True)),
    ("aaaa", "a", ("", True)),
])
def test_reverse_delete(s, c, expected):
    assert reverse_delete(s, c) == expected

def test_reverse_delete_types():
    # Test with different input types
    result = reverse_delete("test", "t")
    assert isinstance(result, tuple)
    assert isinstance(result[0], str)
    assert isinstance(result[1], bool)
