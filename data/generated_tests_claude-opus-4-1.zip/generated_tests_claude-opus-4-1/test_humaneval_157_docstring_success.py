# Test cases for HumanEval/157
# Generated using Claude API


def right_angle_triangle(a, b, c):
    '''
    Given the lengths of the three sides of a triangle. Return True if the three
    sides form a right-angled triangle, False otherwise.
    A right-angled triangle is a triangle in which one angle is right angle or 
    90 degree.
    Example:
    right_angle_triangle(3, 4, 5) == True
    right_angle_triangle(1, 2, 3) == False
    '''

    return a*a == b*b + c*c or b*b == a*a + c*c or c*c == a*a + b*b


# Generated test cases:
import pytest

def right_angle_triangle(a, b, c):
    return a*a == b*b + c*c or b*b == a*a + c*c or c*c == a*a + b*b

@pytest.mark.parametrize("a,b,c,expected", [
    # Classic right triangles
    (3, 4, 5, True),
    (5, 12, 13, True),
    (8, 15, 17, True),
    (7, 24, 25, True),
    (20, 21, 29, True),
    (9, 40, 41, True),
    (11, 60, 61, True),
    (13, 84, 85, True),
    
    # Different order of sides
    (5, 3, 4, True),
    (4, 5, 3, True),
    (13, 5, 12, True),
    (12, 13, 5, True),
    
    # Not right triangles
    (1, 2, 3, False),
    (2, 3, 4, False),
    (1, 1, 1, False),
    (5, 5, 5, False),
    (10, 10, 10, False),
    
    # Edge cases with small numbers
    (1, 0, 1, True),
    (0, 1, 1, True),
    (1, 1, 0, True),
    
    # Floating point right triangles
    (0.3, 0.4, 0.5, True),
    (1.5, 2, 2.5, True),
    (6, 8, 10, True),
    (0.6, 0.8, 1.0, True),
    
    # Floating point non-right triangles
    (1.1, 2.2, 3.3, False),
    (0.5, 0.5, 0.5, False),
    
    # Large numbers
    (300, 400, 500, True),
    (3000, 4000, 5000, True),
    
    # Special case: degenerate triangles
    (0, 0, 0, True),
    
    # Almost right triangles (testing precision)
    (3, 4, 5.001, False),
    (2.999, 4, 5, False),
    (3, 3.999, 5, False),
])
def test_right_angle_triangle(a, b, c, expected):
    assert right_angle_triangle(a, b, c) == expected

def test_right_angle_triangle_negative_sides():
    # Negative sides can still form right triangles mathematically
    assert right_angle_triangle(-3, -4, -5) == True
    assert right_angle_triangle(-3, 4, 5) == True
    assert right_angle_triangle(3, -4, 5) == True
    assert right_angle_triangle(3, 4, -5) == True

def test_right_angle_triangle_mixed_signs():
    assert right_angle_triangle(-5, -12, 13) == True
    assert right_angle_triangle(5, -12, -13) == True
