# Test cases for HumanEval/59
# Generated using Claude API



def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """

    def is_prime(k):
        if k < 2:
            return False
        for i in range(2, k - 1):
            if k % i == 0:
                return False
        return True
    largest = 1
    for j in range(2, n + 1):
        if n % j == 0 and is_prime(j):
            largest = max(largest, j)
    return largest


# Generated test cases:
import pytest

def largest_prime_factor(n: int):
    def is_prime(k):
        if k < 2:
            return False
        for i in range(2, k - 1):
            if k % i == 0:
                return False
        return True
    largest = 1
    for j in range(2, n + 1):
        if n % j == 0 and is_prime(j):
            largest = max(largest, j)
    return largest


@pytest.mark.parametrize("n,expected", [
    (1, 1),
    (2, 2),
    (3, 3),
    (4, 2),
    (5, 5),
    (6, 3),
    (7, 7),
    (8, 2),
    (9, 3),
    (10, 5),
    (11, 11),
    (12, 3),
    (13, 13),
    (14, 7),
    (15, 5),
    (16, 2),
    (17, 17),
    (18, 3),
    (19, 19),
    (20, 5),
    (21, 7),
    (22, 11),
    (23, 23),
    (24, 3),
    (25, 5),
    (26, 13),
    (27, 3),
    (28, 7),
    (29, 29),
    (30, 5),
    (35, 7),
    (49, 7),
    (50, 5),
    (60, 5),
    (77, 11),
    (100, 5),
    (121, 11),
    (143, 13),
    (169, 13),
    (210, 7),
    (330, 11),
    (462, 11),
    (1001, 13),
])
def test_largest_prime_factor(n, expected):
    assert largest_prime_factor(n) == expected


def test_prime_numbers():
    assert largest_prime_factor(2) == 2
    assert largest_prime_factor(3) == 3
    assert largest_prime_factor(5) == 5
    assert largest_prime_factor(7) == 7
    assert largest_prime_factor(11) == 11
    assert largest_prime_factor(13) == 13
    assert largest_prime_factor(17) == 17
    assert largest_prime_factor(19) == 19
    assert largest_prime_factor(23) == 23
    assert largest_prime_factor(29) == 29
    assert largest_prime_factor(31) == 31


def test_powers_of_two():
    assert largest_prime_factor(2) == 2
    assert largest_prime_factor(4) == 2
    assert largest_prime_factor(8) == 2
    assert largest_prime_factor(16) == 2
    assert largest_prime_factor(32) == 2
    assert largest_prime_factor(64) == 2


def test_powers_of_prime():
    assert largest_prime_factor(9) == 3
    assert largest_prime_factor(27) == 3
    assert largest_prime_factor(81) == 3
    assert largest_prime_factor(25) == 5
    assert largest_prime_factor(125) == 5
    assert largest_prime_factor(49) == 7
    assert largest_prime_factor(343) == 7


def test_composite_numbers():
    assert largest_prime_factor(6) == 3
    assert largest_prime_factor(10) == 5
    assert largest_prime_factor(12) == 3
    assert largest_prime_factor(14) == 7
    assert largest_prime_factor(15) == 5
    assert largest_prime_factor(18) == 3
    assert largest_prime_factor(20) == 5
    assert largest_prime_factor(21) == 7
    assert largest_prime_factor(22) == 11


def test_edge_case_one():
    assert largest_prime_factor(1) == 1
