# Test cases for HumanEval/60
# Generated using Claude API



def sum_to_n(n: int):
    """sum_to_n is a function that sums numbers from 1 to n.
    >>> sum_to_n(30)
    465
    >>> sum_to_n(100)
    5050
    >>> sum_to_n(5)
    15
    >>> sum_to_n(10)
    55
    >>> sum_to_n(1)
    1
    """

    return sum(range(n + 1))


# Generated test cases:
import pytest

def sum_to_n(n: int):
    return sum(range(n + 1))

@pytest.mark.parametrize("n,expected", [
    (30, 465),
    (100, 5050),
    (5, 15),
    (10, 55),
    (1, 1),
    (0, 0),
    (2, 3),
    (3, 6),
    (4, 10),
    (50, 1275),
    (1000, 500500),
])
def test_sum_to_n_valid_inputs(n, expected):
    assert sum_to_n(n) == expected

@pytest.mark.parametrize("n", [-1, -5, -10, -100])
def test_sum_to_n_negative_inputs(n):
    assert sum_to_n(n) == 0

def test_sum_to_n_large_number():
    n = 10000
    expected = n * (n + 1) // 2
    assert sum_to_n(n) == expected

def test_sum_to_n_formula_verification():
    for n in range(1, 101):
        assert sum_to_n(n) == n * (n + 1) // 2

@pytest.mark.parametrize("invalid_input", [
    None,
    "string",
    3.14,
    [1, 2, 3],
    {"key": "value"},
])
def test_sum_to_n_invalid_types(invalid_input):
    with pytest.raises(TypeError):
        sum_to_n(invalid_input)
