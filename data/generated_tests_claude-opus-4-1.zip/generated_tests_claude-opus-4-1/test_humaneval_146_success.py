# Test cases for HumanEval/146
# Generated using Claude API


def specialFilter(nums):
    """Write a function that takes an array of numbers as input and returns 
    the number of elements in the array that are greater than 10 and both 
    first and last digits of a number are odd (1, 3, 5, 7, 9).
    For example:
    specialFilter([15, -73, 14, -15]) => 1 
    specialFilter([33, -2, -3, 45, 21, 109]) => 2
    """

    
    count = 0
    for num in nums:
        if num > 10:
            odd_digits = (1, 3, 5, 7, 9)
            number_as_string = str(num)
            if int(number_as_string[0]) in odd_digits and int(number_as_string[-1]) in odd_digits:
                count += 1
        
    return count 


# Generated test cases:
import pytest


@pytest.mark.parametrize("nums,expected", [
    # Empty list
    ([], 0),
    
    # Single element cases
    ([5], 0),  # Less than 10
    ([10], 0),  # Equal to 10
    ([11], 1),  # Both digits odd
    ([12], 0),  # First odd, last even
    ([21], 0),  # First even, last odd
    ([22], 0),  # Both even
    
    # Numbers with odd first and last digits
    ([13, 15, 17, 19], 4),
    ([31, 33, 35, 37, 39], 5),
    ([51, 53, 55, 57, 59], 5),
    ([71, 73, 75, 77, 79], 5),
    ([91, 93, 95, 97, 99], 5),
    
    # Numbers with even first or last digits
    ([20, 22, 24, 26, 28], 0),
    ([40, 42, 44, 46, 48], 0),
    ([60, 62, 64, 66, 68], 0),
    ([80, 82, 84, 86, 88], 0),
    
    # Mixed cases
    ([11, 12, 13, 14, 15], 3),
    ([10, 11, 20, 31, 40, 51], 3),
    
    # Three digit numbers
    ([111, 113, 115, 117, 119], 5),
    ([121, 123, 125, 127, 129], 5),  # All have odd first and last digits
    ([311, 313, 315, 317, 319], 5),
    ([511, 513, 515, 517, 519], 5),
    ([711, 713, 715, 717, 719], 5),
    ([911, 913, 915, 917, 919], 5),
    
    # Large numbers
    ([1111, 1113, 1115, 1117, 1119], 5),
    ([9999, 9997, 9995, 9993, 9991], 5),
    
    # Numbers ending with even digits
    ([110, 112, 114, 116, 118], 0),
    ([310, 312, 314, 316, 318], 0),
    
    # Numbers starting with even digits
    ([211, 213, 215, 217, 219], 0),
    ([411, 413, 415, 417, 419], 0),
    
    # Mixed valid and invalid
    ([5, 10, 11, 12, 13, 20, 31, 40, 51, 100, 111], 5),  # 11, 13, 31, 51, 111
    
    # All numbers <= 10
    ([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 0),
    
    # Negative numbers (should not count)
    ([-11, -13, -15, -17, -19], 0),
    
    # Mix of positive and negative
    ([11, -11, 13, -13, 15], 3),
    
    # Large list with various cases
    ([11, 22, 33, 44, 55, 66, 77, 88, 99, 100, 111, 222, 333], 7),  # 11, 33, 55, 77, 99, 111, 333
])
def test_specialFilter(nums, expected):
    assert specialFilter(nums) == expected


def test_specialFilter_with_single_digit_numbers():
    assert specialFilter([1, 3, 5, 7, 9]) == 0


def test_specialFilter_with_exactly_10():
    assert specialFilter([10, 10, 10]) == 0


def test_specialFilter_large_odd_numbers():
    assert specialFilter([11111, 33333, 55555, 77777, 99999]) == 5


def test_specialFilter_consecutive_numbers():
    assert specialFilter(list(range(10, 20))) == 5  # 11, 13, 15, 17, 19


def test_specialFilter_all_valid():
    assert specialFilter([11, 13, 15, 17, 19, 31, 33, 35, 37, 39]) == 10