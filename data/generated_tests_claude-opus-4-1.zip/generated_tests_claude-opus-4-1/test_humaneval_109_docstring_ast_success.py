# Test cases for HumanEval/109
# Generated using Claude API


def move_one_ball(arr):
    """We have an array 'arr' of N integers arr[1], arr[2], ..., arr[N].The
    numbers in the array will be randomly ordered. Your task is to determine if
    it is possible to get an array sorted in non-decreasing order by performing 
    the following operation on the given array:
        You are allowed to perform right shift operation any number of times.
    
    One right shift operation means shifting all elements of the array by one
    position in the right direction. The last element of the array will be moved to
    the starting position in the array i.e. 0th index. 

    If it is possible to obtain the sorted array by performing the above operation
    then return True else return False.
    If the given array is empty then return True.

    Note: The given list is guaranteed to have unique elements.

    For Example:
    
    move_one_ball([3, 4, 5, 1, 2])==>True
    Explanation: By performin 2 right shift operations, non-decreasing order can
                 be achieved for the given array.
    move_one_ball([3, 5, 4, 1, 2])==>False
    Explanation:It is not possible to get non-decreasing order for the given
                array by performing any number of right shift operations.
                
    """

    if len(arr)==0:
      return True
    sorted_array=sorted(arr)
    my_arr=[]
    
    min_value=min(arr)
    min_index=arr.index(min_value)
    my_arr=arr[min_index:]+arr[0:min_index]
    for i in range(len(arr)):
      if my_arr[i]!=sorted_array[i]:
        return False
    return True


# Generated test cases:
import pytest

@pytest.mark.parametrize("arr,expected", [
    # Empty array
    ([], True),
    
    # Single element
    ([1], True),
    
    # Two elements - already sorted
    ([1, 2], True),
    
    # Two elements - needs rotation
    ([2, 1], True),
    
    # Already sorted array
    ([1, 2, 3, 4, 5], True),
    
    # Example from docstring - can be sorted with rotation
    ([3, 4, 5, 1, 2], True),
    
    # Example from docstring - cannot be sorted
    ([3, 5, 4, 1, 2], False),
    
    # Reverse sorted that can be rotated to sorted
    ([2, 3, 4, 5, 1], True),
    
    # Array that needs multiple rotations
    ([4, 5, 6, 1, 2, 3], True),
    
    # Array with negative numbers - sortable
    ([-1, 0, 1, 2, -3, -2], True),
    
    # Array with negative numbers - not sortable
    ([-1, 2, 0, -3], False),
    
    # All same except one at wrong position
    ([2, 1, 3, 4, 5], False),
    
    # Descending order
    ([5, 4, 3, 2, 1], False),
    
    # Random unsortable array
    ([4, 2, 5, 1, 3], False),
    
    # Array with large gap - actually sortable
    ([10, 20, 30, 1, 2], True),
    
    # Array that is sortable with one rotation
    ([5, 1, 2, 3, 4], True),
    
    # Array with all negative numbers - sortable
    ([-2, -1, -5, -4, -3], True),
    
    # Array with all negative numbers - not sortable  
    ([-2, -5, -1, -4, -3], False),
    
    # Three elements - sortable cases
    ([2, 3, 1], True),
    ([3, 1, 2], True),
    
    # Three elements - not sortable
    ([2, 1, 3], False),
    ([3, 2, 1], False),
    
    # Large sorted array with last element first
    ([100, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10], True),
    
    # Array where min is in middle and still sortable
    ([7, 8, 9, 1, 2, 3, 4, 5, 6], True),
    
    # Array with mixed positive and negative - sortable
    ([0, 1, 2, 3, -2, -1], True),
    
    # Array with zero
    ([0, 1, 2], True),
    ([1, 2, 0], True),
    ([2, 0, 1], True),
])
def test_move_one_ball(arr, expected):
    assert move_one_ball(arr) == expected

def test_move_one_ball_preserves_input():
    original = [3, 4, 5, 1, 2]
    arr_copy = original.copy()
    move_one_ball(arr_copy)
    assert arr_copy == original