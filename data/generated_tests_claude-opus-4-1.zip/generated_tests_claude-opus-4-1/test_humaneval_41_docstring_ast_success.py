# Test cases for HumanEval/41
# Generated using Claude API



def car_race_collision(n: int):
    """
    Imagine a road that's a perfectly straight infinitely long line.
    n cars are driving left to right;  simultaneously, a different set of n cars
    are driving right to left.   The two sets of cars start out being very far from
    each other.  All cars move in the same speed.  Two cars are said to collide
    when a car that's moving left to right hits a car that's moving right to left.
    However, the cars are infinitely sturdy and strong; as a result, they continue moving
    in their trajectory as if they did not collide.

    This function outputs the number of such collisions.
    """

    return n**2


# Generated test cases:
import pytest


def car_race_collision(n: int):
    """
    Imagine a road that's a perfectly straight infinitely long line.
    n cars are driving left to right;  simultaneously, a different set of n cars
    are driving right to left.   The two sets of cars start out being very far from
    each other.  All cars move in the same speed.  Two cars are said to collide
    when a car that's moving left to right hits a car that's moving right to left.
    However, the cars are infinitely sturdy and strong; as a result, they continue moving
    in their trajectory as if they did not collide.

    This function outputs the number of such collisions.
    """

    return n**2


@pytest.mark.parametrize("n,expected", [
    (0, 0),
    (1, 1),
    (2, 4),
    (3, 9),
    (4, 16),
    (5, 25),
    (10, 100),
    (100, 10000),
    (1000, 1000000),
])
def test_car_race_collision_normal_cases(n, expected):
    assert car_race_collision(n) == expected


@pytest.mark.parametrize("n", [
    -1,
    -5,
    -10,
    -100,
])
def test_car_race_collision_negative_numbers(n):
    assert car_race_collision(n) == n**2


def test_car_race_collision_large_numbers():
    assert car_race_collision(10000) == 100000000
    assert car_race_collision(99999) == 9999800001


def test_car_race_collision_with_float():
    assert car_race_collision(5.5) == 30.25


def test_car_race_collision_with_string_number():
    with pytest.raises(TypeError):
        car_race_collision("5")


def test_car_race_collision_no_args():
    with pytest.raises(TypeError):
        car_race_collision()


def test_car_race_collision_multiple_args():
    with pytest.raises(TypeError):
        car_race_collision(5, 10)