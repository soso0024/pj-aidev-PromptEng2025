# Test cases for HumanEval/45
# Generated using Claude API



def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """

    return a * h / 2.0


# Generated test cases:
import pytest
import math

def triangle_area(a, h):
    return a * h / 2.0

class TestTriangleArea:
    
    @pytest.mark.parametrize("a,h,expected", [
        (5, 3, 7.5),
        (10, 5, 25.0),
        (2, 2, 2.0),
        (1, 1, 0.5),
        (100, 50, 2500.0),
    ])
    def test_normal_cases(self, a, h, expected):
        assert triangle_area(a, h) == expected
    
    @pytest.mark.parametrize("a,h,expected", [
        (0, 5, 0.0),
        (5, 0, 0.0),
        (0, 0, 0.0),
    ])
    def test_zero_values(self, a, h, expected):
        assert triangle_area(a, h) == expected
    
    @pytest.mark.parametrize("a,h,expected", [
        (0.5, 0.5, 0.125),
        (1.5, 2.5, 1.875),
        (3.14, 2.71, 4.2547),
        (0.1, 0.1, 0.005),
    ])
    def test_decimal_values(self, a, h, expected):
        assert pytest.approx(triangle_area(a, h), rel=1e-4) == expected
    
    @pytest.mark.parametrize("a,h", [
        (1000000, 1000000),
        (999999.99, 888888.88),
    ])
    def test_large_values(self, a, h):
        result = triangle_area(a, h)
        assert result == a * h / 2.0
        assert isinstance(result, float)
    
    @pytest.mark.parametrize("a,h,expected", [
        (-5, 3, -7.5),
        (5, -3, -7.5),
        (-5, -3, 7.5),
    ])
    def test_negative_values(self, a, h, expected):
        assert triangle_area(a, h) == expected
    
    def test_return_type(self):
        assert isinstance(triangle_area(5, 3), float)
        assert isinstance(triangle_area(4, 2), float)
        assert isinstance(triangle_area(0, 0), float)
