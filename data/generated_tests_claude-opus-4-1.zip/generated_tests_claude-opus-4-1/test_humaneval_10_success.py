# Test cases for HumanEval/10
# Generated using Claude API



def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """ Find the shortest palindrome that begins with a supplied string.
    Algorithm idea is simple:
    - Find the longest postfix of supplied string that is a palindrome.
    - Append to the end of the string reverse of a string prefix that comes before the palindromic suffix.
    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    """

    if not string:
        return ''

    beginning_of_suffix = 0

    while not is_palindrome(string[beginning_of_suffix:]):
        beginning_of_suffix += 1

    return string + string[:beginning_of_suffix][::-1]


# Generated test cases:
import pytest


def is_palindrome(string: str) -> bool:
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    if not string:
        return ''

    beginning_of_suffix = 0

    while not is_palindrome(string[beginning_of_suffix:]):
        beginning_of_suffix += 1

    return string + string[:beginning_of_suffix][::-1]


@pytest.mark.parametrize("input_string,expected", [
    ("", ""),
    ("a", "a"),
    ("aa", "aa"),
    ("ab", "aba"),
    ("abc", "abcba"),
    ("abcd", "abcdcba"),
    ("race", "racecar"),
    ("racecar", "racecar"),
    ("abcba", "abcba"),
    ("abccba", "abccba"),
    ("cat", "catac"),
    ("cata", "catac"),
    ("abcdef", "abcdefedcba"),
    ("xyz", "xyzyx"),
    ("12321", "12321"),
    ("123", "12321"),
    ("1234", "1234321"),
    ("aaa", "aaa"),
    ("aaaa", "aaaa"),
    ("aaab", "aaabaaa"),
    ("baaa", "baaab"),
    ("abba", "abba"),
    ("abab", "ababa"),
    ("baba", "babab"),
    ("x", "x"),
    ("xy", "xyx"),
    ("yx", "yxy"),
    ("noon", "noon"),
    ("level", "level"),
    ("hello", "hellolleh"),
    ("world", "worldlrow"),
    ("python", "pythonohtyp"),
    ("test", "testset"),
    ("radar", "radar"),
    ("madam", "madam"),
    ("refer", "refer"),
    ("deed", "deed"),
    ("civic", "civic"),
    ("kayak", "kayak"),
    ("stats", "stats"),
    ("tenet", "tenet"),
    ("rotor", "rotor"),
    ("sagas", "sagas"),
    ("solos", "solos"),
    ("redder", "redder"),
    ("retter", "retter"),
    ("abcdefg", "abcdefgfedcba"),
    ("123456789", "12345678987654321"),
    ("a b c", "a b c b a"),
    ("a  a", "a  a"),
    ("!@#", "!@#@!"),
    (".", "."),
    ("..", ".."),
    ("...", "..."),
    ("-", "-"),
    ("--", "--"),
    ("---", "---"),
    ("_", "_"),
    ("__", "__"),
    ("___", "___"),
    (" ", " "),
    ("  ", "  "),
    ("   ", "   "),
    ("a ", "a a"),
    (" a", " a "),
    ("a b", "a b a"),
    ("b a", "b a b"),
])
def test_make_palindrome(input_string, expected):
    assert make_palindrome(input_string) == expected


def test_make_palindrome_result_is_palindrome():
    test_strings = ["", "a", "ab", "abc", "abcd", "race", "hello", "world", "python", "test", "xyz", "123", "!@#"]
    for s in test_strings:
        result = make_palindrome(s)
        assert result == result[::-1], f"Result '{result}' for input '{s}' is not a palindrome"


def test_make_palindrome_minimal_addition():
    test_cases = [
        ("abc", 2),  # adds "ba"
        ("abcd", 3),  # adds "cba"
        ("race", 3),  # adds "car"
        ("hello", 4),  # adds "lleh"
    ]
    for input_str, expected_additions in test_cases:
        result = make_palindrome(input_str)
        actual_additions = len(result) - len(input_str)
        assert actual_additions == expected_additions, f"Expected {expected_additions} additions for '{input_str}', got {actual_additions}"


def test_make_palindrome_preserves_original():
    test_strings = ["abc", "hello", "world", "test", "python"]
    for s in test_strings:
        result = make_palindrome(s)
        assert result.startswith(s), f"Result '{result}' does not start with original string '{s}'"


def test_make_palindrome_special_characters():
    special_cases = [
        ("!@#$%", "!@#$%$#@!"),
        ("123!@#", "123!@#@!321"),
        ("a-b-c", "a-b-c-b-a"),
        ("a_b_c", "a_b_c_b_a"),
        ("a.b.c", "a.b.c.b.a"),
    ]
    for input_str, expected in special_cases:
        assert make_palindrome(input_str) == expected


def test_make_palindrome_unicode():
    unicode_cases = [
        ("café", "caféfac"),
        ("naïve", "naïvevïan"),
        ("😀", "😀"),
        ("😀😁", "😀😁😀"),
        ("αβγ", "αβγβα"),
    ]
    for input_str, expected in unicode_cases:
        assert make_palindrome(input_str) == expected