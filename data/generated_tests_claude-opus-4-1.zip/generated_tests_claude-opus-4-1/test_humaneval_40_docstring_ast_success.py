# Test cases for HumanEval/40
# Generated using Claude API



def triples_sum_to_zero(l: list):
    """
    triples_sum_to_zero takes a list of integers as an input.
    it returns True if there are three distinct elements in the list that
    sum to zero, and False otherwise.

    >>> triples_sum_to_zero([1, 3, 5, 0])
    False
    >>> triples_sum_to_zero([1, 3, -2, 1])
    True
    >>> triples_sum_to_zero([1, 2, 3, 7])
    False
    >>> triples_sum_to_zero([2, 4, -5, 3, 9, 7])
    True
    >>> triples_sum_to_zero([1])
    False
    """

    for i in range(len(l)):
        for j in range(i + 1, len(l)):
            for k in range(j + 1, len(l)):
                if l[i] + l[j] + l[k] == 0:
                    return True
    return False


# Generated test cases:
import pytest

@pytest.mark.parametrize("input_list,expected", [
    # Test cases from docstring
    ([1, 3, 5, 0], False),
    ([1, 3, -2, 1], True),
    ([1, 2, 3, 7], False),
    ([2, 4, -5, 3, 9, 7], True),
    ([1], False),
    
    # Edge cases
    ([], False),  # Empty list
    ([0], False),  # Single element
    ([0, 0], False),  # Two elements
    ([0, 0, 0], True),  # Three zeros
    ([1, -1], False),  # Two elements that sum to zero
    
    # Basic positive cases
    ([1, -1, 0], True),  # Simple case summing to zero
    ([1, 2, -3], True),  # 1 + 2 + (-3) = 0
    ([5, -2, -3], True),  # 5 + (-2) + (-3) = 0
    ([-1, -2, 3], True),  # -1 + (-2) + 3 = 0
    
    # Basic negative cases
    ([1, 2, 3], False),  # All positive
    ([-1, -2, -3], False),  # All negative
    ([1, 1, 1], False),  # Same positive values
    ([-1, -1, -1], False),  # Same negative values
    
    # Lists with duplicates
    ([1, 1, -2, 0], True),  # 1 + 1 + (-2) = 0
    ([2, 2, -4, 1], True),  # 2 + 2 + (-4) = 0
    ([1, 1, 1, -2], True),  # 1 + 1 + (-2) = 0
    
    # Larger lists
    ([1, 2, 3, 4, -5, -4], True),  # 1 + 4 + (-5) = 0
    ([10, -5, -3, -2, 0], False),  # No valid triple sums to zero
    ([10, -5, -3, -2, 0, 1], False),  # No valid triple sums to zero
    ([5, -2, -3, 10, 20], True),  # 5 + (-2) + (-3) = 0
    
    # Lists with zeros
    ([0, 1, -1], True),  # 0 + 1 + (-1) = 0
    ([0, 0, 1], False),  # No triple sums to zero
    ([0, -1, 1, 2], True),  # 0 + (-1) + 1 = 0
    
    # Large numbers
    ([100, -50, -50], True),  # 100 + (-50) + (-50) = 0
    ([1000, -999, -1], True),  # 1000 + (-999) + (-1) = 0
    ([999, -500, -499], True),  # 999 + (-500) + (-499) = 0
    
    # Mixed positive and negative
    ([1, -2, 3, -4, 5], True),  # 1 + 3 + (-4) = 0
    ([1, -2, 3, -4, 5, -1], True),  # 3 + (-4) + 1 = 0
    ([2, -1, 3, -4, 5, -1], True),  # 2 + (-1) + (-1) = 0
])
def test_triples_sum_to_zero(input_list, expected):
    assert triples_sum_to_zero(input_list) == expected


def test_triples_sum_to_zero_type_preservation():
    # Test that function doesn't modify the original list
    original = [1, 3, -2, 1]
    copy = original.copy()
    result = triples_sum_to_zero(original)
    assert original == copy
    assert result == True