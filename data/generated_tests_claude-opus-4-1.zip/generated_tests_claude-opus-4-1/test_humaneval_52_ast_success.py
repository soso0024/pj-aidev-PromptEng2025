# Test cases for HumanEval/52
# Generated using Claude API



def below_threshold(l: list, t: int):
    """Return True if all numbers in the list l are below threshold t.
    >>> below_threshold([1, 2, 4, 10], 100)
    True
    >>> below_threshold([1, 20, 4, 10], 5)
    False
    """

    for e in l:
        if e >= t:
            return False
    return True


# Generated test cases:
import pytest


def below_threshold(l: list, t: int):
    for e in l:
        if e >= t:
            return False
    return True


@pytest.mark.parametrize("l,t,expected", [
    # Empty list
    ([], 10, True),
    ([], 0, True),
    ([], -5, True),
    
    # Single element lists
    ([5], 10, True),
    ([10], 10, False),
    ([15], 10, False),
    ([0], 1, True),
    ([-5], 0, True),
    ([-5], -5, False),
    
    # Multiple elements all below threshold
    ([1, 2, 3, 4], 5, True),
    ([0, 1, 2], 3, True),
    ([-10, -5, -1], 0, True),
    ([-100, -50, -25, -10], -5, True),
    
    # Multiple elements with one at threshold
    ([1, 2, 3, 4, 5], 5, False),
    ([0, 5, 2], 5, False),
    ([-10, -5, -1], -5, False),
    
    # Multiple elements with one above threshold
    ([1, 2, 6, 4], 5, False),
    ([0, 1, 2, 10], 3, False),
    ([-10, 0, -1], -5, False),
    
    # All elements at or above threshold
    ([5, 6, 7, 8], 5, False),
    ([10, 10, 10], 10, False),
    
    # Mixed positive and negative numbers
    ([-5, -2, 0, 2, 4], 5, True),
    ([-5, -2, 0, 2, 5], 5, False),
    ([-10, -5, 0, 5, 10], 0, False),
    
    # Large numbers
    ([999999, 1000000], 1000001, True),
    ([999999, 1000001], 1000001, False),
    
    # Floating point numbers (if list can contain them)
    ([1.5, 2.5, 3.5], 4, True),
    ([1.5, 2.5, 4.0], 4, False),
    ([1.5, 2.5, 4.5], 4, False),
    
    # Negative threshold
    ([1, 2, 3], -1, False),
    ([-5, -3, -2], -1, True),
    ([-5, -3, -1], -1, False),
    
    # Zero threshold
    ([-1, -2, -3], 0, True),
    ([0, 1, 2], 0, False),
    ([-1, 0, 1], 0, False),
])
def test_below_threshold(l, t, expected):
    assert below_threshold(l, t) == expected


def test_below_threshold_type_validation():
    # Test with non-numeric elements should work if they support comparison
    assert below_threshold(['a', 'b', 'c'], 'd') == True
    assert below_threshold(['a', 'b', 'd'], 'd') == False
