# Test cases for HumanEval/90
# Generated using Claude API


def next_smallest(lst):
    """
    You are given a list of integers.
    Write a function next_smallest() that returns the 2nd smallest element of the list.
    Return None if there is no such element.
    
    next_smallest([1, 2, 3, 4, 5]) == 2
    next_smallest([5, 1, 4, 3, 2]) == 2
    next_smallest([]) == None
    next_smallest([1, 1]) == None
    """

    lst = sorted(set(lst))
    return None if len(lst) < 2 else lst[1]


# Generated test cases:
import pytest

def next_smallest(lst):
    lst = sorted(set(lst))
    return None if len(lst) < 2 else lst[1]


@pytest.mark.parametrize("input_list,expected", [
    # Basic cases from docstring
    ([1, 2, 3, 4, 5], 2),
    ([5, 1, 4, 3, 2], 2),
    ([], None),
    ([1, 1], None),
    
    # Single element
    ([1], None),
    ([0], None),
    ([-5], None),
    
    # Two distinct elements
    ([1, 2], 2),
    ([2, 1], 2),
    ([0, 1], 1),
    ([-1, 0], 0),
    ([-5, -3], -3),
    
    # Multiple duplicates
    ([1, 1, 1, 1], None),
    ([2, 2, 2, 2, 2], None),
    ([1, 1, 2, 2], 2),
    ([3, 1, 1, 2, 2, 3], 2),
    ([5, 5, 5, 1, 1, 1], 5),
    
    # Negative numbers
    ([-1, -2, -3, -4, -5], -4),
    ([-5, -4, -3, -2, -1], -4),
    ([-10, -20, -30], -20),
    
    # Mixed positive and negative
    ([-1, 0, 1], 0),
    ([-5, -3, 0, 2, 4], -3),
    ([10, -10, 0], 0),
    
    # Large numbers
    ([1000000, 999999, 1000001], 1000000),
    ([100, 200, 300, 400], 200),
    
    # Unsorted with duplicates
    ([3, 1, 4, 1, 5, 9, 2, 6], 2),
    ([10, 10, 9, 9, 8, 8, 7], 8),
    ([5, 3, 5, 3, 5, 3], 5),
    
    # Edge cases with zeros
    ([0, 0, 0], None),
    ([0, 1, 0, 1], 1),
    ([0, -1, 1], 0),
    
    # Floating point-like integers
    ([1, 2, 3, 2, 1], 2),
    ([100, 50, 75, 25], 50),
    
    # All same except one
    ([1, 2, 1, 1, 1, 1], 2),
    ([5, 5, 5, 5, 6], 6),
    
    # Three distinct elements
    ([1, 2, 3], 2),
    ([3, 2, 1], 2),
    ([10, 20, 30], 20),
])
def test_next_smallest(input_list, expected):
    assert next_smallest(input_list) == expected


def test_next_smallest_does_not_modify_original():
    original = [5, 1, 4, 3, 2]
    original_copy = original.copy()
    result = next_smallest(original)
    assert original == original_copy
    assert result == 2


def test_next_smallest_with_large_list():
    large_list = list(range(1000, 0, -1))
    assert next_smallest(large_list) == 2


def test_next_smallest_with_repeated_min():
    assert next_smallest([1, 1, 1, 2, 2, 2]) == 2
    assert next_smallest([0, 0, 0, 0, 1]) == 1
