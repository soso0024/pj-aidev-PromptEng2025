# Test cases for HumanEval/118
# Generated using Claude API


def get_closest_vowel(word):
    """You are given a word. Your task is to find the closest vowel that stands between 
    two consonants from the right side of the word (case sensitive).
    
    Vowels in the beginning and ending doesn't count. Return empty string if you didn't
    find any vowel met the above condition. 

    You may assume that the given string contains English letter only.

    Example:
    get_closest_vowel("yogurt") ==> "u"
    get_closest_vowel("FULL") ==> "U"
    get_closest_vowel("quick") ==> ""
    get_closest_vowel("ab") ==> ""
    """

    if len(word) < 3:
        return ""

    vowels = {"a", "e", "i", "o", "u", "A", "E", 'O', 'U', 'I'}
    for i in range(len(word)-2, 0, -1):
        if word[i] in vowels:
            if (word[i+1] not in vowels) and (word[i-1] not in vowels):
                return word[i]
    return ""


# Generated test cases:
import pytest

@pytest.mark.parametrize("word,expected", [
    # Empty string and short strings
    ("", ""),
    ("a", ""),
    ("ab", ""),
    
    # Three character strings
    ("abc", ""),
    ("aei", ""),
    ("bac", "a"),
    ("bad", "a"),
    
    # Basic cases with vowels between consonants
    ("beautiful", "u"),
    ("world", "o"),
    ("hello", "e"),
    
    # Multiple vowels, should return rightmost valid one
    ("yogurt", "u"),
    ("FULL", "U"),
    
    # Case sensitivity
    ("bAd", "A"),
    ("bEd", "E"),
    ("bId", "I"),
    ("bOd", "O"),
    ("bUd", "U"),
    
    # No valid vowels (vowels at edges or adjacent to other vowels)
    ("aaa", ""),
    ("eee", ""),
    ("aeiou", ""),
    ("bcdfg", ""),
    
    # Vowels at beginning or end
    ("abcd", ""),
    ("bcda", ""),
    
    # Complex cases
    ("abcdefghijklmnop", "o"),
    ("aeiouAEIOU", ""),
    ("bcdfghjklmnpqrstvwxyz", ""),
    
    # Words with multiple valid vowels
    ("cabinet", "e"),
    ("computer", "e"),
    
    # Edge cases with consonant-vowel-consonant patterns
    ("bat", "a"),
    ("bet", "e"),
    ("bit", "i"),
    ("bot", "o"),
    ("but", "u"),
    
    # Longer words
    ("programming", "i"),
    ("development", "e"),
    
    # Words where vowels are adjacent
    ("beautiful", "u"),
    ("queue", ""),
    ("aardvark", "a"),
    
    # Mixed case
    ("BeAutiful", "u"),
    ("PROGRAMMING", "I"),
    
    # Special patterns
    ("xyx", ""),
    ("xax", "a"),
    ("xex", "e"),
    ("xix", "i"),
    ("xox", "o"),
    ("xux", "u"),
    
    # Words ending with consonant-vowel-consonant
    ("cab", "a"),
    ("web", "e"),
    ("lib", "i"),
    ("mob", "o"),
    ("hub", "u"),
])
def test_get_closest_vowel(word, expected):
    assert get_closest_vowel(word) == expected


def test_get_closest_vowel_empty():
    assert get_closest_vowel("") == ""


def test_get_closest_vowel_single_char():
    assert get_closest_vowel("a") == ""
    assert get_closest_vowel("b") == ""


def test_get_closest_vowel_two_chars():
    assert get_closest_vowel("ab") == ""
    assert get_closest_vowel("ba") == ""
    assert get_closest_vowel("ae") == ""


def test_get_closest_vowel_all_consonants():
    assert get_closest_vowel("bcdfg") == ""
    assert get_closest_vowel("xyz") == ""


def test_get_closest_vowel_all_vowels():
    assert get_closest_vowel("aeiou") == ""
    assert get_closest_vowel("AEIOU") == ""