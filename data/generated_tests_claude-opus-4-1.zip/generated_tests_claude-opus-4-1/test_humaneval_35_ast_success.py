# Test cases for HumanEval/35
# Generated using Claude API



def max_element(l: list):
    """Return maximum element in the list.
    >>> max_element([1, 2, 3])
    3
    >>> max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    123
    """

    m = l[0]
    for e in l:
        if e > m:
            m = e
    return m


# Generated test cases:
import pytest

def max_element(l: list):
    m = l[0]
    for e in l:
        if e > m:
            m = e
    return m

@pytest.mark.parametrize("input_list,expected", [
    ([1, 2, 3, 4, 5], 5),
    ([5, 4, 3, 2, 1], 5),
    ([3, 7, 2, 9, 1], 9),
    ([1], 1),
    ([-5, -3, -1, -2, -4], -1),
    ([0, 0, 0, 0], 0),
    ([1.5, 2.7, 3.9, 2.1], 3.9),
    ([-1.5, -0.5, -2.3], -0.5),
    ([100, -100, 50, -50, 0], 100),
    ([999999999, 1000000000, 999999998], 1000000000),
    (["a", "b", "c", "z", "m"], "z"),
    (["apple", "banana", "cherry"], "cherry"),
    ([True, False], True),
    ([False, False, False], False),
    ([3, 3, 3, 3, 3], 3),
    ([-100], -100),
    ([0], 0),
    ([float('inf'), 1, 2, 3], float('inf')),
    ([1, 2, 3, float('inf')], float('inf')),
    ([-float('inf'), -1, -2], -1),
])
def test_max_element_normal_cases(input_list, expected):
    assert max_element(input_list) == expected

def test_max_element_with_none_in_list():
    with pytest.raises(TypeError):
        max_element([1, 2, None, 4])

def test_max_element_empty_list():
    with pytest.raises(IndexError):
        max_element([])

def test_max_element_mixed_types_numbers():
    assert max_element([1, 2.5, 3, 4.7]) == 4.7

def test_max_element_large_list():
    large_list = list(range(1000))
    assert max_element(large_list) == 999

def test_max_element_negative_and_positive():
    assert max_element([-10, -5, 0, 5, 10]) == 10

def test_max_element_with_nan():
    import math
    result = max_element([1, 2, math.nan, 3])
    assert math.isnan(result) or result == 3

def test_max_element_tuple_input():
    assert max_element((1, 5, 3, 2)) == 5
