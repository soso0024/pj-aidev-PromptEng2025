# Test cases for HumanEval/55
# Generated using Claude API



def fib(n: int):
    """Return n-th Fibonacci number.
    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """

    if n == 0:
        return 0
    if n == 1:
        return 1
    return fib(n - 1) + fib(n - 2)


# Generated test cases:
import pytest

def fib(n: int):
    if n == 0:
        return 0
    if n == 1:
        return 1
    return fib(n - 1) + fib(n - 2)

@pytest.mark.parametrize("n,expected", [
    (0, 0),
    (1, 1),
    (2, 1),
    (3, 2),
    (4, 3),
    (5, 5),
    (6, 8),
    (7, 13),
    (8, 21),
    (9, 34),
    (10, 55),
    (15, 610),
    (20, 6765),
])
def test_fib_valid_inputs(n, expected):
    assert fib(n) == expected

def test_fib_base_cases():
    assert fib(0) == 0
    assert fib(1) == 1

def test_fib_small_numbers():
    assert fib(2) == 1
    assert fib(3) == 2
    assert fib(4) == 3

def test_fib_sequence_property():
    for i in range(2, 10):
        assert fib(i) == fib(i-1) + fib(i-2)

@pytest.mark.parametrize("invalid_input", [
    -1,
    -5,
    -100,
])
def test_fib_negative_numbers(invalid_input):
    with pytest.raises(RecursionError):
        fib(invalid_input)