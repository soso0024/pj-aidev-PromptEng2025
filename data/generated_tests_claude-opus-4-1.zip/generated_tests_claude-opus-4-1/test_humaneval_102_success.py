# Test cases for HumanEval/102
# Generated using Claude API


def choose_num(x, y):
    """This function takes two positive numbers x and y and returns the
    biggest even integer number that is in the range [x, y] inclusive. If 
    there's no such number, then the function should return -1.

    For example:
    choose_num(12, 15) = 14
    choose_num(13, 12) = -1
    """

    if x > y:
        return -1
    if y % 2 == 0:
        return y
    if x == y:
        return -1
    return y - 1


# Generated test cases:
import pytest

def choose_num(x, y):
    if x > y:
        return -1
    if y % 2 == 0:
        return y
    if x == y:
        return -1
    return y - 1

@pytest.mark.parametrize("x,y,expected", [
    # Normal cases - y is even
    (1, 4, 4),
    (2, 10, 10),
    (5, 8, 8),
    (0, 2, 2),
    (-4, -2, -2),
    (-10, 0, 0),
    
    # Normal cases - y is odd, x < y
    (1, 5, 4),
    (2, 7, 6),
    (3, 9, 8),
    (0, 3, 2),
    (-5, -1, -2),
    (-7, -3, -4),
    
    # Edge cases - x > y
    (5, 3, -1),
    (10, 5, -1),
    (1, 0, -1),
    (-1, -5, -1),
    (100, 50, -1),
    
    # Edge cases - x == y and y is odd
    (5, 5, -1),
    (3, 3, -1),
    (1, 1, -1),
    (-3, -3, -1),
    
    # Edge cases - x == y and y is even
    (4, 4, 4),
    (2, 2, 2),
    (0, 0, 0),
    (-2, -2, -2),
    (-4, -4, -4),
    
    # Boundary cases
    (1, 2, 2),
    (0, 1, 0),
    (-1, 0, 0),
    (-2, -1, -2),
    
    # Large numbers
    (1, 1000000, 1000000),
    (1, 999999, 999998),
    (1000000, 999999, -1),
])
def test_choose_num(x, y, expected):
    assert choose_num(x, y) == expected

def test_choose_num_types():
    assert isinstance(choose_num(1, 2), int)
    assert isinstance(choose_num(5, 3), int)
    assert isinstance(choose_num(1, 5), int)
