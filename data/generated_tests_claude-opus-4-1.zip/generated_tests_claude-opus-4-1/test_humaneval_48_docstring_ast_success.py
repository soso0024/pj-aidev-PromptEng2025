# Test cases for HumanEval/48
# Generated using Claude API



def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """

    for i in range(len(text)):
        if text[i] != text[len(text) - 1 - i]:
            return False
    return True


# Generated test cases:
import pytest


def is_palindrome(text: str):
    for i in range(len(text)):
        if text[i] != text[len(text) - 1 - i]:
            return False
    return True


@pytest.mark.parametrize("text,expected", [
    # Empty string
    ("", True),
    
    # Single character
    ("a", True),
    ("z", True),
    ("1", True),
    
    # Two characters
    ("aa", True),
    ("ab", False),
    ("11", True),
    
    # Odd length palindromes
    ("aba", True),
    ("racecar", True),
    ("level", True),
    ("noon", True),
    ("civic", True),
    ("aaaaa", True),
    
    # Even length palindromes
    ("abba", True),
    ("1221", True),
    ("abccba", True),
    
    # Non-palindromes
    ("zbcd", False),
    ("abc", False),
    ("hello", False),
    ("python", False),
    ("test", False),
    
    # Special characters and spaces
    ("a b a", True),
    ("a b c", False),
    ("!@!", True),
    ("!@#", False),
    
    # Numbers as strings
    ("121", True),
    ("12321", True),
    ("123", False),
    ("1234321", True),
    
    # Mixed case (case sensitive)
    ("Aa", False),
    ("ABA", True),
    ("AbA", True),
    
    # Long palindromes
    ("a" * 100, True),
    ("a" * 50 + "b" + "a" * 50, True),
    ("abcdefghijihgfedcba", True),
    
    # Almost palindromes
    ("abcba", True),
    ("abcdba", False),
    ("aabaa", True),
    ("aabba", False),
])
def test_is_palindrome(text, expected):
    assert is_palindrome(text) == expected


def test_is_palindrome_docstring_examples():
    assert is_palindrome('') == True
    assert is_palindrome('aba') == True
    assert is_palindrome('aaaaa') == True
    assert is_palindrome('zbcd') == False
