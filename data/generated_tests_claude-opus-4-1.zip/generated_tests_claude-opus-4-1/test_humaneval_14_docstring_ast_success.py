# Test cases for HumanEval/14
# Generated using Claude API

from typing import List


def all_prefixes(string: str) -> List[str]:
    """ Return list of all prefixes from shortest to longest of the input string
    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """

    result = []

    for i in range(len(string)):
        result.append(string[:i+1])
    return result


# Generated test cases:
import pytest
from typing import List


def all_prefixes(string: str) -> List[str]:
    result = []
    for i in range(len(string)):
        result.append(string[:i+1])
    return result


@pytest.mark.parametrize("input_string,expected", [
    ('abc', ['a', 'ab', 'abc']),
    ('', []),
    ('a', ['a']),
    ('hello', ['h', 'he', 'hel', 'hell', 'hello']),
    ('12345', ['1', '12', '123', '1234', '12345']),
    ('  ', [' ', '  ']),
    ('a b', ['a', 'a ', 'a b']),
    ('!@#', ['!', '!@', '!@#']),
    ('x', ['x']),
    ('ab', ['a', 'ab']),
    ('test', ['t', 'te', 'tes', 'test']),
    ('A', ['A']),
    ('ABC', ['A', 'AB', 'ABC']),
    ('123', ['1', '12', '123']),
    ('\n', ['\n']),
    ('\t\n', ['\t', '\t\n']),
    ('😀', ['😀']),
    ('😀😁', ['😀', '😀😁']),
    ('a\nb\nc', ['a', 'a\n', 'a\nb', 'a\nb\n', 'a\nb\nc']),
    ('_test', ['_', '_t', '_te', '_tes', '_test']),
    ('test_case', ['t', 'te', 'tes', 'test', 'test_', 'test_c', 'test_ca', 'test_cas', 'test_case'])
])
def test_all_prefixes(input_string, expected):
    assert all_prefixes(input_string) == expected


def test_all_prefixes_empty_string():
    assert all_prefixes('') == []


def test_all_prefixes_single_char():
    assert all_prefixes('z') == ['z']


def test_all_prefixes_repeated_chars():
    assert all_prefixes('aaa') == ['a', 'aa', 'aaa']


def test_all_prefixes_long_string():
    long_str = 'a' * 100
    result = all_prefixes(long_str)
    assert len(result) == 100
    assert result[0] == 'a'
    assert result[-1] == long_str
    assert all(len(result[i]) == i + 1 for i in range(100))


def test_all_prefixes_unicode():
    assert all_prefixes('café') == ['c', 'ca', 'caf', 'café']


def test_all_prefixes_numbers_as_string():
    assert all_prefixes('987654321') == ['9', '98', '987', '9876', '98765', '987654', '9876543', '98765432', '987654321']


def test_all_prefixes_special_chars():
    assert all_prefixes('$%^') == ['$', '$%', '$%^']


def test_all_prefixes_mixed_case():
    assert all_prefixes('AbC') == ['A', 'Ab', 'AbC']
