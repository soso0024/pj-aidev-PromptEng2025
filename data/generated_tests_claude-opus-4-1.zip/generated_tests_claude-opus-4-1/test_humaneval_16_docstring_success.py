# Test cases for HumanEval/16
# Generated using Claude API



def count_distinct_characters(string: str) -> int:
    """ Given a string, find out how many distinct characters (regardless of case) does it consist of
    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """

    return len(set(string.lower()))


# Generated test cases:
import pytest


@pytest.mark.parametrize("input_string,expected", [
    ("xyzXYZ", 3),
    ("Jerry", 4),
    ("", 0),
    ("a", 1),
    ("A", 1),
    ("aA", 1),
    ("abc", 3),
    ("ABC", 3),
    ("aAbBcC", 3),
    ("Hello World", 8),
    ("hello world", 8),
    ("HELLO WORLD", 8),
    ("123", 3),
    ("!@#$%", 5),
    ("a1b2c3", 6),
    ("   ", 1),
    ("a b c", 4),
    ("aaaaaaa", 1),
    ("AAAAAAA", 1),
    ("aAaAaAa", 1),
    ("abcdefghijklmnopqrstuvwxyz", 26),
    ("ABCDEFGHIJKLMNOPQRSTUVWXYZ", 26),
    ("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", 26),
    ("The quick brown fox jumps over the lazy dog", 27),
    ("THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG", 27),
    ("0123456789", 10),
    ("!@#$%^&*()", 10),
    ("Hello123!@#", 10),
    ("\n\t\r", 3),
    ("a\nb\tc", 5),
    ("😀😁😂", 3),
    ("aaa😀bbb😀ccc", 4),
    ("Über", 4),
    ("café", 4),
    ("naïve", 5),
    ("résumé", 5),
    ("Москва", 6),
    ("北京", 2),
    ("🐍Python🐍", 7),
    ("a" * 1000, 1),
    ("ab" * 500, 2),
])
def test_count_distinct_characters(input_string, expected):
    assert count_distinct_characters(input_string) == expected


def test_count_distinct_characters_type():
    assert isinstance(count_distinct_characters("test"), int)


def test_count_distinct_characters_empty_string():
    assert count_distinct_characters("") == 0


def test_count_distinct_characters_single_char():
    assert count_distinct_characters("x") == 1


def test_count_distinct_characters_repeated_chars():
    assert count_distinct_characters("aaabbbccc") == 3


def test_count_distinct_characters_mixed_case():
    assert count_distinct_characters("AaBbCc") == 3


def test_count_distinct_characters_special_chars():
    assert count_distinct_characters("!@#abc123") == 9


def test_count_distinct_characters_whitespace():
    assert count_distinct_characters("a b c") == 4
    assert count_distinct_characters("   ") == 1
    assert count_distinct_characters("\t\n\r") == 3