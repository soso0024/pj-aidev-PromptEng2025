# Test cases for HumanEval/73
# Generated using Claude API


def smallest_change(arr):
    """
    Given an array arr of integers, find the minimum number of elements that
    need to be changed to make the array palindromic. A palindromic array is an array that
    is read the same backwards and forwards. In one change, you can change one element to any other element.

    For example:
    smallest_change([1,2,3,5,4,7,9,6]) == 4
    smallest_change([1, 2, 3, 4, 3, 2, 2]) == 1
    smallest_change([1, 2, 3, 2, 1]) == 0
    """

    ans = 0
    for i in range(len(arr) // 2):
        if arr[i] != arr[len(arr) - i - 1]:
            ans += 1
    return ans


# Generated test cases:
import pytest

def smallest_change(arr):
    ans = 0
    for i in range(len(arr) // 2):
        if arr[i] != arr[len(arr) - i - 1]:
            ans += 1
    return ans


@pytest.mark.parametrize("arr,expected", [
    # Examples from docstring
    ([1, 2, 3, 5, 4, 7, 9, 6], 4),
    ([1, 2, 3, 4, 3, 2, 2], 1),
    ([1, 2, 3, 2, 1], 0),
    
    # Empty array
    ([], 0),
    
    # Single element
    ([1], 0),
    
    # Two elements - same
    ([1, 1], 0),
    
    # Two elements - different
    ([1, 2], 1),
    
    # Already palindromic arrays
    ([1, 2, 1], 0),
    ([1, 2, 2, 1], 0),
    ([5, 5, 5, 5], 0),
    ([1, 2, 3, 3, 2, 1], 0),
    
    # Arrays needing changes
    ([1, 2, 3], 1),
    ([1, 2, 3, 4], 2),
    ([1, 2, 3, 4, 5], 2),
    ([1, 2, 3, 4, 5, 6], 3),
    
    # All different elements
    ([1, 2, 3, 4, 5, 6, 7, 8], 4),
    
    # Repeated elements
    ([1, 1, 1, 2], 1),
    ([2, 2, 2, 2, 2], 0),
    
    # Negative numbers
    ([-1, -2, -3, -2, -1], 0),
    ([-1, -2, -3, -4], 2),
    
    # Mixed positive and negative
    ([-1, 2, -3, 2, -1], 0),
    ([1, -2, 3, -2, 1], 0),
    ([1, -2, 3, 4, -5], 2),
    
    # Zero in array
    ([0, 1, 0], 0),
    ([0, 0, 0, 0], 0),
    ([0, 1, 2, 3], 2),
    
    # Large numbers
    ([1000000, 999999, 999999, 1000000], 0),
    ([1000000, 999999, 888888, 777777], 2),
    
    # Odd length arrays
    ([1, 2, 3, 4, 5, 6, 7], 3),
    ([1, 2, 3, 4, 3, 2, 1], 0),
    
    # Even length arrays  
    ([1, 2, 3, 4, 5, 6], 3),
    ([1, 2, 3, 3, 2, 1], 0),
])
def test_smallest_change(arr, expected):
    assert smallest_change(arr) == expected


def test_smallest_change_does_not_modify_input():
    arr = [1, 2, 3, 4, 5]
    original = arr.copy()
    smallest_change(arr)
    assert arr == original


def test_smallest_change_with_large_array():
    # Test with a large palindromic array
    large_palindrome = list(range(1000)) + list(range(999, -1, -1))
    assert smallest_change(large_palindrome) == 0
    
    # Test with a large non-palindromic array
    large_non_palindrome = list(range(2000))
    assert smallest_change(large_non_palindrome) == 1000
