# Test cases for HumanEval/81
# Generated using Claude API


def numerical_letter_grade(grades):
    """It is the last week of the semester and the teacher has to give the grades
    to students. The teacher has been making her own algorithm for grading.
    The only problem is, she has lost the code she used for grading.
    She has given you a list of GPAs for some students and you have to write 
    a function that can output a list of letter grades using the following table:
             GPA       |    Letter grade
              4.0                A+
            > 3.7                A 
            > 3.3                A- 
            > 3.0                B+
            > 2.7                B 
            > 2.3                B-
            > 2.0                C+
            > 1.7                C
            > 1.3                C-
            > 1.0                D+ 
            > 0.7                D 
            > 0.0                D-
              0.0                E
    

    Example:
    grade_equation([4.0, 3, 1.7, 2, 3.5]) ==> ['A+', 'B', 'C-', 'C', 'A-']
    """


   
    letter_grade = []
    for gpa in grades:
        if gpa == 4.0:
            letter_grade.append("A+")
        elif gpa > 3.7:
            letter_grade.append("A")
        elif gpa > 3.3:
            letter_grade.append("A-")
        elif gpa > 3.0:
            letter_grade.append("B+")
        elif gpa > 2.7:
            letter_grade.append("B")
        elif gpa > 2.3:
            letter_grade.append("B-")
        elif gpa > 2.0:
            letter_grade.append("C+")
        elif gpa > 1.7:
            letter_grade.append("C")
        elif gpa > 1.3:
            letter_grade.append("C-")
        elif gpa > 1.0:
            letter_grade.append("D+")
        elif gpa > 0.7:
            letter_grade.append("D")
        elif gpa > 0.0:
            letter_grade.append("D-")
        else:
            letter_grade.append("E")
    return letter_grade


# Generated test cases:
import pytest

def numerical_letter_grade(grades):
    letter_grade = []
    for gpa in grades:
        if gpa == 4.0:
            letter_grade.append("A+")
        elif gpa > 3.7:
            letter_grade.append("A")
        elif gpa > 3.3:
            letter_grade.append("A-")
        elif gpa > 3.0:
            letter_grade.append("B+")
        elif gpa > 2.7:
            letter_grade.append("B")
        elif gpa > 2.3:
            letter_grade.append("B-")
        elif gpa > 2.0:
            letter_grade.append("C+")
        elif gpa > 1.7:
            letter_grade.append("C")
        elif gpa > 1.3:
            letter_grade.append("C-")
        elif gpa > 1.0:
            letter_grade.append("D+")
        elif gpa > 0.7:
            letter_grade.append("D")
        elif gpa > 0.0:
            letter_grade.append("D-")
        else:
            letter_grade.append("E")
    return letter_grade


@pytest.mark.parametrize("grades,expected", [
    ([4.0, 3, 1.7, 2, 3.5], ['A+', 'B', 'C-', 'C', 'A-']),
    ([4.0], ['A+']),
    ([3.9], ['A']),
    ([3.8], ['A']),
    ([3.7], ['A-']),
    ([3.5], ['A-']),
    ([3.4], ['A-']),
    ([3.3], ['B+']),
    ([3.2], ['B+']),
    ([3.1], ['B+']),
    ([3.0], ['B']),
    ([2.9], ['B']),
    ([2.8], ['B']),
    ([2.7], ['B-']),
    ([2.5], ['B-']),
    ([2.4], ['B-']),
    ([2.3], ['C+']),
    ([2.2], ['C+']),
    ([2.1], ['C+']),
    ([2.0], ['C']),
    ([1.9], ['C']),
    ([1.8], ['C']),
    ([1.7], ['C-']),
    ([1.5], ['C-']),
    ([1.4], ['C-']),
    ([1.3], ['D+']),
    ([1.2], ['D+']),
    ([1.1], ['D+']),
    ([1.0], ['D']),
    ([0.9], ['D']),
    ([0.8], ['D']),
    ([0.7], ['D-']),
    ([0.5], ['D-']),
    ([0.1], ['D-']),
    ([0.0], ['E']),
    ([], []),
    ([4.0, 0.0], ['A+', 'E']),
    ([3.71, 3.31, 3.01, 2.71, 2.31, 2.01, 1.71, 1.31, 1.01, 0.71, 0.01], 
     ['A', 'A-', 'B+', 'B', 'B-', 'C+', 'C', 'C-', 'D+', 'D', 'D-']),
    ([3.7, 3.3, 3.0, 2.7, 2.3, 2.0, 1.7, 1.3, 1.0, 0.7, 0.0],
     ['A-', 'B+', 'B', 'B-', 'C+', 'C', 'C-', 'D+', 'D', 'D-', 'E']),
    ([4.0, 3.9, 3.5, 3.2, 2.9, 2.5, 2.2, 1.9, 1.5, 1.2, 0.9, 0.5, 0.0],
     ['A+', 'A', 'A-', 'B+', 'B', 'B-', 'C+', 'C', 'C-', 'D+', 'D', 'D-', 'E']),
])
def test_numerical_letter_grade(grades, expected):
    assert numerical_letter_grade(grades) == expected


def test_numerical_letter_grade_multiple_same_grades():
    assert numerical_letter_grade([4.0, 4.0, 4.0]) == ['A+', 'A+', 'A+']
    assert numerical_letter_grade([0.0, 0.0]) == ['E', 'E']
    assert numerical_letter_grade([2.5, 2.5, 2.5]) == ['B-', 'B-', 'B-']


def test_numerical_letter_grade_edge_values():
    assert numerical_letter_grade([3.70001, 3.30001, 3.00001, 2.70001, 2.30001, 2.00001, 1.70001, 1.30001, 1.00001, 0.70001, 0.00001]) == ['A', 'A-', 'B+', 'B', 'B-', 'C+', 'C', 'C-', 'D+', 'D', 'D-']
