# Test cases for HumanEval/142
# Generated using Claude API




def sum_squares(lst):
    """"
    This function will take a list of integers. For all entries in the list, the function shall square the integer entry if its index is a 
    multiple of 3 and will cube the integer entry if its index is a multiple of 4 and not a multiple of 3. The function will not 
    change the entries in the list whose indexes are not a multiple of 3 or 4. The function shall then return the sum of all entries. 
    
    Examples:
    For lst = [1,2,3] the output should be 6
    For lst = []  the output should be 0
    For lst = [-1,-5,2,-1,-5]  the output should be -126
    """

    result =[]
    for i in range(len(lst)):
        if i %3 == 0:
            result.append(lst[i]**2)
        elif i % 4 == 0 and i%3 != 0:
            result.append(lst[i]**3)
        else:
            result.append(lst[i])
    return sum(result)


# Generated test cases:
import pytest

@pytest.mark.parametrize("lst,expected", [
    ([1, 2, 3], 6),
    ([], 0),
    ([-1, -5, 2, -1, -5], -126),
    ([1], 1),
    ([2], 4),
    ([0], 0),
    ([0, 0, 0, 0, 0], 0),
    ([1, 1, 1, 1, 1], 5),
    ([2, 2, 2, 2, 2], 20),
    ([1, 2, 3, 4, 5, 6, 7, 8, 9], 939),
    ([-1, -2, -3, -4, -5, -6, -7, -8, -9], -807),
    ([10], 100),
    ([10, 20], 120),
    ([10, 20, 30], 150),
    ([10, 20, 30, 40], 1750),
    ([10, 20, 30, 40, 50], 126750),
    ([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], 1062),
    ([5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5], 405),
    ([-3, -3, -3, -3, -3, -3, -3, -3, -3], -39),
    ([100, 200, 300, 400, 500], 125170500),
    ([1, 0, 0, 0, 0, 0, 0, 0, 0], 1),
    ([0, 1, 0, 0, 0, 0, 0, 0, 0], 1),
    ([0, 0, 1, 0, 0, 0, 0, 0, 0], 1),
    ([0, 0, 0, 1, 0, 0, 0, 0, 0], 1),
    ([0, 0, 0, 0, 1, 0, 0, 0, 0], 1),
    ([2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16], 1705),
    ([-2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12, -13, -14, -15, -16], -885),
    ([1000], 1000000),
    ([-1000], 1000000),
    ([7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7], 1379),
])
def test_sum_squares(lst, expected):
    assert sum_squares(lst) == expected

def test_sum_squares_does_not_modify_input():
    original = [1, 2, 3, 4, 5]
    lst = original.copy()
    sum_squares(lst)
    assert lst == original

def test_sum_squares_large_list():
    lst = list(range(100))
    result = sum_squares(lst)
    assert isinstance(result, int)

def test_sum_squares_alternating_signs():
    lst = [1, -1, 1, -1, 1, -1, 1, -1]
    result = sum_squares(lst)
    assert result == 2

def test_sum_squares_single_negative():
    assert sum_squares([-5]) == 25

def test_sum_squares_index_multiples():
    lst = [1] * 13
    result = sum_squares(lst)
    expected = 13
    assert result == expected