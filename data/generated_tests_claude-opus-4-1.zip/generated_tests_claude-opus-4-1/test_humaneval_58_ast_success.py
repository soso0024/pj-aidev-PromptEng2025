# Test cases for HumanEval/58
# Generated using Claude API



def common(l1: list, l2: list):
    """Return sorted unique common elements for two lists.
    >>> common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121])
    [1, 5, 653]
    >>> common([5, 3, 2, 8], [3, 2])
    [2, 3]

    """

    ret = set()
    for e1 in l1:
        for e2 in l2:
            if e1 == e2:
                ret.add(e1)
    return sorted(list(ret))


# Generated test cases:
import pytest


@pytest.mark.parametrize("l1,l2,expected", [
    # Empty lists
    ([], [], []),
    ([1, 2, 3], [], []),
    ([], [1, 2, 3], []),
    
    # No common elements
    ([1, 2, 3], [4, 5, 6], []),
    (['a', 'b'], ['c', 'd'], []),
    
    # All elements common
    ([1, 2, 3], [1, 2, 3], [1, 2, 3]),
    (['a', 'b'], ['a', 'b'], ['a', 'b']),
    
    # Some common elements
    ([1, 2, 3, 4], [3, 4, 5, 6], [3, 4]),
    (['a', 'b', 'c'], ['b', 'c', 'd'], ['b', 'c']),
    
    # Duplicates in input lists
    ([1, 1, 2, 2, 3], [2, 2, 3, 3, 4], [2, 3]),
    ([1, 1, 1], [1, 1, 1], [1]),
    (['a', 'a', 'b'], ['a', 'b', 'b'], ['a', 'b']),
    
    # Single element lists
    ([1], [1], [1]),
    ([1], [2], []),
    
    # True/False are equal to 1/0
    ([True, False, 1, 0], [1, 0, 2], [0, 1]),
    
    # Negative numbers
    ([-1, -2, 0, 1], [-2, 0, 2], [-2, 0]),
    
    # Large lists
    (list(range(100)), list(range(50, 150)), list(range(50, 100))),
    
    # None values
    ([None, 1, 2], [None, 3, 4], [None]),
    ([None, None], [None], [None]),
    
    # Complex data types
    ([1, 2, (3, 4)], [(3, 4), 5], [(3, 4)]),
    
    # String elements
    (['hello', 'world'], ['world', 'python'], ['world']),
    (['', 'a'], ['', 'b'], ['']),
    
    # Order testing (should return sorted)
    ([3, 1, 2], [2, 3, 4], [2, 3]),
    (['c', 'a', 'b'], ['b', 'c', 'd'], ['b', 'c']),
])
def test_common(l1, l2, expected):
    assert common(l1, l2) == expected


def test_common_does_not_modify_input():
    l1 = [1, 2, 3]
    l2 = [2, 3, 4]
    l1_copy = l1.copy()
    l2_copy = l2.copy()
    common(l1, l2)
    assert l1 == l1_copy
    assert l2 == l2_copy


def test_common_returns_sorted():
    result = common([5, 3, 1, 4, 2], [2, 4, 1, 6])
    assert result == [1, 2, 4]
    assert result == sorted(result)


def test_common_with_mixed_numeric_types():
    result = common([1, 2.0, 3], [2, 3.0, 4])
    assert result == [2, 3]