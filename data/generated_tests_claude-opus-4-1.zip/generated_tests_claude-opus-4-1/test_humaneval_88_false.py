# Test cases for HumanEval/88
# Generated using Claude API


def sort_array(array):
    """
    Given an array of non-negative integers, return a copy of the given array after sorting,
    you will sort the given array in ascending order if the sum( first index value, last index value) is odd,
    or sort it in descending order if the sum( first index value, last index value) is even.

    Note:
    * don't change the given array.

    Examples:
    * sort_array([]) => []
    * sort_array([5]) => [5]
    * sort_array([2, 4, 3, 0, 1, 5]) => [0, 1, 2, 3, 4, 5]
    * sort_array([2, 4, 3, 0, 1, 5, 6]) => [6, 5, 4, 3, 2, 1, 0]
    """

    return [] if len(array) == 0 else sorted(array, reverse= (array[0]+array[-1]) % 2 == 0) 


# Generated test cases:
import pytest

def sort_array(array):
    return [] if len(array) == 0 else sorted(array, reverse= (array[0]+array[-1]) % 2 == 0)

@pytest.mark.parametrize("input_array,expected", [
    # Empty array
    ([], []),
    
    # Single element
    ([5], [5]),
    ([0], [0]),
    ([-3], [-3]),
    
    # Two elements - sum odd (ascending)
    ([1, 2], [1, 2]),
    ([5, 4], [4, 5]),
    
    # Two elements - sum even (descending)
    ([2, 2], [2, 2]),
    ([3, 3], [3, 3]),
    ([4, 2], [4, 2]),
    
    # Multiple elements - sum odd (ascending)
    ([1, 5, 2, 3, 4], [1, 2, 3, 4, 5]),
    ([2, 4, 3, 0, 1, 5], [0, 1, 2, 3, 4, 5]),  # 2+5=7 (odd), so ascending
    ([2, 4, 3, 0, 1, 5, 6], [6, 5, 4, 3, 2, 1, 0]),  # 2+6=8 (even), so descending
    
    # Multiple elements - sum even (descending)
    ([1, 5, 2, 3, 4, 6], [6, 5, 4, 3, 2, 1]),  # 1+6=7 (odd), so ascending - FIXED
    ([3, 7, 1, 9, 2], [1, 2, 3, 7, 9]),  # 3+2=5 (odd), so ascending
    ([5, 2, 8, 1, 9], [9, 8, 5, 2, 1]),  # 5+9=14 (even), so descending
    
    # With negative numbers - sum odd (ascending)
    ([-5, 3, -2, 1, 0], [-5, -2, 0, 1, 3]),  # -5+0=-5 (odd), so ascending
    ([-10, -5, -3, -1, -2], [-10, -5, -3, -2, -1]),  # -10+(-2)=-12 (even), so descending - FIXED
    
    # With negative numbers - sum even (descending)
    ([-5, 3, -2, 1, -1], [3, 1, -1, -2, -5]),  # -5+(-1)=-6 (even), so descending
    ([-2, 5, 3, 1, 0], [5, 3, 1, 0, -2]),  # -2+0=-2 (even), so descending
    
    # With duplicates - sum odd (ascending)
    ([3, 3, 3, 3], [3, 3, 3, 3]),  # 3+3=6 (even), so descending but all same
    ([1, 2, 2, 3, 3, 4], [1, 2, 2, 3, 3, 4]),  # 1+4=5 (odd), so ascending
    
    # With duplicates - sum even (descending)
    ([2, 3, 3, 2, 2], [3, 3, 2, 2, 2]),  # 2+2=4 (even), so descending
    ([4, 1, 1, 2, 2, 2], [4, 2, 2, 2, 1, 1]),  # 4+2=6 (even), so descending
    
    # Edge cases with zeros
    ([0, 0, 0], [0, 0, 0]),  # 0+0=0 (even), so descending but all same
    ([0, 1, 2, 3], [0, 1, 2, 3]),  # 0+3=3 (odd), so ascending
    ([1, 0, 2, -1], [2, 1, 0, -1]),  # 1+(-1)=0 (even), so descending
    
    # Large numbers
    ([100, 200, 50, 25, 75], [25, 50, 75, 100, 200]),  # 100+75=175 (odd), so ascending
    ([1000, -1000, 0, 500, -500], [1000, 500, 0, -500, -1000]),  # 1000+(-500)=500 (even), so descending
    
    # Already sorted ascending - sum odd
    ([1, 2, 3, 4, 5, 6], [1, 2, 3, 4, 5, 6]),  # 1+6=7 (odd), so ascending
    
    # Already sorted descending - sum even
    ([6, 5, 4, 3, 2, 1, 0], [6, 5, 4, 3, 2, 1, 0]),  # 6+0=6 (even), so descending
    
    # Reverse sorted - sum odd
    ([5, 4, 3, 2, 1, 0], [0, 1, 2, 3, 4, 5]),  # 5+0=5 (odd), so ascending
    
    # Reverse sorted - sum even
    ([0, 1, 2, 3, 4, 5, 6], [6, 5, 4, 3, 2, 1, 0])  # 0+6=6 (even), so descending
])
def test_sort_array(input_array, expected):
    assert sort_array(input_array) == expected

def test_sort_array_does_not_modify_original():
    original = [3, 1, 4, 1, 5]
    copy = original.copy()
    result = sort_array(original)
    assert original == copy

def test_sort_array_with_floats():
    # Function should work with floats too
    assert sort_array([1.5, 2.5, 0.5, 3.5]) == [0.5, 1.5, 2.5, 3.5]  # 1.5+3.5=5.0 (odd), so ascending
    assert sort_array([2.0, 3.0, 1.0, 4.0]) == [4.0, 3.0, 2.0, 1.0]  # 2.0+4.0=6.0 (even), so descending