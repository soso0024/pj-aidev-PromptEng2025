# Test cases for HumanEval/101
# Generated using Claude API


def words_string(s):
    """
    You will be given a string of words separated by commas or spaces. Your task is
    to split the string into words and return an array of the words.
    
    For example:
    words_string("Hi, my name is John") == ["Hi", "my", "name", "is", "John"]
    words_string("One, two, three, four, five, six") == ["One", "two", "three", "four", "five", "six"]
    """

    if not s:
        return []

    s_list = []

    for letter in s:
        if letter == ',':
            s_list.append(' ')
        else:
            s_list.append(letter)

    s_list = "".join(s_list)
    return s_list.split()


# Generated test cases:
import pytest

@pytest.mark.parametrize("input_str,expected", [
    ("Hi, my name is John", ["Hi", "my", "name", "is", "John"]),
    ("One, two, three, four, five, six", ["One", "two", "three", "four", "five", "six"]),
    ("", []),
    ("word", ["word"]),
    ("a,b,c", ["a", "b", "c"]),
    ("a b c", ["a", "b", "c"]),
    ("  spaces  ", ["spaces"]),
    (",,,,", []),
    ("    ", []),
    ("word1,word2 word3", ["word1", "word2", "word3"]),
    ("  leading", ["leading"]),
    ("trailing  ", ["trailing"]),
    ("multiple   spaces", ["multiple", "spaces"]),
    ("comma,comma,", ["comma", "comma"]),
    (",leading", ["leading"]),
    ("a, b, c", ["a", "b", "c"]),
    ("mixed, spaces and,commas", ["mixed", "spaces", "and", "commas"]),
    ("single", ["single"]),
    ("two words", ["two", "words"]),
    ("a,b", ["a", "b"]),
    ("a, b", ["a", "b"]),
    ("a ,b", ["a", "b"]),
    ("a , b", ["a", "b"]),
    ("123,456,789", ["123", "456", "789"]),
    ("special!@#,chars$%^", ["special!@#", "chars$%^"]),
    ("tab\ttab", ["tab", "tab"]),
    ("newline\nnewline", ["newline", "newline"]),
])
def test_words_string(input_str, expected):
    assert words_string(input_str) == expected


def test_words_string_none():
    assert words_string(None) == []


def test_words_string_empty_string():
    assert words_string("") == []


def test_words_string_only_spaces():
    assert words_string("     ") == []


def test_words_string_only_commas():
    assert words_string(",,,,,") == []


def test_words_string_mixed_separators():
    assert words_string("  ,  ,  ") == []


def test_words_string_long_string():
    long_str = "word1, word2, word3, word4, word5, word6, word7, word8, word9, word10"
    expected = ["word1", "word2", "word3", "word4", "word5", "word6", "word7", "word8", "word9", "word10"]
    assert words_string(long_str) == expected


def test_words_string_consecutive_commas():
    assert words_string("a,,b") == ["a", "b"]


def test_words_string_consecutive_spaces():
    assert words_string("a    b") == ["a", "b"]