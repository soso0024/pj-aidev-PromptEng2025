# Test cases for HumanEval/86
# Generated using Claude API


def anti_shuffle(s):
    """
    Write a function that takes a string and returns an ordered version of it.
    Ordered version of string, is a string where all words (separated by space)
    are replaced by a new word where all the characters arranged in
    ascending order based on ascii value.
    Note: You should keep the order of words and blank spaces in the sentence.

    For example:
    anti_shuffle('Hi') returns 'Hi'
    anti_shuffle('hello') returns 'ehllo'
    anti_shuffle('Hello World!!!') returns 'Hello !!!Wdlor'
    """

    return ' '.join([''.join(sorted(list(i))) for i in s.split(' ')])


# Generated test cases:
import pytest

def anti_shuffle(s):
    return ' '.join([''.join(sorted(list(i))) for i in s.split(' ')])

@pytest.mark.parametrize("input_str,expected", [
    # Basic examples from docstring
    ('Hi', 'Hi'),
    ('hello', 'ehllo'),
    ('Hello World!!!', 'Hello !!!Wdlor'),
    
    # Single character
    ('a', 'a'),
    ('Z', 'Z'),
    
    # Empty string
    ('', ''),
    
    # Single word cases
    ('abc', 'abc'),
    ('cba', 'abc'),
    ('321', '123'),
    
    # Multiple spaces
    ('hello  world', 'ehllo  dlorw'),
    ('a   b   c', 'a   b   c'),
    
    # Special characters
    ('!@#$%', '!#$%@'),
    ('test123', '123estt'),
    
    # Mixed case
    ('AbC', 'ACb'),
    ('zZaA', 'AZaz'),  # Fixed: uppercase comes before lowercase in ASCII
    
    # Punctuation with words
    ('hello!', '!ehllo'),
    ('world?', '?dlorw'),
    ('test.', '.estt'),
    
    # Multiple words with various characters
    ('The Quick Brown Fox', 'Teh Qciku Bnorw Fox'),
    ('123 456 789', '123 456 789'),
    ('a1b2c3 d4e5f6', '123abc 456def'),
    
    # Leading/trailing spaces
    (' hello', ' ehllo'),
    ('world ', 'dlorw '),
    (' hello world ', ' ehllo dlorw '),
    
    # Only spaces
    ('   ', '   '),
    (' ', ' '),
    
    # Unicode/ASCII ordering
    ('dcba', 'abcd'),
    ('9876543210', '0123456789'),
    
    # Complex punctuation
    ('!!!???...', '!!!...???'),
    ('()[]{}', '()[]{}'),
    
    # Mixed everything
    ('Hello123!!! World456???', '!!!123Hello 456???Wdlor'),  # Fixed: sorted order
    ('aBc DeF gHi', 'Bac DFe Hgi'),  # Fixed: uppercase before lowercase
    
    # Edge case with numbers and letters
    ('z1a', '1az'),
    ('9a1', '19a'),
    
    # Single space
    (' ', ' '),
    
    # Word with repeating characters
    ('aabbcc', 'aabbcc'),
    ('ccbbaa', 'aabbcc'),
    ('banana', 'aaabnn'),
    
    # All same character
    ('aaaa', 'aaaa'),
    ('ZZZZ', 'ZZZZ'),
    
    # Symbols and alphanumeric
    ('a!b@c#', '!#@abc'),
    ('$%^&*()', '$%&()*^'),
])
def test_anti_shuffle(input_str, expected):
    assert anti_shuffle(input_str) == expected

def test_anti_shuffle_preserves_word_count():
    input_str = "one two three four five"
    result = anti_shuffle(input_str)
    assert len(result.split(' ')) == len(input_str.split(' '))

def test_anti_shuffle_preserves_total_length():
    input_str = "test string with spaces"
    result = anti_shuffle(input_str)
    assert len(result) == len(input_str)

def test_anti_shuffle_preserves_space_positions():
    input_str = "a b c d e"
    result = anti_shuffle(input_str)
    input_spaces = [i for i, char in enumerate(input_str) if char == ' ']
    result_spaces = [i for i, char in enumerate(result) if char == ' ']
    assert input_spaces == result_spaces