# Test cases for HumanEval/107
# Generated using Claude API


def even_odd_palindrome(n):
    """
    Given a positive integer n, return a tuple that has the number of even and odd
    integer palindromes that fall within the range(1, n), inclusive.

    Example 1:

        Input: 3
        Output: (1, 2)
        Explanation:
        Integer palindrome are 1, 2, 3. one of them is even, and two of them are odd.

    Example 2:

        Input: 12
        Output: (4, 6)
        Explanation:
        Integer palindrome are 1, 2, 3, 4, 5, 6, 7, 8, 9, 11. four of them are even, and 6 of them are odd.

    Note:
        1. 1 <= n <= 10^3
        2. returned tuple has the number of even and odd integer palindromes respectively.
    """

    def is_palindrome(n):
        return str(n) == str(n)[::-1]

    even_palindrome_count = 0
    odd_palindrome_count = 0

    for i in range(1, n+1):
        if i%2 == 1 and is_palindrome(i):
                odd_palindrome_count += 1
        elif i%2 == 0 and is_palindrome(i):
            even_palindrome_count += 1
    return (even_palindrome_count, odd_palindrome_count)


# Generated test cases:
import pytest


@pytest.mark.parametrize("n,expected", [
    (1, (0, 1)),
    (2, (1, 1)),
    (3, (1, 2)),
    (4, (2, 2)),
    (5, (2, 3)),
    (6, (3, 3)),
    (7, (3, 4)),
    (8, (4, 4)),
    (9, (4, 5)),
    (10, (4, 5)),
    (11, (4, 6)),
    (12, (4, 6)),
    (20, (4, 6)),
    (22, (5, 6)),
    (33, (5, 7)),
    (44, (6, 7)),
    (55, (6, 8)),
    (66, (7, 8)),
    (77, (7, 9)),
    (88, (8, 9)),
    (99, (8, 10)),
    (100, (8, 10)),
    (101, (8, 11)),
    (111, (8, 12)),
    (121, (8, 13)),
    (131, (8, 14)),
    (141, (8, 15)),
    (151, (8, 16)),
    (161, (8, 17)),
    (171, (8, 18)),
    (181, (8, 19)),
    (191, (8, 20)),
    (200, (8, 20)),
    (212, (10, 20)),
    (222, (11, 20)),
    (0, (0, 0)),
])
def test_even_odd_palindrome(n, expected):
    assert even_odd_palindrome(n) == expected


def test_even_odd_palindrome_single_digit():
    assert even_odd_palindrome(1) == (0, 1)
    assert even_odd_palindrome(9) == (4, 5)


def test_even_odd_palindrome_double_digit():
    assert even_odd_palindrome(10) == (4, 5)
    assert even_odd_palindrome(11) == (4, 6)
    assert even_odd_palindrome(22) == (5, 6)
    assert even_odd_palindrome(99) == (8, 10)


def test_even_odd_palindrome_triple_digit():
    assert even_odd_palindrome(100) == (8, 10)
    assert even_odd_palindrome(101) == (8, 11)
    assert even_odd_palindrome(111) == (8, 12)
    assert even_odd_palindrome(121) == (8, 13)


def test_even_odd_palindrome_zero():
    assert even_odd_palindrome(0) == (0, 0)


def test_even_odd_palindrome_negative():
    assert even_odd_palindrome(-1) == (0, 0)
    assert even_odd_palindrome(-10) == (0, 0)


def test_even_odd_palindrome_large_numbers():
    result = even_odd_palindrome(1000)
    assert result[0] == 48
    assert result[1] == 60


def test_even_odd_palindrome_all_single_digits():
    for i in range(1, 10):
        even_count, odd_count = even_odd_palindrome(i)
        if i % 2 == 0:
            assert even_count == i // 2
            assert odd_count == (i + 1) // 2
        else:
            assert even_count == i // 2
            assert odd_count == (i + 1) // 2