# Test cases for HumanEval/38
# Generated using Claude API



def encode_cyclic(s: str):
    """
    returns encoded string by cycling groups of three characters.
    """
    # split string to groups. Each of length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # cycle elements in each group. Unless group has fewer elements than 3.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def decode_cyclic(s: str):
    """
    takes as input string encoded with encode_cyclic function. Returns decoded string.
    """

    return encode_cyclic(encode_cyclic(s))


# Generated test cases:
import pytest


def encode_cyclic(s: str):
    """
    returns encoded string by cycling groups of three characters.
    """
    # split string to groups. Each of length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # cycle elements in each group. Unless group has fewer elements than 3.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def decode_cyclic(s: str):
    """
    takes as input string encoded with encode_cyclic function. Returns decoded string.
    """
    return encode_cyclic(encode_cyclic(s))


@pytest.mark.parametrize("input_str,expected", [
    ("", ""),
    ("a", "a"),
    ("ab", "ab"),
    ("abc", "bca"),
    ("abcd", "bcad"),
    ("abcde", "bcade"),
    ("abcdef", "bcaefd"),
    ("abcdefg", "bcaefdg"),
    ("abcdefgh", "bcaefdgh"),
    ("abcdefghi", "bcaefdhig"),
    ("123456789", "231564897"),
    ("hello world", "elho lorwld"),
    ("   ", "   "),
    ("123", "231"),
    ("!@#$%^&*()", "@#!%^$*(&)"),
])
def test_encode_cyclic(input_str, expected):
    assert encode_cyclic(input_str) == expected


@pytest.mark.parametrize("input_str", [
    "",
    "a",
    "ab",
    "abc",
    "abcd",
    "abcde",
    "abcdef",
    "abcdefg",
    "abcdefgh",
    "abcdefghi",
    "abcdefghij",
    "abcdefghijk",
    "abcdefghijkl",
    "hello world",
    "The quick brown fox jumps over the lazy dog",
    "1234567890",
    "!@#$%^&*()",
    "   ",
    "\n\t\r",
    "aaaaaaaaaaa",
    "abcabcabcabc",
])
def test_decode_cyclic_reverses_encode(input_str):
    encoded = encode_cyclic(input_str)
    decoded = decode_cyclic(encoded)
    assert decoded == input_str


@pytest.mark.parametrize("encoded,expected", [
    ("", ""),
    ("a", "a"),
    ("ab", "ab"),
    ("bca", "abc"),
    ("bcad", "abcd"),
    ("bcade", "abcde"),
    ("bcaefd", "abcdef"),
    ("bcaefdg", "abcdefg"),
    ("bcaefdgh", "abcdefgh"),
    ("bcaefdhig", "abcdefghi"),
    ("231564897", "123456789"),
    ("elho lorwld", "hello world"),
    ("   ", "   "),
    ("231", "123"),
])
def test_decode_cyclic(encoded, expected):
    assert decode_cyclic(encoded) == expected


def test_encode_decode_cycle():
    test_string = "The quick brown fox"
    encoded_once = encode_cyclic(test_string)
    encoded_twice = encode_cyclic(encoded_once)
    encoded_thrice = encode_cyclic(encoded_twice)
    assert encoded_thrice == test_string


def test_encode_special_characters():
    special_chars = "!@#$%^&*()_+-=[]{}|;:',.<>?/~`"
    encoded = encode_cyclic(special_chars)
    decoded = decode_cyclic(encoded)
    assert decoded == special_chars


def test_encode_unicode():
    unicode_str = "αβγδεζηθ"
    encoded = encode_cyclic(unicode_str)
    decoded = decode_cyclic(encoded)
    assert decoded == unicode_str


def test_encode_numbers():
    numbers = "0123456789"
    encoded = encode_cyclic(numbers)
    decoded = decode_cyclic(encoded)
    assert decoded == numbers


def test_encode_mixed_content():
    mixed = "Hello123!@#World456$%^"
    encoded = encode_cyclic(mixed)
    decoded = decode_cyclic(encoded)
    assert decoded == mixed


def test_encode_whitespace():
    whitespace = "  \t\n\r  "
    encoded = encode_cyclic(whitespace)
    decoded = decode_cyclic(encoded)
    assert decoded == whitespace


def test_long_string():
    long_str = "a" * 1000
    encoded = encode_cyclic(long_str)
    decoded = decode_cyclic(encoded)
    assert decoded == long_str