# Test cases for HumanEval/155
# Generated using Claude API


def even_odd_count(num):
    """Given an integer. return a tuple that has the number of even and odd digits respectively.

     Example:
        even_odd_count(-12) ==> (1, 1)
        even_odd_count(123) ==> (1, 2)
    """

    even_count = 0
    odd_count = 0
    for i in str(abs(num)):
        if int(i)%2==0:
            even_count +=1
        else:
            odd_count +=1
    return (even_count, odd_count)


# Generated test cases:
import pytest


@pytest.mark.parametrize("num,expected", [
    (123, (1, 2)),
    (246, (3, 0)),
    (135, (0, 3)),
    (0, (1, 0)),
    (1, (0, 1)),
    (2, (1, 0)),
    (-123, (1, 2)),
    (-246, (3, 0)),
    (-135, (0, 3)),
    (1234567890, (5, 5)),
    (-1234567890, (5, 5)),
    (2468, (4, 0)),
    (1357, (0, 4)),
    (10, (1, 1)),
    (100, (2, 1)),
    (1000, (3, 1)),
    (9999, (0, 4)),
    (8888, (4, 0)),
    (505050, (3, 3)),
    (-505050, (3, 3)),
    (11111, (0, 5)),
    (22222, (5, 0)),
    (-1, (0, 1)),
    (-10, (1, 1)),
    (987654321, (4, 5)),
    (-987654321, (4, 5))
])
def test_even_odd_count(num, expected):
    assert even_odd_count(num) == expected


def test_even_odd_count_single_digit():
    assert even_odd_count(0) == (1, 0)
    assert even_odd_count(1) == (0, 1)
    assert even_odd_count(2) == (1, 0)
    assert even_odd_count(3) == (0, 1)
    assert even_odd_count(4) == (1, 0)
    assert even_odd_count(5) == (0, 1)
    assert even_odd_count(6) == (1, 0)
    assert even_odd_count(7) == (0, 1)
    assert even_odd_count(8) == (1, 0)
    assert even_odd_count(9) == (0, 1)


def test_even_odd_count_negative_single_digit():
    assert even_odd_count(-1) == (0, 1)
    assert even_odd_count(-2) == (1, 0)
    assert even_odd_count(-3) == (0, 1)
    assert even_odd_count(-4) == (1, 0)
    assert even_odd_count(-5) == (0, 1)
    assert even_odd_count(-6) == (1, 0)
    assert even_odd_count(-7) == (0, 1)
    assert even_odd_count(-8) == (1, 0)
    assert even_odd_count(-9) == (0, 1)


def test_even_odd_count_large_numbers():
    assert even_odd_count(999999999) == (0, 9)
    assert even_odd_count(888888888) == (9, 0)
    assert even_odd_count(-999999999) == (0, 9)
    assert even_odd_count(-888888888) == (9, 0)


def test_even_odd_count_mixed_digits():
    assert even_odd_count(12345) == (2, 3)
    assert even_odd_count(54321) == (2, 3)
    assert even_odd_count(13579) == (0, 5)
    assert even_odd_count(24680) == (5, 0)