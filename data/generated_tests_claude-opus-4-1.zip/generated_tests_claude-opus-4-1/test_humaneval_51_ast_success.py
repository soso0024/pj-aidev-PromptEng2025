# Test cases for HumanEval/51
# Generated using Claude API



def remove_vowels(text):
    """
    remove_vowels is a function that takes string and returns string without vowels.
    >>> remove_vowels('')
    ''
    >>> remove_vowels("abcdef\nghijklm")
    'bcdf\nghjklm'
    >>> remove_vowels('abcdef')
    'bcdf'
    >>> remove_vowels('aaaaa')
    ''
    >>> remove_vowels('aaBAA')
    'B'
    >>> remove_vowels('zbcd')
    'zbcd'
    """

    return "".join([s for s in text if s.lower() not in ["a", "e", "i", "o", "u"]])


# Generated test cases:
import pytest

@pytest.mark.parametrize("text,expected", [
    ("", ""),
    ("a", ""),
    ("b", "b"),
    ("aeiou", ""),
    ("AEIOU", ""),
    ("bcdfg", "bcdfg"),
    ("Hello World", "Hll Wrld"),
    ("Python Programming", "Pythn Prgrmmng"),
    ("The quick brown fox", "Th qck brwn fx"),
    ("AEIOUaeiou", ""),
    ("12345", "12345"),
    ("!@#$%", "!@#$%"),
    ("Mix3d Ch@rs!", "Mx3d Ch@rs!"),
    ("   spaces   ", "   spcs   "),
    ("\n\t\r", "\n\t\r"),
    ("aAbBcCdDeEfF", "bBcCdDfF"),
    ("y is sometimes a vowel", "y s smtms  vwl"),
    ("UPPERCASE VOWELS", "PPRCS VWLS"),
    ("lowercase vowels", "lwrcs vwls"),
    ("MiXeD CaSe TeXt", "MXD CS TXt"),
    ("0123456789", "0123456789"),
    ("a1e2i3o4u5", "12345"),
    (".", "."),
    ("'quotes'", "'qts'"),
    ('"double quotes"', '"dbl qts"'),
    ("café", "cfé"),
    ("naïve", "nïv"),
    ("A" * 1000, ""),
    ("b" * 1000, "b" * 1000),
    ("abcdefghijklmnopqrstuvwxyz", "bcdfghjklmnpqrstvwxyz"),
    ("ABCDEFGHIJKLMNOPQRSTUVWXYZ", "BCDFGHJKLMNPQRSTVWXYZ"),
    ("The rain in Spain falls mainly on the plain", "Th rn n Spn flls mnly n th pln"),
])
def test_remove_vowels(text, expected):
    assert remove_vowels(text) == expected

def test_remove_vowels_type_preservation():
    result = remove_vowels("test")
    assert isinstance(result, str)

def test_remove_vowels_empty_string():
    assert remove_vowels("") == ""

def test_remove_vowels_no_vowels():
    assert remove_vowels("xyz") == "xyz"

def test_remove_vowels_all_vowels():
    assert remove_vowels("aeiouAEIOU") == ""