# Test cases for HumanEval/52
# Generated using Claude API



def below_threshold(l: list, t: int):
    """Return True if all numbers in the list l are below threshold t.
    >>> below_threshold([1, 2, 4, 10], 100)
    True
    >>> below_threshold([1, 20, 4, 10], 5)
    False
    """

    for e in l:
        if e >= t:
            return False
    return True


# Generated test cases:
import pytest


def below_threshold(l: list, t: int):
    for e in l:
        if e >= t:
            return False
    return True


@pytest.mark.parametrize("l,t,expected", [
    # Normal cases
    ([1, 2, 4, 10], 100, True),
    ([1, 20, 4, 10], 5, False),
    ([1, 2, 3, 4, 5], 6, True),
    ([1, 2, 3, 4, 5], 5, False),
    ([10, 20, 30], 40, True),
    ([10, 20, 30], 30, False),
    
    # Edge cases with threshold
    ([1, 2, 3], 4, True),
    ([1, 2, 4], 4, False),
    ([0, 0, 0], 1, True),
    ([0, 0, 0], 0, False),
    
    # Negative numbers
    ([-5, -3, -1], 0, True),
    ([-5, -3, -1], -2, False),
    ([-10, -20, -30], -5, True),
    ([-10, -20, -30], -30, False),
    
    # Mixed positive and negative
    ([-5, 0, 5], 10, True),
    ([-5, 0, 5], 5, False),
    ([-10, -5, 0, 5, 10], 11, True),
    ([-10, -5, 0, 5, 10], 10, False),
    
    # Empty list
    ([], 0, True),
    ([], 100, True),
    ([], -100, True),
    
    # Single element
    ([5], 10, True),
    ([5], 5, False),
    ([5], 4, False),
    ([0], 1, True),
    ([0], 0, False),
    ([-5], 0, True),
    ([-5], -5, False),
    
    # Large numbers
    ([999999], 1000000, True),
    ([1000000], 1000000, False),
    
    # Float numbers in list
    ([1.5, 2.5, 3.5], 4, True),
    ([1.5, 2.5, 3.5], 3.5, False),
    ([1.1, 2.2, 3.3], 3.3, False),
    
    # All same elements
    ([5, 5, 5, 5], 6, True),
    ([5, 5, 5, 5], 5, False),
])
def test_below_threshold(l, t, expected):
    assert below_threshold(l, t) == expected


def test_below_threshold_with_large_list():
    large_list = list(range(1000))
    assert below_threshold(large_list, 1000) == True
    assert below_threshold(large_list, 999) == False
    assert below_threshold(large_list, 500) == False


def test_below_threshold_type_consistency():
    # Test with different numeric types
    assert below_threshold([1, 2, 3], 4.0) == True
    assert below_threshold([1.0, 2.0, 3.0], 4) == True
    assert below_threshold([1, 2.0, 3], 3.0) == False
