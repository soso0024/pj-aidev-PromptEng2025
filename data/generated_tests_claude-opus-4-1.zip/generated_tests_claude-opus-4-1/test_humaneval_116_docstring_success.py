# Test cases for HumanEval/116
# Generated using Claude API


def sort_array(arr):
    """
    In this Kata, you have to sort an array of non-negative integers according to
    number of ones in their binary representation in ascending order.
    For similar number of ones, sort based on decimal value.

    It must be implemented like this:
    >>> sort_array([1, 5, 2, 3, 4]) == [1, 2, 3, 4, 5]
    >>> sort_array([-2, -3, -4, -5, -6]) == [-6, -5, -4, -3, -2]
    >>> sort_array([1, 0, 2, 3, 4]) [0, 1, 2, 3, 4]
    """

    return sorted(sorted(arr), key=lambda x: bin(x)[2:].count('1'))


# Generated test cases:
import pytest

def sort_array(arr):
    return sorted(sorted(arr), key=lambda x: bin(x)[2:].count('1'))

@pytest.mark.parametrize("input_arr,expected", [
    ([1, 5, 2, 3, 4], [1, 2, 4, 3, 5]),
    ([1, 0, 2, 3, 4], [0, 1, 2, 4, 3]),
    ([], []),
    ([0], [0]),
    ([1], [1]),
    ([0, 0, 0], [0, 0, 0]),
    ([1, 1, 1], [1, 1, 1]),
    ([7, 7, 7], [7, 7, 7]),
    ([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10], [0, 1, 2, 4, 8, 3, 5, 6, 9, 10, 7]),
    ([15, 7, 3, 1], [1, 3, 7, 15]),
    ([31, 15, 7, 3, 1], [1, 3, 7, 15, 31]),
    ([255, 127, 63, 31, 15, 7, 3, 1, 0], [0, 1, 3, 7, 15, 31, 63, 127, 255]),
    ([2, 4, 8, 16, 32, 64, 128], [2, 4, 8, 16, 32, 64, 128]),
    ([3, 5, 6, 9, 10, 12], [3, 5, 6, 9, 10, 12]),
    ([100, 200, 300, 400, 500], [100, 200, 400, 300, 500]),
    ([1024, 512, 256, 128, 64, 32, 16, 8, 4, 2, 1], [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024]),
    ([10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0], [0, 1, 2, 4, 8, 3, 5, 6, 9, 10, 7]),
    ([1000000], [1000000]),
    ([1023, 511, 255, 127, 63, 31, 15, 7, 3, 1, 0], [0, 1, 3, 7, 15, 31, 63, 127, 255, 511, 1023]),
])
def test_sort_array(input_arr, expected):
    assert sort_array(input_arr) == expected

def test_sort_array_preserves_original():
    original = [5, 3, 1, 4, 2]
    copy = original.copy()
    result = sort_array(original)
    assert original == copy

def test_sort_array_large_numbers():
    arr = [2**20, 2**20 - 1, 2**10, 2**10 - 1]
    result = sort_array(arr)
    assert result == [2**10, 2**20, 2**10 - 1, 2**20 - 1]

def test_sort_array_duplicates():
    arr = [5, 5, 3, 3, 1, 1]
    result = sort_array(arr)
    assert result == [1, 1, 3, 3, 5, 5]

def test_sort_array_already_sorted():
    arr = [0, 1, 2, 4, 8]
    result = sort_array(arr)
    assert result == [0, 1, 2, 4, 8]

def test_sort_array_reverse_sorted():
    arr = [7, 3, 1, 0]
    result = sort_array(arr)
    assert result == [0, 1, 3, 7]

def test_sort_array_same_bit_count():
    arr = [3, 5, 6, 9, 10, 12]
    result = sort_array(arr)
    assert result == [3, 5, 6, 9, 10, 12]

def test_sort_array_powers_of_two():
    arr = [1, 2, 4, 8, 16, 32]
    result = sort_array(arr)
    assert result == [1, 2, 4, 8, 16, 32]

def test_sort_array_all_ones_in_binary():
    arr = [1, 3, 7, 15, 31, 63]
    result = sort_array(arr)
    assert result == [1, 3, 7, 15, 31, 63]