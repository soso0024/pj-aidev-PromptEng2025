# Test cases for HumanEval/108
# Generated using Claude API


def count_nums(arr):
    """
    Write a function count_nums which takes an array of integers and returns
    the number of elements which has a sum of digits > 0.
    If a number is negative, then its first signed digit will be negative:
    e.g. -123 has signed digits -1, 2, and 3.
    >>> count_nums([]) == 0
    >>> count_nums([-1, 11, -11]) == 1
    >>> count_nums([1, 1, 2]) == 3
    """

    def digits_sum(n):
        neg = 1
        if n < 0: n, neg = -1 * n, -1 
        n = [int(i) for i in str(n)]
        n[0] = n[0] * neg
        return sum(n)
    return len(list(filter(lambda x: x > 0, [digits_sum(i) for i in arr])))


# Generated test cases:
import pytest

@pytest.mark.parametrize("arr,expected", [
    # Empty array
    ([], 0),
    
    # Single element arrays
    ([0], 0),
    ([1], 1),
    ([-1], 0),
    ([10], 1),
    ([-10], 0),
    
    # Examples from docstring
    ([-1, 11, -11], 1),
    ([1, 1, 2], 3),
    
    # All positive numbers
    ([1, 2, 3, 4, 5], 5),
    ([10, 20, 30], 3),
    ([100, 200, 300], 3),
    
    # All negative numbers
    ([-1, -2, -3, -4, -5], 0),
    ([-10, -20, -30], 0),
    ([-100, -200, -300], 0),
    
    # Mixed positive and negative
    ([1, -1, 2, -2, 3, -3], 3),
    ([10, -10, 20, -20], 2),
    
    # Numbers with digit sum = 0
    ([-12, -21, -111], 2),  # -12: -1+2=1, -21: -2+1=-1, -111: -1+1+1=1
    ([12, 21, 111], 3),
    
    # Large numbers
    ([123456789], 1),
    ([-123456789], 1),
    ([999999999], 1),
    ([-999999999], 1),
    
    # Numbers where negative first digit dominates
    ([-99], 0),  # -9 + 9 = 0
    ([-98], 0),  # -9 + 8 = -1
    ([-91], 0),  # -9 + 1 = -8
    ([-19], 1),  # -1 + 9 = 8
    
    # Edge cases with specific digit sums
    ([-100], 0),  # -1 + 0 + 0 = -1
    ([-101], 0),  # -1 + 0 + 1 = 0
    ([-102], 1),  # -1 + 0 + 2 = 1
    
    # Multiple same values
    ([1, 1, 1, 1, 1], 5),
    ([-1, -1, -1, -1], 0),
    ([0, 0, 0, 0], 0),
    
    # Numbers with many zeros
    ([1000, 10000, 100000], 3),
    ([-1000, -10000, -100000], 0),
    
    # Two digit negatives
    ([-10, -11, -12, -13, -14, -15, -16, -17, -18, -19], 8),  # -10: 0, -11: 0, -12: 1, -13: 2, -14: 3, -15: 4, -16: 5, -17: 6, -18: 7, -19: 8
    ([-20, -21, -22, -23, -24, -25, -26, -27, -28, -29], 7),  # -20: 0, -21: -1, -22: 0, -23: 1, -24: 2, -25: 3, -26: 4, -27: 5, -28: 6, -29: 7
    
    # Special cases
    ([11, -11], 1),  # 11: 1+1=2, -11: -1+1=0
    ([22, -22], 1),  # 22: 2+2=4, -22: -2+2=0
    ([33, -33], 1),  # 33: 3+3=6, -33: -3+3=0
    
    # Numbers where sum is exactly 0
    ([-11, -22, -33, -44, -55, -66, -77, -88, -99], 0),
])
def test_count_nums(arr, expected):
    assert count_nums(arr) == expected


def test_count_nums_large_array():
    # Test with a large array
    arr = list(range(-1000, 1001))
    result = count_nums(arr)
    assert result > 0
    assert result <= len(arr)


def test_count_nums_all_zeros():
    arr = [0] * 100
    assert count_nums(arr) == 0


def test_count_nums_alternating():
    arr = []
    for i in range(1, 51):
        arr.append(i)
        arr.append(-i)
    result = count_nums(arr)
    # Positive numbers 1-50 all have positive digit sums
    # Negative numbers: some have positive sums, some don't
    # -1 to -9: all negative sums
    # -10 to -19: -10=0, -11=0, -12=1, -13=2, -14=3, -15=4, -16=5, -17=6, -18=7, -19=8 (8 positive)
    # -20 to -29: -20=0, -21=-1, -22=0, -23=1, -24=2, -25=3, -26=4, -27=5, -28=6, -29=7 (7 positive)
    # -30 to -39: -30=0, -31=-2, -32=-1, -33=0, -34=1, -35=2, -36=3, -37=4, -38=5, -39=6 (6 positive)
    # -40 to -49: -40=0, -41=-3, -42=-2, -43=-1, -44=0, -45=1, -46=2, -47=3, -48=4, -49=5 (5 positive)
    # -50: -5+0=-5 (0 positive)
    # Total: 50 + 8 + 7 + 6 + 5 = 76
    assert result == 76