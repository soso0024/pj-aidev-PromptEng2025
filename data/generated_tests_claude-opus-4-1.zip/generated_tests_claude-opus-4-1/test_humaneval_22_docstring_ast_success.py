# Test cases for HumanEval/22
# Generated using Claude API

from typing import List, Any


def filter_integers(values: List[Any]) -> List[int]:
    """ Filter given list of any python values only for integers
    >>> filter_integers(['a', 3.14, 5])
    [5]
    >>> filter_integers([1, 2, 3, 'abc', {}, []])
    [1, 2, 3]
    """

    return [x for x in values if isinstance(x, int)]


# Generated test cases:
import pytest
from typing import List, Any


def filter_integers(values: List[Any]) -> List[int]:
    return [x for x in values if isinstance(x, int)]


@pytest.mark.parametrize("values,expected", [
    # Basic test cases from docstring
    (['a', 3.14, 5], [5]),
    ([1, 2, 3, 'abc', {}, []], [1, 2, 3]),
    
    # Empty list
    ([], []),
    
    # Only integers
    ([1, 2, 3, 4, 5], [1, 2, 3, 4, 5]),
    ([0, -1, -2, 100, -100], [0, -1, -2, 100, -100]),
    
    # No integers
    (['a', 'b', 'c'], []),
    ([3.14, 2.71, 1.41], []),
    ([[], {}, (), set()], []),
    
    # Mixed types
    ([1, '2', 3.0, 4, None], [1, 4]),
    ([True, False, 1, 0], [True, False, 1, 0]),  # bool is subclass of int
    
    # Complex data structures
    ([{'a': 1}, [1, 2], (1, 2), {1, 2}], []),
    
    # Special numeric values
    ([float('inf'), float('-inf'), float('nan')], []),
    
    # Large numbers
    ([10**100, -10**100, 2**64], [10**100, -10**100, 2**64]),
    
    # Mixed with None
    ([None, 1, None, 2, None], [1, 2]),
    
    # Complex numbers
    ([1+2j, 3+4j, 5], [5]),
    
    # Strings that look like numbers
    (['1', '2', '3', 1, 2], [1, 2]),
    
    # Single element lists
    ([1], [1]),
    ([3.14], []),
    (['string'], []),
    
    # Nested lists with integers
    ([[1, 2], [3, 4], 5], [5]),
    
    # Class instances and functions
    ([lambda x: x, filter_integers, 42], [42]),
])
def test_filter_integers(values, expected):
    assert filter_integers(values) == expected


def test_filter_integers_preserves_order():
    assert filter_integers([3, 1, 4, 1, 5, 9, 2, 6]) == [3, 1, 4, 1, 5, 9, 2, 6]


def test_filter_integers_preserves_duplicates():
    assert filter_integers([1, 1, 1, 'a', 1, 1]) == [1, 1, 1, 1, 1]


def test_filter_integers_with_zero():
    assert filter_integers([0, 0.0, '0', False]) == [0, False]


def test_filter_integers_negative_zero():
    assert filter_integers([-0, 0, -0.0, 0.0]) == [-0, 0]
