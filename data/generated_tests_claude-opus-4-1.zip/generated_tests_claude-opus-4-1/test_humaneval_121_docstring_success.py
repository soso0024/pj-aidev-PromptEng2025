# Test cases for HumanEval/121
# Generated using Claude API


def solution(lst):
    """Given a non-empty list of integers, return the sum of all of the odd elements that are in even positions.
    

    Examples
    solution([5, 8, 7, 1]) ==> 12
    solution([3, 3, 3, 3, 3]) ==> 9
    solution([30, 13, 24, 321]) ==>0
    """

    return sum([x for idx, x in enumerate(lst) if idx%2==0 and x%2==1])


# Generated test cases:
import pytest

def solution(lst):
    return sum([x for idx, x in enumerate(lst) if idx%2==0 and x%2==1])

@pytest.mark.parametrize("lst,expected", [
    ([5, 8, 7, 1], 12),
    ([3, 3, 3, 3, 3], 9),
    ([30, 13, 24, 321], 0),
    ([1], 1),
    ([2], 0),
    ([1, 2], 1),
    ([2, 1], 0),
    ([1, 2, 3], 4),
    ([1, 2, 3, 4], 4),
    ([1, 2, 3, 4, 5], 9),
    ([2, 2, 2, 2], 0),
    ([1, 1, 1, 1], 2),
    ([7, 4, 9, 2, 11], 27),
    ([0, 1, 0, 3, 0], 0),
    ([-1, 2, -3, 4, -5], -9),
    ([-2, -4, -6, -8], 0),
    ([11, 22, 33, 44, 55], 99),
    ([100, 101, 102, 103], 0),
    ([101, 100, 103, 102, 105], 309),
    ([999, 1000, 1001, 1002, 1003], 3003),
    ([1, 0, 1, 0, 1], 3),
    ([0, 0, 0, 0, 1], 1),
    ([-1, -2, -3, -4, -5], -9),
    ([13], 13),
    ([14], 0),
    ([1, 3, 5, 7, 9, 11], 15),
    ([2, 4, 6, 8, 10, 12], 0),
])
def test_solution(lst, expected):
    assert solution(lst) == expected

def test_solution_large_list():
    lst = [1] * 1000
    assert solution(lst) == 500
    
def test_solution_alternating():
    lst = [1, 2] * 50
    assert solution(lst) == 50
    
def test_solution_all_odd():
    lst = [1, 3, 5, 7, 9]
    assert solution(lst) == 15
    
def test_solution_all_even():
    lst = [2, 4, 6, 8, 10]
    assert solution(lst) == 0