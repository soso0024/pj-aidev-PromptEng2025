# Test cases for HumanEval/53
# Generated using Claude API



def add(x: int, y: int):
    """Add two numbers x and y
    >>> add(2, 3)
    5
    >>> add(5, 7)
    12
    """

    return x + y


# Generated test cases:
import pytest

def add(x: int, y: int):
    return x + y

class TestAdd:
    @pytest.mark.parametrize("x,y,expected", [
        (1, 2, 3),
        (0, 0, 0),
        (-1, -1, -2),
        (100, 200, 300),
        (-5, 5, 0),
        (10, -10, 0),
        (-10, 20, 10),
        (999999, 1, 1000000),
        (1, 999999, 1000000),
    ])
    def test_add_normal_cases(self, x, y, expected):
        assert add(x, y) == expected

    def test_add_positive_numbers(self):
        assert add(5, 3) == 8
        assert add(100, 50) == 150
        assert add(1, 1) == 2

    def test_add_negative_numbers(self):
        assert add(-5, -3) == -8
        assert add(-100, -50) == -150
        assert add(-1, -1) == -2

    def test_add_mixed_sign_numbers(self):
        assert add(-5, 10) == 5
        assert add(10, -5) == 5
        assert add(-100, 50) == -50
        assert add(50, -100) == -50

    def test_add_with_zero(self):
        assert add(0, 5) == 5
        assert add(5, 0) == 5
        assert add(0, -5) == -5
        assert add(-5, 0) == -5

    def test_add_large_numbers(self):
        assert add(2147483647, 0) == 2147483647
        assert add(-2147483648, 0) == -2147483648
        assert add(1000000000, 1000000000) == 2000000000

    def test_add_commutative_property(self):
        assert add(7, 3) == add(3, 7)
        assert add(-5, 10) == add(10, -5)
        assert add(0, 100) == add(100, 0)
