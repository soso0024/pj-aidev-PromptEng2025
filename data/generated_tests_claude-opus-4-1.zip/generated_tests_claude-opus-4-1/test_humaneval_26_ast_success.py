# Test cases for HumanEval/26
# Generated using Claude API

from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    """ From a list of integers, remove all elements that occur more than once.
    Keep order of elements left the same as in the input.
    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """

    import collections
    c = collections.Counter(numbers)
    return [n for n in numbers if c[n] <= 1]


# Generated test cases:
import pytest
from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    import collections
    c = collections.Counter(numbers)
    return [n for n in numbers if c[n] <= 1]


@pytest.mark.parametrize("numbers,expected", [
    ([], []),
    ([1], [1]),
    ([1, 2, 3], [1, 2, 3]),
    ([1, 1, 2, 3], [2, 3]),
    ([1, 2, 2, 3], [1, 3]),
    ([1, 2, 3, 3], [1, 2]),
    ([1, 1, 1], []),
    ([1, 2, 1, 3, 2], [3]),
    ([1, 1, 2, 2, 3, 3], []),
    ([5, 4, 3, 2, 1], [5, 4, 3, 2, 1]),
    ([1, 2, 3, 4, 5, 1, 2, 3], [4, 5]),
    ([0], [0]),
    ([0, 0], []),
    ([-1, -2, -3], [-1, -2, -3]),
    ([-1, -1, -2], [-2]),
    ([1, -1, 1, -1], []),
    ([100, 200, 100, 300], [200, 300]),
    ([1, 2, 3, 2, 4, 3, 5], [1, 4, 5]),
    ([7, 7, 7, 7], []),
    ([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]),
    ([10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 1], [10, 9, 8, 7, 6, 5, 4, 3, 2]),
])
def test_remove_duplicates(numbers, expected):
    assert remove_duplicates(numbers) == expected


def test_remove_duplicates_preserves_order():
    assert remove_duplicates([3, 1, 2, 1, 4]) == [3, 2, 4]
    assert remove_duplicates([5, 3, 5, 2, 1]) == [3, 2, 1]


def test_remove_duplicates_with_multiple_duplicates():
    assert remove_duplicates([1, 1, 1, 2, 2, 3]) == [3]
    assert remove_duplicates([5, 5, 5, 5, 5]) == []


def test_remove_duplicates_large_numbers():
    assert remove_duplicates([1000000, 999999, 1000000]) == [999999]
    assert remove_duplicates([2**31 - 1, 2**31 - 1]) == []


def test_remove_duplicates_negative_numbers():
    assert remove_duplicates([-5, -10, -5, -15]) == [-10, -15]
    assert remove_duplicates([-1, -2, -3, -1, -2, -3]) == []


def test_remove_duplicates_mixed_positive_negative():
    assert remove_duplicates([1, -1, 2, -2, 1]) == [-1, 2, -2]
    assert remove_duplicates([0, -0, 1, -1]) == [1, -1]


def test_remove_duplicates_does_not_modify_input():
    original = [1, 2, 1, 3]
    result = remove_duplicates(original)
    assert original == [1, 2, 1, 3]
    assert result == [2, 3]