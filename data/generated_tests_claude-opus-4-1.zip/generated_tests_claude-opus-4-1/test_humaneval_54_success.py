# Test cases for HumanEval/54
# Generated using Claude API



def same_chars(s0: str, s1: str):
    """
    Check if two words have the same characters.
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddeddabc')
    True
    >>> same_chars('abcd', 'dddddddabc')
    True
    >>> same_chars('dddddddabc', 'abcd')
    True
    >>> same_chars('eabcd', 'dddddddabc')
    False
    >>> same_chars('abcd', 'dddddddabce')
    False
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddddabc')
    False
    """

    return set(s0) == set(s1)


# Generated test cases:
import pytest


def same_chars(s0: str, s1: str):
    return set(s0) == set(s1)


@pytest.mark.parametrize("s0,s1,expected", [
    # Same characters, same order
    ("abc", "abc", True),
    ("hello", "hello", True),
    
    # Same characters, different order
    ("abc", "bca", True),
    ("abc", "cab", True),
    ("listen", "silent", True),
    ("elbow", "below", True),
    
    # Same characters with repetitions
    ("aabbcc", "abc", True),
    ("aaabbbccc", "cba", True),
    ("aaa", "a", True),
    ("aaabbb", "ab", True),
    
    # Different characters
    ("abc", "def", False),
    ("hello", "world", False),
    ("abc", "abcd", False),
    ("abcd", "abc", False),
    
    # Empty strings
    ("", "", True),
    ("", "a", False),
    ("a", "", False),
    
    # Single characters
    ("a", "a", True),
    ("a", "b", False),
    ("aaa", "a", True),
    
    # Special characters
    ("!@#", "!@#", True),
    ("!@#", "#@!", True),
    ("abc123", "321cba", True),
    ("abc123", "abc124", False),
    
    # Spaces and whitespace
    ("a b c", "c b a", True),
    ("a b c", "abc", False),
    ("   ", " ", True),
    ("abc ", " abc", True),
    
    # Case sensitivity
    ("ABC", "abc", False),
    ("Abc", "Abc", True),
    ("AaBbCc", "CcBbAa", True),
    
    # Numbers as strings
    ("123", "321", True),
    ("123", "124", False),
    ("111222333", "123", True),
    
    # Unicode characters
    ("café", "éfac", True),
    ("你好", "好你", True),
    ("αβγ", "γβα", True),
    
    # Long strings with same chars
    ("abcdefghijklmnopqrstuvwxyz", "zyxwvutsrqponmlkjihgfedcba", True),
    ("aabbccddeeffgghhiijjkkllmmnnooppqqrrssttuuvvwwxxyyzz", "abcdefghijklmnopqrstuvwxyz", True),
])
def test_same_chars(s0, s1, expected):
    assert same_chars(s0, s1) == expected


def test_same_chars_commutative():
    # Test that the function is commutative
    assert same_chars("abc", "bca") == same_chars("bca", "abc")
    assert same_chars("hello", "world") == same_chars("world", "hello")
    assert same_chars("", "a") == same_chars("a", "")
