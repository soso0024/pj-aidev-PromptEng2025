# Test cases for HumanEval/57
# Generated using Claude API



def monotonic(l: list):
    """Return True is list elements are monotonically increasing or decreasing.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """

    if l == sorted(l) or l == sorted(l, reverse=True):
        return True
    return False


# Generated test cases:
import pytest

@pytest.mark.parametrize("input_list,expected", [
    # Increasing sequences
    ([1, 2, 4, 20], True),
    ([0, 1, 2, 3, 4, 5], True),
    ([-10, -5, 0, 5, 10], True),
    ([1, 1, 2, 2, 3, 3], True),
    
    # Decreasing sequences
    ([4, 1, 0, -10], True),
    ([100, 50, 25, 10, 5], True),
    ([10, 5, 0, -5, -10], True),
    ([3, 3, 2, 2, 1, 1], True),
    
    # Non-monotonic sequences
    ([1, 20, 4, 10], False),
    ([1, 3, 2, 4], False),
    ([5, 1, 3, 2], False),
    ([1, 2, 1, 2], False),
    
    # Edge cases
    ([], True),  # Empty list
    ([1], True),  # Single element
    ([5, 5], True),  # Two equal elements
    ([1, 1, 1, 1, 1], True),  # All equal elements
    
    # Float values
    ([1.1, 2.2, 3.3, 4.4], True),
    ([4.4, 3.3, 2.2, 1.1], True),
    ([1.1, 3.3, 2.2], False),
    
    # Mixed positive and negative
    ([-3, -2, -1, 0, 1, 2, 3], True),
    ([3, 2, 1, 0, -1, -2, -3], True),
    ([-1, 2, -3, 4], False),
    
    # Large numbers
    ([1000000, 2000000, 3000000], True),
    ([3000000, 2000000, 1000000], True),
    
    # Two elements
    ([1, 2], True),
    ([2, 1], True),
    
    # Duplicate values in sequence
    ([1, 2, 2, 3, 4], True),
    ([4, 3, 3, 2, 1], True),
    ([1, 2, 2, 1], False),
])
def test_monotonic(input_list, expected):
    assert monotonic(input_list) == expected

def test_monotonic_large_list():
    # Test with large increasing list
    large_increasing = list(range(10000))
    assert monotonic(large_increasing) == True
    
    # Test with large decreasing list
    large_decreasing = list(range(10000, 0, -1))
    assert monotonic(large_decreasing) == True
    
    # Test with large non-monotonic list
    large_non_monotonic = list(range(5000)) + list(range(5000, 0, -1))
    assert monotonic(large_non_monotonic) == False