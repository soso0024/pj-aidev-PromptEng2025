# Test cases for HumanEval/36
# Generated using Claude API



def fizz_buzz(n: int):
    """Return the number of times the digit 7 appears in integers less than n which are divisible by 11 or 13.
    >>> fizz_buzz(50)
    0
    >>> fizz_buzz(78)
    2
    >>> fizz_buzz(79)
    3
    """

    ns = []
    for i in range(n):
        if i % 11 == 0 or i % 13 == 0:
            ns.append(i)
    s = ''.join(list(map(str, ns)))
    ans = 0
    for c in s:
        ans += (c == '7')
    return ans


# Generated test cases:
import pytest


def fizz_buzz(n: int):
    ns = []
    for i in range(n):
        if i % 11 == 0 or i % 13 == 0:
            ns.append(i)
    s = ''.join(list(map(str, ns)))
    ans = 0
    for c in s:
        ans += (c == '7')
    return ans


@pytest.mark.parametrize("n,expected", [
    (50, 0),
    (78, 2),
    (79, 3),
    (0, 0),
    (1, 0),
    (11, 0),
    (12, 0),
    (13, 0),
    (14, 0),
    (77, 0),
    (78, 2),
    (79, 3),
    (100, 3),
    (150, 4),
    (200, 6),
    (300, 10),
    (500, 15),
    (1000, 47),
    (70, 0),
    (71, 0),
    (72, 0),
    (73, 0),
    (74, 0),
    (75, 0),
    (76, 0),
    (77, 0),
    (78, 2),
    (79, 3),
    (80, 3),
    (170, 4),
    (171, 4),
    (172, 4),
    (173, 4),
    (174, 4),
    (175, 4),
    (176, 4),
    (177, 5),
    (178, 5),
    (179, 5),
    (180, 5),
    (270, 7),
    (271, 7),
    (272, 7),
    (273, 7),
    (274, 8),
    (275, 8),
    (276, 9),
    (277, 9),
    (278, 9),
    (279, 9),
    (280, 9),
])
def test_fizz_buzz(n, expected):
    assert fizz_buzz(n) == expected


def test_fizz_buzz_negative():
    assert fizz_buzz(-1) == 0
    assert fizz_buzz(-10) == 0
    assert fizz_buzz(-100) == 0


def test_fizz_buzz_large_numbers():
    result = fizz_buzz(2000)
    assert isinstance(result, int)
    assert result >= 0


def test_fizz_buzz_specific_divisible_numbers():
    # Test that 77 (divisible by 11) contributes two 7s
    assert fizz_buzz(78) - fizz_buzz(77) == 2
    
    # Test that 78 (divisible by 13) contributes one 7
    assert fizz_buzz(79) - fizz_buzz(78) == 1
    
    # Test numbers with multiple 7s
    # 377 is divisible by 13 and has two 7s
    before_377 = fizz_buzz(377)
    after_377 = fizz_buzz(378)
    assert after_377 >= before_377 + 2
    
    # 770 is divisible by 11 and has two 7s  
    before_770 = fizz_buzz(770)
    after_770 = fizz_buzz(771)
    assert after_770 >= before_770 + 2


def test_fizz_buzz_boundary_cases():
    # Test around multiples of 11
    assert fizz_buzz(22) == 0
    assert fizz_buzz(23) == 0
    assert fizz_buzz(33) == 0
    assert fizz_buzz(34) == 0
    
    # Test around multiples of 13
    assert fizz_buzz(26) == 0
    assert fizz_buzz(27) == 0
    assert fizz_buzz(39) == 0
    assert fizz_buzz(40) == 0