# Test cases for HumanEval/158
# Generated using Claude API


def find_max(words):
    """Write a function that accepts a list of strings.
    The list contains different words. Return the word with maximum number
    of unique characters. If multiple strings have maximum number of unique
    characters, return the one which comes first in lexicographical order.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb" ,"cc"]) == ""aaaaaaa"
    """

    return sorted(words, key = lambda x: (-len(set(x)), x))[0]


# Generated test cases:
import pytest

def find_max(words):
    return sorted(words, key = lambda x: (-len(set(x)), x))[0]


@pytest.mark.parametrize("words,expected", [
    (["name", "of", "string"], "string"),
    (["name", "enam", "game"], "enam"),
    (["aaaaaaa", "bb", "cc"], "aaaaaaa"),
    (["a"], "a"),
    (["abc", "def", "ghi"], "abc"),
    (["aaa", "bbb", "ccc"], "aaa"),
    (["abcd", "efgh", "ijkl"], "abcd"),
    (["hello", "world"], "world"),
    (["python", "java", "c++"], "python"),
    (["test", "best", "rest"], "best"),
    (["xyz", "abc", "def"], "abc"),
    (["abcdef", "ghijkl", "mnopqr"], "abcdef"),
    (["a", "ab", "abc", "abcd"], "abcd"),
    (["abcd", "abc", "ab", "a"], "abcd"),
    (["zzz", "aaa", "bbb"], "aaa"),
    (["12345", "67890", "abcde"], "12345"),
    (["!@#$%", "^&*()", "qwert"], "!@#$%"),
    ([""], ""),
    (["", "a"], "a"),
    (["a", ""], "a"),
    (["aabbcc", "abc", "def"], "aabbcc"),
    (["mississippi", "hello", "world"], "world"),
    (["aaa", "aaab", "aabc"], "aabc"),
    (["xyz", "xyzw", "xyzwv"], "xyzwv"),
    (["abcdefg", "hijklmn", "opqrstu"], "abcdefg"),
    (["aba", "cdc", "efe"], "aba"),
    (["abcde", "fghij", "abcde"], "abcde"),
    (["z", "y", "x", "w", "v"], "v"),
    (["aa", "bb", "ab", "ba"], "ab"),
    (["123", "456", "789", "147"], "123"),
    (["aabbccdd", "abcd", "efgh"], "aabbccdd"),
    (["programming", "python", "code"], "programming"),
    (["test123", "test456", "test789"], "test123"),
    (["AAA", "BBB", "ABC"], "ABC"),
    (["aA", "bB", "cC"], "aA"),
    (["!!", "@@", "!@"], "!@"),
    (["   ", "  a", " ab"], " ab"),
    (["xyz", "zyx", "yxz"], "xyz"),
])
def test_find_max(words, expected):
    assert find_max(words) == expected


def test_find_max_empty_list():
    with pytest.raises(IndexError):
        find_max([])


def test_find_max_single_empty_string():
    assert find_max([""]) == ""


def test_find_max_multiple_empty_strings():
    assert find_max(["", "", ""]) == ""


def test_find_max_special_characters():
    assert find_max(["!@#", "$%^", "&*()"]) == "&*()"


def test_find_max_numbers_as_strings():
    assert find_max(["111", "222", "123"]) == "123"


def test_find_max_mixed_case():
    assert find_max(["ABC", "abc", "AbC"]) == "ABC"


def test_find_max_unicode():
    assert find_max(["café", "naïve", "résumé"]) == "naïve"


def test_find_max_long_strings():
    assert find_max(["a" * 1000, "b" * 1000, "abcdefghij"]) == "abcdefghij"


def test_find_max_duplicate_words():
    assert find_max(["test", "test", "test"]) == "test"


def test_find_max_whitespace():
    assert find_max([" ", "\t", "\n"]) == "\t"