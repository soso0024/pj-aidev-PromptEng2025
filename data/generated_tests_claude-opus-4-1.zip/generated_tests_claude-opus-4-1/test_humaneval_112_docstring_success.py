# Test cases for HumanEval/112
# Generated using Claude API


def reverse_delete(s,c):
    """Task
    We are given two strings s and c, you have to deleted all the characters in s that are equal to any character in c
    then check if the result string is palindrome.
    A string is called palindrome if it reads the same backward as forward.
    You should return a tuple containing the result string and True/False for the check.
    Example
    For s = "abcde", c = "ae", the result should be ('bcd',False)
    For s = "abcdef", c = "b"  the result should be ('acdef',False)
    For s = "abcdedcba", c = "ab", the result should be ('cdedc',True)
    """

    s = ''.join([char for char in s if char not in c])
    return (s,s[::-1] == s)


# Generated test cases:
import pytest

def reverse_delete(s,c):
    s = ''.join([char for char in s if char not in c])
    return (s,s[::-1] == s)

@pytest.mark.parametrize("s,c,expected", [
    ("abcde", "ae", ("bcd", False)),
    ("abcdef", "b", ("acdef", False)),
    ("abcdedcba", "ab", ("cdedc", True)),
    ("", "", ("", True)),
    ("", "abc", ("", True)),
    ("abc", "", ("abc", False)),
    ("a", "a", ("", True)),
    ("aa", "a", ("", True)),
    ("aba", "b", ("aa", True)),
    ("racecar", "e", ("raccar", True)),
    ("racecar", "rc", ("aea", True)),
    ("12321", "13", ("22", True)),
    ("12321", "2", ("131", True)),
    ("abcba", "xyz", ("abcba", True)),
    ("abcba", "b", ("aca", True)),
    ("abcba", "ac", ("bb", True)),
    ("hello", "l", ("heo", False)),
    ("aaaaaa", "a", ("", True)),
    ("abcdefg", "abcdefg", ("", True)),
    ("AbCdEfG", "ACE", ("bdfG", False)),
    ("123454321", "5", ("12344321", True)),
    ("123454321", "4", ("1235321", True)),
    ("123454321", "45", ("123321", True)),
    ("   ", " ", ("", True)),
    ("a b c b a", " ", ("abcba", True)),
    ("!@#$%", "!#%", ("@$", False)),
    ("xyzzyx", "z", ("xyyx", True)),
    ("xyzzyx", "x", ("yzzy", True)),
    ("xyzzyx", "y", ("xzzx", True)),
    ("abcdefghijklmnop", "aeiou", ("bcdfghjklmnp", False)),
    ("aaa", "b", ("aaa", True)),
    ("aba", "c", ("aba", True)),
    ("abcdefedcba", "f", ("abcdeedcba", True)),
    ("abcdefedcba", "abcdef", ("", True)),
    ("x", "x", ("", True)),
    ("x", "y", ("x", True)),
    ("xy", "x", ("y", True)),
    ("xy", "y", ("x", True)),
    ("xyx", "x", ("y", True)),
    ("xyx", "y", ("xx", True))
])
def test_reverse_delete(s, c, expected):
    assert reverse_delete(s, c) == expected

def test_reverse_delete_empty_strings():
    assert reverse_delete("", "") == ("", True)

def test_reverse_delete_no_chars_to_delete():
    assert reverse_delete("hello", "xyz") == ("hello", False)

def test_reverse_delete_all_chars_deleted():
    assert reverse_delete("aaa", "a") == ("", True)

def test_reverse_delete_single_char_palindrome():
    assert reverse_delete("abcba", "bcb") == ("aa", True)

def test_reverse_delete_case_sensitive():
    assert reverse_delete("AaBbCc", "abc") == ("ABC", False)