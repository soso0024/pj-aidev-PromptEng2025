# Test cases for HumanEval/85
# Generated using Claude API


def add(lst):
    """Given a non-empty list of integers lst. add the even elements that are at odd indices..


    Examples:
        add([4, 2, 6, 7]) ==> 2 
    """

    return sum([lst[i] for i in range(1, len(lst), 2) if lst[i]%2 == 0])


# Generated test cases:
import pytest

@pytest.mark.parametrize("lst,expected", [
    ([4, 2, 6, 7], 2),
    ([1, 2, 3, 4], 6),
    ([1, 2, 3, 4, 5, 6], 8),
    ([0], 0),
    ([1, 0], 0),
    ([2, 3], 0),
    ([1, 4], 4),
    ([1, 3, 5, 7], 0),
    ([2, 4, 6, 8], 12),
    ([1, 2, 3, 4, 5, 6, 7, 8], 20),
    ([10, 20, 30, 40, 50, 60], 120),
    ([1], 0),
    ([2, 2], 2),
    ([1, 1, 1, 2], 2),
    ([5, 8, 7, 10, 9, 12], 30),
    ([-1, -2, -3, -4], -6),
    ([0, 0, 0, 0], 0),
    ([1, 0, 3, 0, 5, 0], 0),
    ([-2, -4, -6, -8], -12),
    ([100, 200, 300, 400], 600),
    ([1, 2, 3], 2),
    ([11, 22, 33, 44, 55, 66], 132),
    ([7, 14, 21, 28], 42),
    ([9, 10, 11, 12, 13, 14], 36),
])
def test_add(lst, expected):
    assert add(lst) == expected

def test_add_single_element():
    assert add([5]) == 0
    assert add([4]) == 0
    assert add([0]) == 0

def test_add_two_elements():
    assert add([1, 2]) == 2
    assert add([1, 3]) == 0
    assert add([2, 4]) == 4

def test_add_all_odd():
    assert add([1, 3, 5, 7, 9, 11]) == 0
    assert add([1, 1, 1, 1]) == 0

def test_add_all_even():
    assert add([2, 4, 6, 8, 10]) == 12
    assert add([0, 2, 4, 6]) == 8

def test_add_negative_numbers():
    assert add([-1, -2, -3, -4, -5, -6]) == -12
    assert add([1, -2, 3, -4, 5, -6]) == -12

def test_add_mixed_positive_negative():
    assert add([1, -2, 3, 4, -5, 6]) == 2
    assert add([-1, 2, -3, 4, -5, 6]) == 12

def test_add_large_numbers():
    assert add([1000, 2000, 3000, 4000]) == 6000
    assert add([999, 1000, 999, 1000]) == 2000