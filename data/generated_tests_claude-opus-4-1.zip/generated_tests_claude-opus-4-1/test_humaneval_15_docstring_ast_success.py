# Test cases for HumanEval/15
# Generated using Claude API



def string_sequence(n: int) -> str:
    """ Return a string containing space-delimited numbers starting from 0 upto n inclusive.
    >>> string_sequence(0)
    '0'
    >>> string_sequence(5)
    '0 1 2 3 4 5'
    """

    return ' '.join([str(x) for x in range(n + 1)])


# Generated test cases:
import pytest


def string_sequence(n: int) -> str:
    return ' '.join([str(x) for x in range(n + 1)])


@pytest.mark.parametrize("n,expected", [
    (0, "0"),
    (1, "0 1"),
    (2, "0 1 2"),
    (3, "0 1 2 3"),
    (4, "0 1 2 3 4"),
    (5, "0 1 2 3 4 5"),
    (10, "0 1 2 3 4 5 6 7 8 9 10"),
    (15, "0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15"),
    (20, "0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20"),
    (100, " ".join(str(i) for i in range(101))),
])
def test_string_sequence_normal_cases(n, expected):
    assert string_sequence(n) == expected


def test_string_sequence_zero():
    assert string_sequence(0) == "0"


def test_string_sequence_single_digit():
    assert string_sequence(9) == "0 1 2 3 4 5 6 7 8 9"


def test_string_sequence_double_digit():
    assert string_sequence(11) == "0 1 2 3 4 5 6 7 8 9 10 11"


def test_string_sequence_large_number():
    result = string_sequence(50)
    expected = " ".join(str(i) for i in range(51))
    assert result == expected


def test_string_sequence_very_large_number():
    result = string_sequence(1000)
    expected = " ".join(str(i) for i in range(1001))
    assert result == expected


@pytest.mark.parametrize("n", [-1, -5, -10, -100])
def test_string_sequence_negative_numbers(n):
    result = string_sequence(n)
    assert result == ""


def test_string_sequence_type():
    result = string_sequence(5)
    assert isinstance(result, str)


def test_string_sequence_spacing():
    result = string_sequence(3)
    assert result.count(" ") == 3
    assert "  " not in result
