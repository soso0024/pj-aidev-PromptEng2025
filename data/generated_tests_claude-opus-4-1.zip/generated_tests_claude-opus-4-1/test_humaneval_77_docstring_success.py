# Test cases for HumanEval/77
# Generated using Claude API


def iscube(a):
    '''
    Write a function that takes an integer a and returns True 
    if this ingeger is a cube of some integer number.
    Note: you may assume the input is always valid.
    Examples:
    iscube(1) ==> True
    iscube(2) ==> False
    iscube(-1) ==> True
    iscube(64) ==> True
    iscube(0) ==> True
    iscube(180) ==> False
    '''

    a = abs(a)
    return int(round(a ** (1. / 3))) ** 3 == a


# Generated test cases:
import pytest

def iscube(a):
    a = abs(a)
    return int(round(a ** (1. / 3))) ** 3 == a

@pytest.mark.parametrize("input_val,expected", [
    (0, True),
    (1, True),
    (-1, True),
    (8, True),
    (-8, True),
    (27, True),
    (-27, True),
    (64, True),
    (-64, True),
    (125, True),
    (-125, True),
    (216, True),
    (-216, True),
    (343, True),
    (-343, True),
    (512, True),
    (-512, True),
    (729, True),
    (-729, True),
    (1000, True),
    (-1000, True),
    (1331, True),
    (-1331, True),
    (1728, True),
    (-1728, True),
    (2197, True),
    (-2197, True),
    (2, False),
    (-2, False),
    (3, False),
    (4, False),
    (5, False),
    (6, False),
    (7, False),
    (9, False),
    (10, False),
    (26, False),
    (28, False),
    (63, False),
    (65, False),
    (124, False),
    (126, False),
    (180, False),
    (999, False),
    (1001, False),
    (1330, False),
    (1332, False),
    (2196, False),
    (2198, False),
    (1000000, True),
    (-1000000, True),
    (999999, False),
    (1000001, False),
    (8000000, True),
    (-8000000, True),
    (27000000, True),
    (-27000000, True),
])
def test_iscube(input_val, expected):
    assert iscube(input_val) == expected

def test_iscube_large_perfect_cubes():
    assert iscube(100**3) == True
    assert iscube(-100**3) == True
    assert iscube(50**3) == True
    assert iscube(-50**3) == True
    assert iscube(200**3) == True
    assert iscube(-200**3) == True

def test_iscube_near_perfect_cubes():
    assert iscube(100**3 - 1) == False
    assert iscube(100**3 + 1) == False
    assert iscube(-(100**3 - 1)) == False
    assert iscube(-(100**3 + 1)) == False

def test_iscube_consecutive_cubes():
    cubes = [i**3 for i in range(1, 11)]
    for cube in cubes:
        assert iscube(cube) == True
        assert iscube(-cube) == True
        if cube > 1:
            assert iscube(cube - 1) == False
            assert iscube(cube + 1) == False
