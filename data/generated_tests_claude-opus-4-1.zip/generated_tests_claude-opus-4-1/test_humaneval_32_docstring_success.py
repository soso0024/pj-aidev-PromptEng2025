# Test cases for HumanEval/32
# Generated using Claude API

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


def find_zero(xs: list):
    """ xs are coefficients of a polynomial.
    find_zero find x such that poly(x) = 0.
    find_zero returns only only zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.
    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0
    """

    begin, end = -1., 1.
    while poly(xs, begin) * poly(xs, end) > 0:
        begin *= 2.0
        end *= 2.0
    while end - begin > 1e-10:
        center = (begin + end) / 2.0
        if poly(xs, center) * poly(xs, begin) > 0:
            begin = center
        else:
            end = center
    return begin


# Generated test cases:
import pytest
import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


def find_zero(xs: list):
    begin, end = -1., 1.
    while poly(xs, begin) * poly(xs, end) > 0:
        begin *= 2.0
        end *= 2.0
    while end - begin > 1e-10:
        center = (begin + end) / 2.0
        if poly(xs, center) * poly(xs, begin) > 0:
            begin = center
        else:
            end = center
    return begin


def test_find_zero_linear():
    # f(x) = 1 + 2x, zero at x = -0.5
    result = find_zero([1, 2])
    assert abs(result - (-0.5)) < 1e-9
    assert abs(poly([1, 2], result)) < 1e-9


def test_find_zero_cubic():
    # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    result = find_zero([-6, 11, -6, 1])
    assert abs(result - 1.0) < 1e-9 or abs(result - 2.0) < 1e-9 or abs(result - 3.0) < 1e-9
    assert abs(poly([-6, 11, -6, 1], result)) < 1e-9


def test_find_zero_quadratic():
    # f(x) = x^2 - 1 = -1 + 0x + 1x^2, zeros at x = ±1
    result = find_zero([-1, 0, 1])
    assert abs(result - 1.0) < 1e-9 or abs(result - (-1.0)) < 1e-9
    assert abs(poly([-1, 0, 1], result)) < 1e-9


def test_find_zero_simple_quadratic():
    # f(x) = 1 - x^2 = 1 + 0x - 1x^2, zeros at x = ±1
    result = find_zero([1, 0, -1, 0])
    assert abs(result - 1.0) < 1e-9 or abs(result - (-1.0)) < 1e-9
    assert abs(poly([1, 0, -1, 0], result)) < 1e-9


def test_find_zero_negative_root():
    # f(x) = 2 + x = 0, zero at x = -2
    result = find_zero([2, 1])
    assert abs(result - (-2.0)) < 1e-9
    assert abs(poly([2, 1], result)) < 1e-9


def test_find_zero_positive_root():
    # f(x) = -2 + x = 0, zero at x = 2
    result = find_zero([-2, 1])
    assert abs(result - 2.0) < 1e-9
    assert abs(poly([-2, 1], result)) < 1e-9


def test_find_zero_higher_degree():
    # f(x) = x^3 - 8 = -8 + 0x + 0x^2 + 1x^3, zero at x = 2
    result = find_zero([-8, 0, 0, 1])
    assert abs(result - 2.0) < 1e-9
    assert abs(poly([-8, 0, 0, 1], result)) < 1e-9


def test_find_zero_fractional_root():
    # f(x) = -1 + 4x = 0, zero at x = 0.25
    result = find_zero([-1, 4])
    assert abs(result - 0.25) < 1e-9
    assert abs(poly([-1, 4], result)) < 1e-9


def test_find_zero_large_coefficients():
    # f(x) = 100 - 10x = 0, zero at x = 10
    result = find_zero([100, -10])
    assert abs(result - 10.0) < 1e-9
    assert abs(poly([100, -10], result)) < 1e-9


def test_find_zero_small_coefficients():
    # f(x) = 0.01 - 0.1x = 0, zero at x = 0.1
    result = find_zero([0.01, -0.1])
    assert abs(result - 0.1) < 1e-9
    assert abs(poly([0.01, -0.1], result)) < 1e-9


def test_poly_constant():
    assert poly([5], 0) == 5
    assert poly([5], 1) == 5
    assert poly([5], -1) == 5


def test_poly_linear():
    assert abs(poly([1, 2], 0) - 1) < 1e-9
    assert abs(poly([1, 2], 1) - 3) < 1e-9
    assert abs(poly([1, 2], -1) - (-1)) < 1e-9


def test_poly_quadratic():
    assert abs(poly([1, 2, 3], 0) - 1) < 1e-9
    assert abs(poly([1, 2, 3], 1) - 6) < 1e-9
    assert abs(poly([1, 2, 3], 2) - 17) < 1e-9


def test_poly_cubic():
    assert abs(poly([1, 2, 3, 4], 0) - 1) < 1e-9
    assert abs(poly([1, 2, 3, 4], 1) - 10) < 1e-9
    assert abs(poly([1, 2, 3, 4], 2) - 49) < 1e-9


def test_poly_negative_x():
    assert abs(poly([1, -2, 1], -1) - 4) < 1e-9
    assert abs(poly([0, 1], -5) - (-5)) < 1e-9
