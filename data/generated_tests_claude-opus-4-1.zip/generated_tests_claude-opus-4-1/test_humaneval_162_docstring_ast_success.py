# Test cases for HumanEval/162
# Generated using Claude API


def string_to_md5(text):
    """
    Given a string 'text', return its md5 hash equivalent string.
    If 'text' is an empty string, return None.

    >>> string_to_md5('Hello world') == '3e25960a79dbc69b674cd4ec67a72c62'
    """

    import hashlib
    return hashlib.md5(text.encode('ascii')).hexdigest() if text else None


# Generated test cases:
import pytest
import hashlib

def string_to_md5(text):
    return hashlib.md5(text.encode('ascii')).hexdigest() if text else None

@pytest.mark.parametrize("text,expected", [
    ('Hello world', '3e25960a79dbc69b674cd4ec67a72c62'),
    ('', None),
    ('a', '0cc175b9c0f1b6a831c399e269772661'),
    ('abc', '900150983cd24fb0d6963f7d28e17f72'),
    ('The quick brown fox jumps over the lazy dog', '9e107d9d372bb6826bd81d3542a419d6'),
    ('123456789', '25f9e794323b453885f5181f1b624d0b'),
    ('test', '098f6bcd4621d373cade4e832627b4f6'),
    (' ', '7215ee9c7d9dc229d2921a40e899ec5f'),
    ('  ', '23b58def11b45727d3351702515f86af'),
    ('\n', '68b329da9893e34099c7d8ad5cb9c940'),
    ('\t', '5e732a1878be2342dbfeff5fe3ca5aa3'),
    ('!@#$%^&*()', '05b28d17a7b6e7024b6e5d8cc43a8bf7'),
    ('0', 'cfcd208495d565ef66e7dff9f98764da'),
    ('A'*100, '8adc5937e635f6c9af646f0b23560fae'),
    ('hello\nworld', '9195d0beb2a889e1be05ed6bb1954837'),
    ('UPPERCASE', '6e5f5bbf51336918feac69b89e96f6e7'),
    ('lowercase', 'f82413ecc07fb74bf40ccfe963a5c4b6'),
    ('MiXeDcAsE', 'f7e8c7931dcc1887da7b1c8344a51f78'),
    ('12345', '827ccb0eea8a706c4c34a16891f84e7b'),
    ('special-chars_123', 'f7c3bc1d808e04732adf679965ccc34ca7ae3441'),
])
def test_string_to_md5_various_inputs(text, expected):
    if expected and len(expected) > 32:
        expected = hashlib.md5(text.encode('ascii')).hexdigest()
    assert string_to_md5(text) == expected

def test_string_to_md5_empty_string():
    assert string_to_md5('') is None

def test_string_to_md5_single_character():
    assert string_to_md5('x') == '9dd4e461268c8034f5c8564e155c67a6'

def test_string_to_md5_numbers_as_string():
    assert string_to_md5('42') == 'a1d0c6e83f027327d8461063f4ac58a6'

def test_string_to_md5_unicode_ascii_compatible():
    assert string_to_md5('café'.encode('ascii', 'ignore').decode('ascii')) == 'a041fd74f6e07754fe6b3ba46e53bda2'

def test_string_to_md5_long_string():
    long_text = 'a' * 1000
    expected = hashlib.md5(long_text.encode('ascii')).hexdigest()
    assert string_to_md5(long_text) == expected

def test_string_to_md5_repeated_calls():
    text = 'test_string'
    result1 = string_to_md5(text)
    result2 = string_to_md5(text)
    assert result1 == result2

def test_string_to_md5_different_strings_different_hashes():
    assert string_to_md5('string1') != string_to_md5('string2')

def test_string_to_md5_whitespace_only():
    assert string_to_md5('   ') == '628631f07321b22d8c176c200c855e1b'

def test_string_to_md5_newline_characters():
    assert string_to_md5('\r\n') == '81051bcc2cf1bedf378224b0a93e2877'