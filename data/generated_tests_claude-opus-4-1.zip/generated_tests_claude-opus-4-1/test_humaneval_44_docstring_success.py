# Test cases for HumanEval/44
# Generated using Claude API



def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """

    ret = ""
    while x > 0:
        ret = str(x % base) + ret
        x //= base
    return ret


# Generated test cases:
import pytest

def change_base(x: int, base: int):
    ret = ""
    while x > 0:
        ret = str(x % base) + ret
        x //= base
    return ret

@pytest.mark.parametrize("x,base,expected", [
    (8, 3, "22"),
    (8, 2, "1000"),
    (7, 2, "111"),
    (0, 2, ""),
    (0, 8, ""),
    (1, 2, "1"),
    (1, 9, "1"),
    (10, 2, "1010"),
    (10, 3, "101"),
    (10, 4, "22"),
    (10, 5, "20"),
    (10, 6, "14"),
    (10, 7, "13"),
    (10, 8, "12"),
    (10, 9, "11"),
    (15, 2, "1111"),
    (15, 3, "120"),
    (15, 4, "33"),
    (15, 5, "30"),
    (15, 6, "23"),
    (15, 7, "21"),
    (15, 8, "17"),
    (15, 9, "16"),
    (100, 2, "1100100"),
    (100, 3, "10201"),
    (100, 4, "1210"),
    (100, 5, "400"),
    (100, 6, "244"),
    (100, 7, "202"),
    (100, 8, "144"),
    (100, 9, "121"),
    (255, 2, "11111111"),
    (255, 3, "100110"),
    (255, 4, "3333"),
    (255, 5, "2010"),
    (255, 6, "1103"),
    (255, 7, "513"),
    (255, 8, "377"),
    (255, 9, "313"),
    (1000, 2, "1111101000"),
    (1000, 3, "1101001"),
    (1000, 4, "33220"),
    (1000, 5, "13000"),
    (1000, 6, "4344"),
    (1000, 7, "2626"),
    (1000, 8, "1750"),
    (1000, 9, "1331"),
    (2, 2, "10"),
    (3, 3, "10"),
    (4, 4, "10"),
    (5, 5, "10"),
    (6, 6, "10"),
    (7, 7, "10"),
    (8, 8, "10"),
    (9, 9, "10"),
])
def test_change_base(x, base, expected):
    assert change_base(x, base) == expected

def test_change_base_single_digit():
    for i in range(1, 10):
        for base in range(2, 10):
            if i < base:
                assert change_base(i, base) == str(i)

def test_change_base_powers_of_base():
    for base in range(2, 10):
        assert change_base(base, base) == "10"
        assert change_base(base * base, base) == "100"
        assert change_base(base * base * base, base) == "1000"
