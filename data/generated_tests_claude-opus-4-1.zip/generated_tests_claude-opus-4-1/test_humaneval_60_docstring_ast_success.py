# Test cases for HumanEval/60
# Generated using Claude API



def sum_to_n(n: int):
    """sum_to_n is a function that sums numbers from 1 to n.
    >>> sum_to_n(30)
    465
    >>> sum_to_n(100)
    5050
    >>> sum_to_n(5)
    15
    >>> sum_to_n(10)
    55
    >>> sum_to_n(1)
    1
    """

    return sum(range(n + 1))


# Generated test cases:
import pytest


def sum_to_n(n: int):
    return sum(range(n + 1))


class TestSumToN:
    
    @pytest.mark.parametrize("n,expected", [
        (30, 465),
        (100, 5050),
        (5, 15),
        (10, 55),
        (1, 1),
    ])
    def test_docstring_examples(self, n, expected):
        assert sum_to_n(n) == expected
    
    @pytest.mark.parametrize("n,expected", [
        (0, 0),
        (2, 3),
        (3, 6),
        (4, 10),
        (50, 1275),
        (1000, 500500),
    ])
    def test_normal_cases(self, n, expected):
        assert sum_to_n(n) == expected
    
    def test_zero(self):
        assert sum_to_n(0) == 0
    
    def test_large_number(self):
        assert sum_to_n(10000) == 50005000
    
    @pytest.mark.parametrize("n", [-1, -5, -10, -100])
    def test_negative_numbers(self, n):
        assert sum_to_n(n) == 0
    
    def test_formula_verification(self):
        for n in range(1, 101):
            expected = n * (n + 1) // 2
            assert sum_to_n(n) == expected
    
    @pytest.mark.parametrize("invalid_input", [
        None,
        "5",
        5.5,
        [],
        {},
    ])
    def test_invalid_input_types(self, invalid_input):
        with pytest.raises(TypeError):
            sum_to_n(invalid_input)
