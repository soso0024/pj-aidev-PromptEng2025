# Test cases for HumanEval/48
# Generated using Claude API



def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """

    for i in range(len(text)):
        if text[i] != text[len(text) - 1 - i]:
            return False
    return True


# Generated test cases:
import pytest


@pytest.mark.parametrize("text,expected", [
    ("", True),
    ("a", True),
    ("aa", True),
    ("aba", True),
    ("abba", True),
    ("racecar", True),
    ("A man a plan a canal Panama", False),
    ("race a car", False),
    ("hello", False),
    ("ab", False),
    ("abc", False),
    ("abcd", False),
    ("12321", True),
    ("12345", False),
    ("11", True),
    ("121", True),
    ("1221", True),
    ("12321", True),
    ("123321", True),
    ("1234321", True),
    ("noon", True),
    ("Noon", False),
    ("a b a", True),
    ("aBa", False),
    ("   ", True),
    ("!@#@!", True),
    ("!@#$!", False),
    (".", True),
    ("..", True),
    ("...", True),
    (".a.", True),
    (".a", False),
    ("🙂🙂", True),
    ("🙂😊🙂", True),
    ("🙂😊", False),
    ("あいあ", True),
    ("あいう", False),
])
def test_is_palindrome(text, expected):
    assert is_palindrome(text) == expected


def test_is_palindrome_with_none():
    with pytest.raises(TypeError):
        is_palindrome(None)


def test_is_palindrome_with_number():
    with pytest.raises(TypeError):
        is_palindrome(123)


def test_is_palindrome_with_list():
    with pytest.raises(TypeError):
        is_palindrome([1, 2, 1])


def test_is_palindrome_long_string():
    long_palindrome = "a" * 10000 + "b" + "a" * 10000
    assert is_palindrome(long_palindrome) == True
    
    long_non_palindrome = "a" * 10000 + "b" + "a" * 9999 + "c"
    assert is_palindrome(long_non_palindrome) == False