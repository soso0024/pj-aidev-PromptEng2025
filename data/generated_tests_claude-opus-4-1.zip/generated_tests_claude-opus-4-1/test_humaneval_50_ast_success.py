# Test cases for HumanEval/50
# Generated using Claude API



def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


def decode_shift(s: str):
    """
    takes as input string encoded with encode_shift function. Returns decoded string.
    """

    return "".join([chr(((ord(ch) - 5 - ord("a")) % 26) + ord("a")) for ch in s])


# Generated test cases:
import pytest

def decode_shift(s: str):
    return "".join([chr(((ord(ch) - 5 - ord("a")) % 26) + ord("a")) for ch in s])

@pytest.mark.parametrize("input_str,expected", [
    ("f", "a"),
    ("g", "b"),
    ("h", "c"),
    ("i", "d"),
    ("j", "e"),
    ("a", "v"),
    ("b", "w"),
    ("c", "x"),
    ("d", "y"),
    ("e", "z"),
    ("", ""),
    ("fghij", "abcde"),
    ("abcde", "vwxyz"),
    ("z", "u"),
    ("y", "t"),
    ("klmnopqrstuvwxyz", "fghijklmnopqrstu"),
    ("abcdefghijklmnopqrstuvwxyz", "vwxyzabcdefghijklmnopqrstu"),
    ("fffff", "aaaaa"),
    ("zzzzz", "uuuuu"),
    ("mjqqt", "hello"),
    ("btwqi", "world"),
    ("f", "a"),
    ("fghi", "abcd"),
    ("jklmn", "efghi"),
    ("opqrs", "jklmn"),
    ("tuvwx", "opqrs"),
    ("yzabc", "tuvwx"),
    ("def", "yza"),
])
def test_decode_shift(input_str, expected):
    assert decode_shift(input_str) == expected

def test_decode_shift_single_chars():
    for i in range(26):
        encoded_char = chr((i + 5) % 26 + ord('a'))
        original_char = chr(i + ord('a'))
        assert decode_shift(encoded_char) == original_char

def test_decode_shift_empty_string():
    assert decode_shift("") == ""

def test_decode_shift_full_alphabet():
    encoded = "fghijklmnopqrstuvwxyzabcde"
    decoded = "abcdefghijklmnopqrstuvwxyz"
    assert decode_shift(encoded) == decoded

def test_decode_shift_wrap_around():
    assert decode_shift("abcde") == "vwxyz"
    assert decode_shift("cdefg") == "xyzab"

def test_decode_shift_repeated_chars():
    assert decode_shift("aaaaa") == "vvvvv"
    assert decode_shift("zzzzz") == "uuuuu"
    assert decode_shift("mmmmm") == "hhhhh"
