# Test cases for HumanEval/40
# Generated using Claude API



def triples_sum_to_zero(l: list):
    """
    triples_sum_to_zero takes a list of integers as an input.
    it returns True if there are three distinct elements in the list that
    sum to zero, and False otherwise.

    >>> triples_sum_to_zero([1, 3, 5, 0])
    False
    >>> triples_sum_to_zero([1, 3, -2, 1])
    True
    >>> triples_sum_to_zero([1, 2, 3, 7])
    False
    >>> triples_sum_to_zero([2, 4, -5, 3, 9, 7])
    True
    >>> triples_sum_to_zero([1])
    False
    """

    for i in range(len(l)):
        for j in range(i + 1, len(l)):
            for k in range(j + 1, len(l)):
                if l[i] + l[j] + l[k] == 0:
                    return True
    return False


# Generated test cases:
import pytest

@pytest.mark.parametrize("input_list,expected", [
    # Basic cases with triples that sum to zero
    ([1, -2, 1], True),
    ([1, 2, -3], True),
    ([-1, 0, 1], True),
    ([0, 0, 0], True),
    
    # Cases without triples that sum to zero
    ([1, 2, 3], False),
    ([1, 1, 1], False),
    ([-1, -2, -3], False),
    
    # Edge cases
    ([], False),  # Empty list
    ([1], False),  # Single element
    ([1, 2], False),  # Two elements
    
    # Multiple zeros
    ([0, 0, 0, 1], True),
    ([0, 0, 1], False),
    
    # Larger lists with triples
    ([1, 2, 3, -6], False),  # 1+2+3=6, not 0; 1+2-6=-3, not 0; 1+3-6=-2, not 0; 2+3-6=-1, not 0
    ([5, -2, -3, 0], True),
    ([1, 2, 3, 4, -7], True),
    
    # Larger lists without triples
    ([1, 2, 3, 4, 5], False),
    ([10, 20, 30], False),
    
    # Lists with duplicates
    ([1, 1, -2], True),
    ([2, 2, 2], False),
    ([1, -1, 1, -1], False),  # No three distinct indices sum to 0
    
    # Mixed positive and negative
    ([-5, -3, -1, 2, 4, 6], True),
    ([-10, -5, 1, 2, 3], True),  # -10 + 1 + 9 would be 0, but we don't have 9. Actually -5+2+3=0
    
    # Floating point numbers
    ([0.5, 0.5, -1.0], True),
    ([1.5, 2.5, -4.0], True),
    ([0.1, 0.2, 0.3], False),
    
    # Large numbers
    ([1000, -500, -500], True),
    ([999999, -999998, -1], True),
    ([1000000, 2000000, 3000000], False),
])
def test_triples_sum_to_zero(input_list, expected):
    assert triples_sum_to_zero(input_list) == expected


def test_triples_sum_to_zero_does_not_modify_input():
    original = [1, 2, -3, 4]
    copy = original.copy()
    triples_sum_to_zero(original)
    assert original == copy


def test_triples_sum_to_zero_with_none_elements():
    # Function expects numeric values, None will cause TypeError
    with pytest.raises(TypeError):
        triples_sum_to_zero([1, None, -1])


def test_triples_sum_to_zero_early_return():
    # Test that function returns as soon as it finds a triple
    result = triples_sum_to_zero([1, -1, 0, 100, 200, 300])
    assert result == True


def test_triples_sum_to_zero_order_independence():
    # Same elements in different order should give same result
    list1 = [1, 2, -3, 4]
    list2 = [4, -3, 2, 1]
    assert triples_sum_to_zero(list1) == triples_sum_to_zero(list2)