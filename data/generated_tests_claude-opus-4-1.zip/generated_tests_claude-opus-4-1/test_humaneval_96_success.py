# Test cases for HumanEval/96
# Generated using Claude API


def count_up_to(n):
    """Implement a function that takes an non-negative integer and returns an array of the first n
    integers that are prime numbers and less than n.
    for example:
    count_up_to(5) => [2,3]
    count_up_to(11) => [2,3,5,7]
    count_up_to(0) => []
    count_up_to(20) => [2,3,5,7,11,13,17,19]
    count_up_to(1) => []
    count_up_to(18) => [2,3,5,7,11,13,17]
    """

    primes = []
    for i in range(2, n):
        is_prime = True
        for j in range(2, i):
            if i % j == 0:
                is_prime = False
                break
        if is_prime:
            primes.append(i)
    return primes



# Generated test cases:
import pytest

def count_up_to(n):
    primes = []
    for i in range(2, n):
        is_prime = True
        for j in range(2, i):
            if i % j == 0:
                is_prime = False
                break
        if is_prime:
            primes.append(i)
    return primes


@pytest.mark.parametrize("n,expected", [
    (0, []),
    (1, []),
    (2, []),
    (3, [2]),
    (4, [2, 3]),
    (5, [2, 3]),
    (6, [2, 3, 5]),
    (10, [2, 3, 5, 7]),
    (11, [2, 3, 5, 7]),
    (12, [2, 3, 5, 7, 11]),
    (20, [2, 3, 5, 7, 11, 13, 17, 19]),
    (30, [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]),
    (50, [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]),
    (100, [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]),
])
def test_count_up_to_valid_inputs(n, expected):
    assert count_up_to(n) == expected


def test_count_up_to_negative():
    assert count_up_to(-1) == []
    assert count_up_to(-10) == []
    assert count_up_to(-100) == []


def test_count_up_to_large_number():
    result = count_up_to(200)
    assert 2 in result
    assert 3 in result
    assert 197 in result
    assert 199 in result
    assert 200 not in result
    assert len(result) == 46


def test_count_up_to_type():
    result = count_up_to(10)
    assert isinstance(result, list)
    assert all(isinstance(x, int) for x in result)


def test_count_up_to_order():
    result = count_up_to(30)
    assert result == sorted(result)


def test_count_up_to_uniqueness():
    result = count_up_to(50)
    assert len(result) == len(set(result))


def test_count_up_to_all_primes():
    result = count_up_to(30)
    for prime in result:
        for i in range(2, prime):
            assert prime % i != 0
