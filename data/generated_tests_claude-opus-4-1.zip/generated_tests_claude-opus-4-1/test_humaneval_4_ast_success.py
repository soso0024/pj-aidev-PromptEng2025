# Test cases for HumanEval/4
# Generated using Claude API

from typing import List


def mean_absolute_deviation(numbers: List[float]) -> float:
    """ For a given list of input numbers, calculate Mean Absolute Deviation
    around the mean of this dataset.
    Mean Absolute Deviation is the average absolute difference between each
    element and a centerpoint (mean in this case):
    MAD = average | x - x_mean |
    >>> mean_absolute_deviation([1.0, 2.0, 3.0, 4.0])
    1.0
    """

    mean = sum(numbers) / len(numbers)
    return sum(abs(x - mean) for x in numbers) / len(numbers)


# Generated test cases:
import pytest
from typing import List
import math


def mean_absolute_deviation(numbers: List[float]) -> float:
    mean = sum(numbers) / len(numbers)
    return sum(abs(x - mean) for x in numbers) / len(numbers)


class TestMeanAbsoluteDeviation:
    
    def test_single_element(self):
        assert mean_absolute_deviation([5.0]) == 0.0
        assert mean_absolute_deviation([0.0]) == 0.0
        assert mean_absolute_deviation([-10.0]) == 0.0
    
    def test_two_elements(self):
        assert mean_absolute_deviation([1.0, 3.0]) == 1.0
        assert mean_absolute_deviation([0.0, 10.0]) == 5.0
        assert mean_absolute_deviation([-5.0, 5.0]) == 5.0
    
    def test_all_same_elements(self):
        assert mean_absolute_deviation([2.0, 2.0, 2.0, 2.0]) == 0.0
        assert mean_absolute_deviation([0.0, 0.0, 0.0]) == 0.0
        assert mean_absolute_deviation([-1.0, -1.0, -1.0, -1.0, -1.0]) == 0.0
    
    def test_positive_numbers(self):
        assert mean_absolute_deviation([1.0, 2.0, 3.0, 4.0, 5.0]) == 1.2
        assert abs(mean_absolute_deviation([10.0, 20.0, 30.0]) - 20/3) < 1e-10
    
    def test_negative_numbers(self):
        assert mean_absolute_deviation([-1.0, -2.0, -3.0, -4.0, -5.0]) == 1.2
        assert abs(mean_absolute_deviation([-10.0, -20.0, -30.0]) - 20/3) < 1e-10
    
    def test_mixed_positive_negative(self):
        assert mean_absolute_deviation([-2.0, -1.0, 0.0, 1.0, 2.0]) == 1.2
        assert mean_absolute_deviation([-10.0, 0.0, 10.0]) == 20/3
    
    def test_decimal_numbers(self):
        result = mean_absolute_deviation([1.5, 2.5, 3.5, 4.5])
        assert abs(result - 1.0) < 1e-10
        
        result = mean_absolute_deviation([0.1, 0.2, 0.3, 0.4, 0.5])
        assert abs(result - 0.12) < 1e-10
    
    def test_large_numbers(self):
        assert mean_absolute_deviation([1000.0, 2000.0, 3000.0]) == 2000/3
        assert mean_absolute_deviation([1e6, 2e6, 3e6]) == 2e6/3
    
    def test_small_numbers(self):
        result = mean_absolute_deviation([0.001, 0.002, 0.003])
        assert abs(result - 0.002/3) < 1e-10
        
        result = mean_absolute_deviation([1e-6, 2e-6, 3e-6])
        assert abs(result - 2e-6/3) < 1e-12
    
    def test_symmetric_around_zero(self):
        assert mean_absolute_deviation([-3.0, -1.0, 1.0, 3.0]) == 2.0
        assert mean_absolute_deviation([-2.0, 0.0, 2.0]) == 4/3
    
    def test_known_example(self):
        # MAD of [1, 2, 3, 4, 5]
        # mean = 3, deviations = [2, 1, 0, 1, 2], MAD = 6/5 = 1.2
        assert mean_absolute_deviation([1.0, 2.0, 3.0, 4.0, 5.0]) == 1.2
    
    def test_another_known_example(self):
        # MAD of [2, 2, 3, 4, 14]
        # mean = 5, deviations = [3, 3, 2, 1, 9], MAD = 18/5 = 3.6
        assert mean_absolute_deviation([2.0, 2.0, 3.0, 4.0, 14.0]) == 3.6
    
    @pytest.mark.parametrize("numbers,expected", [
        ([1.0], 0.0),
        ([1.0, 1.0], 0.0),
        ([1.0, 3.0], 1.0),
        ([1.0, 2.0, 3.0], 2/3),
        ([0.0, 0.0, 0.0], 0.0),
        ([-1.0, 0.0, 1.0], 2/3),
        ([10.0, 20.0], 5.0),
    ])
    def test_parametrized_cases(self, numbers, expected):
        assert abs(mean_absolute_deviation(numbers) - expected) < 1e-10
