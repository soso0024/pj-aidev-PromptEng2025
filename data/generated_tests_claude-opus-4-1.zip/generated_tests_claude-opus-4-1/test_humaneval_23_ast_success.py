# Test cases for HumanEval/23
# Generated using Claude API



def strlen(string: str) -> int:
    """ Return length of given string
    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """

    return len(string)


# Generated test cases:
import pytest


def strlen(string: str) -> int:
    return len(string)


class TestStrlen:
    @pytest.mark.parametrize("input_string,expected", [
        ("", 0),
        ("a", 1),
        ("hello", 5),
        ("hello world", 11),
        ("   ", 3),
        ("Hello, World!", 13),
        ("1234567890", 10),
        ("abc\ndef", 7),
        ("tab\ttab", 7),
        ("unicode: 你好", 11),
        ("emoji: 😀", 8),
        ("special!@#$%^&*()", 17),
        ("'single quotes'", 15),
        ('"double quotes"', 15),
        ("line1\nline2\nline3", 17),
        ("trailing space ", 15),
        (" leading space", 14),
        ("  both spaces  ", 15),
        ("a" * 100, 100),
        ("a" * 1000, 1000),
        ("\n\r\t", 3),
        ("null\x00char", 9),
        ("mixed123ABC!@#", 14),
        ("", 0),
        ("_underscore_", 12),
        ("hyphen-ated", 11),
        ("dot.separated", 13),
        ("path/to/file", 12),
        ("http://example.com", 18),
        ("email@domain.com", 16),
    ])
    def test_strlen_various_strings(self, input_string, expected):
        assert strlen(input_string) == expected

    def test_strlen_empty_string(self):
        assert strlen("") == 0

    def test_strlen_single_character(self):
        assert strlen("x") == 1

    def test_strlen_long_string(self):
        long_str = "a" * 10000
        assert strlen(long_str) == 10000

    def test_strlen_multiline_string(self):
        multiline = """This is
        a multiline
        string"""
        assert strlen(multiline) == 42

    def test_strlen_with_escape_sequences(self):
        assert strlen("hello\nworld") == 11
        assert strlen("tab\there") == 8
        assert strlen("quote\"here") == 10
        assert strlen("backslash\\here") == 14

    def test_strlen_unicode_characters(self):
        assert strlen("café") == 4
        assert strlen("🎉🎊🎈") == 3
        assert strlen("Здравствуйте") == 12
        assert strlen("こんにちは") == 5

    def test_strlen_raw_string(self):
        raw_str = r"raw\nstring"
        assert strlen(raw_str) == 11

    def test_strlen_repeated_characters(self):
        assert strlen("aaaa") == 4
        assert strlen("    ") == 4
        assert strlen("....") == 4