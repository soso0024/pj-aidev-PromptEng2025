# Test cases for HumanEval/75
# Generated using Claude API


def is_multiply_prime(a):
    """Write a function that returns true if the given number is the multiplication of 3 prime numbers
    and false otherwise.
    Knowing that (a) is less then 100. 
    Example:
    is_multiply_prime(30) == True
    30 = 2 * 3 * 5
    """

    def is_prime(n):
        for j in range(2,n):
            if n%j == 0:
                return False
        return True

    for i in range(2,101):
        if not is_prime(i): continue
        for j in range(2,101):
            if not is_prime(j): continue
            for k in range(2,101):
                if not is_prime(k): continue
                if i*j*k == a: return True
    return False


# Generated test cases:
import pytest


@pytest.mark.parametrize("input_val,expected", [
    (8, True),  # 2 * 2 * 2
    (30, True),  # 2 * 3 * 5
    (105, True),  # 3 * 5 * 7
    (70, True),  # 2 * 5 * 7
    (12, True),  # 2 * 2 * 3
    (18, True),  # 2 * 3 * 3
    (27, True),  # 3 * 3 * 3
    (125, True),  # 5 * 5 * 5
    (343, True),  # 7 * 7 * 7
    (1, False),  # Not a product of three primes
    (2, False),  # Single prime
    (4, False),  # 2 * 2 (only two primes)
    (6, False),  # 2 * 3 (only two primes)
    (10, False),  # 2 * 5 (only two primes)
    (15, False),  # 3 * 5 (only two primes)
    (16, False),  # 2 * 2 * 2 * 2 (four primes)
    (24, False),  # 2 * 2 * 2 * 3 (four primes)
    (60, False),  # 2 * 2 * 3 * 5 (four primes)
    (100, False),  # 2 * 2 * 5 * 5 (four primes)
    (1000001, False),  # Too large for the function's range
    (0, False),  # Zero
    (-8, False),  # Negative number
    (-30, False),  # Negative number
    (11, False),  # Single prime
    (13, False),  # Single prime
    (210, False),  # 2 * 3 * 5 * 7 (four primes)
    (420, False),  # 2 * 2 * 3 * 5 * 7 (five primes)
    (385, True),  # 5 * 7 * 11
    (231, True),  # 3 * 7 * 11
    (165, True),  # 3 * 5 * 11
    (195, True),  # 3 * 5 * 13
    (455, True),  # 5 * 7 * 13
    (1001, True),  # 7 * 11 * 13
    (969, True),  # 3 * 17 * 19
    (9699690, False),  # 2 * 3 * 5 * 7 * 11 * 13 * 17 * 19 (too many primes and too large)
])
def test_is_multiply_prime(input_val, expected):
    assert is_multiply_prime(input_val) == expected


def test_is_multiply_prime_edge_cases():
    assert is_multiply_prime(2 * 2 * 97) == True
    assert is_multiply_prime(2 * 3 * 97) == True
    assert is_multiply_prime(3 * 31 * 31) == True
    assert is_multiply_prime(97 * 97 * 97) == True  # 97^3 is within range
    assert is_multiply_prime(2 * 2 * 101) == False  # 101 is out of range
    assert is_multiply_prime(2 * 3 * 101) == False  # 101 is out of range