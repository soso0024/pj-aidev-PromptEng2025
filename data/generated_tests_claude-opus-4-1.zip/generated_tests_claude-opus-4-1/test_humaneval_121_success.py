# Test cases for HumanEval/121
# Generated using Claude API


def solution(lst):
    """Given a non-empty list of integers, return the sum of all of the odd elements that are in even positions.
    

    Examples
    solution([5, 8, 7, 1]) ==> 12
    solution([3, 3, 3, 3, 3]) ==> 9
    solution([30, 13, 24, 321]) ==>0
    """

    return sum([x for idx, x in enumerate(lst) if idx%2==0 and x%2==1])


# Generated test cases:
import pytest

def solution(lst):
    return sum([x for idx, x in enumerate(lst) if idx%2==0 and x%2==1])

@pytest.mark.parametrize("input_list,expected", [
    # Empty list
    ([], 0),
    
    # Single element - odd at even index
    ([1], 1),
    ([3], 3),
    
    # Single element - even at even index
    ([2], 0),
    ([4], 0),
    
    # Two elements
    ([1, 2], 1),
    ([2, 3], 0),
    ([3, 4], 3),
    ([4, 5], 0),
    
    # Multiple elements - normal cases
    ([1, 2, 3, 4, 5], 9),  # 1 + 3 + 5 = 9
    ([2, 4, 6, 8, 10], 0),  # all even
    ([1, 3, 5, 7, 9], 15),  # 1 + 5 + 9 = 15
    
    # Mixed values
    ([5, 8, 7, 1], 12),  # 5 at index 0 + 7 at index 2 = 12
    ([0, 1, 2, 3, 4, 5], 0),  # 0 at index 0, 2 at index 2, 4 at index 4
    ([1, 0, 3, 0, 5, 0], 9),  # 1 + 3 + 5 = 9
    
    # Negative numbers
    ([-1, 2, -3, 4, -5], -9),  # -1 + -3 + -5 = -9
    ([-2, -4, -6, -8], 0),  # all even
    ([1, -2, -3, 4, 5], 3),  # 1 + (-3) + 5 = 3
    
    # Large numbers
    ([101, 200, 303, 400, 505], 909),  # 101 + 303 + 505 = 909
    
    # Zero values
    ([0, 0, 0, 0], 0),
    ([0, 1, 0, 1, 0], 0),
    ([1, 0, 1, 0, 1], 3),
    
    # Long list
    ([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 25),  # 1 + 3 + 5 + 7 + 9 = 25
    
    # All odd numbers
    ([1, 1, 1, 1, 1], 3),  # indices 0, 2, 4
    
    # Alternating odd and even
    ([1, 2, 1, 2, 1, 2], 3),  # 1 + 1 + 1 = 3
    ([2, 1, 2, 1, 2, 1], 0),  # all even at even indices
])
def test_solution(input_list, expected):
    assert solution(input_list) == expected

def test_solution_does_not_modify_input():
    original = [1, 2, 3, 4, 5]
    copy = original.copy()
    solution(original)
    assert original == copy

def test_solution_with_large_values():
    lst = [999999, 1000000, 999997, 1000002]
    assert solution(lst) == 999999 + 999997

def test_solution_type_consistency():
    assert isinstance(solution([]), int)
    assert isinstance(solution([1, 2, 3]), int)