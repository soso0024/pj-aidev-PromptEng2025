# Test cases for HumanEval/93
# Generated using Claude API


def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """

    vowels = "aeiouAEIOU"
    vowels_replace = dict([(i, chr(ord(i) + 2)) for i in vowels])
    message = message.swapcase()
    return ''.join([vowels_replace[i] if i in vowels else i for i in message])


# Generated test cases:
import pytest

def encode(message):
    vowels = "aeiouAEIOU"
    vowels_replace = dict([(i, chr(ord(i) + 2)) for i in vowels])
    message = message.swapcase()
    return ''.join([vowels_replace[i] if i in vowels else i for i in message])

@pytest.mark.parametrize("input_msg,expected", [
    ("", ""),
    ("a", "C"),
    ("A", "c"),
    ("e", "G"),
    ("E", "g"),
    ("i", "K"),
    ("I", "k"),
    ("o", "Q"),
    ("O", "q"),
    ("u", "W"),
    ("U", "w"),
    ("hello", "HGLLQ"),
    ("HELLO", "hgllq"),
    ("Hello World", "hGLLQ wQRLD"),
    ("aeiou", "CGKQW"),
    ("AEIOU", "cgkqw"),
    ("bcdfg", "BCDFG"),
    ("BCDFG", "bcdfg"),
    ("The Quick Brown Fox", "tHG qWKCK bRQWN fQX"),
    ("123456", "123456"),
    ("!@#$%^&*()", "!@#$%^&*()"),
    ("Mix123ABC", "mKX123cbc"),
    ("aAbBcCdDeEfF", "CcBbCcDdGgFf"),
    ("Programming", "pRQGRCMMKNG"),
    ("Python Testing", "pYTHQN tGSTKNG"),
    (" ", " "),
    ("   spaces   ", "   SPCCGS   "),
    ("\t\n", "\t\n"),
    ("a1e2i3o4u5", "C1G2K3Q4W5"),
    ("A1E2I3O4U5", "c1g2k3q4w5"),
])
def test_encode(input_msg, expected):
    assert encode(input_msg) == expected

def test_encode_single_consonants():
    assert encode("b") == "B"
    assert encode("B") == "b"
    assert encode("z") == "Z"
    assert encode("Z") == "z"

def test_encode_mixed_case():
    assert encode("HeLLo") == "hGllQ"
    assert encode("WoRlD") == "wQrLd"

def test_encode_special_characters():
    assert encode("hello!") == "HGLLQ!"
    assert encode("test@123") == "TGST@123"
    assert encode("a-b-c") == "C-B-C"

def test_encode_numbers():
    assert encode("123") == "123"
    assert encode("0") == "0"
    assert encode("999") == "999"

def test_encode_unicode_basic():
    assert encode("café") == "CCFÉ"
    
def test_encode_long_string():
    long_str = "a" * 1000
    expected = "C" * 1000
    assert encode(long_str) == expected

def test_encode_alternating_case():
    assert encode("aBcDeF") == "CbCdGf"
    assert encode("AbCdEf") == "cBcDgF"

def test_encode_punctuation():
    assert encode("Hello, World!") == "hGLLQ, wQRLD!"
    assert encode("What's up?") == "wHCT'S WP?"

def test_encode_newlines_tabs():
    assert encode("hello\nworld") == "HGLLQ\nWQRLD"
    assert encode("test\ttab") == "TGST\tTCB"

def test_encode_consecutive_vowels():
    assert encode("aaa") == "CCC"
    assert encode("eee") == "GGG"
    assert encode("aeiouaeiou") == "CGKQWCGKQW"

def test_encode_consecutive_consonants():
    assert encode("bcd") == "BCD"
    assert encode("xyz") == "XYZ"

def test_encode_mixed_vowels_consonants():
    assert encode("abcde") == "CBCDG"
    assert encode("ABCDE") == "cbcdg"