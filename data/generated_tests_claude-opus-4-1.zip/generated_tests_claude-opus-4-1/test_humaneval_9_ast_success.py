# Test cases for HumanEval/9
# Generated using Claude API

from typing import List, Tuple


def rolling_max(numbers: List[int]) -> List[int]:
    """ From a given list of integers, generate a list of rolling maximum element found until given moment
    in the sequence.
    >>> rolling_max([1, 2, 3, 2, 3, 4, 2])
    [1, 2, 3, 3, 3, 4, 4]
    """

    running_max = None
    result = []

    for n in numbers:
        if running_max is None:
            running_max = n
        else:
            running_max = max(running_max, n)

        result.append(running_max)

    return result


# Generated test cases:
import pytest
from typing import List


def rolling_max(numbers: List[int]) -> List[int]:
    running_max = None
    result = []

    for n in numbers:
        if running_max is None:
            running_max = n
        else:
            running_max = max(running_max, n)

        result.append(running_max)

    return result


@pytest.mark.parametrize("numbers,expected", [
    ([], []),
    ([1], [1]),
    ([1, 2, 3, 4, 5], [1, 2, 3, 4, 5]),
    ([5, 4, 3, 2, 1], [5, 5, 5, 5, 5]),
    ([1, 3, 2, 5, 4], [1, 3, 3, 5, 5]),
    ([1, 1, 1, 1, 1], [1, 1, 1, 1, 1]),
    ([-5, -3, -1, 0, 2], [-5, -3, -1, 0, 2]),
    ([10, -5, 20, -10, 30], [10, 10, 20, 20, 30]),
    ([-10, -20, -5, -30], [-10, -10, -5, -5]),
    ([0, 0, 0], [0, 0, 0]),
    ([100], [100]),
    ([1, 2, 1, 3, 1, 4, 1], [1, 2, 2, 3, 3, 4, 4]),
    ([5, 5, 5, 6, 5, 7], [5, 5, 5, 6, 6, 7]),
    ([-1, -2, -3, -2, -1], [-1, -1, -1, -1, -1]),
    ([2147483647, -2147483648, 0], [2147483647, 2147483647, 2147483647]),
    ([1, 10, 2, 20, 3, 30], [1, 10, 10, 20, 20, 30]),
    ([-100, 100, -50, 50], [-100, 100, 100, 100]),
    ([9, 8, 7, 10, 5, 4, 3], [9, 9, 9, 10, 10, 10, 10]),
    ([42], [42]),
    ([1, 2], [1, 2]),
    ([2, 1], [2, 2])
])
def test_rolling_max(numbers, expected):
    assert rolling_max(numbers) == expected


def test_rolling_max_does_not_modify_input():
    original = [1, 3, 2, 5, 4]
    input_copy = original.copy()
    rolling_max(input_copy)
    assert input_copy == original


def test_rolling_max_with_large_list():
    numbers = list(range(1000))
    result = rolling_max(numbers)
    assert result == numbers
    
    numbers_reverse = list(range(999, -1, -1))
    result_reverse = rolling_max(numbers_reverse)
    assert result_reverse == [999] * 1000


def test_rolling_max_alternating():
    numbers = [i if i % 2 == 0 else -i for i in range(10)]
    expected = [0, 0, 2, 2, 4, 4, 6, 6, 8, 8]
    assert rolling_max(numbers) == expected
