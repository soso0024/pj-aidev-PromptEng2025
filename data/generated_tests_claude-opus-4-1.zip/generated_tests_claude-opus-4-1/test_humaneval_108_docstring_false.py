# Test cases for HumanEval/108
# Generated using Claude API


def count_nums(arr):
    """
    Write a function count_nums which takes an array of integers and returns
    the number of elements which has a sum of digits > 0.
    If a number is negative, then its first signed digit will be negative:
    e.g. -123 has signed digits -1, 2, and 3.
    >>> count_nums([]) == 0
    >>> count_nums([-1, 11, -11]) == 1
    >>> count_nums([1, 1, 2]) == 3
    """

    def digits_sum(n):
        neg = 1
        if n < 0: n, neg = -1 * n, -1 
        n = [int(i) for i in str(n)]
        n[0] = n[0] * neg
        return sum(n)
    return len(list(filter(lambda x: x > 0, [digits_sum(i) for i in arr])))


# Generated test cases:
import pytest

@pytest.mark.parametrize("arr,expected", [
    ([], 0),
    ([-1, 11, -11], 1),
    ([1, 1, 2], 3),
    ([0], 0),
    ([1], 1),
    ([-1], 0),
    ([10], 1),
    ([-10], 0),
    ([100], 1),
    ([-100], 0),
    ([123], 1),
    ([-123], 1),
    ([999], 1),
    ([-999], 1),
    ([12, -12], 2),
    ([21, -21], 1),
    ([111, -111], 2),
    ([1234], 1),
    ([-1234], 1),
    ([9999], 1),
    ([-9999], 1),
    ([0, 0, 0], 0),
    ([1, 2, 3, 4, 5], 5),
    ([-1, -2, -3, -4, -5], 0),
    ([10, 20, 30, 40, 50], 5),
    ([-10, -20, -30, -40, -50], 0),
    ([11, -11, 22, -22], 2),
    ([100, -100, 200, -200], 2),
    ([505], 1),
    ([-505], 0),
    ([1001], 1),
    ([-1001], 0),
    ([9, -9], 1),
    ([99, -99], 2),
    ([999, -999], 2),
    ([1000, -1000], 1),
    ([12345], 1),
    ([-12345], 1),
    ([54321], 1),
    ([-54321], 1),
    ([101, -101], 1),
    ([202, -202], 1),
    ([303, -303], 1),
    ([404, -404], 1),
    ([505, -505], 1),
    ([606, -606], 1),
    ([707, -707], 1),
    ([808, -808], 1),
    ([909, -909], 1),
    ([1, -1, 2, -2, 3, -3], 3),
    ([10, -10, 20, -20, 30, -30], 3),
    ([11, -12, 13, -14, 15], 5),
    ([-91], 0),
    ([-92], 0),
    ([-93], 0),
    ([-94], 0),
    ([-95], 0),
    ([-96], 0),
    ([-97], 0),
    ([-98], 0),
    ([-99], 0),
    ([19], 1),
    ([-19], 1),
    ([28], 1),
    ([-28], 1),
    ([37], 1),
    ([-37], 1),
    ([46], 1),
    ([-46], 1),
    ([55], 1),
    ([-55], 0),
    ([64], 1),
    ([-64], 0),
    ([73], 1),
    ([-73], 0),
    ([82], 1),
    ([-82], 0),
    ([91], 1),
    ([-91], 0)
])
def test_count_nums(arr, expected):
    assert count_nums(arr) == expected


def test_count_nums_large_numbers():
    assert count_nums([999999]) == 1
    assert count_nums([-999999]) == 1
    assert count_nums([1000000]) == 1
    assert count_nums([-1000000]) == 0


def test_count_nums_mixed():
    assert count_nums([0, 1, -1, 10, -10, 100, -100]) == 3
    assert count_nums([5, -5, 15, -15, 25, -25]) == 5
    assert count_nums([9, -9, 99, -99, 999, -999]) == 4