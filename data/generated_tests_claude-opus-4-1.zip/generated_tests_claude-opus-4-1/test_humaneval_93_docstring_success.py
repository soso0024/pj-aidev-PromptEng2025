# Test cases for HumanEval/93
# Generated using Claude API


def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """

    vowels = "aeiouAEIOU"
    vowels_replace = dict([(i, chr(ord(i) + 2)) for i in vowels])
    message = message.swapcase()
    return ''.join([vowels_replace[i] if i in vowels else i for i in message])


# Generated test cases:
import pytest

def encode(message):
    vowels = "aeiouAEIOU"
    vowels_replace = dict([(i, chr(ord(i) + 2)) for i in vowels])
    message = message.swapcase()
    return ''.join([vowels_replace[i] if i in vowels else i for i in message])


@pytest.mark.parametrize("input_msg,expected", [
    ("test", "TGST"),
    ("This is a message", "tHKS KS C MGSSCGG"),
    ("", ""),
    ("a", "C"),
    ("A", "c"),
    ("e", "G"),
    ("E", "g"),
    ("i", "K"),
    ("I", "k"),
    ("o", "Q"),
    ("O", "q"),
    ("u", "W"),
    ("U", "w"),
    ("aeiou", "CGKQW"),
    ("AEIOU", "cgkqw"),
    ("bcdfg", "BCDFG"),
    ("BCDFG", "bcdfg"),
    ("Hello World", "hGLLQ wQRLD"),
    ("Python Programming", "pYTHQN pRQGRCMMKNG"),
    ("aaa", "CCC"),
    ("AAA", "ccc"),
    ("The quick brown fox", "tHG QWKCK BRQWN FQX"),
    ("Jumps over the lazy dog", "jWMPS QVGR THG LCZY DQG"),
    ("AbCdEfGhIjKl", "cBcDgFgHkJkL"),
    ("xyz", "XYZ"),
    ("XYZ", "xyz"),
    ("aEiOu", "CgKqW"),
    ("AeIoU", "cGkQw"),
    ("Mixed CASE with VOWELS", "mKXGD ccsg WKTH vqwgls"),
    ("aeioubcdfghjklmnpqrstvwxyz", "CGKQWBCDFGHJKLMNPQRSTVWXYZ"),
    ("AEIOUBCDFGHJKLMNPQRSTVWXYZ", "cgkqwbcdfghjklmnpqrstvwxyz"),
    ("a e i o u", "C G K Q W"),
    ("A E I O U", "c g k q w")
])
def test_encode(input_msg, expected):
    assert encode(input_msg) == expected


def test_encode_all_lowercase_letters():
    input_str = "abcdefghijklmnopqrstuvwxyz"
    expected = "CBCDGFGHKJKLMNQPQRSTWVWXYZ"
    assert encode(input_str) == expected


def test_encode_all_uppercase_letters():
    input_str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    expected = "cbcdgfghkjklmnqpqrstwvwxyz"
    assert encode(input_str) == expected


def test_encode_spaces_preserved():
    assert encode("a b c") == "C B C"
    assert encode("  spaces  ") == "  SPCCGS  "


def test_encode_repeated_vowels():
    assert encode("aaaeeeiiioouuu") == "CCCGGGKKKQQWWW"
    assert encode("AAAEEEIIIOOUUU") == "cccgggkkkqqwww"


def test_encode_alternating_case():
    assert encode("aAbBcCdDeEfF") == "CcBbCcDdGgFf"


def test_encode_single_characters():
    assert encode("a") == "C"
    assert encode("b") == "B"
    assert encode("A") == "c"
    assert encode("B") == "b"