# Test cases for HumanEval/162
# Generated using Claude API


def string_to_md5(text):
    """
    Given a string 'text', return its md5 hash equivalent string.
    If 'text' is an empty string, return None.

    >>> string_to_md5('Hello world') == '3e25960a79dbc69b674cd4ec67a72c62'
    """

    import hashlib
    return hashlib.md5(text.encode('ascii')).hexdigest() if text else None


# Generated test cases:
import pytest
import hashlib

def string_to_md5(text):
    return hashlib.md5(text.encode('ascii')).hexdigest() if text else None

@pytest.mark.parametrize("text,expected", [
    ("", None),
    ("hello", "5d41402abc4b2a76b9719d911017c592"),
    ("Hello", "8b1a9953c4611296a827abf8c47804d7"),
    ("hello world", "5eb63bbbe01eeed093cb22bb8f5acdc3"),
    ("a", "0cc175b9c0f1b6a831c399e269772661"),
    ("abc", "900150983cd24fb0d6963f7d28e17f72"),
    ("The quick brown fox jumps over the lazy dog", "9e107d9d372bb6826bd81d3542a419d6"),
    ("123", "202cb962ac59075b964b07152d234b70"),
    ("!@#$%^&*()", "05b28d17a7b6e7024b6e5d8cc43a8bf7"),
    (" ", "7215ee9c7d9dc229d2921a40e899ec5f"),
    ("  ", "23b58def11b45727d3351702515f86af"),
    ("\t", "5e732a1878be2342dbfeff5fe3ca5aa3"),
    ("\n", "68b329da9893e34099c7d8ad5cb9c940"),
    ("test123", "cc03e747a6afbbcbf8be7668acfebee5"),
    ("TEST", "033bd94b1168d7e4f0d644c3c95e35bf"),
    ("0", "cfcd208495d565ef66e7dff9f98764da"),
    ("python", "23eeeb4347bdd26bfc6b7ee9a3b755dd"),
    ("a" * 100, "36a92cc94a9e0fa21f625f8bfb007adf"),
    ("1234567890", "e807f1fcf82d132f9bb018ca6738a19f"),
    ("test@example.com", "55502f40dc8b7c769880b10874abc9d0"),
    ("http://www.example.com", "847310eb455f9ae37cb56962213c491d"),
    ("/path/to/file", "b4a91649090a2784056565363583d067"),
    ("line1\nline2", "ee5a58024a155466b43bc559d953e018"),
])
def test_string_to_md5_valid_inputs(text, expected):
    assert string_to_md5(text) == expected

def test_string_to_md5_none_input():
    assert string_to_md5(None) is None

def test_string_to_md5_consistency():
    text = "consistent_test"
    result1 = string_to_md5(text)
    result2 = string_to_md5(text)
    assert result1 == result2

def test_string_to_md5_different_strings_different_hashes():
    assert string_to_md5("test1") != string_to_md5("test2")

def test_string_to_md5_case_sensitive():
    assert string_to_md5("Test") != string_to_md5("test")

def test_string_to_md5_whitespace_matters():
    assert string_to_md5("test") != string_to_md5("test ")
    assert string_to_md5("test") != string_to_md5(" test")

def test_string_to_md5_output_format():
    result = string_to_md5("test")
    assert isinstance(result, str)
    assert len(result) == 32
    assert all(c in "0123456789abcdef" for c in result)

def test_string_to_md5_empty_vs_none():
    assert string_to_md5("") is None
    assert string_to_md5(None) is None