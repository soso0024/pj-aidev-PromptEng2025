# Test cases for HumanEval/11
# Generated using Claude API

from typing import List


def string_xor(a: str, b: str) -> str:
    """ Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.
    >>> string_xor('010', '110')
    '100'
    """

    def xor(i, j):
        if i == j:
            return '0'
        else:
            return '1'

    return ''.join(xor(x, y) for x, y in zip(a, b))


# Generated test cases:
import pytest
from typing import List


def string_xor(a: str, b: str) -> str:
    def xor(i, j):
        if i == j:
            return '0'
        else:
            return '1'

    return ''.join(xor(x, y) for x, y in zip(a, b))


@pytest.mark.parametrize("a,b,expected", [
    ('010', '110', '100'),
    ('0', '0', '0'),
    ('1', '1', '0'),
    ('0', '1', '1'),
    ('1', '0', '1'),
    ('000', '000', '000'),
    ('111', '111', '000'),
    ('000', '111', '111'),
    ('111', '000', '111'),
    ('101010', '010101', '111111'),
    ('11111', '00000', '11111'),
    ('00000', '11111', '11111'),
    ('10101', '10101', '00000'),
    ('1010', '0101', '1111'),
    ('0101', '1010', '1111'),
    ('11', '00', '11'),
    ('00', '11', '11'),
    ('10', '01', '11'),
    ('01', '10', '11'),
    ('', '', ''),
    ('1', '0', '1'),
    ('0', '1', '1'),
    ('1111111111', '0000000000', '1111111111'),
    ('0000000000', '1111111111', '1111111111'),
    ('1010101010', '0101010101', '1111111111'),
    ('0101010101', '1010101010', '1111111111'),
])
def test_string_xor(a, b, expected):
    assert string_xor(a, b) == expected


@pytest.mark.parametrize("a,b", [
    ('100', '10'),
    ('10', '100'),
    ('1', '11'),
    ('11', '1'),
    ('', '1'),
    ('1', ''),
    ('10101', '101'),
    ('101', '10101'),
])
def test_string_xor_different_lengths(a, b):
    result = string_xor(a, b)
    assert len(result) == min(len(a), len(b))


def test_string_xor_empty_strings():
    assert string_xor('', '') == ''


def test_string_xor_single_bit():
    assert string_xor('0', '0') == '0'
    assert string_xor('1', '1') == '0'
    assert string_xor('0', '1') == '1'
    assert string_xor('1', '0') == '1'


def test_string_xor_long_strings():
    a = '1' * 1000
    b = '0' * 1000
    expected = '1' * 1000
    assert string_xor(a, b) == expected
    
    a = '1' * 1000
    b = '1' * 1000
    expected = '0' * 1000
    assert string_xor(a, b) == expected
    
    a = '10' * 500
    b = '01' * 500
    expected = '11' * 500
    assert string_xor(a, b) == expected


def test_string_xor_alternating_patterns():
    assert string_xor('101010', '101010') == '000000'
    assert string_xor('010101', '010101') == '000000'
    assert string_xor('101010', '010101') == '111111'
    assert string_xor('010101', '101010') == '111111'
