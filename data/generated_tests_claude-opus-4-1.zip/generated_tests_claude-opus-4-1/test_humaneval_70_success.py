# Test cases for HumanEval/70
# Generated using Claude API


def strange_sort_list(lst):
    '''
    Given list of integers, return list in strange order.
    Strange sorting, is when you start with the minimum value,
    then maximum of the remaining integers, then minimum and so on.

    Examples:
    strange_sort_list([1, 2, 3, 4]) == [1, 4, 2, 3]
    strange_sort_list([5, 5, 5, 5]) == [5, 5, 5, 5]
    strange_sort_list([]) == []
    '''

    res, switch = [], True
    while lst:
        res.append(min(lst) if switch else max(lst))
        lst.remove(res[-1])
        switch = not switch
    return res


# Generated test cases:
import pytest

def strange_sort_list(lst):
    res, switch = [], True
    while lst:
        res.append(min(lst) if switch else max(lst))
        lst.remove(res[-1])
        switch = not switch
    return res

@pytest.mark.parametrize("input_list,expected", [
    ([1, 2, 3, 4], [1, 4, 2, 3]),
    ([5, 5, 5, 5], [5, 5, 5, 5]),
    ([1, 2, 3, 4, 5], [1, 5, 2, 4, 3]),
    ([10, 20, 30], [10, 30, 20]),
    ([1], [1]),
    ([], []),
    ([2, 1], [1, 2]),
    ([-1, -2, -3], [-3, -1, -2]),
    ([0, -1, 1], [-1, 1, 0]),
    ([100, 50, 75, 25], [25, 100, 50, 75]),
    ([3, 3, 3, 1, 1], [1, 3, 1, 3, 3]),
    ([9, 8, 7, 6, 5, 4, 3, 2, 1], [1, 9, 2, 8, 3, 7, 4, 6, 5]),
    ([1, 1, 1, 2, 2, 2], [1, 2, 1, 2, 1, 2]),
    ([-5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5], [-5, 5, -4, 4, -3, 3, -2, 2, -1, 1, 0]),
    ([42], [42]),
    ([10, -10], [-10, 10]),
    ([0, 0, 0], [0, 0, 0]),
    ([1.5, 2.5, 3.5], [1.5, 3.5, 2.5]),
    ([-100, 100, 0], [-100, 100, 0]),
])
def test_strange_sort_list(input_list, expected):
    result = strange_sort_list(input_list.copy())
    assert result == expected

def test_strange_sort_list_does_not_modify_original():
    original = [3, 1, 2]
    copy_original = original.copy()
    strange_sort_list(original)
    assert original != copy_original

def test_strange_sort_list_with_duplicates():
    assert strange_sort_list([5, 2, 3, 2, 5]) == [2, 5, 2, 5, 3]

def test_strange_sort_list_large_range():
    assert strange_sort_list([1000, 1, 500, 250, 750]) == [1, 1000, 250, 750, 500]

def test_strange_sort_list_all_negative():
    assert strange_sort_list([-10, -20, -30, -40]) == [-40, -10, -30, -20]

def test_strange_sort_list_alternating_signs():
    assert strange_sort_list([1, -1, 2, -2, 3, -3]) == [-3, 3, -2, 2, -1, 1]
