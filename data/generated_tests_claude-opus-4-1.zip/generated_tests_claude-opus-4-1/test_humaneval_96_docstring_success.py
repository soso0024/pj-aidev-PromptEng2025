# Test cases for HumanEval/96
# Generated using Claude API


def count_up_to(n):
    """Implement a function that takes an non-negative integer and returns an array of the first n
    integers that are prime numbers and less than n.
    for example:
    count_up_to(5) => [2,3]
    count_up_to(11) => [2,3,5,7]
    count_up_to(0) => []
    count_up_to(20) => [2,3,5,7,11,13,17,19]
    count_up_to(1) => []
    count_up_to(18) => [2,3,5,7,11,13,17]
    """

    primes = []
    for i in range(2, n):
        is_prime = True
        for j in range(2, i):
            if i % j == 0:
                is_prime = False
                break
        if is_prime:
            primes.append(i)
    return primes



# Generated test cases:
import pytest

def count_up_to(n):
    primes = []
    for i in range(2, n):
        is_prime = True
        for j in range(2, i):
            if i % j == 0:
                is_prime = False
                break
        if is_prime:
            primes.append(i)
    return primes


@pytest.mark.parametrize("n,expected", [
    (5, [2, 3]),
    (11, [2, 3, 5, 7]),
    (0, []),
    (20, [2, 3, 5, 7, 11, 13, 17, 19]),
    (1, []),
    (18, [2, 3, 5, 7, 11, 13, 17]),
    (2, []),
    (3, [2]),
    (4, [2, 3]),
    (10, [2, 3, 5, 7]),
    (30, [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]),
    (50, [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]),
    (100, [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]),
])
def test_count_up_to_basic(n, expected):
    assert count_up_to(n) == expected


def test_count_up_to_negative():
    # Assuming function should handle negative numbers gracefully
    assert count_up_to(-1) == []
    assert count_up_to(-10) == []


def test_count_up_to_large_prime():
    result = count_up_to(97)
    assert 97 not in result
    assert all(p < 97 for p in result)
    
    result = count_up_to(98)
    assert 97 in result


def test_count_up_to_type():
    result = count_up_to(10)
    assert isinstance(result, list)
    assert all(isinstance(x, int) for x in result)


def test_count_up_to_order():
    result = count_up_to(20)
    assert result == sorted(result)


def test_count_up_to_uniqueness():
    result = count_up_to(30)
    assert len(result) == len(set(result))


def test_count_up_to_all_primes():
    def is_prime(num):
        if num < 2:
            return False
        for i in range(2, int(num ** 0.5) + 1):
            if num % i == 0:
                return False
        return True
    
    result = count_up_to(50)
    for num in result:
        assert is_prime(num)
    
    for i in range(2, 50):
        if is_prime(i):
            assert i in result
