# Test cases for HumanEval/38
# Generated using Claude API



def encode_cyclic(s: str):
    """
    returns encoded string by cycling groups of three characters.
    """
    # split string to groups. Each of length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # cycle elements in each group. Unless group has fewer elements than 3.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def decode_cyclic(s: str):
    """
    takes as input string encoded with encode_cyclic function. Returns decoded string.
    """

    return encode_cyclic(encode_cyclic(s))


# Generated test cases:
import pytest


def encode_cyclic(s: str):
    """
    returns encoded string by cycling groups of three characters.
    """
    # split string to groups. Each of length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # cycle elements in each group. Unless group has fewer elements than 3.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def decode_cyclic(s: str):
    return encode_cyclic(encode_cyclic(s))


@pytest.mark.parametrize("input_str,expected", [
    ("", ""),
    ("a", "a"),
    ("ab", "ab"),
    ("bca", "abc"),
    ("bcad", "abcd"),
    ("bcade", "abcde"),
    ("bcaefd", "abcdef"),
    ("bcaefdg", "abcdefg"),
    ("bcaefdgh", "abcdefgh"),
    ("bcaefdgih", "abcdefghi"),
])
def test_decode_cyclic_basic(input_str, expected):
    assert decode_cyclic(input_str) == expected


@pytest.mark.parametrize("original", [
    "Hello World!",
    "123456789",
    "The quick brown fox",
    "a" * 100,
    "abc" * 50,
    "!@#$%^&*()",
    "   spaces   ",
    "\t\n\r",
    "MixedCase123!@#",
])
def test_decode_cyclic_reverses_encode(original):
    encoded = encode_cyclic(original)
    decoded = decode_cyclic(encoded)
    assert decoded == original


def test_decode_cyclic_empty_string():
    assert decode_cyclic("") == ""


def test_decode_cyclic_single_char():
    assert decode_cyclic("x") == "x"


def test_decode_cyclic_two_chars():
    assert decode_cyclic("xy") == "xy"


def test_decode_cyclic_three_chars():
    encoded = encode_cyclic("xyz")
    assert decode_cyclic(encoded) == "xyz"


def test_decode_cyclic_unicode():
    test_str = "αβγδεζ"
    encoded = encode_cyclic(test_str)
    assert decode_cyclic(encoded) == test_str


def test_decode_cyclic_special_chars():
    test_str = "!@#$%^&*()_+-=[]{}|;:',.<>?/"
    encoded = encode_cyclic(test_str)
    assert decode_cyclic(encoded) == test_str


def test_decode_cyclic_newlines_tabs():
    test_str = "line1\nline2\ttab\rcarriage"
    encoded = encode_cyclic(test_str)
    assert decode_cyclic(encoded) == test_str


def test_decode_cyclic_repeated_pattern():
    test_str = "abcabcabc"
    encoded = encode_cyclic(test_str)
    assert decode_cyclic(encoded) == test_str


def test_decode_cyclic_long_string():
    test_str = "a" * 1000
    encoded = encode_cyclic(test_str)
    assert decode_cyclic(encoded) == test_str


def test_decode_cyclic_mixed_content():
    test_str = "Hello123!@#World456$%^Test789&*()"
    encoded = encode_cyclic(test_str)
    assert decode_cyclic(encoded) == test_str


@pytest.mark.parametrize("length", [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 99, 100, 101])
def test_decode_cyclic_various_lengths(length):
    test_str = "x" * length
    encoded = encode_cyclic(test_str)
    assert decode_cyclic(encoded) == test_str


def test_decode_cyclic_idempotent():
    test_str = "test string for idempotency"
    encoded = encode_cyclic(test_str)
    decoded = decode_cyclic(encoded)
    assert decoded == test_str