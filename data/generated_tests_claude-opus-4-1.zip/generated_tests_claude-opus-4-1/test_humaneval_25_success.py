# Test cases for HumanEval/25
# Generated using Claude API

from typing import List


def factorize(n: int) -> List[int]:
    """ Return list of prime factors of given integer in the order from smallest to largest.
    Each of the factors should be listed number of times corresponding to how many times it appeares in factorization.
    Input number should be equal to the product of all factors
    >>> factorize(8)
    [2, 2, 2]
    >>> factorize(25)
    [5, 5]
    >>> factorize(70)
    [2, 5, 7]
    """

    import math
    fact = []
    i = 2
    while i <= int(math.sqrt(n) + 1):
        if n % i == 0:
            fact.append(i)
            n //= i
        else:
            i += 1

    if n > 1:
        fact.append(n)
    return fact


# Generated test cases:
import pytest
from typing import List
import math


def factorize(n: int) -> List[int]:
    fact = []
    i = 2
    while i <= int(math.sqrt(n) + 1):
        if n % i == 0:
            fact.append(i)
            n //= i
        else:
            i += 1

    if n > 1:
        fact.append(n)
    return fact


@pytest.mark.parametrize("n,expected", [
    (1, []),
    (2, [2]),
    (3, [3]),
    (4, [2, 2]),
    (5, [5]),
    (6, [2, 3]),
    (7, [7]),
    (8, [2, 2, 2]),
    (9, [3, 3]),
    (10, [2, 5]),
    (12, [2, 2, 3]),
    (15, [3, 5]),
    (16, [2, 2, 2, 2]),
    (17, [17]),
    (18, [2, 3, 3]),
    (20, [2, 2, 5]),
    (24, [2, 2, 2, 3]),
    (25, [5, 5]),
    (27, [3, 3, 3]),
    (30, [2, 3, 5]),
    (36, [2, 2, 3, 3]),
    (49, [7, 7]),
    (50, [2, 5, 5]),
    (60, [2, 2, 3, 5]),
    (100, [2, 2, 5, 5]),
    (121, [11, 11]),
    (128, [2, 2, 2, 2, 2, 2, 2]),
    (169, [13, 13]),
    (210, [2, 3, 5, 7]),
    (256, [2, 2, 2, 2, 2, 2, 2, 2]),
    (361, [19, 19]),
    (420, [2, 2, 3, 5, 7]),
    (1000, [2, 2, 2, 5, 5, 5]),
    (1001, [7, 11, 13]),
    (1024, [2, 2, 2, 2, 2, 2, 2, 2, 2, 2]),
    (2310, [2, 3, 5, 7, 11]),
    (9999, [3, 3, 11, 101]),
    (10000, [2, 2, 2, 2, 5, 5, 5, 5]),
    (10007, [10007]),
    (97, [97]),
    (101, [101]),
    (103, [103]),
    (107, [107]),
    (113, [113]),
    (127, [127]),
    (131, [131]),
    (137, [137]),
    (139, [139]),
    (149, [149])
])
def test_factorize(n, expected):
    assert factorize(n) == expected


def test_factorize_large_prime():
    assert factorize(997) == [997]
    assert factorize(1009) == [1009]
    assert factorize(10007) == [10007]


def test_factorize_perfect_squares():
    assert factorize(4) == [2, 2]
    assert factorize(9) == [3, 3]
    assert factorize(16) == [2, 2, 2, 2]
    assert factorize(25) == [5, 5]
    assert factorize(36) == [2, 2, 3, 3]
    assert factorize(49) == [7, 7]
    assert factorize(64) == [2, 2, 2, 2, 2, 2]
    assert factorize(81) == [3, 3, 3, 3]
    assert factorize(100) == [2, 2, 5, 5]


def test_factorize_powers_of_two():
    assert factorize(2) == [2]
    assert factorize(4) == [2, 2]
    assert factorize(8) == [2, 2, 2]
    assert factorize(16) == [2, 2, 2, 2]
    assert factorize(32) == [2, 2, 2, 2, 2]
    assert factorize(64) == [2, 2, 2, 2, 2, 2]
    assert factorize(128) == [2, 2, 2, 2, 2, 2, 2]
    assert factorize(256) == [2, 2, 2, 2, 2, 2, 2, 2]
    assert factorize(512) == [2, 2, 2, 2, 2, 2, 2, 2, 2]


def test_factorize_product_verification():
    for n in [12, 24, 36, 48, 60, 72, 84, 96, 108, 120, 1000, 5040, 10000]:
        factors = factorize(n)
        product = 1
        for factor in factors:
            product *= factor
        assert product == n
