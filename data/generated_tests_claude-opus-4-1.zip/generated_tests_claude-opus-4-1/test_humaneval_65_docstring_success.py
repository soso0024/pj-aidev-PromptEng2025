# Test cases for HumanEval/65
# Generated using Claude API


def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.
    >>> circular_shift(12, 1)
    "21"
    >>> circular_shift(12, 2)
    "12"
    """

    s = str(x)
    if shift > len(s):
        return s[::-1]
    else:
        return s[len(s) - shift:] + s[:len(s) - shift]


# Generated test cases:
import pytest

def circular_shift(x, shift):
    s = str(x)
    if shift > len(s):
        return s[::-1]
    else:
        return s[len(s) - shift:] + s[:len(s) - shift]


@pytest.mark.parametrize("x,shift,expected", [
    (12, 1, "21"),
    (12, 2, "12"),
    (123, 1, "312"),
    (123, 2, "231"),
    (123, 3, "123"),
    (123, 4, "321"),
    (123, 5, "321"),
    (123, 100, "321"),
    (1, 1, "1"),
    (1, 0, "1"),
    (1, 2, "1"),
    (12345, 0, "12345"),
    (12345, 1, "51234"),
    (12345, 2, "45123"),
    (12345, 3, "34512"),
    (12345, 4, "23451"),
    (12345, 5, "12345"),
    (12345, 6, "54321"),
    (9876543210, 1, "0987654321"),
    (9876543210, 5, "4321098765"),
    (9876543210, 10, "9876543210"),
    (9876543210, 11, "0123456789"),
    (100, 1, "010"),
    (100, 2, "001"),
    (100, 3, "100"),
    (100, 4, "001"),
    (1000, 1, "0100"),
    (1000, 2, "0010"),
    (1000, 3, "0001"),
    (1000, 4, "1000"),
    (1000, 5, "0001"),
    (0, 0, "0"),
    (0, 1, "0"),
    (0, 2, "0"),
    (10, 1, "01"),
    (10, 2, "10"),
    (10, 3, "01"),
])
def test_circular_shift(x, shift, expected):
    assert circular_shift(x, shift) == expected


def test_circular_shift_large_numbers():
    assert circular_shift(123456789, 0) == "123456789"
    assert circular_shift(123456789, 9) == "123456789"
    assert circular_shift(123456789, 10) == "987654321"


def test_circular_shift_single_digit():
    for i in range(10):
        assert circular_shift(i, 0) == str(i)
        assert circular_shift(i, 1) == str(i)
        assert circular_shift(i, 10) == str(i)