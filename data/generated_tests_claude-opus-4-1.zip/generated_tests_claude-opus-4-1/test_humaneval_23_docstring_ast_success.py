# Test cases for HumanEval/23
# Generated using Claude API



def strlen(string: str) -> int:
    """ Return length of given string
    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """

    return len(string)


# Generated test cases:
import pytest


def strlen(string: str) -> int:
    return len(string)


class TestStrlen:
    
    @pytest.mark.parametrize("input_string,expected", [
        ("", 0),
        ("a", 1),
        ("ab", 2),
        ("abc", 3),
        ("hello", 5),
        ("hello world", 11),
        ("   ", 3),
        ("\t\n", 2),
        ("12345", 5),
        ("!@#$%", 5),
        ("Hello, World!", 13),
        ("a" * 100, 100),
        ("a" * 1000, 1000),
        ("\n\r\t", 3),
        ("🙂", 1),
        ("🙂😀", 2),
        ("Hello\nWorld", 11),
        ("Hello\tWorld", 11),
        ("Hello\\nWorld", 12),
        ('single quotes', 13),
        ('"double quotes"', 15),
        ("'mixed' \"quotes\"", 16),
        ("line1\nline2\nline3", 17),
        (" leading", 8),
        ("trailing ", 9),
        (" both ", 6),
        ("0", 1),
        ("", 0),
        ("_underscore_", 12),
        ("CamelCase", 9),
        ("snake_case", 10),
        ("kebab-case", 10),
        ("dot.notation", 12),
        ("path/to/file", 12),
        ("email@example.com", 17),
        ("http://example.com", 18),
        ("one\ttab", 7),
        ("two\t\ttabs", 9),
        ("mixed\t \nspaces", 14),
    ])
    def test_strlen_various_strings(self, input_string, expected):
        assert strlen(input_string) == expected
    
    def test_strlen_empty_string(self):
        assert strlen("") == 0
    
    def test_strlen_single_character(self):
        assert strlen("x") == 1
    
    def test_strlen_unicode_characters(self):
        assert strlen("café") == 4
        assert strlen("日本語") == 3
        assert strlen("Здравствуй") == 10
        assert strlen("مرحبا") == 5
    
    def test_strlen_special_characters(self):
        assert strlen("\0") == 1
        assert strlen("\x00") == 1
        assert strlen("\u0000") == 1
    
    def test_strlen_multiline_string(self):
        multiline = """This is
a multiline
string"""
        assert strlen(multiline) == 26
    
    def test_strlen_raw_string(self):
        raw = r"C:\Users\test\file.txt"
        assert strlen(raw) == 22
    
    def test_strlen_repeated_characters(self):
        assert strlen("aaaa") == 4
        assert strlen("1111") == 4
        assert strlen("    ") == 4
    
    def test_strlen_mixed_content(self):
        assert strlen("abc123!@#") == 9
        assert strlen("MiXeD cAsE 123") == 14
    
    def test_strlen_escape_sequences(self):
        assert strlen("\\") == 1
        assert strlen("\\\\") == 2
        assert strlen("\\n") == 2
        assert strlen("\\'") == 2
        assert strlen('\\"') == 2