# Test cases for HumanEval/39
# Generated using Claude API



def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """

    import math

    def is_prime(p):
        if p < 2:
            return False
        for k in range(2, min(int(math.sqrt(p)) + 1, p - 1)):
            if p % k == 0:
                return False
        return True
    f = [0, 1]
    while True:
        f.append(f[-1] + f[-2])
        if is_prime(f[-1]):
            n -= 1
        if n == 0:
            return f[-1]


# Generated test cases:
import pytest

def prime_fib(n: int):
    import math

    def is_prime(p):
        if p < 2:
            return False
        for k in range(2, min(int(math.sqrt(p)) + 1, p - 1)):
            if p % k == 0:
                return False
        return True
    f = [0, 1]
    while True:
        f.append(f[-1] + f[-2])
        if is_prime(f[-1]):
            n -= 1
        if n == 0:
            return f[-1]


@pytest.mark.parametrize("n,expected", [
    (1, 2),
    (2, 3),
    (3, 5),
    (4, 13),
    (5, 89),
    (6, 233),
    (7, 1597),
    (8, 28657),
    (9, 514229),
])
def test_prime_fib_basic(n, expected):
    assert prime_fib(n) == expected


def test_prime_fib_first_ten():
    expected_values = [2, 3, 5, 13, 89, 233, 1597, 28657, 514229, 433494437]
    for i, expected in enumerate(expected_values, 1):
        assert prime_fib(i) == expected


def test_prime_fib_single_values():
    assert prime_fib(1) == 2
    assert prime_fib(2) == 3
    assert prime_fib(3) == 5
    assert prime_fib(4) == 13
    assert prime_fib(5) == 89


def test_prime_fib_larger_values():
    assert prime_fib(10) == 433494437


def test_prime_fib_sequence_properties():
    # Test that results are increasing
    prev = prime_fib(1)
    for i in range(2, 8):
        curr = prime_fib(i)
        assert curr > prev
        prev = curr


def test_prime_fib_primality():
    def is_prime(n):
        if n < 2:
            return False
        for i in range(2, int(n**0.5) + 1):
            if n % i == 0:
                return False
        return True
    
    for i in range(1, 8):
        result = prime_fib(i)
        assert is_prime(result)


def test_prime_fib_fibonacci_property():
    def is_fibonacci(n):
        a, b = 0, 1
        while b < n:
            a, b = b, a + b
        return b == n or n == 0
    
    for i in range(1, 8):
        result = prime_fib(i)
        assert is_fibonacci(result)
