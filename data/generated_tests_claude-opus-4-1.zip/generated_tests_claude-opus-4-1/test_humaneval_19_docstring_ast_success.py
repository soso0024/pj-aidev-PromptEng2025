# Test cases for HumanEval/19
# Generated using Claude API

from typing import List


def sort_numbers(numbers: str) -> str:
    """ Input is a space-delimited string of numberals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight' and 'nine'.
    Return the string with numbers sorted from smallest to largest
    >>> sort_numbers('three one five')
    'one three five'
    """

    value_map = {
        'zero': 0,
        'one': 1,
        'two': 2,
        'three': 3,
        'four': 4,
        'five': 5,
        'six': 6,
        'seven': 7,
        'eight': 8,
        'nine': 9
    }
    return ' '.join(sorted([x for x in numbers.split(' ') if x], key=lambda x: value_map[x]))


# Generated test cases:
import pytest


def sort_numbers(numbers: str) -> str:
    value_map = {
        'zero': 0,
        'one': 1,
        'two': 2,
        'three': 3,
        'four': 4,
        'five': 5,
        'six': 6,
        'seven': 7,
        'eight': 8,
        'nine': 9
    }
    return ' '.join(sorted([x for x in numbers.split(' ') if x], key=lambda x: value_map[x]))


@pytest.mark.parametrize("input_str,expected", [
    ("three one five", "one three five"),
    ("zero nine eight seven six five four three two one", "zero one two three four five six seven eight nine"),
    ("one", "one"),
    ("nine eight seven", "seven eight nine"),
    ("five five five", "five five five"),
    ("two one zero", "zero one two"),
    ("nine zero", "zero nine"),
    ("", ""),
    ("zero", "zero"),
    ("nine", "nine"),
    ("one two three four five six seven eight nine zero", "zero one two three four five six seven eight nine"),
    ("three three one one", "one one three three"),
    ("six four two eight", "two four six eight"),
    ("seven three nine one five", "one three five seven nine"),
    ("eight eight eight", "eight eight eight"),
    ("four two six", "two four six"),
    ("nine five one", "one five nine"),
    ("zero zero zero", "zero zero zero"),
    ("five four three two one", "one two three four five"),
    ("nine eight seven six five four three two one zero", "zero one two three four five six seven eight nine"),
])
def test_sort_numbers(input_str, expected):
    assert sort_numbers(input_str) == expected


def test_sort_numbers_empty_string():
    assert sort_numbers("") == ""


def test_sort_numbers_single_number():
    assert sort_numbers("five") == "five"
    assert sort_numbers("zero") == "zero"
    assert sort_numbers("nine") == "nine"


def test_sort_numbers_duplicates():
    assert sort_numbers("one one one") == "one one one"
    assert sort_numbers("five two five two") == "two two five five"


def test_sort_numbers_all_numbers():
    all_nums = "zero one two three four five six seven eight nine"
    assert sort_numbers(all_nums) == all_nums
    
    reverse_nums = "nine eight seven six five four three two one zero"
    assert sort_numbers(reverse_nums) == all_nums


def test_sort_numbers_random_order():
    assert sort_numbers("five three eight one nine zero two seven four six") == "zero one two three four five six seven eight nine"
    assert sort_numbers("three seven one") == "one three seven"
    assert sort_numbers("eight two five") == "two five eight"


def test_sort_numbers_pairs():
    assert sort_numbers("one zero") == "zero one"
    assert sort_numbers("nine eight") == "eight nine"
    assert sort_numbers("five four") == "four five"


def test_sort_numbers_with_extra_spaces():
    assert sort_numbers("three  one  five") == "one three five"
    assert sort_numbers("  two  four  ") == "two four"
