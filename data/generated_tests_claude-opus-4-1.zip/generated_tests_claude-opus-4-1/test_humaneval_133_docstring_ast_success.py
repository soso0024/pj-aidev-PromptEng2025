# Test cases for HumanEval/133
# Generated using Claude API



def sum_squares(lst):
    """You are given a list of numbers.
    You need to return the sum of squared numbers in the given list,
    round each element in the list to the upper int(Ceiling) first.
    Examples:
    For lst = [1,2,3] the output should be 14
    For lst = [1,4,9] the output should be 98
    For lst = [1,3,5,7] the output should be 84
    For lst = [1.4,4.2,0] the output should be 29
    For lst = [-2.4,1,1] the output should be 6
    

    """

    import math
    squared = 0
    for i in lst:
        squared += math.ceil(i)**2
    return squared


# Generated test cases:
import pytest
import math

def sum_squares(lst):
    squared = 0
    for i in lst:
        squared += math.ceil(i)**2
    return squared

@pytest.mark.parametrize("lst,expected", [
    ([1, 2, 3], 14),
    ([1, 4, 9], 98),
    ([1, 3, 5, 7], 84),
    ([1.4, 4.2, 0], 29),
    ([-2.4, 1, 1], 6),
    ([], 0),
    ([0], 0),
    ([0.1], 1),
    ([0.9], 1),
    ([1.1], 4),
    ([-1], 1),
    ([-1.1], 1),
    ([-1.9], 1),
    ([-2], 4),
    ([-2.1], 4),
    ([0.5, 0.5, 0.5], 3),
    ([2.5, 3.5, 4.5], 50),
    ([-0.1], 0),
    ([-0.9], 0),
    ([100], 10000),
    ([10.1, 20.2, 30.3], 1523),
    ([-10.1, -20.2, -30.3], 1400),
    ([1.0000001], 4),
    ([0.9999999], 1),
    ([-0.0000001], 0),
    ([1e-10], 1),
    ([-1e-10], 0),
    ([1.5, -1.5, 2.5, -2.5], 18),
    ([999.9], 1000000),
    ([-999.9], 998001),
])
def test_sum_squares(lst, expected):
    assert sum_squares(lst) == expected

def test_sum_squares_with_infinity():
    with pytest.raises(OverflowError):
        sum_squares([float('inf')])
    with pytest.raises(OverflowError):
        sum_squares([-float('inf')])

def test_sum_squares_with_nan():
    with pytest.raises(ValueError):
        sum_squares([float('nan')])

def test_sum_squares_large_list():
    lst = [1.5] * 1000
    expected = 4000
    assert sum_squares(lst) == expected

def test_sum_squares_alternating_signs():
    lst = [1, -1, 2, -2, 3, -3]
    expected = 28
    assert sum_squares(lst) == expected

def test_sum_squares_very_small_numbers():
    lst = [1e-100, 2e-100, 3e-100]
    expected = 3
    assert sum_squares(lst) == expected

def test_sum_squares_mixed_integers_floats():
    lst = [1, 1.0, 1.1, 1.9, 2, 2.0]
    expected = 18
    assert sum_squares(lst) == expected