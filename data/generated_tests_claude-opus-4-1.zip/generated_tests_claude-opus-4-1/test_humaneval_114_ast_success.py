# Test cases for HumanEval/114
# Generated using Claude API


def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """

    max_sum = 0
    s = 0
    for num in nums:
        s += -num
        if (s < 0):
            s = 0
        max_sum = max(s, max_sum)
    if max_sum == 0:
        max_sum = max(-i for i in nums)
    min_sum = -max_sum
    return min_sum


# Generated test cases:
import pytest


@pytest.mark.parametrize("nums,expected", [
    # Single element
    ([1], 1),
    ([-1], -1),
    ([0], 0),
    ([5], 5),
    ([-5], -5),
    
    # Two elements
    ([1, 2], 1),
    ([-1, -2], -3),
    ([1, -2], -2),
    ([-1, 2], -1),
    ([0, 0], 0),
    
    # All positive
    ([1, 2, 3, 4], 1),
    ([5, 10, 15], 5),
    ([100, 200, 300], 100),
    
    # All negative
    ([-1, -2, -3], -6),
    ([-5, -10, -15], -30),
    ([-100, -200, -300], -600),
    
    # Mixed positive and negative
    ([1, -2, 3, -4, 5], -4),
    ([-1, 2, -3, 4, -5], -5),
    ([10, -20, 30, -40, 50], -40),
    
    # Contains zeros
    ([0, 1, 2, 3], 0),
    ([0, -1, -2, -3], -6),
    ([1, 0, -2, 0, 3], -2),
    ([0, 0, 0, 0], 0),
    
    # Subarray sums
    ([2, -5, 1, -4, 3, -2], -8),
    ([1, 2, -5, -2, 3], -7),
    ([-2, 1, -3, 4, -1, 2, 1, -5, 4], -5),
    
    # Large numbers
    ([1000, -2000, 3000, -4000], -4000),
    ([-1000, -2000, -3000], -6000),
    ([10000, 20000, 30000], 10000),
    
    # Alternating signs
    ([1, -1, 1, -1, 1], -1),
    ([-1, 1, -1, 1, -1], -1),
    ([2, -3, 4, -5, 6], -5),
    
    # Edge cases with specific patterns
    ([5, -3, 5], -3),
    ([-5, 3, -5], -7),
    ([1, 2, 3, -10, 4, 5], -10),
    ([10, -5, -6, 3], -11),
    
    # Longer arrays
    ([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 1),
    ([-1, -2, -3, -4, -5, -6, -7, -8, -9, -10], -55),
    ([1, -2, 3, -4, 5, -6, 7, -8, 9, -10], -10),
    
    # Arrays where minimum subarray is in the middle
    ([10, -20, -30, 10], -50),
    ([5, -10, -20, -30, 5], -60),
    ([100, -50, -60, -70, 100], -180),
])
def test_minSubArraySum(nums, expected):
    assert minSubArraySum(nums) == expected


def test_minSubArraySum_empty():
    with pytest.raises(ValueError):
        max(-i for i in [])


@pytest.mark.parametrize("nums", [
    [1, 2, None],
    None,
    "string",
    123,
])
def test_minSubArraySum_invalid_input(nums):
    with pytest.raises((TypeError, AttributeError)):
        minSubArraySum(nums)


def test_minSubArraySum_floats():
    # The function works with floats, so test it separately
    assert minSubArraySum([1.5, 2.5, 3.5]) == 1.5
    assert minSubArraySum([-1.5, -2.5, -3.5]) == -7.5