# Test cases for HumanEval/21
# Generated using Claude API

from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    """ Given list of numbers (of at least two elements), apply a linear transform to that list,
    such that the smallest number will become 0 and the largest will become 1
    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.25, 0.5, 0.75, 1.0]
    """

    min_number = min(numbers)
    max_number = max(numbers)
    return [(x - min_number) / (max_number - min_number) for x in numbers]


# Generated test cases:
import pytest
from typing import List
import math


def rescale_to_unit(numbers: List[float]) -> List[float]:
    min_number = min(numbers)
    max_number = max(numbers)
    return [(x - min_number) / (max_number - min_number) for x in numbers]


class TestRescaleToUnit:
    
    def test_basic_positive_numbers(self):
        result = rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
        expected = [0.0, 0.25, 0.5, 0.75, 1.0]
        assert result == expected
    
    def test_negative_numbers(self):
        result = rescale_to_unit([-5.0, -3.0, -1.0])
        expected = [0.0, 0.5, 1.0]
        assert result == expected
    
    def test_mixed_positive_negative(self):
        result = rescale_to_unit([-2.0, 0.0, 2.0])
        expected = [0.0, 0.5, 1.0]
        assert result == expected
    
    def test_already_unit_interval(self):
        result = rescale_to_unit([0.0, 0.5, 1.0])
        expected = [0.0, 0.5, 1.0]
        assert result == expected
    
    def test_single_value_repeated(self):
        with pytest.raises(ZeroDivisionError):
            rescale_to_unit([5.0, 5.0, 5.0])
    
    def test_two_distinct_values(self):
        result = rescale_to_unit([10.0, 20.0, 10.0, 20.0])
        expected = [0.0, 1.0, 0.0, 1.0]
        assert result == expected
    
    def test_large_range(self):
        result = rescale_to_unit([0.0, 100.0, 50.0])
        expected = [0.0, 1.0, 0.5]
        assert result == expected
    
    def test_decimal_values(self):
        result = rescale_to_unit([0.1, 0.2, 0.3, 0.4])
        expected = [0.0, 1/3, 2/3, 1.0]
        for r, e in zip(result, expected):
            assert math.isclose(r, e, rel_tol=1e-9)
    
    def test_single_element(self):
        with pytest.raises(ZeroDivisionError):
            rescale_to_unit([42.0])
    
    def test_empty_list(self):
        with pytest.raises(ValueError):
            rescale_to_unit([])
    
    @pytest.mark.parametrize("numbers,expected", [
        ([0.0, 1.0], [0.0, 1.0]),
        ([5.0, 10.0], [0.0, 1.0]),
        ([100.0, 200.0, 150.0], [0.0, 1.0, 0.5]),
        ([-10.0, -5.0, 0.0], [0.0, 0.5, 1.0]),
    ])
    def test_parametrized_cases(self, numbers, expected):
        result = rescale_to_unit(numbers)
        assert result == expected
    
    def test_very_small_differences(self):
        result = rescale_to_unit([1.0, 1.0001, 1.0002])
        expected = [0.0, 0.5, 1.0]
        for r, e in zip(result, expected):
            assert math.isclose(r, e, rel_tol=1e-9)
    
    def test_order_preservation(self):
        input_list = [3.0, 1.0, 4.0, 1.0, 5.0, 9.0, 2.0]
        result = rescale_to_unit(input_list)
        assert len(result) == len(input_list)
        assert min(result) == 0.0
        assert max(result) == 1.0
        for i in range(len(input_list) - 1):
            if input_list[i] < input_list[i+1]:
                assert result[i] < result[i+1]
            elif input_list[i] > input_list[i+1]:
                assert result[i] > result[i+1]
            else:
                assert result[i] == result[i+1]
