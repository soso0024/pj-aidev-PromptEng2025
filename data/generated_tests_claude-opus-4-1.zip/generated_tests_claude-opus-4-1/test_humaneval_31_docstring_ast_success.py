# Test cases for HumanEval/31
# Generated using Claude API



def is_prime(n):
    """Return true if a given number is prime, and false otherwise.
    >>> is_prime(6)
    False
    >>> is_prime(101)
    True
    >>> is_prime(11)
    True
    >>> is_prime(13441)
    True
    >>> is_prime(61)
    True
    >>> is_prime(4)
    False
    >>> is_prime(1)
    False
    """

    if n < 2:
        return False
    for k in range(2, n - 1):
        if n % k == 0:
            return False
    return True


# Generated test cases:
import pytest

def is_prime(n):
    if n < 2:
        return False
    for k in range(2, n - 1):
        if n % k == 0:
            return False
    return True

@pytest.mark.parametrize("n,expected", [
    (6, False),
    (101, True),
    (11, True),
    (13441, True),
    (61, True),
    (4, False),
    (1, False),
    (0, False),
    (-1, False),
    (-5, False),
    (2, True),
    (3, True),
    (5, True),
    (7, True),
    (9, False),
    (10, False),
    (13, True),
    (15, False),
    (17, True),
    (19, True),
    (20, False),
    (23, True),
    (25, False),
    (29, True),
    (31, True),
    (37, True),
    (41, True),
    (43, True),
    (47, True),
    (49, False),
    (53, True),
    (59, True),
    (67, True),
    (71, True),
    (73, True),
    (79, True),
    (83, True),
    (89, True),
    (97, True),
    (100, False),
    (121, False),
    (169, False),
    (197, True),
    (199, True),
    (200, False),
    (997, True),
    (1000, False),
    (1009, True),
])
def test_is_prime(n, expected):
    assert is_prime(n) == expected

def test_is_prime_negative_numbers():
    for n in range(-100, 0):
        assert is_prime(n) == False

def test_is_prime_small_composites():
    composites = [4, 6, 8, 9, 10, 12, 14, 15, 16, 18, 20, 21, 22, 24, 25, 26, 27, 28, 30]
    for n in composites:
        assert is_prime(n) == False

def test_is_prime_small_primes():
    primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]
    for n in primes:
        assert is_prime(n) == True

def test_is_prime_perfect_squares():
    perfect_squares = [4, 9, 16, 25, 36, 49, 64, 81, 100, 121, 144, 169, 196, 225]
    for n in perfect_squares:
        assert is_prime(n) == False
