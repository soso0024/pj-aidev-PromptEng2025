# Test cases for HumanEval/125
# Generated using Claude API


def split_words(txt):
    '''
    Given a string of words, return a list of words split on whitespace, if no whitespaces exists in the text you
    should split on commas ',' if no commas exists you should return the number of lower-case letters with odd order in the
    alphabet, ord('a') = 0, ord('b') = 1, ... ord('z') = 25
    Examples
    split_words("Hello world!") ➞ ["Hello", "world!"]
    split_words("Hello,world!") ➞ ["Hello", "world!"]
    split_words("abcdef") == 3 
    '''

    if " " in txt:
        return txt.split()
    elif "," in txt:
        return txt.replace(',',' ').split()
    else:
        return len([i for i in txt if i.islower() and ord(i)%2 == 0])


# Generated test cases:
import pytest

def split_words(txt):
    if " " in txt:
        return txt.split()
    elif "," in txt:
        return txt.replace(',',' ').split()
    else:
        return len([i for i in txt if i.islower() and ord(i)%2 == 0])


@pytest.mark.parametrize("input_txt,expected", [
    # Test cases with spaces
    ("Hello world!", ["Hello", "world!"]),
    ("one two three", ["one", "two", "three"]),
    ("  multiple   spaces  ", ["multiple", "spaces"]),
    ("a b c d", ["a", "b", "c", "d"]),
    
    # Test cases with commas (no spaces)
    ("Hello,world!", ["Hello", "world!"]),
    ("one,two,three", ["one", "two", "three"]),
    ("a,b,c", ["a", "b", "c"]),
    ("first,second", ["first", "second"]),
    
    # Test cases with both spaces and commas (spaces take precedence)
    ("Hello, world!", ["Hello,", "world!"]),
    ("one, two, three", ["one,", "two,", "three"]),
    
    # Test cases with no spaces or commas - count lowercase letters with odd order in alphabet
    # The function counts lowercase letters where ord(letter) % 2 == 0 (even ASCII values)
    ("abcdef", 3),  # b(98), d(100), f(102) have even ASCII
    ("bdf", 3),  # b(98), d(100), f(102) all have even ASCII
    ("ace", 0),  # a(97), c(99), e(101) all have odd ASCII
    ("", 0),  # empty string
    ("ABCDEF", 0),  # no lowercase letters
    ("AbCdEf", 3),  # b(98), d(100), f(102) have even ASCII
    ("z", 1),  # z(122) has even ASCII
    ("y", 0),  # y(121) has odd ASCII
    ("aaa", 0),  # a(97) has odd ASCII
    
    # Edge cases
    ("123456", 0),  # only numbers
    ("!@#$%^", 0),  # only special characters
    ("Hello123", 2),  # e(101) odd, l(108) even, l(108) even, o(111) odd = 2 even
    ("hello", 3),  # h(104) even, e(101) odd, l(108) even, l(108) even, o(111) odd = 3 even
    
    # Single character cases
    ("a", 0),  # a(97) has odd ASCII
    ("b", 1),  # b(98) has even ASCII
    (" ", []),  # single space
    (",", []),  # single comma
    
    # Multiple commas
    (",,hello,,world,,", ["hello", "world"]),  # replace commas with spaces and split removes empty strings
    ("a,,b", ["a", "b"]),  # replace commas with spaces and split removes empty strings
])
def test_split_words(input_txt, expected):
    assert split_words(input_txt) == expected


def test_split_words_priority():
    # Test that spaces have priority over commas
    assert split_words("a b,c") == ["a", "b,c"]
    assert split_words("a, b, c") == ["a,", "b,", "c"]


def test_split_words_lowercase_counting():
    # Verify the counting logic for lowercase letters with even ASCII values
    # The function counts based on ord(char) % 2 == 0
    assert split_words("abcdefghijklmnopqrstuvwxyz") == 13
    # Even ASCII: b(98), d(100), f(102), h(104), j(106), l(108), n(110), p(112), r(114), t(116), v(118), x(120), z(122)