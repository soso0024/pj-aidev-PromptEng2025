# Test cases for HumanEval/24
# Generated using Claude API



def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    >>> largest_divisor(15)
    5
    """

    for i in reversed(range(n)):
        if n % i == 0:
            return i


# Generated test cases:
import pytest

def largest_divisor(n: int) -> int:
    for i in reversed(range(n)):
        if n % i == 0:
            return i

@pytest.mark.parametrize("n,expected", [
    (15, 5),
    (12, 6),
    (10, 5),
    (9, 3),
    (8, 4),
    (7, 1),
    (6, 3),
    (5, 1),
    (4, 2),
    (3, 1),
    (2, 1),
    (100, 50),
    (99, 33),
    (97, 1),
    (16, 8),
    (25, 5),
    (49, 7),
    (121, 11),
    (1000, 500),
    (17, 1),
    (13, 1),
    (11, 1),
])
def test_largest_divisor_normal_cases(n, expected):
    assert largest_divisor(n) == expected

def test_largest_divisor_prime_numbers():
    primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]
    for prime in primes:
        assert largest_divisor(prime) == 1

def test_largest_divisor_perfect_squares():
    assert largest_divisor(4) == 2
    assert largest_divisor(9) == 3
    assert largest_divisor(16) == 8
    assert largest_divisor(25) == 5
    assert largest_divisor(36) == 18
    assert largest_divisor(49) == 7
    assert largest_divisor(64) == 32
    assert largest_divisor(81) == 27
    assert largest_divisor(100) == 50

def test_largest_divisor_even_numbers():
    assert largest_divisor(2) == 1
    assert largest_divisor(4) == 2
    assert largest_divisor(6) == 3
    assert largest_divisor(8) == 4
    assert largest_divisor(10) == 5
    assert largest_divisor(20) == 10
    assert largest_divisor(50) == 25
    assert largest_divisor(100) == 50

def test_largest_divisor_powers_of_two():
    assert largest_divisor(2) == 1
    assert largest_divisor(4) == 2
    assert largest_divisor(8) == 4
    assert largest_divisor(16) == 8
    assert largest_divisor(32) == 16
    assert largest_divisor(64) == 32
    assert largest_divisor(128) == 64
    assert largest_divisor(256) == 128
