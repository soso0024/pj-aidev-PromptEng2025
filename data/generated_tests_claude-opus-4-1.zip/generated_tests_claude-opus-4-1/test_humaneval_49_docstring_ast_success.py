# Test cases for HumanEval/49
# Generated using Claude API



def modp(n: int, p: int):
    """Return 2^n modulo p (be aware of numerics).
    >>> modp(3, 5)
    3
    >>> modp(1101, 101)
    2
    >>> modp(0, 101)
    1
    >>> modp(3, 11)
    8
    >>> modp(100, 101)
    1
    """

    ret = 1
    for i in range(n):
        ret = (2 * ret) % p
    return ret


# Generated test cases:
import pytest


@pytest.mark.parametrize("n,p,expected", [
    (3, 5, 3),
    (1101, 101, 2),
    (0, 101, 1),
    (3, 11, 8),
    (100, 101, 1),
    (1, 2, 0),
    (1, 3, 2),
    (2, 3, 1),
    (4, 7, 2),
    (5, 7, 4),
    (10, 13, 10),
    (0, 1, 1),
    (1, 1, 0),
    (1000, 1, 0),
    (0, 2, 1),
    (1, 5, 2),
    (2, 5, 4),
    (4, 5, 1),
    (5, 5, 2),
    (6, 5, 4),
    (0, 1000000007, 1),
    (1000, 1000000007, 688423210),
    (15, 17, 9),
    (16, 17, 1),
    (17, 17, 2),
    (0, 3, 1),
    (50, 97, 4),
    (100, 97, 16),
    (200, 97, 62),
    (1000000, 7, 2),
    (1000001, 7, 4),
    (1000002, 7, 1),
])
def test_modp(n, p, expected):
    assert modp(n, p) == expected


def test_modp_large_n():
    assert modp(10000, 1009) == 955


def test_modp_power_of_two_modulus():
    assert modp(3, 8) == 0
    assert modp(2, 4) == 0
    assert modp(1, 2) == 0


def test_modp_prime_modulus():
    assert modp(10, 23) == 12
    assert modp(22, 23) == 1
    assert modp(23, 23) == 2


def test_modp_fermat_little_theorem():
    # For prime p, 2^(p-1) ≡ 1 (mod p) when gcd(2,p)=1
    assert modp(4, 5) == 1
    assert modp(10, 11) == 1
    assert modp(12, 13) == 1
    assert modp(16, 17) == 1