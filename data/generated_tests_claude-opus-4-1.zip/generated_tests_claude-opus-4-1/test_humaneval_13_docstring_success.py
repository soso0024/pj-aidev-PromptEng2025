# Test cases for HumanEval/13
# Generated using Claude API



def greatest_common_divisor(a: int, b: int) -> int:
    """ Return a greatest common divisor of two integers a and b
    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """

    while b:
        a, b = b, a % b
    return a


# Generated test cases:
import pytest

def greatest_common_divisor(a: int, b: int) -> int:
    while b:
        a, b = b, a % b
    return abs(a)

@pytest.mark.parametrize("a,b,expected", [
    (3, 5, 1),
    (25, 15, 5),
    (48, 18, 6),
    (100, 50, 50),
    (17, 19, 1),
    (0, 5, 5),
    (5, 0, 5),
    (0, 0, 0),
    (1, 1, 1),
    (2, 2, 2),
    (12, 8, 4),
    (8, 12, 4),
    (1071, 462, 21),
    (270, 192, 6),
    (1, 100, 1),
    (100, 1, 1),
    (-10, 5, 5),
    (10, -5, 5),
    (-10, -5, 5),
    (-48, -18, 6),
    (-48, 18, 6),
    (48, -18, 6),
    (1000000, 500000, 500000),
    (123456, 789012, 12),
    (2**10, 2**8, 2**8),
    (3**5, 3**3, 3**3),
    (13*17, 13*19, 13),
    (7*11*13, 7*11*17, 7*11),
])
def test_greatest_common_divisor(a, b, expected):
    assert greatest_common_divisor(a, b) == expected

def test_greatest_common_divisor_commutative():
    assert greatest_common_divisor(24, 36) == greatest_common_divisor(36, 24)
    assert greatest_common_divisor(100, 75) == greatest_common_divisor(75, 100)
    assert greatest_common_divisor(17, 31) == greatest_common_divisor(31, 17)

def test_greatest_common_divisor_with_prime_numbers():
    assert greatest_common_divisor(2, 3) == 1
    assert greatest_common_divisor(5, 7) == 1
    assert greatest_common_divisor(11, 13) == 1
    assert greatest_common_divisor(23, 29) == 1

def test_greatest_common_divisor_with_same_number():
    assert greatest_common_divisor(42, 42) == 42
    assert greatest_common_divisor(100, 100) == 100
    assert greatest_common_divisor(1, 1) == 1

def test_greatest_common_divisor_with_multiples():
    assert greatest_common_divisor(10, 20) == 10
    assert greatest_common_divisor(15, 45) == 15
    assert greatest_common_divisor(7, 21) == 7
    assert greatest_common_divisor(100, 200) == 100

def test_greatest_common_divisor_large_numbers():
    assert greatest_common_divisor(1234567890, 987654321) == 9
    assert greatest_common_divisor(2**20, 2**15) == 2**15
    assert greatest_common_divisor(10**9, 10**6) == 10**6