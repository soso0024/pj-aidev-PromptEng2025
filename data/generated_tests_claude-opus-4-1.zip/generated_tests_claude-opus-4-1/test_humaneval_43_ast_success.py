# Test cases for HumanEval/43
# Generated using Claude API



def pairs_sum_to_zero(l):
    """
    pairs_sum_to_zero takes a list of integers as an input.
    it returns True if there are two distinct elements in the list that
    sum to zero, and False otherwise.
    >>> pairs_sum_to_zero([1, 3, 5, 0])
    False
    >>> pairs_sum_to_zero([1, 3, -2, 1])
    False
    >>> pairs_sum_to_zero([1, 2, 3, 7])
    False
    >>> pairs_sum_to_zero([2, 4, -5, 3, 5, 7])
    True
    >>> pairs_sum_to_zero([1])
    False
    """

    for i, l1 in enumerate(l):
        for j in range(i + 1, len(l)):
            if l1 + l[j] == 0:
                return True
    return False


# Generated test cases:
import pytest

def pairs_sum_to_zero(l):
    for i, l1 in enumerate(l):
        for j in range(i + 1, len(l)):
            if l1 + l[j] == 0:
                return True
    return False


@pytest.mark.parametrize("input_list,expected", [
    # Basic cases with pairs that sum to zero
    ([1, -1], True),
    ([2, -2, 3], True),
    ([5, -5, 0], True),
    ([-3, 3, 1, 2], True),
    ([10, -10, 5, -5], True),
    
    # Cases without pairs that sum to zero
    ([1, 2, 3], False),
    ([5, 5, 5], False),
    ([-1, -2, -3], False),
    ([1, 3, 5, 7], False),
    
    # Edge cases
    ([], False),
    ([0], False),
    ([1], False),
    ([0, 0], True),
    
    # Multiple zeros
    ([0, 0, 0], True),
    ([1, 0, 0, 2], True),
    
    # Large numbers
    ([1000000, -1000000], True),
    ([999999, -999998], False),
    
    # Floating point numbers
    ([1.5, -1.5], True),
    ([2.7, -2.7, 3.1], True),
    ([0.1, 0.2, 0.3], False),
    
    # Mixed positive and negative without pairs
    ([1, 2, -3, -4], False),
    ([10, 20, -5, -15], False),
    
    # Duplicate values
    ([1, 1, -1], True),
    ([2, 2, 2, -2], True),
    ([3, 3, 3], False),
    
    # Complex cases
    ([1, 2, 3, -3, 4, 5], True),
    ([100, 50, -25, 25, -100], True),
    ([-10, -5, 0, 5, 10], True),
    ([1, 2, 3, 4, 5, -6], False),
])
def test_pairs_sum_to_zero(input_list, expected):
    assert pairs_sum_to_zero(input_list) == expected


def test_pairs_sum_to_zero_with_none_values():
    # Test that function handles lists with None gracefully
    with pytest.raises(TypeError):
        pairs_sum_to_zero([1, None, -1])


def test_pairs_sum_to_zero_with_string_values():
    # Test that function raises error with non-numeric values
    with pytest.raises(TypeError):
        pairs_sum_to_zero([1, "2", -1])


def test_pairs_sum_to_zero_large_list():
    # Test with a large list
    large_list = list(range(1000)) + [-500]
    assert pairs_sum_to_zero(large_list) == True
    
    large_list_no_pair = list(range(1000, 2000))
    assert pairs_sum_to_zero(large_list_no_pair) == False


def test_pairs_sum_to_zero_all_negative():
    assert pairs_sum_to_zero([-1, -2, -3, -4]) == False
    assert pairs_sum_to_zero([-5, -5, -10]) == False


def test_pairs_sum_to_zero_all_positive():
    assert pairs_sum_to_zero([1, 2, 3, 4]) == False
    assert pairs_sum_to_zero([5, 5, 10]) == False
