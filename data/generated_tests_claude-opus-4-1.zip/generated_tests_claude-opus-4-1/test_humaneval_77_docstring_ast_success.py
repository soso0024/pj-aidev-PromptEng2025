# Test cases for HumanEval/77
# Generated using Claude API


def iscube(a):
    '''
    Write a function that takes an integer a and returns True 
    if this ingeger is a cube of some integer number.
    Note: you may assume the input is always valid.
    Examples:
    iscube(1) ==> True
    iscube(2) ==> False
    iscube(-1) ==> True
    iscube(64) ==> True
    iscube(0) ==> True
    iscube(180) ==> False
    '''

    a = abs(a)
    return int(round(a ** (1. / 3))) ** 3 == a


# Generated test cases:
import pytest

def iscube(a):
    a = abs(a)
    return int(round(a ** (1. / 3))) ** 3 == a

@pytest.mark.parametrize("input_val,expected", [
    # Perfect cubes
    (0, True),
    (1, True),
    (8, True),
    (27, True),
    (64, True),
    (125, True),
    (216, True),
    (343, True),
    (512, True),
    (729, True),
    (1000, True),
    (1331, True),
    
    # Negative perfect cubes
    (-1, True),
    (-8, True),
    (-27, True),
    (-64, True),
    (-125, True),
    (-216, True),
    (-343, True),
    (-512, True),
    (-729, True),
    (-1000, True),
    
    # Non-cubes
    (2, False),
    (3, False),
    (4, False),
    (5, False),
    (6, False),
    (7, False),
    (9, False),
    (10, False),
    (26, False),
    (28, False),
    (63, False),
    (65, False),
    (124, False),
    (126, False),
    (180, False),
    (999, False),
    (1001, False),
    
    # Negative non-cubes
    (-2, False),
    (-3, False),
    (-7, False),
    (-9, False),
    (-26, False),
    (-28, False),
    (-63, False),
    (-65, False),
    (-180, False),
    
    # Large perfect cubes
    (1728, True),  # 12^3
    (2197, True),  # 13^3
    (2744, True),  # 14^3
    (3375, True),  # 15^3
    (4096, True),  # 16^3
    (4913, True),  # 17^3
    (5832, True),  # 18^3
    (6859, True),  # 19^3
    (8000, True),  # 20^3
    (1000000, True),  # 100^3
    (1030301, True),  # 101^3
    
    # Large non-cubes
    (1727, False),
    (1729, False),
    (2196, False),
    (2198, False),
    (999999, False),
    (1000001, False),
])
def test_iscube(input_val, expected):
    assert iscube(input_val) == expected

def test_iscube_very_large():
    assert iscube(1000000000) == True  # 1000^3
    assert iscube(999999999) == False
    assert iscube(1000000001) == False
    assert iscube(-1000000000) == True
    assert iscube(-999999999) == False
