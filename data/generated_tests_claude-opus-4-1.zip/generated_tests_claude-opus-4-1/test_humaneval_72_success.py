# Test cases for HumanEval/72
# Generated using Claude API


def will_it_fly(q,w):
    '''
    Write a function that returns True if the object q will fly, and False otherwise.
    The object q will fly if it's balanced (it is a palindromic list) and the sum of its elements is less than or equal the maximum possible weight w.

    Example:
    will_it_fly([1, 2], 5) ➞ False 
    # 1+2 is less than the maximum possible weight, but it's unbalanced.

    will_it_fly([3, 2, 3], 1) ➞ False
    # it's balanced, but 3+2+3 is more than the maximum possible weight.

    will_it_fly([3, 2, 3], 9) ➞ True
    # 3+2+3 is less than the maximum possible weight, and it's balanced.

    will_it_fly([3], 5) ➞ True
    # 3 is less than the maximum possible weight, and it's balanced.
    '''

    if sum(q) > w:
        return False

    i, j = 0, len(q)-1
    while i<j:
        if q[i] != q[j]:
            return False
        i+=1
        j-=1
    return True


# Generated test cases:
import pytest


@pytest.mark.parametrize("q,w,expected", [
    # Palindrome cases that fit weight limit
    ([1, 2, 1], 5, True),
    ([1, 2, 3, 2, 1], 10, True),
    ([5], 5, True),
    ([5], 6, True),
    ([1, 1], 2, True),
    ([1, 1], 3, True),
    ([0, 0, 0], 0, True),
    ([0, 0, 0], 1, True),
    
    # Palindrome cases that exceed weight limit
    ([1, 2, 1], 3, False),
    ([1, 2, 3, 2, 1], 8, False),
    ([5], 4, False),
    ([1, 1], 1, False),
    ([10, 20, 10], 39, False),
    
    # Non-palindrome cases within weight limit
    ([1, 2], 5, False),
    ([1, 2, 3], 10, False),
    ([1, 2, 3, 4], 20, False),
    ([5, 4, 3, 2, 1], 100, False),
    
    # Non-palindrome cases exceeding weight limit
    ([1, 2], 2, False),
    ([1, 2, 3], 5, False),
    
    # Edge cases
    ([], 0, True),
    ([], 10, True),
    ([0], 0, True),
    ([0], 1, True),
    ([-1, -1], 0, True),
    ([-1, -1], -3, False),
    ([-5, 0, -5], -10, True),
    ([-5, 0, -5], -11, False),
    
    # Large numbers
    ([1000, 2000, 1000], 4000, True),
    ([1000, 2000, 1000], 3999, False),
    
    # Mixed positive and negative
    ([-1, 0, 1, 0, -1], 0, True),
    ([-1, 0, 1, 0, -1], -1, True),
    ([1, -1, -1, 1], 0, True),
    ([1, -1, -1, 1], -1, False),
    
    # Floating point numbers
    ([1.5, 2.5, 1.5], 5.5, True),
    ([1.5, 2.5, 1.5], 5.4, False),
    ([0.1, 0.2, 0.1], 0.4, True),
    ([0.1, 0.2, 0.1], 0.39, False),
])
def test_will_it_fly(q, w, expected):
    assert will_it_fly(q, w) == expected


def test_will_it_fly_empty_list():
    assert will_it_fly([], 0) == True
    assert will_it_fly([], 100) == True
    assert will_it_fly([], -10) == False


def test_will_it_fly_single_element():
    assert will_it_fly([5], 5) == True
    assert will_it_fly([5], 6) == True
    assert will_it_fly([5], 4) == False
    assert will_it_fly([0], 0) == True
    assert will_it_fly([-5], -5) == True
    assert will_it_fly([-5], -6) == False


def test_will_it_fly_two_elements():
    assert will_it_fly([1, 1], 2) == True
    assert will_it_fly([1, 1], 3) == True
    assert will_it_fly([1, 1], 1) == False
    assert will_it_fly([1, 2], 10) == False
    assert will_it_fly([2, 1], 10) == False


def test_will_it_fly_odd_length_palindrome():
    assert will_it_fly([1, 2, 3, 2, 1], 9) == True
    assert will_it_fly([1, 2, 3, 2, 1], 8) == False
    assert will_it_fly([5, 4, 3, 4, 5], 21) == True
    assert will_it_fly([5, 4, 3, 4, 5], 20) == False


def test_will_it_fly_even_length_palindrome():
    assert will_it_fly([1, 2, 2, 1], 6) == True
    assert will_it_fly([1, 2, 2, 1], 5) == False
    assert will_it_fly([3, 4, 4, 3], 14) == True
    assert will_it_fly([3, 4, 4, 3], 13) == False