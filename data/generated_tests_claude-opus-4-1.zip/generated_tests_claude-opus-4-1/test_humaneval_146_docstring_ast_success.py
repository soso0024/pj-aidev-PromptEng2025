# Test cases for HumanEval/146
# Generated using Claude API


def specialFilter(nums):
    """Write a function that takes an array of numbers as input and returns 
    the number of elements in the array that are greater than 10 and both 
    first and last digits of a number are odd (1, 3, 5, 7, 9).
    For example:
    specialFilter([15, -73, 14, -15]) => 1 
    specialFilter([33, -2, -3, 45, 21, 109]) => 2
    """

    
    count = 0
    for num in nums:
        if num > 10:
            odd_digits = (1, 3, 5, 7, 9)
            number_as_string = str(num)
            if int(number_as_string[0]) in odd_digits and int(number_as_string[-1]) in odd_digits:
                count += 1
        
    return count 


# Generated test cases:
import pytest

def specialFilter(nums):
    count = 0
    for num in nums:
        if num > 10:
            odd_digits = (1, 3, 5, 7, 9)
            number_as_string = str(num)
            if int(number_as_string[0]) in odd_digits and int(number_as_string[-1]) in odd_digits:
                count += 1
    return count

@pytest.mark.parametrize("nums,expected", [
    # Test cases from docstring
    ([15, -73, 14, -15], 1),
    ([33, -2, -3, 45, 21, 109], 2),
    
    # Empty list
    ([], 0),
    
    # Single element cases
    ([11], 1),  # Both digits odd
    ([13], 1),  # Both digits odd
    ([12], 0),  # Last digit even
    ([21], 0),  # Last digit even
    ([10], 0),  # Not greater than 10
    ([9], 0),   # Less than 10
    
    # Numbers exactly 10 or less
    ([10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1], 0),
    
    # Negative numbers
    ([-15, -33, -99, -111], 0),
    
    # Mixed positive and negative
    ([15, -15, 33, -33], 2),
    
    # All valid numbers
    ([11, 13, 15, 17, 19, 31, 33, 35, 37, 39], 10),
    
    # All invalid numbers (even first or last digit)
    ([12, 14, 16, 18, 20, 22, 24, 26, 28, 30], 0),
    
    # Three digit numbers
    ([111, 113, 115, 117, 119], 5),
    ([100, 102, 104, 106, 108], 0),
    ([311, 313, 315, 317, 319], 5),
    ([211, 213, 215, 217, 219], 0),
    
    # Large numbers
    ([1111, 3333, 5555, 7777, 9999], 5),
    ([1110, 3330, 5550, 7770, 9990], 0),
    
    # Numbers with odd first digit but even last digit
    ([10, 12, 14, 16, 18, 30, 32, 34, 36, 38], 0),
    
    # Numbers with even first digit but odd last digit
    ([21, 23, 25, 27, 29, 41, 43, 45, 47, 49], 0),
    
    # Mixed valid and invalid
    ([11, 12, 13, 14, 15, 16, 17, 18, 19, 20], 5),
    
    # Edge case: number 11 (minimum valid)
    ([11], 1),
    
    # Numbers just above and below threshold
    ([9, 10, 11], 1),
    
    # All zeros
    ([0, 0, 0], 0),
    
    # Very large valid numbers
    ([999999999, 111111111, 333333333], 3),
    
    # Mixed with floats converted to int (if applicable)
    ([15, 33, 45, 21], 2),
])
def test_specialFilter(nums, expected):
    assert specialFilter(nums) == expected

def test_specialFilter_type_consistency():
    # Test that function returns int
    result = specialFilter([15, 33, 45])
    assert isinstance(result, int)

def test_specialFilter_no_mutation():
    # Test that original list is not mutated
    original = [15, 33, 45, 21]
    copy = original.copy()
    specialFilter(original)
    assert original == copy
