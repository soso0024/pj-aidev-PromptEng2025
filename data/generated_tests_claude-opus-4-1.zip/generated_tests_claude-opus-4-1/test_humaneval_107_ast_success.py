# Test cases for HumanEval/107
# Generated using Claude API


def even_odd_palindrome(n):
    """
    Given a positive integer n, return a tuple that has the number of even and odd
    integer palindromes that fall within the range(1, n), inclusive.

    Example 1:

        Input: 3
        Output: (1, 2)
        Explanation:
        Integer palindrome are 1, 2, 3. one of them is even, and two of them are odd.

    Example 2:

        Input: 12
        Output: (4, 6)
        Explanation:
        Integer palindrome are 1, 2, 3, 4, 5, 6, 7, 8, 9, 11. four of them are even, and 6 of them are odd.

    Note:
        1. 1 <= n <= 10^3
        2. returned tuple has the number of even and odd integer palindromes respectively.
    """

    def is_palindrome(n):
        return str(n) == str(n)[::-1]

    even_palindrome_count = 0
    odd_palindrome_count = 0

    for i in range(1, n+1):
        if i%2 == 1 and is_palindrome(i):
                odd_palindrome_count += 1
        elif i%2 == 0 and is_palindrome(i):
            even_palindrome_count += 1
    return (even_palindrome_count, odd_palindrome_count)


# Generated test cases:
import pytest


@pytest.mark.parametrize("n,expected", [
    (1, (0, 1)),  # Only 1 (odd palindrome)
    (2, (1, 1)),  # 1 (odd), 2 (even)
    (3, (1, 2)),  # 1, 3 (odd), 2 (even)
    (4, (2, 2)),  # 1, 3 (odd), 2, 4 (even)
    (5, (2, 3)),  # 1, 3, 5 (odd), 2, 4 (even)
    (9, (4, 5)),  # 1,3,5,7,9 (odd), 2,4,6,8 (even)
    (10, (4, 5)), # Same as 9
    (11, (4, 6)), # Adds 11 (odd palindrome)
    (12, (4, 6)), # Same as 11
    (22, (5, 6)), # Adds 22 (even palindrome)
    (33, (5, 7)), # Adds 33 (odd palindrome)
    (99, (8, 10)), # All single digits + 11,22,33,44,55,66,77,88,99
    (100, (8, 10)), # Same as 99
    (101, (8, 11)), # Adds 101 (odd palindrome)
    (111, (8, 12)), # Adds 111 (odd palindrome)
    (121, (8, 13)), # Adds 121 (odd palindrome)
    (0, (0, 0)),  # Edge case: n=0
])
def test_even_odd_palindrome(n, expected):
    assert even_odd_palindrome(n) == expected


def test_even_odd_palindrome_single_digits():
    # Test all single digits (all are palindromes)
    assert even_odd_palindrome(1) == (0, 1)  # 1
    assert even_odd_palindrome(2) == (1, 1)  # 1, 2
    assert even_odd_palindrome(3) == (1, 2)  # 1, 2, 3
    assert even_odd_palindrome(4) == (2, 2)  # 1, 2, 3, 4
    assert even_odd_palindrome(5) == (2, 3)  # 1, 2, 3, 4, 5
    assert even_odd_palindrome(6) == (3, 3)  # 1, 2, 3, 4, 5, 6
    assert even_odd_palindrome(7) == (3, 4)  # 1, 2, 3, 4, 5, 6, 7
    assert even_odd_palindrome(8) == (4, 4)  # 1, 2, 3, 4, 5, 6, 7, 8
    assert even_odd_palindrome(9) == (4, 5)  # 1, 2, 3, 4, 5, 6, 7, 8, 9


def test_even_odd_palindrome_double_digit_palindromes():
    # Test double digit palindromes
    assert even_odd_palindrome(11) == (4, 6)   # adds 11 (odd)
    assert even_odd_palindrome(22) == (5, 6)   # adds 22 (even)
    assert even_odd_palindrome(33) == (5, 7)   # adds 33 (odd)
    assert even_odd_palindrome(44) == (6, 7)   # adds 44 (even)
    assert even_odd_palindrome(55) == (6, 8)   # adds 55 (odd)
    assert even_odd_palindrome(66) == (7, 8)   # adds 66 (even)
    assert even_odd_palindrome(77) == (7, 9)   # adds 77 (odd)
    assert even_odd_palindrome(88) == (8, 9)   # adds 88 (even)
    assert even_odd_palindrome(99) == (8, 10)  # adds 99 (odd)


def test_even_odd_palindrome_triple_digit_palindromes():
    # Test triple digit palindromes
    assert even_odd_palindrome(101) == (8, 11)  # adds 101 (odd)
    assert even_odd_palindrome(111) == (8, 12)  # adds 111 (odd)
    assert even_odd_palindrome(121) == (8, 13)  # adds 121 (odd)
    assert even_odd_palindrome(131) == (8, 14)  # adds 131 (odd)
    assert even_odd_palindrome(141) == (8, 15)  # adds 141 (odd)
    assert even_odd_palindrome(151) == (8, 16)  # adds 151 (odd)
    assert even_odd_palindrome(161) == (8, 17)  # adds 161 (odd)
    assert even_odd_palindrome(171) == (8, 18)  # adds 171 (odd)
    assert even_odd_palindrome(181) == (8, 19)  # adds 181 (odd)
    assert even_odd_palindrome(191) == (8, 20)  # adds 191 (odd)


def test_even_odd_palindrome_edge_cases():
    assert even_odd_palindrome(0) == (0, 0)
    assert even_odd_palindrome(-1) == (0, 0)  # range(1, 0) is empty
    assert even_odd_palindrome(-10) == (0, 0)  # range(1, -9) is empty


def test_even_odd_palindrome_large_numbers():
    result = even_odd_palindrome(1000)
    # Should include all single digits (1-9): 4 even, 5 odd
    # Double digit palindromes (11,22,33,44,55,66,77,88,99): 4 even, 5 odd
    # Triple digit palindromes (101-999): many more
    assert result[0] > 0  # Should have even palindromes
    assert result[1] > 0  # Should have odd palindromes
    assert result[0] + result[1] > 18  # At least single and double digit palindromes