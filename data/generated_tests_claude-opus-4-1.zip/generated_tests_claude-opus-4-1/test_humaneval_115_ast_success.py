# Test cases for HumanEval/115
# Generated using Claude API


def max_fill(grid, capacity):
    import math
    """
    You are given a rectangular grid of wells. Each row represents a single well,
    and each 1 in a row represents a single unit of water.
    Each well has a corresponding bucket that can be used to extract water from it, 
    and all buckets have the same capacity.
    Your task is to use the buckets to empty the wells.
    Output the number of times you need to lower the buckets.

    Example 1:
        Input: 
            grid : [[0,0,1,0], [0,1,0,0], [1,1,1,1]]
            bucket_capacity : 1
        Output: 6

    Example 2:
        Input: 
            grid : [[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]]
            bucket_capacity : 2
        Output: 5
    
    Example 3:
        Input: 
            grid : [[0,0,0], [0,0,0]]
            bucket_capacity : 5
        Output: 0

    Constraints:
        * all wells have the same length
        * 1 <= grid.length <= 10^2
        * 1 <= grid[:,1].length <= 10^2
        * grid[i][j] -> 0 | 1
        * 1 <= capacity <= 10
    """

    return sum([math.ceil(sum(arr)/capacity) for arr in grid])


# Generated test cases:
import pytest
import math


def max_fill(grid, capacity):
    return sum([math.ceil(sum(arr)/capacity) for arr in grid])


@pytest.mark.parametrize("grid,capacity,expected", [
    # Basic cases
    ([[1, 2, 3], [4, 5, 6]], 5, 5),
    ([[1, 1, 1], [1, 1, 1]], 2, 4),
    ([[5]], 5, 1),
    ([[10]], 5, 2),
    
    # Empty grid and rows
    ([], 5, 0),
    ([[]], 5, 0),
    ([[], []], 5, 0),
    ([[0, 0, 0]], 5, 0),
    
    # Single element rows
    ([[1], [2], [3]], 2, 4),
    ([[5], [5], [5]], 5, 3),
    
    # Large capacity
    ([[1, 2, 3], [4, 5, 6]], 100, 2),
    ([[1, 1, 1]], 1000, 1),
    
    # Capacity of 1
    ([[1, 2, 3]], 1, 6),
    ([[5, 5]], 1, 10),
    
    # Mixed zero and non-zero values
    ([[0, 1, 0], [2, 0, 3]], 3, 3),
    ([[0, 0], [0, 0]], 5, 0),
    
    # Exact division cases
    ([[10]], 10, 1),
    ([[5, 5]], 10, 1),
    ([[3, 3, 3]], 9, 1),
    
    # Non-exact division cases
    ([[10]], 3, 4),
    ([[7]], 3, 3),
    ([[1, 2, 3, 4]], 3, 4),
    
    # Multiple rows with different sums
    ([[1], [2], [3], [4], [5]], 2, 9),
    ([[10, 20], [5, 5], [1, 1]], 10, 5),
    
    # Large numbers
    ([[100, 200, 300]], 100, 6),
    ([[1000]], 7, 143),
    
    # Decimal-like results (should ceil)
    ([[1]], 2, 1),
    ([[3]], 2, 2),
    ([[5]], 3, 2),
])
def test_max_fill(grid, capacity, expected):
    assert max_fill(grid, capacity) == expected


def test_max_fill_with_floats():
    # Test with float values in grid
    assert max_fill([[1.5, 2.5]], 2) == 2
    assert max_fill([[0.5, 0.5]], 1) == 1


def test_max_fill_large_grid():
    # Test with larger grid
    large_grid = [[i for i in range(10)] for _ in range(10)]
    result = max_fill(large_grid, 10)
    assert result == 50


def test_max_fill_single_column():
    # Test with single column grid
    grid = [[1], [2], [3], [4], [5]]
    assert max_fill(grid, 1) == 15
    assert max_fill(grid, 5) == 5


def test_max_fill_uniform_grid():
    # Test with uniform values
    grid = [[5, 5, 5], [5, 5, 5], [5, 5, 5]]
    assert max_fill(grid, 15) == 3
    assert max_fill(grid, 5) == 9