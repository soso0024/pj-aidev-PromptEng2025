# Test cases for HumanEval/5
# Generated using Claude API

from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """ Insert a number 'delimeter' between every two consecutive elements of input list `numbers'
    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """

    if not numbers:
        return []

    result = []

    for n in numbers[:-1]:
        result.append(n)
        result.append(delimeter)

    result.append(numbers[-1])

    return result


# Generated test cases:
import pytest
from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    if not numbers:
        return []

    result = []

    for n in numbers[:-1]:
        result.append(n)
        result.append(delimeter)

    result.append(numbers[-1])

    return result


@pytest.mark.parametrize("numbers,delimeter,expected", [
    ([], 4, []),
    ([1, 2, 3], 4, [1, 4, 2, 4, 3]),
    ([1], 5, [1]),
    ([1, 2], 0, [1, 0, 2]),
    ([5, 5, 5], 5, [5, 5, 5, 5, 5]),
    ([1, 2, 3, 4, 5], -1, [1, -1, 2, -1, 3, -1, 4, -1, 5]),
    ([0, 0], 0, [0, 0, 0]),
    ([-1, -2, -3], 0, [-1, 0, -2, 0, -3]),
    ([100], 200, [100]),
    ([1, 2, 3, 4], 10, [1, 10, 2, 10, 3, 10, 4]),
    ([7, 8, 9, 10, 11], 0, [7, 0, 8, 0, 9, 0, 10, 0, 11]),
    ([42], -42, [42]),
    ([1, 1, 1, 1], 1, [1, 1, 1, 1, 1, 1, 1]),
    ([-5, 5], 0, [-5, 0, 5]),
    ([0], 1, [0]),
    ([10, 20, 30, 40, 50], 15, [10, 15, 20, 15, 30, 15, 40, 15, 50]),
    ([2, 4, 6], 1, [2, 1, 4, 1, 6]),
    ([999, -999], 0, [999, 0, -999]),
    ([1, 2, 3, 4, 5, 6], 7, [1, 7, 2, 7, 3, 7, 4, 7, 5, 7, 6]),
    ([0, 0, 0], -1, [0, -1, 0, -1, 0])
])
def test_intersperse(numbers, delimeter, expected):
    assert intersperse(numbers, delimeter) == expected


def test_intersperse_empty_list():
    assert intersperse([], 0) == []
    assert intersperse([], -1) == []
    assert intersperse([], 100) == []


def test_intersperse_single_element():
    assert intersperse([1], 0) == [1]
    assert intersperse([0], 0) == [0]
    assert intersperse([-1], 1) == [-1]
    assert intersperse([999], -999) == [999]


def test_intersperse_two_elements():
    assert intersperse([1, 2], 3) == [1, 3, 2]
    assert intersperse([0, 0], 1) == [0, 1, 0]
    assert intersperse([-1, 1], 0) == [-1, 0, 1]


def test_intersperse_negative_delimiter():
    assert intersperse([1, 2, 3], -1) == [1, -1, 2, -1, 3]
    assert intersperse([5, 10, 15], -100) == [5, -100, 10, -100, 15]


def test_intersperse_zero_delimiter():
    assert intersperse([1, 2, 3], 0) == [1, 0, 2, 0, 3]
    assert intersperse([-1, -2], 0) == [-1, 0, -2]


def test_intersperse_same_values():
    assert intersperse([1, 1, 1], 2) == [1, 2, 1, 2, 1]
    assert intersperse([0, 0, 0, 0], 1) == [0, 1, 0, 1, 0, 1, 0]


def test_intersperse_delimiter_in_list():
    assert intersperse([1, 2, 3], 2) == [1, 2, 2, 2, 3]
    assert intersperse([5, 10, 5], 5) == [5, 5, 10, 5, 5]


def test_intersperse_large_numbers():
    assert intersperse([1000000, 2000000], 3000000) == [1000000, 3000000, 2000000]
    assert intersperse([-1000000, 1000000], 0) == [-1000000, 0, 1000000]


def test_intersperse_does_not_modify_input():
    original = [1, 2, 3]
    result = intersperse(original, 4)
    assert original == [1, 2, 3]
    assert result == [1, 4, 2, 4, 3]
