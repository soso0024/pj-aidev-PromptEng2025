# Test cases for HumanEval/12
# Generated using Claude API

from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    """ Out of list of strings, return the longest one. Return the first one in case of multiple
    strings of the same length. Return None in case the input list is empty.
    >>> longest([])

    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    """

    if not strings:
        return None

    maxlen = max(len(x) for x in strings)
    for s in strings:
        if len(s) == maxlen:
            return s


# Generated test cases:
import pytest
from typing import List, Optional


@pytest.mark.parametrize("strings,expected", [
    ([], None),
    ([""], ""),
    (["a"], "a"),
    (["a", "bb", "ccc"], "ccc"),
    (["ccc", "bb", "a"], "ccc"),
    (["short", "medium", "longest", "tiny"], "longest"),
    (["abc", "def", "ghi"], "abc"),
    (["z", "yy", "xxx", "wwww", "vvvvv"], "vvvvv"),
    (["hello", "world", "python", "test"], "python"),
    (["same", "size", "here", "four"], "same"),
    (["", "a", "bb"], "bb"),
    (["", "", ""], ""),
    (["one"], "one"),
    (["first", "second", "third", "fourth", "fifth"], "second"),
    (["a" * 100, "b" * 50, "c" * 75], "a" * 100),
    (["equal", "length", "strings", "seventh"], "strings"),
    (["12345", "1234", "123", "12", "1"], "12345"),
    (["     ", "    ", "   ", "  ", " "], "     "),
    (["abc def", "abcdef", "ab cd ef"], "ab cd ef"),
    (["🙂", "🙂🙂", "🙂🙂🙂"], "🙂🙂🙂"),
    (["tab\t", "newline\n", "space "], "newline\n"),
])
def test_longest(strings, expected):
    assert longest(strings) == expected


def test_longest_with_none_list():
    assert longest([]) is None


def test_longest_returns_first_occurrence():
    result = longest(["abc", "def", "ghi", "jkl"])
    assert result == "abc"
    
    result = longest(["a", "bb", "cc", "dd", "e"])
    assert result == "bb"


def test_longest_with_special_characters():
    assert longest(["!@#", "$%^&", "*()_+"]) == "*()_+"
    assert longest(["\n\r", "\t\t\t", "   "]) == "\t\t\t"


def test_longest_with_mixed_types_strings():
    assert longest(["123", "45.6", "True", "None"]) == "45.6"


def test_longest_preserves_string_content():
    test_strings = ["preserve", "this", "content", "exactly"]
    result = longest(test_strings)
    assert result == "preserve"
    assert result in test_strings