# Test cases for HumanEval/64
# Generated using Claude API


FIX = """
Add more test cases.
"""

def vowels_count(s):
    """Write a function vowels_count which takes a string representing
    a word as input and returns the number of vowels in the string.
    Vowels in this case are 'a', 'e', 'i', 'o', 'u'. Here, 'y' is also a
    vowel, but only when it is at the end of the given word.

    Example:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    """

    vowels = "aeiouAEIOU"
    n_vowels = sum(c in vowels for c in s)
    if s[-1] == 'y' or s[-1] == 'Y':
        n_vowels += 1
    return n_vowels


# Generated test cases:
import pytest

def vowels_count(s):
    vowels = "aeiouAEIOU"
    n_vowels = sum(c in vowels for c in s)
    if s[-1] == 'y' or s[-1] == 'Y':
        n_vowels += 1
    return n_vowels

@pytest.mark.parametrize("input_str,expected", [
    ("hello", 2),
    ("HELLO", 2),
    ("aeiou", 5),
    ("AEIOU", 5),
    ("bcdfg", 0),
    ("BCDFG", 0),
    ("y", 1),
    ("Y", 1),
    ("ay", 2),
    ("AY", 2),
    ("ya", 1),
    ("YA", 1),
    ("happy", 2),
    ("HAPPY", 2),
    ("sky", 1),
    ("SKY", 1),
    ("rhythm", 0),
    ("RHYTHM", 0),
    ("a", 1),
    ("A", 1),
    ("e", 1),
    ("E", 1),
    ("i", 1),
    ("I", 1),
    ("o", 1),
    ("O", 1),
    ("u", 1),
    ("U", 1),
    ("xyz", 0),
    ("XYZ", 0),
    ("aEiOu", 5),
    ("AeIoU", 5),
    ("beautiful", 5),
    ("BEAUTIFUL", 5),
    ("queue", 4),
    ("QUEUE", 4),
    ("why", 1),
    ("WHY", 1),
    ("cry", 1),
    ("CRY", 1),
    ("fly", 1),
    ("FLY", 1),
    ("my", 1),
    ("MY", 1),
    ("by", 1),
    ("BY", 1),
    ("yay", 2),
    ("YAY", 2),
    ("yesterday", 4),
    ("YESTERDAY", 4),
    ("yellow", 2),
    ("YELLOW", 2),
    ("1234567890", 0),
    ("!@#$%^&*()", 0),
    ("a1e2i3o4u5", 5),
    ("A1E2I3O4U5", 5),
    ("hello world!", 3),
    ("HELLO WORLD!", 3),
    ("The quick brown fox", 5),
    ("THE QUICK BROWN FOX", 5),
    ("aaaaaa", 6),
    ("AAAAAA", 6),
    ("eeeeeee", 7),
    ("EEEEEEE", 7),
    ("iiiiiii", 7),
    ("IIIIIII", 7),
    ("ooooooo", 7),
    ("OOOOOOO", 7),
    ("uuuuuuu", 7),
    ("UUUUUUU", 7),
    ("yyyyyyy", 1),
    ("YYYYYYY", 1),
    ("aey", 3),
    ("AEY", 3),
    ("yea", 2),
    ("YEA", 2),
    ("b", 0),
    ("B", 0),
    ("z", 0),
    ("Z", 0),
])
def test_vowels_count(input_str, expected):
    assert vowels_count(input_str) == expected

def test_vowels_count_empty_string_raises_error():
    with pytest.raises(IndexError):
        vowels_count("")
