# Test cases for HumanEval/44
# Generated using Claude API



def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """

    ret = ""
    while x > 0:
        ret = str(x % base) + ret
        x //= base
    return ret


# Generated test cases:
import pytest

@pytest.mark.parametrize("x,base,expected", [
    (0, 2, ""),
    (0, 10, ""),
    (1, 2, "1"),
    (2, 2, "10"),
    (3, 2, "11"),
    (4, 2, "100"),
    (5, 2, "101"),
    (8, 2, "1000"),
    (15, 2, "1111"),
    (16, 2, "10000"),
    (10, 10, "10"),
    (100, 10, "100"),
    (255, 10, "255"),
    (8, 8, "10"),
    (9, 8, "11"),
    (64, 8, "100"),
    (10, 16, "10"),
    (15, 16, "15"),
    (16, 16, "10"),
    (255, 16, "1515"),
    (256, 16, "100"),
    (10, 3, "101"),
    (27, 3, "1000"),
    (10, 5, "20"),
    (25, 5, "100"),
    (26, 5, "101"),
    (10, 7, "13"),
    (49, 7, "100"),
    (50, 7, "101"),
    (100, 2, "1100100"),
    (1000, 2, "1111101000"),
    (1234, 10, "1234"),
    (1234, 16, "4132"),
    (1234, 8, "2322"),
    (1234, 2, "10011010010"),
    (999, 10, "999"),
    (999, 9, "1330"),
    (999, 8, "1747"),
    (999, 7, "2625"),
    (999, 6, "4343"),
    (999, 5, "12444"),
    (999, 4, "33213"),
    (999, 3, "1101000"),
    (999, 2, "1111100111"),
])
def test_change_base_normal_cases(x, base, expected):
    assert change_base(x, base) == expected

def test_change_base_zero():
    assert change_base(0, 2) == ""
    assert change_base(0, 8) == ""
    assert change_base(0, 10) == ""
    assert change_base(0, 16) == ""

def test_change_base_one():
    assert change_base(1, 2) == "1"
    assert change_base(1, 8) == "1"
    assert change_base(1, 10) == "1"
    assert change_base(1, 16) == "1"

def test_change_base_large_numbers():
    assert change_base(10000, 2) == "10011100010000"
    assert change_base(10000, 8) == "23420"
    assert change_base(10000, 10) == "10000"
    assert change_base(10000, 16) == "2710"

def test_change_base_powers_of_base():
    assert change_base(2, 2) == "10"
    assert change_base(4, 2) == "100"
    assert change_base(8, 2) == "1000"
    assert change_base(8, 8) == "10"
    assert change_base(64, 8) == "100"
    assert change_base(10, 10) == "10"
    assert change_base(100, 10) == "100"
    assert change_base(16, 16) == "10"
    assert change_base(256, 16) == "100"