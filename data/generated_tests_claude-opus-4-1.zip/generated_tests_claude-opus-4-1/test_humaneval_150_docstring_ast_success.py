# Test cases for HumanEval/150
# Generated using Claude API


def x_or_y(n, x, y):
    """A simple program which should return the value of x if n is 
    a prime number and should return the value of y otherwise.

    Examples:
    for x_or_y(7, 34, 12) == 34
    for x_or_y(15, 8, 5) == 5
    
    """

    if n == 1:
        return y
    for i in range(2, n):
        if n % i == 0:
            return y
            break
    else:
        return x


# Generated test cases:
import pytest

def x_or_y(n, x, y):
    if n == 1:
        return y
    for i in range(2, n):
        if n % i == 0:
            return y
            break
    else:
        return x

@pytest.mark.parametrize("n,x,y,expected", [
    # Prime numbers should return x
    (2, 10, 20, 10),
    (3, 10, 20, 10),
    (5, 10, 20, 10),
    (7, 34, 12, 34),
    (11, 100, 200, 100),
    (13, -5, -10, -5),
    (17, 0, 1, 0),
    (19, 1, 0, 1),
    (23, 50, 60, 50),
    (29, 99, 88, 99),
    (31, 1000, 2000, 1000),
    (37, -100, -200, -100),
    (41, 42, 43, 42),
    (43, 44, 45, 44),
    (47, 48, 49, 48),
    
    # Non-prime numbers should return y
    (1, 10, 20, 20),
    (4, 10, 20, 20),
    (6, 10, 20, 20),
    (8, 10, 20, 20),
    (9, 10, 20, 20),
    (10, 10, 20, 20),
    (12, 10, 20, 20),
    (14, 10, 20, 20),
    (15, 8, 5, 5),
    (16, 100, 200, 200),
    (18, -5, -10, -10),
    (20, 0, 1, 1),
    (21, 1, 0, 0),
    (22, 50, 60, 60),
    (24, 99, 88, 88),
    (25, 1000, 2000, 2000),
    (26, -100, -200, -200),
    (27, 42, 43, 43),
    (28, 44, 45, 45),
    (30, 48, 49, 49),
    
    # Edge cases with 0 and negative values for x and y
    (2, 0, 0, 0),
    (4, 0, 0, 0),
    (3, -1, -1, -1),
    (6, -1, -1, -1),
    
    # Large composite numbers
    (100, 1, 2, 2),
    (1000, 1, 2, 2),
    (99, 1, 2, 2),
    (49, 1, 2, 2),
    (121, 1, 2, 2),
    
    # Large prime numbers
    (97, 1, 2, 1),
    (101, 1, 2, 1),
    (103, 1, 2, 1),
    (107, 1, 2, 1),
    (109, 1, 2, 1),
    
    # Special case: 1 is not prime
    (1, 100, 200, 200),
    (1, -100, -200, -200),
    (1, 0, 1, 1),
    
    # Float-like values for x and y
    (2, 3.14, 2.71, 3.14),
    (4, 3.14, 2.71, 2.71),
    
    # String values for x and y
    (2, "prime", "not_prime", "prime"),
    (4, "prime", "not_prime", "not_prime"),
    (7, "yes", "no", "yes"),
    (8, "yes", "no", "no"),
    
    # List values for x and y
    (2, [1, 2, 3], [4, 5, 6], [1, 2, 3]),
    (4, [1, 2, 3], [4, 5, 6], [4, 5, 6]),
    
    # None values
    (2, None, "not_none", None),
    (4, "not_none", None, None),
])
def test_x_or_y(n, x, y, expected):
    assert x_or_y(n, x, y) == expected

def test_x_or_y_with_same_values():
    assert x_or_y(2, 5, 5) == 5
    assert x_or_y(4, 5, 5) == 5
    assert x_or_y(7, 10, 10) == 10
    assert x_or_y(8, 10, 10) == 10
