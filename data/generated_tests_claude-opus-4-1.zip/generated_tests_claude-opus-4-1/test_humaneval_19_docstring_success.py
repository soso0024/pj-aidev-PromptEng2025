# Test cases for HumanEval/19
# Generated using Claude API

from typing import List


def sort_numbers(numbers: str) -> str:
    """ Input is a space-delimited string of numberals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight' and 'nine'.
    Return the string with numbers sorted from smallest to largest
    >>> sort_numbers('three one five')
    'one three five'
    """

    value_map = {
        'zero': 0,
        'one': 1,
        'two': 2,
        'three': 3,
        'four': 4,
        'five': 5,
        'six': 6,
        'seven': 7,
        'eight': 8,
        'nine': 9
    }
    return ' '.join(sorted([x for x in numbers.split(' ') if x], key=lambda x: value_map[x]))


# Generated test cases:
import pytest


def sort_numbers(numbers: str) -> str:
    value_map = {
        'zero': 0,
        'one': 1,
        'two': 2,
        'three': 3,
        'four': 4,
        'five': 5,
        'six': 6,
        'seven': 7,
        'eight': 8,
        'nine': 9
    }
    return ' '.join(sorted([x for x in numbers.split(' ') if x], key=lambda x: value_map[x]))


@pytest.mark.parametrize("input_str,expected", [
    ("three one five", "one three five"),
    ("zero nine eight seven six five four three two one", "zero one two three four five six seven eight nine"),
    ("one", "one"),
    ("nine eight seven", "seven eight nine"),
    ("five five five", "five five five"),
    ("two one zero", "zero one two"),
    ("", ""),
    ("nine zero", "zero nine"),
    ("four two six eight", "two four six eight"),
    ("seven three nine one five", "one three five seven nine"),
])
def test_sort_numbers_basic(input_str, expected):
    assert sort_numbers(input_str) == expected


def test_sort_numbers_empty_string():
    assert sort_numbers("") == ""


def test_sort_numbers_single_number():
    assert sort_numbers("five") == "five"
    assert sort_numbers("zero") == "zero"
    assert sort_numbers("nine") == "nine"


def test_sort_numbers_duplicates():
    assert sort_numbers("one one one") == "one one one"
    assert sort_numbers("three two three two") == "two two three three"
    assert sort_numbers("nine zero nine zero") == "zero zero nine nine"


def test_sort_numbers_all_numbers():
    input_str = "nine eight seven six five four three two one zero"
    expected = "zero one two three four five six seven eight nine"
    assert sort_numbers(input_str) == expected


def test_sort_numbers_reverse_order():
    assert sort_numbers("nine eight seven six five") == "five six seven eight nine"
    assert sort_numbers("four three two one zero") == "zero one two three four"


def test_sort_numbers_already_sorted():
    assert sort_numbers("zero one two three") == "zero one two three"
    assert sort_numbers("five six seven eight nine") == "five six seven eight nine"


def test_sort_numbers_mixed_order():
    assert sort_numbers("five two eight one nine") == "one two five eight nine"
    assert sort_numbers("six three zero nine four") == "zero three four six nine"


def test_sort_numbers_pairs():
    assert sort_numbers("one zero") == "zero one"
    assert sort_numbers("nine eight") == "eight nine"
    assert sort_numbers("five four") == "four five"
