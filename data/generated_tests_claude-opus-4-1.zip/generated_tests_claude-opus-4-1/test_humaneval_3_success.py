# Test cases for HumanEval/3
# Generated using Claude API

from typing import List


def below_zero(operations: List[int]) -> bool:
    """ You're given a list of deposit and withdrawal operations on a bank account that starts with
    zero balance. Your task is to detect if at any point the balance of account fallls below zero, and
    at that point function should return True. Otherwise it should return False.
    >>> below_zero([1, 2, 3])
    False
    >>> below_zero([1, 2, -4, 5])
    True
    """

    balance = 0

    for op in operations:
        balance += op
        if balance < 0:
            return True

    return False


# Generated test cases:
import pytest
from typing import List


def below_zero(operations: List[int]) -> bool:
    balance = 0

    for op in operations:
        balance += op
        if balance < 0:
            return True

    return False


@pytest.mark.parametrize("operations,expected", [
    # Empty list
    ([], False),
    
    # Single element cases
    ([0], False),
    ([1], False),
    ([-1], True),
    ([100], False),
    ([-100], True),
    
    # Never goes below zero
    ([1, 2, 3], False),
    ([10, 20, 30], False),
    ([5, -3, 2], False),
    ([100, -50, -25], False),
    
    # Goes below zero immediately
    ([-1, 2, 3], True),
    ([-10, 20, 30], True),
    
    # Goes below zero in the middle
    ([1, -2, 3], True),
    ([10, -20, 30], True),
    ([5, -10, 20], True),
    
    # Goes below zero at the end
    ([10, -20], True),
    ([1, 2, -5], True),
    
    # Balance exactly zero
    ([1, -1], False),
    ([10, -5, -5], False),
    ([100, -50, -50], False),
    
    # Multiple ups and downs but never below zero
    ([10, -5, 10, -5, 10, -5], False),
    ([100, -99, 100, -99], False),
    
    # Goes below zero then recovers (still returns True)
    ([10, -20, 30], True),
    ([5, -10, 20, -5], True),
    
    # Large numbers
    ([1000000, -999999], False),
    ([1000000, -1000001], True),
    
    # Many operations
    ([1] * 100 + [-50], False),
    ([1] * 50 + [-100], True),
    
    # Alternating positive and negative
    ([1, -1, 1, -1, 1, -1], False),
    ([1, -2, 1, -2, 1, -2], True),
])
def test_below_zero(operations, expected):
    assert below_zero(operations) == expected


def test_below_zero_type_validation():
    # Test with valid list types
    assert below_zero([1, 2, 3]) == False
    assert below_zero([-1, -2, -3]) == True


def test_below_zero_immutability():
    # Ensure the function doesn't modify the input list
    operations = [10, -20, 30]
    original = operations.copy()
    result = below_zero(operations)
    assert operations == original
    assert result == True
