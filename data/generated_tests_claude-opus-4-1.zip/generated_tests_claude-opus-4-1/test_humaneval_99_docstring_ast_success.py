# Test cases for HumanEval/99
# Generated using Claude API


def closest_integer(value):
    '''
    Create a function that takes a value (string) representing a number
    and returns the closest integer to it. If the number is equidistant
    from two integers, round it away from zero.

    Examples
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15

    Note:
    Rounding away from zero means that if the given number is equidistant
    from two integers, the one you should return is the one that is the
    farthest from zero. For example closest_integer("14.5") should
    return 15 and closest_integer("-14.5") should return -15.
    '''

    from math import floor, ceil

    if value.count('.') == 1:
        # remove trailing zeros
        while (value[-1] == '0'):
            value = value[:-1]

    num = float(value)
    if value[-2:] == '.5':
        if num > 0:
            res = ceil(num)
        else:
            res = floor(num)
    elif len(value) > 0:
        res = int(round(num))
    else:
        res = 0

    return res



# Generated test cases:
import pytest

@pytest.mark.parametrize("value,expected", [
    # Basic integer strings
    ("10", 10),
    ("0", 0),
    ("-5", -5),
    ("100", 100),
    ("-100", -100),
    
    # Basic decimal strings
    ("15.3", 15),
    ("15.7", 16),
    ("15.1", 15),
    ("15.9", 16),
    
    # Negative decimals
    ("-15.3", -15),
    ("-15.7", -16),
    ("-15.1", -15),
    ("-15.9", -16),
    
    # Edge case: .5 values (round away from zero)
    ("14.5", 15),
    ("-14.5", -15),
    ("0.5", 1),
    ("-0.5", -1),
    ("1.5", 2),
    ("-1.5", -2),
    ("99.5", 100),
    ("-99.5", -100),
    
    # Values close to .5
    ("14.49", 14),
    ("14.51", 15),
    ("-14.49", -14),
    ("-14.51", -15),
    
    # Trailing zeros
    ("15.0", 15),
    ("15.00", 15),
    ("15.000", 15),
    ("-15.0", -15),
    ("-15.00", -15),
    ("14.50", 15),
    ("-14.50", -15),
    ("14.500", 15),
    ("-14.500", -15),
    
    # Small decimals
    ("0.1", 0),
    ("0.4", 0),
    ("0.6", 1),
    ("0.9", 1),
    ("-0.1", 0),
    ("-0.4", 0),
    ("-0.6", -1),
    ("-0.9", -1),
    
    # Large numbers
    ("999.4", 999),
    ("999.5", 1000),
    ("999.6", 1000),
    ("-999.4", -999),
    ("-999.5", -1000),
    ("-999.6", -1000),
    
    # Edge cases with .5 and trailing zeros
    ("1.50", 2),
    ("-1.50", -2),
    ("10.50", 11),
    ("-10.50", -11),
    
    # Very small and very large values
    ("0.01", 0),
    ("0.99", 1),
    ("-0.01", 0),
    ("-0.99", -1),
    ("1000000.5", 1000001),
    ("-1000000.5", -1000001),
    
    # Numbers without decimal point
    ("5", 5),
    ("-5", -5),
    
    # Numbers with .25 and .75
    ("10.25", 10),
    ("10.75", 11),
    ("-10.25", -10),
    ("-10.75", -11),
])
def test_closest_integer(value, expected):
    assert closest_integer(value) == expected