# Test cases for HumanEval/27
# Generated using Claude API



def flip_case(string: str) -> str:
    """ For a given string, flip lowercase characters to uppercase and uppercase to lowercase.
    >>> flip_case('Hello')
    'hELLO'
    """

    return string.swapcase()


# Generated test cases:
import pytest


@pytest.mark.parametrize("input_string,expected", [
    ("Hello", "hELLO"),
    ("hELLO", "Hello"),
    ("HELLO", "hello"),
    ("hello", "HELLO"),
    ("", ""),
    ("123", "123"),
    ("Hello World!", "hELLO wORLD!"),
    ("aBcDeFg", "AbCdEfG"),
    ("ABC123xyz", "abc123XYZ"),
    ("!@#$%^&*()", "!@#$%^&*()"),
    ("a", "A"),
    ("A", "a"),
    ("1", "1"),
    (" ", " "),
    ("MiXeD CaSe TeXt", "mIxEd cAsE tExT"),
    ("lower", "LOWER"),
    ("UPPER", "upper"),
    ("123ABC456def", "123abc456DEF"),
    ("Hello\nWorld", "hELLO\nwORLD"),
    ("Hello\tWorld", "hELLO\twORLD"),
    ("αβγ", "ΑΒΓ"),
    ("Test123Test", "tEST123tEST"),
    ("   spaces   ", "   SPACES   "),
    ("CamelCaseExample", "cAMELcASEeXAMPLE"),
    ("snake_case_example", "SNAKE_CASE_EXAMPLE"),
    ("SCREAMING_SNAKE_CASE", "screaming_snake_case"),
    ("kebab-case-example", "KEBAB-CASE-EXAMPLE"),
    ("dot.case.example", "DOT.CASE.EXAMPLE"),
    ("'quoted'", "'QUOTED'"),
    ('"DOUBLE"', '"double"'),
    ("Mix123Ed456CaSe789", "mIX123eD456cAsE789"),
])
def test_flip_case(input_string, expected):
    assert flip_case(input_string) == expected


def test_flip_case_preserves_type():
    result = flip_case("test")
    assert isinstance(result, str)


def test_flip_case_idempotent():
    original = "Hello World"
    flipped_once = flip_case(original)
    flipped_twice = flip_case(flipped_once)
    assert flipped_twice == original


def test_flip_case_with_unicode():
    assert flip_case("Café") == "cAFÉ"
    assert flip_case("ÑOÑO") == "ñoño"


def test_flip_case_long_string():
    long_string = "A" * 1000 + "b" * 1000
    expected = "a" * 1000 + "B" * 1000
    assert flip_case(long_string) == expected


def test_flip_case_special_characters():
    assert flip_case("Hello@World#2023") == "hELLO@wORLD#2023"
    assert flip_case("Test_Under-Score") == "tEST_uNDER-sCORE"


def test_flip_case_multiline():
    input_text = """First Line
Second LINE
THIRD line"""
    expected = """fIRST lINE
sECOND line
third LINE"""
    assert flip_case(input_text) == expected