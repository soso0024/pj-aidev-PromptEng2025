# Test cases for HumanEval/153
# Generated using Claude API


def Strongest_Extension(class_name, extensions):
    """You will be given the name of a class (a string) and a list of extensions.
    The extensions are to be used to load additional classes to the class. The
    strength of the extension is as follows: Let CAP be the number of the uppercase
    letters in the extension's name, and let SM be the number of lowercase letters 
    in the extension's name, the strength is given by the fraction CAP - SM. 
    You should find the strongest extension and return a string in this 
    format: ClassName.StrongestExtensionName.
    If there are two or more extensions with the same strength, you should
    choose the one that comes first in the list.
    For example, if you are given "Slices" as the class and a list of the
    extensions: ['SErviNGSliCes', 'Cheese', 'StuFfed'] then you should
    return 'Slices.SErviNGSliCes' since 'SErviNGSliCes' is the strongest extension 
    (its strength is -1).
    Example:
    for Strongest_Extension('my_class', ['AA', 'Be', 'CC']) == 'my_class.AA'
    """

    strong = extensions[0]
    my_val = len([x for x in extensions[0] if x.isalpha() and x.isupper()]) - len([x for x in extensions[0] if x.isalpha() and x.islower()])
    for s in extensions:
        val = len([x for x in s if x.isalpha() and x.isupper()]) - len([x for x in s if x.isalpha() and x.islower()])
        if val > my_val:
            strong = s
            my_val = val

    ans = class_name + "." + strong
    return ans



# Generated test cases:
import pytest
from function_implementation import Strongest_Extension

@pytest.mark.parametrize("class_name,extensions,expected", [
    ("my_class", ["AA", "Be", "CC"], "my_class.AA"),
    ("Slices", ["SErviNGSliCes", "Cheese", "StuFfed"], "Slices.SErviNGSliCes"),
    ("Test", ["ABC", "abc", "AbC"], "Test.ABC"),
    ("Class", ["UPPER", "lower", "MiXeD"], "Class.UPPER"),
    ("Example", ["aaa", "BBB", "ccc"], "Example.BBB"),
    ("Sample", ["A", "a", "B"], "Sample.A"),
    ("Demo", ["", "A", "a"], "Demo.A"),
    ("Test", ["123", "456", "789"], "Test.123"),
    ("Class", ["A1B2", "a1b2", "1234"], "Class.A1B2"),
    ("MyClass", ["aBc", "AbC", "ABC"], "MyClass.ABC"),
    ("Test", ["aB", "Ab", "ab"], "Test.aB"),
    ("Class", ["AAA", "AAa", "Aaa"], "Class.AAA"),
    ("Demo", ["z"], "Demo.z"),
    ("Test", ["ZZZZ", "zzzz", "ZzZz"], "Test.ZZZZ"),
    ("Class", ["equal", "EQUAL", "EqUaL"], "Class.EQUAL"),
    ("Sample", ["@#$", "A@#$", "a@#$"], "Sample.A@#$"),
    ("Test", ["Mix123ed", "MIX123ED", "mix123ed"], "Test.MIX123ED"),
    ("Demo", ["CamelCase", "snake_case", "UPPER_CASE"], "Demo.UPPER_CASE"),
    ("Class", ["", "", ""], "Class."),
    ("Test", ["aaaa", "aaaa", "aaaa"], "Test.aaaa"),
    ("Sample", ["AAAA", "AAAA", "AAAA"], "Sample.AAAA"),
    ("Demo", ["AaBbCc", "AAbbCC", "aaBBcc"], "Demo.AAbbCC"),
    ("Test", ["X", "XX", "XXX"], "Test.XXX"),
    ("Class", ["x", "xx", "xxx"], "Class.x"),
    ("Sample", ["Aa", "AA", "aa"], "Sample.AA"),
    ("Demo", ["AbAbAb", "ABABAB", "ababab"], "Demo.ABABAB"),
    ("Test", ["1A2B3C", "1a2b3c", "123ABC"], "Test.1A2B3C"),
    ("Class", ["_ABC_", "_abc_", "_AbC_"], "Class._ABC_"),
    ("Sample", [" ABC ", " abc ", " AbC "], "Sample. ABC "),
    ("Demo", ["!@#ABC", "!@#abc", "!@#AbC"], "Demo.!@#ABC"),
])
def test_strongest_extension(class_name, extensions, expected):
    assert Strongest_Extension(class_name, extensions) == expected


def test_single_extension():
    assert Strongest_Extension("MyClass", ["OnlyOne"]) == "MyClass.OnlyOne"
    assert Strongest_Extension("Test", ["a"]) == "Test.a"
    assert Strongest_Extension("Demo", ["Z"]) == "Demo.Z"


def test_same_strength_first_wins():
    assert Strongest_Extension("Test", ["AB", "CD", "EF"]) == "Test.AB"
    assert Strongest_Extension("Class", ["ab", "cd", "ef"]) == "Class.ab"
    assert Strongest_Extension("Demo", ["AaBb", "CcDd", "EeFf"]) == "Demo.AaBb"


def test_empty_extension_name():
    assert Strongest_Extension("Test", [""]) == "Test."
    assert Strongest_Extension("Class", ["", "A"]) == "Class.A"
    assert Strongest_Extension("Demo", ["a", ""]) == "Demo.a"


def test_non_alphabetic_characters():
    assert Strongest_Extension("Test", ["123", "456"]) == "Test.123"
    assert Strongest_Extension("Class", ["!@#", "$%^"]) == "Class.!@#"
    assert Strongest_Extension("Demo", ["___", "---"]) == "Demo.___"


def test_mixed_characters():
    assert Strongest_Extension("Test", ["A1b2C3", "a1B2c3"]) == "Test.A1b2C3"
    assert Strongest_Extension("Class", ["ABC_123", "abc_123"]) == "Class.ABC_123"
    assert Strongest_Extension("Demo", ["Test@123", "test@123"]) == "Demo.Test@123"


def test_negative_strength():
    assert Strongest_Extension("Test", ["abc", "ABC"]) == "Test.ABC"
    assert Strongest_Extension("Class", ["aaaa", "A"]) == "Class.A"
    assert Strongest_Extension("Demo", ["lowercase", "UPPERCASE"]) == "Demo.UPPERCASE"


def test_zero_strength():
    assert Strongest_Extension("Test", ["AaBb", "CcDd"]) == "Test.AaBb"
    assert Strongest_Extension("Class", ["Aa", "Bb"]) == "Class.Aa"
    assert Strongest_Extension("Demo", ["AbCd", "EfGh"]) == "Demo.AbCd"