# Test cases for HumanEval/101
# Generated using Claude API


def words_string(s):
    """
    You will be given a string of words separated by commas or spaces. Your task is
    to split the string into words and return an array of the words.
    
    For example:
    words_string("Hi, my name is John") == ["Hi", "my", "name", "is", "John"]
    words_string("One, two, three, four, five, six") == ["One", "two", "three", "four", "five", "six"]
    """

    if not s:
        return []

    s_list = []

    for letter in s:
        if letter == ',':
            s_list.append(' ')
        else:
            s_list.append(letter)

    s_list = "".join(s_list)
    return s_list.split()


# Generated test cases:
import pytest

def words_string(s):
    if not s:
        return []
    s_list = []
    for letter in s:
        if letter == ',':
            s_list.append(' ')
        else:
            s_list.append(letter)
    s_list = "".join(s_list)
    return s_list.split()

@pytest.mark.parametrize("input_str,expected", [
    ("", []),
    ("hello", ["hello"]),
    ("hello,world", ["hello", "world"]),
    ("hello, world", ["hello", "world"]),
    ("hello,world,python", ["hello", "world", "python"]),
    ("a,b,c,d,e", ["a", "b", "c", "d", "e"]),
    ("one", ["one"]),
    ("one,", ["one"]),
    (",one", ["one"]),
    (",", []),
    (",,", []),
    (",,,", []),
    ("a,,b", ["a", "b"]),
    ("a, ,b", ["a", "b"]),
    ("hello , world", ["hello", "world"]),
    ("  hello,world  ", ["hello", "world"]),
    ("hello,  world", ["hello", "world"]),
    ("hello  ,world", ["hello", "world"]),
    ("test,123,abc", ["test", "123", "abc"]),
    ("word1,word2,word3,word4", ["word1", "word2", "word3", "word4"]),
    ("single", ["single"]),
    ("with spaces", ["with", "spaces"]),
    ("multiple  spaces", ["multiple", "spaces"]),
    ("trailing,", ["trailing"]),
    (",leading", ["leading"]),
    ("mid,,dle", ["mid", "dle"]),
])
def test_words_string(input_str, expected):
    assert words_string(input_str) == expected

def test_words_string_none():
    assert words_string(None) == []

def test_words_string_empty_string():
    assert words_string("") == []

def test_words_string_only_commas():
    assert words_string(",,,,,") == []

def test_words_string_single_word():
    assert words_string("word") == ["word"]

def test_words_string_multiple_words():
    assert words_string("first,second,third") == ["first", "second", "third"]

def test_words_string_with_spaces():
    assert words_string("hello world") == ["hello", "world"]

def test_words_string_mixed_spaces_and_commas():
    assert words_string("hello, world, python") == ["hello", "world", "python"]

def test_words_string_consecutive_commas():
    assert words_string("a,,,,b") == ["a", "b"]

def test_words_string_special_characters():
    assert words_string("hello@world,test#123") == ["hello@world", "test#123"]

def test_words_string_numbers():
    assert words_string("123,456,789") == ["123", "456", "789"]

def test_words_string_mixed_content():
    assert words_string("abc123,def456,ghi789") == ["abc123", "def456", "ghi789"]
