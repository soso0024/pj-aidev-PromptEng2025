# Test cases for HumanEval/160
# Generated using Claude API


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and 
    the second list is a list of integers. Use the two given lists to build the algebric 
    expression and return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + ) 
    Subtraction ( - ) 
    Multiplication ( * ) 
    Floor division ( // ) 
    Exponentiation ( ** ) 

    Example:
    operator['+', '*', '-']
    array = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9

    Note:
        The length of operator list is equal to the length of operand list minus one.
        Operand is a list of of non-negative integers.
        Operator list has at least one operator, and operand list has at least two operands.

    """

    expression = str(operand[0])
    for oprt, oprn in zip(operator, operand[1:]):
        expression+= oprt + str(oprn)
    return eval(expression)


# Generated test cases:
import pytest

class TestDoAlgebra:
    
    def test_simple_addition(self):
        assert do_algebra(['+'], [1, 2]) == 3
        assert do_algebra(['+'], [5, 10]) == 15
    
    def test_simple_subtraction(self):
        assert do_algebra(['-'], [10, 3]) == 7
        assert do_algebra(['-'], [5, 5]) == 0
    
    def test_simple_multiplication(self):
        assert do_algebra(['*'], [3, 4]) == 12
        assert do_algebra(['*'], [7, 8]) == 56
    
    def test_simple_division(self):
        assert do_algebra(['/'], [10, 2]) == 5
        assert do_algebra(['//'], [10, 3]) == 3
    
    def test_simple_power(self):
        assert do_algebra(['**'], [2, 3]) == 8
        assert do_algebra(['**'], [5, 2]) == 25
    
    def test_simple_modulo(self):
        assert do_algebra(['%'], [10, 3]) == 1
        assert do_algebra(['%'], [20, 7]) == 6
    
    def test_multiple_operations(self):
        assert do_algebra(['+', '*'], [2, 3, 4]) == 14
        assert do_algebra(['*', '+'], [2, 3, 4]) == 10
        assert do_algebra(['+', '-', '*'], [1, 2, 3, 4]) == -9
    
    def test_complex_expression(self):
        assert do_algebra(['+', '*', '-'], [5, 2, 3, 1]) == 10
        assert do_algebra(['*', '+', '/', '-'], [2, 3, 4, 2, 1]) == 7.0
    
    def test_negative_numbers(self):
        assert do_algebra(['+'], [-5, 3]) == -2
        assert do_algebra(['-'], [-10, -5]) == -5
        assert do_algebra(['*'], [-3, 4]) == -12
    
    def test_float_operations(self):
        assert do_algebra(['/'], [5, 2]) == 2.5
        assert do_algebra(['+'], [1.5, 2.5]) == 4.0
        assert do_algebra(['*'], [2.5, 4]) == 10.0
    
    def test_single_operand(self):
        assert do_algebra([], [42]) == 42
        assert do_algebra([], [-10]) == -10
        assert do_algebra([], [3.14]) == 3.14
    
    def test_zero_operations(self):
        assert do_algebra(['+'], [0, 5]) == 5
        assert do_algebra(['*'], [0, 100]) == 0
        assert do_algebra(['-'], [10, 0]) == 10
    
    def test_division_by_zero(self):
        with pytest.raises(ZeroDivisionError):
            do_algebra(['/'], [5, 0])
        with pytest.raises(ZeroDivisionError):
            do_algebra(['//'], [10, 0])
        with pytest.raises(ZeroDivisionError):
            do_algebra(['%'], [10, 0])
    
    def test_order_of_operations(self):
        assert do_algebra(['+', '*'], [2, 3, 4]) == 14
        assert do_algebra(['*', '+'], [2, 3, 4]) == 10
        assert do_algebra(['-', '/'], [10, 2, 2]) == 9.0
    
    def test_parentheses_not_supported(self):
        # Since we're building a string expression, parentheses in operators won't work as expected
        assert do_algebra(['+', '*', '+'], [1, 2, 3, 4]) == 11
    
    def test_large_numbers(self):
        assert do_algebra(['+'], [1000000, 2000000]) == 3000000
        assert do_algebra(['*'], [1000, 1000]) == 1000000
        assert do_algebra(['**'], [10, 6]) == 1000000
    
    def test_many_operations(self):
        operators = ['+', '-', '*', '/', '+', '-']
        operands = [10, 5, 2, 3, 6, 1, 2]
        result = do_algebra(operators, operands)
        assert result == 10 + 5 - 2 * 3 / 6 + 1 - 2
    
    def test_all_same_operator(self):
        assert do_algebra(['+', '+', '+'], [1, 2, 3, 4]) == 10
        assert do_algebra(['*', '*', '*'], [2, 3, 4, 5]) == 120