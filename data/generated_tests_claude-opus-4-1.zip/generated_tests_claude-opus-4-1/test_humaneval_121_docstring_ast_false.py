# Test cases for HumanEval/121
# Generated using Claude API


def solution(lst):
    """Given a non-empty list of integers, return the sum of all of the odd elements that are in even positions.
    

    Examples
    solution([5, 8, 7, 1]) ==> 12
    solution([3, 3, 3, 3, 3]) ==> 9
    solution([30, 13, 24, 321]) ==>0
    """

    return sum([x for idx, x in enumerate(lst) if idx%2==0 and x%2==1])


# Generated test cases:
import pytest

@pytest.mark.parametrize("lst,expected", [
    ([5, 8, 7, 1], 12),
    ([3, 3, 3, 3, 3], 9),
    ([30, 13, 24, 321], 0),
    ([1], 1),
    ([2], 0),
    ([1, 2], 1),
    ([2, 1], 0),
    ([1, 2, 3], 4),
    ([1, 2, 3, 4], 4),
    ([1, 2, 3, 4, 5], 9),
    ([0, 0, 0, 0], 0),
    ([1, 1, 1, 1], 2),
    ([7, 7, 7, 7, 7, 7], 21),
    ([-1, -2, -3, -4, -5], -9),
    ([-1, 2, 3, -4, 5], 4),
    ([11, 22, 33, 44, 55], 99),
    ([100, 101, 102, 103], 0),
    ([101, 100, 103, 102, 105], 309),
    ([2, 4, 6, 8, 10], 0),
    ([1, 3, 5, 7, 9], 15),
    ([999, 1000, 1001, 1002, 1003], 3003),
    ([0], 0),
    ([1000000], 0),
    ([1000001], 1000001),
    ([13, 0, 17, 0, 19], 49),
])
def test_solution(lst, expected):
    assert solution(lst) == expected

def test_solution_single_odd():
    assert solution([7]) == 7

def test_solution_single_even():
    assert solution([8]) == 0

def test_solution_alternating():
    assert solution([1, 2, 1, 2, 1, 2]) == 3

def test_solution_large_numbers():
    assert solution([999999, 1000000, 999997, 1000002]) == 1999996

def test_solution_all_zeros():
    assert solution([0, 0, 0, 0, 0, 0]) == 0

def test_solution_negative_odds():
    assert solution([-1, 0, -3, 0, -5]) == -9

def test_solution_mixed_signs():
    assert solution([1, -2, -3, 4, 5, -6, -7]) == 6