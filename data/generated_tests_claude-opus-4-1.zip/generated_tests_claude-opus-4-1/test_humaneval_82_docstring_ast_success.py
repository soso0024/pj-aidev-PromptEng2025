# Test cases for HumanEval/82
# Generated using Claude API


def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise
    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """

    l = len(string)
    if l == 0 or l == 1:
        return False
    for i in range(2, l):
        if l % i == 0:
            return False
    return True


# Generated test cases:
import pytest

def prime_length(string):
    l = len(string)
    if l == 0 or l == 1:
        return False
    for i in range(2, l):
        if l % i == 0:
            return False
    return True

@pytest.mark.parametrize("string,expected", [
    # Examples from docstring
    ("Hello", True),
    ("abcdcba", True),
    ("kittens", True),
    ("orange", False),
    
    # Edge cases
    ("", False),  # length 0
    ("a", False),  # length 1
    
    # Prime lengths
    ("ab", True),  # length 2
    ("abc", True),  # length 3
    ("abcde", True),  # length 5
    ("abcdefghijk", True),  # length 11
    ("abcdefghijklm", True),  # length 13
    ("abcdefghijklmnopq", True),  # length 17
    ("abcdefghijklmnopqrs", True),  # length 19
    ("abcdefghijklmnopqrstuvw", True),  # length 23
    
    # Non-prime lengths
    ("abcd", False),  # length 4
    ("abcdef", False),  # length 6
    ("abcdefgh", False),  # length 8
    ("abcdefghi", False),  # length 9
    ("abcdefghij", False),  # length 10
    ("abcdefghijkl", False),  # length 12
    ("abcdefghijklmno", False),  # length 15
    
    # Special characters and spaces
    ("  ", True),  # length 2
    ("   ", True),  # length 3
    ("    ", False),  # length 4
    ("!@#$%", True),  # length 5
    ("hello world", True),  # length 11
    
    # Unicode characters
    ("αβγ", True),  # length 3
    ("你好", True),  # length 2
    ("🙂🙂🙂🙂", False),  # length 4
    
    # Large prime length
    ("a" * 29, True),  # length 29
    ("a" * 31, True),  # length 31
    ("a" * 37, True),  # length 37
    
    # Large non-prime length
    ("a" * 30, False),  # length 30
    ("a" * 32, False),  # length 32
    ("a" * 36, False),  # length 36
])
def test_prime_length(string, expected):
    assert prime_length(string) == expected

def test_prime_length_type():
    assert isinstance(prime_length("test"), bool)
    assert isinstance(prime_length(""), bool)
