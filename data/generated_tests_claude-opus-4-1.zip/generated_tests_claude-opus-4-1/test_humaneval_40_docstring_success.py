# Test cases for HumanEval/40
# Generated using Claude API



def triples_sum_to_zero(l: list):
    """
    triples_sum_to_zero takes a list of integers as an input.
    it returns True if there are three distinct elements in the list that
    sum to zero, and False otherwise.

    >>> triples_sum_to_zero([1, 3, 5, 0])
    False
    >>> triples_sum_to_zero([1, 3, -2, 1])
    True
    >>> triples_sum_to_zero([1, 2, 3, 7])
    False
    >>> triples_sum_to_zero([2, 4, -5, 3, 9, 7])
    True
    >>> triples_sum_to_zero([1])
    False
    """

    for i in range(len(l)):
        for j in range(i + 1, len(l)):
            for k in range(j + 1, len(l)):
                if l[i] + l[j] + l[k] == 0:
                    return True
    return False


# Generated test cases:
import pytest


@pytest.mark.parametrize("input_list,expected", [
    # Basic test cases from docstring
    ([1, 3, 5, 0], False),
    ([1, 3, -2, 1], True),
    ([1, 2, 3, 7], False),
    ([2, 4, -5, 3, 9, 7], True),
    ([1], False),
    
    # Edge cases - empty and small lists
    ([], False),
    ([0], False),
    ([1, 2], False),
    ([0, 0], False),
    
    # Three zeros
    ([0, 0, 0], True),
    
    # Exactly three elements
    ([1, -1, 0], True),
    ([1, 2, 3], False),
    ([-1, -2, 3], True),
    ([5, -2, -3], True),
    
    # Lists with duplicates
    ([1, 1, -2], True),
    ([2, 2, -4], True),
    ([1, 1, 1], False),
    ([-1, -1, 2], True),
    
    # Negative numbers
    ([-1, -2, -3, 6], False),  # Fixed: -1 + -2 + -3 = -6, not 0
    ([-5, -4, -3, -2, -1], False),
    ([-1, 0, 1], True),
    
    # Large numbers
    ([100, -50, -50], True),
    ([1000, 500, -1500], True),
    ([999, 998, 997], False),
    
    # Multiple valid triples
    ([1, -1, 0, 2, -2], True),
    ([3, -3, 2, -2, 1, -1, 0], True),
    
    # All positive numbers
    ([1, 2, 3, 4, 5], False),
    
    # All negative numbers except one that makes a triple
    ([-5, -3, -2, 10], False),  # Fixed: -5 + -3 + -2 = -10, not 0
    
    # Mixed with zero
    ([0, 1, -1, 2, 3], True),
    ([0, 0, 0, 1, 2], True),
    ([0, 1, 2, 3], False),
    
    # Longer lists
    ([1, 2, 3, 4, 5, -6, -7], True),  # Fixed: 1 + 5 + -6 = 0
    ([10, -5, -4, -1, 2, 3], True),
    (list(range(-10, 11)), True),
    
    # Float-like integers
    ([1, 2, -3], True),
    ([10, 20, 30], False),
])
def test_triples_sum_to_zero(input_list, expected):
    assert triples_sum_to_zero(input_list) == expected


def test_triples_sum_to_zero_large_list():
    # Test with a larger list that has a triple
    large_list = list(range(100)) + [-50, -49]
    assert triples_sum_to_zero(large_list) == True
    
    # Test with a larger list without a triple
    large_list_no_triple = list(range(1, 101))
    assert triples_sum_to_zero(large_list_no_triple) == False


def test_triples_sum_to_zero_does_not_modify_input():
    original = [1, 2, -3, 4]
    input_copy = original.copy()
    result = triples_sum_to_zero(input_copy)
    assert input_copy == original
    assert result == True