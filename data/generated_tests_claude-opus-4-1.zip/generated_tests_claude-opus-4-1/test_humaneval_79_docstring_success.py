# Test cases for HumanEval/79
# Generated using Claude API


def decimal_to_binary(decimal):
    """You will be given a number in decimal form and your task is to convert it to
    binary format. The function should return a string, with each character representing a binary
    number. Each character in the string will be '0' or '1'.

    There will be an extra couple of characters 'db' at the beginning and at the end of the string.
    The extra characters are there to help with the format.

    Examples:
    decimal_to_binary(15)   # returns "db1111db"
    decimal_to_binary(32)   # returns "db100000db"
    """

    return "db" + bin(decimal)[2:] + "db"


# Generated test cases:
import pytest

def decimal_to_binary(decimal):
    return "db" + bin(decimal)[2:] + "db"

@pytest.mark.parametrize("input_val,expected", [
    (15, "db1111db"),
    (32, "db100000db"),
    (0, "db0db"),
    (1, "db1db"),
    (2, "db10db"),
    (3, "db11db"),
    (4, "db100db"),
    (5, "db101db"),
    (7, "db111db"),
    (8, "db1000db"),
    (16, "db10000db"),
    (31, "db11111db"),
    (63, "db111111db"),
    (64, "db1000000db"),
    (127, "db1111111db"),
    (128, "db10000000db"),
    (255, "db11111111db"),
    (256, "db100000000db"),
    (1023, "db1111111111db"),
    (1024, "db10000000000db"),
    (100, "db1100100db"),
    (1000, "db1111101000db"),
    (10000, "db10011100010000db"),
    (999999, "db11110100001000111111db"),
])
def test_decimal_to_binary_valid_inputs(input_val, expected):
    assert decimal_to_binary(input_val) == expected

def test_decimal_to_binary_large_number():
    assert decimal_to_binary(2**20) == "db100000000000000000000db"
    assert decimal_to_binary(2**10 - 1) == "db1111111111db"

def test_decimal_to_binary_powers_of_two():
    assert decimal_to_binary(2) == "db10db"
    assert decimal_to_binary(4) == "db100db"
    assert decimal_to_binary(8) == "db1000db"
    assert decimal_to_binary(16) == "db10000db"
    assert decimal_to_binary(32) == "db100000db"
    assert decimal_to_binary(64) == "db1000000db"
    assert decimal_to_binary(128) == "db10000000db"
    assert decimal_to_binary(256) == "db100000000db"
    assert decimal_to_binary(512) == "db1000000000db"

def test_decimal_to_binary_format():
    result = decimal_to_binary(10)
    assert result.startswith("db")
    assert result.endswith("db")
    assert all(c in "01" for c in result[2:-2])

def test_decimal_to_binary_consecutive_numbers():
    assert decimal_to_binary(10) == "db1010db"
    assert decimal_to_binary(11) == "db1011db"
    assert decimal_to_binary(12) == "db1100db"
    assert decimal_to_binary(13) == "db1101db"
    assert decimal_to_binary(14) == "db1110db"
