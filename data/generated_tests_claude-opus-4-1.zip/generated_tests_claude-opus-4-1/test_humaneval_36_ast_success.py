# Test cases for HumanEval/36
# Generated using Claude API



def fizz_buzz(n: int):
    """Return the number of times the digit 7 appears in integers less than n which are divisible by 11 or 13.
    >>> fizz_buzz(50)
    0
    >>> fizz_buzz(78)
    2
    >>> fizz_buzz(79)
    3
    """

    ns = []
    for i in range(n):
        if i % 11 == 0 or i % 13 == 0:
            ns.append(i)
    s = ''.join(list(map(str, ns)))
    ans = 0
    for c in s:
        ans += (c == '7')
    return ans


# Generated test cases:
import pytest

@pytest.mark.parametrize("n,expected", [
    (0, 0),
    (1, 0),
    (10, 0),
    (11, 0),
    (12, 0),
    (13, 0),
    (14, 0),
    (22, 0),
    (23, 0),
    (26, 0),
    (50, 0),
    (77, 0),
    (78, 2),
    (79, 3),
    (100, 3),
    (143, 4),
    (144, 4),
    (176, 4),
    (177, 5),
    (200, 6),
    (273, 7),
    (274, 8),
    (275, 8),
    (276, 9),
    (277, 9),
    (278, 9),
    (279, 9),
    (300, 10),
    (377, 11),
    (378, 13),
    (500, 15),
    (770, 35),
    (771, 37),
    (777, 37),
    (778, 37),
    (779, 37),
    (780, 37),
    (1000, 47),
])
def test_fizz_buzz_various_inputs(n, expected):
    assert fizz_buzz(n) == expected


def test_fizz_buzz_small_values():
    assert fizz_buzz(0) == 0
    assert fizz_buzz(1) == 0
    assert fizz_buzz(5) == 0
    assert fizz_buzz(10) == 0


def test_fizz_buzz_includes_11():
    assert fizz_buzz(12) == 0
    assert fizz_buzz(23) == 0


def test_fizz_buzz_includes_13():
    assert fizz_buzz(14) == 0
    assert fizz_buzz(27) == 0


def test_fizz_buzz_multiples_of_11():
    assert fizz_buzz(34) == 0
    assert fizz_buzz(45) == 0
    assert fizz_buzz(56) == 0
    assert fizz_buzz(67) == 0


def test_fizz_buzz_multiples_of_13():
    assert fizz_buzz(40) == 0
    assert fizz_buzz(53) == 0
    assert fizz_buzz(66) == 0


def test_fizz_buzz_with_sevens():
    assert fizz_buzz(78) == 2
    assert fizz_buzz(178) == 5
    assert fizz_buzz(278) == 9


def test_fizz_buzz_large_numbers():
    assert fizz_buzz(2000) >= 0
    assert fizz_buzz(5000) >= 0


def test_fizz_buzz_edge_cases():
    assert fizz_buzz(11) == 0
    assert fizz_buzz(13) == 0
    assert fizz_buzz(143) == 4
    assert fizz_buzz(169) == 4


def test_fizz_buzz_consecutive_values():
    for i in range(1, 20):
        result = fizz_buzz(i)
        assert isinstance(result, int)
        assert result >= 0