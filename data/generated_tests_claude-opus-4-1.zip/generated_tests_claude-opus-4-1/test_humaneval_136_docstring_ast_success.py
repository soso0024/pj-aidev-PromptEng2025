# Test cases for HumanEval/136
# Generated using Claude API


def largest_smallest_integers(lst):
    '''
    Create a function that returns a tuple (a, b), where 'a' is
    the largest of negative integers, and 'b' is the smallest
    of positive integers in a list.
    If there is no negative or positive integers, return them as None.

    Examples:
    largest_smallest_integers([2, 4, 1, 3, 5, 7]) == (None, 1)
    largest_smallest_integers([]) == (None, None)
    largest_smallest_integers([0]) == (None, None)
    '''

    smallest = list(filter(lambda x: x < 0, lst))
    largest = list(filter(lambda x: x > 0, lst))
    return (max(smallest) if smallest else None, min(largest) if largest else None)


# Generated test cases:
import pytest

def largest_smallest_integers(lst):
    smallest = list(filter(lambda x: x < 0, lst))
    largest = list(filter(lambda x: x > 0, lst))
    return (max(smallest) if smallest else None, min(largest) if largest else None)


@pytest.mark.parametrize("input_list,expected", [
    # Basic examples from docstring
    ([2, 4, 1, 3, 5, 7], (None, 1)),
    ([], (None, None)),
    ([0], (None, None)),
    
    # Only positive integers
    ([1, 2, 3, 4, 5], (None, 1)),
    ([10, 20, 30], (None, 10)),
    ([100], (None, 100)),
    
    # Only negative integers
    ([-1, -2, -3, -4, -5], (-1, None)),
    ([-10, -20, -30], (-10, None)),
    ([-100], (-100, None)),
    
    # Mix of positive and negative
    ([-5, -3, -1, 1, 3, 5], (-1, 1)),
    ([-10, -5, 2, 8], (-5, 2)),
    ([-100, -50, -25, 10, 20, 30], (-25, 10)),
    
    # With zeros
    ([0, 0, 0], (None, None)),
    ([-1, 0, 1], (-1, 1)),
    ([-5, -3, 0, 0, 2, 4], (-3, 2)),
    ([0, 1, 2, 3], (None, 1)),
    ([-3, -2, -1, 0], (-1, None)),
    
    # Single element lists
    ([1], (None, 1)),
    ([-1], (-1, None)),
    ([0], (None, None)),
    
    # Large numbers
    ([-1000000, 1000000], (-1000000, 1000000)),
    ([-999999, -1, 1, 999999], (-1, 1)),
    
    # Duplicates
    ([1, 1, 1, 1], (None, 1)),
    ([-1, -1, -1, -1], (-1, None)),
    ([-2, -2, 2, 2], (-2, 2)),
    ([0, 0, 1, 1, -1, -1], (-1, 1)),
    
    # Edge cases with extreme values
    ([-1, -2, -3, 1, 2, 3], (-1, 1)),
    ([5, 4, 3, 2, 1], (None, 1)),
    ([-5, -4, -3, -2, -1], (-1, None)),
    
    # Mixed with various ranges
    ([-100, -50, -1, 0, 1, 50, 100], (-1, 1)),
    ([-7, -3, -2, 4, 8, 9], (-2, 4)),
    ([10, -10, 20, -20, 30, -30], (-10, 10)),
])
def test_largest_smallest_integers(input_list, expected):
    assert largest_smallest_integers(input_list) == expected


def test_empty_list():
    assert largest_smallest_integers([]) == (None, None)


def test_only_zeros():
    assert largest_smallest_integers([0, 0, 0, 0, 0]) == (None, None)


def test_large_list():
    large_positive = list(range(1, 1001))
    assert largest_smallest_integers(large_positive) == (None, 1)
    
    large_negative = list(range(-1000, 0))
    assert largest_smallest_integers(large_negative) == (-1, None)
    
    large_mixed = list(range(-500, 501))
    large_mixed.remove(0)
    assert largest_smallest_integers(large_mixed) == (-1, 1)
