# Test cases for HumanEval/143
# Generated using Claude API


def words_in_sentence(sentence):
    """
    You are given a string representing a sentence,
    the sentence contains some words separated by a space,
    and you have to return a string that contains the words from the original sentence,
    whose lengths are prime numbers,
    the order of the words in the new string should be the same as the original one.

    Example 1:
        Input: sentence = "This is a test"
        Output: "is"

    Example 2:
        Input: sentence = "lets go for swimming"
        Output: "go for"

    Constraints:
        * 1 <= len(sentence) <= 100
        * sentence contains only letters
    """

    new_lst = []
    for word in sentence.split():
        flg = 0
        if len(word) == 1:
            flg = 1
        for i in range(2, len(word)):
            if len(word)%i == 0:
                flg = 1
        if flg == 0 or len(word) == 2:
            new_lst.append(word)
    return " ".join(new_lst)


# Generated test cases:
import pytest

def words_in_sentence(sentence):
    new_lst = []
    for word in sentence.split():
        flg = 0
        if len(word) == 1:
            flg = 1
        for i in range(2, len(word)):
            if len(word)%i == 0:
                flg = 1
        if flg == 0 or len(word) == 2:
            new_lst.append(word)
    return " ".join(new_lst)


@pytest.mark.parametrize("sentence,expected", [
    ("This is a test", "is"),
    ("lets go for swimming", "go for"),
    ("there is no place available here", "there is no place"),
    ("Hi I am Hussein", "Hi am Hussein"),
    ("go for it", "go for it"),
    ("", ""),
    ("a", ""),
    ("ab", "ab"),
    ("abc", "abc"),
    ("abcd", ""),
    ("abcde", "abcde"),
    ("abcdef", ""),
    ("abcdefg", "abcdefg"),
    ("abcdefgh", ""),
    ("abcdefghi", ""),
    ("abcdefghij", ""),
    ("abcdefghijk", "abcdefghijk"),
    ("a b c d e f g h i j k", ""),
    ("aa bb cc dd ee ff gg hh ii jj kk", "aa bb cc dd ee ff gg hh ii jj kk"),
    ("aaa bbb ccc ddd eee fff ggg hhh iii jjj kkk", "aaa bbb ccc ddd eee fff ggg hhh iii jjj kkk"),
    ("aaaa bbbb cccc dddd eeee ffff gggg hhhh iiii jjjj kkkk", ""),
    ("aaaaa bbbbb ccccc ddddd eeeee fffff ggggg hhhhh iiiii jjjjj kkkkk", "aaaaa bbbbb ccccc ddddd eeeee fffff ggggg hhhhh iiiii jjjjj kkkkk"),
    ("aaaaaa bbbbbb cccccc dddddd eeeeee ffffff gggggg hhhhhh iiiiii jjjjjj kkkkkk", ""),
    ("aaaaaaa bbbbbbb ccccccc ddddddd eeeeeee fffffff ggggggg hhhhhhh iiiiiii jjjjjjj kkkkkkk", "aaaaaaa bbbbbbb ccccccc ddddddd eeeeeee fffffff ggggggg hhhhhhh iiiiiii jjjjjjj kkkkkkk"),
    ("Hello world", "Hello world"),
    ("Python is great", "is great"),
    ("I love programming", "programming"),
    ("The quick brown fox jumps over the lazy dog", "The quick brown fox jumps the dog"),
    ("   ", ""),
    ("  hello  world  ", "hello world"),
    ("12 123 1234 12345 123456 1234567", "12 123 12345 1234567"),
    ("to be or not to be", "to be or not to be"),
    ("prime numbers are special", "prime numbers are special"),
    ("one two three four five six seven eight nine ten", "one two three six seven eight ten"),
])
def test_words_in_sentence(sentence, expected):
    assert words_in_sentence(sentence) == expected


def test_single_word_sentences():
    assert words_in_sentence("hello") == "hello"
    assert words_in_sentence("world") == "world"
    assert words_in_sentence("Python") == ""
    assert words_in_sentence("is") == "is"
    assert words_in_sentence("a") == ""
    assert words_in_sentence("I") == ""


def test_all_prime_length_words():
    assert words_in_sentence("ab abc abcde abcdefg abcdefghijk") == "ab abc abcde abcdefg abcdefghijk"


def test_all_composite_length_words():
    assert words_in_sentence("abcd abcdef abcdefgh abcdefghi") == ""


def test_mixed_length_words():
    assert words_in_sentence("a ab abc abcd abcde abcdef") == "ab abc abcde"


def test_repeated_words():
    assert words_in_sentence("the the the") == "the the the"
    assert words_in_sentence("test test test test") == ""
    assert words_in_sentence("go go go") == "go go go"


def test_special_characters():
    assert words_in_sentence("it's don't can't") == "don't can't"
    assert words_in_sentence("hello-world test_case") == "hello-world"


def test_numbers_as_words():
    assert words_in_sentence("1 22 333 4444 55555") == "22 333 55555"


def test_case_sensitivity():
    assert words_in_sentence("Hello WORLD python PROGRAMMING") == "Hello WORLD PROGRAMMING"


def test_long_sentence():
    sentence = " ".join(["word" + str(i) for i in range(100)])
    result = words_in_sentence(sentence)
    assert isinstance(result, str)