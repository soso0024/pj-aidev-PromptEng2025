# Test cases for HumanEval/58
# Generated using Claude API



def common(l1: list, l2: list):
    """Return sorted unique common elements for two lists.
    >>> common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121])
    [1, 5, 653]
    >>> common([5, 3, 2, 8], [3, 2])
    [2, 3]

    """

    ret = set()
    for e1 in l1:
        for e2 in l2:
            if e1 == e2:
                ret.add(e1)
    return sorted(list(ret))


# Generated test cases:
import pytest


@pytest.mark.parametrize("l1,l2,expected", [
    ([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121], [1, 5, 653]),
    ([5, 3, 2, 8], [3, 2], [2, 3]),
    ([], [], []),
    ([1, 2, 3], [], []),
    ([], [1, 2, 3], []),
    ([1, 2, 3], [4, 5, 6], []),
    ([1, 2, 3], [1, 2, 3], [1, 2, 3]),
    ([1, 1, 1], [1, 1, 1], [1]),
    ([1, 2, 3, 4, 5], [5, 4, 3, 2, 1], [1, 2, 3, 4, 5]),
    ([1], [1], [1]),
    ([1], [2], []),
    ([-1, -2, -3], [-3, -2, -1], [-3, -2, -1]),
    ([0, 0, 0], [0], [0]),
    ([1.5, 2.5, 3.5], [2.5, 3.5, 4.5], [2.5, 3.5]),
    (["a", "b", "c"], ["b", "c", "d"], ["b", "c"]),
    ([True, False], [False, True], [False, True]),
    ([1, 2, 3, 2, 1], [2, 3, 4, 3, 2], [2, 3]),
    (list(range(100)), list(range(50, 150)), list(range(50, 100))),
])
def test_common(l1, l2, expected):
    assert common(l1, l2) == expected


def test_common_large_lists():
    l1 = list(range(1000))
    l2 = list(range(500, 1500))
    expected = list(range(500, 1000))
    assert common(l1, l2) == expected


def test_common_no_modification_of_input():
    l1 = [1, 2, 3]
    l2 = [2, 3, 4]
    l1_copy = l1.copy()
    l2_copy = l2.copy()
    common(l1, l2)
    assert l1 == l1_copy
    assert l2 == l2_copy