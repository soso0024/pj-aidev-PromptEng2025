# Test cases for HumanEval/159
# Generated using Claude API


def eat(number, need, remaining):
    """
    You're a hungry rabbit, and you already have eaten a certain number of carrots,
    but now you need to eat more carrots to complete the day's meals.
    you should return an array of [ total number of eaten carrots after your meals,
                                    the number of carrots left after your meals ]
    if there are not enough remaining carrots, you will eat all remaining carrots, but will still be hungry.
    
    Example:
    * eat(5, 6, 10) -> [11, 4]
    * eat(4, 8, 9) -> [12, 1]
    * eat(1, 10, 10) -> [11, 0]
    * eat(2, 11, 5) -> [7, 0]
    
    Variables:
    @number : integer
        the number of carrots that you have eaten.
    @need : integer
        the number of carrots that you need to eat.
    @remaining : integer
        the number of remaining carrots thet exist in stock
    
    Constrain:
    * 0 <= number <= 1000
    * 0 <= need <= 1000
    * 0 <= remaining <= 1000

    Have fun :)
    """

    if(need <= remaining):
        return [ number + need , remaining-need ]
    else:
        return [ number + remaining , 0]


# Generated test cases:
import pytest

def eat(number, need, remaining):
    if(need <= remaining):
        return [ number + need , remaining-need ]
    else:
        return [ number + remaining , 0]

@pytest.mark.parametrize("number,need,remaining,expected", [
    # Examples from docstring
    (5, 6, 10, [11, 4]),
    (4, 8, 9, [12, 1]),
    (1, 10, 10, [11, 0]),
    (2, 11, 5, [7, 0]),
    
    # Edge cases - zeros
    (0, 0, 0, [0, 0]),
    (0, 0, 10, [0, 10]),
    (0, 10, 0, [0, 0]),
    (10, 0, 0, [10, 0]),
    (10, 0, 10, [10, 10]),
    (0, 10, 10, [10, 0]),
    (10, 10, 0, [10, 0]),
    
    # Exact match cases
    (5, 5, 5, [10, 0]),
    (100, 100, 100, [200, 0]),
    
    # Need less than remaining
    (10, 5, 20, [15, 15]),
    (100, 50, 200, [150, 150]),
    (0, 50, 100, [50, 50]),
    
    # Need more than remaining
    (10, 20, 5, [15, 0]),
    (100, 200, 50, [150, 0]),
    (0, 100, 50, [50, 0]),
    
    # Large numbers within constraints
    (1000, 0, 0, [1000, 0]),
    (0, 1000, 1000, [1000, 0]),
    (1000, 1000, 1000, [2000, 0]),
    (500, 500, 1000, [1000, 500]),
    (999, 1, 1000, [1000, 999]),
    (1, 999, 1000, [1000, 1]),
    
    # Various combinations
    (50, 25, 100, [75, 75]),
    (200, 300, 250, [450, 0]),
    (333, 333, 333, [666, 0]),
    (100, 1, 1, [101, 0]),
    (1, 100, 1, [2, 0]),
])
def test_eat(number, need, remaining, expected):
    assert eat(number, need, remaining) == expected

def test_eat_return_type():
    result = eat(5, 6, 10)
    assert isinstance(result, list)
    assert len(result) == 2
    assert isinstance(result[0], int)
    assert isinstance(result[1], int)

def test_eat_non_negative_results():
    # Test that results are always non-negative
    test_cases = [
        (0, 0, 0),
        (10, 20, 5),
        (100, 200, 150),
        (500, 500, 500),
    ]
    for number, need, remaining in test_cases:
        result = eat(number, need, remaining)
        assert result[0] >= 0
        assert result[1] >= 0
