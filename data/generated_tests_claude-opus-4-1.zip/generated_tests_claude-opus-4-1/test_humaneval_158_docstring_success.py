# Test cases for HumanEval/158
# Generated using Claude API


def find_max(words):
    """Write a function that accepts a list of strings.
    The list contains different words. Return the word with maximum number
    of unique characters. If multiple strings have maximum number of unique
    characters, return the one which comes first in lexicographical order.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb" ,"cc"]) == ""aaaaaaa"
    """

    return sorted(words, key = lambda x: (-len(set(x)), x))[0]


# Generated test cases:
import pytest

def find_max(words):
    return sorted(words, key = lambda x: (-len(set(x)), x))[0]

@pytest.mark.parametrize("words,expected", [
    (["name", "of", "string"], "string"),
    (["name", "enam", "game"], "enam"),
    (["aaaaaaa", "bb", "cc"], "aaaaaaa"),
    (["a"], "a"),
    (["abc", "def", "ghi"], "abc"),
    (["aaa", "bbb", "ccc"], "aaa"),
    (["abcd", "efgh", "ijkl"], "abcd"),
    (["hello", "world"], "world"),
    (["python", "java", "c++"], "python"),
    (["test", "best", "rest"], "best"),
    (["xyz", "abc", "def"], "abc"),
    (["abcdef", "ghijkl", "mnopqr"], "abcdef"),
    (["a", "ab", "abc", "abcd"], "abcd"),
    (["abcd", "abc", "ab", "a"], "abcd"),
    (["zzz", "aaa", "bbb"], "aaa"),
    (["12345", "67890", "abcde"], "12345"),
    (["", "a", "ab"], "ab"),
    ([""], ""),
    (["aabbcc", "abc", "def"], "aabbcc"),
    (["xyz", "xyzw", "xyzwv"], "xyzwv"),
    (["mississippi", "hello", "world"], "world"),
    (["aabbccdd", "abcd", "efgh"], "aabbccdd"),
    (["programming", "python", "code"], "programming"),
    (["unique", "chars", "test"], "chars"),
    (["aaaa", "bbbb", "cccc", "dddd"], "aaaa"),
    (["abcdefghij", "klmnopqrst", "uvwxyz"], "abcdefghij"),
    (["same", "length", "unique"], "length"),
    (["cat", "dog", "bat"], "bat"),
    (["apple", "banana", "cherry"], "cherry"),
    (["x", "xx", "xxx", "xxxx"], "x"),
])
def test_find_max(words, expected):
    assert find_max(words) == expected

def test_find_max_empty_list():
    with pytest.raises(IndexError):
        find_max([])

def test_find_max_single_empty_string():
    assert find_max([""]) == ""

def test_find_max_multiple_empty_strings():
    assert find_max(["", "", ""]) == ""

def test_find_max_mixed_empty_and_non_empty():
    assert find_max(["", "a", ""]) == "a"

def test_find_max_special_characters():
    assert find_max(["!@#", "$%^", "&*()"]) == "&*()"

def test_find_max_numbers_as_strings():
    assert find_max(["123", "456", "789"]) == "123"

def test_find_max_unicode_characters():
    assert find_max(["café", "naïve", "résumé"]) == "naïve"

def test_find_max_same_unique_count_lexicographical():
    assert find_max(["bcd", "abc", "def"]) == "abc"

def test_find_max_repeated_words():
    assert find_max(["test", "test", "test"]) == "test"

def test_find_max_case_sensitive():
    assert find_max(["ABC", "abc", "Abc"]) == "ABC"