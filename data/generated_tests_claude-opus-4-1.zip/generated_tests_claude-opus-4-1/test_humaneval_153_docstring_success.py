# Test cases for HumanEval/153
# Generated using Claude API


def Strongest_Extension(class_name, extensions):
    """You will be given the name of a class (a string) and a list of extensions.
    The extensions are to be used to load additional classes to the class. The
    strength of the extension is as follows: Let CAP be the number of the uppercase
    letters in the extension's name, and let SM be the number of lowercase letters 
    in the extension's name, the strength is given by the fraction CAP - SM. 
    You should find the strongest extension and return a string in this 
    format: ClassName.StrongestExtensionName.
    If there are two or more extensions with the same strength, you should
    choose the one that comes first in the list.
    For example, if you are given "Slices" as the class and a list of the
    extensions: ['SErviNGSliCes', 'Cheese', 'StuFfed'] then you should
    return 'Slices.SErviNGSliCes' since 'SErviNGSliCes' is the strongest extension 
    (its strength is -1).
    Example:
    for Strongest_Extension('my_class', ['AA', 'Be', 'CC']) == 'my_class.AA'
    """

    strong = extensions[0]
    my_val = len([x for x in extensions[0] if x.isalpha() and x.isupper()]) - len([x for x in extensions[0] if x.isalpha() and x.islower()])
    for s in extensions:
        val = len([x for x in s if x.isalpha() and x.isupper()]) - len([x for x in s if x.isalpha() and x.islower()])
        if val > my_val:
            strong = s
            my_val = val

    ans = class_name + "." + strong
    return ans



# Generated test cases:
import pytest

def Strongest_Extension(class_name, extensions):
    strong = extensions[0]
    my_val = len([x for x in extensions[0] if x.isalpha() and x.isupper()]) - len([x for x in extensions[0] if x.isalpha() and x.islower()])
    for s in extensions:
        val = len([x for x in s if x.isalpha() and x.isupper()]) - len([x for x in s if x.isalpha() and x.islower()])
        if val > my_val:
            strong = s
            my_val = val

    ans = class_name + "." + strong
    return ans


@pytest.mark.parametrize("class_name,extensions,expected", [
    ("my_class", ["AA", "Be", "CC"], "my_class.AA"),
    ("Slices", ["SErviNGSliCes", "Cheese", "StuFfed"], "Slices.SErviNGSliCes"),
    ("Test", ["ABC", "abc", "AbC"], "Test.ABC"),
    ("Example", ["UPPERCASE"], "Example.UPPERCASE"),
    ("Example", ["lowercase"], "Example.lowercase"),
    ("Example", ["MiXeD"], "Example.MiXeD"),
    ("Class", ["AAA", "BBB", "CCC"], "Class.AAA"),
    ("Class", ["aaa", "bbb", "ccc"], "Class.aaa"),
    ("Test", ["Aa", "AA", "aa"], "Test.AA"),
    ("Test", ["aA", "Aa", "AA"], "Test.AA"),
    ("MyClass", ["123", "456", "789"], "MyClass.123"),
    ("MyClass", ["A1B2", "C3D4", "E5F6"], "MyClass.A1B2"),
    ("Test", ["", "A", "a"], "Test.A"),
    ("Test", ["A"], "Test.A"),
    ("LongClassName", ["VeryLongExtensionName", "SHORT"], "LongClassName.SHORT"),
    ("Class", ["aBc", "AbC", "ABC"], "Class.ABC"),
    ("Class", ["abc", "aBc", "AbC", "ABC"], "Class.ABC"),
    ("Test", ["AAaa", "aaAA", "AaAa"], "Test.AAaa"),
    ("Test", ["!@#", "$%^", "&*()"], "Test.!@#"),
    ("Test", ["A!a", "B@b", "C#c"], "Test.A!a"),
    ("EmptyExt", [""], "EmptyExt."),
    ("SingleChar", ["A", "B", "C", "a", "b", "c"], "SingleChar.A"),
    ("MixedCase", ["AaBbCc", "AABBCC", "aabbcc"], "MixedCase.AABBCC"),
    ("Numbers", ["123ABC", "456def", "789GHI"], "Numbers.123ABC"),
    ("Special", ["___AAA___", "---aaa---", "...BBB..."], "Special.___AAA___"),
    ("Ties", ["AB", "CD", "EF"], "Ties.AB"),
    ("Negative", ["aaa", "aa", "a"], "Negative.a"),
    ("Zero", ["Aa", "Bb", "Cc"], "Zero.Aa"),
    ("Complex", ["AaBbCcDd", "AABBCCDD", "aabbccdd", "AbCdEfGh"], "Complex.AABBCCDD"),
])
def test_strongest_extension(class_name, extensions, expected):
    assert Strongest_Extension(class_name, extensions) == expected


def test_single_extension():
    assert Strongest_Extension("MyClass", ["OnlyOne"]) == "MyClass.OnlyOne"


def test_all_same_strength():
    assert Strongest_Extension("Test", ["Aa", "Bb", "Cc"]) == "Test.Aa"


def test_uppercase_wins():
    assert Strongest_Extension("Test", ["UPPER", "lower", "MiXeD"]) == "Test.UPPER"


def test_first_wins_on_tie():
    assert Strongest_Extension("Test", ["AA", "BB", "CC"]) == "Test.AA"


def test_non_alpha_ignored():
    assert Strongest_Extension("Test", ["A1B2C3", "123456", "!@#$%^"]) == "Test.A1B2C3"


def test_empty_string_extension():
    assert Strongest_Extension("Test", ["", "a", "A"]) == "Test.A"


def test_mixed_with_numbers():
    assert Strongest_Extension("Class", ["ABC123", "abc456", "789"]) == "Class.ABC123"