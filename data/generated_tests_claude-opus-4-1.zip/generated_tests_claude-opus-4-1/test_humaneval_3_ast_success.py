# Test cases for HumanEval/3
# Generated using Claude API

from typing import List


def below_zero(operations: List[int]) -> bool:
    """ You're given a list of deposit and withdrawal operations on a bank account that starts with
    zero balance. Your task is to detect if at any point the balance of account fallls below zero, and
    at that point function should return True. Otherwise it should return False.
    >>> below_zero([1, 2, 3])
    False
    >>> below_zero([1, 2, -4, 5])
    True
    """

    balance = 0

    for op in operations:
        balance += op
        if balance < 0:
            return True

    return False


# Generated test cases:
import pytest
from typing import List


def below_zero(operations: List[int]) -> bool:
    balance = 0
    for op in operations:
        balance += op
        if balance < 0:
            return True
    return False


@pytest.mark.parametrize("operations,expected", [
    # Empty list
    ([], False),
    
    # Single element cases
    ([0], False),
    ([1], False),
    ([-1], True),
    ([100], False),
    ([-100], True),
    
    # Never goes below zero
    ([1, 2, 3], False),
    ([10, -5, 3], False),
    ([100, -50, -25, -10], False),
    ([5, -4, 10, -10], False),
    
    # Goes below zero immediately
    ([-1, 100, 200], True),
    ([-5, -10, 100], True),
    
    # Goes below zero after some operations
    ([10, -20, 30], True),
    ([5, -3, -3, 10], True),
    ([100, -50, -60, 100], True),
    ([1, 2, -5, 10], True),
    
    # Exactly reaches zero but never below
    ([10, -10], False),
    ([5, -5, 10, -10], False),
    ([100, -50, -50], False),
    
    # Large numbers
    ([1000000, -999999], False),
    ([1000000, -1000001], True),
    
    # Multiple ups and downs
    ([10, -5, -4, -2, 100], True),
    ([10, -5, -4, 20, -10], False),
    ([50, -20, -10, -30, 100], True),
    
    # All positive
    ([1, 2, 3, 4, 5], False),
    
    # All negative
    ([-1, -2, -3], True),
    
    # Alternating signs
    ([1, -1, 1, -1], False),
    ([1, -2, 3, -4], True),
    ([-1, 2, -3, 4], True),
])
def test_below_zero(operations, expected):
    assert below_zero(operations) == expected


def test_below_zero_type_validation():
    # Test with valid integer lists
    assert below_zero([1, 2, 3]) == False
    assert below_zero([-1, -2, -3]) == True
