# Test cases for HumanEval/135
# Generated using Claude API


def can_arrange(arr):
    """Create a function which returns the largest index of an element which
    is not greater than or equal to the element immediately preceding it. If
    no such element exists then return -1. The given array will not contain
    duplicate values.

    Examples:
    can_arrange([1,2,4,3,5]) = 3
    can_arrange([1,2,3]) = -1
    """

    ind=-1
    i=1
    while i<len(arr):
      if arr[i]<arr[i-1]:
        ind=i
      i+=1
    return ind


# Generated test cases:
import pytest

def can_arrange(arr):
    ind=-1
    i=1
    while i<len(arr):
      if arr[i]<arr[i-1]:
        ind=i
      i+=1
    return ind

@pytest.mark.parametrize("arr,expected", [
    # Empty array
    ([], -1),
    
    # Single element
    ([1], -1),
    
    # Two elements - ascending
    ([1, 2], -1),
    
    # Two elements - descending
    ([2, 1], 1),
    
    # Two elements - equal
    ([1, 1], -1),
    
    # Multiple elements - all ascending
    ([1, 2, 3, 4, 5], -1),
    
    # Multiple elements - all descending
    ([5, 4, 3, 2, 1], 4),
    
    # Multiple elements - all equal
    ([3, 3, 3, 3], -1),
    
    # Multiple elements - one decrease at beginning
    ([2, 1, 3, 4, 5], 1),
    
    # Multiple elements - one decrease in middle
    ([1, 2, 3, 2, 4], 3),
    
    # Multiple elements - one decrease at end
    ([1, 2, 3, 4, 2], 4),
    
    # Multiple elements - multiple decreases
    ([1, 3, 2, 5, 4, 7, 6], 6),
    
    # Negative numbers
    ([-5, -3, -4, -1], 2),
    
    # Mix of positive and negative
    ([-2, -1, 0, 1, -1], 4),
    
    # Floating point numbers
    ([1.5, 2.5, 2.0, 3.0], 2),
    
    # Large numbers
    ([1000000, 2000000, 1500000], 2),
    
    # Alternating pattern
    ([1, 3, 2, 4, 3, 5, 4], 6),
])
def test_can_arrange(arr, expected):
    assert can_arrange(arr) == expected

def test_can_arrange_does_not_modify_input():
    original = [3, 1, 2]
    copy = original.copy()
    can_arrange(original)
    assert original == copy

def test_can_arrange_with_none_values():
    with pytest.raises(TypeError):
        can_arrange([1, None, 3])

def test_can_arrange_with_string_values():
    result = can_arrange(['a', 'c', 'b'])
    assert result == 2
