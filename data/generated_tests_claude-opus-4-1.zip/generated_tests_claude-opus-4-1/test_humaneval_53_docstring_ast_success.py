# Test cases for HumanEval/53
# Generated using Claude API



def add(x: int, y: int):
    """Add two numbers x and y
    >>> add(2, 3)
    5
    >>> add(5, 7)
    12
    """

    return x + y


# Generated test cases:
import pytest

def add(x: int, y: int):
    return x + y

class TestAdd:
    def test_positive_numbers(self):
        assert add(2, 3) == 5
        assert add(5, 7) == 12
        assert add(100, 200) == 300
    
    def test_negative_numbers(self):
        assert add(-2, -3) == -5
        assert add(-10, -20) == -30
    
    def test_mixed_sign_numbers(self):
        assert add(-5, 10) == 5
        assert add(10, -5) == 5
        assert add(-10, 5) == -5
        assert add(5, -10) == -5
    
    def test_zero(self):
        assert add(0, 0) == 0
        assert add(0, 5) == 5
        assert add(5, 0) == 5
        assert add(0, -5) == -5
        assert add(-5, 0) == -5
    
    def test_large_numbers(self):
        assert add(1000000, 2000000) == 3000000
        assert add(999999999, 1) == 1000000000
    
    def test_commutative_property(self):
        assert add(3, 5) == add(5, 3)
        assert add(-7, 2) == add(2, -7)
        assert add(100, -50) == add(-50, 100)
    
    @pytest.mark.parametrize("x,y,expected", [
        (1, 1, 2),
        (10, 20, 30),
        (-1, -1, -2),
        (0, 100, 100),
        (100, 0, 100),
        (-50, 50, 0),
        (50, -50, 0),
        (999, 1, 1000),
        (-999, -1, -1000),
    ])
    def test_parametrized_cases(self, x, y, expected):
        assert add(x, y) == expected
    
    def test_identity_element(self):
        for i in range(-10, 11):
            assert add(i, 0) == i
            assert add(0, i) == i
    
    def test_inverse_elements(self):
        for i in range(1, 11):
            assert add(i, -i) == 0
            assert add(-i, i) == 0
