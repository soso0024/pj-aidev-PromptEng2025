# Test cases for HumanEval/120
# Generated using Claude API


def maximum(arr, k):
    """
    Given an array arr of integers and a positive integer k, return a sorted list 
    of length k with the maximum k numbers in arr.

    Example 1:

        Input: arr = [-3, -4, 5], k = 3
        Output: [-4, -3, 5]

    Example 2:

        Input: arr = [4, -4, 4], k = 2
        Output: [4, 4]

    Example 3:

        Input: arr = [-3, 2, 1, 2, -1, -2, 1], k = 1
        Output: [2]

    Note:
        1. The length of the array will be in the range of [1, 1000].
        2. The elements in the array will be in the range of [-1000, 1000].
        3. 0 <= k <= len(arr)
    """

    if k == 0:
        return []
    arr.sort()
    ans = arr[-k:]
    return ans


# Generated test cases:
import pytest

@pytest.mark.parametrize("arr,k,expected", [
    # Example cases from docstring
    ([-3, -4, 5], 3, [-4, -3, 5]),
    ([4, -4, 4], 2, [4, 4]),
    ([-3, 2, 1, 2, -1, -2, 1], 1, [2]),
    
    # Edge cases with k = 0
    ([1, 2, 3], 0, []),
    ([-1, -2, -3], 0, []),
    ([0], 0, []),
    
    # Edge cases with k = len(arr)
    ([1, 2, 3], 3, [1, 2, 3]),
    ([5, 1, 3, 2, 4], 5, [1, 2, 3, 4, 5]),
    ([10], 1, [10]),
    
    # Single element array
    ([5], 1, [5]),
    ([-5], 1, [-5]),
    ([0], 1, [0]),
    
    # All negative numbers
    ([-1, -2, -3, -4, -5], 3, [-3, -2, -1]),
    ([-10, -20, -30], 2, [-20, -10]),
    ([-100, -50, -75], 1, [-50]),
    
    # All positive numbers
    ([1, 2, 3, 4, 5], 3, [3, 4, 5]),
    ([10, 20, 30], 2, [20, 30]),
    ([100, 50, 75], 1, [100]),
    
    # Mixed positive and negative
    ([-5, -3, 0, 2, 4], 3, [0, 2, 4]),
    ([-10, 0, 10], 2, [0, 10]),
    ([1, -1, 2, -2, 0], 3, [0, 1, 2]),
    
    # Duplicate values
    ([1, 1, 1, 1], 2, [1, 1]),
    ([5, 5, 5, 3, 3], 3, [5, 5, 5]),
    ([0, 0, 0, 0], 4, [0, 0, 0, 0]),
    ([-2, -2, 3, 3, 3], 4, [-2, 3, 3, 3]),
    
    # Already sorted arrays
    ([1, 2, 3, 4, 5], 2, [4, 5]),
    ([-5, -4, -3, -2, -1], 3, [-3, -2, -1]),
    
    # Reverse sorted arrays
    ([5, 4, 3, 2, 1], 2, [4, 5]),
    ([-1, -2, -3, -4, -5], 3, [-3, -2, -1]),
    
    # Random order
    ([3, 7, 1, 9, 2, 5], 4, [3, 5, 7, 9]),
    ([10, -5, 0, 15, -10, 20], 3, [10, 15, 20]),
    
    # Large values
    ([1000, -1000, 500, -500, 0], 3, [0, 500, 1000]),
    ([999, 998, 997, 996], 2, [998, 999]),
    
    # k = 1 cases
    ([10, 20, 30, 40], 1, [40]),
    ([-10, -20, -30, -40], 1, [-10]),
    ([0, -1, 1], 1, [1]),
    
    # Two element arrays
    ([1, 2], 1, [2]),
    ([1, 2], 2, [1, 2]),
    ([-1, 1], 1, [1]),
    ([-1, -2], 2, [-2, -1]),
])
def test_maximum(arr, k, expected):
    assert maximum(arr.copy(), k) == expected

@pytest.mark.parametrize("arr,k,expected", [
    # Test that original array is not modified (using copy in test)
    ([3, 1, 2], 2, [2, 3]),
    ([5, 4, 3, 2, 1], 3, [3, 4, 5]),
])
def test_maximum_preserves_original(arr, k, expected):
    original = arr.copy()
    result = maximum(arr.copy(), k)
    assert result == expected
    # The function modifies the input array, so we test with a copy