# Test cases for HumanEval/34
# Generated using Claude API



def unique(l: list):
    """Return sorted unique elements in a list
    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """

    return sorted(list(set(l)))


# Generated test cases:
import pytest

@pytest.mark.parametrize("input_list,expected", [
    ([], []),
    ([1], [1]),
    ([1, 2, 3], [1, 2, 3]),
    ([3, 2, 1], [1, 2, 3]),
    ([1, 1, 1], [1]),
    ([1, 2, 2, 3, 3, 3], [1, 2, 3]),
    ([5, 1, 5, 1, 5], [1, 5]),
    ([-1, -2, -3], [-3, -2, -1]),
    ([0, 0, 0], [0]),
    ([1, -1, 0, -1, 1], [-1, 0, 1]),
    ([10, 20, 10, 30, 20], [10, 20, 30]),
    (["a", "b", "c"], ["a", "b", "c"]),
    (["c", "b", "a"], ["a", "b", "c"]),
    (["apple", "banana", "apple"], ["apple", "banana"]),
    (["", "", "a"], ["", "a"]),
    ([1.5, 2.5, 1.5], [1.5, 2.5]),
    ([True, False, True], [False, True]),
    ([None, None], [None]),
    ([(1, 2), (1, 2), (3, 4)], [(1, 2), (3, 4)]),
    ([float('inf'), float('-inf'), 0], [float('-inf'), 0, float('inf')]),
])
def test_unique(input_list, expected):
    assert unique(input_list) == expected

def test_unique_preserves_original_list():
    original = [3, 1, 2, 1]
    original_copy = original.copy()
    result = unique(original)
    assert original == original_copy
    assert result == [1, 2, 3]

def test_unique_with_mixed_types_sortable():
    result = unique([3, 1.0, 2, 1])
    assert result == [1, 2, 3]

def test_unique_large_list():
    input_list = list(range(1000)) * 3
    result = unique(input_list)
    assert result == list(range(1000))

def test_unique_with_negative_and_positive():
    assert unique([-5, -3, 0, 3, 5, -3, 3]) == [-5, -3, 0, 3, 5]

def test_unique_with_mixed_types_raises():
    with pytest.raises(TypeError):
        unique([1, "1", 1.0])