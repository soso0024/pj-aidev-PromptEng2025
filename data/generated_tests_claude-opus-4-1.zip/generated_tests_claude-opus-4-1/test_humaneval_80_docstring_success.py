# Test cases for HumanEval/80
# Generated using Claude API


def is_happy(s):
    """You are given a string s.
    Your task is to check if the string is happy or not.
    A string is happy if its length is at least 3 and every 3 consecutive letters are distinct
    For example:
    is_happy(a) => False
    is_happy(aa) => False
    is_happy(abcd) => True
    is_happy(aabb) => False
    is_happy(adb) => True
    is_happy(xyy) => False
    """

    if len(s) < 3:
      return False

    for i in range(len(s) - 2):
      
      if s[i] == s[i+1] or s[i+1] == s[i+2] or s[i] == s[i+2]:
        return False
    return True


# Generated test cases:
import pytest

def is_happy(s):
    if len(s) < 3:
        return False
    for i in range(len(s) - 2):
        if s[i] == s[i+1] or s[i+1] == s[i+2] or s[i] == s[i+2]:
            return False
    return True


@pytest.mark.parametrize("input_str,expected", [
    # Examples from docstring
    ("a", False),
    ("aa", False),
    ("abcd", True),
    ("aabb", False),
    ("adb", True),
    ("xyy", False),
    
    # Edge cases - strings with length < 3
    ("", False),
    ("x", False),
    ("xy", False),
    
    # Edge cases - strings with exactly length 3
    ("abc", True),
    ("aaa", False),
    ("aba", False),
    ("aab", False),
    ("abb", False),
    
    # Normal cases - happy strings
    ("abcdef", True),
    ("xyz", True),
    ("abcabc", True),
    ("abcdabcd", True),
    
    # Normal cases - unhappy strings
    ("aabc", False),
    ("abcc", False),
    ("abcaa", False),
    ("abcdde", False),
    ("abcded", False),
    
    # Repeating patterns
    ("ababab", False),
    ("abcabcabc", True),
    ("xyzxyz", True),
    
    # Special characters and numbers
    ("12345", True),
    ("112", False),
    ("!@#", True),
    ("!@!", False),
    
    # Longer strings
    ("abcdefghijk", True),
    ("abcdefghiij", False),
    ("abcdefghijkl", True),
    
    # Mixed cases
    ("AbC", True),
    ("AAA", False),
    ("AaA", False),
    
    # Strings with spaces
    ("a b c", False),  # Fixed: "a b c" has spaces at positions that create duplicate patterns
    ("a  b", False),
    ("   ", False),
])
def test_is_happy(input_str, expected):
    assert is_happy(input_str) == expected


def test_is_happy_empty_string():
    assert is_happy("") == False


def test_is_happy_single_char():
    assert is_happy("z") == False


def test_is_happy_two_chars():
    assert is_happy("ab") == False


def test_is_happy_all_distinct():
    assert is_happy("abcdefg") == True


def test_is_happy_consecutive_duplicates():
    assert is_happy("abccde") == False
    assert is_happy("aabcde") == False
    assert is_happy("abcdee") == False


def test_is_happy_non_consecutive_duplicates():
    assert is_happy("abacad") == False
    assert is_happy("abcabc") == True


def test_is_happy_alternating_pattern():
    assert is_happy("aba") == False
    assert is_happy("abab") == False
    assert is_happy("ababab") == False