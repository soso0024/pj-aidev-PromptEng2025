# Test cases for HumanEval/154
# Generated using Claude API


def cycpattern_check(a , b):
    """You are given 2 words. You need to return True if the second word or any of its rotations is a substring in the first word
    cycpattern_check("abcd","abd") => False
    cycpattern_check("hello","ell") => True
    cycpattern_check("whassup","psus") => False
    cycpattern_check("abab","baa") => True
    cycpattern_check("efef","eeff") => False
    cycpattern_check("himenss","simen") => True

    """

    l = len(b)
    pat = b + b
    for i in range(len(a) - l + 1):
        for j in range(l + 1):
            if a[i:i+l] == pat[j:j+l]:
                return True
    return False


# Generated test cases:
import pytest

def cycpattern_check(a, b):
    l = len(b)
    pat = b + b
    for i in range(len(a) - l + 1):
        for j in range(l + 1):
            if a[i:i+l] == pat[j:j+l]:
                return True
    return False

@pytest.mark.parametrize("a,b,expected", [
    ("abcd", "abd", False),
    ("hello", "ell", True),
    ("whassup", "psus", False),
    ("abab", "baa", True),
    ("efef", "eeff", False),
    ("himenss", "simen", True),
])
def test_given_examples(a, b, expected):
    assert cycpattern_check(a, b) == expected

@pytest.mark.parametrize("a,b,expected", [
    ("", "", True),
    ("a", "", True),
    ("", "a", False),
    ("a", "a", True),
    ("ab", "a", True),
    ("ab", "b", True),
    ("ab", "ab", True),
    ("ab", "ba", True),
])
def test_edge_cases(a, b, expected):
    assert cycpattern_check(a, b) == expected

@pytest.mark.parametrize("a,b,expected", [
    ("abcdef", "cde", True),
    ("abcdef", "def", True),
    ("abcdef", "abc", True),
    ("abcdef", "bcd", True),
    ("abcdef", "efa", False),
    ("abcdef", "fab", False),
    ("abcdef", "defa", False),
])
def test_substring_cases(a, b, expected):
    assert cycpattern_check(a, b) == expected

@pytest.mark.parametrize("a,b,expected", [
    ("abcabc", "cab", True),
    ("abcabc", "bca", True),
    ("abcabc", "abc", True),
    ("xyzxyz", "zxy", True),
    ("xyzxyz", "yzx", True),
    ("xyzxyz", "xyz", True),
])
def test_rotation_cases(a, b, expected):
    assert cycpattern_check(a, b) == expected

@pytest.mark.parametrize("a,b,expected", [
    ("aaa", "aa", True),
    ("aaaa", "aaa", True),
    ("abababab", "abab", True),
    ("abababab", "baba", True),
    ("abababab", "ababa", True),
])
def test_repeating_patterns(a, b, expected):
    assert cycpattern_check(a, b) == expected

@pytest.mark.parametrize("a,b,expected", [
    ("short", "verylongstring", False),
    ("abc", "defg", False),
    ("xyz", "abcd", False),
    ("test", "longer", False),
])
def test_no_match_cases(a, b, expected):
    assert cycpattern_check(a, b) == expected

@pytest.mark.parametrize("a,b,expected", [
    ("123456", "234", True),
    ("123456", "345", True),
    ("123456", "456", True),
    ("123456", "561", False),
    ("123456", "612", False),
])
def test_numeric_strings(a, b, expected):
    assert cycpattern_check(a, b) == expected

@pytest.mark.parametrize("a,b,expected", [
    ("AbCdEf", "CdE", True),
    ("AbCdEf", "cde", False),
    ("HELLO", "ELL", True),
    ("HELLO", "ell", False),
    ("MixedCase", "edCa", True),
    ("MixedCase", "aseM", False),
])
def test_case_sensitivity(a, b, expected):
    assert cycpattern_check(a, b) == expected

@pytest.mark.parametrize("a,b,expected", [
    ("a b c", " b ", True),
    ("a b c", "b c", True),
    ("a b c", "c a", False),
    ("hello world", "o w", True),
    ("hello world", "ld", True),
    ("hello world", "ldh", False),
])
def test_with_spaces(a, b, expected):
    assert cycpattern_check(a, b) == expected

@pytest.mark.parametrize("a,b,expected", [
    ("!@#$%", "@#$", True),
    ("!@#$%", "#$%", True),
    ("!@#$%", "$%!", False),
    ("a!b@c#", "!b@", True),
    ("a!b@c#", "@c#", True),
    ("a!b@c#", "#a!", False),
])
def test_special_characters(a, b, expected):
    assert cycpattern_check(a, b) == expected
