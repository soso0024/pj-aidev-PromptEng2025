# Test cases for HumanEval/118
# Generated using Claude API


def get_closest_vowel(word):
    """You are given a word. Your task is to find the closest vowel that stands between 
    two consonants from the right side of the word (case sensitive).
    
    Vowels in the beginning and ending doesn't count. Return empty string if you didn't
    find any vowel met the above condition. 

    You may assume that the given string contains English letter only.

    Example:
    get_closest_vowel("yogurt") ==> "u"
    get_closest_vowel("FULL") ==> "U"
    get_closest_vowel("quick") ==> ""
    get_closest_vowel("ab") ==> ""
    """

    if len(word) < 3:
        return ""

    vowels = {"a", "e", "i", "o", "u", "A", "E", 'O', 'U', 'I'}
    for i in range(len(word)-2, 0, -1):
        if word[i] in vowels:
            if (word[i+1] not in vowels) and (word[i-1] not in vowels):
                return word[i]
    return ""


# Generated test cases:
import pytest


@pytest.mark.parametrize("word,expected", [
    ("yogurt", "u"),
    ("FULL", "U"),
    ("quick", ""),
    ("ab", ""),
    ("", ""),
    ("a", ""),
    ("aa", ""),
    ("aaa", ""),
    ("bab", "a"),
    ("beb", "e"),
    ("bib", "i"),
    ("bob", "o"),
    ("bub", "u"),
    ("BAB", "A"),
    ("BEB", "E"),
    ("BIB", "I"),
    ("BOB", "O"),
    ("BUB", "U"),
    ("beautiful", "u"),
    ("aeiou", ""),
    ("bcdfg", ""),
    ("abcdefg", "e"),
    ("abcdefgh", "e"),
    ("xyzabc", "a"),
    ("programming", "i"),
    ("hello", "e"),
    ("world", "o"),
    ("python", "o"),
    ("testing", "i"),
    ("aei", ""),
    ("eia", ""),
    ("bac", "a"),
    ("cab", "a"),
    ("cba", ""),
    ("abc", ""),
    ("abec", "e"),
    ("abeca", "e"),
    ("abecad", "a"),
    ("abecade", "a"),
    ("consonants", "a"),
    ("rhythm", ""),
    ("fly", ""),
    ("cry", ""),
    ("gym", ""),
    ("myth", ""),
    ("lynx", ""),
    ("xyz", ""),
    ("aebece", "e"),
    ("aebecef", "e"),
    ("aebecefig", "i"),
    ("aebecefigu", "i"),
    ("AEBECE", "E"),
    ("AEBECEF", "E"),
    ("AEBECEFIG", "I"),
    ("AEBECEFIGU", "I"),
    ("bababab", "a"),
    ("babababa", "a"),
    ("ababab", "a"),
    ("abababa", "a"),
    ("eieio", ""),
    ("aeiouAEIOU", ""),
    ("bcdfghjklmnpqrstvwxyz", ""),
    ("BCDFGHJKLMNPQRSTVWXYZ", ""),
    ("xax", "a"),
    ("xex", "e"),
    ("xix", "i"),
    ("xox", "o"),
    ("xux", "u"),
    ("XAX", "A"),
    ("XEX", "E"),
    ("XIX", "I"),
    ("XOX", "O"),
    ("XUX", "U"),
    ("xxaxx", "a"),
    ("xxexx", "e"),
    ("xxixx", "i"),
    ("xxoxx", "o"),
    ("xxuxx", "u"),
    ("xxaxxexx", "e"),
    ("xxaxxexxi", "e"),
    ("xxaxxexxixx", "i"),
    ("xxaxxexxixxo", "i"),
    ("xxaxxexxixxoxx", "o"),
    ("xxaxxexxixxoxxu", "o"),
    ("xxaxxexxixxoxxuxx", "u"),
])
def test_get_closest_vowel(word, expected):
    assert get_closest_vowel(word) == expected


def test_empty_string():
    assert get_closest_vowel("") == ""


def test_single_character():
    assert get_closest_vowel("a") == ""
    assert get_closest_vowel("b") == ""
    assert get_closest_vowel("A") == ""
    assert get_closest_vowel("B") == ""


def test_two_characters():
    assert get_closest_vowel("ab") == ""
    assert get_closest_vowel("ba") == ""
    assert get_closest_vowel("ae") == ""
    assert get_closest_vowel("ea") == ""
    assert get_closest_vowel("bc") == ""


def test_vowel_at_beginning():
    assert get_closest_vowel("abc") == ""
    assert get_closest_vowel("ebcd") == ""
    assert get_closest_vowel("ibcde") == ""


def test_vowel_at_end():
    assert get_closest_vowel("bca") == ""
    assert get_closest_vowel("bcde") == ""
    assert get_closest_vowel("bcdei") == ""


def test_multiple_valid_vowels():
    assert get_closest_vowel("babeb") == "e"
    assert get_closest_vowel("babebib") == "i"
    assert get_closest_vowel("babebibob") == "o"


def test_case_sensitivity():
    assert get_closest_vowel("bAb") == "A"
    assert get_closest_vowel("bEb") == "E"
    assert get_closest_vowel("bIb") == "I"
    assert get_closest_vowel("bOb") == "O"
    assert get_closest_vowel("bUb") == "U"


def test_consecutive_vowels():
    assert get_closest_vowel("baeb") == ""
    assert get_closest_vowel("baeib") == ""
    assert get_closest_vowel("baeiob") == ""