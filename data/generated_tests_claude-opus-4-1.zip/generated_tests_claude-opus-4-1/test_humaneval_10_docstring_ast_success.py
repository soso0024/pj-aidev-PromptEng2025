# Test cases for HumanEval/10
# Generated using Claude API



def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """ Find the shortest palindrome that begins with a supplied string.
    Algorithm idea is simple:
    - Find the longest postfix of supplied string that is a palindrome.
    - Append to the end of the string reverse of a string prefix that comes before the palindromic suffix.
    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    """

    if not string:
        return ''

    beginning_of_suffix = 0

    while not is_palindrome(string[beginning_of_suffix:]):
        beginning_of_suffix += 1

    return string + string[:beginning_of_suffix][::-1]


# Generated test cases:
import pytest


def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """ Find the shortest palindrome that begins with a supplied string.
    Algorithm idea is simple:
    - Find the longest postfix of supplied string that is a palindrome.
    - Append to the end of the string reverse of a string prefix that comes before the palindromic suffix.
    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    """
    if not string:
        return ''

    beginning_of_suffix = 0

    while not is_palindrome(string[beginning_of_suffix:]):
        beginning_of_suffix += 1

    return string + string[:beginning_of_suffix][::-1]


@pytest.mark.parametrize("input_str,expected", [
    ("", ""),
    ("cat", "catac"),
    ("cata", "catac"),
    ("a", "a"),
    ("aa", "aa"),
    ("ab", "aba"),
    ("abc", "abcba"),
    ("abcd", "abcdcba"),
    ("aba", "aba"),
    ("abab", "ababa"),
    ("abcba", "abcba"),
    ("racecar", "racecar"),
    ("race", "racecar"),
    ("hello", "hellolleh"),
    ("world", "worldlrow"),
    ("aaa", "aaa"),
    ("aaaa", "aaaa"),
    ("abba", "abba"),
    ("abbc", "abbcbba"),
    ("xyz", "xyzyx"),
    ("12321", "12321"),
    ("123", "12321"),
    ("1234", "1234321"),
    ("madam", "madam"),
    ("madamim", "madamimadam"),
    ("nurses", "nursesrun"),
    ("abcdefg", "abcdefgfedcba"),
    ("z", "z"),
    ("zz", "zz"),
    ("zzz", "zzz"),
    ("abcabc", "abcabcbacba"),
    ("abcdcba", "abcdcba"),
    ("abcddcba", "abcddcba"),
    ("abcdedcba", "abcdedcba"),
    ("x", "x"),
    ("xy", "xyx"),
    ("xyx", "xyx"),
    ("xyxy", "xyxyx"),
    ("xyxyx", "xyxyx"),
    ("abcdef", "abcdefedcba"),
    ("fedcba", "fedcbabcdef"),
    ("aabbaa", "aabbaa"),
    ("aabba", "aabbaa"),
    ("aabb", "aabbaa"),
    ("aab", "aabaa"),
    ("baa", "baab"),
    ("baab", "baab"),
    ("baaba", "baabaab"),
    ("baabaa", "baabaab")
])
def test_make_palindrome(input_str, expected):
    assert make_palindrome(input_str) == expected


def test_make_palindrome_result_is_palindrome():
    test_strings = ["", "a", "ab", "abc", "abcd", "hello", "world", "racecar", "madam", "12345"]
    for s in test_strings:
        result = make_palindrome(s)
        assert is_palindrome(result), f"Result '{result}' for input '{s}' is not a palindrome"


def test_make_palindrome_starts_with_original():
    test_strings = ["", "a", "ab", "abc", "abcd", "hello", "world", "racecar", "madam", "12345"]
    for s in test_strings:
        result = make_palindrome(s)
        assert result.startswith(s), f"Result '{result}' does not start with original string '{s}'"


def test_make_palindrome_shortest_possible():
    test_cases = [
        ("abc", 5),
        ("abcba", 5),
        ("abcd", 7),
        ("a", 1),
        ("aa", 2),
        ("aaa", 3)
    ]
    for input_str, expected_len in test_cases:
        result = make_palindrome(input_str)
        assert len(result) == expected_len, f"Result length {len(result)} for '{input_str}' is not optimal (expected {expected_len})"


@pytest.mark.parametrize("input_str", [
    "!@#$%",
    "hello world",
    "123-456",
    "a.b.c",
    "a_b_c",
    "A",
    "AB",
    "ABC",
    "AaBbCc",
    "   ",
    "\t\n",
    "😀",
    "😀😀",
    "hello😀",
    "αβγ",
    "中文",
    "日本語"
])
def test_make_palindrome_special_characters(input_str):
    result = make_palindrome(input_str)
    assert is_palindrome(result)
    assert result.startswith(input_str)


def test_is_palindrome():
    assert is_palindrome("") == True
    assert is_palindrome("a") == True
    assert is_palindrome("aa") == True
    assert is_palindrome("aba") == True
    assert is_palindrome("abba") == True
    assert is_palindrome("racecar") == True
    assert is_palindrome("ab") == False
    assert is_palindrome("abc") == False
    assert is_palindrome("hello") == False
    assert is_palindrome("12321") == True
    assert is_palindrome("12345") == False