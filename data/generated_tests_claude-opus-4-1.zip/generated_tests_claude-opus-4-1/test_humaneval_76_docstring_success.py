# Test cases for HumanEval/76
# Generated using Claude API


def is_simple_power(x, n):
    """Your task is to write a function that returns true if a number x is a simple
    power of n and false in other cases.
    x is a simple power of n if n**int=x
    For example:
    is_simple_power(1, 4) => true
    is_simple_power(2, 2) => true
    is_simple_power(8, 2) => true
    is_simple_power(3, 2) => false
    is_simple_power(3, 1) => false
    is_simple_power(5, 3) => false
    """

    if (n == 1): 
        return (x == 1) 
    power = 1
    while (power < x): 
        power = power * n 
    return (power == x) 


# Generated test cases:
import pytest

def is_simple_power(x, n):
    if (n == 1): 
        return (x == 1) 
    power = 1
    while (power < x): 
        power = power * n 
    return (power == x)


@pytest.mark.parametrize("x,n,expected", [
    # Examples from docstring
    (1, 4, True),
    (2, 2, True),
    (8, 2, True),
    (3, 2, False),
    (3, 1, False),
    (5, 3, False),
    
    # Powers of 2
    (1, 2, True),
    (4, 2, True),
    (16, 2, True),
    (32, 2, True),
    (64, 2, True),
    (128, 2, True),
    (256, 2, True),
    
    # Powers of 3
    (1, 3, True),
    (3, 3, True),
    (9, 3, True),
    (27, 3, True),
    (81, 3, True),
    (243, 3, True),
    
    # Powers of 4
    (1, 4, True),
    (4, 4, True),
    (16, 4, True),
    (64, 4, True),
    (256, 4, True),
    
    # Powers of 5
    (1, 5, True),
    (5, 5, True),
    (25, 5, True),
    (125, 5, True),
    (625, 5, True),
    
    # Edge case: n = 1
    (1, 1, True),
    (2, 1, False),
    (10, 1, False),
    (100, 1, False),
    (0, 1, False),
    
    # Not powers
    (6, 2, False),
    (7, 2, False),
    (10, 2, False),
    (15, 2, False),
    (10, 3, False),
    (26, 3, False),
    (80, 3, False),
    (15, 4, False),
    (63, 4, False),
    (24, 5, False),
    (124, 5, False),
    
    # x = 1 cases
    (1, 2, True),
    (1, 3, True),
    (1, 10, True),
    (1, 100, True),
    
    # Large numbers
    (1024, 2, True),
    (2048, 2, True),
    (4096, 2, True),
    (729, 3, True),
    (2187, 3, True),
    (1000, 10, True),
    (10000, 10, True),
    
    # Non-powers with large numbers
    (1023, 2, False),
    (1025, 2, False),
    (728, 3, False),
    (730, 3, False),
    (999, 10, False),
    (1001, 10, False),
    
    # Small x values
    (0, 2, False),
    (0, 3, False),
    (0, 10, False),
    
    # Base cases
    (2, 2, True),
    (3, 3, True),
    (4, 4, True),
    (5, 5, True),
    (10, 10, True),
    
    # Mixed cases
    (49, 7, True),
    (343, 7, True),
    (36, 6, True),
    (216, 6, True),
    (64, 8, True),
    (512, 8, True),
    (81, 9, True),
    (729, 9, True),
])
def test_is_simple_power(x, n, expected):
    assert is_simple_power(x, n) == expected


def test_is_simple_power_special_cases():
    # Additional edge cases
    assert is_simple_power(1, 1) == True
    assert is_simple_power(1, 1000) == True
    assert is_simple_power(1000000, 10) == True
    assert is_simple_power(1000001, 10) == False
    assert is_simple_power(1048576, 2) == True
    assert is_simple_power(1048577, 2) == False
