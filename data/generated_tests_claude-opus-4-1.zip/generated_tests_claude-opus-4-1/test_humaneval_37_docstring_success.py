# Test cases for HumanEval/37
# Generated using Claude API



def sort_even(l: list):
    """This function takes a list l and returns a list l' such that
    l' is identical to l in the odd indicies, while its values at the even indicies are equal
    to the values of the even indicies of l, but sorted.
    >>> sort_even([1, 2, 3])
    [1, 2, 3]
    >>> sort_even([5, 6, 3, 4])
    [3, 6, 5, 4]
    """

    evens = l[::2]
    odds = l[1::2]
    evens.sort()
    ans = []
    for e, o in zip(evens, odds):
        ans.extend([e, o])
    if len(evens) > len(odds):
        ans.append(evens[-1])
    return ans


# Generated test cases:
import pytest

def sort_even(l: list):
    evens = l[::2]
    odds = l[1::2]
    evens.sort()
    ans = []
    for e, o in zip(evens, odds):
        ans.extend([e, o])
    if len(evens) > len(odds):
        ans.append(evens[-1])
    return ans


@pytest.mark.parametrize("input_list,expected", [
    # Basic cases from docstring
    ([1, 2, 3], [1, 2, 3]),
    ([5, 6, 3, 4], [3, 6, 5, 4]),
    
    # Empty list
    ([], []),
    
    # Single element
    ([1], [1]),
    
    # Two elements
    ([2, 1], [2, 1]),
    ([5, 3], [5, 3]),
    
    # Three elements
    ([3, 2, 1], [1, 2, 3]),
    ([9, 5, 7], [7, 5, 9]),
    
    # Four elements
    ([4, 3, 2, 1], [2, 3, 4, 1]),
    ([10, 20, 30, 40], [10, 20, 30, 40]),
    
    # Five elements
    ([5, 4, 3, 2, 1], [1, 4, 3, 2, 5]),
    ([9, 8, 7, 6, 5], [5, 8, 7, 6, 9]),
    
    # Already sorted even indices
    ([1, 10, 2, 20, 3], [1, 10, 2, 20, 3]),
    
    # Reverse sorted even indices
    ([9, 1, 7, 2, 5, 3, 3], [3, 1, 5, 2, 7, 3, 9]),
    
    # Duplicate values at even indices
    ([5, 1, 5, 2, 5], [5, 1, 5, 2, 5]),
    ([3, 10, 1, 20, 3, 30], [1, 10, 3, 20, 3, 30]),
    
    # Negative numbers
    ([-1, 2, -3, 4], [-3, 2, -1, 4]),
    ([-5, -6, -3, -4], [-5, -6, -3, -4]),
    ([0, -1, -2, -3, -4], [-4, -1, -2, -3, 0]),
    
    # Mixed positive and negative
    ([5, 0, -3, 0, 2], [-3, 0, 2, 0, 5]),
    ([10, -5, -10, 5, 0], [-10, -5, 0, 5, 10]),
    
    # Large numbers
    ([1000, 1, 500, 2, 250], [250, 1, 500, 2, 1000]),
    
    # Floats
    ([3.5, 1.1, 2.2, 4.4], [2.2, 1.1, 3.5, 4.4]),
    ([5.5, 0, 1.1, 0, 3.3], [1.1, 0, 3.3, 0, 5.5]),
    
    # Longer lists
    ([10, 1, 9, 2, 8, 3, 7, 4, 6, 5], [6, 1, 7, 2, 8, 3, 9, 4, 10, 5]),
    ([100, 99, 80, 79, 60, 59, 40, 39, 20, 19, 0], [0, 99, 20, 79, 40, 59, 60, 39, 80, 19, 100]),
])
def test_sort_even(input_list, expected):
    assert sort_even(input_list) == expected


def test_sort_even_preserves_original():
    original = [5, 6, 3, 4]
    original_copy = original.copy()
    result = sort_even(original)
    assert original == original_copy
    assert result == [3, 6, 5, 4]


def test_sort_even_with_strings():
    assert sort_even(['d', 'b', 'c', 'a']) == ['c', 'b', 'd', 'a']
    assert sort_even(['z', 'y', 'x', 'w', 'v']) == ['v', 'y', 'x', 'w', 'z']


def test_sort_even_mixed_types():
    # Numbers that can be compared
    assert sort_even([3, 'a', 1, 'b', 2]) == [1, 'a', 2, 'b', 3]
