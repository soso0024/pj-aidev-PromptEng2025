# Test cases for HumanEval/84
# Generated using Claude API


def solve(N):
    """Given a positive integer N, return the total sum of its digits in binary.
    
    Example
        For N = 1000, the sum of digits will be 1 the output should be "1".
        For N = 150, the sum of digits will be 6 the output should be "110".
        For N = 147, the sum of digits will be 12 the output should be "1100".
    
    Variables:
        @N integer
             Constraints: 0 ≤ N ≤ 10000.
    Output:
         a string of binary number
    """

    return bin(sum(int(i) for i in str(N)))[2:]


# Generated test cases:
import pytest

def solve(N):
    return bin(sum(int(i) for i in str(N)))[2:]

@pytest.mark.parametrize("N,expected", [
    (1000, "1"),
    (150, "110"),
    (147, "1100"),
    (0, "0"),
    (1, "1"),
    (9, "1001"),
    (10, "1"),
    (11, "10"),
    (99, "10010"),
    (100, "1"),
    (999, "11011"),
    (9999, "100100"),
    (10000, "1"),
    (5555, "10100"),
    (1234, "1010"),
    (4321, "1010"),
    (8888, "100000"),
    (7777, "11100"),
    (2468, "10100"),
    (1357, "10000"),
    (5, "101"),
    (15, "110"),
    (25, "111"),
    (35, "1000"),
    (45, "1001"),
    (55, "1010"),
    (65, "1011"),
    (75, "1100"),
    (85, "1101"),
    (95, "1110"),
    (111, "11"),
    (222, "110"),
    (333, "1001"),
    (444, "1100"),
    (555, "1111"),
    (666, "10010"),
    (777, "10101"),
    (888, "11000"),
    (1111, "100"),
    (2222, "1000"),
    (3333, "1100"),
    (4444, "10000"),
    (6666, "11000"),
    (7777, "11100"),
    (8888, "100000"),
    (9999, "100100"),
    (123, "110"),
    (456, "1111"),
    (789, "11000"),
    (2020, "100"),
    (2021, "101"),
    (3000, "11"),
    (4000, "100"),
    (5000, "101"),
    (6000, "110"),
    (7000, "111"),
    (8000, "1000"),
    (9000, "1001")
])
def test_solve(N, expected):
    assert solve(N) == expected

def test_solve_type():
    result = solve(123)
    assert isinstance(result, str)
    assert all(c in '01' for c in result)

def test_solve_zero():
    assert solve(0) == "0"

def test_solve_single_digit():
    for i in range(10):
        result = solve(i)
        assert result == bin(i)[2:]

def test_solve_boundary():
    assert solve(10000) == "1"
    assert solve(9999) == "100100"
