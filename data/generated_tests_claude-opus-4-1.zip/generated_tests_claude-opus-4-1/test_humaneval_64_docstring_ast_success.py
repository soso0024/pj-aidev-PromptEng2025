# Test cases for HumanEval/64
# Generated using Claude API


FIX = """
Add more test cases.
"""

def vowels_count(s):
    """Write a function vowels_count which takes a string representing
    a word as input and returns the number of vowels in the string.
    Vowels in this case are 'a', 'e', 'i', 'o', 'u'. Here, 'y' is also a
    vowel, but only when it is at the end of the given word.

    Example:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    """

    vowels = "aeiouAEIOU"
    n_vowels = sum(c in vowels for c in s)
    if s[-1] == 'y' or s[-1] == 'Y':
        n_vowels += 1
    return n_vowels


# Generated test cases:
import pytest

def vowels_count(s):
    vowels = "aeiouAEIOU"
    n_vowels = sum(c in vowels for c in s)
    if s and (s[-1] == 'y' or s[-1] == 'Y'):
        n_vowels += 1
    return n_vowels


@pytest.mark.parametrize("input_str,expected", [
    ("abcde", 2),
    ("ACEDY", 3),
    ("", 0),
    ("a", 1),
    ("e", 1),
    ("i", 1),
    ("o", 1),
    ("u", 1),
    ("y", 1),
    ("Y", 1),
    ("A", 1),
    ("E", 1),
    ("I", 1),
    ("O", 1),
    ("U", 1),
    ("bcdfg", 0),
    ("BCDFG", 0),
    ("aeiou", 5),
    ("AEIOU", 5),
    ("aeiouy", 6),
    ("AEIOUY", 6),
    ("yaeiou", 5),
    ("YAEIOU", 5),
    ("rhythm", 0),
    ("fly", 1),
    ("FLY", 1),
    ("sky", 1),
    ("SKY", 1),
    ("happy", 2),
    ("HAPPY", 2),
    ("yellow", 2),
    ("YELLOW", 2),
    ("yay", 2),
    ("YAY", 2),
    ("yyy", 1),
    ("YYY", 1),
    ("aaa", 3),
    ("AAA", 3),
    ("xyz", 0),
    ("XYZ", 0),
    ("boy", 2),
    ("BOY", 2),
    ("toy", 2),
    ("TOY", 2),
    ("gym", 0),
    ("GYM", 0),
    ("syzygy", 1),
    ("SYZYGY", 1),
    ("AeIoUy", 6),
    ("aEiOuY", 6),
    ("bcdfghjklmnpqrstvwxz", 0),
    ("BCDFGHJKLMNPQRSTVWXZ", 0),
    ("1234567890", 0),
    ("!@#$%^&*()", 0),
    ("a1e2i3o4u5", 5),
    ("A1E2I3O4U5", 5),
    ("hello world", 3),
    ("HELLO WORLD", 3),
    ("Python", 1),
    ("PYTHON", 1),
    ("yesterday", 4),
    ("YESTERDAY", 4),
    ("yoyo", 2),
    ("YOYO", 2),
    ("ayaya", 3),
    ("AYAYA", 3),
    ("yayayay", 4),
    ("YAYAYAY", 4),
])
def test_vowels_count(input_str, expected):
    assert vowels_count(input_str) == expected


def test_vowels_count_single_char_vowels():
    for vowel in "aeiouAEIOU":
        assert vowels_count(vowel) == 1
    for vowel in "yY":
        assert vowels_count(vowel) == 1


def test_vowels_count_single_char_consonants():
    for consonant in "bcdfghjklmnpqrstvwxzBCDFGHJKLMNPQRSTVWXZ":
        assert vowels_count(consonant) == 0


def test_vowels_count_y_position():
    assert vowels_count("ya") == 1
    assert vowels_count("ay") == 2
    assert vowels_count("yay") == 2
    assert vowels_count("yyy") == 1
    assert vowels_count("ayaya") == 3
    assert vowels_count("ayayay") == 4