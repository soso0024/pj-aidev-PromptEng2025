# Test cases for HumanEval/47
# Generated using Claude API



def median(l: list):
    """Return median of elements in the list l.
    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """

    l = sorted(l)
    if len(l) % 2 == 1:
        return l[len(l) // 2]
    else:
        return (l[len(l) // 2 - 1] + l[len(l) // 2]) / 2.0


# Generated test cases:
import pytest

@pytest.mark.parametrize("input_list,expected", [
    # Odd number of elements
    ([1], 1),
    ([3, 1, 2], 2),
    ([5, 3, 1, 4, 2], 3),
    ([7], 7),
    ([9, 1, 5], 5),
    
    # Even number of elements
    ([1, 2], 1.5),
    ([1, 2, 3, 4], 2.5),
    ([10, 20], 15.0),
    ([1, 3, 5, 7], 4.0),
    ([2, 4, 6, 8, 10, 12], 7.0),
    
    # Negative numbers
    ([-1], -1),
    ([-5, -3, -1], -3),
    ([-2, -1], -1.5),
    ([-10, -5, 0, 5], -2.5),
    
    # Mixed positive and negative
    ([-1, 0, 1], 0),
    ([-2, -1, 1, 2], 0.0),
    ([-5, -2, 3, 7, 9], 3),
    
    # Floating point numbers
    ([1.5], 1.5),
    ([1.5, 2.5], 2.0),
    ([1.1, 2.2, 3.3], 2.2),
    ([0.5, 1.5, 2.5, 3.5], 2.0),
    
    # Duplicate values
    ([1, 1, 1], 1),
    ([2, 2, 2, 2], 2.0),
    ([1, 2, 2, 3], 2.0),
    ([5, 5, 5, 5, 5], 5),
    
    # Already sorted
    ([1, 2, 3, 4, 5], 3),
    ([10, 20, 30, 40], 25.0),
    
    # Reverse sorted
    ([5, 4, 3, 2, 1], 3),
    ([40, 30, 20, 10], 25.0),
    
    # Random order
    ([3, 7, 1, 4, 6, 2, 5], 4),
    ([100, 50, 75, 25], 62.5),
    
    # Large numbers
    ([1000000], 1000000),
    ([1000000, 2000000], 1500000.0),
    
    # Zero
    ([0], 0),
    ([0, 0], 0.0),
    ([-1, 0, 1], 0),
    
    # Edge case with two elements
    ([100, 1], 50.5),
    ([-100, 100], 0.0),
])
def test_median(input_list, expected):
    assert median(input_list) == expected

def test_median_empty_list():
    with pytest.raises(IndexError):
        median([])

def test_median_preserves_original_list():
    original = [3, 1, 2]
    original_copy = original.copy()
    result = median(original)
    assert original == original_copy
    assert result == 2

def test_median_with_inf():
    import math
    assert median([float('inf')]) == float('inf')
    assert median([float('-inf')]) == float('-inf')
    assert math.isnan(median([float('-inf'), float('inf')]))
    assert median([1, 2, float('inf')]) == 2

def test_median_with_very_close_floats():
    assert median([1.0000001, 1.0000002, 1.0000003]) == 1.0000002
    
def test_median_large_list():
    large_list = list(range(1, 1001))
    assert median(large_list) == 500.5
    
def test_median_single_negative():
    assert median([-42]) == -42

def test_median_all_same_values():
    assert median([7, 7, 7, 7, 7, 7, 7]) == 7