# Test cases for HumanEval/120
# Generated using Claude API


def maximum(arr, k):
    """
    Given an array arr of integers and a positive integer k, return a sorted list 
    of length k with the maximum k numbers in arr.

    Example 1:

        Input: arr = [-3, -4, 5], k = 3
        Output: [-4, -3, 5]

    Example 2:

        Input: arr = [4, -4, 4], k = 2
        Output: [4, 4]

    Example 3:

        Input: arr = [-3, 2, 1, 2, -1, -2, 1], k = 1
        Output: [2]

    Note:
        1. The length of the array will be in the range of [1, 1000].
        2. The elements in the array will be in the range of [-1000, 1000].
        3. 0 <= k <= len(arr)
    """

    if k == 0:
        return []
    arr.sort()
    ans = arr[-k:]
    return ans


# Generated test cases:
import pytest

@pytest.mark.parametrize("arr,k,expected", [
    ([-3, -4, 5], 3, [-4, -3, 5]),
    ([4, -4, 4], 2, [4, 4]),
    ([-3, 2, 1, 2, -1, -2, 1], 1, [2]),
    ([1], 1, [1]),
    ([1], 0, []),
    ([5, 4, 3, 2, 1], 0, []),
    ([5, 4, 3, 2, 1], 5, [1, 2, 3, 4, 5]),
    ([5, 4, 3, 2, 1], 3, [3, 4, 5]),
    ([1, 2, 3, 4, 5], 2, [4, 5]),
    ([-5, -4, -3, -2, -1], 2, [-2, -1]),
    ([-5, -4, -3, -2, -1], 5, [-5, -4, -3, -2, -1]),
    ([0, 0, 0, 0], 2, [0, 0]),
    ([0, 0, 0, 0], 4, [0, 0, 0, 0]),
    ([10, -10, 5, -5, 0], 3, [0, 5, 10]),
    ([10, -10, 5, -5, 0], 5, [-10, -5, 0, 5, 10]),
    ([1000, -1000, 500, -500], 2, [500, 1000]),
    ([1000, -1000, 500, -500], 4, [-1000, -500, 500, 1000]),
    ([7, 7, 7, 7, 7], 3, [7, 7, 7]),
    ([1, 1, 2, 2, 3, 3], 4, [2, 2, 3, 3]),
    ([9, 8, 7, 6, 5, 4, 3, 2, 1, 0], 1, [9]),
    ([9, 8, 7, 6, 5, 4, 3, 2, 1, 0], 10, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]),
    ([-1, -2, -3, -4, -5, -6], 3, [-3, -2, -1]),
    ([100], 0, []),
    ([-100], 1, [-100]),
    ([5, 2, 8, 1, 9, 3, 7], 4, [5, 7, 8, 9]),
    ([42], 1, [42]),
    ([3, 1, 4, 1, 5, 9, 2, 6], 5, [3, 4, 5, 6, 9]),
])
def test_maximum(arr, k, expected):
    assert maximum(arr, k) == expected

def test_maximum_does_not_modify_original():
    arr = [5, 3, 1, 4, 2]
    original = arr.copy()
    result = maximum(arr.copy(), 3)
    assert arr == original
    assert result == [3, 4, 5]

def test_maximum_with_negative_numbers():
    assert maximum([-10, -20, -30, -5, -15], 2) == [-10, -5]

def test_maximum_all_same_elements():
    assert maximum([5, 5, 5, 5, 5], 3) == [5, 5, 5]

def test_maximum_mixed_positive_negative():
    assert maximum([-3, -1, 0, 2, 4], 3) == [0, 2, 4]