# Test cases for HumanEval/128
# Generated using Claude API


def prod_signs(arr):
    """
    You are given an array arr of integers and you need to return
    sum of magnitudes of integers multiplied by product of all signs
    of each number in the array, represented by 1, -1 or 0.
    Note: return None for empty arr.

    Example:
    >>> prod_signs([1, 2, 2, -4]) == -9
    >>> prod_signs([0, 1]) == 0
    >>> prod_signs([]) == None
    """

    if not arr: return None
    prod = 0 if 0 in arr else (-1) ** len(list(filter(lambda x: x < 0, arr)))
    return prod * sum([abs(i) for i in arr])


# Generated test cases:
import pytest

@pytest.mark.parametrize("arr,expected", [
    # Empty array
    ([], None),
    
    # Single element arrays
    ([0], 0),
    ([1], 1),
    ([-1], -1),
    ([5], 5),
    ([-5], -5),
    
    # Arrays with zero
    ([0, 1], 0),
    ([1, 0], 0),
    ([0, 0], 0),
    ([0, 1, 2, 3], 0),
    ([-1, -2, 0, 3], 0),
    ([0, -1, -2, -3], 0),
    
    # All positive numbers
    ([1, 2, 3], 6),
    ([1, 1, 1], 3),
    ([2, 4, 6], 12),
    ([10, 20], 30),
    
    # All negative numbers
    ([-1, -2, -3], -6),  # odd number of negatives
    ([-1, -2], 3),      # even number of negatives
    ([-1], -1),         # odd number of negatives
    ([-1, -2, -3, -4], 10),  # even number of negatives
    ([-5, -10, -15], -30),   # odd number of negatives
    
    # Mixed positive and negative
    ([1, 2, 2, -4], -9),
    ([1, -1], -2),
    ([-1, 1], -2),
    ([1, -2, 3], -6),
    ([-1, -2, 3], 6),
    ([1, 2, -3, -4], 10),
    ([-1, 2, -3, 4], 10),
    ([1, -2, 3, -4, 5], 15),
    
    # Large numbers
    ([100, -200, 300], -600),
    ([-1000], -1000),
    ([1000, 2000], 3000),
    
    # Multiple same values
    ([2, 2, 2], 6),
    ([-2, -2, -2], -6),
    ([3, 3, -3, -3], 12),
])
def test_prod_signs(arr, expected):
    assert prod_signs(arr) == expected

def test_prod_signs_type():
    assert prod_signs([]) is None
    assert isinstance(prod_signs([1, 2, 3]), int)
    assert isinstance(prod_signs([0]), int)