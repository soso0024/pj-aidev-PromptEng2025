# Test cases for HumanEval/159
# Generated using Claude API


def eat(number, need, remaining):
    """
    You're a hungry rabbit, and you already have eaten a certain number of carrots,
    but now you need to eat more carrots to complete the day's meals.
    you should return an array of [ total number of eaten carrots after your meals,
                                    the number of carrots left after your meals ]
    if there are not enough remaining carrots, you will eat all remaining carrots, but will still be hungry.
    
    Example:
    * eat(5, 6, 10) -> [11, 4]
    * eat(4, 8, 9) -> [12, 1]
    * eat(1, 10, 10) -> [11, 0]
    * eat(2, 11, 5) -> [7, 0]
    
    Variables:
    @number : integer
        the number of carrots that you have eaten.
    @need : integer
        the number of carrots that you need to eat.
    @remaining : integer
        the number of remaining carrots thet exist in stock
    
    Constrain:
    * 0 <= number <= 1000
    * 0 <= need <= 1000
    * 0 <= remaining <= 1000

    Have fun :)
    """

    if(need <= remaining):
        return [ number + need , remaining-need ]
    else:
        return [ number + remaining , 0]


# Generated test cases:
import pytest

def eat(number, need, remaining):
    if(need <= remaining):
        return [ number + need , remaining-need ]
    else:
        return [ number + remaining , 0]

@pytest.mark.parametrize("number,need,remaining,expected", [
    # Examples from docstring
    (5, 6, 10, [11, 4]),
    (4, 8, 9, [12, 1]),
    (1, 10, 10, [11, 0]),
    (2, 11, 5, [7, 0]),
    
    # Edge cases - zeros
    (0, 0, 0, [0, 0]),
    (0, 0, 10, [0, 10]),
    (0, 10, 0, [0, 0]),
    (10, 0, 0, [10, 0]),
    (10, 0, 10, [10, 10]),
    (0, 10, 10, [10, 0]),
    (10, 10, 0, [10, 0]),
    
    # Edge cases - boundary values
    (1000, 0, 0, [1000, 0]),
    (0, 1000, 0, [0, 0]),
    (0, 0, 1000, [0, 1000]),
    (1000, 1000, 1000, [2000, 0]),
    (999, 1, 1000, [1000, 999]),
    (1, 999, 1000, [1000, 1]),
    
    # Normal cases - enough remaining
    (10, 5, 20, [15, 15]),
    (100, 50, 200, [150, 150]),
    (25, 25, 25, [50, 0]),
    (50, 100, 100, [150, 0]),
    
    # Normal cases - not enough remaining
    (10, 20, 5, [15, 0]),
    (100, 200, 50, [150, 0]),
    (25, 50, 10, [35, 0]),
    (500, 600, 100, [600, 0]),
    
    # Cases where need equals remaining
    (5, 10, 10, [15, 0]),
    (0, 100, 100, [100, 0]),
    (50, 50, 50, [100, 0]),
    
    # Cases where need is less than remaining
    (5, 3, 10, [8, 7]),
    (100, 1, 500, [101, 499]),
    (0, 50, 100, [50, 50]),
    
    # Large numbers
    (900, 100, 100, [1000, 0]),
    (500, 500, 500, [1000, 0]),
    (333, 333, 334, [666, 1]),
])
def test_eat(number, need, remaining, expected):
    assert eat(number, need, remaining) == expected

def test_eat_return_type():
    result = eat(5, 6, 10)
    assert isinstance(result, list)
    assert len(result) == 2
    assert isinstance(result[0], int)
    assert isinstance(result[1], int)

def test_eat_non_negative_results():
    for number in [0, 10, 100]:
        for need in [0, 10, 100]:
            for remaining in [0, 10, 100]:
                result = eat(number, need, remaining)
                assert result[0] >= 0
                assert result[1] >= 0
