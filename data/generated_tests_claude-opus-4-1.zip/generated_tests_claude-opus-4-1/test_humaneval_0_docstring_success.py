# Test cases for HumanEval/0
# Generated using Claude API

from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """

    for idx, elem in enumerate(numbers):
        for idx2, elem2 in enumerate(numbers):
            if idx != idx2:
                distance = abs(elem - elem2)
                if distance < threshold:
                    return True

    return False


# Generated test cases:
import pytest
from typing import List


@pytest.mark.parametrize("numbers,threshold,expected", [
    # Basic cases from docstring
    ([1.0, 2.0, 3.0], 0.5, False),
    ([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3, True),
    
    # Empty list
    ([], 1.0, False),
    
    # Single element
    ([1.0], 1.0, False),
    
    # Two elements - close
    ([1.0, 1.5], 0.6, True),
    ([1.0, 1.5], 0.5, False),
    ([1.0, 1.5], 0.51, True),
    
    # Two elements - far
    ([1.0, 10.0], 1.0, False),
    
    # Negative numbers
    ([-1.0, -1.5, -2.0], 0.6, True),
    ([-1.0, -1.5, -2.0], 0.4, False),
    
    # Mixed positive and negative
    ([-1.0, 0.0, 1.0], 1.1, True),
    ([-1.0, 0.0, 1.0], 1.0, False),
    ([-1.0, 0.0, 1.0], 0.9, False),
    
    # Zero threshold
    ([1.0, 2.0, 3.0], 0.0, False),
    ([1.0, 1.0, 2.0], 0.0, False),
    
    # Very small threshold
    ([1.0, 1.0000001, 2.0], 0.000001, True),
    ([1.0, 1.0000001, 2.0], 0.0000001, False),
    
    # Large numbers
    ([1000000.0, 1000001.0, 1000002.0], 1.5, True),
    ([1000000.0, 1000001.0, 1000002.0], 0.5, False),
    
    # Duplicate values
    ([1.0, 1.0], 0.1, True),
    ([1.0, 1.0], 0.0, False),
    ([1.0, 2.0, 1.0], 0.1, True),
    
    # Multiple close pairs
    ([1.0, 1.1, 2.0, 2.1, 3.0], 0.2, True),
    ([1.0, 1.1, 2.0, 2.1, 3.0], 0.05, False),
    
    # Edge case with exact threshold
    ([1.0, 2.0], 1.0, False),
    ([1.0, 2.0], 1.000001, True),
    
    # Floating point precision
    ([0.1, 0.2, 0.3], 0.1, True),
    ([0.1, 0.2, 0.3], 0.100001, True),
    
    # Large list
    (list(range(0, 100, 10)), 5.0, False),
    (list(range(0, 100, 10)), 10.0, False),
    (list(range(0, 100, 10)), 10.1, True),
])
def test_has_close_elements(numbers, threshold, expected):
    assert has_close_elements(numbers, threshold) == expected


def test_has_close_elements_with_floats():
    assert has_close_elements([1.0, 1.9999999], 0.0000002) == False
    assert has_close_elements([1.0, 1.9999999], 0.0000001) == False


def test_has_close_elements_order_independence():
    numbers1 = [1.0, 2.0, 3.0, 4.0]
    numbers2 = [4.0, 3.0, 2.0, 1.0]
    assert has_close_elements(numbers1, 1.5) == has_close_elements(numbers2, 1.5)


def test_has_close_elements_negative_threshold():
    # Negative threshold should never find close elements
    assert has_close_elements([1.0, 1.0], -1.0) == False
    assert has_close_elements([0.0, 0.0], -0.1) == False