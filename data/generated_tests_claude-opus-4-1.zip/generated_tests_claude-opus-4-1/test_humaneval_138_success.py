# Test cases for HumanEval/138
# Generated using Claude API


def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """

    return n%2 == 0 and n >= 8


# Generated test cases:
import pytest


@pytest.mark.parametrize("n,expected", [
    # Even numbers >= 8 (should return True)
    (8, True),
    (10, True),
    (12, True),
    (100, True),
    (1000, True),
    (999998, True),
    
    # Even numbers < 8 (should return False)
    (0, False),
    (2, False),
    (4, False),
    (6, False),
    (-2, False),
    (-4, False),
    (-100, False),
    
    # Odd numbers (should return False)
    (1, False),
    (3, False),
    (5, False),
    (7, False),
    (9, False),
    (11, False),
    (99, False),
    (999999, False),
    (-1, False),
    (-3, False),
    (-99, False),
    
    # Edge cases
    (8.0, True),  # Float that equals 8
    (10.0, True),  # Float that equals 10
    (-8, False),  # Negative even number
    (-10, False),  # Negative even number
])
def test_is_equal_to_sum_even(n, expected):
    assert is_equal_to_sum_even(n) == expected


def test_is_equal_to_sum_even_type_errors():
    with pytest.raises(TypeError):
        is_equal_to_sum_even("8")
    with pytest.raises(TypeError):
        is_equal_to_sum_even(None)
    with pytest.raises(TypeError):
        is_equal_to_sum_even([8])
    with pytest.raises(TypeError):
        is_equal_to_sum_even({8})


def test_is_equal_to_sum_even_float_values():
    # Non-integer floats work with modulo operator
    assert is_equal_to_sum_even(8.5) == False
    assert is_equal_to_sum_even(9.1) == False
    assert is_equal_to_sum_even(10.2) == False