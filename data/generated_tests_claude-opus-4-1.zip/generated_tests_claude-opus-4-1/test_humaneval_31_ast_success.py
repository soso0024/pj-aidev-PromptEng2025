# Test cases for HumanEval/31
# Generated using Claude API



def is_prime(n):
    """Return true if a given number is prime, and false otherwise.
    >>> is_prime(6)
    False
    >>> is_prime(101)
    True
    >>> is_prime(11)
    True
    >>> is_prime(13441)
    True
    >>> is_prime(61)
    True
    >>> is_prime(4)
    False
    >>> is_prime(1)
    False
    """

    if n < 2:
        return False
    for k in range(2, n - 1):
        if n % k == 0:
            return False
    return True


# Generated test cases:
import pytest

def is_prime(n):
    if n < 2:
        return False
    for k in range(2, n - 1):
        if n % k == 0:
            return False
    return True

@pytest.mark.parametrize("n,expected", [
    (0, False),
    (1, False),
    (-1, False),
    (-5, False),
    (-100, False),
    (2, True),
    (3, True),
    (4, False),
    (5, True),
    (6, False),
    (7, True),
    (8, False),
    (9, False),
    (10, False),
    (11, True),
    (12, False),
    (13, True),
    (17, True),
    (19, True),
    (20, False),
    (23, True),
    (25, False),
    (29, True),
    (31, True),
    (37, True),
    (41, True),
    (43, True),
    (47, True),
    (49, False),
    (53, True),
    (59, True),
    (61, True),
    (67, True),
    (71, True),
    (73, True),
    (79, True),
    (83, True),
    (89, True),
    (97, True),
    (100, False),
    (101, True),
    (121, False),
    (169, False),
])
def test_is_prime(n, expected):
    assert is_prime(n) == expected

def test_is_prime_negative_numbers():
    for n in range(-10, 0):
        assert is_prime(n) == False

def test_is_prime_small_composites():
    composites = [4, 6, 8, 9, 10, 12, 14, 15, 16, 18, 20]
    for n in composites:
        assert is_prime(n) == False

def test_is_prime_small_primes():
    primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]
    for n in primes:
        assert is_prime(n) == True

def test_is_prime_perfect_squares():
    perfect_squares = [4, 9, 16, 25, 36, 49, 64, 81, 100]
    for n in perfect_squares:
        assert is_prime(n) == False
