# Test cases for HumanEval/102
# Generated using Claude API


def choose_num(x, y):
    """This function takes two positive numbers x and y and returns the
    biggest even integer number that is in the range [x, y] inclusive. If 
    there's no such number, then the function should return -1.

    For example:
    choose_num(12, 15) = 14
    choose_num(13, 12) = -1
    """

    if x > y:
        return -1
    if y % 2 == 0:
        return y
    if x == y:
        return -1
    return y - 1


# Generated test cases:
import pytest

def choose_num(x, y):
    if x > y:
        return -1
    if y % 2 == 0:
        return y
    if x == y:
        return -1
    return y - 1

@pytest.mark.parametrize("x,y,expected", [
    # x > y cases
    (10, 5, -1),
    (100, 50, -1),
    (1, 0, -1),
    (-5, -10, -1),
    
    # y is even (and x <= y)
    (1, 10, 10),
    (5, 10, 10),
    (10, 10, 10),
    (0, 0, 0),
    (-10, -4, -4),
    (2, 8, 8),
    (-100, 100, 100),
    
    # x == y and y is odd
    (5, 5, -1),
    (7, 7, -1),
    (1, 1, -1),
    (-3, -3, -1),
    (999, 999, -1),
    
    # x < y and y is odd
    (1, 5, 4),
    (2, 7, 6),
    (0, 1, 0),
    (10, 11, 10),
    (-10, -5, -6),
    (98, 99, 98),
    
    # Edge cases with negative numbers
    (-10, -8, -8),
    (-11, -9, -10),
    (-1, -1, -1),
    (-2, -1, -2),
    
    # Zero cases
    (0, 2, 2),
    (0, 3, 2),
    (-1, 0, 0),
    
    # Large numbers
    (1000, 1000, 1000),
    (999, 1000, 1000),
    (998, 999, 998),
])
def test_choose_num(x, y, expected):
    assert choose_num(x, y) == expected

def test_choose_num_types():
    # Test with integer inputs
    assert isinstance(choose_num(1, 2), int)
    assert isinstance(choose_num(5, 3), int)
    assert isinstance(choose_num(4, 7), int)
