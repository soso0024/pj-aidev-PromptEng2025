# Test cases for HumanEval/42
# Generated using Claude API



def incr_list(l: list):
    """Return list with elements incremented by 1.
    >>> incr_list([1, 2, 3])
    [2, 3, 4]
    >>> incr_list([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [6, 4, 6, 3, 4, 4, 10, 1, 124]
    """

    return [(e + 1) for e in l]


# Generated test cases:
import pytest


@pytest.mark.parametrize("input_list,expected", [
    ([], []),
    ([0], [1]),
    ([1, 2, 3], [2, 3, 4]),
    ([-1, 0, 1], [0, 1, 2]),
    ([10, 20, 30], [11, 21, 31]),
    ([-5, -10, -15], [-4, -9, -14]),
    ([0.5, 1.5, 2.5], [1.5, 2.5, 3.5]),
    ([100], [101]),
    ([1, 1, 1, 1], [2, 2, 2, 2]),
    (list(range(10)), list(range(1, 11))),
    ([999999], [1000000]),
    ([-999999], [-999998]),
    ([float('inf')], [float('inf')]),
    ([float('-inf')], [float('-inf')]),
])
def test_incr_list_normal_cases(input_list, expected):
    assert incr_list(input_list) == expected


def test_incr_list_empty():
    assert incr_list([]) == []


def test_incr_list_single_element():
    assert incr_list([5]) == [6]


def test_incr_list_negative_numbers():
    assert incr_list([-3, -2, -1]) == [-2, -1, 0]


def test_incr_list_mixed_numbers():
    assert incr_list([-2, 0, 2]) == [-1, 1, 3]


def test_incr_list_large_numbers():
    assert incr_list([1000000, 2000000]) == [1000001, 2000001]


def test_incr_list_floats():
    result = incr_list([1.1, 2.2, 3.3])
    expected = [2.1, 3.2, 4.3]
    for r, e in zip(result, expected):
        assert abs(r - e) < 0.0001


def test_incr_list_does_not_modify_original():
    original = [1, 2, 3]
    original_copy = original.copy()
    result = incr_list(original)
    assert original == original_copy
    assert result == [2, 3, 4]


def test_incr_list_with_zero():
    assert incr_list([0, 0, 0]) == [1, 1, 1]


@pytest.mark.parametrize("invalid_input", [
    None,
    "string",
    123,
    {"key": "value"},
])
def test_incr_list_invalid_input_type(invalid_input):
    with pytest.raises((TypeError, AttributeError)):
        incr_list(invalid_input)


def test_incr_list_with_tuple():
    # Tuples work with list comprehension iteration
    assert incr_list((1, 2, 3)) == [2, 3, 4]


def test_incr_list_with_non_numeric_elements():
    with pytest.raises(TypeError):
        incr_list(["a", "b", "c"])
    
    with pytest.raises(TypeError):
        incr_list([1, "2", 3])
    
    with pytest.raises(TypeError):
        incr_list([None, None])


def test_incr_list_with_complex_numbers():
    result = incr_list([1+2j, 3+4j])
    expected = [2+2j, 4+4j]
    assert result == expected


def test_incr_list_with_boolean():
    assert incr_list([True, False]) == [2, 1]


def test_incr_list_long_list():
    input_list = list(range(1000))
    expected = list(range(1, 1001))
    assert incr_list(input_list) == expected