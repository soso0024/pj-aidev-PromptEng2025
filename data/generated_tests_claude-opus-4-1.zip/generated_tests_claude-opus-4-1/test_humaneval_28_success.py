# Test cases for HumanEval/28
# Generated using Claude API

from typing import List


def concatenate(strings: List[str]) -> str:
    """ Concatenate list of strings into a single string
    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """

    return ''.join(strings)


# Generated test cases:
import pytest
from typing import List


def concatenate(strings: List[str]) -> str:
    return ''.join(strings)


class TestConcatenate:
    
    @pytest.mark.parametrize("input_strings,expected", [
        (["hello", "world"], "helloworld"),
        (["a", "b", "c"], "abc"),
        ([""], ""),
        (["single"], "single"),
        (["hello", " ", "world"], "hello world"),
        (["123", "456"], "123456"),
        (["", "", ""], ""),
        (["hello", "", "world"], "helloworld"),
        (["", "test", ""], "test"),
    ])
    def test_normal_cases(self, input_strings, expected):
        assert concatenate(input_strings) == expected
    
    def test_empty_list(self):
        assert concatenate([]) == ""
    
    def test_single_empty_string(self):
        assert concatenate([""]) == ""
    
    def test_multiple_empty_strings(self):
        assert concatenate(["", "", "", ""]) == ""
    
    def test_special_characters(self):
        assert concatenate(["@", "#", "$", "%"]) == "@#$%"
        assert concatenate(["hello\n", "world\t"]) == "hello\nworld\t"
    
    def test_unicode_characters(self):
        assert concatenate(["こんにちは", "世界"]) == "こんにちは世界"
        assert concatenate(["😀", "😁", "😂"]) == "😀😁😂"
    
    def test_mixed_types_strings(self):
        assert concatenate(["123", "abc", "!@#"]) == "123abc!@#"
    
    def test_long_strings(self):
        long_str = "a" * 1000
        assert concatenate([long_str, long_str]) == "a" * 2000
    
    def test_whitespace_strings(self):
        assert concatenate([" ", "  ", "   "]) == "      "
        assert concatenate(["\n", "\t", "\r"]) == "\n\t\r"
    
    @pytest.mark.parametrize("input_strings", [
        ["first", "second", "third", "fourth", "fifth"],
        ["a"] * 100,
        ["line1\n", "line2\n", "line3\n"],
    ])
    def test_multiple_strings(self, input_strings):
        expected = ''.join(input_strings)
        assert concatenate(input_strings) == expected
    
    def test_quotes_in_strings(self):
        assert concatenate(["'single'", '"double"']) == "'single'\"double\""
        assert concatenate(['he said "hello"', "it's fine"]) == 'he said "hello"it\'s fine'
