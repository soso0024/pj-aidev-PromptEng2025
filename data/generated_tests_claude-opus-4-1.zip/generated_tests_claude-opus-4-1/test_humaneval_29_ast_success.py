# Test cases for HumanEval/29
# Generated using Claude API

from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    """ Filter an input list of strings only for ones that start with a given prefix.
    >>> filter_by_prefix([], 'a')
    []
    >>> filter_by_prefix(['abc', 'bcd', 'cde', 'array'], 'a')
    ['abc', 'array']
    """

    return [x for x in strings if x.startswith(prefix)]


# Generated test cases:
import pytest
from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    return [x for x in strings if x.startswith(prefix)]


@pytest.mark.parametrize("strings,prefix,expected", [
    ([], "", []),
    ([], "a", []),
    ([""], "", [""]),
    ([""], "a", []),
    (["a"], "", ["a"]),
    (["a"], "a", ["a"]),
    (["a"], "b", []),
    (["abc", "bcd", "cde"], "a", ["abc"]),
    (["abc", "bcd", "cde"], "b", ["bcd"]),
    (["abc", "bcd", "cde"], "c", ["cde"]),
    (["abc", "bcd", "cde"], "d", []),
    (["abc", "bcd", "cde"], "", ["abc", "bcd", "cde"]),
    (["apple", "apricot", "banana", "application"], "app", ["apple", "application"]),
    (["apple", "apricot", "banana", "application"], "apr", ["apricot"]),
    (["apple", "apricot", "banana", "application"], "ban", ["banana"]),
    (["apple", "apricot", "banana", "application"], "orange", []),
    (["test", "testing", "tester", "contest"], "test", ["test", "testing", "tester"]),
    (["hello", "world", "hello world"], "hello", ["hello", "hello world"]),
    (["123", "456", "123456"], "123", ["123", "123456"]),
    (["", "a", "aa", "aaa"], "a", ["a", "aa", "aaa"]),
    (["ABC", "abc", "AbC"], "A", ["ABC", "AbC"]),
    (["ABC", "abc", "AbC"], "a", ["abc"]),
    (["  spaces", "spaces", " spaces"], " ", ["  spaces", " spaces"]),
    (["prefix", "prefixed", "pre", "fix"], "prefix", ["prefix", "prefixed"]),
    (["a" * 100, "b" * 100, "a" * 50 + "b" * 50], "a" * 50, ["a" * 100, "a" * 50 + "b" * 50]),
    (["one"], "one", ["one"]),
    (["one"], "ones", []),
    (["ones"], "one", ["ones"]),
    (["!@#", "$%^", "!@#$%^"], "!@#", ["!@#", "!@#$%^"]),
    (["unicode_🎉", "unicode_🎊", "other"], "unicode_", ["unicode_🎉", "unicode_🎊"]),
    (["\n", "\t", "\n\t"], "\n", ["\n", "\n\t"]),
    (["case", "Case", "CASE"], "case", ["case"]),
    (["a", "aa", "aaa", "aaaa", "aaaaa"], "aaa", ["aaa", "aaaa", "aaaaa"]),
])
def test_filter_by_prefix(strings, prefix, expected):
    assert filter_by_prefix(strings, prefix) == expected


def test_filter_by_prefix_empty_list():
    assert filter_by_prefix([], "test") == []


def test_filter_by_prefix_empty_prefix():
    assert filter_by_prefix(["a", "b", "c"], "") == ["a", "b", "c"]


def test_filter_by_prefix_no_matches():
    assert filter_by_prefix(["apple", "banana", "cherry"], "z") == []


def test_filter_by_prefix_all_match():
    assert filter_by_prefix(["test1", "test2", "test3"], "test") == ["test1", "test2", "test3"]


def test_filter_by_prefix_single_element_match():
    assert filter_by_prefix(["hello"], "hel") == ["hello"]


def test_filter_by_prefix_single_element_no_match():
    assert filter_by_prefix(["hello"], "bye") == []


def test_filter_by_prefix_preserves_order():
    assert filter_by_prefix(["cat", "car", "dog", "can"], "ca") == ["cat", "car", "can"]


def test_filter_by_prefix_exact_match():
    assert filter_by_prefix(["test", "testing", "tested"], "test") == ["test", "testing", "tested"]


def test_filter_by_prefix_longer_prefix_than_string():
    assert filter_by_prefix(["a", "ab", "abc"], "abcd") == []


def test_filter_by_prefix_with_duplicates():
    assert filter_by_prefix(["test", "test", "other", "test"], "test") == ["test", "test", "test"]
