# Test cases for HumanEval/45
# Generated using Claude API



def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """

    return a * h / 2.0


# Generated test cases:
import pytest
import math

def triangle_area(a, h):
    return a * h / 2.0

class TestTriangleArea:
    
    @pytest.mark.parametrize("base,height,expected", [
        (10, 5, 25.0),
        (5, 10, 25.0),
        (1, 1, 0.5),
        (100, 200, 10000.0),
        (3.5, 4.2, 7.35),
        (0.1, 0.1, 0.005),
    ])
    def test_normal_cases(self, base, height, expected):
        assert triangle_area(base, height) == pytest.approx(expected)
    
    @pytest.mark.parametrize("base,height,expected", [
        (0, 5, 0.0),
        (5, 0, 0.0),
        (0, 0, 0.0),
    ])
    def test_zero_cases(self, base, height, expected):
        assert triangle_area(base, height) == expected
    
    @pytest.mark.parametrize("base,height", [
        (-5, 10),
        (10, -5),
        (-10, -5),
    ])
    def test_negative_values(self, base, height):
        result = triangle_area(base, height)
        assert result == base * height / 2.0
    
    @pytest.mark.parametrize("base,height,expected", [
        (1e-10, 1e-10, 5e-21),
        (1e10, 1e10, 5e19),
        (math.pi, math.e, math.pi * math.e / 2),
        (2/3, 3/4, 0.25),
    ])
    def test_special_numbers(self, base, height, expected):
        assert triangle_area(base, height) == pytest.approx(expected)
    
    def test_float_precision(self):
        result = triangle_area(1/3, 1/3)
        assert result == pytest.approx(1/18)
    
    def test_large_numbers(self):
        result = triangle_area(1e308, 2)
        assert math.isinf(result)
    
    def test_type_consistency(self):
        assert isinstance(triangle_area(5, 10), float)
        assert isinstance(triangle_area(5.0, 10.0), float)
        assert isinstance(triangle_area(5, 10.0), float)