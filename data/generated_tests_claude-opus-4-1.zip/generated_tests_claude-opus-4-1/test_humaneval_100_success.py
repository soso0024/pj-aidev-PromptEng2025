# Test cases for HumanEval/100
# Generated using Claude API


def make_a_pile(n):
    """
    Given a positive integer n, you have to make a pile of n levels of stones.
    The first level has n stones.
    The number of stones in the next level is:
        - the next odd number if n is odd.
        - the next even number if n is even.
    Return the number of stones in each level in a list, where element at index
    i represents the number of stones in the level (i+1).

    Examples:
    >>> make_a_pile(3)
    [3, 5, 7]
    """

    return [n + 2*i for i in range(n)]


# Generated test cases:
import pytest


def make_a_pile(n):
    return [n + 2*i for i in range(n)]


@pytest.mark.parametrize("n,expected", [
    (1, [1]),
    (2, [2, 4]),
    (3, [3, 5, 7]),
    (4, [4, 6, 8, 10]),
    (5, [5, 7, 9, 11, 13]),
    (10, [10, 12, 14, 16, 18, 20, 22, 24, 26, 28]),
    (0, []),
])
def test_make_a_pile_normal_cases(n, expected):
    assert make_a_pile(n) == expected


def test_make_a_pile_large_number():
    n = 100
    result = make_a_pile(n)
    assert len(result) == 100
    assert result[0] == 100
    assert result[-1] == 298
    assert all(result[i+1] - result[i] == 2 for i in range(len(result)-1))


def test_make_a_pile_negative_number():
    result = make_a_pile(-5)
    assert result == []


def test_make_a_pile_negative_produces_negative_start():
    n = 3
    result = make_a_pile(-n)
    assert result == []


def test_make_a_pile_single_element():
    assert make_a_pile(1) == [1]
    assert len(make_a_pile(1)) == 1


def test_make_a_pile_arithmetic_progression():
    for n in [5, 10, 15, 20]:
        result = make_a_pile(n)
        differences = [result[i+1] - result[i] for i in range(len(result)-1)]
        assert all(d == 2 for d in differences)


def test_make_a_pile_first_element():
    for n in range(1, 10):
        result = make_a_pile(n)
        assert result[0] == n


def test_make_a_pile_last_element():
    for n in range(1, 10):
        result = make_a_pile(n)
        if n > 0:
            assert result[-1] == n + 2*(n-1)
