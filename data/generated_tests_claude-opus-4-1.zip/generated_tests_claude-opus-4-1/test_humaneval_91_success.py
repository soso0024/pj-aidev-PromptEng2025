# Test cases for HumanEval/91
# Generated using Claude API


def is_bored(S):
    """
    You'll be given a string of words, and your task is to count the number
    of boredoms. A boredom is a sentence that starts with the word "I".
    Sentences are delimited by '.', '?' or '!'.
   
    For example:
    >>> is_bored("Hello world")
    0
    >>> is_bored("The sky is blue. The sun is shining. I love this weather")
    1
    """

    import re
    sentences = re.split(r'[.?!]\s*', S)
    return sum(sentence[0:2] == 'I ' for sentence in sentences)


# Generated test cases:
import pytest
import re

def is_bored(S):
    sentences = re.split(r'[.?!]\s*', S)
    return sum(sentence[0:2] == 'I ' for sentence in sentences)

@pytest.mark.parametrize("input_string,expected", [
    ("I am bored.", 1),
    ("I am happy. I am sad.", 2),
    ("Hello world. I am here.", 1),
    ("I think. I know. I believe.", 3),
    ("You are nice. He is kind.", 0),
    ("I am bored! I am tired? I am done.", 3),
    ("", 0),
    ("I", 0),
    ("I ", 1),
    ("I am", 1),
    ("   I am bored.", 0),
    ("I am bored.I am tired.", 2),
    ("I am bored!    I am tired.", 2),
    ("I am bored?I am tired!", 2),
    ("What am I doing? I am coding.", 1),
    ("I'm bored.", 0),
    ("I  am bored.", 1),
    ("Hello. I am here. Goodbye.", 1),
    ("I.", 0),
    ("I .", 1),
    ("I ?", 1),
    ("I !", 1),
    (".", 0),
    ("?", 0),
    ("!", 0),
    ("I am bored.You are not.", 1),
    ("I am bored. You are not.", 1),
    ("I am bored.  I am tired.", 2),
    ("I am bored...I am tired.", 2),
    ("The sky is blue. I wonder why? I don't know!", 2),
    ("II am not bored.", 0),
    ("iI am not bored.", 0),
    ("i am bored. I am tired.", 1),
    ("I am bored\n. I am tired.", 2),
    ("I am bored.\nI am tired.", 2),
    ("I am bored.\n\nI am tired.", 2),
    ("I am bored.\tI am tired.", 2),
])
def test_is_bored(input_string, expected):
    assert is_bored(input_string) == expected

def test_is_bored_empty_sentences():
    assert is_bored("...") == 0
    assert is_bored("???") == 0
    assert is_bored("!!!") == 0
    assert is_bored(".?.!") == 0

def test_is_bored_single_character():
    assert is_bored("a") == 0
    assert is_bored("I") == 0
    assert is_bored(".") == 0

def test_is_bored_multiple_spaces():
    assert is_bored("I am bored.     I am tired.") == 2
    assert is_bored("I am bored.     You are tired.") == 1

def test_is_bored_mixed_punctuation():
    assert is_bored("I am here! You are there? He is everywhere.") == 1
    assert is_bored("Really? I think so! Maybe. I don't know.") == 2

def test_is_bored_no_space_after_I():
    assert is_bored("Im bored.") == 0
    assert is_bored("Iam bored.") == 0

def test_is_bored_only_I_space():
    assert is_bored("I . I ? I !") == 3
    assert is_bored("I  . I  ? I  !") == 3