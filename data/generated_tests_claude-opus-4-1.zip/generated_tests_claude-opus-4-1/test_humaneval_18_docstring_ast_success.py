# Test cases for HumanEval/18
# Generated using Claude API



def how_many_times(string: str, substring: str) -> int:
    """ Find how many times a given substring can be found in the original string. Count overlaping cases.
    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """

    times = 0

    for i in range(len(string) - len(substring) + 1):
        if string[i:i+len(substring)] == substring:
            times += 1

    return times


# Generated test cases:
import pytest


def how_many_times(string: str, substring: str) -> int:
    times = 0
    for i in range(len(string) - len(substring) + 1):
        if string[i:i+len(substring)] == substring:
            times += 1
    return times


@pytest.mark.parametrize("string,substring,expected", [
    # Test cases from docstring
    ('', 'a', 0),
    ('aaa', 'a', 3),
    ('aaaa', 'aa', 3),
    
    # Empty strings
    ('', '', 1),
    ('a', '', 2),
    ('abc', '', 4),
    
    # Single character searches
    ('a', 'a', 1),
    ('b', 'a', 0),
    ('abcabc', 'a', 2),
    ('abcabc', 'b', 2),
    ('abcabc', 'c', 2),
    
    # Overlapping cases
    ('aaa', 'aa', 2),
    ('aaaa', 'aaa', 2),
    ('aaaaa', 'aa', 4),
    ('abababa', 'aba', 3),
    ('abababab', 'abab', 3),
    
    # Non-overlapping cases
    ('abcdef', 'abc', 1),
    ('abcdef', 'def', 1),
    ('abcdef', 'cde', 1),
    
    # Substring longer than string
    ('a', 'aa', 0),
    ('ab', 'abc', 0),
    ('', 'a', 0),
    
    # Substring equals string
    ('abc', 'abc', 1),
    ('a', 'a', 1),
    
    # No matches
    ('abcdef', 'xyz', 0),
    ('hello', 'world', 0),
    ('python', 'java', 0),
    
    # Repeated patterns
    ('aaabaaabaaab', 'aaab', 3),
    ('abcabcabc', 'abc', 3),
    ('abcabcabc', 'cab', 2),
    
    # Special characters
    ('...', '.', 3),
    ('...', '..', 2),
    ('a.b.c', '.', 2),
    ('a b c', ' ', 2),
    
    # Numbers in strings
    ('123123', '123', 2),
    ('111', '11', 2),
    ('12121212', '121', 3),
    
    # Case sensitivity
    ('AAAaaa', 'AAA', 1),
    ('AAAaaa', 'aaa', 1),
    ('AaAaAa', 'Aa', 3),
    ('AaAaAa', 'aA', 2),
    
    # Long strings with patterns
    ('abababababababab', 'ab', 8),
    ('abababababababab', 'ba', 7),
    ('abcdefghijklmnop', 'mnop', 1),
    
    # Unicode characters
    ('ααα', 'α', 3),
    ('ααα', 'αα', 2),
    ('😀😀😀', '😀', 3),
    ('😀😀😀', '😀😀', 2),
])
def test_how_many_times(string, substring, expected):
    assert how_many_times(string, substring) == expected


def test_how_many_times_type_validation():
    # Test with valid string types
    assert isinstance(how_many_times('test', 'es'), int)
    assert isinstance(how_many_times('', ''), int)


def test_how_many_times_edge_cases():
    # Very long string
    long_string = 'a' * 1000
    assert how_many_times(long_string, 'a') == 1000
    assert how_many_times(long_string, 'aa') == 999
    
    # Substring at boundaries
    assert how_many_times('abcdef', 'ab') == 1
    assert how_many_times('abcdef', 'ef') == 1
    
    # Multiple overlapping patterns
    assert how_many_times('aaaaaaa', 'aaa') == 5
