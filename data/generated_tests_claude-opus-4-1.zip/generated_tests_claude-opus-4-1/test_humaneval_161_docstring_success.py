# Test cases for HumanEval/161
# Generated using Claude API


def solve(s):
    """You are given a string s.
    if s[i] is a letter, reverse its case from lower to upper or vise versa, 
    otherwise keep it as it is.
    If the string contains no letters, reverse the string.
    The function should return the resulted string.
    Examples
    solve("1234") = "4321"
    solve("ab") = "AB"
    solve("#a@C") = "#A@c"
    """

    flg = 0
    idx = 0
    new_str = list(s)
    for i in s:
        if i.isalpha():
            new_str[idx] = i.swapcase()
            flg = 1
        idx += 1
    s = ""
    for i in new_str:
        s += i
    if flg == 0:
        return s[len(s)::-1]
    return s


# Generated test cases:
import pytest

def solve(s):
    flg = 0
    idx = 0
    new_str = list(s)
    for i in s:
        if i.isalpha():
            new_str[idx] = i.swapcase()
            flg = 1
        idx += 1
    s = ""
    for i in new_str:
        s += i
    if flg == 0:
        return s[len(s)::-1]
    return s


@pytest.mark.parametrize("input_str,expected", [
    ("1234", "4321"),
    ("ab", "AB"),
    ("#a@C", "#A@c"),
    ("", ""),
    ("a", "A"),
    ("A", "a"),
    ("ABC", "abc"),
    ("abc", "ABC"),
    ("aBc", "AbC"),
    ("Hello World!", "hELLO wORLD!"),
    ("123456789", "987654321"),
    ("!@#$%^&*()", ")(*&^%$#@!"),
    ("a1b2c3", "A1B2C3"),
    ("A1B2C3", "a1b2c3"),
    ("   ", "   "),
    ("123abc456", "123ABC456"),
    ("zzZ", "ZZz"),
    ("Test123", "tEST123"),
    ("@#$a", "@#$A"),
    ("1", "1"),
    ("!", "!"),
    ("aAaAaA", "AaAaAa"),
    ("12!@#34", "43#@!21"),
    ("abcDEF123", "ABCdef123"),
    ("MixedCASE123", "mIXEDcase123"),
    ("NoLetters123!@#", "nOlETTERS123!@#"),
])
def test_solve(input_str, expected):
    assert solve(input_str) == expected


def test_solve_empty_string():
    assert solve("") == ""


def test_solve_single_letter_lowercase():
    assert solve("x") == "X"


def test_solve_single_letter_uppercase():
    assert solve("X") == "x"


def test_solve_only_digits():
    assert solve("9876543210") == "0123456789"


def test_solve_only_special_chars():
    assert solve("!@#$%") == "%$#@!"


def test_solve_mixed_case_letters():
    assert solve("aBcDeF") == "AbCdEf"


def test_solve_letters_with_spaces():
    assert solve("a b c") == "A B C"


def test_solve_unicode_letters():
    assert solve("café") == "CAFÉ"


def test_solve_long_string_no_letters():
    assert solve("1234567890" * 10) == "0987654321" * 10


def test_solve_long_string_with_letters():
    assert solve("a" * 100) == "A" * 100