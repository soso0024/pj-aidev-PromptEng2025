# Test cases for HumanEval/104
# Generated using Claude API


def unique_digits(x):
    """Given a list of positive integers x. return a sorted list of all 
    elements that hasn't any even digit.

    Note: Returned list should be sorted in increasing order.
    
    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """

    odd_digit_elements = []
    for i in x:
        if all (int(c) % 2 == 1 for c in str(i)):
            odd_digit_elements.append(i)
    return sorted(odd_digit_elements)


# Generated test cases:
import pytest

def unique_digits(x):
    odd_digit_elements = []
    for i in x:
        if all (int(c) % 2 == 1 for c in str(i)):
            odd_digit_elements.append(i)
    return sorted(odd_digit_elements)


@pytest.mark.parametrize("input_list,expected", [
    ([15, 33, 1422, 1], [1, 15, 33]),
    ([152, 323, 1422, 10], []),
    ([1, 3, 5, 7, 9], [1, 3, 5, 7, 9]),
    ([2, 4, 6, 8, 10], []),
    ([11, 13, 15, 17, 19], [11, 13, 15, 17, 19]),
    ([111, 333, 555, 777, 999], [111, 333, 555, 777, 999]),
    ([135, 357, 579, 791, 913], [135, 357, 579, 791, 913]),
    ([1357, 9753, 1111, 3333], [1111, 1357, 3333, 9753]),
    ([20, 40, 60, 80, 100], []),
    ([12, 34, 56, 78, 90], []),
    ([1], [1]),
    ([2], []),
    ([0], []),
    ([10, 20, 30, 40, 50], []),
    ([11, 22, 33, 44, 55], [11, 33, 55]),
    ([123, 456, 789], []),
    ([135, 246, 357], [135, 357]),
    ([9999, 8888, 7777, 6666], [7777, 9999]),
    ([31, 13, 71, 17, 91, 19], [13, 17, 19, 31, 71, 91]),
    ([100, 200, 300, 400, 500], []),
    ([101, 202, 303, 404, 505], []),
    ([111, 222, 333, 444, 555], [111, 333, 555]),
    ([1000, 2000, 3000, 4000, 5000], []),
    ([1001, 2002, 3003, 4004, 5005], []),
    ([9, 99, 999, 9999, 99999], [9, 99, 999, 9999, 99999]),
    ([8, 88, 888, 8888, 88888], []),
    ([7, 77, 777, 7777, 77777], [7, 77, 777, 7777, 77777]),
    ([5, 15, 25, 35, 45], [5, 15, 35]),
    ([10, 11, 12, 13, 14], [11, 13]),
    ([20, 21, 22, 23, 24], []),
    ([30, 31, 32, 33, 34], [31, 33]),
    ([40, 41, 42, 43, 44], []),
    ([50, 51, 52, 53, 54], [51, 53]),
    ([60, 61, 62, 63, 64], []),
    ([70, 71, 72, 73, 74], [71, 73]),
    ([80, 81, 82, 83, 84], []),
    ([90, 91, 92, 93, 94], [91, 93]),
    ([], []),
    ([1, 1, 1], [1, 1, 1]),
    ([3, 1, 5, 7, 9, 3, 1], [1, 1, 3, 3, 5, 7, 9]),
    ([100, 11, 200, 33, 300], [11, 33]),
    ([9753, 1357, 2468, 8642], [1357, 9753]),
    ([13579, 24680, 97531, 86420], [13579, 97531]),
])
def test_unique_digits(input_list, expected):
    assert unique_digits(input_list) == expected


def test_unique_digits_empty_list():
    assert unique_digits([]) == []


def test_unique_digits_single_odd_digit():
    assert unique_digits([1]) == [1]
    assert unique_digits([3]) == [3]
    assert unique_digits([5]) == [5]
    assert unique_digits([7]) == [7]
    assert unique_digits([9]) == [9]


def test_unique_digits_single_even_digit():
    assert unique_digits([0]) == []
    assert unique_digits([2]) == []
    assert unique_digits([4]) == []
    assert unique_digits([6]) == []
    assert unique_digits([8]) == []


def test_unique_digits_sorting():
    assert unique_digits([99, 11, 77, 33, 55]) == [11, 33, 55, 77, 99]
    assert unique_digits([9999, 111, 7777, 333, 5555]) == [111, 333, 5555, 7777, 9999]


def test_unique_digits_duplicates():
    assert unique_digits([11, 11, 11]) == [11, 11, 11]
    assert unique_digits([33, 33, 11, 11]) == [11, 11, 33, 33]


def test_unique_digits_mixed():
    assert unique_digits([123, 135, 246, 357, 468, 579]) == [135, 357, 579]
    assert unique_digits([1234, 1357, 2468, 3579, 4680, 5791]) == [1357, 3579, 5791]
