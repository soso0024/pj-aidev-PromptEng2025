# Test cases for HumanEval/35
# Generated using Claude API



def max_element(l: list):
    """Return maximum element in the list.
    >>> max_element([1, 2, 3])
    3
    >>> max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    123
    """

    m = l[0]
    for e in l:
        if e > m:
            m = e
    return m


# Generated test cases:
import pytest

def max_element(l: list):
    m = l[0]
    for e in l:
        if e > m:
            m = e
    return m

def test_max_element_basic():
    assert max_element([1, 2, 3]) == 3
    assert max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10]) == 123

def test_max_element_single_element():
    assert max_element([42]) == 42
    assert max_element([-5]) == -5
    assert max_element([0]) == 0

def test_max_element_all_negative():
    assert max_element([-1, -2, -3, -4, -5]) == -1
    assert max_element([-100, -50, -75]) == -50

def test_max_element_all_same():
    assert max_element([5, 5, 5, 5]) == 5
    assert max_element([0, 0, 0]) == 0
    assert max_element([-3, -3, -3]) == -3

def test_max_element_max_at_beginning():
    assert max_element([100, 1, 2, 3]) == 100
    assert max_element([50, -10, 0, 25]) == 50

def test_max_element_max_at_end():
    assert max_element([1, 2, 3, 100]) == 100
    assert max_element([-10, 0, 25, 50]) == 50

def test_max_element_max_in_middle():
    assert max_element([1, 100, 2, 3]) == 100
    assert max_element([-10, 50, 0, 25]) == 50

def test_max_element_with_floats():
    assert max_element([1.5, 2.7, 3.2, 2.1]) == 3.2
    assert max_element([-1.5, -0.5, -2.0]) == -0.5

def test_max_element_mixed_types():
    assert max_element([1, 2.5, 3, 4.7]) == 4.7
    assert max_element([-1, -2.5, 0, 1.5]) == 1.5

def test_max_element_large_list():
    assert max_element(list(range(-1000, 1001))) == 1000
    assert max_element(list(range(1000, 0, -1))) == 1000

def test_max_element_with_duplicates():
    assert max_element([1, 5, 2, 5, 3, 5]) == 5
    assert max_element([10, 10, 9, 8, 10]) == 10

def test_max_element_empty_list_raises_error():
    with pytest.raises(IndexError):
        max_element([])
