# Test cases for HumanEval/114
# Generated using Claude API


def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """

    max_sum = 0
    s = 0
    for num in nums:
        s += -num
        if (s < 0):
            s = 0
        max_sum = max(s, max_sum)
    if max_sum == 0:
        max_sum = max(-i for i in nums)
    min_sum = -max_sum
    return min_sum


# Generated test cases:
import pytest

def test_minSubArraySum():
    assert minSubArraySum([1, -2, 3, 10, -4, 7, 2, -5]) == -3
    assert minSubArraySum([-1, -2]) == 3
    assert minSubArraySum([1, 2, 3, 4]) == -10
    assert minSubArraySum([-1, -2, -3]) == 6
    with pytest.raises(IndexError):
        minSubArraySum([])