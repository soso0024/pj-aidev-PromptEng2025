# Test cases for HumanEval/125
# Generated using Claude API


def split_words(txt):
    '''
    Given a string of words, return a list of words split on whitespace, if no whitespaces exists in the text you
    should split on commas ',' if no commas exists you should return the number of lower-case letters with odd order in the
    alphabet, ord('a') = 0, ord('b') = 1, ... ord('z') = 25
    Examples
    split_words("Hello world!") ➞ ["Hello", "world!"]
    split_words("Hello,world!") ➞ ["Hello", "world!"]
    split_words("abcdef") == 3 
    '''

    if " " in txt:
        return txt.split()
    elif "," in txt:
        return txt.replace(',',' ').split()
    else:
        return len([i for i in txt if i.islower() and ord(i)%2 == 0])


# Generated test cases:
import pytest

def test_split_words_with_spaces():
    assert split_words("hello world") == ["hello", "world"]

def test_split_words_with_commas():
    assert split_words("hello,world") == ["hello", "world"]

def test_split_words_with_lowercase_even_chars():
    assert split_words("abcdefg") == 3

def test_split_words_empty_string():
    assert split_words("") == 0

def test_split_words_single_word():
    assert split_words("hello") == 0

def test_split_words_mixed_case():
    assert split_words("Hello,World") == ["Hello", "World"]

def test_split_words_multiple_commas():
    assert split_words("hello,world,python") == ["hello", "world", "python"]

def test_split_words_spaces_and_commas():
    assert split_words("hello world,python") == ["hello", "world", "python"]

@pytest.mark.parametrize("input_str,expected", [
    ("hello world", ["hello", "world"]),
    ("hello,world", ["hello", "world"]),
    ("abcdefg", 3),
    ("", 0),
    ("hello", 0),
    ("Hello,World", ["Hello", "World"]),
    ("hello,world,python", ["hello", "world", "python"]),
    ("hello world,python", ["hello", "world", "python"])
])
def test_split_words_parametrized(input_str, expected):
    assert split_words(input_str) == expected