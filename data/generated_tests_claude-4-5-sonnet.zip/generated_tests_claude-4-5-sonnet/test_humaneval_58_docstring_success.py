# Test cases for HumanEval/58
# Generated using Claude API



def common(l1: list, l2: list):
    """Return sorted unique common elements for two lists.
    >>> common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121])
    [1, 5, 653]
    >>> common([5, 3, 2, 8], [3, 2])
    [2, 3]

    """

    ret = set()
    for e1 in l1:
        for e2 in l2:
            if e1 == e2:
                ret.add(e1)
    return sorted(list(ret))


# Generated test cases:
import pytest


def common(l1: list, l2: list):
    ret = set()
    for e1 in l1:
        for e2 in l2:
            if e1 == e2:
                ret.add(e1)
    return sorted(list(ret))


def test_common_basic_case():
    assert common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121]) == [1, 5, 653]


def test_common_subset():
    assert common([5, 3, 2, 8], [3, 2]) == [2, 3]


def test_common_empty_first_list():
    assert common([], [1, 2, 3]) == []


def test_common_empty_second_list():
    assert common([1, 2, 3], []) == []


def test_common_both_empty():
    assert common([], []) == []


def test_common_no_common_elements():
    assert common([1, 2, 3], [4, 5, 6]) == []


def test_common_all_elements_common():
    assert common([1, 2, 3], [1, 2, 3]) == [1, 2, 3]


def test_common_duplicates_in_first_list():
    assert common([1, 1, 2, 2, 3], [1, 2]) == [1, 2]


def test_common_duplicates_in_second_list():
    assert common([1, 2], [1, 1, 2, 2, 3]) == [1, 2]


def test_common_duplicates_in_both_lists():
    assert common([1, 1, 2, 2, 3, 3], [1, 1, 2, 2, 4, 4]) == [1, 2]


def test_common_single_element_lists_match():
    assert common([5], [5]) == [5]


def test_common_single_element_lists_no_match():
    assert common([5], [6]) == []


def test_common_negative_numbers():
    assert common([-1, -2, -3, 0], [-2, -3, 1]) == [-3, -2]


def test_common_mixed_positive_negative():
    assert common([-5, -1, 0, 1, 5], [-1, 0, 1]) == [-1, 0, 1]


def test_common_floats():
    assert common([1.5, 2.5, 3.5], [2.5, 3.5, 4.5]) == [2.5, 3.5]


def test_common_strings():
    assert common(['a', 'b', 'c'], ['b', 'c', 'd']) == ['b', 'c']


def test_common_mixed_types():
    result = common([1, 2, 'a', 'b'], ['a', 'b', 'c'])
    assert result == ['a', 'b']


def test_common_large_numbers():
    assert common([1000000, 2000000, 3000000], [2000000, 3000000, 4000000]) == [2000000, 3000000]


def test_common_sorted_output():
    assert common([5, 3, 1], [1, 3, 5]) == [1, 3, 5]


def test_common_unsorted_input():
    assert common([9, 2, 7, 3], [3, 7, 1, 9]) == [3, 7, 9]


@pytest.mark.parametrize("l1,l2,expected", [
    ([1, 2, 3], [2, 3, 4], [2, 3]),
    ([10, 20, 30], [20, 30, 40], [20, 30]),
    ([1], [1], [1]),
    ([], [], []),
    ([1, 2], [3, 4], []),
])
def test_common_parametrized(l1, l2, expected):
    assert common(l1, l2) == expected