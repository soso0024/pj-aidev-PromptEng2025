# Test cases for HumanEval/106
# Generated using Claude API


def f(n):
    """ Implement the function f that takes n as a parameter,
    and returns a list of size n, such that the value of the element at index i is the factorial of i if i is even
    or the sum of numbers from 1 to i otherwise.
    i starts from 1.
    the factorial of i is the multiplication of the numbers from 1 to i (1 * 2 * ... * i).
    Example:
    f(5) == [1, 2, 6, 24, 15]
    """

    ret = []
    for i in range(1,n+1):
        if i%2 == 0:
            x = 1
            for j in range(1,i+1): x *= j
            ret += [x]
        else:
            x = 0
            for j in range(1,i+1): x += j
            ret += [x]
    return ret


# Generated test cases:
import pytest

def f(n):
    ret = []
    for i in range(1,n+1):
        if i%2 == 0:
            x = 1
            for j in range(1,i+1): x *= j
            ret += [x]
        else:
            x = 0
            for j in range(1,i+1): x += j
            ret += [x]
    return ret

def test_f_zero():
    assert f(0) == []

def test_f_one():
    assert f(1) == [1]

def test_f_two():
    assert f(2) == [1, 2]

def test_f_three():
    assert f(3) == [1, 2, 6]

def test_f_four():
    assert f(4) == [1, 2, 6, 24]

def test_f_five():
    assert f(5) == [1, 2, 6, 24, 15]

def test_f_six():
    assert f(6) == [1, 2, 6, 24, 15, 720]

def test_f_seven():
    assert f(7) == [1, 2, 6, 24, 15, 720, 28]

def test_f_eight():
    assert f(8) == [1, 2, 6, 24, 15, 720, 28, 40320]

def test_f_ten():
    result = f(10)
    assert len(result) == 10
    assert result[0] == 1
    assert result[1] == 2
    assert result[2] == 6
    assert result[3] == 24
    assert result[4] == 15
    assert result[5] == 720
    assert result[6] == 28
    assert result[7] == 40320
    assert result[8] == 45
    assert result[9] == 3628800

@pytest.mark.parametrize("n,expected", [
    (0, []),
    (1, [1]),
    (2, [1, 2]),
    (3, [1, 2, 6]),
    (4, [1, 2, 6, 24]),
])
def test_f_parametrized(n, expected):
    assert f(n) == expected

def test_f_odd_positions():
    result = f(9)
    assert result[0] == 1
    assert result[2] == 6
    assert result[4] == 15
    assert result[6] == 28
    assert result[8] == 45

def test_f_even_positions():
    result = f(8)
    assert result[1] == 2
    assert result[3] == 24
    assert result[5] == 720
    assert result[7] == 40320

def test_f_length():
    assert len(f(0)) == 0
    assert len(f(1)) == 1
    assert len(f(5)) == 5
    assert len(f(10)) == 10
    assert len(f(15)) == 15
