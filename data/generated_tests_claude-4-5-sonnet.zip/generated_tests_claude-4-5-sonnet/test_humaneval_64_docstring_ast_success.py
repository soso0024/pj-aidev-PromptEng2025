# Test cases for HumanEval/64
# Generated using Claude API


FIX = """
Add more test cases.
"""

def vowels_count(s):
    """Write a function vowels_count which takes a string representing
    a word as input and returns the number of vowels in the string.
    Vowels in this case are 'a', 'e', 'i', 'o', 'u'. Here, 'y' is also a
    vowel, but only when it is at the end of the given word.

    Example:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    """

    vowels = "aeiouAEIOU"
    n_vowels = sum(c in vowels for c in s)
    if s[-1] == 'y' or s[-1] == 'Y':
        n_vowels += 1
    return n_vowels


# Generated test cases:
import pytest

def vowels_count(s):
    vowels = "aeiouAEIOU"
    n_vowels = sum(c in vowels for c in s)
    if s[-1] == 'y' or s[-1] == 'Y':
        n_vowels += 1
    return n_vowels

def test_vowels_count_basic():
    assert vowels_count("abcde") == 2

def test_vowels_count_with_y_at_end():
    assert vowels_count("ACEDY") == 3

def test_vowels_count_lowercase_vowels():
    assert vowels_count("aeiou") == 5

def test_vowels_count_uppercase_vowels():
    assert vowels_count("AEIOU") == 5

def test_vowels_count_mixed_case():
    assert vowels_count("AeIoU") == 5

def test_vowels_count_no_vowels_except_y():
    assert vowels_count("bcdfgy") == 1

def test_vowels_count_no_vowels_at_all():
    assert vowels_count("bcdfg") == 0

def test_vowels_count_only_consonants():
    assert vowels_count("xyz") == 0

def test_vowels_count_y_at_end_uppercase():
    assert vowels_count("HAPPY") == 2

def test_vowels_count_y_at_end_lowercase():
    assert vowels_count("happy") == 2

def test_vowels_count_y_not_at_end():
    assert vowels_count("yellow") == 2

def test_vowels_count_y_in_middle():
    assert vowels_count("python") == 1

def test_vowels_count_single_vowel():
    assert vowels_count("a") == 1

def test_vowels_count_single_y():
    assert vowels_count("y") == 1

def test_vowels_count_single_Y():
    assert vowels_count("Y") == 1

def test_vowels_count_single_consonant():
    assert vowels_count("b") == 0

def test_vowels_count_all_vowels_with_y():
    assert vowels_count("aeiouy") == 6

def test_vowels_count_all_vowels_uppercase_with_y():
    assert vowels_count("AEIOUY") == 6

def test_vowels_count_repeated_vowels():
    assert vowels_count("aaaaaa") == 6

def test_vowels_count_long_word():
    assert vowels_count("beautiful") == 5

def test_vowels_count_long_word_with_y():
    assert vowels_count("beauty") == 4

def test_vowels_count_word_ending_consonant():
    assert vowels_count("test") == 1

def test_vowels_count_multiple_y_only_last_counts():
    assert vowels_count("yay") == 2

def test_vowels_count_mixed_case_with_y():
    assert vowels_count("HaPpY") == 2

@pytest.mark.parametrize("input_str,expected", [
    ("abcde", 2),
    ("ACEDY", 3),
    ("aeiou", 5),
    ("AEIOU", 5),
    ("bcdfg", 0),
    ("y", 1),
    ("Y", 1),
    ("a", 1),
    ("b", 0),
    ("happy", 2),
    ("HAPPY", 2),
    ("yellow", 2),
    ("sky", 1),
    ("rhythm", 0),
    ("beauty", 4),
    ("aeiouy", 6),
    ("AEIOUY", 6),
])
def test_vowels_count_parametrized(input_str, expected):
    assert vowels_count(input_str) == expected
