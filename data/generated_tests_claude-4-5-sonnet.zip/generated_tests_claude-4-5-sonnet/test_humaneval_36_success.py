# Test cases for HumanEval/36
# Generated using Claude API



def fizz_buzz(n: int):
    """Return the number of times the digit 7 appears in integers less than n which are divisible by 11 or 13.
    >>> fizz_buzz(50)
    0
    >>> fizz_buzz(78)
    2
    >>> fizz_buzz(79)
    3
    """

    ns = []
    for i in range(n):
        if i % 11 == 0 or i % 13 == 0:
            ns.append(i)
    s = ''.join(list(map(str, ns)))
    ans = 0
    for c in s:
        ans += (c == '7')
    return ans


# Generated test cases:
import pytest

def fizz_buzz(n: int):
    ns = []
    for i in range(n):
        if i % 11 == 0 or i % 13 == 0:
            ns.append(i)
    s = ''.join(list(map(str, ns)))
    ans = 0
    for c in s:
        ans += (c == '7')
    return ans


def test_fizz_buzz_zero():
    assert fizz_buzz(0) == 0


def test_fizz_buzz_one():
    assert fizz_buzz(1) == 0


def test_fizz_buzz_small_number():
    assert fizz_buzz(10) == 0


def test_fizz_buzz_includes_11():
    assert fizz_buzz(12) == 0


def test_fizz_buzz_includes_13():
    assert fizz_buzz(14) == 0


def test_fizz_buzz_includes_22():
    assert fizz_buzz(23) == 0


def test_fizz_buzz_includes_26():
    assert fizz_buzz(27) == 0


def test_fizz_buzz_includes_77():
    assert fizz_buzz(78) == 2


def test_fizz_buzz_includes_70():
    result = fizz_buzz(71)
    assert result == 0


def test_fizz_buzz_includes_77_and_more():
    result = fizz_buzz(100)
    assert result > 0


def test_fizz_buzz_large_number():
    result = fizz_buzz(200)
    assert isinstance(result, int)
    assert result >= 0


def test_fizz_buzz_with_multiple_sevens():
    result = fizz_buzz(80)
    assert result >= 2


def test_fizz_buzz_11_multiples():
    result = fizz_buzz(12)
    assert result == 0


def test_fizz_buzz_13_multiples():
    result = fizz_buzz(14)
    assert result == 0


def test_fizz_buzz_both_11_and_13():
    result = fizz_buzz(27)
    assert result == 0


def test_fizz_buzz_50():
    result = fizz_buzz(50)
    assert isinstance(result, int)


def test_fizz_buzz_78_has_77():
    result = fizz_buzz(78)
    assert result == 2


def test_fizz_buzz_143():
    result = fizz_buzz(143)
    assert isinstance(result, int)


@pytest.mark.parametrize("n,expected", [
    (0, 0),
    (1, 0),
    (11, 0),
    (12, 0),
    (13, 0),
    (14, 0),
])
def test_fizz_buzz_parametrized_no_sevens(n, expected):
    assert fizz_buzz(n) == expected


def test_fizz_buzz_return_type():
    result = fizz_buzz(50)
    assert isinstance(result, int)


def test_fizz_buzz_non_negative():
    result = fizz_buzz(100)
    assert result >= 0