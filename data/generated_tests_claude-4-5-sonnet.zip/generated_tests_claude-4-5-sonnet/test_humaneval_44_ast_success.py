# Test cases for HumanEval/44
# Generated using Claude API



def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """

    ret = ""
    while x > 0:
        ret = str(x % base) + ret
        x //= base
    return ret


# Generated test cases:
import pytest

def change_base(x: int, base: int):
    ret = ""
    while x > 0:
        ret = str(x % base) + ret
        x //= base
    return ret

def test_change_base_binary():
    assert change_base(8, 2) == "1000"
    assert change_base(7, 2) == "111"
    assert change_base(1, 2) == "1"
    assert change_base(15, 2) == "1111"

def test_change_base_octal():
    assert change_base(8, 8) == "10"
    assert change_base(64, 8) == "100"
    assert change_base(7, 8) == "7"

def test_change_base_hexadecimal():
    assert change_base(16, 16) == "10"
    assert change_base(255, 16) == "15" + "15"

def test_change_base_decimal():
    assert change_base(123, 10) == "123"
    assert change_base(1, 10) == "1"
    assert change_base(999, 10) == "999"

def test_change_base_zero():
    assert change_base(0, 2) == ""
    assert change_base(0, 10) == ""
    assert change_base(0, 16) == ""

def test_change_base_base_3():
    assert change_base(9, 3) == "100"
    assert change_base(10, 3) == "101"
    assert change_base(2, 3) == "2"

def test_change_base_base_5():
    assert change_base(25, 5) == "100"
    assert change_base(24, 5) == "44"
    assert change_base(4, 5) == "4"

def test_change_base_large_numbers():
    assert change_base(1000, 2) == "1111101000"
    assert change_base(1000, 10) == "1000"
    assert change_base(1024, 2) == "10000000000"

@pytest.mark.parametrize("x,base,expected", [
    (8, 2, "1000"),
    (7, 2, "111"),
    (8, 8, "10"),
    (123, 10, "123"),
    (1, 2, "1"),
    (0, 2, ""),
    (9, 3, "100"),
    (25, 5, "100"),
    (16, 16, "10"),
    (100, 7, "202"),
])
def test_change_base_parametrized(x, base, expected):
    assert change_base(x, base) == expected

def test_change_base_base_7():
    assert change_base(49, 7) == "100"
    assert change_base(50, 7) == "101"

def test_change_base_base_9():
    assert change_base(81, 9) == "100"
    assert change_base(80, 9) == "88"

def test_change_base_single_digit_result():
    assert change_base(5, 10) == "5"
    assert change_base(3, 5) == "3"
    assert change_base(1, 100) == "1"
