# Test cases for HumanEval/104
# Generated using Claude API


def unique_digits(x):
    """Given a list of positive integers x. return a sorted list of all 
    elements that hasn't any even digit.

    Note: Returned list should be sorted in increasing order.
    
    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """

    odd_digit_elements = []
    for i in x:
        if all (int(c) % 2 == 1 for c in str(i)):
            odd_digit_elements.append(i)
    return sorted(odd_digit_elements)


# Generated test cases:
import pytest


def unique_digits(x):
    odd_digit_elements = []
    for i in x:
        if all (int(c) % 2 == 1 for c in str(i)):
            odd_digit_elements.append(i)
    return sorted(odd_digit_elements)


def test_empty_list():
    assert unique_digits([]) == []


def test_single_odd_digit():
    assert unique_digits([1]) == [1]
    assert unique_digits([3]) == [3]
    assert unique_digits([5]) == [5]
    assert unique_digits([7]) == [7]
    assert unique_digits([9]) == [9]


def test_single_even_digit():
    assert unique_digits([2]) == []
    assert unique_digits([4]) == []
    assert unique_digits([6]) == []
    assert unique_digits([8]) == []
    assert unique_digits([0]) == []


def test_multiple_odd_digits():
    assert unique_digits([13, 57, 99]) == [13, 57, 99]
    assert unique_digits([111, 333, 555]) == [111, 333, 555]


def test_multiple_even_digits():
    assert unique_digits([2, 4, 6, 8]) == []
    assert unique_digits([20, 40, 60]) == []


def test_mixed_odd_and_even():
    assert unique_digits([1, 2, 3, 4]) == [1, 3]
    assert unique_digits([15, 22, 37, 48]) == [15, 37]


def test_numbers_with_mixed_digits():
    assert unique_digits([12, 23, 34]) == []
    assert unique_digits([13, 24, 35]) == [13, 35]
    assert unique_digits([135, 246, 357]) == [135, 357]


def test_sorting():
    assert unique_digits([99, 11, 55, 33]) == [11, 33, 55, 99]
    assert unique_digits([7, 1, 9, 3, 5]) == [1, 3, 5, 7, 9]
    assert unique_digits([777, 111, 999, 333]) == [111, 333, 777, 999]


def test_duplicates():
    assert unique_digits([1, 1, 1]) == [1, 1, 1]
    assert unique_digits([13, 13, 57, 57]) == [13, 13, 57, 57]


def test_large_numbers():
    assert unique_digits([1357, 2468, 9753]) == [1357, 9753]
    assert unique_digits([13579, 24680]) == [13579]


def test_zero():
    assert unique_digits([0]) == []
    assert unique_digits([10, 20, 30]) == []


def test_negative_numbers():
    assert unique_digits([-1, -3, -5]) == []
    assert unique_digits([-13, -24, -35]) == []


def test_mixed_positive_negative():
    assert unique_digits([1, -1, 3, -3]) == [1, 3]
    assert unique_digits([13, -13, 24, -24]) == [13]


def test_all_odd_digits_unsorted():
    assert unique_digits([97, 13, 75, 31, 59]) == [13, 31, 59, 75, 97]


def test_no_odd_digit_numbers():
    assert unique_digits([2, 4, 6, 8, 10, 20, 24, 68]) == []


def test_single_element_with_even_digit():
    assert unique_digits([12]) == []
    assert unique_digits([21]) == []


def test_large_list_mixed():
    assert unique_digits([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]) == [1, 3, 5, 7, 9, 11, 13, 15]


def test_three_digit_numbers():
    assert unique_digits([135, 246, 357, 468, 579]) == [135, 357, 579]


def test_four_digit_numbers():
    assert unique_digits([1357, 2468, 1111, 2222, 9753]) == [1111, 1357, 9753]


@pytest.mark.parametrize("input_list,expected", [
    ([15, 33, 1422, 1], [1, 15, 33]),
    ([152, 323, 1422, 10], []),
    ([12, 22, 32], []),
    ([1, 3, 5, 7, 9], [1, 3, 5, 7, 9]),
    ([2, 4, 6, 8], []),
])
def test_parametrized_cases(input_list, expected):
    assert unique_digits(input_list) == expected