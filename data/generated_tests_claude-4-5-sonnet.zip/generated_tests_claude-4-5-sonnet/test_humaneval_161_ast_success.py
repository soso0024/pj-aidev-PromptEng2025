# Test cases for HumanEval/161
# Generated using Claude API


def solve(s):
    """You are given a string s.
    if s[i] is a letter, reverse its case from lower to upper or vise versa, 
    otherwise keep it as it is.
    If the string contains no letters, reverse the string.
    The function should return the resulted string.
    Examples
    solve("1234") = "4321"
    solve("ab") = "AB"
    solve("#a@C") = "#A@c"
    """

    flg = 0
    idx = 0
    new_str = list(s)
    for i in s:
        if i.isalpha():
            new_str[idx] = i.swapcase()
            flg = 1
        idx += 1
    s = ""
    for i in new_str:
        s += i
    if flg == 0:
        return s[len(s)::-1]
    return s


# Generated test cases:
import pytest

def solve(s):
    flg = 0
    idx = 0
    new_str = list(s)
    for i in s:
        if i.isalpha():
            new_str[idx] = i.swapcase()
            flg = 1
        idx += 1
    s = ""
    for i in new_str:
        s += i
    if flg == 0:
        return s[len(s)::-1]
    return s

@pytest.mark.parametrize("input_str,expected", [
    ("abc", "ABC"),
    ("ABC", "abc"),
    ("AbC", "aBc"),
    ("hello", "HELLO"),
    ("WORLD", "world"),
    ("HeLLo", "hEllO"),
    ("123", "321"),
    ("456789", "987654"),
    ("", ""),
    ("!@#", "#@!"),
    ("abc123", "ABC123"),
    ("123abc", "123ABC"),
    ("ABC123", "abc123"),
    ("a1b2c3", "A1B2C3"),
    ("!@#abc", "!@#ABC"),
    ("abc!@#", "ABC!@#"),
    ("123!@#", "#@!321"),
    ("a", "A"),
    ("Z", "z"),
    ("1", "1"),
    ("!", "!"),
    (" ", " "),
    ("   ", "   "),
    ("a b c", "A B C"),
    ("A B C", "a b c"),
    ("123 456", "654 321"),
    ("hello world", "HELLO WORLD"),
    ("HELLO WORLD", "hello world"),
    ("Hello World", "hELLO wORLD"),
    ("123abc456", "123ABC456"),
    ("abc123def", "ABC123DEF"),
    ("!a!b!c!", "!A!B!C!"),
    ("!!!abc!!!", "!!!ABC!!!"),
    ("123abc456def789", "123ABC456DEF789"),
    ("aB1cD2eF3", "Ab1Cd2Ef3"),
    ("!@#$%", "%$#@!"),
    ("12345", "54321"),
    ("a1!b2@c3#", "A1!B2@C3#"),
    ("NoLetters123!@#", "nOlETTERS123!@#"),
])
def test_solve(input_str, expected):
    assert solve(input_str) == expected

def test_solve_empty_string():
    assert solve("") == ""

def test_solve_only_numbers():
    assert solve("123456") == "654321"

def test_solve_only_special_chars():
    assert solve("!@#$%^&*()") == ")(*&^%$#@!"

def test_solve_only_lowercase():
    assert solve("abcdef") == "ABCDEF"

def test_solve_only_uppercase():
    assert solve("ABCDEF") == "abcdef"

def test_solve_mixed_case():
    assert solve("aBcDeF") == "AbCdEf"

def test_solve_single_char_letter():
    assert solve("a") == "A"
    assert solve("Z") == "z"

def test_solve_single_char_number():
    assert solve("5") == "5"

def test_solve_single_char_special():
    assert solve("!") == "!"

def test_solve_spaces_only():
    assert solve("     ") == "     "

def test_solve_mixed_with_spaces():
    assert solve("a b c d") == "A B C D"

def test_solve_numbers_and_special():
    assert solve("123!@#") == "#@!321"
