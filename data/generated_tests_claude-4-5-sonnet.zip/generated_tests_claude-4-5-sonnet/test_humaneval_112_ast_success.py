# Test cases for HumanEval/112
# Generated using Claude API


def reverse_delete(s,c):
    """Task
    We are given two strings s and c, you have to deleted all the characters in s that are equal to any character in c
    then check if the result string is palindrome.
    A string is called palindrome if it reads the same backward as forward.
    You should return a tuple containing the result string and True/False for the check.
    Example
    For s = "abcde", c = "ae", the result should be ('bcd',False)
    For s = "abcdef", c = "b"  the result should be ('acdef',False)
    For s = "abcdedcba", c = "ab", the result should be ('cdedc',True)
    """

    s = ''.join([char for char in s if char not in c])
    return (s,s[::-1] == s)


# Generated test cases:
import pytest

def reverse_delete(s,c):
    s = ''.join([char for char in s if char not in c])
    return (s,s[::-1] == s)

def test_reverse_delete_basic():
    assert reverse_delete("abcde", "ae") == ("bcd", False)

def test_reverse_delete_palindrome():
    assert reverse_delete("abcdef", "b") == ("acdef", False)

def test_reverse_delete_results_in_palindrome():
    assert reverse_delete("abba", "cd") == ("abba", True)

def test_reverse_delete_empty_string():
    assert reverse_delete("", "abc") == ("", True)

def test_reverse_delete_empty_chars():
    assert reverse_delete("abcde", "") == ("abcde", False)

def test_reverse_delete_both_empty():
    assert reverse_delete("", "") == ("", True)

def test_reverse_delete_all_chars_removed():
    assert reverse_delete("aaa", "a") == ("", True)

def test_reverse_delete_no_chars_removed():
    assert reverse_delete("abcde", "xyz") == ("abcde", False)

def test_reverse_delete_single_char_palindrome():
    assert reverse_delete("a", "b") == ("a", True)

def test_reverse_delete_single_char_removed():
    assert reverse_delete("a", "a") == ("", True)

def test_reverse_delete_multiple_chars_to_remove():
    assert reverse_delete("abcdefg", "ace") == ("bdfg", False)

def test_reverse_delete_results_in_two_char_palindrome():
    assert reverse_delete("aabbcc", "bc") == ("aa", True)

def test_reverse_delete_results_in_odd_palindrome():
    assert reverse_delete("abcba", "d") == ("abcba", True)

def test_reverse_delete_complex_case():
    assert reverse_delete("dwwkckssw", "ks") == ("dwwcw", False)

def test_reverse_delete_numeric_strings():
    assert reverse_delete("12321", "4") == ("12321", True)

def test_reverse_delete_special_chars():
    assert reverse_delete("a!b!c!b!a", "!") == ("abcba", True)

@pytest.mark.parametrize("s,c,expected", [
    ("abc", "a", ("bc", False)),
    ("abc", "c", ("ab", False)),
    ("aba", "c", ("aba", True)),
    ("racecar", "x", ("racecar", True)),
    ("hello", "lo", ("he", False)),
    ("aabbaa", "b", ("aaaa", True)),
    ("xyz", "xyz", ("", True)),
    ("abcdefg", "abcdefg", ("", True)),
    ("aaa", "b", ("aaa", True)),
    ("abcdcba", "e", ("abcdcba", True)),
])
def test_reverse_delete_parametrized(s, c, expected):
    assert reverse_delete(s, c) == expected
