# Test cases for HumanEval/160
# Generated using Claude API


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and 
    the second list is a list of integers. Use the two given lists to build the algebric 
    expression and return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + ) 
    Subtraction ( - ) 
    Multiplication ( * ) 
    Floor division ( // ) 
    Exponentiation ( ** ) 

    Example:
    operator['+', '*', '-']
    array = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9

    Note:
        The length of operator list is equal to the length of operand list minus one.
        Operand is a list of of non-negative integers.
        Operator list has at least one operator, and operand list has at least two operands.

    """

    expression = str(operand[0])
    for oprt, oprn in zip(operator, operand[1:]):
        expression+= oprt + str(oprn)
    return eval(expression)


# Generated test cases:
import pytest

def do_algebra(operator, operand):
    expression = str(operand[0])
    for oprt, oprn in zip(operator, operand[1:]):
        expression+= oprt + str(oprn)
    return eval(expression)

def test_do_algebra_addition():
    assert do_algebra(['+'], [2, 3]) == 5

def test_do_algebra_subtraction():
    assert do_algebra(['-'], [5, 3]) == 2

def test_do_algebra_multiplication():
    assert do_algebra(['*'], [4, 5]) == 20

def test_do_algebra_floor_division():
    assert do_algebra(['//'], [10, 3]) == 3

def test_do_algebra_exponentiation():
    assert do_algebra(['**'], [2, 3]) == 8

def test_do_algebra_example_from_docstring():
    assert do_algebra(['+', '*', '-'], [2, 3, 4, 5]) == 9

def test_do_algebra_multiple_additions():
    assert do_algebra(['+', '+', '+'], [1, 2, 3, 4]) == 10

def test_do_algebra_multiple_multiplications():
    assert do_algebra(['*', '*'], [2, 3, 4]) == 24

def test_do_algebra_mixed_operations():
    assert do_algebra(['+', '-', '*'], [10, 5, 3, 2]) == 9

def test_do_algebra_with_zeros():
    assert do_algebra(['+', '*'], [0, 5, 0]) == 0

def test_do_algebra_order_of_operations():
    assert do_algebra(['*', '+'], [2, 3, 4]) == 10

def test_do_algebra_exponentiation_priority():
    assert do_algebra(['**', '*'], [2, 3, 2]) == 16

def test_do_algebra_floor_division_with_remainder():
    assert do_algebra(['//'], [7, 2]) == 3

def test_do_algebra_complex_expression():
    assert do_algebra(['**', '+', '*', '-'], [2, 2, 3, 4, 5]) == 11

def test_do_algebra_all_operations():
    assert do_algebra(['+', '-', '*', '//', '**'], [10, 5, 3, 2, 4, 2]) == 15

def test_do_algebra_single_operation_large_numbers():
    assert do_algebra(['+'], [1000, 2000]) == 3000

def test_do_algebra_multiple_subtractions():
    assert do_algebra(['-', '-', '-'], [100, 10, 20, 30]) == 40

def test_do_algebra_exponentiation_with_zero():
    assert do_algebra(['**'], [5, 0]) == 1

def test_do_algebra_multiplication_by_zero():
    assert do_algebra(['*', '+'], [5, 0, 10]) == 10

def test_do_algebra_two_operands_minimum():
    assert do_algebra(['+'], [1, 1]) == 2

def test_do_algebra_long_expression():
    assert do_algebra(['+', '+', '+', '+', '+'], [1, 1, 1, 1, 1, 1]) == 6

def test_do_algebra_division_and_multiplication():
    assert do_algebra(['//', '*'], [20, 4, 3]) == 15

def test_do_algebra_precedence_test():
    assert do_algebra(['+', '**'], [2, 3, 2]) == 11

def test_do_algebra_left_to_right_same_precedence():
    assert do_algebra(['-', '+'], [10, 3, 2]) == 9

def test_do_algebra_exponentiation_chain():
    assert do_algebra(['**', '**'], [2, 2, 2]) == 16