# Test cases for HumanEval/114
# Generated using Claude API


def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """

    max_sum = 0
    s = 0
    for num in nums:
        s += -num
        if (s < 0):
            s = 0
        max_sum = max(s, max_sum)
    if max_sum == 0:
        max_sum = max(-i for i in nums)
    min_sum = -max_sum
    return min_sum


# Generated test cases:
import pytest

def minSubArraySum(nums):
    max_sum = 0
    s = 0
    for num in nums:
        s += -num
        if (s < 0):
            s = 0
        max_sum = max(s, max_sum)
    if max_sum == 0:
        max_sum = max(-i for i in nums)
    min_sum = -max_sum
    return min_sum


@pytest.mark.parametrize("nums,expected", [
    ([2, 3, 4, 1, 2, 4], 1),
    ([-1, -2, -3], -6),
    ([1], 1),
    ([-1], -1),
    ([0], 0),
    ([1, 2, 3, 4, 5], 1),
    ([5, 4, 3, 2, 1], 1),
    ([-5, -4, -3, -2, -1], -15),
    ([1, -1, 2, -2, 3, -3], -3),
    ([10, -5, 3, -2, 8], -5),
    ([0, 0, 0], 0),
    ([1, 1, 1, 1], 1),
    ([-1, -1, -1, -1], -4),
    ([100], 100),
    ([-100], -100),
    ([5, -10, 3], -10),
    ([-5, 10, -3], -5),
    ([1, 2, -5, 4], -5),
    ([2, -1, 3, -4, 5], -4),
    ([10, 20, 30], 10),
    ([-10, -20, -30], -60),
    ([0, -1, 0], -1),
    ([0, 1, 0], 0),
    ([3, -7, 4, -2], -7),
    ([5, 5, -10, 5], -10),
    ([-2, -3, 4, -1, -2, 1, 5, -3], -5),
    ([1, 2, 3, -10, 5], -10),
    ([-1, 2, -3, 4, -5], -5),
    ([7, -6, 13, -5, 3, -12, -3, -5, -3, 2, -13], -36),
])
def test_minSubArraySum_parametrized(nums, expected):
    assert minSubArraySum(nums) == expected


def test_minSubArraySum_single_positive():
    assert minSubArraySum([5]) == 5


def test_minSubArraySum_single_negative():
    assert minSubArraySum([-5]) == -5


def test_minSubArraySum_all_positive():
    assert minSubArraySum([1, 2, 3, 4, 5]) == 1


def test_minSubArraySum_all_negative():
    assert minSubArraySum([-1, -2, -3, -4, -5]) == -15


def test_minSubArraySum_mixed():
    assert minSubArraySum([2, -1, 3, -4, 5]) == -4


def test_minSubArraySum_zeros():
    assert minSubArraySum([0, 0, 0, 0]) == 0


def test_minSubArraySum_with_zeros():
    assert minSubArraySum([1, 0, -1, 0, 2]) == -1


def test_minSubArraySum_large_positive():
    assert minSubArraySum([1000, 2000, 3000]) == 1000


def test_minSubArraySum_large_negative():
    assert minSubArraySum([-1000, -2000, -3000]) == -6000


def test_minSubArraySum_alternating():
    assert minSubArraySum([1, -2, 3, -4, 5, -6]) == -6


def test_minSubArraySum_two_elements_positive():
    assert minSubArraySum([5, 10]) == 5


def test_minSubArraySum_two_elements_negative():
    assert minSubArraySum([-5, -10]) == -15


def test_minSubArraySum_two_elements_mixed():
    assert minSubArraySum([5, -10]) == -10