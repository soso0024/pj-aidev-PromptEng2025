# Test cases for HumanEval/28
# Generated using Claude API

from typing import List


def concatenate(strings: List[str]) -> str:
    """ Concatenate list of strings into a single string
    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """

    return ''.join(strings)


# Generated test cases:
import pytest
from typing import List


def concatenate(strings: List[str]) -> str:
    return ''.join(strings)


def test_concatenate_empty_list():
    assert concatenate([]) == ''


def test_concatenate_single_string():
    assert concatenate(['hello']) == 'hello'


def test_concatenate_multiple_strings():
    assert concatenate(['hello', 'world']) == 'helloworld'


def test_concatenate_three_strings():
    assert concatenate(['a', 'b', 'c']) == 'abc'


def test_concatenate_with_empty_strings():
    assert concatenate(['', '', '']) == ''


def test_concatenate_mixed_empty_and_non_empty():
    assert concatenate(['hello', '', 'world']) == 'helloworld'


def test_concatenate_with_spaces():
    assert concatenate(['hello', ' ', 'world']) == 'hello world'


def test_concatenate_with_special_characters():
    assert concatenate(['!', '@', '#', '$']) == '!@#$'


def test_concatenate_with_numbers_as_strings():
    assert concatenate(['1', '2', '3']) == '123'


def test_concatenate_with_newlines():
    assert concatenate(['line1', '\n', 'line2']) == 'line1\nline2'


def test_concatenate_with_tabs():
    assert concatenate(['tab', '\t', 'separated']) == 'tab\tseparated'


def test_concatenate_unicode_strings():
    assert concatenate(['hello', '世界']) == 'hello世界'


def test_concatenate_with_emojis():
    assert concatenate(['😀', '😁', '😂']) == '😀😁😂'


@pytest.mark.parametrize("input_list,expected", [
    ([], ''),
    (['a'], 'a'),
    (['a', 'b'], 'ab'),
    (['hello', ' ', 'world'], 'hello world'),
    (['', 'test', ''], 'test'),
    (['1', '2', '3', '4', '5'], '12345'),
])
def test_concatenate_parametrized(input_list, expected):
    assert concatenate(input_list) == expected


def test_concatenate_long_list():
    long_list = ['a'] * 1000
    assert concatenate(long_list) == 'a' * 1000


def test_concatenate_with_quotes():
    assert concatenate(['"', "'", '"']) == "\"'\""


def test_concatenate_with_backslashes():
    assert concatenate(['\\', 'path', '\\', 'to']) == '\\path\\to'
