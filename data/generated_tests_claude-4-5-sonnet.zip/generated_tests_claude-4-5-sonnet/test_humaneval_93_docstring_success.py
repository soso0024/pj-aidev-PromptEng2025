# Test cases for HumanEval/93
# Generated using Claude API


def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """

    vowels = "aeiouAEIOU"
    vowels_replace = dict([(i, chr(ord(i) + 2)) for i in vowels])
    message = message.swapcase()
    return ''.join([vowels_replace[i] if i in vowels else i for i in message])


# Generated test cases:
import pytest

def encode(message):
    vowels = "aeiouAEIOU"
    vowels_replace = dict([(i, chr(ord(i) + 2)) for i in vowels])
    message = message.swapcase()
    return ''.join([vowels_replace[i] if i in vowels else i for i in message])


@pytest.mark.parametrize("message,expected", [
    ("test", "TGST"),
    ("This is a message", "tHKS KS C MGSSCGG"),
    ("", ""),
    ("a", "C"),
    ("e", "G"),
    ("i", "K"),
    ("o", "Q"),
    ("u", "W"),
    ("A", "c"),
    ("E", "g"),
    ("I", "k"),
    ("O", "q"),
    ("U", "w"),
    ("aeiou", "CGKQW"),
    ("AEIOU", "cgkqw"),
    ("bcdfg", "BCDFG"),
    ("BCDFG", "bcdfg"),
    ("Hello World", "hGLLQ wQRLD"),
    ("HELLO WORLD", "hgllq wqrld"),
    ("aAeEiIoOuU", "CcGgKkQqWw"),
    ("xyz", "XYZ"),
    ("XYZ", "xyz"),
    ("Programming", "pRQGRCMMKNG"),
    ("PROGRAMMING", "prqgrcmmkng"),
    ("The quick brown fox", "tHG QWKCK BRQWN FQX"),
    ("AEIOUaeiou", "cgkqwCGKQW"),
    ("z", "Z"),
    ("Z", "z"),
    ("abcdefghijklmnopqrstuvwxyz", "CBCDGFGHKJKLMNQPQRSTWVWXYZ"),
    ("ABCDEFGHIJKLMNOPQRSTUVWXYZ", "cbcdgfghkjklmnqpqrstwvwxyz"),
    ("aaa", "CCC"),
    ("AAA", "ccc"),
    ("aea", "CGC"),
    ("AEA", "cgc"),
    ("bbb", "BBB"),
    ("BBB", "bbb"),
])
def test_encode_parametrized(message, expected):
    assert encode(message) == expected


def test_encode_empty_string():
    assert encode("") == ""


def test_encode_single_lowercase_vowel():
    assert encode("a") == "C"
    assert encode("e") == "G"
    assert encode("i") == "K"
    assert encode("o") == "Q"
    assert encode("u") == "W"


def test_encode_single_uppercase_vowel():
    assert encode("A") == "c"
    assert encode("E") == "g"
    assert encode("I") == "k"
    assert encode("O") == "q"
    assert encode("U") == "w"


def test_encode_single_lowercase_consonant():
    assert encode("b") == "B"
    assert encode("z") == "Z"


def test_encode_single_uppercase_consonant():
    assert encode("B") == "b"
    assert encode("Z") == "z"


def test_encode_all_vowels_lowercase():
    assert encode("aeiou") == "CGKQW"


def test_encode_all_vowels_uppercase():
    assert encode("AEIOU") == "cgkqw"


def test_encode_all_consonants_lowercase():
    assert encode("bcdfg") == "BCDFG"


def test_encode_all_consonants_uppercase():
    assert encode("BCDFG") == "bcdfg"


def test_encode_mixed_case_with_spaces():
    assert encode("Hello World") == "hGLLQ wQRLD"


def test_encode_sentence():
    assert encode("This is a message") == "tHKS KS C MGSSCGG"


def test_encode_repeated_vowels():
    assert encode("aaa") == "CCC"
    assert encode("eee") == "GGG"


def test_encode_repeated_consonants():
    assert encode("bbb") == "BBB"
    assert encode("zzz") == "ZZZ"


def test_encode_alphabet_lowercase():
    result = encode("abcdefghijklmnopqrstuvwxyz")
    assert result == "CBCDGFGHKJKLMNQPQRSTWVWXYZ"


def test_encode_alphabet_uppercase():
    result = encode("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
    assert result == "cbcdgfghkjklmnqpqrstwvwxyz"