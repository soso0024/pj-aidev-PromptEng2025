# Test cases for HumanEval/13
# Generated using Claude API



def greatest_common_divisor(a: int, b: int) -> int:
    """ Return a greatest common divisor of two integers a and b
    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """

    while b:
        a, b = b, a % b
    return a


# Generated test cases:
import pytest

def greatest_common_divisor(a: int, b: int) -> int:
    while b:
        a, b = b, a % b
    return a

@pytest.mark.parametrize("a,b,expected", [
    (3, 5, 1),
    (25, 15, 5),
    (10, 5, 5),
    (100, 50, 50),
    (17, 19, 1),
    (48, 18, 6),
    (1, 1, 1),
    (0, 5, 5),
    (5, 0, 5),
    (0, 0, 0),
    (1, 100, 1),
    (100, 1, 1),
    (7, 7, 7),
    (12, 8, 4),
    (54, 24, 6),
    (101, 103, 1),
    (1071, 462, 21),
    (270, 192, 6),
    (13, 13, 13),
    (2, 4, 2),
    (4, 2, 2),
    (15, 25, 5),
    (21, 14, 7),
    (35, 14, 7),
    (144, 60, 12),
    (1000, 500, 500),
    (999, 333, 333),
    (97, 1, 1),
    (1, 97, 1),
])
def test_greatest_common_divisor_parametrized(a, b, expected):
    assert greatest_common_divisor(a, b) == expected

def test_gcd_coprime_numbers():
    assert greatest_common_divisor(17, 13) == 1
    assert greatest_common_divisor(29, 31) == 1

def test_gcd_one_divides_other():
    assert greatest_common_divisor(20, 10) == 10
    assert greatest_common_divisor(10, 20) == 10
    assert greatest_common_divisor(100, 25) == 25

def test_gcd_same_numbers():
    assert greatest_common_divisor(42, 42) == 42
    assert greatest_common_divisor(1, 1) == 1
    assert greatest_common_divisor(999, 999) == 999

def test_gcd_with_zero():
    assert greatest_common_divisor(0, 10) == 10
    assert greatest_common_divisor(10, 0) == 10
    assert greatest_common_divisor(0, 0) == 0

def test_gcd_with_one():
    assert greatest_common_divisor(1, 50) == 1
    assert greatest_common_divisor(50, 1) == 1

def test_gcd_large_numbers():
    assert greatest_common_divisor(123456, 789012) == 12
    assert greatest_common_divisor(1000000, 500000) == 500000

def test_gcd_prime_numbers():
    assert greatest_common_divisor(11, 13) == 1
    assert greatest_common_divisor(23, 29) == 1

def test_gcd_powers_of_two():
    assert greatest_common_divisor(16, 8) == 8
    assert greatest_common_divisor(64, 32) == 32
    assert greatest_common_divisor(128, 256) == 128

def test_gcd_consecutive_numbers():
    assert greatest_common_divisor(5, 6) == 1
    assert greatest_common_divisor(99, 100) == 1
