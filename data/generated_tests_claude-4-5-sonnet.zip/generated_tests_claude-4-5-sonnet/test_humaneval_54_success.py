# Test cases for HumanEval/54
# Generated using Claude API



def same_chars(s0: str, s1: str):
    """
    Check if two words have the same characters.
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddeddabc')
    True
    >>> same_chars('abcd', 'dddddddabc')
    True
    >>> same_chars('dddddddabc', 'abcd')
    True
    >>> same_chars('eabcd', 'dddddddabc')
    False
    >>> same_chars('abcd', 'dddddddabce')
    False
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddddabc')
    False
    """

    return set(s0) == set(s1)


# Generated test cases:
import pytest


def same_chars(s0: str, s1: str):
    return set(s0) == set(s1)


@pytest.mark.parametrize("s0,s1,expected", [
    ("abc", "abc", True),
    ("abc", "cba", True),
    ("abc", "abcd", False),
    ("abcd", "abc", False),
    ("", "", True),
    ("a", "", False),
    ("", "a", False),
    ("aaa", "a", True),
    ("a", "aaa", True),
    ("abc", "def", False),
    ("aabbcc", "abc", True),
    ("abc", "aabbcc", True),
    ("hello", "olleh", True),
    ("hello", "world", False),
    ("123", "321", True),
    ("123", "1234", False),
    ("   ", " ", True),
    ("a b c", "cba", False),
    ("a b c", "abc", False),
    ("!@#", "#@!", True),
    ("!@#", "!@#$", False),
    ("aA", "Aa", True),
    ("aA", "aa", False),
    ("test", "TEST", False),
    ("abcdefg", "gfedcba", True),
    ("abcdefg", "abcdefgh", False),
    ("111", "1", True),
    ("123123", "321", True),
    ("aaabbbccc", "abc", True),
    ("xyz", "xyzxyz", True),
])
def test_same_chars_parametrized(s0, s1, expected):
    assert same_chars(s0, s1) == expected


def test_same_chars_empty_strings():
    assert same_chars("", "") == True


def test_same_chars_one_empty():
    assert same_chars("abc", "") == False
    assert same_chars("", "abc") == False


def test_same_chars_identical():
    assert same_chars("test", "test") == True


def test_same_chars_anagram():
    assert same_chars("listen", "silent") == True


def test_same_chars_different_lengths_same_chars():
    assert same_chars("aaa", "a") == True
    assert same_chars("aaabbb", "ab") == True


def test_same_chars_different_chars():
    assert same_chars("abc", "xyz") == False


def test_same_chars_special_characters():
    assert same_chars("!@#$", "$#@!") == True
    assert same_chars("!@#", "!@#$%") == False


def test_same_chars_whitespace():
    assert same_chars("a b c", "cba") == False
    assert same_chars("   ", " ") == True


def test_same_chars_case_sensitive():
    assert same_chars("Aa", "aA") == True
    assert same_chars("Aa", "aa") == False
    assert same_chars("ABC", "abc") == False


def test_same_chars_numbers():
    assert same_chars("123", "321") == True
    assert same_chars("1234", "123") == False


def test_same_chars_mixed():
    assert same_chars("a1b2c3", "3c2b1a") == True
    assert same_chars("a1b2", "a1b2c3") == False


def test_same_chars_unicode():
    assert same_chars("café", "éfac") == True
    assert same_chars("café", "cafe") == False


def test_same_chars_repeated_chars():
    assert same_chars("aabbcc", "abc") == True
    assert same_chars("aaaa", "a") == True
    assert same_chars("abcabc", "abc") == True