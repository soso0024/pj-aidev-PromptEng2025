# Test cases for HumanEval/50
# Generated using Claude API



def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


def decode_shift(s: str):
    """
    takes as input string encoded with encode_shift function. Returns decoded string.
    """

    return "".join([chr(((ord(ch) - 5 - ord("a")) % 26) + ord("a")) for ch in s])


# Generated test cases:
import pytest

def decode_shift(s: str):
    return "".join([chr(((ord(ch) - 5 - ord("a")) % 26) + ord("a")) for ch in s])

def test_decode_shift_empty_string():
    assert decode_shift("") == ""

def test_decode_shift_single_character():
    assert decode_shift("f") == "a"

def test_decode_shift_wrap_around():
    assert decode_shift("a") == "v"
    assert decode_shift("b") == "w"
    assert decode_shift("c") == "x"
    assert decode_shift("d") == "y"
    assert decode_shift("e") == "z"

def test_decode_shift_no_wrap():
    assert decode_shift("f") == "a"
    assert decode_shift("g") == "b"
    assert decode_shift("h") == "c"
    assert decode_shift("z") == "u"

def test_decode_shift_full_alphabet():
    encoded = "fghijklmnopqrstuvwxyzabcde"
    expected = "abcdefghijklmnopqrstuvwxyz"
    assert decode_shift(encoded) == expected

def test_decode_shift_word():
    assert decode_shift("mjqqt") == "hello"

def test_decode_shift_multiple_words():
    assert decode_shift("mjqqtbtwqi") == "helloworld"

@pytest.mark.parametrize("input_str,expected", [
    ("f", "a"),
    ("a", "v"),
    ("z", "u"),
    ("mjqqt", "hello"),
    ("", ""),
    ("fghij", "abcde"),
    ("abcde", "vwxyz"),
])
def test_decode_shift_parametrized(input_str, expected):
    assert decode_shift(input_str) == expected

def test_decode_shift_all_same_character():
    assert decode_shift("aaaaa") == "vvvvv"
    assert decode_shift("zzzzz") == "uuuuu"

def test_decode_shift_long_string():
    long_input = "f" * 1000
    expected = "a" * 1000
    assert decode_shift(long_input) == expected

def test_decode_shift_inverse_property():
    def encode_shift(s: str):
        return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])
    
    original = "abcdefghijklmnopqrstuvwxyz"
    encoded = encode_shift(original)
    decoded = decode_shift(encoded)
    assert decoded == original

def test_decode_shift_specific_patterns():
    assert decode_shift("fgh") == "abc"
    assert decode_shift("xyz") == "stu"
    assert decode_shift("abc") == "vwx"
