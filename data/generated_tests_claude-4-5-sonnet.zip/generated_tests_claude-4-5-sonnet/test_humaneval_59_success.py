# Test cases for HumanEval/59
# Generated using Claude API



def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """

    def is_prime(k):
        if k < 2:
            return False
        for i in range(2, k - 1):
            if k % i == 0:
                return False
        return True
    largest = 1
    for j in range(2, n + 1):
        if n % j == 0 and is_prime(j):
            largest = max(largest, j)
    return largest


# Generated test cases:
import pytest


def largest_prime_factor(n: int):
    def is_prime(k):
        if k < 2:
            return False
        for i in range(2, k - 1):
            if k % i == 0:
                return False
        return True
    largest = 1
    for j in range(2, n + 1):
        if n % j == 0 and is_prime(j):
            largest = max(largest, j)
    return largest


@pytest.mark.parametrize("n,expected", [
    (2, 2),
    (3, 3),
    (4, 2),
    (5, 5),
    (6, 3),
    (7, 7),
    (8, 2),
    (9, 3),
    (10, 5),
    (13, 13),
    (15, 5),
    (21, 7),
    (29, 29),
    (100, 5),
    (13195, 29),
    (17, 17),
    (18, 3),
    (20, 5),
    (25, 5),
    (30, 5),
    (49, 7),
    (50, 5),
    (77, 11),
    (91, 13),
    (121, 11),
    (143, 13),
])
def test_largest_prime_factor_normal_cases(n, expected):
    assert largest_prime_factor(n) == expected


def test_largest_prime_factor_small_primes():
    assert largest_prime_factor(2) == 2
    assert largest_prime_factor(3) == 3
    assert largest_prime_factor(5) == 5
    assert largest_prime_factor(7) == 7
    assert largest_prime_factor(11) == 11


def test_largest_prime_factor_powers_of_two():
    assert largest_prime_factor(2) == 2
    assert largest_prime_factor(4) == 2
    assert largest_prime_factor(8) == 2
    assert largest_prime_factor(16) == 2
    assert largest_prime_factor(32) == 2


def test_largest_prime_factor_powers_of_three():
    assert largest_prime_factor(3) == 3
    assert largest_prime_factor(9) == 3
    assert largest_prime_factor(27) == 3


def test_largest_prime_factor_composite_numbers():
    assert largest_prime_factor(12) == 3
    assert largest_prime_factor(14) == 7
    assert largest_prime_factor(15) == 5
    assert largest_prime_factor(35) == 7
    assert largest_prime_factor(42) == 7


def test_largest_prime_factor_products_of_two_primes():
    assert largest_prime_factor(6) == 3
    assert largest_prime_factor(10) == 5
    assert largest_prime_factor(14) == 7
    assert largest_prime_factor(15) == 5
    assert largest_prime_factor(22) == 11
    assert largest_prime_factor(33) == 11
