# Test cases for HumanEval/80
# Generated using Claude API


def is_happy(s):
    """You are given a string s.
    Your task is to check if the string is happy or not.
    A string is happy if its length is at least 3 and every 3 consecutive letters are distinct
    For example:
    is_happy(a) => False
    is_happy(aa) => False
    is_happy(abcd) => True
    is_happy(aabb) => False
    is_happy(adb) => True
    is_happy(xyy) => False
    """

    if len(s) < 3:
      return False

    for i in range(len(s) - 2):
      
      if s[i] == s[i+1] or s[i+1] == s[i+2] or s[i] == s[i+2]:
        return False
    return True


# Generated test cases:
import pytest

def is_happy(s):
    if len(s) < 3:
      return False

    for i in range(len(s) - 2):
      
      if s[i] == s[i+1] or s[i+1] == s[i+2] or s[i] == s[i+2]:
        return False
    return True


def test_empty_string():
    assert is_happy("") == False


def test_single_character():
    assert is_happy("a") == False


def test_two_characters():
    assert is_happy("ab") == False


def test_three_characters_all_different():
    assert is_happy("abc") == True


def test_three_characters_first_two_same():
    assert is_happy("aab") == False


def test_three_characters_last_two_same():
    assert is_happy("abb") == False


def test_three_characters_first_and_last_same():
    assert is_happy("aba") == False


def test_three_characters_all_same():
    assert is_happy("aaa") == False


def test_happy_string_length_four():
    assert is_happy("abcd") == True


def test_unhappy_consecutive_same():
    assert is_happy("abbc") == False


def test_unhappy_alternating_pattern():
    assert is_happy("abab") == False


def test_happy_string_no_repeats():
    assert is_happy("abcdef") == True


def test_unhappy_with_repeat_at_end():
    assert is_happy("abcdd") == False


def test_unhappy_with_repeat_in_middle():
    assert is_happy("abccde") == False


def test_happy_long_string():
    assert is_happy("abcdefghij") == True


def test_unhappy_pattern_aba():
    assert is_happy("xyzxyz") == True


def test_happy_string_with_numbers():
    assert is_happy("123") == True


def test_unhappy_string_with_numbers():
    assert is_happy("121") == False


@pytest.mark.parametrize("input_str,expected", [
    ("", False),
    ("a", False),
    ("ab", False),
    ("abc", True),
    ("aaa", False),
    ("aba", False),
    ("aab", False),
    ("abb", False),
    ("abcd", True),
    ("abcabc", True),
    ("abcdefg", True),
    ("xyzxyz", True),
    ("123456", True),
    ("121212", False),
    ("abcddcba", False),
    ("xyz", True),
    ("xyx", False),
])
def test_is_happy_parametrized(input_str, expected):
    assert is_happy(input_str) == expected


def test_happy_minimum_valid_length():
    assert is_happy("xyz") == True


def test_unhappy_all_same_long():
    assert is_happy("aaaa") == False


def test_happy_special_characters():
    assert is_happy("!@#") == True


def test_unhappy_special_characters():
    assert is_happy("!@!") == False