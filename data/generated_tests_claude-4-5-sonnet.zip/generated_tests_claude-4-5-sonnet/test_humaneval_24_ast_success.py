# Test cases for HumanEval/24
# Generated using Claude API



def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    >>> largest_divisor(15)
    5
    """

    for i in reversed(range(n)):
        if n % i == 0:
            return i


# Generated test cases:
import pytest

def largest_divisor(n: int) -> int:
    for i in reversed(range(n)):
        if n % i == 0:
            return i

def test_largest_divisor_small_prime():
    assert largest_divisor(7) == 1

def test_largest_divisor_composite():
    assert largest_divisor(12) == 6

def test_largest_divisor_even():
    assert largest_divisor(10) == 5

def test_largest_divisor_power_of_two():
    assert largest_divisor(16) == 8

def test_largest_divisor_large_prime():
    assert largest_divisor(97) == 1

def test_largest_divisor_large_composite():
    assert largest_divisor(100) == 50

def test_largest_divisor_two():
    assert largest_divisor(2) == 1

def test_largest_divisor_three():
    assert largest_divisor(3) == 1

def test_largest_divisor_four():
    assert largest_divisor(4) == 2

def test_largest_divisor_six():
    assert largest_divisor(6) == 3

def test_largest_divisor_nine():
    assert largest_divisor(9) == 3

def test_largest_divisor_fifteen():
    assert largest_divisor(15) == 5

def test_largest_divisor_twenty():
    assert largest_divisor(20) == 10

def test_largest_divisor_thirty():
    assert largest_divisor(30) == 15

def test_largest_divisor_fifty():
    assert largest_divisor(50) == 25

def test_largest_divisor_hundred():
    assert largest_divisor(100) == 50

@pytest.mark.parametrize("n,expected", [
    (2, 1),
    (3, 1),
    (4, 2),
    (5, 1),
    (6, 3),
    (8, 4),
    (9, 3),
    (10, 5),
    (12, 6),
    (15, 5),
    (18, 9),
    (20, 10),
    (24, 12),
    (25, 5),
    (36, 18),
    (49, 7),
    (64, 32),
    (81, 27),
    (100, 50),
    (121, 11),
])
def test_largest_divisor_parametrized(n, expected):
    assert largest_divisor(n) == expected
