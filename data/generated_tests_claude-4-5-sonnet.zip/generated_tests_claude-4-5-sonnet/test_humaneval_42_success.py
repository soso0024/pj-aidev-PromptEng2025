# Test cases for HumanEval/42
# Generated using Claude API



def incr_list(l: list):
    """Return list with elements incremented by 1.
    >>> incr_list([1, 2, 3])
    [2, 3, 4]
    >>> incr_list([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [6, 4, 6, 3, 4, 4, 10, 1, 124]
    """

    return [(e + 1) for e in l]


# Generated test cases:
import pytest

def incr_list(l: list):
    return [(e + 1) for e in l]


def test_incr_list_empty():
    assert incr_list([]) == []


def test_incr_list_single_element():
    assert incr_list([1]) == [2]


def test_incr_list_multiple_elements():
    assert incr_list([1, 2, 3]) == [2, 3, 4]


def test_incr_list_negative_numbers():
    assert incr_list([-1, -2, -3]) == [0, -1, -2]


def test_incr_list_mixed_numbers():
    assert incr_list([-1, 0, 1]) == [0, 1, 2]


def test_incr_list_zero():
    assert incr_list([0]) == [1]


def test_incr_list_large_numbers():
    assert incr_list([999, 1000, 1001]) == [1000, 1001, 1002]


def test_incr_list_floats():
    assert incr_list([1.5, 2.5, 3.5]) == [2.5, 3.5, 4.5]


def test_incr_list_mixed_int_float():
    assert incr_list([1, 2.5, 3]) == [2, 3.5, 4]


@pytest.mark.parametrize("input_list,expected", [
    ([1], [2]),
    ([0], [1]),
    ([5, 10, 15], [6, 11, 16]),
    ([-5, -10], [-4, -9]),
    ([100], [101])
])
def test_incr_list_parametrized(input_list, expected):
    assert incr_list(input_list) == expected


def test_incr_list_does_not_modify_original():
    original = [1, 2, 3]
    result = incr_list(original)
    assert original == [1, 2, 3]
    assert result == [2, 3, 4]


def test_incr_list_with_non_numeric_raises_error():
    with pytest.raises(TypeError):
        incr_list(['a', 'b', 'c'])


def test_incr_list_with_mixed_types_raises_error():
    with pytest.raises(TypeError):
        incr_list([1, 'a', 3])


def test_incr_list_with_none_raises_error():
    with pytest.raises(TypeError):
        incr_list([1, None, 3])
