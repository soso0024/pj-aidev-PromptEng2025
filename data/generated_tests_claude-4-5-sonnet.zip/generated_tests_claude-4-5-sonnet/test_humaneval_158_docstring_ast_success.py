# Test cases for HumanEval/158
# Generated using Claude API


def find_max(words):
    """Write a function that accepts a list of strings.
    The list contains different words. Return the word with maximum number
    of unique characters. If multiple strings have maximum number of unique
    characters, return the one which comes first in lexicographical order.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb" ,"cc"]) == ""aaaaaaa"
    """

    return sorted(words, key = lambda x: (-len(set(x)), x))[0]


# Generated test cases:
import pytest

def find_max(words):
    return sorted(words, key = lambda x: (-len(set(x)), x))[0]

def test_find_max_basic():
    assert find_max(["name", "of", "string"]) == "string"

def test_find_max_lexicographical():
    assert find_max(["name", "enam", "game"]) == "enam"

def test_find_max_same_char():
    assert find_max(["aaaaaaa", "bb", "cc"]) == "aaaaaaa"

def test_find_max_single_word():
    assert find_max(["hello"]) == "hello"

def test_find_max_empty_string():
    assert find_max([""]) == ""

def test_find_max_with_empty_strings():
    assert find_max(["", "a", "ab"]) == "ab"

def test_find_max_all_same_unique_chars():
    assert find_max(["abc", "def", "ghi"]) == "abc"

def test_find_max_two_words():
    assert find_max(["ab", "ba"]) == "ab"

def test_find_max_repeated_chars():
    assert find_max(["aaa", "bbb", "ccc"]) == "aaa"

def test_find_max_mixed_lengths():
    assert find_max(["a", "ab", "abc", "abcd"]) == "abcd"

def test_find_max_same_unique_different_length():
    assert find_max(["aaa", "a", "aa"]) == "a"

def test_find_max_complex_case():
    assert find_max(["abcde", "abcd", "abc", "ab", "a"]) == "abcde"

def test_find_max_tie_breaker():
    assert find_max(["xyz", "abc", "def"]) == "abc"

def test_find_max_numbers_as_strings():
    assert find_max(["123", "456", "789"]) == "123"

def test_find_max_special_chars():
    assert find_max(["!@#", "$%^", "&*()"]) == "&*()"

def test_find_max_mixed_case():
    assert find_max(["ABC", "abc", "AbC"]) == "ABC"

def test_find_max_unicode():
    assert find_max(["αβγ", "δεζ", "ηθι"]) == "αβγ"

def test_find_max_spaces():
    assert find_max(["a b", "c d", "e f"]) == "a b"

def test_find_max_duplicate_words():
    assert find_max(["test", "test", "best"]) == "best"

def test_find_max_one_unique_vs_many_repeated():
    assert find_max(["abcdef", "aaaaaa"]) == "abcdef"