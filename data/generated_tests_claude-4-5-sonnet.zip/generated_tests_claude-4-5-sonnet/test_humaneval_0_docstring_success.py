# Test cases for HumanEval/0
# Generated using Claude API

from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """

    for idx, elem in enumerate(numbers):
        for idx2, elem2 in enumerate(numbers):
            if idx != idx2:
                distance = abs(elem - elem2)
                if distance < threshold:
                    return True

    return False


# Generated test cases:
import pytest
from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    for idx, elem in enumerate(numbers):
        for idx2, elem2 in enumerate(numbers):
            if idx != idx2:
                distance = abs(elem - elem2)
                if distance < threshold:
                    return True
    return False


class TestHasCloseElements:
    
    def test_no_close_elements(self):
        assert has_close_elements([1.0, 2.0, 3.0], 0.5) == False
    
    def test_has_close_elements(self):
        assert has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3) == True
    
    def test_empty_list(self):
        assert has_close_elements([], 0.5) == False
    
    def test_single_element(self):
        assert has_close_elements([1.0], 0.5) == False
    
    def test_two_elements_close(self):
        assert has_close_elements([1.0, 1.1], 0.2) == True
    
    def test_two_elements_not_close(self):
        assert has_close_elements([1.0, 2.0], 0.5) == False
    
    def test_identical_elements(self):
        assert has_close_elements([1.0, 1.0], 0.1) == True
    
    def test_identical_elements_zero_threshold(self):
        assert has_close_elements([1.0, 1.0], 0.0) == False
    
    def test_negative_numbers(self):
        assert has_close_elements([-1.0, -1.5, -2.0], 0.3) == False
    
    def test_negative_numbers_close(self):
        assert has_close_elements([-1.0, -1.2, -2.0], 0.3) == True
    
    def test_mixed_positive_negative(self):
        assert has_close_elements([-1.0, 1.0, 2.0], 0.5) == False
    
    def test_mixed_positive_negative_close(self):
        assert has_close_elements([-1.0, -0.9, 1.0], 0.2) == True
    
    def test_zero_in_list(self):
        assert has_close_elements([0.0, 1.0, 2.0], 0.5) == False
    
    def test_zero_in_list_close(self):
        assert has_close_elements([0.0, 0.1, 2.0], 0.2) == True
    
    def test_large_threshold(self):
        assert has_close_elements([1.0, 10.0, 100.0], 50.0) == True
    
    def test_very_small_threshold(self):
        assert has_close_elements([1.0, 2.0, 3.0], 0.0001) == False
    
    def test_exact_threshold_boundary(self):
        assert has_close_elements([1.0, 1.5], 0.5) == False
    
    def test_just_below_threshold(self):
        assert has_close_elements([1.0, 1.49], 0.5) == True
    
    def test_multiple_close_pairs(self):
        assert has_close_elements([1.0, 1.1, 2.0, 2.1], 0.2) == True
    
    def test_all_same_elements(self):
        assert has_close_elements([5.0, 5.0, 5.0, 5.0], 0.1) == True
    
    def test_large_list_no_close(self):
        assert has_close_elements([1.0, 3.0, 5.0, 7.0, 9.0, 11.0], 1.0) == False
    
    def test_large_list_with_close(self):
        assert has_close_elements([1.0, 3.0, 5.0, 7.0, 9.0, 9.5], 1.0) == True
    
    def test_floating_point_precision(self):
        assert has_close_elements([1.0, 1.0000001], 0.000001) == True
    
    def test_very_large_numbers(self):
        assert has_close_elements([1000000.0, 1000001.0], 2.0) == True
    
    def test_very_small_numbers(self):
        assert has_close_elements([0.0001, 0.0002, 0.0003], 0.00005) == False


@pytest.mark.parametrize("numbers,threshold,expected", [
    ([1.0, 2.0, 3.0], 0.5, False),
    ([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3, True),
    ([], 0.5, False),
    ([1.0], 0.5, False),
    ([1.0, 1.0], 0.1, True),
    ([1.0, 1.5, 2.0], 0.5, False),
    ([1.0, 1.4, 2.0], 0.5, True),
    ([-5.0, -4.5, 0.0], 0.6, True),
    ([10.0, 20.0, 30.0], 5.0, False),
])
def test_has_close_elements_parametrized(numbers, threshold, expected):
    assert has_close_elements(numbers, threshold) == expected
