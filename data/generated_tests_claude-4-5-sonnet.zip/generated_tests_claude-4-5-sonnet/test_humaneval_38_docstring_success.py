# Test cases for HumanEval/38
# Generated using Claude API



def encode_cyclic(s: str):
    """
    returns encoded string by cycling groups of three characters.
    """
    # split string to groups. Each of length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # cycle elements in each group. Unless group has fewer elements than 3.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def decode_cyclic(s: str):
    """
    takes as input string encoded with encode_cyclic function. Returns decoded string.
    """

    return encode_cyclic(encode_cyclic(s))


# Generated test cases:
import pytest


def encode_cyclic(s: str):
    """
    returns encoded string by cycling groups of three characters.
    """
    # split string to groups. Each of length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # cycle elements in each group. Unless group has fewer elements than 3.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def decode_cyclic(s: str):
    return encode_cyclic(encode_cyclic(s))


def test_decode_cyclic_empty_string():
    assert decode_cyclic("") == ""


def test_decode_cyclic_single_character():
    assert decode_cyclic("a") == "a"


def test_decode_cyclic_two_characters():
    assert decode_cyclic("ab") == "ab"


def test_decode_cyclic_three_characters():
    encoded = encode_cyclic("abc")
    assert decode_cyclic(encoded) == "abc"


def test_decode_cyclic_six_characters():
    encoded = encode_cyclic("abcdef")
    assert decode_cyclic(encoded) == "abcdef"


def test_decode_cyclic_four_characters():
    encoded = encode_cyclic("abcd")
    assert decode_cyclic(encoded) == "abcd"


def test_decode_cyclic_five_characters():
    encoded = encode_cyclic("abcde")
    assert decode_cyclic(encoded) == "abcde"


def test_decode_cyclic_seven_characters():
    encoded = encode_cyclic("abcdefg")
    assert decode_cyclic(encoded) == "abcdefg"


def test_decode_cyclic_eight_characters():
    encoded = encode_cyclic("abcdefgh")
    assert decode_cyclic(encoded) == "abcdefgh"


def test_decode_cyclic_nine_characters():
    encoded = encode_cyclic("abcdefghi")
    assert decode_cyclic(encoded) == "abcdefghi"


def test_decode_cyclic_with_spaces():
    encoded = encode_cyclic("abc def")
    assert decode_cyclic(encoded) == "abc def"


def test_decode_cyclic_with_numbers():
    encoded = encode_cyclic("123456789")
    assert decode_cyclic(encoded) == "123456789"


def test_decode_cyclic_with_special_characters():
    encoded = encode_cyclic("!@#$%^")
    assert decode_cyclic(encoded) == "!@#$%^"


def test_decode_cyclic_long_string():
    original = "abcdefghijklmnopqrstuvwxyz"
    encoded = encode_cyclic(original)
    assert decode_cyclic(encoded) == original


def test_decode_cyclic_repeated_characters():
    encoded = encode_cyclic("aaaaaa")
    assert decode_cyclic(encoded) == "aaaaaa"


@pytest.mark.parametrize("input_str", [
    "a",
    "ab",
    "abc",
    "abcd",
    "abcde",
    "abcdef",
    "abcdefg",
    "abcdefgh",
    "abcdefghi",
    "abcdefghij",
    "hello world",
    "123",
    "1234567890",
    "!@#$%^&*()",
    ""
])
def test_decode_cyclic_parametrized(input_str):
    encoded = encode_cyclic(input_str)
    assert decode_cyclic(encoded) == input_str


def test_encode_decode_cycle_property():
    test_strings = ["", "a", "ab", "abc", "abcd", "abcde", "abcdef", "test123", "hello world!"]
    for s in test_strings:
        encoded = encode_cyclic(s)
        decoded = decode_cyclic(encoded)
        assert decoded == s


def test_decode_cyclic_unicode():
    encoded = encode_cyclic("αβγδεζ")
    assert decode_cyclic(encoded) == "αβγδεζ"


def test_decode_cyclic_mixed_case():
    encoded = encode_cyclic("AbCdEf")
    assert decode_cyclic(encoded) == "AbCdEf"
