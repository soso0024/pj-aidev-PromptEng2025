# Test cases for HumanEval/36
# Generated using Claude API



def fizz_buzz(n: int):
    """Return the number of times the digit 7 appears in integers less than n which are divisible by 11 or 13.
    >>> fizz_buzz(50)
    0
    >>> fizz_buzz(78)
    2
    >>> fizz_buzz(79)
    3
    """

    ns = []
    for i in range(n):
        if i % 11 == 0 or i % 13 == 0:
            ns.append(i)
    s = ''.join(list(map(str, ns)))
    ans = 0
    for c in s:
        ans += (c == '7')
    return ans


# Generated test cases:
import pytest

def fizz_buzz(n: int):
    ns = []
    for i in range(n):
        if i % 11 == 0 or i % 13 == 0:
            ns.append(i)
    s = ''.join(list(map(str, ns)))
    ans = 0
    for c in s:
        ans += (c == '7')
    return ans

@pytest.mark.parametrize("n,expected", [
    (0, 0),
    (1, 0),
    (11, 0),
    (13, 0),
    (14, 0),
    (22, 0),
    (26, 0),
    (50, 0),
    (78, 2),
    (79, 3),
    (100, 3),
    (150, 4),
    (200, 6),
    (78, 2),
    (144, 4),
    (145, 4),
])
def test_fizz_buzz_parametrized(n, expected):
    assert fizz_buzz(n) == expected

def test_fizz_buzz_zero():
    assert fizz_buzz(0) == 0

def test_fizz_buzz_one():
    assert fizz_buzz(1) == 0

def test_fizz_buzz_small_no_seven():
    assert fizz_buzz(11) == 0

def test_fizz_buzz_includes_thirteen():
    assert fizz_buzz(14) == 0

def test_fizz_buzz_with_seven_in_number():
    result = fizz_buzz(78)
    assert result == 2

def test_fizz_buzz_multiple_sevens():
    result = fizz_buzz(100)
    assert result == 3

def test_fizz_buzz_large_number():
    result = fizz_buzz(200)
    assert result == 6

def test_fizz_buzz_includes_multiples_of_11():
    result = fizz_buzz(23)
    assert result == 0

def test_fizz_buzz_includes_multiples_of_13():
    result = fizz_buzz(27)
    assert result == 0

def test_fizz_buzz_includes_both_11_and_13():
    result = fizz_buzz(144)
    assert result == 4

def test_fizz_buzz_seventy_seven():
    result = fizz_buzz(78)
    assert result == 2

def test_fizz_buzz_includes_zero():
    result = fizz_buzz(1)
    assert result == 0

def test_fizz_buzz_boundary_at_143():
    result = fizz_buzz(144)
    assert result == 4

def test_fizz_buzz_boundary_at_144():
    result = fizz_buzz(145)
    assert result == 4