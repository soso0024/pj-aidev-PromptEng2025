# Test cases for HumanEval/158
# Generated using Claude API


def find_max(words):
    """Write a function that accepts a list of strings.
    The list contains different words. Return the word with maximum number
    of unique characters. If multiple strings have maximum number of unique
    characters, return the one which comes first in lexicographical order.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb" ,"cc"]) == ""aaaaaaa"
    """

    return sorted(words, key = lambda x: (-len(set(x)), x))[0]


# Generated test cases:
import pytest


def find_max(words):
    return sorted(words, key = lambda x: (-len(set(x)), x))[0]


def test_find_max_single_word():
    assert find_max(["hello"]) == "hello"


def test_find_max_different_unique_chars():
    assert find_max(["abc", "ab", "a"]) == "abc"


def test_find_max_same_unique_chars_lexicographic():
    assert find_max(["abc", "def", "ghi"]) == "abc"


def test_find_max_repeated_chars():
    assert find_max(["aaa", "abc"]) == "abc"


def test_find_max_tie_breaker():
    assert find_max(["cat", "dog", "bat"]) == "bat"


def test_find_max_empty_string_in_list():
    assert find_max(["", "a"]) == "a"


def test_find_max_all_same_char():
    assert find_max(["aaa", "bb", "c"]) == "aaa"


def test_find_max_mixed_lengths():
    assert find_max(["abcd", "aabbccdd", "xyz"]) == "aabbccdd"


def test_find_max_case_sensitive():
    assert find_max(["ABC", "abc"]) == "ABC"


def test_find_max_numbers_as_strings():
    assert find_max(["123", "111", "456"]) == "123"


def test_find_max_special_characters():
    assert find_max(["a!b", "abc", "a!!"]) == "a!b"


def test_find_max_unicode():
    assert find_max(["αβγ", "ααα", "abc"]) == "abc"


def test_find_max_two_words_same_unique():
    assert find_max(["aab", "bba"]) == "aab"


def test_find_max_longer_word_fewer_unique():
    assert find_max(["aaaa", "ab"]) == "ab"


def test_find_max_multiple_ties():
    assert find_max(["xyz", "abc", "def"]) == "abc"


def test_find_max_single_char_words():
    assert find_max(["a", "b", "c"]) == "a"


def test_find_max_whitespace():
    assert find_max(["a b", "abc", "a  "]) == "a b"


def test_find_max_repeated_words():
    assert find_max(["hello", "world", "hello"]) == "world"


def test_find_max_long_strings():
    assert find_max(["abcdefghij", "aaaaaaaaaa", "abcde"]) == "abcdefghij"


def test_find_max_all_empty_except_one():
    assert find_max(["", "", "a"]) == "a"