# Test cases for HumanEval/145
# Generated using Claude API


def order_by_points(nums):
    """
    Write a function which sorts the given list of integers
    in ascending order according to the sum of their digits.
    Note: if there are several items with similar sum of their digits,
    order them based on their index in original list.

    For example:
    >>> order_by_points([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    >>> order_by_points([]) == []
    """

    def digits_sum(n):
        neg = 1
        if n < 0: n, neg = -1 * n, -1 
        n = [int(i) for i in str(n)]
        n[0] = n[0] * neg
        return sum(n)
    return sorted(nums, key=digits_sum)


# Generated test cases:
import pytest

def order_by_points(nums):
    def digits_sum(n):
        neg = 1
        if n < 0: n, neg = -1 * n, -1 
        n = [int(i) for i in str(n)]
        n[0] = n[0] * neg
        return sum(n)
    return sorted(nums, key=digits_sum)


def test_order_by_points_example_1():
    assert order_by_points([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]


def test_order_by_points_empty_list():
    assert order_by_points([]) == []


def test_order_by_points_single_element():
    assert order_by_points([5]) == [5]


def test_order_by_points_all_positive():
    assert order_by_points([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]


def test_order_by_points_all_negative():
    assert order_by_points([-1, -2, -3, -4, -5]) == [-5, -4, -3, -2, -1]


def test_order_by_points_mixed_signs():
    assert order_by_points([5, -5, 10, -10]) == [-5, -10, 5, 10]


def test_order_by_points_same_digit_sum():
    assert order_by_points([12, 21, 30]) == [12, 21, 30]


def test_order_by_points_zero():
    assert order_by_points([0]) == [0]


def test_order_by_points_with_zeros():
    assert order_by_points([0, 1, -1, 2, -2]) == [-2, -1, 0, 1, 2]


def test_order_by_points_large_numbers():
    assert order_by_points([999, 100, 1]) == [1, 100, 999]


def test_order_by_points_negative_large_numbers():
    assert order_by_points([-999, -100, -1]) == [-999, -100, -1]


def test_order_by_points_duplicate_values():
    assert order_by_points([5, 5, 5]) == [5, 5, 5]


def test_order_by_points_complex_case():
    assert order_by_points([111, 21, 3, 4000, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]) == [10, 11, 111, 21, 3, 12, 4000, 13, 5, 14, 6, 15, 7, 8, 9]


def test_order_by_points_negative_complex():
    assert order_by_points([-111, -21, -3, -4000, -5]) == [-5, -4000, -3, -21, -111]


def test_order_by_points_mixed_complex():
    assert order_by_points([123, -123, 321, -321, 0]) == [-321, -123, 0, 123, 321]


def test_order_by_points_preserve_order_same_sum():
    result = order_by_points([10, 100, 1000])
    assert result == [10, 100, 1000]


def test_order_by_points_two_digit_numbers():
    assert order_by_points([23, 32, 14, 41]) == [23, 32, 14, 41]


def test_order_by_points_negative_two_digit():
    assert order_by_points([-23, -32, -14, -41]) == [-41, -32, -23, -14]


def test_order_by_points_mixed_two_digit():
    assert order_by_points([23, -23, 32, -32]) == [-32, -23, 23, 32]