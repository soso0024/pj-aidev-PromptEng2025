# Test cases for HumanEval/146
# Generated using Claude API


def specialFilter(nums):
    """Write a function that takes an array of numbers as input and returns 
    the number of elements in the array that are greater than 10 and both 
    first and last digits of a number are odd (1, 3, 5, 7, 9).
    For example:
    specialFilter([15, -73, 14, -15]) => 1 
    specialFilter([33, -2, -3, 45, 21, 109]) => 2
    """

    
    count = 0
    for num in nums:
        if num > 10:
            odd_digits = (1, 3, 5, 7, 9)
            number_as_string = str(num)
            if int(number_as_string[0]) in odd_digits and int(number_as_string[-1]) in odd_digits:
                count += 1
        
    return count 


# Generated test cases:
import pytest

def specialFilter(nums):
    count = 0
    for num in nums:
        if num > 10:
            odd_digits = (1, 3, 5, 7, 9)
            number_as_string = str(num)
            if int(number_as_string[0]) in odd_digits and int(number_as_string[-1]) in odd_digits:
                count += 1
        
    return count

@pytest.mark.parametrize("nums,expected", [
    ([15, -73, 14, -15], 1),
    ([33, -2, -3, 45, 21, 109], 2),
    ([], 0),
    ([1, 2, 3, 4, 5], 0),
    ([11], 1),
    ([13], 1),
    ([15], 1),
    ([17], 1),
    ([19], 1),
    ([31], 1),
    ([33], 1),
    ([35], 1),
    ([37], 1),
    ([39], 1),
    ([51], 1),
    ([53], 1),
    ([55], 1),
    ([57], 1),
    ([59], 1),
    ([71], 1),
    ([73], 1),
    ([75], 1),
    ([77], 1),
    ([79], 1),
    ([91], 1),
    ([93], 1),
    ([95], 1),
    ([97], 1),
    ([99], 1),
    ([10], 0),
    ([12], 0),
    ([14], 0),
    ([16], 0),
    ([18], 0),
    ([20], 0),
    ([22], 0),
    ([24], 0),
    ([26], 0),
    ([28], 0),
    ([111], 1),
    ([113], 1),
    ([131], 1),
    ([333], 1),
    ([555], 1),
    ([777], 1),
    ([999], 1),
    ([112], 0),
    ([114], 0),
    ([211], 0),
    ([411], 0),
    ([123], 1),
    ([321], 1),
    ([135], 1),
    ([531], 1),
    ([124], 0),
    ([421], 0),
    ([11, 13, 15, 17, 19], 5),
    ([12, 14, 16, 18, 20], 0),
    ([11, 12, 13, 14, 15], 3),
    ([-11, -13, -15], 0),
    ([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 0),
    ([11, 22, 33, 44, 55], 3),
    ([100, 200, 300], 0),
    ([101, 201, 301], 2),
    ([111, 222, 333], 2),
    ([1111, 2222, 3333], 2),
    ([1357, 2468, 9753], 2),
    ([10, 11, 12, 13, 14, 15, 16, 17, 18, 19], 5),
    ([21, 23, 25, 27, 29], 0),
    ([31, 33, 35, 37, 39], 5),
    ([41, 43, 45, 47, 49], 0),
    ([51, 53, 55, 57, 59], 5),
    ([61, 63, 65, 67, 69], 0),
    ([71, 73, 75, 77, 79], 5),
    ([81, 83, 85, 87, 89], 0),
    ([91, 93, 95, 97, 99], 5),
    ([11, 13, 15, 17, 19, 21, 23, 25, 27, 29], 5),
    ([12, 14, 16, 18, 20, 22, 24, 26, 28, 30], 0),
    ([1, 3, 5, 7, 9, 11, 13, 15, 17, 19], 5),
    ([2, 4, 6, 8, 10, 12, 14, 16, 18, 20], 0),
    ([-100, -50, -10, 0, 10, 50, 100], 0),
    ([11, -11, 13, -13, 15, -15], 3),
])
def test_specialFilter(nums, expected):
    assert specialFilter(nums) == expected

def test_specialFilter_empty_list():
    assert specialFilter([]) == 0

def test_specialFilter_single_element_valid():
    assert specialFilter([11]) == 1

def test_specialFilter_single_element_invalid():
    assert specialFilter([12]) == 0

def test_specialFilter_all_valid():
    assert specialFilter([11, 33, 55, 77, 99]) == 5

def test_specialFilter_all_invalid():
    assert specialFilter([12, 14, 16, 18, 20]) == 0

def test_specialFilter_mixed():
    assert specialFilter([11, 12, 13, 14, 15]) == 3

def test_specialFilter_negative_numbers():
    assert specialFilter([-11, -13, -15, -17, -19]) == 0

def test_specialFilter_large_numbers():
    assert specialFilter([1111, 2222, 3333, 4444, 5555]) == 3

def test_specialFilter_boundary_10():
    assert specialFilter([10]) == 0

def test_specialFilter_boundary_11():
    assert specialFilter([11]) == 1