# Test cases for HumanEval/117
# Generated using Claude API


def select_words(s, n):
    """Given a string s and a natural number n, you have been tasked to implement 
    a function that returns a list of all words from string s that contain exactly 
    n consonants, in order these words appear in the string s.
    If the string s is empty then the function should return an empty list.
    Note: you may assume the input string contains only letters and spaces.
    Examples:
    select_words("Mary had a little lamb", 4) ==> ["little"]
    select_words("Mary had a little lamb", 3) ==> ["Mary", "lamb"]
    select_words("simple white space", 2) ==> []
    select_words("Hello world", 4) ==> ["world"]
    select_words("Uncle sam", 3) ==> ["Uncle"]
    """

    result = []
    for word in s.split():
        n_consonants = 0
        for i in range(0, len(word)):
            if word[i].lower() not in ["a","e","i","o","u"]:
                n_consonants += 1 
        if n_consonants == n:
            result.append(word)
    return result



# Generated test cases:
import pytest

def select_words(s, n):
    result = []
    for word in s.split():
        n_consonants = 0
        for i in range(0, len(word)):
            if word[i].lower() not in ["a","e","i","o","u"]:
                n_consonants += 1 
        if n_consonants == n:
            result.append(word)
    return result


@pytest.mark.parametrize("s,n,expected", [
    ("Mary had a little lamb", 4, ["little"]),
    ("Mary had a little lamb", 3, ["Mary", "lamb"]),
    ("simple white space", 2, []),
    ("Hello world", 4, ["world"]),
    ("Uncle sam", 3, ["Uncle"]),
    ("", 0, []),
    ("", 5, []),
    ("a", 0, ["a"]),
    ("a", 1, []),
    ("b", 1, ["b"]),
    ("b", 0, []),
    ("aeiou", 0, ["aeiou"]),
    ("AEIOU", 0, ["AEIOU"]),
    ("bcdfg", 5, ["bcdfg"]),
    ("bcdfg", 3, []),
    ("aaa eee iii ooo uuu", 0, ["aaa", "eee", "iii", "ooo", "uuu"]),
    ("bbb ccc ddd", 3, ["bbb", "ccc", "ddd"]),
    ("ab cd ef", 1, ["ab", "ef"]),
    ("abc def ghi", 2, ["abc", "def", "ghi"]),
    ("a e i o u", 0, ["a", "e", "i", "o", "u"]),
    ("b c d f g", 1, ["b", "c", "d", "f", "g"]),
    ("The quick brown fox", 3, ["quick"]),
    ("The quick brown fox", 2, ["The", "fox"]),
    ("AEIOUaeiou", 0, ["AEIOUaeiou"]),
    ("BCDFGbcdfg", 10, ["BCDFGbcdfg"]),
    ("MiXeD CaSe WoRdS", 3, ["MiXeD"]),
    ("one two three four five", 2, ["two", "four", "five"]),
    ("one two three four five", 3, ["three"]),
    ("programming", 7, []),
    ("python java ruby", 3, ["ruby"]),
    ("python java ruby", 4, []),
    ("a b c d e f g h i j", 1, ["b", "c", "d", "f", "g", "h", "j"]),
    ("a b c d e f g h i j", 0, ["a", "e", "i"]),
    ("test", 3, ["test"]),
    ("test", 0, []),
    ("aardvark", 5, ["aardvark"]),
    ("rhythm", 6, ["rhythm"]),
    ("fly", 3, ["fly"]),
    ("sky", 3, ["sky"]),
    ("by my", 2, ["by", "my"]),
    ("A E I O U", 0, ["A", "E", "I", "O", "U"]),
    ("B C D F G", 1, ["B", "C", "D", "F", "G"]),
])
def test_select_words_parametrized(s, n, expected):
    assert select_words(s, n) == expected


def test_empty_string():
    assert select_words("", 0) == []
    assert select_words("", 1) == []
    assert select_words("", 10) == []


def test_single_vowel():
    assert select_words("a", 0) == ["a"]
    assert select_words("e", 0) == ["e"]
    assert select_words("i", 0) == ["i"]
    assert select_words("o", 0) == ["o"]
    assert select_words("u", 0) == ["u"]


def test_single_consonant():
    assert select_words("b", 1) == ["b"]
    assert select_words("z", 1) == ["z"]


def test_all_vowels():
    assert select_words("aeiou AEIOU", 0) == ["aeiou", "AEIOU"]


def test_all_consonants():
    assert select_words("bcdfg", 5) == ["bcdfg"]
    assert select_words("xyz", 3) == ["xyz"]


def test_mixed_case():
    assert select_words("HeLLo WoRLd", 4) == ["WoRLd"]


def test_multiple_spaces():
    assert select_words("hello  world", 3) == ["hello"]


def test_no_matches():
    assert select_words("aaa eee iii", 5) == []


def test_all_matches():
    assert select_words("ab cd ef", 1) == ["ab", "ef"]


def test_large_n():
    assert select_words("hello world", 100) == []


def test_zero_consonants():
    assert select_words("a e i o u", 0) == ["a", "e", "i", "o", "u"]