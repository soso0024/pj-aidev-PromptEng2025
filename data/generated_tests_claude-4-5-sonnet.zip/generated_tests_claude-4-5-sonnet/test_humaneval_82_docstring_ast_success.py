# Test cases for HumanEval/82
# Generated using Claude API


def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise
    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """

    l = len(string)
    if l == 0 or l == 1:
        return False
    for i in range(2, l):
        if l % i == 0:
            return False
    return True


# Generated test cases:
import pytest

def prime_length(string):
    l = len(string)
    if l == 0 or l == 1:
        return False
    for i in range(2, l):
        if l % i == 0:
            return False
    return True

@pytest.mark.parametrize("string,expected", [
    ("Hello", True),
    ("abcdcba", True),
    ("kittens", True),
    ("orange", False),
    ("", False),
    ("a", False),
    ("ab", True),
    ("abc", True),
    ("abcd", False),
    ("abcde", True),
    ("abcdef", False),
    ("abcdefg", True),
    ("abcdefgh", False),
    ("abcdefghi", False),
    ("abcdefghij", False),
    ("abcdefghijk", True),
    ("abcdefghijkl", False),
    ("abcdefghijklm", True),
    ("abcdefghijklmn", False),
    ("abcdefghijklmno", False),
    ("abcdefghijklmnop", False),
    ("abcdefghijklmnopq", True),
    ("abcdefghijklmnopqr", False),
    ("abcdefghijklmnopqrs", True),
    ("abcdefghijklmnopqrst", False),
    ("abcdefghijklmnopqrstu", False),
    ("abcdefghijklmnopqrstuv", False),
    ("abcdefghijklmnopqrstuvw", True),
    ("abcdefghijklmnopqrstuvwx", False),
    ("abcdefghijklmnopqrstuvwxy", False),
    ("abcdefghijklmnopqrstuvwxyz", False),
    ("x" * 2, True),
    ("x" * 3, True),
    ("x" * 4, False),
    ("x" * 5, True),
    ("x" * 6, False),
    ("x" * 7, True),
    ("x" * 8, False),
    ("x" * 9, False),
    ("x" * 10, False),
    ("x" * 11, True),
    ("x" * 13, True),
    ("x" * 17, True),
    ("x" * 19, True),
    ("x" * 23, True),
    ("x" * 29, True),
    ("x" * 31, True),
    ("x" * 12, False),
    ("x" * 15, False),
    ("x" * 20, False),
    ("x" * 25, False),
    ("x" * 30, False),
])
def test_prime_length_parametrized(string, expected):
    assert prime_length(string) == expected

def test_prime_length_empty_string():
    assert prime_length("") == False

def test_prime_length_single_char():
    assert prime_length("a") == False

def test_prime_length_two_chars():
    assert prime_length("ab") == True

def test_prime_length_three_chars():
    assert prime_length("abc") == True

def test_prime_length_four_chars():
    assert prime_length("abcd") == False

def test_prime_length_five_chars():
    assert prime_length("Hello") == True

def test_prime_length_seven_chars():
    assert prime_length("abcdcba") == True
    assert prime_length("kittens") == True

def test_prime_length_six_chars():
    assert prime_length("orange") == False

def test_prime_length_special_chars():
    assert prime_length("!!") == True
    assert prime_length("!!!") == True
    assert prime_length("!!!!") == False

def test_prime_length_spaces():
    assert prime_length("  ") == True
    assert prime_length("   ") == True
    assert prime_length("    ") == False

def test_prime_length_mixed():
    assert prime_length("a b") == True
    assert prime_length("a b c") == True
    assert prime_length("a b c d") == True