# Test cases for HumanEval/85
# Generated using Claude API


def add(lst):
    """Given a non-empty list of integers lst. add the even elements that are at odd indices..


    Examples:
        add([4, 2, 6, 7]) ==> 2 
    """

    return sum([lst[i] for i in range(1, len(lst), 2) if lst[i]%2 == 0])


# Generated test cases:
import pytest

def add(lst):
    return sum([lst[i] for i in range(1, len(lst), 2) if lst[i]%2 == 0])

def test_add_example():
    assert add([4, 2, 6, 7]) == 2

def test_add_single_element():
    assert add([5]) == 0

def test_add_two_elements_even_at_odd_index():
    assert add([1, 2]) == 2

def test_add_two_elements_odd_at_odd_index():
    assert add([1, 3]) == 0

def test_add_all_even_at_odd_indices():
    assert add([1, 2, 3, 4, 5, 6]) == 12

def test_add_all_odd_at_odd_indices():
    assert add([1, 1, 2, 3, 4, 5]) == 0

def test_add_mixed_values():
    assert add([1, 2, 3, 4, 5, 6, 7, 8]) == 20

def test_add_no_odd_indices():
    assert add([10]) == 0

def test_add_large_even_numbers():
    assert add([1, 100, 2, 200, 3, 300]) == 600

def test_add_negative_even_at_odd_indices():
    assert add([1, -2, 3, -4, 5, -6]) == -12

def test_add_negative_odd_at_odd_indices():
    assert add([1, -1, 2, -3, 3, -5]) == 0

def test_add_mixed_negative_positive():
    assert add([0, 2, 1, -4, 2, 6, 3, 8]) == 12

def test_add_zeros():
    assert add([0, 0, 0, 0]) == 0

def test_add_even_at_even_indices_only():
    assert add([2, 1, 4, 3, 6, 5]) == 0

def test_add_long_list():
    assert add([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]) == 42

def test_add_alternating_even_odd():
    assert add([1, 2, 1, 4, 1, 6, 1, 8]) == 20

@pytest.mark.parametrize("input_list,expected", [
    ([4, 2, 6, 7], 2),
    ([1, 2], 2),
    ([1, 3], 0),
    ([5], 0),
    ([1, 2, 3, 4, 5, 6], 12),
    ([0, 0, 0, 0], 0),
    ([1, -2, 3, -4], -6),
    ([10, 20, 30, 40], 60),
])
def test_add_parametrized(input_list, expected):
    assert add(input_list) == expected