# Test cases for HumanEval/93
# Generated using Claude API


def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """

    vowels = "aeiouAEIOU"
    vowels_replace = dict([(i, chr(ord(i) + 2)) for i in vowels])
    message = message.swapcase()
    return ''.join([vowels_replace[i] if i in vowels else i for i in message])


# Generated test cases:
import pytest

def encode(message):
    vowels = "aeiouAEIOU"
    vowels_replace = dict([(i, chr(ord(i) + 2)) for i in vowels])
    message = message.swapcase()
    return ''.join([vowels_replace[i] if i in vowels else i for i in message])


@pytest.mark.parametrize("message,expected", [
    ("test", "TGST"),
    ("This is a message", "tHKS KS C MGSSCGG"),
    ("", ""),
    ("a", "C"),
    ("A", "c"),
    ("e", "G"),
    ("E", "g"),
    ("i", "K"),
    ("I", "k"),
    ("o", "Q"),
    ("O", "q"),
    ("u", "W"),
    ("U", "w"),
    ("aeiou", "CGKQW"),
    ("AEIOU", "cgkqw"),
    ("bcdfg", "BCDFG"),
    ("BCDFG", "bcdfg"),
    ("Hello World", "hGLLQ wQRLD"),
    ("Python", "pYTHQN"),
    ("aEiOu", "CgKqW"),
    ("123", "123"),
    ("!@#$%", "!@#$%"),
    ("abc123XYZ", "CBC123xyz"),
    ("The quick brown fox", "tHG QWKCK BRQWN FQX"),
    ("aaa", "CCC"),
    ("AAA", "ccc"),
    ("   ", "   "),
    ("a b c", "C B C"),
    ("MixedCASE", "mKXGDccsg"),
    ("!a!e!i!o!u!", "!C!G!K!Q!W!"),
    ("1a2e3i4o5u6", "1C2G3K4Q5W6"),
    ("aeioubcdfgAEIOU", "CGKQWBCDFGcgkqw"),
])
def test_encode_parametrized(message, expected):
    assert encode(message) == expected


def test_encode_empty_string():
    assert encode("") == ""


def test_encode_only_vowels():
    assert encode("aeiouAEIOU") == "CGKQWcgkqw"


def test_encode_only_consonants():
    assert encode("bcdfghjklmnpqrstvwxyz") == "BCDFGHJKLMNPQRSTVWXYZ"


def test_encode_only_uppercase_consonants():
    assert encode("BCDFGHJKLMNPQRSTVWXYZ") == "bcdfghjklmnpqrstvwxyz"


def test_encode_numbers_only():
    assert encode("1234567890") == "1234567890"


def test_encode_special_characters():
    assert encode("!@#$%^&*()_+-=[]{}|;:',.<>?/") == "!@#$%^&*()_+-=[]{}|;:',.<>?/"


def test_encode_mixed_content():
    assert encode("Hello123World!") == "hGLLQ123wQRLD!"


def test_encode_single_lowercase_vowel():
    for vowel, expected in [('a', 'C'), ('e', 'G'), ('i', 'K'), ('o', 'Q'), ('u', 'W')]:
        assert encode(vowel) == expected


def test_encode_single_uppercase_vowel():
    for vowel, expected in [('A', 'c'), ('E', 'g'), ('I', 'k'), ('O', 'q'), ('U', 'w')]:
        assert encode(vowel) == expected


def test_encode_spaces():
    assert encode("a b c d e") == "C B C D G"


def test_encode_newlines_and_tabs():
    assert encode("a\nb\tc") == "C\nB\tC"


def test_encode_repeated_characters():
    assert encode("aaaa") == "CCCC"
    assert encode("EEEE") == "gggg"