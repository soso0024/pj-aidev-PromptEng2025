# Test cases for HumanEval/141
# Generated using Claude API


def file_name_check(file_name):
    """Create a function which takes a string representing a file's name, and returns
    'Yes' if the the file's name is valid, and returns 'No' otherwise.
    A file's name is considered to be valid if and only if all the following conditions 
    are met:
    - There should not be more than three digits ('0'-'9') in the file's name.
    - The file's name contains exactly one dot '.'
    - The substring before the dot should not be empty, and it starts with a letter from 
    the latin alphapet ('a'-'z' and 'A'-'Z').
    - The substring after the dot should be one of these: ['txt', 'exe', 'dll']
    Examples:
    file_name_check("example.txt") # => 'Yes'
    file_name_check("1example.dll") # => 'No' (the name should start with a latin alphapet letter)
    """

    suf = ['txt', 'exe', 'dll']
    lst = file_name.split(sep='.')
    if len(lst) != 2:
        return 'No'
    if not lst[1] in suf:
        return 'No'
    if len(lst[0]) == 0:
        return 'No'
    if not lst[0][0].isalpha():
        return 'No'
    t = len([x for x in lst[0] if x.isdigit()])
    if t > 3:
        return 'No'
    return 'Yes'


# Generated test cases:
import pytest


def file_name_check(file_name):
    suf = ['txt', 'exe', 'dll']
    lst = file_name.split(sep='.')
    if len(lst) != 2:
        return 'No'
    if not lst[1] in suf:
        return 'No'
    if len(lst[0]) == 0:
        return 'No'
    if not lst[0][0].isalpha():
        return 'No'
    t = len([x for x in lst[0] if x.isdigit()])
    if t > 3:
        return 'No'
    return 'Yes'


@pytest.mark.parametrize("file_name,expected", [
    ("example.txt", "Yes"),
    ("test.exe", "Yes"),
    ("program.dll", "Yes"),
    ("file1.txt", "Yes"),
    ("file12.txt", "Yes"),
    ("file123.txt", "Yes"),
    ("a.txt", "Yes"),
    ("A.txt", "Yes"),
    ("Z9.exe", "Yes"),
    ("file1234.txt", "No"),
    ("1file.txt", "No"),
    ("9test.exe", "No"),
    (".txt", "No"),
    ("file.doc", "No"),
    ("file.pdf", "No"),
    ("file.jpg", "No"),
    ("file", "No"),
    ("file.txt.exe", "No"),
    ("file..txt", "No"),
    ("file.txt.", "No"),
    (".file.txt", "No"),
    ("", "No"),
    ("file.", "No"),
    (".exe", "No"),
    ("123.txt", "No"),
    ("_file.txt", "No"),
    ("-file.txt", "No"),
    ("file@.txt", "Yes"),
    ("file_.txt", "Yes"),
    ("file-.txt", "Yes"),
    ("a1b2c3.txt", "Yes"),
    ("a1b2c3d4.txt", "No"),
    ("test0000.txt", "No"),
    ("t1e2s3t.exe", "Yes"),
    ("t1e2s3t4.exe", "No"),
    ("MyFile.dll", "Yes"),
    ("MyFile123.dll", "Yes"),
    ("MyFile1234.dll", "No"),
])
def test_file_name_check_parametrized(file_name, expected):
    assert file_name_check(file_name) == expected


def test_valid_txt_file():
    assert file_name_check("document.txt") == "Yes"


def test_valid_exe_file():
    assert file_name_check("application.exe") == "Yes"


def test_valid_dll_file():
    assert file_name_check("library.dll") == "Yes"


def test_file_with_one_digit():
    assert file_name_check("file1.txt") == "Yes"


def test_file_with_two_digits():
    assert file_name_check("file12.txt") == "Yes"


def test_file_with_three_digits():
    assert file_name_check("file123.txt") == "Yes"


def test_file_with_four_digits():
    assert file_name_check("file1234.txt") == "No"


def test_file_starting_with_digit():
    assert file_name_check("1file.txt") == "No"


def test_empty_filename():
    assert file_name_check(".txt") == "No"


def test_invalid_extension():
    assert file_name_check("file.doc") == "No"


def test_no_extension():
    assert file_name_check("file") == "No"


def test_multiple_dots():
    assert file_name_check("file.name.txt") == "No"


def test_empty_string():
    assert file_name_check("") == "No"


def test_single_character_name():
    assert file_name_check("a.txt") == "Yes"


def test_uppercase_name():
    assert file_name_check("FILE.txt") == "Yes"


def test_mixed_case_name():
    assert file_name_check("MyFile.exe") == "Yes"


def test_special_characters_in_name():
    assert file_name_check("file@name.txt") == "Yes"


def test_underscore_at_start():
    assert file_name_check("_file.txt") == "No"


def test_digits_scattered():
    assert file_name_check("a1b2c3.txt") == "Yes"


def test_digits_scattered_more_than_three():
    assert file_name_check("a1b2c3d4.txt") == "No"


def test_only_extension():
    assert file_name_check(".exe") == "No"


def test_trailing_dot():
    assert file_name_check("file.txt.") == "No"
