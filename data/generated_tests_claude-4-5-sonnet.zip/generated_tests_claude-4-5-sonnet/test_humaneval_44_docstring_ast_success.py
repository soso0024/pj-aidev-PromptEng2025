# Test cases for HumanEval/44
# Generated using Claude API



def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """

    ret = ""
    while x > 0:
        ret = str(x % base) + ret
        x //= base
    return ret


# Generated test cases:
import pytest

def change_base(x: int, base: int):
    ret = ""
    while x > 0:
        ret = str(x % base) + ret
        x //= base
    return ret

def test_change_base_8_to_base_3():
    assert change_base(8, 3) == '22'

def test_change_base_8_to_base_2():
    assert change_base(8, 2) == '1000'

def test_change_base_7_to_base_2():
    assert change_base(7, 2) == '111'

def test_change_base_0():
    assert change_base(0, 2) == ''

def test_change_base_1_to_base_2():
    assert change_base(1, 2) == '1'

def test_change_base_1_to_base_10():
    assert change_base(1, 10) == '1'

def test_change_base_10_to_base_10():
    assert change_base(10, 10) == '10'

def test_change_base_15_to_base_2():
    assert change_base(15, 2) == '1111'

def test_change_base_255_to_base_2():
    assert change_base(255, 2) == '11111111'

def test_change_base_100_to_base_3():
    assert change_base(100, 3) == '10201'

def test_change_base_64_to_base_8():
    assert change_base(64, 8) == '100'

def test_change_base_81_to_base_9():
    assert change_base(81, 9) == '100'

def test_change_base_large_number():
    assert change_base(1000, 2) == '1111101000'

def test_change_base_to_base_9():
    assert change_base(100, 9) == '121'

def test_change_base_small_to_large_base():
    assert change_base(5, 7) == '5'

def test_change_base_equal_to_base():
    assert change_base(5, 5) == '10'

@pytest.mark.parametrize("x,base,expected", [
    (8, 3, '22'),
    (8, 2, '1000'),
    (7, 2, '111'),
    (10, 2, '1010'),
    (16, 2, '10000'),
    (27, 3, '1000'),
    (50, 5, '200'),
    (100, 4, '1210'),
    (1, 2, '1'),
    (2, 2, '10'),
    (3, 2, '11'),
    (4, 2, '100'),
    (5, 2, '101'),
    (6, 2, '110'),
])
def test_change_base_parametrized(x, base, expected):
    assert change_base(x, base) == expected
