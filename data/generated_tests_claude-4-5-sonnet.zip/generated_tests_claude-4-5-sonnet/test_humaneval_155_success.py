# Test cases for HumanEval/155
# Generated using Claude API


def even_odd_count(num):
    """Given an integer. return a tuple that has the number of even and odd digits respectively.

     Example:
        even_odd_count(-12) ==> (1, 1)
        even_odd_count(123) ==> (1, 2)
    """

    even_count = 0
    odd_count = 0
    for i in str(abs(num)):
        if int(i)%2==0:
            even_count +=1
        else:
            odd_count +=1
    return (even_count, odd_count)


# Generated test cases:
import pytest

def even_odd_count(num):
    even_count = 0
    odd_count = 0
    for i in str(abs(num)):
        if int(i)%2==0:
            even_count +=1
        else:
            odd_count +=1
    return (even_count, odd_count)

@pytest.mark.parametrize("num,expected", [
    (0, (1, 0)),
    (1, (0, 1)),
    (2, (1, 0)),
    (12, (1, 1)),
    (123, (1, 2)),
    (1234, (2, 2)),
    (12345, (2, 3)),
    (246, (3, 0)),
    (135, (0, 3)),
    (2468, (4, 0)),
    (13579, (0, 5)),
    (-1, (0, 1)),
    (-2, (1, 0)),
    (-12, (1, 1)),
    (-123, (1, 2)),
    (-1234, (2, 2)),
    (-246, (3, 0)),
    (-135, (0, 3)),
    (100, (2, 1)),
    (1000, (3, 1)),
    (1001, (2, 2)),
    (9999, (0, 4)),
    (8888, (4, 0)),
    (-100, (2, 1)),
    (-1000, (3, 1)),
    (987654321, (4, 5)),
    (-987654321, (4, 5)),
    (1357924680, (5, 5)),
    (20, (2, 0)),
    (31, (0, 2)),
    (42, (2, 0)),
    (53, (0, 2)),
    (64, (2, 0)),
    (75, (0, 2)),
    (86, (2, 0)),
    (97, (0, 2)),
])
def test_even_odd_count_parametrized(num, expected):
    assert even_odd_count(num) == expected

def test_even_odd_count_zero():
    assert even_odd_count(0) == (1, 0)

def test_even_odd_count_single_even():
    assert even_odd_count(2) == (1, 0)
    assert even_odd_count(4) == (1, 0)
    assert even_odd_count(6) == (1, 0)
    assert even_odd_count(8) == (1, 0)

def test_even_odd_count_single_odd():
    assert even_odd_count(1) == (0, 1)
    assert even_odd_count(3) == (0, 1)
    assert even_odd_count(5) == (0, 1)
    assert even_odd_count(7) == (0, 1)
    assert even_odd_count(9) == (0, 1)

def test_even_odd_count_negative_numbers():
    assert even_odd_count(-1) == (0, 1)
    assert even_odd_count(-2) == (1, 0)
    assert even_odd_count(-123) == (1, 2)
    assert even_odd_count(-2468) == (4, 0)
    assert even_odd_count(-13579) == (0, 5)

def test_even_odd_count_mixed():
    assert even_odd_count(12) == (1, 1)
    assert even_odd_count(123) == (1, 2)
    assert even_odd_count(1234) == (2, 2)
    assert even_odd_count(12345) == (2, 3)

def test_even_odd_count_all_even():
    assert even_odd_count(2468) == (4, 0)
    assert even_odd_count(2020) == (4, 0)
    assert even_odd_count(8642) == (4, 0)

def test_even_odd_count_all_odd():
    assert even_odd_count(13579) == (0, 5)
    assert even_odd_count(1357) == (0, 4)
    assert even_odd_count(975) == (0, 3)

def test_even_odd_count_large_numbers():
    assert even_odd_count(123456789) == (4, 5)
    assert even_odd_count(987654321) == (4, 5)
    assert even_odd_count(1111111111) == (0, 10)
    assert even_odd_count(2222222222) == (10, 0)

def test_even_odd_count_return_type():
    result = even_odd_count(123)
    assert isinstance(result, tuple)
    assert len(result) == 2
    assert isinstance(result[0], int)
    assert isinstance(result[1], int)