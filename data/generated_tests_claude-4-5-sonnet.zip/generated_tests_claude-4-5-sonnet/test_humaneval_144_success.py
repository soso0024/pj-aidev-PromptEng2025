# Test cases for HumanEval/144
# Generated using Claude API


def simplify(x, n):
    """Your task is to implement a function that will simplify the expression
    x * n. The function returns True if x * n evaluates to a whole number and False
    otherwise. Both x and n, are string representation of a fraction, and have the following format,
    <numerator>/<denominator> where both numerator and denominator are positive whole numbers.

    You can assume that x, and n are valid fractions, and do not have zero as denominator.

    simplify("1/5", "5/1") = True
    simplify("1/6", "2/1") = False
    simplify("7/10", "10/2") = False
    """

    a, b = x.split("/")
    c, d = n.split("/")
    numerator = int(a) * int(c)
    denom = int(b) * int(d)
    if (numerator/denom == int(numerator/denom)):
        return True
    return False


# Generated test cases:
import pytest


def simplify(x, n):
    a, b = x.split("/")
    c, d = n.split("/")
    numerator = int(a) * int(c)
    denom = int(b) * int(d)
    if (numerator/denom == int(numerator/denom)):
        return True
    return False


def test_simplify_basic_true():
    assert simplify("1/5", "5/1") == True


def test_simplify_basic_false():
    assert simplify("1/6", "2/1") == False


def test_simplify_equal_fractions():
    assert simplify("2/4", "4/2") == True


def test_simplify_result_is_one():
    assert simplify("3/7", "7/3") == True


def test_simplify_result_is_integer():
    assert simplify("4/2", "3/2") == True


def test_simplify_result_not_integer():
    assert simplify("1/3", "1/2") == False


def test_simplify_large_numerators():
    assert simplify("100/50", "50/100") == True


def test_simplify_zero_numerator():
    assert simplify("0/5", "3/7") == True


def test_simplify_one_numerator():
    assert simplify("1/1", "1/1") == True


def test_simplify_result_two():
    assert simplify("2/1", "1/1") == True


def test_simplify_result_three():
    assert simplify("3/1", "1/1") == True


def test_simplify_complex_fraction():
    assert simplify("7/10", "10/2") == False


def test_simplify_another_complex():
    assert simplify("2/10", "50/10") == True


def test_simplify_small_fractions():
    assert simplify("1/2", "1/2") == False


def test_simplify_negative_numerator():
    assert simplify("-1/2", "2/1") == True


def test_simplify_negative_denominator():
    assert simplify("1/-2", "2/1") == True


def test_simplify_both_negative():
    assert simplify("-1/-2", "2/1") == True


def test_simplify_large_numbers():
    assert simplify("1000/500", "500/1000") == True


def test_simplify_prime_numbers():
    assert simplify("7/11", "11/7") == True


@pytest.mark.parametrize("x,n,expected", [
    ("1/5", "5/1", True),
    ("1/6", "2/1", False),
    ("7/10", "10/2", False),
    ("2/10", "50/10", True),
    ("4/1", "1/2", True),
    ("3/2", "2/3", True),
    ("1/4", "1/4", False),
    ("10/1", "1/10", True),
    ("5/2", "2/5", True),
    ("8/4", "4/8", True),
])
def test_simplify_parametrized(x, n, expected):
    assert simplify(x, n) == expected
