# Test cases for HumanEval/25
# Generated using Claude API

from typing import List


def factorize(n: int) -> List[int]:
    """ Return list of prime factors of given integer in the order from smallest to largest.
    Each of the factors should be listed number of times corresponding to how many times it appeares in factorization.
    Input number should be equal to the product of all factors
    >>> factorize(8)
    [2, 2, 2]
    >>> factorize(25)
    [5, 5]
    >>> factorize(70)
    [2, 5, 7]
    """

    import math
    fact = []
    i = 2
    while i <= int(math.sqrt(n) + 1):
        if n % i == 0:
            fact.append(i)
            n //= i
        else:
            i += 1

    if n > 1:
        fact.append(n)
    return fact


# Generated test cases:
import pytest
from typing import List
import math


def factorize(n: int) -> List[int]:
    fact = []
    i = 2
    while i <= int(math.sqrt(n) + 1):
        if n % i == 0:
            fact.append(i)
            n //= i
        else:
            i += 1

    if n > 1:
        fact.append(n)
    return fact


@pytest.mark.parametrize("n,expected", [
    (2, [2]),
    (3, [3]),
    (4, [2, 2]),
    (5, [5]),
    (6, [2, 3]),
    (8, [2, 2, 2]),
    (9, [3, 3]),
    (10, [2, 5]),
    (12, [2, 2, 3]),
    (15, [3, 5]),
    (16, [2, 2, 2, 2]),
    (20, [2, 2, 5]),
    (24, [2, 2, 2, 3]),
    (25, [5, 5]),
    (30, [2, 3, 5]),
    (32, [2, 2, 2, 2, 2]),
    (36, [2, 2, 3, 3]),
    (48, [2, 2, 2, 2, 3]),
    (49, [7, 7]),
    (50, [2, 5, 5]),
    (60, [2, 2, 3, 5]),
    (64, [2, 2, 2, 2, 2, 2]),
    (100, [2, 2, 5, 5]),
    (128, [2, 2, 2, 2, 2, 2, 2]),
    (144, [2, 2, 2, 2, 3, 3]),
    (256, [2, 2, 2, 2, 2, 2, 2, 2]),
    (1000, [2, 2, 2, 5, 5, 5]),
    (97, [97]),
    (101, [101]),
    (103, [103]),
    (107, [107]),
    (109, [109]),
    (113, [113]),
    (127, [127]),
    (131, [131]),
    (137, [137]),
    (139, [139]),
    (149, [149]),
    (151, [151]),
    (157, [157]),
    (163, [163]),
    (167, [167]),
    (173, [173]),
    (179, [179]),
    (181, [181]),
    (191, [191]),
    (193, [193]),
    (197, [197]),
    (199, [199]),
    (211, [211]),
    (223, [223]),
    (227, [227]),
    (229, [229]),
    (233, [233]),
    (239, [239]),
    (241, [241]),
    (251, [251]),
])
def test_factorize_parametrized(n, expected):
    assert factorize(n) == expected


def test_factorize_small_primes():
    assert factorize(2) == [2]
    assert factorize(3) == [3]
    assert factorize(5) == [5]
    assert factorize(7) == [7]
    assert factorize(11) == [11]
    assert factorize(13) == [13]


def test_factorize_powers_of_two():
    assert factorize(2) == [2]
    assert factorize(4) == [2, 2]
    assert factorize(8) == [2, 2, 2]
    assert factorize(16) == [2, 2, 2, 2]
    assert factorize(32) == [2, 2, 2, 2, 2]
    assert factorize(64) == [2, 2, 2, 2, 2, 2]


def test_factorize_composite_numbers():
    assert factorize(6) == [2, 3]
    assert factorize(12) == [2, 2, 3]
    assert factorize(18) == [2, 3, 3]
    assert factorize(30) == [2, 3, 5]
    assert factorize(42) == [2, 3, 7]
    assert factorize(60) == [2, 2, 3, 5]


def test_factorize_perfect_squares():
    assert factorize(4) == [2, 2]
    assert factorize(9) == [3, 3]
    assert factorize(25) == [5, 5]
    assert factorize(49) == [7, 7]
    assert factorize(121) == [11, 11]


def test_factorize_large_primes():
    assert factorize(997) == [997]
    assert factorize(1009) == [1009]
    assert factorize(1013) == [1013]


def test_factorize_large_composites():
    assert factorize(1000) == [2, 2, 2, 5, 5, 5]
    assert factorize(9999) == [3, 3, 11, 101]
    assert factorize(10000) == [2, 2, 2, 2, 5, 5, 5, 5]


def test_factorize_product_verification():
    for n in [2, 6, 12, 30, 100, 256, 1000]:
        factors = factorize(n)
        product = 1
        for f in factors:
            product *= f
        assert product == n


def test_factorize_all_factors_are_prime():
    def is_prime(num):
        if num < 2:
            return False
        for i in range(2, int(math.sqrt(num)) + 1):
            if num % i == 0:
                return False
        return True
    
    for n in [6, 12, 30, 100, 256, 1000]:
        factors = factorize(n)
        for factor in factors:
            assert is_prime(factor)
