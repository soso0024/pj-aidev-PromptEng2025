# Test cases for HumanEval/56
# Generated using Claude API



def correct_bracketing(brackets: str):
    """ brackets is a string of "<" and ">".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """

    depth = 0
    for b in brackets:
        if b == "<":
            depth += 1
        else:
            depth -= 1
        if depth < 0:
            return False
    return depth == 0


# Generated test cases:
import pytest

def correct_bracketing(brackets: str):
    depth = 0
    for b in brackets:
        if b == "<":
            depth += 1
        else:
            depth -= 1
        if depth < 0:
            return False
    return depth == 0


@pytest.mark.parametrize("brackets,expected", [
    ("", True),
    ("<>", True),
    ("<<>>", True),
    ("<><>", True),
    ("<<><>>", True),
    ("<<<<>>>>", True),
    ("<<><<>>>", True),
    ("<", False),
    (">", False),
    ("<>><", False),
    ("<<>", False),
    ("<>>", False),
    ("><<>", False),
    (">>>", False),
    ("<<<", False),
    ("><", False),
    ("<<>>><", False),
    ("<><><>", True),
    ("<<>><<>>", True),
    ("<<<<", False),
    (">>>>", False),
    ("<<><><>>", True),
    ("<><><><>", True),
    ("<<<<<>>>>>", True),
    (">>>>><<<<<", False),
    ("<<>><>", True),
    ("<><<>>", True),
    ("<<>><", False),
    (">", False),
    (">>>>>>", False),
    ("<<<<<<", False),
    ("<><><><><>", True),
    ("<<>><<>><<>>", True),
])
def test_correct_bracketing(brackets, expected):
    assert correct_bracketing(brackets) == expected


def test_empty_string():
    assert correct_bracketing("") == True


def test_single_open():
    assert correct_bracketing("<") == False


def test_single_close():
    assert correct_bracketing(">") == False


def test_simple_pair():
    assert correct_bracketing("<>") == True


def test_nested():
    assert correct_bracketing("<<>>") == True


def test_multiple_pairs():
    assert correct_bracketing("<><>") == True


def test_close_before_open():
    assert correct_bracketing("><") == False


def test_unbalanced_more_open():
    assert correct_bracketing("<<>") == False


def test_unbalanced_more_close():
    assert correct_bracketing("<>>") == False


def test_complex_valid():
    assert correct_bracketing("<<><>>") == True


def test_complex_invalid():
    assert correct_bracketing("<<>><>") == True


def test_deeply_nested():
    assert correct_bracketing("<<<<<<>>>>>>") == True


def test_deeply_nested_invalid():
    assert correct_bracketing("<<<<<<>>>>>>>") == False