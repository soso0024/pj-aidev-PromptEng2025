# Test cases for HumanEval/136
# Generated using Claude API


def largest_smallest_integers(lst):
    '''
    Create a function that returns a tuple (a, b), where 'a' is
    the largest of negative integers, and 'b' is the smallest
    of positive integers in a list.
    If there is no negative or positive integers, return them as None.

    Examples:
    largest_smallest_integers([2, 4, 1, 3, 5, 7]) == (None, 1)
    largest_smallest_integers([]) == (None, None)
    largest_smallest_integers([0]) == (None, None)
    '''

    smallest = list(filter(lambda x: x < 0, lst))
    largest = list(filter(lambda x: x > 0, lst))
    return (max(smallest) if smallest else None, min(largest) if largest else None)


# Generated test cases:
import pytest

def largest_smallest_integers(lst):
    smallest = list(filter(lambda x: x < 0, lst))
    largest = list(filter(lambda x: x > 0, lst))
    return (max(smallest) if smallest else None, min(largest) if largest else None)

@pytest.mark.parametrize("lst,expected", [
    ([2, 4, 1, 3, 5, 7], (None, 1)),
    ([], (None, None)),
    ([0], (None, None)),
    ([-1, -2, -3, -4], (-1, None)),
    ([1, 2, 3, 4], (None, 1)),
    ([-5, -3, -1, 1, 3, 5], (-1, 1)),
    ([-10, -20, 10, 20], (-10, 10)),
    ([0, 0, 0], (None, None)),
    ([-1], (-1, None)),
    ([1], (None, 1)),
    ([-100, -50, -25, 25, 50, 100], (-25, 25)),
    ([5, 3, 1, -1, -3, -5], (-1, 1)),
    ([-1, 0, 1], (-1, 1)),
    ([0, -1, 1], (-1, 1)),
    ([-5, -10, -15], (-5, None)),
    ([15, 10, 5], (None, 5)),
    ([-1, -1, -1], (-1, None)),
    ([1, 1, 1], (None, 1)),
    ([-100, 100], (-100, 100)),
    ([100, -100], (-100, 100)),
    ([-2, -1, 0, 1, 2], (-1, 1)),
    ([0, 0, -1, 1], (-1, 1)),
])
def test_largest_smallest_integers(lst, expected):
    assert largest_smallest_integers(lst) == expected

def test_empty_list():
    assert largest_smallest_integers([]) == (None, None)

def test_only_zeros():
    assert largest_smallest_integers([0, 0, 0, 0]) == (None, None)

def test_only_negatives():
    result = largest_smallest_integers([-5, -10, -3, -7])
    assert result == (-3, None)

def test_only_positives():
    result = largest_smallest_integers([5, 10, 3, 7])
    assert result == (None, 3)

def test_mixed_with_zero():
    result = largest_smallest_integers([-5, 0, 5])
    assert result == (-5, 5)

def test_single_negative():
    assert largest_smallest_integers([-42]) == (-42, None)

def test_single_positive():
    assert largest_smallest_integers([42]) == (None, 42)

def test_single_zero():
    assert largest_smallest_integers([0]) == (None, None)

def test_large_numbers():
    result = largest_smallest_integers([-1000000, 1000000])
    assert result == (-1000000, 1000000)

def test_duplicates():
    result = largest_smallest_integers([-5, -5, 5, 5])
    assert result == (-5, 5)
