# Test cases for HumanEval/102
# Generated using Claude API


def choose_num(x, y):
    """This function takes two positive numbers x and y and returns the
    biggest even integer number that is in the range [x, y] inclusive. If 
    there's no such number, then the function should return -1.

    For example:
    choose_num(12, 15) = 14
    choose_num(13, 12) = -1
    """

    if x > y:
        return -1
    if y % 2 == 0:
        return y
    if x == y:
        return -1
    return y - 1


# Generated test cases:
import pytest

def choose_num(x, y):
    if x > y:
        return -1
    if y % 2 == 0:
        return y
    if x == y:
        return -1
    return y - 1


@pytest.mark.parametrize("x,y,expected", [
    (1, 1, -1),
    (2, 2, 2),
    (3, 3, -1),
    (1, 2, 2),
    (2, 3, 2),
    (1, 3, 2),
    (1, 4, 4),
    (2, 4, 4),
    (3, 4, 4),
    (1, 5, 4),
    (2, 5, 4),
    (3, 5, 4),
    (4, 5, 4),
    (5, 1, -1),
    (10, 5, -1),
    (100, 50, -1),
    (0, 0, 0),
    (0, 1, 0),
    (0, 2, 2),
    (0, 3, 2),
    (1, 10, 10),
    (1, 11, 10),
    (5, 10, 10),
    (5, 11, 10),
    (6, 11, 10),
    (10, 10, 10),
    (11, 11, -1),
    (10, 11, 10),
    (1, 100, 100),
    (1, 101, 100),
    (50, 100, 100),
    (50, 101, 100),
    (99, 100, 100),
    (99, 101, 100),
    (100, 101, 100),
    (101, 101, -1),
    (2, 1, -1),
    (3, 2, -1),
    (4, 3, -1),
    (5, 4, -1),
    (6, 5, -1),
    (7, 6, -1),
    (8, 7, -1),
    (9, 8, -1),
    (10, 9, -1),
    (-5, -3, -4),
    (-5, -2, -2),
    (-5, -1, -2),
    (-5, 0, 0),
    (-5, 1, 0),
    (-5, 2, 2),
    (-4, -4, -4),
    (-3, -3, -1),
    (-2, -2, -2),
    (-1, -1, -1),
    (-10, -5, -6),
    (-10, -4, -4),
    (-10, 10, 10),
    (-10, 11, 10),
    (0, 10, 10),
    (0, 11, 10),
])
def test_choose_num(x, y, expected):
    assert choose_num(x, y) == expected


def test_choose_num_x_greater_than_y():
    assert choose_num(10, 5) == -1
    assert choose_num(100, 50) == -1
    assert choose_num(2, 1) == -1


def test_choose_num_y_even():
    assert choose_num(1, 2) == 2
    assert choose_num(1, 4) == 4
    assert choose_num(1, 100) == 100
    assert choose_num(2, 2) == 2


def test_choose_num_y_odd_x_equals_y():
    assert choose_num(1, 1) == -1
    assert choose_num(3, 3) == -1
    assert choose_num(5, 5) == -1
    assert choose_num(99, 99) == -1


def test_choose_num_y_odd_x_less_than_y():
    assert choose_num(1, 3) == 2
    assert choose_num(1, 5) == 4
    assert choose_num(2, 5) == 4
    assert choose_num(1, 11) == 10


def test_choose_num_edge_cases():
    assert choose_num(0, 0) == 0
    assert choose_num(0, 1) == 0
    assert choose_num(0, 2) == 2


def test_choose_num_negative_numbers():
    assert choose_num(-5, -3) == -4
    assert choose_num(-5, -2) == -2
    assert choose_num(-10, -5) == -6
    assert choose_num(-10, 10) == 10