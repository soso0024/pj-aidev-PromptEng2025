# Test cases for HumanEval/10
# Generated using Claude API



def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """ Find the shortest palindrome that begins with a supplied string.
    Algorithm idea is simple:
    - Find the longest postfix of supplied string that is a palindrome.
    - Append to the end of the string reverse of a string prefix that comes before the palindromic suffix.
    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    """

    if not string:
        return ''

    beginning_of_suffix = 0

    while not is_palindrome(string[beginning_of_suffix:]):
        beginning_of_suffix += 1

    return string + string[:beginning_of_suffix][::-1]


# Generated test cases:
import pytest

def is_palindrome(string: str) -> bool:
    return string == string[::-1]

def make_palindrome(string: str) -> str:
    if not string:
        return ''

    beginning_of_suffix = 0

    while not is_palindrome(string[beginning_of_suffix:]):
        beginning_of_suffix += 1

    return string + string[:beginning_of_suffix][::-1]

def test_make_palindrome_empty_string():
    assert make_palindrome('') == ''

def test_make_palindrome_single_character():
    assert make_palindrome('a') == 'a'

def test_make_palindrome_already_palindrome():
    assert make_palindrome('aba') == 'aba'
    assert make_palindrome('racecar') == 'racecar'
    assert make_palindrome('noon') == 'noon'

def test_make_palindrome_cat():
    assert make_palindrome('cat') == 'catac'

def test_make_palindrome_cata():
    assert make_palindrome('cata') == 'catac'

def test_make_palindrome_two_characters():
    assert make_palindrome('ab') == 'aba'
    assert make_palindrome('xy') == 'xyx'

def test_make_palindrome_three_characters():
    assert make_palindrome('abc') == 'abcba'
    assert make_palindrome('xyz') == 'xyzyx'

def test_make_palindrome_with_suffix_palindrome():
    assert make_palindrome('abcd') == 'abcdcba'
    assert make_palindrome('abcdc') == 'abcdcba'

def test_make_palindrome_longer_strings():
    assert make_palindrome('hello') == 'hellolleh'
    assert make_palindrome('world') == 'worldlrow'

def test_make_palindrome_numeric_strings():
    assert make_palindrome('123') == '12321'
    assert make_palindrome('1234') == '1234321'

def test_make_palindrome_special_characters():
    assert make_palindrome('a!b') == 'a!b!a'
    assert make_palindrome('x@y') == 'x@y@x'

def test_make_palindrome_spaces():
    assert make_palindrome('a b') == 'a b a'
    assert make_palindrome('ab c') == 'ab c ba'

@pytest.mark.parametrize("input_str,expected", [
    ('', ''),
    ('a', 'a'),
    ('ab', 'aba'),
    ('cat', 'catac'),
    ('cata', 'catac'),
    ('abc', 'abcba'),
    ('racecar', 'racecar'),
    ('noon', 'noon'),
    ('test', 'testset'),
])
def test_make_palindrome_parametrized(input_str, expected):
    assert make_palindrome(input_str) == expected

def test_make_palindrome_result_is_palindrome():
    test_strings = ['', 'a', 'ab', 'abc', 'cat', 'cata', 'hello', 'world', 'test']
    for s in test_strings:
        result = make_palindrome(s)
        assert is_palindrome(result), f"Result '{result}' for input '{s}' is not a palindrome"

def test_make_palindrome_starts_with_original():
    test_strings = ['a', 'ab', 'abc', 'cat', 'cata', 'hello', 'world']
    for s in test_strings:
        result = make_palindrome(s)
        assert result.startswith(s), f"Result '{result}' does not start with '{s}'"