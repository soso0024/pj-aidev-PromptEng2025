# Test cases for HumanEval/153
# Generated using Claude API


def Strongest_Extension(class_name, extensions):
    """You will be given the name of a class (a string) and a list of extensions.
    The extensions are to be used to load additional classes to the class. The
    strength of the extension is as follows: Let CAP be the number of the uppercase
    letters in the extension's name, and let SM be the number of lowercase letters 
    in the extension's name, the strength is given by the fraction CAP - SM. 
    You should find the strongest extension and return a string in this 
    format: ClassName.StrongestExtensionName.
    If there are two or more extensions with the same strength, you should
    choose the one that comes first in the list.
    For example, if you are given "Slices" as the class and a list of the
    extensions: ['SErviNGSliCes', 'Cheese', 'StuFfed'] then you should
    return 'Slices.SErviNGSliCes' since 'SErviNGSliCes' is the strongest extension 
    (its strength is -1).
    Example:
    for Strongest_Extension('my_class', ['AA', 'Be', 'CC']) == 'my_class.AA'
    """

    strong = extensions[0]
    my_val = len([x for x in extensions[0] if x.isalpha() and x.isupper()]) - len([x for x in extensions[0] if x.isalpha() and x.islower()])
    for s in extensions:
        val = len([x for x in s if x.isalpha() and x.isupper()]) - len([x for x in s if x.isalpha() and x.islower()])
        if val > my_val:
            strong = s
            my_val = val

    ans = class_name + "." + strong
    return ans



# Generated test cases:
import pytest

def Strongest_Extension(class_name, extensions):
    """You will be given the name of a class (a string) and a list of extensions.
    The extensions are to be used to load additional classes to the class. The
    strength of the extension is as follows: Let CAP be the number of the uppercase
    letters in the extension's name, and let SM be the number of lowercase letters 
    in the extension's name, the strength is given by the fraction CAP - SM. 
    You should find the strongest extension and return a string in this 
    format: ClassName.StrongestExtensionName.
    If there are two or more extensions with the same strength, you should
    choose the one that comes first in the list.
    For example, if you are given "Slices" as the class and a list of the
    extensions: ['SErviNGSliCes', 'Cheese', 'StuFfed'] then you should
    return 'Slices.SErviNGSliCes' since 'SErviNGSliCes' is the strongest extension 
    (its strength is -1).
    Example:
    for Strongest_Extension('my_class', ['AA', 'Be', 'CC']) == 'my_class.AA'
    """

    strong = extensions[0]
    my_val = len([x for x in extensions[0] if x.isalpha() and x.isupper()]) - len([x for x in extensions[0] if x.isalpha() and x.islower()])
    for s in extensions:
        val = len([x for x in s if x.isalpha() and x.isupper()]) - len([x for x in s if x.isalpha() and x.islower()])
        if val > my_val:
            strong = s
            my_val = val

    ans = class_name + "." + strong
    return ans


@pytest.mark.parametrize("class_name,extensions,expected", [
    ("Slices", ["SErviNGSliCes", "Cheese", "StuFfed"], "Slices.StuFfed"),
    ("my_class", ["AA", "Be", "CC"], "my_class.AA"),
    ("TestClass", ["ABC", "abc", "AbC"], "TestClass.ABC"),
    ("Class", ["a", "A"], "Class.A"),
    ("MyClass", ["aaa", "AAA", "aAa"], "MyClass.AAA"),
    ("Example", ["lower", "UPPER", "MiXeD"], "Example.UPPER"),
    ("Test", ["abc"], "Test.abc"),
    ("Single", ["X"], "Single.X"),
    ("Numbers", ["123ABC", "abc123", "ABC123"], "Numbers.ABC123"),
    ("Special", ["A!B@C", "a#b$c", "ABC"], "Special.ABC"),
    ("Equal", ["Aa", "Bb", "Cc"], "Equal.Aa"),
    ("TieBreaker", ["AB", "CD", "EF"], "TieBreaker.AB"),
    ("Negative", ["aaa", "bbb", "ccc"], "Negative.aaa"),
    ("Mixed", ["AaBbCc", "aAbBcC", "AAbbcc"], "Mixed.AAbbcc"),
    ("Empty", [""], "Empty."),
    ("NonAlpha", ["123", "456", "789"], "NonAlpha.123"),
    ("Symbols", ["!!!", "@@@", "###"], "Symbols.!!!"),
    ("Combined", ["A1a", "B2b", "C3c"], "Combined.A1a"),
    ("LongName", ["VeryLongExtensionName", "Short", "Med"], "LongName.Short"),
    ("AllUpper", ["AAAA", "BBBB", "CCCC"], "AllUpper.AAAA"),
    ("AllLower", ["aaaa", "bbbb", "cccc"], "AllLower.aaaa"),
    ("OneChar", ["a", "b", "c"], "OneChar.a"),
    ("OneCharUpper", ["A", "B", "C"], "OneCharUpper.A"),
    ("MixedSymbols", ["A!a", "B@b", "C#c"], "MixedSymbols.A!a"),
    ("Spaces", ["A B", "a b", "AB"], "Spaces.AB"),
])
def test_strongest_extension_parametrized(class_name, extensions, expected):
    assert Strongest_Extension(class_name, extensions) == expected


def test_strongest_extension_example_from_docstring():
    assert Strongest_Extension("Slices", ["SErviNGSliCes", "Cheese", "StuFfed"]) == "Slices.StuFfed"


def test_strongest_extension_all_uppercase():
    assert Strongest_Extension("Class", ["AAA", "BBB", "CCC"]) == "Class.AAA"


def test_strongest_extension_all_lowercase():
    assert Strongest_Extension("Class", ["aaa", "bbb", "ccc"]) == "Class.aaa"


def test_strongest_extension_single_extension():
    assert Strongest_Extension("Test", ["OnlyOne"]) == "Test.OnlyOne"


def test_strongest_extension_tie_first_wins():
    assert Strongest_Extension("Tie", ["AA", "BB", "CC"]) == "Tie.AA"


def test_strongest_extension_negative_strength():
    assert Strongest_Extension("Negative", ["aaa", "bbb"]) == "Negative.aaa"


def test_strongest_extension_positive_strength():
    assert Strongest_Extension("Positive", ["AAA", "BBB"]) == "Positive.AAA"


def test_strongest_extension_zero_strength():
    assert Strongest_Extension("Zero", ["Aa", "Bb"]) == "Zero.Aa"


def test_strongest_extension_with_numbers():
    assert Strongest_Extension("Numbers", ["A1B2C3", "a1b2c3", "ABC123"]) == "Numbers.ABC123"


def test_strongest_extension_with_special_chars():
    assert Strongest_Extension("Special", ["A!B@C#", "a!b@c#", "ABC"]) == "Special.ABC"


def test_strongest_extension_empty_string():
    assert Strongest_Extension("Empty", ["", "A", "a"]) == "Empty.A"


def test_strongest_extension_only_numbers():
    assert Strongest_Extension("OnlyNums", ["123", "456"]) == "OnlyNums.123"


def test_strongest_extension_mixed_case_complex():
    result = Strongest_Extension("Complex", ["AaBbCcDd", "AAaaBBbb", "aaaaBBBB"])
    assert result == "Complex.aaaaBBBB"


def test_strongest_extension_long_list():
    extensions = ["a" * i + "A" * (10 - i) for i in range(10)]
    result = Strongest_Extension("Long", extensions)
    assert result == "Long.AAAAAAAAAA"