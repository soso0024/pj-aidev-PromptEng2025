# Test cases for HumanEval/146
# Generated using Claude API


def specialFilter(nums):
    """Write a function that takes an array of numbers as input and returns 
    the number of elements in the array that are greater than 10 and both 
    first and last digits of a number are odd (1, 3, 5, 7, 9).
    For example:
    specialFilter([15, -73, 14, -15]) => 1 
    specialFilter([33, -2, -3, 45, 21, 109]) => 2
    """

    
    count = 0
    for num in nums:
        if num > 10:
            odd_digits = (1, 3, 5, 7, 9)
            number_as_string = str(num)
            if int(number_as_string[0]) in odd_digits and int(number_as_string[-1]) in odd_digits:
                count += 1
        
    return count 


# Generated test cases:
import pytest

def specialFilter(nums):
    count = 0
    for num in nums:
        if num > 10:
            odd_digits = (1, 3, 5, 7, 9)
            number_as_string = str(num)
            if int(number_as_string[0]) in odd_digits and int(number_as_string[-1]) in odd_digits:
                count += 1
    return count

def test_empty_list():
    assert specialFilter([]) == 0

def test_single_element_valid():
    assert specialFilter([11]) == 1

def test_single_element_invalid_first_digit():
    assert specialFilter([21]) == 0

def test_single_element_invalid_last_digit():
    assert specialFilter([12]) == 0

def test_single_element_both_invalid():
    assert specialFilter([22]) == 0

def test_single_element_less_than_10():
    assert specialFilter([5]) == 0

def test_single_element_equal_to_10():
    assert specialFilter([10]) == 0

def test_multiple_valid_numbers():
    assert specialFilter([11, 13, 15, 17, 19]) == 5

def test_multiple_invalid_numbers():
    assert specialFilter([12, 14, 16, 18, 20]) == 0

def test_mixed_valid_and_invalid():
    assert specialFilter([11, 12, 13, 14, 15]) == 3

def test_numbers_less_than_or_equal_to_10():
    assert specialFilter([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == 0

def test_large_numbers():
    assert specialFilter([111, 131, 151, 171, 191]) == 5

def test_large_numbers_invalid():
    assert specialFilter([112, 134, 156, 178, 192]) == 0

def test_three_digit_numbers_mixed():
    assert specialFilter([111, 222, 333, 444, 555]) == 3

def test_negative_numbers():
    assert specialFilter([-11, -13, -15]) == 0

def test_mixed_positive_negative():
    assert specialFilter([-11, 11, -13, 13]) == 2

def test_all_odd_digits_various_lengths():
    assert specialFilter([11, 111, 1111, 11111]) == 4

def test_first_digit_even_last_odd():
    assert specialFilter([21, 23, 25, 27, 29]) == 0

def test_first_digit_odd_last_even():
    assert specialFilter([12, 32, 52, 72, 92]) == 0

def test_both_digits_even():
    assert specialFilter([22, 24, 26, 28, 42]) == 0

def test_boundary_11():
    assert specialFilter([11]) == 1

def test_boundary_99():
    assert specialFilter([99]) == 1

def test_boundary_10():
    assert specialFilter([10]) == 0

def test_large_list_all_valid():
    assert specialFilter([11, 13, 15, 17, 19, 31, 33, 35, 37, 39]) == 10

def test_large_list_all_invalid():
    assert specialFilter([12, 14, 16, 18, 20, 22, 24, 26, 28, 30]) == 0

def test_zero():
    assert specialFilter([0]) == 0

def test_single_digit_odd():
    assert specialFilter([1, 3, 5, 7, 9]) == 0

def test_single_digit_even():
    assert specialFilter([2, 4, 6, 8]) == 0

def test_four_digit_numbers():
    assert specialFilter([1111, 1313, 1515, 2222, 2424]) == 3

def test_five_digit_numbers():
    assert specialFilter([11111, 12345, 13579, 24680]) == 3

@pytest.mark.parametrize("nums,expected", [
    ([15, 19, 11], 3),
    ([12, 14, 16], 0),
    ([11, 12, 13], 2),
    ([5, 8, 10], 0),
    ([33, 55, 77, 99], 4),
    ([31, 51, 71, 91], 4),
    ([13, 24, 35, 46, 57], 3),
])
def test_parametrized_cases(nums, expected):
    assert specialFilter(nums) == expected