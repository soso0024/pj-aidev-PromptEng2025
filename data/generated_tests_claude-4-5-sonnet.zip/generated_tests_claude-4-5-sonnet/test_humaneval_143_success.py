# Test cases for HumanEval/143
# Generated using Claude API


def words_in_sentence(sentence):
    """
    You are given a string representing a sentence,
    the sentence contains some words separated by a space,
    and you have to return a string that contains the words from the original sentence,
    whose lengths are prime numbers,
    the order of the words in the new string should be the same as the original one.

    Example 1:
        Input: sentence = "This is a test"
        Output: "is"

    Example 2:
        Input: sentence = "lets go for swimming"
        Output: "go for"

    Constraints:
        * 1 <= len(sentence) <= 100
        * sentence contains only letters
    """

    new_lst = []
    for word in sentence.split():
        flg = 0
        if len(word) == 1:
            flg = 1
        for i in range(2, len(word)):
            if len(word)%i == 0:
                flg = 1
        if flg == 0 or len(word) == 2:
            new_lst.append(word)
    return " ".join(new_lst)


# Generated test cases:
import pytest


def words_in_sentence(sentence):
    new_lst = []
    for word in sentence.split():
        flg = 0
        if len(word) == 1:
            flg = 1
        for i in range(2, len(word)):
            if len(word)%i == 0:
                flg = 1
        if flg == 0 or len(word) == 2:
            new_lst.append(word)
    return " ".join(new_lst)


@pytest.mark.parametrize("sentence,expected", [
    ("This is a test", "is"),
    ("lets go for swimming", "go for"),
    ("there is no place available here", "there is no place"),
    ("Hi", "Hi"),
    ("a", ""),
    ("ab", "ab"),
    ("abc", "abc"),
    ("abcd", ""),
    ("abcde", "abcde"),
    ("abcdef", ""),
    ("I love coding", ""),
    ("", ""),
    ("a b c d e", ""),
    ("ab cd ef gh", "ab cd ef gh"),
    ("abc def ghi", "abc def ghi"),
    ("abcd efgh ijkl", ""),
    ("prime numbers are fun", "prime numbers are fun"),
    ("test with multiple words here", "words"),
    ("x", ""),
    ("xy", "xy"),
    ("xyz", "xyz"),
    ("wxyz", ""),
    ("hello world", "hello world"),
    ("programming is great", "programming is great"),
    ("one two three four five", "one two three"),
    ("aa bb cc dd ee ff gg", "aa bb cc dd ee ff gg"),
    ("aaa bbb ccc ddd eee", "aaa bbb ccc ddd eee"),
    ("aaaa bbbb cccc", ""),
    ("a ab abc abcd abcde", "ab abc abcde"),
    ("the quick brown fox", "the quick brown fox"),
    ("I am happy today", "am happy today"),
])
def test_words_in_sentence_parametrized(sentence, expected):
    assert words_in_sentence(sentence) == expected


def test_empty_string():
    assert words_in_sentence("") == ""


def test_single_character_word():
    assert words_in_sentence("a") == ""
    assert words_in_sentence("I") == ""
    assert words_in_sentence("x") == ""


def test_two_character_words():
    assert words_in_sentence("ab") == "ab"
    assert words_in_sentence("is") == "is"
    assert words_in_sentence("to") == "to"


def test_prime_length_words():
    assert words_in_sentence("abc") == "abc"
    assert words_in_sentence("abcde") == "abcde"
    assert words_in_sentence("abcdefg") == "abcdefg"


def test_composite_length_words():
    assert words_in_sentence("abcd") == ""
    assert words_in_sentence("abcdef") == ""
    assert words_in_sentence("abcdefgh") == ""


def test_mixed_length_words():
    assert words_in_sentence("a ab abc abcd") == "ab abc"
    assert words_in_sentence("I is the best") == "is the"


def test_all_prime_lengths():
    assert words_in_sentence("ab abc abcde") == "ab abc abcde"


def test_all_composite_lengths():
    assert words_in_sentence("abcd abcdef") == ""


def test_multiple_spaces():
    result = words_in_sentence("ab  cd")
    assert result == "ab cd"


def test_sentence_with_only_single_chars():
    assert words_in_sentence("a b c d") == ""


def test_sentence_with_only_two_char_words():
    assert words_in_sentence("ab cd ef gh") == "ab cd ef gh"


def test_long_sentence():
    sentence = "this is a very long sentence with many words of different lengths"
    result = words_in_sentence(sentence)
    words = result.split()
    for word in words:
        length = len(word)
        if length == 2:
            assert True
        else:
            is_prime = length > 1
            for i in range(2, length):
                if length % i == 0:
                    is_prime = False
                    break
            assert is_prime


def test_real_world_sentence():
    assert words_in_sentence("This is a test") == "is"
    assert words_in_sentence("lets go for swimming") == "go for"