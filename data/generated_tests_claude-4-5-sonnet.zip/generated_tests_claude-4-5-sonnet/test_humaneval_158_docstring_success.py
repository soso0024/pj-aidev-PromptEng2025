# Test cases for HumanEval/158
# Generated using Claude API


def find_max(words):
    """Write a function that accepts a list of strings.
    The list contains different words. Return the word with maximum number
    of unique characters. If multiple strings have maximum number of unique
    characters, return the one which comes first in lexicographical order.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb" ,"cc"]) == ""aaaaaaa"
    """

    return sorted(words, key = lambda x: (-len(set(x)), x))[0]


# Generated test cases:
import pytest


def find_max(words):
    return sorted(words, key = lambda x: (-len(set(x)), x))[0]


def test_find_max_basic():
    assert find_max(["name", "of", "string"]) == "string"


def test_find_max_lexicographical():
    assert find_max(["name", "enam", "game"]) == "enam"


def test_find_max_same_char_repeated():
    assert find_max(["aaaaaaa", "bb", "cc"]) == "aaaaaaa"


def test_find_max_single_word():
    assert find_max(["hello"]) == "hello"


def test_find_max_empty_string_in_list():
    assert find_max(["", "a", "ab"]) == "ab"


def test_find_max_all_empty_strings():
    assert find_max([""]) == ""


def test_find_max_same_unique_chars_different_lengths():
    assert find_max(["aaa", "aa", "a"]) == "a"


def test_find_max_multiple_same_unique_count():
    assert find_max(["abc", "def", "ghi"]) == "abc"


def test_find_max_single_char_words():
    assert find_max(["a", "b", "c"]) == "a"


def test_find_max_mixed_lengths():
    assert find_max(["a", "ab", "abc", "abcd"]) == "abcd"


def test_find_max_duplicate_words():
    assert find_max(["test", "test", "best"]) == "best"


def test_find_max_special_characters():
    assert find_max(["a!b", "abc", "a@b"]) == "a!b"


def test_find_max_numbers_as_strings():
    assert find_max(["123", "456", "789"]) == "123"


def test_find_max_case_sensitive():
    assert find_max(["Abc", "abc", "ABC"]) == "ABC"


def test_find_max_with_spaces():
    assert find_max(["a b", "abc", "ab"]) == "a b"


def test_find_max_all_same_unique_chars():
    assert find_max(["aaa", "bbb", "ccc"]) == "aaa"


def test_find_max_lexicographical_priority():
    assert find_max(["zz", "aa", "bb"]) == "aa"


def test_find_max_longer_words():
    assert find_max(["abcdefghij", "abcdefghi", "abcdefgh"]) == "abcdefghij"


def test_find_max_two_words_same_unique():
    assert find_max(["ab", "ba"]) == "ab"


def test_find_max_unicode_characters():
    assert find_max(["café", "test", "hello"]) == "café"