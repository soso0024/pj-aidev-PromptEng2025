# Test cases for HumanEval/18
# Generated using Claude API



def how_many_times(string: str, substring: str) -> int:
    """ Find how many times a given substring can be found in the original string. Count overlaping cases.
    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """

    times = 0

    for i in range(len(string) - len(substring) + 1):
        if string[i:i+len(substring)] == substring:
            times += 1

    return times


# Generated test cases:
import pytest

def how_many_times(string: str, substring: str) -> int:
    times = 0
    for i in range(len(string) - len(substring) + 1):
        if string[i:i+len(substring)] == substring:
            times += 1
    return times


@pytest.mark.parametrize("string,substring,expected", [
    ('', 'a', 0),
    ('aaa', 'a', 3),
    ('aaaa', 'aa', 3),
    ('hello', 'l', 2),
    ('hello', 'll', 1),
    ('hello', 'hello', 1),
    ('hello', 'hellohello', 0),
    ('abcabcabc', 'abc', 3),
    ('abcabcabc', 'abcabc', 2),
    ('aaaaaaa', 'aaa', 5),
    ('abababab', 'aba', 3),
    ('abababab', 'abab', 3),
    ('test', 'xyz', 0),
    ('a', 'a', 1),
    ('a', 'ab', 0),
    ('ab', 'ab', 1),
    ('aba', 'aba', 1),
    ('ababa', 'aba', 2),
    ('mississippi', 'issi', 2),
    ('mississippi', 'ss', 2),
    ('mississippi', 'i', 4),
    ('aaaaaa', 'aa', 5),
    ('aaaaaa', 'aaa', 4),
    ('aaaaaa', 'aaaa', 3),
    ('aaaaaa', 'aaaaa', 2),
    ('aaaaaa', 'aaaaaa', 1),
    ('aaaaaa', 'aaaaaaa', 0),
    ('123123123', '123', 3),
    ('123123123', '231', 2),
    ('abcdefg', 'xyz', 0),
    ('abcdefg', 'abc', 1),
    ('abcdefg', 'efg', 1),
    ('abcdefg', 'cde', 1),
    ('abcdefg', 'abcdefg', 1),
    ('abcdefg', 'abcdefgh', 0),
])
def test_how_many_times(string, substring, expected):
    assert how_many_times(string, substring) == expected


def test_single_character_string():
    assert how_many_times('a', 'a') == 1
    assert how_many_times('a', 'b') == 0


def test_overlapping_patterns():
    assert how_many_times('aaaa', 'aa') == 3
    assert how_many_times('aaaaaa', 'aa') == 5


def test_non_overlapping_patterns():
    assert how_many_times('abcabc', 'abc') == 2


def test_substring_longer_than_string():
    assert how_many_times('ab', 'abc') == 0
    assert how_many_times('hello', 'hello world') == 0


def test_substring_not_in_string():
    assert how_many_times('hello', 'xyz') == 0


def test_case_sensitive():
    assert how_many_times('Hello', 'hello') == 0
    assert how_many_times('HELLO', 'hello') == 0


def test_special_characters():
    assert how_many_times('a.b.c.d', '.') == 3
    assert how_many_times('a..b..c', '..') == 2