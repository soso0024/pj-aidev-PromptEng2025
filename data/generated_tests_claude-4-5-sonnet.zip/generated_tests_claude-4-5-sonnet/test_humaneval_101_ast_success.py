# Test cases for HumanEval/101
# Generated using Claude API


def words_string(s):
    """
    You will be given a string of words separated by commas or spaces. Your task is
    to split the string into words and return an array of the words.
    
    For example:
    words_string("Hi, my name is John") == ["Hi", "my", "name", "is", "John"]
    words_string("One, two, three, four, five, six") == ["One", "two", "three", "four", "five", "six"]
    """

    if not s:
        return []

    s_list = []

    for letter in s:
        if letter == ',':
            s_list.append(' ')
        else:
            s_list.append(letter)

    s_list = "".join(s_list)
    return s_list.split()


# Generated test cases:
import pytest

def words_string(s):
    if not s:
        return []

    s_list = []

    for letter in s:
        if letter == ',':
            s_list.append(' ')
        else:
            s_list.append(letter)

    s_list = "".join(s_list)
    return s_list.split()


@pytest.mark.parametrize("input_str,expected", [
    ("", []),
    ("Hi, my name is John", ["Hi", "my", "name", "is", "John"]),
    ("One, two, three, four, five, six", ["One", "two", "three", "four", "five", "six"]),
    ("Hi", ["Hi"]),
    ("Hello,world", ["Hello", "world"]),
    ("a,b,c,d", ["a", "b", "c", "d"]),
    ("   ", []),
    ("word", ["word"]),
    ("one two three", ["one", "two", "three"]),
    ("one,two three,four", ["one", "two", "three", "four"]),
    (",,,", []),
    ("   ,   ,   ", []),
    ("a b c", ["a", "b", "c"]),
    ("test,", ["test"]),
    (",test", ["test"]),
    ("a, b, c", ["a", "b", "c"]),
    ("hello,world,foo,bar", ["hello", "world", "foo", "bar"]),
    ("single", ["single"]),
    ("multiple   spaces", ["multiple", "spaces"]),
    ("comma,and space mix", ["comma", "and", "space", "mix"]),
])
def test_words_string_parametrized(input_str, expected):
    assert words_string(input_str) == expected


def test_words_string_empty():
    assert words_string("") == []


def test_words_string_none():
    assert words_string(None) == []


def test_words_string_simple():
    assert words_string("Hi, my name is John") == ["Hi", "my", "name", "is", "John"]


def test_words_string_multiple_commas():
    assert words_string("One, two, three, four, five, six") == ["One", "two", "three", "four", "five", "six"]


def test_words_string_no_comma():
    assert words_string("Hi") == ["Hi"]


def test_words_string_comma_no_space():
    assert words_string("Hello,world") == ["Hello", "world"]


def test_words_string_only_commas():
    assert words_string(",,,") == []


def test_words_string_only_spaces():
    assert words_string("   ") == []


def test_words_string_mixed_separators():
    assert words_string("one,two three,four") == ["one", "two", "three", "four"]


def test_words_string_trailing_comma():
    assert words_string("test,") == ["test"]


def test_words_string_leading_comma():
    assert words_string(",test") == ["test"]


def test_words_string_single_word():
    assert words_string("word") == ["word"]


def test_words_string_multiple_spaces():
    assert words_string("multiple   spaces") == ["multiple", "spaces"]
