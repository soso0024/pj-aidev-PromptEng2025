# Test cases for HumanEval/53
# Generated using Claude API



def add(x: int, y: int):
    """Add two numbers x and y
    >>> add(2, 3)
    5
    >>> add(5, 7)
    12
    """

    return x + y


# Generated test cases:
import pytest

def add(x: int, y: int):
    return x + y


class TestAdd:
    def test_add_positive_numbers(self):
        assert add(2, 3) == 5
    
    def test_add_negative_numbers(self):
        assert add(-2, -3) == -5
    
    def test_add_positive_and_negative(self):
        assert add(5, -3) == 2
    
    def test_add_negative_and_positive(self):
        assert add(-5, 3) == -2
    
    def test_add_zero_to_positive(self):
        assert add(0, 5) == 5
    
    def test_add_zero_to_negative(self):
        assert add(0, -5) == -5
    
    def test_add_positive_to_zero(self):
        assert add(5, 0) == 5
    
    def test_add_negative_to_zero(self):
        assert add(-5, 0) == -5
    
    def test_add_zeros(self):
        assert add(0, 0) == 0
    
    def test_add_large_numbers(self):
        assert add(1000000, 2000000) == 3000000
    
    def test_add_large_negative_numbers(self):
        assert add(-1000000, -2000000) == -3000000
    
    def test_add_max_int(self):
        assert add(2**31 - 1, 0) == 2**31 - 1
    
    def test_add_min_int(self):
        assert add(-(2**31), 0) == -(2**31)
    
    @pytest.mark.parametrize("x,y,expected", [
        (1, 1, 2),
        (10, 20, 30),
        (-10, 10, 0),
        (100, -50, 50),
        (0, 0, 0),
        (-1, -1, -2),
        (999, 1, 1000),
    ])
    def test_add_parametrized(self, x, y, expected):
        assert add(x, y) == expected
    
    def test_add_commutative(self):
        assert add(3, 5) == add(5, 3)
    
    def test_add_associative(self):
        assert add(add(1, 2), 3) == add(1, add(2, 3))
