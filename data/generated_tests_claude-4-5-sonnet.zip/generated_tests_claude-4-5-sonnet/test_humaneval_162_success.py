# Test cases for HumanEval/162
# Generated using Claude API


def string_to_md5(text):
    """
    Given a string 'text', return its md5 hash equivalent string.
    If 'text' is an empty string, return None.

    >>> string_to_md5('Hello world') == '3e25960a79dbc69b674cd4ec67a72c62'
    """

    import hashlib
    return hashlib.md5(text.encode('ascii')).hexdigest() if text else None


# Generated test cases:
import pytest
import hashlib


def string_to_md5(text):
    return hashlib.md5(text.encode('ascii')).hexdigest() if text else None


class TestStringToMd5:
    
    def test_empty_string(self):
        assert string_to_md5("") is None
    
    def test_none_input(self):
        assert string_to_md5(None) is None
    
    def test_simple_string(self):
        result = string_to_md5("hello")
        expected = hashlib.md5("hello".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_single_character(self):
        result = string_to_md5("a")
        expected = hashlib.md5("a".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_string_with_spaces(self):
        result = string_to_md5("hello world")
        expected = hashlib.md5("hello world".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_string_with_numbers(self):
        result = string_to_md5("test123")
        expected = hashlib.md5("test123".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_string_with_special_characters(self):
        result = string_to_md5("test!@#$%")
        expected = hashlib.md5("test!@#$%".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_long_string(self):
        long_text = "a" * 1000
        result = string_to_md5(long_text)
        expected = hashlib.md5(long_text.encode('ascii')).hexdigest()
        assert result == expected
    
    def test_uppercase_string(self):
        result = string_to_md5("HELLO")
        expected = hashlib.md5("HELLO".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_mixed_case_string(self):
        result = string_to_md5("HeLLo WoRLd")
        expected = hashlib.md5("HeLLo WoRLd".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_numeric_string(self):
        result = string_to_md5("1234567890")
        expected = hashlib.md5("1234567890".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_string_with_newline(self):
        result = string_to_md5("hello\nworld")
        expected = hashlib.md5("hello\nworld".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_string_with_tab(self):
        result = string_to_md5("hello\tworld")
        expected = hashlib.md5("hello\tworld".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_known_md5_hash(self):
        result = string_to_md5("hello")
        assert result == "5d41402abc4b2a76b9719d911017c592"
    
    def test_another_known_md5_hash(self):
        result = string_to_md5("world")
        assert result == "7d793037a0760186574b0282f2f435e7"
    
    def test_return_type_is_string(self):
        result = string_to_md5("test")
        assert isinstance(result, str)
    
    def test_return_type_is_none_for_empty(self):
        result = string_to_md5("")
        assert result is None
    
    def test_hexdigest_length(self):
        result = string_to_md5("test")
        assert len(result) == 32
    
    def test_hexdigest_contains_only_hex_chars(self):
        result = string_to_md5("test")
        assert all(c in "0123456789abcdef" for c in result)
    
    @pytest.mark.parametrize("input_text,expected_hash", [
        ("a", "0cc175b9c0f1b6a831c399e269772661"),
        ("abc", "900150983cd24fb0d6963f7d28e17f72"),
        ("message digest", "f96b697d7cb7938d525a2f31aaf161d0"),
    ])
    def test_parametrized_known_hashes(self, input_text, expected_hash):
        assert string_to_md5(input_text) == expected_hash
