# Test cases for HumanEval/24
# Generated using Claude API



def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    >>> largest_divisor(15)
    5
    """

    for i in reversed(range(n)):
        if n % i == 0:
            return i


# Generated test cases:
import pytest

def largest_divisor(n: int) -> int:
    for i in reversed(range(n)):
        if n % i == 0:
            return i

def test_largest_divisor_15():
    assert largest_divisor(15) == 5

def test_largest_divisor_prime_number():
    assert largest_divisor(7) == 1
    assert largest_divisor(13) == 1
    assert largest_divisor(17) == 1

def test_largest_divisor_even_numbers():
    assert largest_divisor(10) == 5
    assert largest_divisor(12) == 6
    assert largest_divisor(20) == 10
    assert largest_divisor(100) == 50

def test_largest_divisor_perfect_squares():
    assert largest_divisor(4) == 2
    assert largest_divisor(9) == 3
    assert largest_divisor(16) == 8
    assert largest_divisor(25) == 5
    assert largest_divisor(36) == 18

def test_largest_divisor_small_numbers():
    assert largest_divisor(2) == 1
    assert largest_divisor(3) == 1
    assert largest_divisor(4) == 2

def test_largest_divisor_large_numbers():
    assert largest_divisor(1000) == 500
    assert largest_divisor(999) == 333
    assert largest_divisor(1024) == 512

def test_largest_divisor_composite_numbers():
    assert largest_divisor(21) == 7
    assert largest_divisor(30) == 15
    assert largest_divisor(42) == 21
    assert largest_divisor(60) == 30

@pytest.mark.parametrize("n,expected", [
    (15, 5),
    (7, 1),
    (10, 5),
    (4, 2),
    (100, 50),
    (2, 1),
    (9, 3),
    (21, 7),
    (1000, 500),
])
def test_largest_divisor_parametrized(n, expected):
    assert largest_divisor(n) == expected
