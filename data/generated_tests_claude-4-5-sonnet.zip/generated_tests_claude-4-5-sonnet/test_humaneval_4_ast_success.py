# Test cases for HumanEval/4
# Generated using Claude API

from typing import List


def mean_absolute_deviation(numbers: List[float]) -> float:
    """ For a given list of input numbers, calculate Mean Absolute Deviation
    around the mean of this dataset.
    Mean Absolute Deviation is the average absolute difference between each
    element and a centerpoint (mean in this case):
    MAD = average | x - x_mean |
    >>> mean_absolute_deviation([1.0, 2.0, 3.0, 4.0])
    1.0
    """

    mean = sum(numbers) / len(numbers)
    return sum(abs(x - mean) for x in numbers) / len(numbers)


# Generated test cases:
import pytest
from typing import List


def mean_absolute_deviation(numbers: List[float]) -> float:
    mean = sum(numbers) / len(numbers)
    return sum(abs(x - mean) for x in numbers) / len(numbers)


def test_mean_absolute_deviation_single_element():
    assert mean_absolute_deviation([1.0]) == 0.0


def test_mean_absolute_deviation_two_elements():
    assert mean_absolute_deviation([1.0, 2.0]) == 0.5


def test_mean_absolute_deviation_identical_elements():
    assert mean_absolute_deviation([5.0, 5.0, 5.0, 5.0]) == 0.0


def test_mean_absolute_deviation_positive_numbers():
    result = mean_absolute_deviation([1.0, 2.0, 3.0, 4.0, 5.0])
    assert abs(result - 1.2) < 1e-9


def test_mean_absolute_deviation_negative_numbers():
    result = mean_absolute_deviation([-1.0, -2.0, -3.0, -4.0, -5.0])
    assert abs(result - 1.2) < 1e-9


def test_mean_absolute_deviation_mixed_numbers():
    result = mean_absolute_deviation([-2.0, -1.0, 0.0, 1.0, 2.0])
    assert abs(result - 1.2) < 1e-9


def test_mean_absolute_deviation_with_zero():
    result = mean_absolute_deviation([0.0, 0.0, 0.0])
    assert result == 0.0


def test_mean_absolute_deviation_large_numbers():
    result = mean_absolute_deviation([100.0, 200.0, 300.0])
    assert abs(result - 66.66666666666667) < 1e-9


def test_mean_absolute_deviation_small_numbers():
    result = mean_absolute_deviation([0.1, 0.2, 0.3])
    assert abs(result - 0.06666666666666667) < 1e-9


def test_mean_absolute_deviation_floats():
    result = mean_absolute_deviation([1.5, 2.5, 3.5, 4.5])
    assert abs(result - 1.0) < 1e-9


def test_mean_absolute_deviation_symmetric_distribution():
    result = mean_absolute_deviation([1.0, 3.0, 5.0, 7.0, 9.0])
    assert abs(result - 2.4) < 1e-9


def test_mean_absolute_deviation_asymmetric_distribution():
    result = mean_absolute_deviation([1.0, 1.0, 1.0, 10.0])
    expected_mean = 3.25
    expected_mad = (abs(1.0 - 3.25) + abs(1.0 - 3.25) + abs(1.0 - 3.25) + abs(10.0 - 3.25)) / 4
    assert abs(result - expected_mad) < 1e-9


def test_mean_absolute_deviation_two_identical_elements():
    assert mean_absolute_deviation([7.0, 7.0]) == 0.0


def test_mean_absolute_deviation_integers_as_floats():
    result = mean_absolute_deviation([1.0, 2.0, 3.0])
    assert abs(result - 0.6666666666666666) < 1e-9


@pytest.mark.parametrize("numbers,expected", [
    ([1.0], 0.0),
    ([2.0, 2.0], 0.0),
    ([1.0, 3.0], 1.0),
    ([0.0, 1.0, 2.0], 0.6666666666666666),
])
def test_mean_absolute_deviation_parametrized(numbers, expected):
    assert abs(mean_absolute_deviation(numbers) - expected) < 1e-9
