# Test cases for HumanEval/101
# Generated using Claude API


def words_string(s):
    """
    You will be given a string of words separated by commas or spaces. Your task is
    to split the string into words and return an array of the words.
    
    For example:
    words_string("Hi, my name is John") == ["Hi", "my", "name", "is", "John"]
    words_string("One, two, three, four, five, six") == ["One", "two", "three", "four", "five", "six"]
    """

    if not s:
        return []

    s_list = []

    for letter in s:
        if letter == ',':
            s_list.append(' ')
        else:
            s_list.append(letter)

    s_list = "".join(s_list)
    return s_list.split()


# Generated test cases:
import pytest

def words_string(s):
    if not s:
        return []

    s_list = []

    for letter in s:
        if letter == ',':
            s_list.append(' ')
        else:
            s_list.append(letter)

    s_list = "".join(s_list)
    return s_list.split()


@pytest.mark.parametrize("input_str,expected", [
    ("Hi, my name is John", ["Hi", "my", "name", "is", "John"]),
    ("One, two, three, four, five, six", ["One", "two", "three", "four", "five", "six"]),
    ("", []),
    ("Hello", ["Hello"]),
    ("Hello World", ["Hello", "World"]),
    ("Hello,World", ["Hello", "World"]),
    ("a,b,c,d", ["a", "b", "c", "d"]),
    ("a b c d", ["a", "b", "c", "d"]),
    ("a, b, c, d", ["a", "b", "c", "d"]),
    ("a,  b,  c", ["a", "b", "c"]),
    ("  spaces  around  ", ["spaces", "around"]),
    (",,,", []),
    ("   ", []),
    ("word,", ["word"]),
    (",word", ["word"]),
    ("one two,three four", ["one", "two", "three", "four"]),
    ("multiple   spaces", ["multiple", "spaces"]),
    ("comma,,,multiple", ["comma", "multiple"]),
    ("mix, of  ,separators", ["mix", "of", "separators"]),
    ("a", ["a"]),
    (",", []),
    ("test,test,test", ["test", "test", "test"]),
    ("test test test", ["test", "test", "test"]),
])
def test_words_string_parametrized(input_str, expected):
    assert words_string(input_str) == expected


def test_words_string_empty_string():
    assert words_string("") == []


def test_words_string_only_commas():
    assert words_string(",,,") == []


def test_words_string_only_spaces():
    assert words_string("   ") == []


def test_words_string_single_word():
    assert words_string("Hello") == ["Hello"]


def test_words_string_comma_separated():
    assert words_string("one,two,three") == ["one", "two", "three"]


def test_words_string_space_separated():
    assert words_string("one two three") == ["one", "two", "three"]


def test_words_string_mixed_separators():
    assert words_string("one, two three,four") == ["one", "two", "three", "four"]


def test_words_string_leading_trailing_spaces():
    assert words_string("  hello world  ") == ["hello", "world"]


def test_words_string_leading_trailing_commas():
    assert words_string(",hello,world,") == ["hello", "world"]


def test_words_string_multiple_consecutive_commas():
    assert words_string("a,,,b") == ["a", "b"]


def test_words_string_multiple_consecutive_spaces():
    assert words_string("a   b") == ["a", "b"]
