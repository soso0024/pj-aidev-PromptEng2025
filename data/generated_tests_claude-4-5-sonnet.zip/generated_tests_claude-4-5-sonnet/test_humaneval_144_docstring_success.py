# Test cases for HumanEval/144
# Generated using Claude API


def simplify(x, n):
    """Your task is to implement a function that will simplify the expression
    x * n. The function returns True if x * n evaluates to a whole number and False
    otherwise. Both x and n, are string representation of a fraction, and have the following format,
    <numerator>/<denominator> where both numerator and denominator are positive whole numbers.

    You can assume that x, and n are valid fractions, and do not have zero as denominator.

    simplify("1/5", "5/1") = True
    simplify("1/6", "2/1") = False
    simplify("7/10", "10/2") = False
    """

    a, b = x.split("/")
    c, d = n.split("/")
    numerator = int(a) * int(c)
    denom = int(b) * int(d)
    if (numerator/denom == int(numerator/denom)):
        return True
    return False


# Generated test cases:
import pytest

def simplify(x, n):
    a, b = x.split("/")
    c, d = n.split("/")
    numerator = int(a) * int(c)
    denom = int(b) * int(d)
    if (numerator/denom == int(numerator/denom)):
        return True
    return False

@pytest.mark.parametrize("x,n,expected", [
    ("1/5", "5/1", True),
    ("1/6", "2/1", False),
    ("7/10", "10/2", False),
    ("1/1", "1/1", True),
    ("2/1", "3/1", True),
    ("1/2", "2/1", True),
    ("1/3", "3/1", True),
    ("1/4", "4/1", True),
    ("1/4", "2/1", False),
    ("2/3", "3/2", True),
    ("3/4", "4/3", True),
    ("5/6", "6/5", True),
    ("1/2", "1/2", False),
    ("1/3", "1/3", False),
    ("2/4", "4/2", True),
    ("3/6", "6/3", True),
    ("4/8", "8/4", True),
    ("10/20", "20/10", True),
    ("1/10", "10/1", True),
    ("1/100", "100/1", True),
    ("7/14", "14/7", True),
    ("5/10", "10/5", True),
    ("3/9", "9/3", True),
    ("1/7", "7/1", True),
    ("1/8", "8/1", True),
    ("1/9", "9/1", True),
    ("2/5", "5/2", True),
    ("3/7", "7/3", True),
    ("4/9", "9/4", True),
    ("5/11", "11/5", True),
    ("1/2", "3/1", False),
    ("1/3", "2/1", False),
    ("1/4", "3/1", False),
    ("1/5", "2/1", False),
    ("2/3", "2/1", False),
    ("3/4", "2/1", False),
    ("3/5", "5/3", True),
    ("7/8", "8/7", True),
    ("11/13", "13/11", True),
    ("100/200", "200/100", True),
    ("1/1", "2/2", True),
    ("2/2", "3/3", True),
    ("5/5", "7/7", True),
    ("10/10", "20/20", True),
])
def test_simplify_parametrized(x, n, expected):
    assert simplify(x, n) == expected

def test_simplify_basic_true():
    assert simplify("1/5", "5/1") == True

def test_simplify_basic_false():
    assert simplify("1/6", "2/1") == False

def test_simplify_example_false():
    assert simplify("7/10", "10/2") == False

def test_simplify_identity():
    assert simplify("1/1", "1/1") == True

def test_simplify_whole_numbers():
    assert simplify("2/1", "3/1") == True

def test_simplify_reciprocals():
    assert simplify("1/2", "2/1") == True

def test_simplify_large_numerators():
    assert simplify("100/1", "200/1") == True

def test_simplify_large_denominators():
    assert simplify("1/100", "100/1") == True

def test_simplify_equal_fractions():
    assert simplify("2/4", "4/2") == True

def test_simplify_non_whole_result():
    assert simplify("1/3", "1/2") == False

def test_simplify_prime_numbers():
    assert simplify("1/7", "7/1") == True

def test_simplify_composite_result():
    assert simplify("2/3", "3/2") == True
