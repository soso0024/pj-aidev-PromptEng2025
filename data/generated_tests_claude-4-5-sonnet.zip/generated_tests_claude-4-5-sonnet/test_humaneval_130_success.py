# Test cases for HumanEval/130
# Generated using Claude API


def tri(n):
    """Everyone knows Fibonacci sequence, it was studied deeply by mathematicians in 
    the last couple centuries. However, what people don't know is Tribonacci sequence.
    Tribonacci sequence is defined by the recurrence:
    tri(1) = 3
    tri(n) = 1 + n / 2, if n is even.
    tri(n) =  tri(n - 1) + tri(n - 2) + tri(n + 1), if n is odd.
    For example:
    tri(2) = 1 + (2 / 2) = 2
    tri(4) = 3
    tri(3) = tri(2) + tri(1) + tri(4)
           = 2 + 3 + 3 = 8 
    You are given a non-negative integer number n, you have to a return a list of the 
    first n + 1 numbers of the Tribonacci sequence.
    Examples:
    tri(3) = [1, 3, 2, 8]
    """

    if n == 0:
        return [1]
    my_tri = [1, 3]
    for i in range(2, n + 1):
        if i % 2 == 0:
            my_tri.append(i / 2 + 1)
        else:
            my_tri.append(my_tri[i - 1] + my_tri[i - 2] + (i + 3) / 2)
    return my_tri


# Generated test cases:
import pytest

def tri(n):
    if n == 0:
        return [1]
    my_tri = [1, 3]
    for i in range(2, n + 1):
        if i % 2 == 0:
            my_tri.append(i / 2 + 1)
        else:
            my_tri.append(my_tri[i - 1] + my_tri[i - 2] + (i + 3) / 2)
    return my_tri

def test_tri_zero():
    assert tri(0) == [1]

def test_tri_one():
    assert tri(1) == [1, 3]

def test_tri_two():
    result = tri(2)
    assert len(result) == 3
    assert result[0] == 1
    assert result[1] == 3
    assert result[2] == 2.0

def test_tri_three():
    result = tri(3)
    assert len(result) == 4
    assert result[0] == 1
    assert result[1] == 3
    assert result[2] == 2.0
    assert result[3] == 8.0

def test_tri_four():
    result = tri(4)
    assert len(result) == 5
    assert result[0] == 1
    assert result[1] == 3
    assert result[2] == 2.0
    assert result[3] == 8.0
    assert result[4] == 3.0

def test_tri_five():
    result = tri(5)
    assert len(result) == 6
    assert result[0] == 1
    assert result[1] == 3
    assert result[2] == 2.0
    assert result[3] == 8.0
    assert result[4] == 3.0
    assert result[5] == 15.0

def test_tri_six():
    result = tri(6)
    assert len(result) == 7
    assert result[6] == 4.0

def test_tri_seven():
    result = tri(7)
    assert len(result) == 8
    assert result[7] == 24.0

def test_tri_eight():
    result = tri(8)
    assert len(result) == 9
    assert result[8] == 5.0

def test_tri_ten():
    result = tri(10)
    assert len(result) == 11
    assert result[0] == 1
    assert result[1] == 3

def test_tri_even_indices():
    result = tri(10)
    assert result[2] == 2.0
    assert result[4] == 3.0
    assert result[6] == 4.0
    assert result[8] == 5.0
    assert result[10] == 6.0

def test_tri_odd_indices():
    result = tri(9)
    assert result[1] == 3
    assert result[3] == 8.0
    assert result[5] == 15.0
    assert result[7] == 24.0
    assert result[9] == 35.0

def test_tri_length():
    assert len(tri(0)) == 1
    assert len(tri(1)) == 2
    assert len(tri(5)) == 6
    assert len(tri(10)) == 11
    assert len(tri(20)) == 21

def test_tri_first_elements():
    for n in range(2, 10):
        result = tri(n)
        assert result[0] == 1
        assert result[1] == 3

@pytest.mark.parametrize("n,expected_length", [
    (0, 1),
    (1, 2),
    (2, 3),
    (3, 4),
    (5, 6),
    (10, 11),
    (15, 16),
])
def test_tri_parametrized_length(n, expected_length):
    assert len(tri(n)) == expected_length

def test_tri_large_n():
    result = tri(100)
    assert len(result) == 101
    assert result[0] == 1
    assert result[1] == 3
