# Test cases for HumanEval/19
# Generated using Claude API

from typing import List


def sort_numbers(numbers: str) -> str:
    """ Input is a space-delimited string of numberals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight' and 'nine'.
    Return the string with numbers sorted from smallest to largest
    >>> sort_numbers('three one five')
    'one three five'
    """

    value_map = {
        'zero': 0,
        'one': 1,
        'two': 2,
        'three': 3,
        'four': 4,
        'five': 5,
        'six': 6,
        'seven': 7,
        'eight': 8,
        'nine': 9
    }
    return ' '.join(sorted([x for x in numbers.split(' ') if x], key=lambda x: value_map[x]))


# Generated test cases:
import pytest
from typing import List


def sort_numbers(numbers: str) -> str:
    value_map = {
        'zero': 0,
        'one': 1,
        'two': 2,
        'three': 3,
        'four': 4,
        'five': 5,
        'six': 6,
        'seven': 7,
        'eight': 8,
        'nine': 9
    }
    return ' '.join(sorted([x for x in numbers.split(' ') if x], key=lambda x: value_map[x]))


@pytest.mark.parametrize("input_str,expected", [
    ("three one five", "one three five"),
    ("five zero four", "zero four five"),
    ("nine eight seven six five four three two one zero", "zero one two three four five six seven eight nine"),
    ("zero", "zero"),
    ("one", "one"),
    ("nine", "nine"),
    ("", ""),
    ("one one one", "one one one"),
    ("two one two one", "one one two two"),
    ("five four three two one", "one two three four five"),
    ("nine zero", "zero nine"),
    ("eight seven six", "six seven eight"),
    ("one two three four five six seven eight nine", "one two three four five six seven eight nine"),
    ("nine eight seven six five four three two one", "one two three four five six seven eight nine"),
    ("three three three", "three three three"),
    ("zero zero", "zero zero"),
    ("five five five five", "five five five five"),
    ("two four six eight", "two four six eight"),
    ("one three five seven nine", "one three five seven nine"),
    ("nine seven five three one", "one three five seven nine"),
])
def test_sort_numbers_parametrized(input_str, expected):
    assert sort_numbers(input_str) == expected


def test_sort_numbers_single_number():
    assert sort_numbers("five") == "five"


def test_sort_numbers_already_sorted():
    assert sort_numbers("one two three") == "one two three"


def test_sort_numbers_reverse_order():
    assert sort_numbers("three two one") == "one two three"


def test_sort_numbers_empty_string():
    assert sort_numbers("") == ""


def test_sort_numbers_all_numbers():
    result = sort_numbers("nine eight seven six five four three two one zero")
    expected = "zero one two three four five six seven eight nine"
    assert result == expected


def test_sort_numbers_duplicates():
    assert sort_numbers("five five five") == "five five five"
    assert sort_numbers("one two one") == "one one two"


def test_sort_numbers_mixed_duplicates():
    assert sort_numbers("three one three two one") == "one one two three three"


def test_sort_numbers_two_numbers():
    assert sort_numbers("five three") == "three five"


def test_sort_numbers_with_zero():
    assert sort_numbers("zero five three") == "zero three five"


def test_sort_numbers_only_zero():
    assert sort_numbers("zero") == "zero"


def test_sort_numbers_multiple_zeros():
    assert sort_numbers("zero zero zero") == "zero zero zero"
