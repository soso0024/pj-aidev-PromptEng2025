# Test cases for HumanEval/125
# Generated using Claude API


def split_words(txt):
    '''
    Given a string of words, return a list of words split on whitespace, if no whitespaces exists in the text you
    should split on commas ',' if no commas exists you should return the number of lower-case letters with odd order in the
    alphabet, ord('a') = 0, ord('b') = 1, ... ord('z') = 25
    Examples
    split_words("Hello world!") ➞ ["Hello", "world!"]
    split_words("Hello,world!") ➞ ["Hello", "world!"]
    split_words("abcdef") == 3 
    '''

    if " " in txt:
        return txt.split()
    elif "," in txt:
        return txt.replace(',',' ').split()
    else:
        return len([i for i in txt if i.islower() and ord(i)%2 == 0])


# Generated test cases:
import pytest

def split_words(txt):
    if " " in txt:
        return txt.split()
    elif "," in txt:
        return txt.replace(',',' ').split()
    else:
        return len([i for i in txt if i.islower() and ord(i)%2 == 0])

def test_split_words_with_whitespace():
    assert split_words("Hello world!") == ["Hello", "world!"]

def test_split_words_with_multiple_whitespaces():
    assert split_words("Hello  world  test") == ["Hello", "world", "test"]

def test_split_words_with_comma():
    assert split_words("Hello,world!") == ["Hello", "world!"]

def test_split_words_with_multiple_commas():
    assert split_words("Hello,world,test") == ["Hello", "world", "test"]

def test_split_words_no_whitespace_no_comma():
    assert split_words("abcdef") == 3

def test_split_words_lowercase_odd_positions():
    assert split_words("abc") == 1

def test_split_words_single_word_with_space():
    assert split_words("Hello ") == ["Hello"]

def test_split_words_empty_string():
    assert split_words("") == 0

def test_split_words_only_uppercase():
    assert split_words("ABCDEF") == 0

def test_split_words_mixed_case_no_delimiters():
    assert split_words("AbCdEf") == 3

def test_split_words_whitespace_priority_over_comma():
    assert split_words("Hello, world") == ["Hello,", "world"]

def test_split_words_single_lowercase_letter_a():
    assert split_words("a") == 0

def test_split_words_single_lowercase_letter_b():
    assert split_words("b") == 1

def test_split_words_single_lowercase_letter_c():
    assert split_words("c") == 0

def test_split_words_single_lowercase_letter_d():
    assert split_words("d") == 1

def test_split_words_all_even_ord_lowercase():
    assert split_words("bdfhjlnprtvxz") == 13

def test_split_words_all_odd_ord_lowercase():
    assert split_words("acegikmoqsuwy") == 0

def test_split_words_numbers_and_special_chars():
    assert split_words("123!@#") == 0

def test_split_words_mixed_with_numbers():
    assert split_words("a1b2c3") == 1

def test_split_words_tab_as_whitespace():
    assert split_words("Hello\tworld") == 5

def test_split_words_newline_as_whitespace():
    assert split_words("Hello\nworld") == 5

def test_split_words_comma_with_spaces_around():
    assert split_words("Hello , world") == ["Hello", ",", "world"]

def test_split_words_multiple_commas_no_space():
    assert split_words("a,b,c,d") == ["a", "b", "c", "d"]

@pytest.mark.parametrize("input_str,expected", [
    ("Hello world!", ["Hello", "world!"]),
    ("Hello,world!", ["Hello", "world!"]),
    ("abcdef", 3),
    ("", 0),
    ("a", 0),
    ("b", 1),
    ("ABCD", 0),
    ("test case", ["test", "case"]),
    ("test,case", ["test", "case"]),
    ("xyz", 2),
])
def test_split_words_parametrized(input_str, expected):
    assert split_words(input_str) == expected