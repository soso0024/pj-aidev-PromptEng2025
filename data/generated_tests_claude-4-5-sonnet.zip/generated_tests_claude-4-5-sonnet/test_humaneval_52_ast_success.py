# Test cases for HumanEval/52
# Generated using Claude API



def below_threshold(l: list, t: int):
    """Return True if all numbers in the list l are below threshold t.
    >>> below_threshold([1, 2, 4, 10], 100)
    True
    >>> below_threshold([1, 20, 4, 10], 5)
    False
    """

    for e in l:
        if e >= t:
            return False
    return True


# Generated test cases:
import pytest

def below_threshold(l: list, t: int):
    for e in l:
        if e >= t:
            return False
    return True

def test_empty_list():
    assert below_threshold([], 5) == True

def test_all_below_threshold():
    assert below_threshold([1, 2, 3, 4], 5) == True

def test_one_at_threshold():
    assert below_threshold([1, 2, 5, 4], 5) == False

def test_one_above_threshold():
    assert below_threshold([1, 2, 6, 4], 5) == False

def test_all_above_threshold():
    assert below_threshold([6, 7, 8, 9], 5) == False

def test_single_element_below():
    assert below_threshold([3], 5) == True

def test_single_element_at_threshold():
    assert below_threshold([5], 5) == False

def test_single_element_above():
    assert below_threshold([7], 5) == False

def test_negative_numbers_below():
    assert below_threshold([-5, -3, -1], 0) == True

def test_negative_numbers_mixed():
    assert below_threshold([-5, -3, 0], 0) == False

def test_negative_threshold():
    assert below_threshold([-10, -8, -6], -5) == True

def test_negative_threshold_with_above():
    assert below_threshold([-10, -4, -6], -5) == False

def test_zero_threshold():
    assert below_threshold([-1, -2, -3], 0) == True

def test_zero_in_list_zero_threshold():
    assert below_threshold([0], 0) == False

def test_large_numbers():
    assert below_threshold([100, 200, 300], 1000) == True

def test_large_numbers_at_threshold():
    assert below_threshold([100, 200, 1000], 1000) == False

def test_floats_below():
    assert below_threshold([1.5, 2.5, 3.5], 4) == True

def test_floats_above():
    assert below_threshold([1.5, 2.5, 4.5], 4) == False

def test_mixed_int_float():
    assert below_threshold([1, 2.5, 3], 4) == True

def test_first_element_at_threshold():
    assert below_threshold([5, 1, 2], 5) == False

def test_last_element_at_threshold():
    assert below_threshold([1, 2, 5], 5) == False

def test_all_equal_below():
    assert below_threshold([3, 3, 3, 3], 4) == True

def test_all_equal_at_threshold():
    assert below_threshold([4, 4, 4, 4], 4) == False

@pytest.mark.parametrize("lst,threshold,expected", [
    ([1, 2, 3], 4, True),
    ([1, 2, 4], 4, False),
    ([5, 6, 7], 4, False),
    ([], 10, True),
    ([0], 1, True),
    ([1], 1, False),
    ([-5, -4, -3], -2, True),
    ([-5, -2, -3], -2, False),
])
def test_parametrized_cases(lst, threshold, expected):
    assert below_threshold(lst, threshold) == expected
