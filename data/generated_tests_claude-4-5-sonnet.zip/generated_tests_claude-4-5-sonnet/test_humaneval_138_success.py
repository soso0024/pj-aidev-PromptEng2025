# Test cases for HumanEval/138
# Generated using Claude API


def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """

    return n%2 == 0 and n >= 8


# Generated test cases:
import pytest

def is_equal_to_sum_even(n):
    return n%2 == 0 and n >= 8

@pytest.mark.parametrize("n,expected", [
    (8, True),
    (10, True),
    (12, True),
    (100, True),
    (1000, True),
    (6, False),
    (4, False),
    (2, False),
    (0, False),
    (7, False),
    (9, False),
    (11, False),
    (13, False),
    (99, False),
    (101, False),
    (-2, False),
    (-8, False),
    (-10, False),
])
def test_is_equal_to_sum_even(n, expected):
    assert is_equal_to_sum_even(n) == expected

def test_boundary_value_8():
    assert is_equal_to_sum_even(8) == True

def test_boundary_value_7():
    assert is_equal_to_sum_even(7) == False

def test_boundary_value_6():
    assert is_equal_to_sum_even(6) == False

def test_even_below_8():
    assert is_equal_to_sum_even(2) == False
    assert is_equal_to_sum_even(4) == False
    assert is_equal_to_sum_even(6) == False

def test_odd_numbers():
    assert is_equal_to_sum_even(1) == False
    assert is_equal_to_sum_even(3) == False
    assert is_equal_to_sum_even(5) == False
    assert is_equal_to_sum_even(9) == False

def test_large_even_numbers():
    assert is_equal_to_sum_even(1000) == True
    assert is_equal_to_sum_even(10000) == True

def test_large_odd_numbers():
    assert is_equal_to_sum_even(1001) == False
    assert is_equal_to_sum_even(9999) == False

def test_negative_numbers():
    assert is_equal_to_sum_even(-2) == False
    assert is_equal_to_sum_even(-8) == False
    assert is_equal_to_sum_even(-10) == False

def test_zero():
    assert is_equal_to_sum_even(0) == False
