# Test cases for HumanEval/84
# Generated using Claude API


def solve(N):
    """Given a positive integer N, return the total sum of its digits in binary.
    
    Example
        For N = 1000, the sum of digits will be 1 the output should be "1".
        For N = 150, the sum of digits will be 6 the output should be "110".
        For N = 147, the sum of digits will be 12 the output should be "1100".
    
    Variables:
        @N integer
             Constraints: 0 ≤ N ≤ 10000.
    Output:
         a string of binary number
    """

    return bin(sum(int(i) for i in str(N)))[2:]


# Generated test cases:
import pytest

def solve(N):
    return bin(sum(int(i) for i in str(N)))[2:]

@pytest.mark.parametrize("N,expected", [
    (1000, "1"),
    (150, "110"),
    (147, "1100"),
    (0, "0"),
    (1, "1"),
    (9, "1001"),
    (10, "1"),
    (99, "10010"),
    (100, "1"),
    (999, "11011"),
    (9999, "100100"),
    (10000, "1"),
    (5, "101"),
    (15, "110"),
    (255, "1100"),
    (1234, "1010"),
    (5555, "10100"),
    (7777, "11100"),
    (8888, "100000"),
    (123, "110"),
    (456, "1111"),
    (789, "11000"),
    (1111, "100"),
    (2222, "1000"),
    (3333, "1100"),
    (4444, "10000"),
    (6666, "11000"),
])
def test_solve_parametrized(N, expected):
    assert solve(N) == expected

def test_solve_minimum():
    assert solve(0) == "0"

def test_solve_single_digit():
    assert solve(1) == "1"
    assert solve(2) == "10"
    assert solve(3) == "11"
    assert solve(4) == "100"
    assert solve(5) == "101"
    assert solve(6) == "110"
    assert solve(7) == "111"
    assert solve(8) == "1000"
    assert solve(9) == "1001"

def test_solve_maximum():
    assert solve(10000) == "1"

def test_solve_all_nines():
    assert solve(9) == "1001"
    assert solve(99) == "10010"
    assert solve(999) == "11011"
    assert solve(9999) == "100100"

def test_solve_powers_of_ten():
    assert solve(10) == "1"
    assert solve(100) == "1"
    assert solve(1000) == "1"

def test_solve_digit_sum_examples():
    assert solve(11) == "10"
    assert solve(22) == "100"
    assert solve(33) == "110"
    assert solve(44) == "1000"
    assert solve(55) == "1010"