# Test cases for HumanEval/29
# Generated using Claude API

from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    """ Filter an input list of strings only for ones that start with a given prefix.
    >>> filter_by_prefix([], 'a')
    []
    >>> filter_by_prefix(['abc', 'bcd', 'cde', 'array'], 'a')
    ['abc', 'array']
    """

    return [x for x in strings if x.startswith(prefix)]


# Generated test cases:
import pytest
from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    return [x for x in strings if x.startswith(prefix)]


def test_filter_by_prefix_empty_list():
    assert filter_by_prefix([], "a") == []


def test_filter_by_prefix_empty_prefix():
    assert filter_by_prefix(["abc", "bcd", "cde"], "") == ["abc", "bcd", "cde"]


def test_filter_by_prefix_no_matches():
    assert filter_by_prefix(["abc", "bcd", "cde"], "z") == []


def test_filter_by_prefix_all_matches():
    assert filter_by_prefix(["abc", "abd", "abe"], "ab") == ["abc", "abd", "abe"]


def test_filter_by_prefix_some_matches():
    assert filter_by_prefix(["abc", "bcd", "acd", "def"], "a") == ["abc", "acd"]


def test_filter_by_prefix_single_character_prefix():
    assert filter_by_prefix(["apple", "banana", "apricot", "cherry"], "a") == ["apple", "apricot"]


def test_filter_by_prefix_multi_character_prefix():
    assert filter_by_prefix(["apple", "application", "apply", "banana"], "app") == ["apple", "application", "apply"]


def test_filter_by_prefix_exact_match():
    assert filter_by_prefix(["test", "testing", "tester"], "test") == ["test", "testing", "tester"]


def test_filter_by_prefix_case_sensitive():
    assert filter_by_prefix(["Apple", "apple", "APPLE"], "app") == ["apple"]


def test_filter_by_prefix_longer_prefix_than_strings():
    assert filter_by_prefix(["a", "ab", "abc"], "abcd") == []


def test_filter_by_prefix_with_special_characters():
    assert filter_by_prefix(["@test", "@testing", "test"], "@") == ["@test", "@testing"]


def test_filter_by_prefix_with_numbers():
    assert filter_by_prefix(["123abc", "123def", "456ghi"], "123") == ["123abc", "123def"]


def test_filter_by_prefix_with_spaces():
    assert filter_by_prefix(["hello world", "hello there", "goodbye"], "hello") == ["hello world", "hello there"]


def test_filter_by_prefix_single_element_match():
    assert filter_by_prefix(["test"], "te") == ["test"]


def test_filter_by_prefix_single_element_no_match():
    assert filter_by_prefix(["test"], "ab") == []


@pytest.mark.parametrize("strings,prefix,expected", [
    (["abc", "def", "ghi"], "a", ["abc"]),
    (["abc", "def", "ghi"], "d", ["def"]),
    (["abc", "def", "ghi"], "g", ["ghi"]),
    (["test1", "test2", "test3"], "test", ["test1", "test2", "test3"]),
    (["", "a", "ab"], "", ["", "a", "ab"]),
])
def test_filter_by_prefix_parametrized(strings, prefix, expected):
    assert filter_by_prefix(strings, prefix) == expected


def test_filter_by_prefix_empty_strings_in_list():
    assert filter_by_prefix(["", "a", "ab"], "a") == ["a", "ab"]


def test_filter_by_prefix_empty_string_matches_empty_prefix():
    assert filter_by_prefix(["", "a", "b"], "") == ["", "a", "b"]
