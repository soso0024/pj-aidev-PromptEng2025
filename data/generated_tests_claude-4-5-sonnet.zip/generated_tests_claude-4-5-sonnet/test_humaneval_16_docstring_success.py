# Test cases for HumanEval/16
# Generated using Claude API



def count_distinct_characters(string: str) -> int:
    """ Given a string, find out how many distinct characters (regardless of case) does it consist of
    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """

    return len(set(string.lower()))


# Generated test cases:
import pytest

def count_distinct_characters(string: str) -> int:
    return len(set(string.lower()))


@pytest.mark.parametrize("input_string,expected", [
    ("xyzXYZ", 3),
    ("Jerry", 4),
    ("", 0),
    ("a", 1),
    ("A", 1),
    ("aA", 1),
    ("abc", 3),
    ("ABC", 3),
    ("aAbBcC", 3),
    ("aaa", 1),
    ("AAA", 1),
    ("abcABC", 3),
    ("Hello World", 8),
    ("hello world", 8),
    ("HELLO WORLD", 8),
    ("123", 3),
    ("112233", 3),
    ("abc123", 6),
    ("!@#$%", 5),
    ("aaa!!!", 2),
    ("The quick brown fox jumps over the lazy dog", 27),
    ("   ", 1),
    ("a b c", 4),
    ("aAbBcC123!@#", 9),
    ("aaaaaaaaaa", 1),
    ("abcdefghijklmnopqrstuvwxyz", 26),
    ("ABCDEFGHIJKLMNOPQRSTUVWXYZ", 26),
    ("aAbBcCdDeEfFgGhHiIjJkKlLmMnNoOpPqQrRsStTuUvVwWxXyYzZ", 26),
    ("1234567890", 10),
    ("!@#$%^&*()_+-=[]{}|;:',.<>?/~`", 30),
])
def test_count_distinct_characters_parametrized(input_string, expected):
    assert count_distinct_characters(input_string) == expected


def test_count_distinct_characters_empty_string():
    assert count_distinct_characters("") == 0


def test_count_distinct_characters_single_char():
    assert count_distinct_characters("a") == 1
    assert count_distinct_characters("Z") == 1


def test_count_distinct_characters_case_insensitive():
    assert count_distinct_characters("aA") == 1
    assert count_distinct_characters("AaBbCc") == 3
    assert count_distinct_characters("xyzXYZ") == 3


def test_count_distinct_characters_repeated():
    assert count_distinct_characters("aaa") == 1
    assert count_distinct_characters("aaabbbccc") == 3


def test_count_distinct_characters_with_spaces():
    assert count_distinct_characters(" ") == 1
    assert count_distinct_characters("a b c") == 4
    assert count_distinct_characters("   ") == 1


def test_count_distinct_characters_with_numbers():
    assert count_distinct_characters("123") == 3
    assert count_distinct_characters("111222333") == 3
    assert count_distinct_characters("abc123") == 6


def test_count_distinct_characters_with_special_chars():
    assert count_distinct_characters("!@#") == 3
    assert count_distinct_characters("!!!") == 1
    assert count_distinct_characters("a!b@c#") == 6


def test_count_distinct_characters_mixed():
    assert count_distinct_characters("Hello World") == 8
    assert count_distinct_characters("Jerry") == 4


def test_count_distinct_characters_all_alphabet():
    assert count_distinct_characters("abcdefghijklmnopqrstuvwxyz") == 26
    assert count_distinct_characters("The quick brown fox jumps over the lazy dog") == 27