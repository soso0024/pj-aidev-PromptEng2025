# Test cases for HumanEval/86
# Generated using Claude API


def anti_shuffle(s):
    """
    Write a function that takes a string and returns an ordered version of it.
    Ordered version of string, is a string where all words (separated by space)
    are replaced by a new word where all the characters arranged in
    ascending order based on ascii value.
    Note: You should keep the order of words and blank spaces in the sentence.

    For example:
    anti_shuffle('Hi') returns 'Hi'
    anti_shuffle('hello') returns 'ehllo'
    anti_shuffle('Hello World!!!') returns 'Hello !!!Wdlor'
    """

    return ' '.join([''.join(sorted(list(i))) for i in s.split(' ')])


# Generated test cases:
import pytest

def anti_shuffle(s):
    return ' '.join([''.join(sorted(list(i))) for i in s.split(' ')])

@pytest.mark.parametrize("input_str,expected", [
    ("Hi", "Hi"),
    ("hello", "ehllo"),
    ("Hello World!!!", "Hello !!!Wdlor"),
    ("", ""),
    (" ", " "),
    ("a", "a"),
    ("abc", "abc"),
    ("cba", "abc"),
    ("321", "123"),
    ("zyxwvu", "uvwxyz"),
    ("test case", "estt aces"),
    ("  ", "  "),
    ("a b c", "a b c"),
    ("z y x", "z y x"),
    ("Hello World", "Hello Wdlor"),
    ("Python Programming", "Phnoty Paggimmnorr"),
    ("123 456 789", "123 456 789"),
    ("zyx wvu tsr", "xyz uvw rst"),
    ("!@# $%^", "!#@ $%^"),
    ("aaa bbb ccc", "aaa bbb ccc"),
    ("single", "egilns"),
    ("a  b", "a  b"),
    ("   ", "   "),
    ("Test", "Test"),
    ("HELLO", "EHLLO"),
    ("HeLLo WoRLd", "HLLeo LRWdo"),
    ("123abc", "123abc"),
    ("abc123", "123abc"),
    ("!@#abc", "!#@abc"),
    ("abc!@#", "!#@abc"),
    ("a1b2c3", "123abc"),
    ("The quick brown fox", "Teh cikqu bnorw fox"),
    ("   leading spaces", "   adegiln acepss"),
    ("trailing spaces   ", "agiilnrt acepss   "),
    ("multiple   spaces", "eillmptu   acepss"),
    ("A", "A"),
    ("Z", "Z"),
    ("aZ", "Za"),
    ("Za", "Za"),
])
def test_anti_shuffle_parametrized(input_str, expected):
    assert anti_shuffle(input_str) == expected

def test_anti_shuffle_empty_string():
    assert anti_shuffle("") == ""

def test_anti_shuffle_single_character():
    assert anti_shuffle("a") == "a"

def test_anti_shuffle_single_word():
    assert anti_shuffle("hello") == "ehllo"

def test_anti_shuffle_multiple_words():
    assert anti_shuffle("hello world") == "ehllo dlorw"

def test_anti_shuffle_with_punctuation():
    assert anti_shuffle("Hello World!!!") == "Hello !!!Wdlor"

def test_anti_shuffle_preserves_spaces():
    result = anti_shuffle("a b c")
    assert result == "a b c"
    assert result.count(" ") == 2

def test_anti_shuffle_multiple_spaces():
    result = anti_shuffle("a  b")
    assert result == "a  b"

def test_anti_shuffle_numbers():
    assert anti_shuffle("321 654") == "123 456"

def test_anti_shuffle_mixed_case():
    result = anti_shuffle("HeLLo")
    assert result == "HLLeo"

def test_anti_shuffle_special_characters():
    assert anti_shuffle("!@# $%^") == "!#@ $%^"

def test_anti_shuffle_already_sorted():
    assert anti_shuffle("abc def") == "abc def"

def test_anti_shuffle_reverse_sorted():
    assert anti_shuffle("zyx wvu") == "xyz uvw"

def test_anti_shuffle_only_spaces():
    assert anti_shuffle("   ") == "   "

def test_anti_shuffle_long_string():
    input_str = "the quick brown fox jumps over the lazy dog"
    result = anti_shuffle(input_str)
    words = result.split(" ")
    assert len(words) == 9
    assert words[0] == "eht"
    assert words[1] == "cikqu"