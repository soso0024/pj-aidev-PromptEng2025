# Test cases for HumanEval/12
# Generated using Claude API

from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    """ Out of list of strings, return the longest one. Return the first one in case of multiple
    strings of the same length. Return None in case the input list is empty.
    >>> longest([])

    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    """

    if not strings:
        return None

    maxlen = max(len(x) for x in strings)
    for s in strings:
        if len(s) == maxlen:
            return s


# Generated test cases:
import pytest
from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    if not strings:
        return None

    maxlen = max(len(x) for x in strings)
    for s in strings:
        if len(s) == maxlen:
            return s


def test_empty_list():
    assert longest([]) is None


def test_single_string():
    assert longest(["hello"]) == "hello"


def test_multiple_strings_different_lengths():
    assert longest(["a", "bb", "ccc"]) == "ccc"


def test_multiple_strings_same_length():
    result = longest(["abc", "def", "ghi"])
    assert result == "abc"


def test_longest_at_beginning():
    assert longest(["longest", "a", "bb"]) == "longest"


def test_longest_at_end():
    assert longest(["a", "bb", "longest"]) == "longest"


def test_longest_in_middle():
    assert longest(["a", "longest", "bb"]) == "longest"


def test_two_strings_equal_length():
    result = longest(["ab", "cd"])
    assert result == "ab"


def test_multiple_longest_returns_first():
    result = longest(["abc", "def", "ghi"])
    assert result == "abc"
    assert len(result) == 3


def test_empty_strings():
    assert longest([""]) == ""


def test_empty_and_non_empty_strings():
    assert longest(["", "a", "bb"]) == "bb"


def test_all_empty_strings():
    result = longest(["", "", ""])
    assert result == ""


def test_single_character_strings():
    result = longest(["a", "b", "c"])
    assert result == "a"


def test_very_long_string():
    long_str = "a" * 1000
    assert longest([long_str, "short"]) == long_str


def test_mixed_lengths():
    assert longest(["a", "bb", "c", "dddd", "eee"]) == "dddd"


def test_whitespace_strings():
    assert longest(["a", "  ", "b"]) == "  "


def test_special_characters():
    assert longest(["@", "##", "$$$"]) == "$$$"


def test_unicode_strings():
    assert longest(["a", "ää", "bbb"]) == "bbb"


@pytest.mark.parametrize("input_list,expected", [
    (["x"], "x"),
    (["short", "longer"], "longer"),
    (["aaa", "bb", "c"], "aaa"),
    (["same", "size"], "same"),
])
def test_parametrized_cases(input_list, expected):
    assert longest(input_list) == expected
