# Test cases for HumanEval/155
# Generated using Claude API


def even_odd_count(num):
    """Given an integer. return a tuple that has the number of even and odd digits respectively.

     Example:
        even_odd_count(-12) ==> (1, 1)
        even_odd_count(123) ==> (1, 2)
    """

    even_count = 0
    odd_count = 0
    for i in str(abs(num)):
        if int(i)%2==0:
            even_count +=1
        else:
            odd_count +=1
    return (even_count, odd_count)


# Generated test cases:
import pytest

def even_odd_count(num):
    even_count = 0
    odd_count = 0
    for i in str(abs(num)):
        if int(i)%2==0:
            even_count +=1
        else:
            odd_count +=1
    return (even_count, odd_count)

@pytest.mark.parametrize("num,expected", [
    (-12, (1, 1)),
    (123, (1, 2)),
    (0, (1, 0)),
    (1, (0, 1)),
    (2, (1, 0)),
    (10, (1, 1)),
    (11, (0, 2)),
    (22, (2, 0)),
    (2468, (4, 0)),
    (1357, (0, 4)),
    (2345, (2, 2)),
    (-2345, (2, 2)),
    (100, (2, 1)),
    (999, (0, 3)),
    (-999, (0, 3)),
    (1234567890, (5, 5)),
    (-1234567890, (5, 5)),
    (8, (1, 0)),
    (9, (0, 1)),
    (-8, (1, 0)),
    (-9, (0, 1)),
    (20, (2, 0)),
    (13579, (0, 5)),
    (24680, (5, 0)),
    (102030, (4, 2)),
    (101010, (3, 3)),
    (505050, (3, 3)),
])
def test_even_odd_count(num, expected):
    assert even_odd_count(num) == expected

def test_even_odd_count_single_digit_even():
    assert even_odd_count(4) == (1, 0)

def test_even_odd_count_single_digit_odd():
    assert even_odd_count(7) == (0, 1)

def test_even_odd_count_negative_single_digit():
    assert even_odd_count(-5) == (0, 1)
    assert even_odd_count(-6) == (1, 0)

def test_even_odd_count_large_number():
    assert even_odd_count(123456789) == (4, 5)

def test_even_odd_count_all_zeros():
    assert even_odd_count(0) == (1, 0)
    assert even_odd_count(1000) == (3, 1)

def test_even_odd_count_mixed():
    assert even_odd_count(135792) == (1, 5)