# Test cases for HumanEval/35
# Generated using Claude API



def max_element(l: list):
    """Return maximum element in the list.
    >>> max_element([1, 2, 3])
    3
    >>> max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    123
    """

    m = l[0]
    for e in l:
        if e > m:
            m = e
    return m


# Generated test cases:
import pytest

def max_element(l: list):
    m = l[0]
    for e in l:
        if e > m:
            m = e
    return m

def test_max_element_single_element():
    assert max_element([5]) == 5

def test_max_element_all_positive():
    assert max_element([1, 2, 3, 4, 5]) == 5

def test_max_element_all_negative():
    assert max_element([-5, -2, -10, -1]) == -1

def test_max_element_mixed_positive_negative():
    assert max_element([-5, 3, -2, 8, 1]) == 8

def test_max_element_duplicates():
    assert max_element([5, 5, 5, 5]) == 5

def test_max_element_max_at_beginning():
    assert max_element([10, 5, 3, 1]) == 10

def test_max_element_max_at_end():
    assert max_element([1, 3, 5, 10]) == 10

def test_max_element_max_in_middle():
    assert max_element([1, 5, 10, 3, 2]) == 10

def test_max_element_with_zero():
    assert max_element([0, -1, -5]) == 0

def test_max_element_floats():
    assert max_element([1.5, 2.7, 1.2, 3.9]) == 3.9

def test_max_element_mixed_int_float():
    assert max_element([1, 2.5, 3, 1.5]) == 3

def test_max_element_two_elements():
    assert max_element([3, 7]) == 7

def test_max_element_large_numbers():
    assert max_element([1000000, 999999, 1000001]) == 1000001

def test_max_element_empty_list_raises_error():
    with pytest.raises(IndexError):
        max_element([])

def test_max_element_strings():
    assert max_element(['a', 'z', 'b', 'm']) == 'z'

def test_max_element_negative_floats():
    assert max_element([-1.5, -2.7, -1.2, -3.9]) == -1.2
