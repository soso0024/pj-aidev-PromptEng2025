# Test cases for HumanEval/160
# Generated using Claude API


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and 
    the second list is a list of integers. Use the two given lists to build the algebric 
    expression and return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + ) 
    Subtraction ( - ) 
    Multiplication ( * ) 
    Floor division ( // ) 
    Exponentiation ( ** ) 

    Example:
    operator['+', '*', '-']
    array = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9

    Note:
        The length of operator list is equal to the length of operand list minus one.
        Operand is a list of of non-negative integers.
        Operator list has at least one operator, and operand list has at least two operands.

    """

    expression = str(operand[0])
    for oprt, oprn in zip(operator, operand[1:]):
        expression+= oprt + str(oprn)
    return eval(expression)


# Generated test cases:
import pytest

def do_algebra(operator, operand):
    expression = str(operand[0])
    for oprt, oprn in zip(operator, operand[1:]):
        expression+= oprt + str(oprn)
    return eval(expression)

def test_basic_addition():
    assert do_algebra(['+'], [1, 2]) == 3

def test_basic_subtraction():
    assert do_algebra(['-'], [5, 3]) == 2

def test_basic_multiplication():
    assert do_algebra(['*'], [4, 5]) == 20

def test_basic_division():
    assert do_algebra(['/'], [10, 2]) == 5

def test_multiple_operations():
    assert do_algebra(['+', '*'], [2, 3, 4]) == 14

def test_multiple_operations_with_precedence():
    assert do_algebra(['*', '+'], [2, 3, 4]) == 10

def test_complex_expression():
    assert do_algebra(['+', '-', '*'], [1, 2, 3, 4]) == -9

def test_division_with_float_result():
    assert do_algebra(['/'], [7, 2]) == 3.5

def test_power_operation():
    assert do_algebra(['**'], [2, 3]) == 8

def test_floor_division():
    assert do_algebra(['//'], [7, 2]) == 3

def test_modulo_operation():
    assert do_algebra(['%'], [10, 3]) == 1

def test_single_operand_no_operator():
    assert do_algebra([], [42]) == 42

def test_negative_numbers():
    assert do_algebra(['+'], [-5, 3]) == -2

def test_negative_result():
    assert do_algebra(['-'], [3, 5]) == -2

def test_zero_operands():
    assert do_algebra(['+', '*'], [0, 5, 2]) == 10

def test_multiplication_by_zero():
    assert do_algebra(['*'], [5, 0]) == 0

def test_mixed_operations():
    assert do_algebra(['+', '*', '-'], [2, 3, 4, 1]) == 13

def test_parentheses_not_supported():
    result = do_algebra(['+', '*'], [2, 3, 4])
    assert result == 14

def test_float_operands():
    assert do_algebra(['+'], [1.5, 2.5]) == 4.0

def test_mixed_int_float():
    assert do_algebra(['*'], [2, 3.5]) == 7.0

def test_large_numbers():
    assert do_algebra(['*'], [1000000, 1000000]) == 1000000000000

def test_division_by_zero_raises_error():
    with pytest.raises(ZeroDivisionError):
        do_algebra(['/'], [1, 0])

def test_multiple_additions():
    assert do_algebra(['+', '+', '+'], [1, 2, 3, 4]) == 10

def test_multiple_multiplications():
    assert do_algebra(['*', '*', '*'], [2, 2, 2, 2]) == 16

def test_subtraction_chain():
    assert do_algebra(['-', '-', '-'], [10, 1, 2, 3]) == 4

def test_order_of_operations():
    assert do_algebra(['+', '*', '+'], [1, 2, 3, 4]) == 11

def test_power_with_negative():
    assert do_algebra(['**'], [2, -1]) == 0.5

def test_complex_order_of_operations():
    assert do_algebra(['*', '+', '/'], [2, 3, 4, 2]) == 8.0
