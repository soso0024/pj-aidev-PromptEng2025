# Test cases for HumanEval/141
# Generated using Claude API


def file_name_check(file_name):
    """Create a function which takes a string representing a file's name, and returns
    'Yes' if the the file's name is valid, and returns 'No' otherwise.
    A file's name is considered to be valid if and only if all the following conditions 
    are met:
    - There should not be more than three digits ('0'-'9') in the file's name.
    - The file's name contains exactly one dot '.'
    - The substring before the dot should not be empty, and it starts with a letter from 
    the latin alphapet ('a'-'z' and 'A'-'Z').
    - The substring after the dot should be one of these: ['txt', 'exe', 'dll']
    Examples:
    file_name_check("example.txt") # => 'Yes'
    file_name_check("1example.dll") # => 'No' (the name should start with a latin alphapet letter)
    """

    suf = ['txt', 'exe', 'dll']
    lst = file_name.split(sep='.')
    if len(lst) != 2:
        return 'No'
    if not lst[1] in suf:
        return 'No'
    if len(lst[0]) == 0:
        return 'No'
    if not lst[0][0].isalpha():
        return 'No'
    t = len([x for x in lst[0] if x.isdigit()])
    if t > 3:
        return 'No'
    return 'Yes'


# Generated test cases:
import pytest

def file_name_check(file_name):
    suf = ['txt', 'exe', 'dll']
    lst = file_name.split(sep='.')
    if len(lst) != 2:
        return 'No'
    if not lst[1] in suf:
        return 'No'
    if len(lst[0]) == 0:
        return 'No'
    if not lst[0][0].isalpha():
        return 'No'
    t = len([x for x in lst[0] if x.isdigit()])
    if t > 3:
        return 'No'
    return 'Yes'

@pytest.mark.parametrize("file_name,expected", [
    ("example.txt", "Yes"),
    ("test.exe", "Yes"),
    ("program.dll", "Yes"),
    ("a.txt", "Yes"),
    ("A.txt", "Yes"),
    ("z.exe", "Yes"),
    ("Z.dll", "Yes"),
    ("file1.txt", "Yes"),
    ("file12.txt", "Yes"),
    ("file123.txt", "Yes"),
    ("a1b2c3.exe", "Yes"),
    ("test0.dll", "Yes"),
    ("1example.dll", "No"),
    ("9test.txt", "No"),
    (".txt", "No"),
    ("example.", "No"),
    ("example", "No"),
    ("example.txt.exe", "No"),
    ("example..txt", "No"),
    ("file1234.txt", "No"),
    ("file1234567.exe", "No"),
    ("example.doc", "No"),
    ("example.pdf", "No"),
    ("example.jpg", "No"),
    ("example.TXT", "No"),
    ("example.Txt", "No"),
    ("_test.txt", "No"),
    ("-test.txt", "No"),
    ("1.txt", "No"),
    ("123.exe", "No"),
    ("test.txt.dll", "No"),
    ("a.b.c.txt", "No"),
    ("", "No"),
    (".", "No"),
    ("..", "No"),
    ("a.", "No"),
    ("a.tx", "No"),
    ("a.text", "No"),
    ("a.e", "No"),
    ("a.d", "No"),
    ("abc.txt", "Yes"),
    ("ABC.exe", "Yes"),
    ("aBc.dll", "Yes"),
    ("a1.txt", "Yes"),
    ("a12.txt", "Yes"),
    ("a123.txt", "Yes"),
    ("a1234.txt", "No"),
    ("ab12cd34.txt", "No"),
    ("test_file.txt", "Yes"),
    ("test-file.exe", "Yes"),
    ("myFile123.dll", "Yes"),
    ("File.txt", "Yes"),
    ("f1i2l3e.txt", "Yes"),
    ("f1i2l3e4.txt", "No"),
    ("file0000.txt", "No"),
])
def test_file_name_check(file_name, expected):
    assert file_name_check(file_name) == expected

def test_valid_txt_files():
    assert file_name_check("document.txt") == "Yes"
    assert file_name_check("readme.txt") == "Yes"
    assert file_name_check("notes1.txt") == "Yes"

def test_valid_exe_files():
    assert file_name_check("setup.exe") == "Yes"
    assert file_name_check("install.exe") == "Yes"
    assert file_name_check("run1.exe") == "Yes"

def test_valid_dll_files():
    assert file_name_check("library.dll") == "Yes"
    assert file_name_check("system.dll") == "Yes"
    assert file_name_check("module1.dll") == "Yes"

def test_starts_with_digit():
    assert file_name_check("1file.txt") == "No"
    assert file_name_check("2test.exe") == "No"
    assert file_name_check("0program.dll") == "No"

def test_too_many_digits():
    assert file_name_check("file1234.txt") == "No"
    assert file_name_check("test12345.exe") == "No"
    assert file_name_check("a1b2c3d4.dll") == "No"

def test_invalid_extension():
    assert file_name_check("file.doc") == "No"
    assert file_name_check("file.pdf") == "No"
    assert file_name_check("file.jpg") == "No"
    assert file_name_check("file.png") == "No"

def test_multiple_dots():
    assert file_name_check("file.name.txt") == "No"
    assert file_name_check("test..exe") == "No"
    assert file_name_check("a.b.c.dll") == "No"

def test_no_dot():
    assert file_name_check("filename") == "No"
    assert file_name_check("test") == "No"

def test_empty_name_before_dot():
    assert file_name_check(".txt") == "No"
    assert file_name_check(".exe") == "No"
    assert file_name_check(".dll") == "No"

def test_starts_with_special_char():
    assert file_name_check("_file.txt") == "No"
    assert file_name_check("-test.exe") == "No"
    assert file_name_check("@program.dll") == "No"

def test_edge_cases_with_exactly_three_digits():
    assert file_name_check("a1b2c3.txt") == "Yes"
    assert file_name_check("x123.exe") == "Yes"
    assert file_name_check("test999.dll") == "Yes"
