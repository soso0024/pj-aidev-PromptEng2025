# Test cases for HumanEval/2
# Generated using Claude API



def truncate_number(number: float) -> float:
    """ Given a positive floating point number, it can be decomposed into
    and integer part (largest integer smaller than given number) and decimals
    (leftover part always smaller than 1).

    Return the decimal part of the number.
    >>> truncate_number(3.5)
    0.5
    """

    return number % 1.0


# Generated test cases:
import pytest

def truncate_number(number: float) -> float:
    return number % 1.0

def test_truncate_positive_decimal():
    assert truncate_number(3.5) == 0.5

def test_truncate_positive_decimal_small():
    assert abs(truncate_number(1.25) - 0.25) < 1e-10

def test_truncate_positive_decimal_large():
    assert abs(truncate_number(123.456) - 0.456) < 1e-10

def test_truncate_negative_decimal():
    result = truncate_number(-3.5)
    assert abs(result - 0.5) < 1e-10

def test_truncate_negative_decimal_small():
    result = truncate_number(-1.25)
    assert abs(result - 0.75) < 1e-10

def test_truncate_whole_number_positive():
    assert truncate_number(5.0) == 0.0

def test_truncate_whole_number_negative():
    assert truncate_number(-5.0) == 0.0

def test_truncate_zero():
    assert truncate_number(0.0) == 0.0

def test_truncate_small_positive():
    assert abs(truncate_number(0.123) - 0.123) < 1e-10

def test_truncate_small_negative():
    result = truncate_number(-0.123)
    assert abs(result - 0.877) < 1e-10

def test_truncate_almost_one():
    assert abs(truncate_number(0.999999) - 0.999999) < 1e-10

def test_truncate_large_number():
    assert abs(truncate_number(1000000.789) - 0.789) < 1e-10

def test_truncate_very_small_fraction():
    assert abs(truncate_number(5.0001) - 0.0001) < 1e-10

@pytest.mark.parametrize("number,expected", [
    (3.5, 0.5),
    (1.25, 0.25),
    (10.9, 0.9),
    (0.5, 0.5),
    (100.01, 0.01),
    (7.0, 0.0),
])
def test_truncate_parametrized_positive(number, expected):
    assert abs(truncate_number(number) - expected) < 1e-10

@pytest.mark.parametrize("number", [
    -3.5,
    -1.25,
    -10.9,
    -0.5,
])
def test_truncate_parametrized_negative(number):
    result = truncate_number(number)
    assert 0.0 <= result < 1.0

def test_truncate_integer_input():
    assert truncate_number(42) == 0.0

def test_truncate_negative_integer():
    assert truncate_number(-42) == 0.0

def test_truncate_float_precision():
    result = truncate_number(1.123456789)
    assert abs(result - 0.123456789) < 1e-9
