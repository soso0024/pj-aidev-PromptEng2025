# Test cases for HumanEval/80
# Generated using Claude API


def is_happy(s):
    """You are given a string s.
    Your task is to check if the string is happy or not.
    A string is happy if its length is at least 3 and every 3 consecutive letters are distinct
    For example:
    is_happy(a) => False
    is_happy(aa) => False
    is_happy(abcd) => True
    is_happy(aabb) => False
    is_happy(adb) => True
    is_happy(xyy) => False
    """

    if len(s) < 3:
      return False

    for i in range(len(s) - 2):
      
      if s[i] == s[i+1] or s[i+1] == s[i+2] or s[i] == s[i+2]:
        return False
    return True


# Generated test cases:
import pytest

def is_happy(s):
    if len(s) < 3:
      return False

    for i in range(len(s) - 2):
      
      if s[i] == s[i+1] or s[i+1] == s[i+2] or s[i] == s[i+2]:
        return False
    return True


@pytest.mark.parametrize("input_str,expected", [
    ("a", False),
    ("aa", False),
    ("abcd", True),
    ("aabb", False),
    ("adb", True),
    ("xyy", False),
    ("", False),
    ("ab", False),
    ("abc", True),
    ("aaa", False),
    ("aba", False),
    ("abb", False),
    ("baa", False),
    ("abcdef", True),
    ("abcabc", True),
    ("abccba", False),
    ("xyz", True),
    ("xyx", False),
    ("xxy", False),
    ("yxx", False),
    ("abcdefghijk", True),
    ("abcdefghijka", True),
    ("abcdefghijaa", False),
    ("abab", False),
    ("ababab", False),
    ("aabab", False),
    ("ababa", False),
    ("ababaa", False),
    ("123", True),
    ("112", False),
    ("121", False),
    ("122", False),
    ("1234567890", True),
    ("12345678900", False),
    ("abcdefg", True),
    ("abcdeff", False),
    ("abcdeef", False),
    ("abcddef", False),
    ("abcddeg", False),
])
def test_is_happy(input_str, expected):
    assert is_happy(input_str) == expected


def test_is_happy_single_char():
    assert is_happy("x") == False


def test_is_happy_two_chars_same():
    assert is_happy("xx") == False


def test_is_happy_two_chars_different():
    assert is_happy("xy") == False


def test_is_happy_three_chars_all_same():
    assert is_happy("xxx") == False


def test_is_happy_three_chars_first_two_same():
    assert is_happy("xxy") == False


def test_is_happy_three_chars_last_two_same():
    assert is_happy("xyy") == False


def test_is_happy_three_chars_first_last_same():
    assert is_happy("xyx") == False


def test_is_happy_three_chars_all_different():
    assert is_happy("xyz") == True


def test_is_happy_empty_string():
    assert is_happy("") == False


def test_is_happy_long_happy_string():
    assert is_happy("abcdefghijklmnopqrstuvwxyz") == True


def test_is_happy_long_unhappy_string_with_repeat():
    assert is_happy("abcdefghijklmnopqrstuvwxyyz") == False


def test_is_happy_alternating_pattern():
    assert is_happy("ababababab") == False


def test_is_happy_alternating_pattern_broken():
    assert is_happy("abababaabb") == False