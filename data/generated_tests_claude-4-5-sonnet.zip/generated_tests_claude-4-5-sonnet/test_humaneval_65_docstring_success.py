# Test cases for HumanEval/65
# Generated using Claude API


def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.
    >>> circular_shift(12, 1)
    "21"
    >>> circular_shift(12, 2)
    "12"
    """

    s = str(x)
    if shift > len(s):
        return s[::-1]
    else:
        return s[len(s) - shift:] + s[:len(s) - shift]


# Generated test cases:
import pytest

def circular_shift(x, shift):
    s = str(x)
    if shift > len(s):
        return s[::-1]
    else:
        return s[len(s) - shift:] + s[:len(s) - shift]

def test_circular_shift_basic_example_1():
    assert circular_shift(12, 1) == "21"

def test_circular_shift_basic_example_2():
    assert circular_shift(12, 2) == "12"

def test_circular_shift_zero_shift():
    assert circular_shift(12345, 0) == "12345"

def test_circular_shift_single_digit():
    assert circular_shift(5, 1) == "5"

def test_circular_shift_single_digit_zero_shift():
    assert circular_shift(7, 0) == "7"

def test_circular_shift_single_digit_large_shift():
    assert circular_shift(9, 5) == "9"

def test_circular_shift_shift_equals_length():
    assert circular_shift(123, 3) == "123"

def test_circular_shift_shift_greater_than_length():
    assert circular_shift(12345, 10) == "54321"

def test_circular_shift_shift_one_more_than_length():
    assert circular_shift(123, 4) == "321"

def test_circular_shift_three_digits_shift_one():
    assert circular_shift(123, 1) == "312"

def test_circular_shift_three_digits_shift_two():
    assert circular_shift(123, 2) == "231"

def test_circular_shift_large_number():
    assert circular_shift(123456789, 3) == "789123456"

def test_circular_shift_large_number_large_shift():
    assert circular_shift(123456789, 20) == "987654321"

def test_circular_shift_zero_value():
    assert circular_shift(0, 1) == "0"

def test_circular_shift_zero_value_zero_shift():
    assert circular_shift(0, 0) == "0"

def test_circular_shift_zero_value_large_shift():
    assert circular_shift(0, 10) == "0"

def test_circular_shift_negative_number():
    assert circular_shift(-123, 1) == "3-12"

def test_circular_shift_negative_number_large_shift():
    assert circular_shift(-123, 10) == "321-"

def test_circular_shift_two_digit_shift_one():
    assert circular_shift(99, 1) == "99"

def test_circular_shift_palindrome():
    assert circular_shift(121, 1) == "112"

def test_circular_shift_all_same_digits():
    assert circular_shift(1111, 2) == "1111"

@pytest.mark.parametrize("x,shift,expected", [
    (12, 1, "21"),
    (12, 2, "12"),
    (123, 1, "312"),
    (123, 2, "231"),
    (123, 3, "123"),
    (123, 4, "321"),
    (1, 0, "1"),
    (1, 1, "1"),
    (1, 2, "1"),
    (100, 1, "010"),
    (100, 2, "001"),
    (100, 5, "001"),
    (54321, 2, "21543"),
])
def test_circular_shift_parametrized(x, shift, expected):
    assert circular_shift(x, shift) == expected