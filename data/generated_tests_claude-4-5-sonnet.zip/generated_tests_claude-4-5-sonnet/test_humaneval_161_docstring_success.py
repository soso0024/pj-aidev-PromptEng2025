# Test cases for HumanEval/161
# Generated using Claude API


def solve(s):
    """You are given a string s.
    if s[i] is a letter, reverse its case from lower to upper or vise versa, 
    otherwise keep it as it is.
    If the string contains no letters, reverse the string.
    The function should return the resulted string.
    Examples
    solve("1234") = "4321"
    solve("ab") = "AB"
    solve("#a@C") = "#A@c"
    """

    flg = 0
    idx = 0
    new_str = list(s)
    for i in s:
        if i.isalpha():
            new_str[idx] = i.swapcase()
            flg = 1
        idx += 1
    s = ""
    for i in new_str:
        s += i
    if flg == 0:
        return s[len(s)::-1]
    return s


# Generated test cases:
import pytest

def solve(s):
    flg = 0
    idx = 0
    new_str = list(s)
    for i in s:
        if i.isalpha():
            new_str[idx] = i.swapcase()
            flg = 1
        idx += 1
    s = ""
    for i in new_str:
        s += i
    if flg == 0:
        return s[len(s)::-1]
    return s


@pytest.mark.parametrize("input_str,expected", [
    ("1234", "4321"),
    ("ab", "AB"),
    ("#a@C", "#A@c"),
    ("", ""),
    ("ABC", "abc"),
    ("xyz", "XYZ"),
    ("AbCdEf", "aBcDeF"),
    ("12345", "54321"),
    ("!@#$%", "%$#@!"),
    ("a", "A"),
    ("Z", "z"),
    ("123abc456", "123ABC456"),
    ("Hello World", "hELLO wORLD"),
    ("!@#", "!@#"[::-1]),
    ("a1b2c3", "A1B2C3"),
    ("NoLettersHere123", "nOlETTERShERE123"),
    ("   ", "   "),
    ("123 456", "654 321"),
    ("aB1cD2", "Ab1Cd2"),
    ("!a!", "!A!"),
    ("!!!", "!!!"),
    ("aBc123XyZ", "AbC123xYz"),
    ("UPPER", "upper"),
    ("lower", "LOWER"),
    ("MiXeD", "mIxEd"),
    ("123", "321"),
    ("   abc   ", "   ABC   "),
    ("@#$%^&*()", ")(*&^%$#@"),
    ("a1", "A1"),
    ("1a", "1A"),
    ("AaBbCc", "aAbBcC"),
])
def test_solve_parametrized(input_str, expected):
    assert solve(input_str) == expected


def test_solve_empty_string():
    assert solve("") == ""


def test_solve_only_numbers():
    assert solve("1234") == "4321"
    assert solve("0") == "0"
    assert solve("999") == "999"


def test_solve_only_letters_lowercase():
    assert solve("abc") == "ABC"
    assert solve("z") == "Z"


def test_solve_only_letters_uppercase():
    assert solve("ABC") == "abc"
    assert solve("Z") == "z"


def test_solve_mixed_case_letters():
    assert solve("AaBbCc") == "aAbBcC"
    assert solve("HeLLo") == "hEllO"


def test_solve_letters_and_numbers():
    assert solve("a1b2c3") == "A1B2C3"
    assert solve("123abc") == "123ABC"


def test_solve_special_characters_only():
    assert solve("!@#$") == "$#@!"
    assert solve("!!!") == "!!!"


def test_solve_mixed_with_special_chars():
    assert solve("#a@C") == "#A@c"
    assert solve("!A!b!") == "!a!B!"


def test_solve_spaces():
    assert solve("   ") == "   "
    assert solve("a b c") == "A B C"
    assert solve("1 2 3") == "3 2 1"


def test_solve_single_character():
    assert solve("a") == "A"
    assert solve("Z") == "z"
    assert solve("1") == "1"
    assert solve("!") == "!"


def test_solve_long_string_no_letters():
    assert solve("1234567890") == "0987654321"


def test_solve_long_string_with_letters():
    result = solve("abcdefghijklmnopqrstuvwxyz")
    expected = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    assert result == expected
