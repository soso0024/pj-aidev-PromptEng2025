# Test cases for HumanEval/162
# Generated using Claude API


def string_to_md5(text):
    """
    Given a string 'text', return its md5 hash equivalent string.
    If 'text' is an empty string, return None.

    >>> string_to_md5('Hello world') == '3e25960a79dbc69b674cd4ec67a72c62'
    """

    import hashlib
    return hashlib.md5(text.encode('ascii')).hexdigest() if text else None


# Generated test cases:
import pytest
import hashlib


def string_to_md5(text):
    return hashlib.md5(text.encode('ascii')).hexdigest() if text else None


def test_string_to_md5_empty_string():
    assert string_to_md5('') is None


def test_string_to_md5_none():
    assert string_to_md5(None) is None


def test_string_to_md5_simple_string():
    result = string_to_md5('hello')
    expected = hashlib.md5('hello'.encode('ascii')).hexdigest()
    assert result == expected


def test_string_to_md5_with_spaces():
    result = string_to_md5('hello world')
    expected = hashlib.md5('hello world'.encode('ascii')).hexdigest()
    assert result == expected


def test_string_to_md5_with_numbers():
    result = string_to_md5('12345')
    expected = hashlib.md5('12345'.encode('ascii')).hexdigest()
    assert result == expected


def test_string_to_md5_with_special_chars():
    result = string_to_md5('!@#$%^&*()')
    expected = hashlib.md5('!@#$%^&*()'.encode('ascii')).hexdigest()
    assert result == expected


def test_string_to_md5_alphanumeric():
    result = string_to_md5('abc123XYZ')
    expected = hashlib.md5('abc123XYZ'.encode('ascii')).hexdigest()
    assert result == expected


def test_string_to_md5_single_char():
    result = string_to_md5('a')
    expected = hashlib.md5('a'.encode('ascii')).hexdigest()
    assert result == expected


def test_string_to_md5_long_string():
    text = 'a' * 1000
    result = string_to_md5(text)
    expected = hashlib.md5(text.encode('ascii')).hexdigest()
    assert result == expected


def test_string_to_md5_returns_hexdigest():
    result = string_to_md5('test')
    assert isinstance(result, str)
    assert len(result) == 32
    assert all(c in '0123456789abcdef' for c in result)


@pytest.mark.parametrize("input_text,expected_hash", [
    ('hello', '5d41402abc4b2a76b9719d911017c592'),
    ('world', '7d793037a0760186574b0282f2f435e7'),
    ('A', '7fc56270e7a70fa81a5935b72eacbe29'),
])
def test_string_to_md5_known_hashes(input_text, expected_hash):
    assert string_to_md5(input_text) == expected_hash


def test_string_to_md5_zero_string():
    result = string_to_md5('0')
    expected = hashlib.md5('0'.encode('ascii')).hexdigest()
    assert result == expected