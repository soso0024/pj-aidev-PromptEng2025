# Test cases for HumanEval/55
# Generated using Claude API



def fib(n: int):
    """Return n-th Fibonacci number.
    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """

    if n == 0:
        return 0
    if n == 1:
        return 1
    return fib(n - 1) + fib(n - 2)


# Generated test cases:
import pytest

def fib(n: int):
    if n == 0:
        return 0
    if n == 1:
        return 1
    return fib(n - 1) + fib(n - 2)

def test_fib_base_case_zero():
    assert fib(0) == 0

def test_fib_base_case_one():
    assert fib(1) == 1

def test_fib_small_values():
    assert fib(2) == 1
    assert fib(3) == 2
    assert fib(4) == 3
    assert fib(5) == 5

def test_fib_medium_values():
    assert fib(6) == 8
    assert fib(7) == 13
    assert fib(8) == 21
    assert fib(9) == 34
    assert fib(10) == 55

@pytest.mark.parametrize("n,expected", [
    (0, 0),
    (1, 1),
    (2, 1),
    (3, 2),
    (4, 3),
    (5, 5),
    (6, 8),
    (7, 13),
    (8, 21),
    (9, 34),
    (10, 55),
    (11, 89),
    (12, 144),
    (13, 233),
    (14, 377),
    (15, 610)
])
def test_fib_parametrized(n, expected):
    assert fib(n) == expected

def test_fib_sequence_property():
    for i in range(2, 15):
        assert fib(i) == fib(i - 1) + fib(i - 2)

def test_fib_increasing():
    for i in range(1, 15):
        assert fib(i) >= fib(i - 1)

def test_fib_return_type():
    assert isinstance(fib(0), int)
    assert isinstance(fib(5), int)
    assert isinstance(fib(10), int)
