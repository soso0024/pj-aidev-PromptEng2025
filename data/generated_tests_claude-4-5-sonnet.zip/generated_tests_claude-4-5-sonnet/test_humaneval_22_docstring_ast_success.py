# Test cases for HumanEval/22
# Generated using Claude API

from typing import List, Any


def filter_integers(values: List[Any]) -> List[int]:
    """ Filter given list of any python values only for integers
    >>> filter_integers(['a', 3.14, 5])
    [5]
    >>> filter_integers([1, 2, 3, 'abc', {}, []])
    [1, 2, 3]
    """

    return [x for x in values if isinstance(x, int)]


# Generated test cases:
import pytest
from typing import List, Any


def filter_integers(values: List[Any]) -> List[int]:
    return [x for x in values if isinstance(x, int)]


class TestFilterIntegers:
    
    def test_mixed_types_with_string_float_int(self):
        assert filter_integers(['a', 3.14, 5]) == [5]
    
    def test_integers_and_other_types(self):
        assert filter_integers([1, 2, 3, 'abc', {}, []]) == [1, 2, 3]
    
    def test_empty_list(self):
        assert filter_integers([]) == []
    
    def test_only_integers(self):
        assert filter_integers([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    
    def test_no_integers(self):
        assert filter_integers(['a', 'b', 'c', 3.14, 2.71, [], {}, None]) == []
    
    def test_negative_integers(self):
        assert filter_integers([-1, -2, -3, 'test']) == [-1, -2, -3]
    
    def test_zero(self):
        assert filter_integers([0, 'zero', 0.0]) == [0]
    
    def test_boolean_values(self):
        assert filter_integers([True, False, 1, 0]) == [True, False, 1, 0]
    
    def test_none_values(self):
        assert filter_integers([None, 1, None, 2]) == [1, 2]
    
    def test_nested_lists(self):
        assert filter_integers([[1, 2], [3, 4], 5]) == [5]
    
    def test_nested_dicts(self):
        assert filter_integers([{'a': 1}, {'b': 2}, 3]) == [3]
    
    def test_floats_only(self):
        assert filter_integers([1.1, 2.2, 3.3, 4.4]) == []
    
    def test_strings_only(self):
        assert filter_integers(['1', '2', '3']) == []
    
    def test_mixed_with_tuples(self):
        assert filter_integers([1, (2, 3), 4, 'test']) == [1, 4]
    
    def test_large_integers(self):
        assert filter_integers([1000000, 'large', 999999999999]) == [1000000, 999999999999]
    
    def test_mixed_numeric_types(self):
        assert filter_integers([1, 1.0, 1.5, 2, 2.0, 2.5]) == [1, 2]
    
    def test_complex_numbers(self):
        assert filter_integers([1, 2+3j, 3, 4+0j]) == [1, 3]
    
    def test_sets(self):
        assert filter_integers([{1, 2}, 3, {4, 5}]) == [3]
    
    def test_callable_objects(self):
        assert filter_integers([lambda x: x, 1, print, 2]) == [1, 2]
    
    def test_class_instances(self):
        class CustomClass:
            pass
        obj = CustomClass()
        assert filter_integers([obj, 1, 2]) == [1, 2]


@pytest.mark.parametrize("input_list,expected", [
    ([1, 2, 3], [1, 2, 3]),
    ([], []),
    (['a', 'b', 'c'], []),
    ([1.5, 2.5, 3.5], []),
    ([1, 'a', 2, 'b', 3], [1, 2, 3]),
    ([0], [0]),
    ([-1, -2, -3], [-1, -2, -3]),
    ([True, False], [True, False]),
    ([None, None], []),
    ([[1], [2], 3], [3]),
])
def test_filter_integers_parametrized(input_list, expected):
    assert filter_integers(input_list) == expected
