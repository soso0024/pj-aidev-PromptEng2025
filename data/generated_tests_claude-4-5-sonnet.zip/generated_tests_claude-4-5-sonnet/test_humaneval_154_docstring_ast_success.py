# Test cases for HumanEval/154
# Generated using Claude API


def cycpattern_check(a , b):
    """You are given 2 words. You need to return True if the second word or any of its rotations is a substring in the first word
    cycpattern_check("abcd","abd") => False
    cycpattern_check("hello","ell") => True
    cycpattern_check("whassup","psus") => False
    cycpattern_check("abab","baa") => True
    cycpattern_check("efef","eeff") => False
    cycpattern_check("himenss","simen") => True

    """

    l = len(b)
    pat = b + b
    for i in range(len(a) - l + 1):
        for j in range(l + 1):
            if a[i:i+l] == pat[j:j+l]:
                return True
    return False


# Generated test cases:
import pytest

def cycpattern_check(a , b):
    l = len(b)
    pat = b + b
    for i in range(len(a) - l + 1):
        for j in range(l + 1):
            if a[i:i+l] == pat[j:j+l]:
                return True
    return False

@pytest.mark.parametrize("a,b,expected", [
    ("abcd", "abd", False),
    ("hello", "ell", True),
    ("whassup", "psus", False),
    ("abab", "baa", True),
    ("efef", "eeff", False),
    ("himenss", "simen", True),
    ("", "", True),
    ("a", "", True),
    ("", "a", False),
    ("abc", "abc", True),
    ("abc", "bca", True),
    ("abc", "cab", True),
    ("abcdef", "def", True),
    ("abcdef", "fed", False),
    ("abcdef", "efd", True),
    ("test", "stte", True),
    ("rotation", "ationr", False),
    ("rotation", "tionro", False),
    ("rotation", "onrota", False),
    ("rotation", "notaro", False),
    ("aaa", "aa", True),
    ("aaa", "aaa", True),
    ("aaa", "aaaa", False),
    ("abcabc", "abc", True),
    ("abcabc", "bca", True),
    ("abcabc", "cab", True),
    ("xyzxyz", "zxy", True),
    ("xyzxyz", "yzx", True),
    ("single", "ngle", True),
    ("single", "gles", False),
    ("single", "esin", False),
    ("single", "nglesi", True),
    ("abcdefgh", "cdefgh", True),
    ("abcdefgh", "habcde", False),
    ("test123", "123", True),
    ("test123", "231", True),
    ("test123", "312", True),
    ("test123", "321", False),
    ("a", "a", True),
    ("ab", "a", True),
    ("ab", "b", True),
    ("ab", "ba", True),
    ("abc", "d", False),
    ("abcdefghij", "fghij", True),
    ("abcdefghij", "jfghi", True),
    ("mississippi", "issip", True),
    ("mississippi", "sipis", True),
])
def test_cycpattern_check(a, b, expected):
    assert cycpattern_check(a, b) == expected

def test_cycpattern_check_empty_strings():
    assert cycpattern_check("", "") == True

def test_cycpattern_check_empty_first():
    assert cycpattern_check("", "abc") == False

def test_cycpattern_check_empty_second():
    assert cycpattern_check("abc", "") == True

def test_cycpattern_check_single_char_match():
    assert cycpattern_check("a", "a") == True

def test_cycpattern_check_single_char_no_match():
    assert cycpattern_check("a", "b") == False

def test_cycpattern_check_longer_pattern():
    assert cycpattern_check("short", "verylongpattern") == False

def test_cycpattern_check_same_length():
    assert cycpattern_check("abc", "abc") == True
    assert cycpattern_check("abc", "bca") == True
    assert cycpattern_check("abc", "xyz") == False

def test_cycpattern_check_repeated_chars():
    assert cycpattern_check("aaaa", "aa") == True
    assert cycpattern_check("aaaa", "aaa") == True
    assert cycpattern_check("aaaa", "aaaa") == True