# Test cases for HumanEval/10
# Generated using Claude API



def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """ Find the shortest palindrome that begins with a supplied string.
    Algorithm idea is simple:
    - Find the longest postfix of supplied string that is a palindrome.
    - Append to the end of the string reverse of a string prefix that comes before the palindromic suffix.
    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    """

    if not string:
        return ''

    beginning_of_suffix = 0

    while not is_palindrome(string[beginning_of_suffix:]):
        beginning_of_suffix += 1

    return string + string[:beginning_of_suffix][::-1]


# Generated test cases:
import pytest

def is_palindrome(s: str) -> bool:
    return s == s[::-1]

def make_palindrome(string: str) -> str:
    if not string:
        return ''

    beginning_of_suffix = 0

    while not is_palindrome(string[beginning_of_suffix:]):
        beginning_of_suffix += 1

    return string + string[:beginning_of_suffix][::-1]

def test_empty_string():
    assert make_palindrome('') == ''

def test_single_character():
    assert make_palindrome('a') == 'a'
    assert is_palindrome(make_palindrome('a'))

def test_already_palindrome():
    assert make_palindrome('aba') == 'aba'
    assert make_palindrome('racecar') == 'racecar'
    assert make_palindrome('noon') == 'noon'
    assert is_palindrome(make_palindrome('aba'))

def test_two_characters_same():
    assert make_palindrome('aa') == 'aa'
    assert is_palindrome(make_palindrome('aa'))

def test_two_characters_different():
    result = make_palindrome('ab')
    assert is_palindrome(result)
    assert result == 'aba'

def test_simple_strings():
    result = make_palindrome('cat')
    assert is_palindrome(result)
    assert result == 'catac'

def test_longer_strings():
    result = make_palindrome('race')
    assert is_palindrome(result)
    assert result == 'racecar'

def test_string_needs_one_char():
    result = make_palindrome('abc')
    assert is_palindrome(result)
    assert result == 'abcba'

def test_string_needs_multiple_chars():
    result = make_palindrome('abcd')
    assert is_palindrome(result)
    assert result == 'abcdcba'

def test_string_with_repeated_chars():
    result = make_palindrome('aab')
    assert is_palindrome(result)
    assert result == 'aabaa'

def test_string_ending_with_palindrome():
    result = make_palindrome('abcc')
    assert is_palindrome(result)
    assert result == 'abccba'

@pytest.mark.parametrize("input_str,expected", [
    ('', ''),
    ('a', 'a'),
    ('ab', 'aba'),
    ('abc', 'abcba'),
    ('cat', 'catac'),
    ('race', 'racecar'),
    ('aba', 'aba'),
    ('noon', 'noon'),
    ('abcd', 'abcdcba'),
    ('xyz', 'xyzyx'),
])
def test_parametrized_cases(input_str, expected):
    result = make_palindrome(input_str)
    assert result == expected
    assert is_palindrome(result)

def test_all_results_are_palindromes():
    test_strings = ['a', 'ab', 'abc', 'abcd', 'test', 'hello', 'world', 'python', 'x', 'xy', 'xyz']
    for s in test_strings:
        result = make_palindrome(s)
        assert is_palindrome(result), f"Result '{result}' for input '{s}' is not a palindrome"

def test_result_starts_with_original():
    test_strings = ['a', 'ab', 'abc', 'test', 'hello']
    for s in test_strings:
        result = make_palindrome(s)
        assert result.startswith(s), f"Result '{result}' does not start with original '{s}'"

def test_minimal_length_palindrome():
    result = make_palindrome('abc')
    assert len(result) == 5
    assert result == 'abcba'
