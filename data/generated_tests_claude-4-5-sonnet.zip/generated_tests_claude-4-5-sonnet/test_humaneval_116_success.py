# Test cases for HumanEval/116
# Generated using Claude API


def sort_array(arr):
    """
    In this Kata, you have to sort an array of non-negative integers according to
    number of ones in their binary representation in ascending order.
    For similar number of ones, sort based on decimal value.

    It must be implemented like this:
    >>> sort_array([1, 5, 2, 3, 4]) == [1, 2, 3, 4, 5]
    >>> sort_array([-2, -3, -4, -5, -6]) == [-6, -5, -4, -3, -2]
    >>> sort_array([1, 0, 2, 3, 4]) [0, 1, 2, 3, 4]
    """

    return sorted(sorted(arr), key=lambda x: bin(x)[2:].count('1'))


# Generated test cases:
import pytest

def sort_array(arr):
    return sorted(sorted(arr), key=lambda x: bin(x)[2:].count('1'))

def test_empty_array():
    assert sort_array([]) == []

def test_single_element():
    assert sort_array([5]) == [5]

def test_two_elements_same_bit_count():
    assert sort_array([3, 5]) == [3, 5]

def test_two_elements_different_bit_count():
    assert sort_array([1, 2]) == [1, 2]

def test_ascending_order_same_bit_count():
    assert sort_array([1, 3, 5, 7]) == [1, 3, 5, 7]

def test_descending_order_same_bit_count():
    assert sort_array([7, 5, 3, 1]) == [1, 3, 5, 7]

def test_mixed_bit_counts():
    assert sort_array([1, 2, 3, 4, 5]) == [1, 2, 4, 3, 5]

def test_all_zeros():
    assert sort_array([0]) == [0]

def test_multiple_zeros():
    assert sort_array([0, 0, 0]) == [0, 0, 0]

def test_powers_of_two():
    assert sort_array([8, 4, 2, 1]) == [1, 2, 4, 8]

def test_same_elements():
    assert sort_array([5, 5, 5, 5]) == [5, 5, 5, 5]

def test_large_numbers():
    assert sort_array([15, 16, 31, 32]) == [16, 32, 15, 31]

def test_complex_case():
    assert sort_array([1, 5, 2, 3, 4, 6, 7, 8]) == [1, 2, 4, 8, 3, 5, 6, 7]

def test_bit_count_grouping():
    result = sort_array([7, 8, 9, 10, 11, 12, 13, 14, 15])
    assert result == [8, 9, 10, 12, 7, 11, 13, 14, 15]

def test_negative_and_positive():
    assert sort_array([0, 1, 2]) == [0, 1, 2]

def test_unsorted_with_duplicates():
    assert sort_array([3, 1, 2, 4, 5, 3]) == [1, 2, 4, 3, 3, 5]

def test_reverse_sorted():
    assert sort_array([10, 9, 8, 7, 6, 5, 4, 3, 2, 1]) == [1, 2, 4, 8, 3, 5, 6, 9, 10, 7]

def test_already_sorted_by_bits():
    assert sort_array([0, 1, 2, 3]) == [0, 1, 2, 3]

def test_large_array():
    arr = list(range(20))
    result = sort_array(arr)
    assert len(result) == 20
    assert sorted(result) == arr

@pytest.mark.parametrize("input_arr,expected", [
    ([1, 2, 3], [1, 2, 3]),
    ([3, 2, 1], [1, 2, 3]),
    ([4, 5, 6], [4, 5, 6]),
    ([8, 7, 6], [8, 6, 7]),
])
def test_parametrized_cases(input_arr, expected):
    assert sort_array(input_arr) == expected