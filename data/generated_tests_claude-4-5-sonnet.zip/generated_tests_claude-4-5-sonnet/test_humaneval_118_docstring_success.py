# Test cases for HumanEval/118
# Generated using Claude API


def get_closest_vowel(word):
    """You are given a word. Your task is to find the closest vowel that stands between 
    two consonants from the right side of the word (case sensitive).
    
    Vowels in the beginning and ending doesn't count. Return empty string if you didn't
    find any vowel met the above condition. 

    You may assume that the given string contains English letter only.

    Example:
    get_closest_vowel("yogurt") ==> "u"
    get_closest_vowel("FULL") ==> "U"
    get_closest_vowel("quick") ==> ""
    get_closest_vowel("ab") ==> ""
    """

    if len(word) < 3:
        return ""

    vowels = {"a", "e", "i", "o", "u", "A", "E", 'O', 'U', 'I'}
    for i in range(len(word)-2, 0, -1):
        if word[i] in vowels:
            if (word[i+1] not in vowels) and (word[i-1] not in vowels):
                return word[i]
    return ""


# Generated test cases:
import pytest

def get_closest_vowel(word):
    if len(word) < 3:
        return ""

    vowels = {"a", "e", "i", "o", "u", "A", "E", 'O', 'U', 'I'}
    for i in range(len(word)-2, 0, -1):
        if word[i] in vowels:
            if (word[i+1] not in vowels) and (word[i-1] not in vowels):
                return word[i]
    return ""

@pytest.mark.parametrize("word,expected", [
    ("yogurt", "u"),
    ("FULL", "U"),
    ("quick", ""),
    ("ab", ""),
    ("a", ""),
    ("", ""),
    ("abc", ""),
    ("bcd", ""),
    ("cat", "a"),
    ("dog", "o"),
    ("test", "e"),
    ("TEST", "E"),
    ("beautiful", "u"),
    ("BEAUTIFUL", "U"),
    ("aei", ""),
    ("aeo", ""),
    ("bae", ""),
    ("eab", ""),
    ("bac", "a"),
    ("cab", "a"),
    ("bad", "a"),
    ("dab", "a"),
    ("bAd", "A"),
    ("dAb", "A"),
    ("consonant", "a"),
    ("CONSONANT", "A"),
    ("rhythm", ""),
    ("sky", ""),
    ("fly", ""),
    ("gym", ""),
    ("aaa", ""),
    ("bbb", ""),
    ("aba", ""),
    ("bab", "a"),
    ("abcde", ""),
    ("bcade", "a"),
    ("bcdae", ""),
    ("bcaed", ""),
    ("aeiou", ""),
    ("bcdefg", "e"),
    ("bAcDeFg", "e"),
    ("BaCdEfG", "E"),
    ("apple", ""),
    ("orange", "a"),
    ("ORANGE", "A"),
    ("banana", "a"),
    ("BANANA", "A"),
    ("grape", "a"),
    ("GRAPE", "A"),
    ("melon", "o"),
    ("MELON", "O"),
    ("lemon", "o"),
    ("LEMON", "O"),
    ("peach", ""),
    ("PEACH", ""),
    ("pear", ""),
    ("PEAR", ""),
    ("plum", "u"),
    ("PLUM", "U"),
    ("kiwi", "i"),
    ("KIWI", "I"),
    ("mango", "a"),
    ("MANGO", "A"),
    ("cherry", "e"),
    ("CHERRY", "E"),
    ("strawberry", "e"),
    ("STRAWBERRY", "E"),
    ("blueberry", "e"),
    ("BLUEBERRY", "E"),
    ("raspberry", "e"),
    ("RASPBERRY", "E"),
    ("blackberry", "e"),
    ("BLACKBERRY", "E"),
    ("watermelon", "o"),
    ("WATERMELON", "O"),
    ("pineapple", "i"),
    ("PINEAPPLE", "I"),
    ("grapefruit", "e"),
    ("GRAPEFRUIT", "E"),
    ("coconut", "u"),
    ("COCONUT", "U"),
    ("papaya", "a"),
    ("PAPAYA", "A"),
    ("avocado", "a"),
    ("AVOCADO", "A"),
    ("bcd", ""),
    ("bcdefghijk", "i"),
    ("bcdefghijka", "i"),
    ("abcdefghijk", "i"),
    ("bcadefghijk", "i"),
    ("bcdefaghijk", "i"),
    ("bcdefghiajk", "e"),
    ("bcdefghijak", "a"),
])
def test_get_closest_vowel(word, expected):
    assert get_closest_vowel(word) == expected

def test_get_closest_vowel_empty_string():
    assert get_closest_vowel("") == ""

def test_get_closest_vowel_single_char():
    assert get_closest_vowel("a") == ""
    assert get_closest_vowel("b") == ""

def test_get_closest_vowel_two_chars():
    assert get_closest_vowel("ab") == ""
    assert get_closest_vowel("ba") == ""
    assert get_closest_vowel("ae") == ""
    assert get_closest_vowel("bc") == ""

def test_get_closest_vowel_three_chars_no_vowel():
    assert get_closest_vowel("bcd") == ""

def test_get_closest_vowel_three_chars_with_vowel():
    assert get_closest_vowel("bac") == "a"
    assert get_closest_vowel("bad") == "a"

def test_get_closest_vowel_vowel_at_edges():
    assert get_closest_vowel("abc") == ""
    assert get_closest_vowel("cba") == ""

def test_get_closest_vowel_multiple_vowels():
    assert get_closest_vowel("beautiful") == "u"
    assert get_closest_vowel("education") == "a"

def test_get_closest_vowel_case_sensitive():
    assert get_closest_vowel("bAd") == "A"
    assert get_closest_vowel("bad") == "a"
    assert get_closest_vowel("FULL") == "U"
    assert get_closest_vowel("full") == "u"

def test_get_closest_vowel_consecutive_vowels():
    assert get_closest_vowel("aei") == ""
    assert get_closest_vowel("bae") == ""
    assert get_closest_vowel("eab") == ""

def test_get_closest_vowel_all_consonants():
    assert get_closest_vowel("bcdfg") == ""
    assert get_closest_vowel("rhythm") == ""

def test_get_closest_vowel_all_vowels():
    assert get_closest_vowel("aeiou") == ""
    assert get_closest_vowel("AEIOU") == ""