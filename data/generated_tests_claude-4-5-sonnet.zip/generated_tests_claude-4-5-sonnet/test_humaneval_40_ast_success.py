# Test cases for HumanEval/40
# Generated using Claude API



def triples_sum_to_zero(l: list):
    """
    triples_sum_to_zero takes a list of integers as an input.
    it returns True if there are three distinct elements in the list that
    sum to zero, and False otherwise.

    >>> triples_sum_to_zero([1, 3, 5, 0])
    False
    >>> triples_sum_to_zero([1, 3, -2, 1])
    True
    >>> triples_sum_to_zero([1, 2, 3, 7])
    False
    >>> triples_sum_to_zero([2, 4, -5, 3, 9, 7])
    True
    >>> triples_sum_to_zero([1])
    False
    """

    for i in range(len(l)):
        for j in range(i + 1, len(l)):
            for k in range(j + 1, len(l)):
                if l[i] + l[j] + l[k] == 0:
                    return True
    return False


# Generated test cases:
import pytest

def triples_sum_to_zero(l: list):
    for i in range(len(l)):
        for j in range(i + 1, len(l)):
            for k in range(j + 1, len(l)):
                if l[i] + l[j] + l[k] == 0:
                    return True
    return False

def test_triples_sum_to_zero_empty_list():
    assert triples_sum_to_zero([]) == False

def test_triples_sum_to_zero_single_element():
    assert triples_sum_to_zero([0]) == False

def test_triples_sum_to_zero_two_elements():
    assert triples_sum_to_zero([0, 0]) == False

def test_triples_sum_to_zero_three_zeros():
    assert triples_sum_to_zero([0, 0, 0]) == True

def test_triples_sum_to_zero_simple_case():
    assert triples_sum_to_zero([1, -1, 0]) == True

def test_triples_sum_to_zero_no_triple():
    assert triples_sum_to_zero([1, 2, 3]) == False

def test_triples_sum_to_zero_negative_numbers():
    assert triples_sum_to_zero([-1, -2, -3]) == False

def test_triples_sum_to_zero_mixed_numbers():
    assert triples_sum_to_zero([1, 2, -3, 4]) == True

def test_triples_sum_to_zero_multiple_triples():
    assert triples_sum_to_zero([1, -1, 0, 2, -2]) == True

def test_triples_sum_to_zero_large_numbers():
    assert triples_sum_to_zero([100, -50, -50]) == True

def test_triples_sum_to_zero_no_match_large_list():
    assert triples_sum_to_zero([1, 2, 3, 4, 5, 6]) == False

def test_triples_sum_to_zero_match_at_end():
    assert triples_sum_to_zero([1, 2, 3, 4, 5, -9]) == True

def test_triples_sum_to_zero_match_at_beginning():
    assert triples_sum_to_zero([1, 2, -3, 4, 5, 6]) == True

def test_triples_sum_to_zero_duplicates():
    assert triples_sum_to_zero([1, 1, 1, -2]) == True

def test_triples_sum_to_zero_duplicates_sum_zero():
    assert triples_sum_to_zero([2, 2, -4]) == True

def test_triples_sum_to_zero_all_same_positive():
    assert triples_sum_to_zero([5, 5, 5, 5]) == False

def test_triples_sum_to_zero_all_same_negative():
    assert triples_sum_to_zero([-5, -5, -5, -5]) == False

def test_triples_sum_to_zero_complex_case():
    assert triples_sum_to_zero([10, -5, -5, 3, 7, -10]) == True

def test_triples_sum_to_zero_four_elements_no_match():
    assert triples_sum_to_zero([1, 2, 4, 8]) == False

def test_triples_sum_to_zero_four_elements_with_match():
    assert triples_sum_to_zero([1, 2, -3, 4]) == True

@pytest.mark.parametrize("input_list,expected", [
    ([1, 3, 5, 0], False),
    ([1, 3, -2, 1], True),
    ([1, 2, 3, 7], False),
    ([2, 4, -5, 3, 9, 7], True),
    ([1], False),
    ([1, 1], False),
    ([0, 1, 1], False),
    ([-1, 0, 1], True),
    ([5, -5, 0], True),
    ([10, 20, 30], False),
])
def test_triples_sum_to_zero_parametrized(input_list, expected):
    assert triples_sum_to_zero(input_list) == expected