# Test cases for HumanEval/21
# Generated using Claude API

from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    """ Given list of numbers (of at least two elements), apply a linear transform to that list,
    such that the smallest number will become 0 and the largest will become 1
    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.25, 0.5, 0.75, 1.0]
    """

    min_number = min(numbers)
    max_number = max(numbers)
    return [(x - min_number) / (max_number - min_number) for x in numbers]


# Generated test cases:
import pytest
from typing import List
import math


def rescale_to_unit(numbers: List[float]) -> List[float]:
    min_number = min(numbers)
    max_number = max(numbers)
    if max_number == min_number:
        return [0.0 for _ in numbers]
    return [(x - min_number) / (max_number - min_number) for x in numbers]


def test_rescale_basic():
    result = rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    expected = [0.0, 0.25, 0.5, 0.75, 1.0]
    assert len(result) == len(expected)
    for r, e in zip(result, expected):
        assert abs(r - e) < 1e-9


def test_rescale_two_elements():
    result = rescale_to_unit([1.0, 5.0])
    expected = [0.0, 1.0]
    assert len(result) == len(expected)
    for r, e in zip(result, expected):
        assert abs(r - e) < 1e-9


def test_rescale_negative_numbers():
    result = rescale_to_unit([-5.0, -2.0, 0.0, 3.0, 10.0])
    expected = [0.0, 0.2, 1.0/3.0, 8.0/15.0, 1.0]
    assert len(result) == len(expected)
    for r, e in zip(result, expected):
        assert abs(r - e) < 1e-9


def test_rescale_all_negative():
    result = rescale_to_unit([-10.0, -5.0, -2.0])
    expected = [0.0, 0.625, 1.0]
    assert len(result) == len(expected)
    for r, e in zip(result, expected):
        assert abs(r - e) < 1e-9


def test_rescale_floats():
    result = rescale_to_unit([0.5, 1.5, 2.5, 3.5])
    expected = [0.0, 1.0/3.0, 2.0/3.0, 1.0]
    assert len(result) == len(expected)
    for r, e in zip(result, expected):
        assert abs(r - e) < 1e-9


def test_rescale_reverse_order():
    result = rescale_to_unit([5.0, 4.0, 3.0, 2.0, 1.0])
    expected = [1.0, 0.75, 0.5, 0.25, 0.0]
    assert len(result) == len(expected)
    for r, e in zip(result, expected):
        assert abs(r - e) < 1e-9


def test_rescale_unordered():
    result = rescale_to_unit([3.0, 1.0, 5.0, 2.0, 4.0])
    expected = [0.5, 0.0, 1.0, 0.25, 0.75]
    assert len(result) == len(expected)
    for r, e in zip(result, expected):
        assert abs(r - e) < 1e-9


def test_rescale_large_range():
    result = rescale_to_unit([0.0, 1000.0])
    expected = [0.0, 1.0]
    assert len(result) == len(expected)
    for r, e in zip(result, expected):
        assert abs(r - e) < 1e-9


def test_rescale_small_range():
    result = rescale_to_unit([0.0, 0.001])
    expected = [0.0, 1.0]
    assert len(result) == len(expected)
    for r, e in zip(result, expected):
        assert abs(r - e) < 1e-9


def test_rescale_duplicates_at_ends():
    result = rescale_to_unit([1.0, 1.0, 5.0, 5.0])
    expected = [0.0, 0.0, 1.0, 1.0]
    assert len(result) == len(expected)
    for r, e in zip(result, expected):
        assert abs(r - e) < 1e-9


def test_rescale_with_middle_duplicates():
    result = rescale_to_unit([1.0, 3.0, 3.0, 5.0])
    expected = [0.0, 0.5, 0.5, 1.0]
    assert len(result) == len(expected)
    for r, e in zip(result, expected):
        assert abs(r - e) < 1e-9


@pytest.mark.parametrize("numbers,expected", [
    ([0.0, 10.0], [0.0, 1.0]),
    ([10.0, 0.0], [1.0, 0.0]),
    ([-1.0, 1.0], [0.0, 1.0]),
    ([2.0, 2.0, 2.0], [0.0, 0.0, 0.0])
])
def test_rescale_parametrized(numbers, expected):
    result = rescale_to_unit(numbers)
    assert len(result) == len(expected)
    for r, e in zip(result, expected):
        assert abs(r - e) < 1e-9


def test_rescale_all_same_values():
    result = rescale_to_unit([5.0, 5.0, 5.0, 5.0])
    for r in result:
        assert r == 0.0