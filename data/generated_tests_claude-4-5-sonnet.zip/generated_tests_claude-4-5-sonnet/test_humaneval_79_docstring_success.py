# Test cases for HumanEval/79
# Generated using Claude API


def decimal_to_binary(decimal):
    """You will be given a number in decimal form and your task is to convert it to
    binary format. The function should return a string, with each character representing a binary
    number. Each character in the string will be '0' or '1'.

    There will be an extra couple of characters 'db' at the beginning and at the end of the string.
    The extra characters are there to help with the format.

    Examples:
    decimal_to_binary(15)   # returns "db1111db"
    decimal_to_binary(32)   # returns "db100000db"
    """

    return "db" + bin(decimal)[2:] + "db"


# Generated test cases:
import pytest

def decimal_to_binary(decimal):
    return "db" + bin(decimal)[2:] + "db"

def test_decimal_to_binary_15():
    assert decimal_to_binary(15) == "db1111db"

def test_decimal_to_binary_32():
    assert decimal_to_binary(32) == "db100000db"

def test_decimal_to_binary_0():
    assert decimal_to_binary(0) == "db0db"

def test_decimal_to_binary_1():
    assert decimal_to_binary(1) == "db1db"

def test_decimal_to_binary_2():
    assert decimal_to_binary(2) == "db10db"

def test_decimal_to_binary_7():
    assert decimal_to_binary(7) == "db111db"

def test_decimal_to_binary_8():
    assert decimal_to_binary(8) == "db1000db"

def test_decimal_to_binary_100():
    assert decimal_to_binary(100) == "db1100100db"

def test_decimal_to_binary_255():
    assert decimal_to_binary(255) == "db11111111db"

def test_decimal_to_binary_1024():
    assert decimal_to_binary(1024) == "db10000000000db"

@pytest.mark.parametrize("decimal,expected", [
    (0, "db0db"),
    (1, "db1db"),
    (2, "db10db"),
    (3, "db11db"),
    (4, "db100db"),
    (5, "db101db"),
    (10, "db1010db"),
    (15, "db1111db"),
    (16, "db10000db"),
    (31, "db11111db"),
    (32, "db100000db"),
    (63, "db111111db"),
    (64, "db1000000db"),
    (127, "db1111111db"),
    (128, "db10000000db"),
    (256, "db100000000db"),
    (512, "db1000000000db"),
    (1000, "db1111101000db"),
])
def test_decimal_to_binary_parametrized(decimal, expected):
    assert decimal_to_binary(decimal) == expected

def test_decimal_to_binary_starts_with_db():
    result = decimal_to_binary(42)
    assert result.startswith("db")

def test_decimal_to_binary_ends_with_db():
    result = decimal_to_binary(42)
    assert result.endswith("db")

def test_decimal_to_binary_middle_contains_only_binary():
    result = decimal_to_binary(42)
    middle = result[2:-2]
    assert all(c in '01' for c in middle)

def test_decimal_to_binary_large_number():
    assert decimal_to_binary(9999) == "db10011100001111db"
