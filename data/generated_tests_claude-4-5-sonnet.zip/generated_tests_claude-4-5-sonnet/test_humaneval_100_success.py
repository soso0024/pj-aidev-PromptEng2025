# Test cases for HumanEval/100
# Generated using Claude API


def make_a_pile(n):
    """
    Given a positive integer n, you have to make a pile of n levels of stones.
    The first level has n stones.
    The number of stones in the next level is:
        - the next odd number if n is odd.
        - the next even number if n is even.
    Return the number of stones in each level in a list, where element at index
    i represents the number of stones in the level (i+1).

    Examples:
    >>> make_a_pile(3)
    [3, 5, 7]
    """

    return [n + 2*i for i in range(n)]


# Generated test cases:
import pytest

def make_a_pile(n):
    return [n + 2*i for i in range(n)]

def test_make_a_pile_basic_case():
    assert make_a_pile(3) == [3, 5, 7]

def test_make_a_pile_single_element():
    assert make_a_pile(1) == [1]

def test_make_a_pile_two_elements():
    assert make_a_pile(2) == [2, 4]

def test_make_a_pile_larger_number():
    assert make_a_pile(5) == [5, 7, 9, 11, 13]

def test_make_a_pile_ten_elements():
    assert make_a_pile(10) == [10, 12, 14, 16, 18, 20, 22, 24, 26, 28]

def test_make_a_pile_length():
    result = make_a_pile(7)
    assert len(result) == 7

def test_make_a_pile_arithmetic_sequence():
    result = make_a_pile(4)
    assert result == [4, 6, 8, 10]
    for i in range(len(result) - 1):
        assert result[i+1] - result[i] == 2

def test_make_a_pile_first_element():
    n = 15
    result = make_a_pile(n)
    assert result[0] == n

def test_make_a_pile_last_element():
    n = 6
    result = make_a_pile(n)
    assert result[-1] == n + 2*(n-1)

@pytest.mark.parametrize("n,expected", [
    (1, [1]),
    (2, [2, 4]),
    (3, [3, 5, 7]),
    (4, [4, 6, 8, 10]),
    (5, [5, 7, 9, 11, 13]),
])
def test_make_a_pile_parametrized(n, expected):
    assert make_a_pile(n) == expected

def test_make_a_pile_zero():
    assert make_a_pile(0) == []

def test_make_a_pile_large_number():
    result = make_a_pile(100)
    assert len(result) == 100
    assert result[0] == 100
    assert result[-1] == 298

def test_make_a_pile_all_odd_when_n_odd():
    result = make_a_pile(5)
    for num in result:
        assert num % 2 == 1

def test_make_a_pile_all_even_when_n_even():
    result = make_a_pile(4)
    for num in result:
        assert num % 2 == 0
