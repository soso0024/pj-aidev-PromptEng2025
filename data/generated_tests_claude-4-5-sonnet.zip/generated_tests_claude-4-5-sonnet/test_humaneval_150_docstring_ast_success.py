# Test cases for HumanEval/150
# Generated using Claude API


def x_or_y(n, x, y):
    """A simple program which should return the value of x if n is 
    a prime number and should return the value of y otherwise.

    Examples:
    for x_or_y(7, 34, 12) == 34
    for x_or_y(15, 8, 5) == 5
    
    """

    if n == 1:
        return y
    for i in range(2, n):
        if n % i == 0:
            return y
            break
    else:
        return x


# Generated test cases:
import pytest

def x_or_y(n, x, y):
    if n == 1:
        return y
    for i in range(2, n):
        if n % i == 0:
            return y
            break
    else:
        return x

@pytest.mark.parametrize("n,x,y,expected", [
    (7, 34, 12, 34),
    (15, 8, 5, 5),
    (2, 100, 200, 100),
    (3, 100, 200, 100),
    (5, 100, 200, 100),
    (11, 100, 200, 100),
    (13, 100, 200, 100),
    (17, 100, 200, 100),
    (19, 100, 200, 100),
    (23, 100, 200, 100),
    (29, 100, 200, 100),
    (31, 100, 200, 100),
    (1, 100, 200, 200),
    (4, 100, 200, 200),
    (6, 100, 200, 200),
    (8, 100, 200, 200),
    (9, 100, 200, 200),
    (10, 100, 200, 200),
    (12, 100, 200, 200),
    (14, 100, 200, 200),
    (16, 100, 200, 200),
    (18, 100, 200, 200),
    (20, 100, 200, 200),
    (21, 100, 200, 200),
    (22, 100, 200, 200),
    (24, 100, 200, 200),
    (25, 100, 200, 200),
    (26, 100, 200, 200),
    (27, 100, 200, 200),
    (28, 100, 200, 200),
    (30, 100, 200, 200),
    (97, 1, 0, 1),
    (100, 1, 0, 0),
    (101, 1, 0, 1),
    (2, -5, -10, -5),
    (4, -5, -10, -10),
    (7, 0, 0, 0),
    (8, 0, 0, 0),
    (2, 1, 2, 1),
    (3, 1, 2, 1),
    (4, 1, 2, 2),
    (5, 1, 2, 1),
    (6, 1, 2, 2),
])
def test_x_or_y_parametrized(n, x, y, expected):
    assert x_or_y(n, x, y) == expected

def test_x_or_y_small_primes():
    assert x_or_y(2, 10, 20) == 10
    assert x_or_y(3, 10, 20) == 10
    assert x_or_y(5, 10, 20) == 10
    assert x_or_y(7, 10, 20) == 10

def test_x_or_y_small_composites():
    assert x_or_y(4, 10, 20) == 20
    assert x_or_y(6, 10, 20) == 20
    assert x_or_y(8, 10, 20) == 20
    assert x_or_y(9, 10, 20) == 20

def test_x_or_y_one():
    assert x_or_y(1, 10, 20) == 20
    assert x_or_y(1, 100, 200) == 200
    assert x_or_y(1, -5, -10) == -10

def test_x_or_y_large_prime():
    assert x_or_y(97, 1, 2) == 1
    assert x_or_y(89, 1, 2) == 1

def test_x_or_y_large_composite():
    assert x_or_y(100, 1, 2) == 2
    assert x_or_y(99, 1, 2) == 2

def test_x_or_y_negative_values():
    assert x_or_y(7, -10, -20) == -10
    assert x_or_y(8, -10, -20) == -20

def test_x_or_y_zero_values():
    assert x_or_y(7, 0, 1) == 0
    assert x_or_y(8, 0, 1) == 1

def test_x_or_y_same_xy():
    assert x_or_y(7, 5, 5) == 5
    assert x_or_y(8, 5, 5) == 5
