# Test cases for HumanEval/27
# Generated using Claude API



def flip_case(string: str) -> str:
    """ For a given string, flip lowercase characters to uppercase and uppercase to lowercase.
    >>> flip_case('Hello')
    'hELLO'
    """

    return string.swapcase()


# Generated test cases:
import pytest

def flip_case(string: str) -> str:
    return string.swapcase()

def test_flip_case_lowercase():
    assert flip_case("hello") == "HELLO"

def test_flip_case_uppercase():
    assert flip_case("HELLO") == "hello"

def test_flip_case_mixed():
    assert flip_case("HeLLo") == "hEllO"

def test_flip_case_empty_string():
    assert flip_case("") == ""

def test_flip_case_numbers():
    assert flip_case("123") == "123"

def test_flip_case_special_characters():
    assert flip_case("!@#$%") == "!@#$%"

def test_flip_case_mixed_with_numbers():
    assert flip_case("Hello123") == "hELLO123"

def test_flip_case_mixed_with_special_chars():
    assert flip_case("Hello!World") == "hELLO!wORLD"

def test_flip_case_spaces():
    assert flip_case("Hello World") == "hELLO wORLD"

def test_flip_case_single_char_lower():
    assert flip_case("a") == "A"

def test_flip_case_single_char_upper():
    assert flip_case("A") == "a"

def test_flip_case_all_spaces():
    assert flip_case("   ") == "   "

def test_flip_case_tabs_and_newlines():
    assert flip_case("Hello\tWorld\n") == "hELLO\twORLD\n"

@pytest.mark.parametrize("input_str,expected", [
    ("abc", "ABC"),
    ("ABC", "abc"),
    ("AbC", "aBc"),
    ("123abc", "123ABC"),
    ("", ""),
    ("a", "A"),
    ("Z", "z"),
    ("Hello World!", "hELLO wORLD!"),
    ("CamelCase", "cAMELcASE"),
    ("snake_case", "SNAKE_CASE"),
])
def test_flip_case_parametrized(input_str, expected):
    assert flip_case(input_str) == expected

def test_flip_case_unicode():
    assert flip_case("Café") == "cAFÉ"

def test_flip_case_long_string():
    input_str = "The Quick Brown Fox Jumps Over The Lazy Dog"
    expected = "tHE qUICK bROWN fOX jUMPS oVER tHE lAZY dOG"
    assert flip_case(input_str) == expected

def test_flip_case_alphanumeric():
    assert flip_case("Test123Test") == "tEST123tEST"

def test_flip_case_only_numbers():
    assert flip_case("0123456789") == "0123456789"

def test_flip_case_punctuation():
    assert flip_case("Hello, World!") == "hELLO, wORLD!"