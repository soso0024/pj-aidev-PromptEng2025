# Test cases for HumanEval/76
# Generated using Claude API


def is_simple_power(x, n):
    """Your task is to write a function that returns true if a number x is a simple
    power of n and false in other cases.
    x is a simple power of n if n**int=x
    For example:
    is_simple_power(1, 4) => true
    is_simple_power(2, 2) => true
    is_simple_power(8, 2) => true
    is_simple_power(3, 2) => false
    is_simple_power(3, 1) => false
    is_simple_power(5, 3) => false
    """

    if (n == 1): 
        return (x == 1) 
    power = 1
    while (power < x): 
        power = power * n 
    return (power == x) 


# Generated test cases:
import pytest

def is_simple_power(x, n):
    if (n == 1): 
        return (x == 1) 
    power = 1
    while (power < x): 
        power = power * n 
    return (power == x)

@pytest.mark.parametrize("x,n,expected", [
    (1, 4, True),
    (2, 2, True),
    (8, 2, True),
    (3, 2, False),
    (3, 1, False),
    (5, 3, False),
    (1, 1, True),
    (1, 2, True),
    (1, 100, True),
    (4, 2, True),
    (16, 2, True),
    (32, 2, True),
    (64, 2, True),
    (27, 3, True),
    (81, 3, True),
    (125, 5, True),
    (100, 10, True),
    (1000, 10, True),
    (10, 10, True),
    (9, 3, True),
    (25, 5, True),
    (49, 7, True),
    (121, 11, True),
    (5, 2, False),
    (6, 2, False),
    (7, 2, False),
    (10, 2, False),
    (15, 3, False),
    (20, 4, False),
    (50, 5, False),
    (100, 3, False),
    (2, 1, False),
    (3, 1, False),
    (10, 1, False),
    (0, 2, False),
    (0, 1, False),
    (1, 0, True),
    (16, 4, True),
    (256, 2, True),
    (243, 3, True),
    (1024, 2, True),
    (128, 2, True),
    (512, 2, True),
    (343, 7, True),
    (216, 6, True),
    (36, 6, True),
    (144, 12, True),
    (169, 13, True),
    (196, 14, True),
    (225, 15, True),
    (7, 3, False),
    (11, 2, False),
    (13, 2, False),
    (17, 2, False),
    (19, 2, False),
    (23, 2, False),
])
def test_is_simple_power(x, n, expected):
    assert is_simple_power(x, n) == expected

def test_is_simple_power_large_numbers():
    assert is_simple_power(1048576, 2) == True
    assert is_simple_power(59049, 3) == True
    assert is_simple_power(1000000, 10) == True
    assert is_simple_power(1000001, 10) == False

def test_is_simple_power_edge_cases():
    assert is_simple_power(1, 1) == True
    assert is_simple_power(0, 0) == False
    assert is_simple_power(1, 1000000) == True