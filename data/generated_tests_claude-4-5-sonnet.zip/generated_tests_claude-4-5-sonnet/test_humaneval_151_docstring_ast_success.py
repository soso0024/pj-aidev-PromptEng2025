# Test cases for HumanEval/151
# Generated using Claude API


def double_the_difference(lst):
    '''
    Given a list of numbers, return the sum of squares of the numbers
    in the list that are odd. Ignore numbers that are negative or not integers.
    
    double_the_difference([1, 3, 2, 0]) == 1 + 9 + 0 + 0 = 10
    double_the_difference([-1, -2, 0]) == 0
    double_the_difference([9, -2]) == 81
    double_the_difference([0]) == 0  
   
    If the input list is empty, return 0.
    '''

    return sum([i**2 for i in lst if i > 0 and i%2!=0 and "." not in str(i)])


# Generated test cases:
import pytest

def double_the_difference(lst):
    return sum([i**2 for i in lst if i > 0 and i%2!=0 and "." not in str(i)])

def test_example_case_1():
    assert double_the_difference([1, 3, 2, 0]) == 10

def test_example_case_2():
    assert double_the_difference([-1, -2, 0]) == 0

def test_example_case_3():
    assert double_the_difference([9, -2]) == 81

def test_example_case_4():
    assert double_the_difference([0]) == 0

def test_empty_list():
    assert double_the_difference([]) == 0

def test_single_odd_positive():
    assert double_the_difference([5]) == 25

def test_single_even_positive():
    assert double_the_difference([4]) == 0

def test_single_negative_odd():
    assert double_the_difference([-3]) == 0

def test_single_negative_even():
    assert double_the_difference([-4]) == 0

def test_all_even_numbers():
    assert double_the_difference([2, 4, 6, 8]) == 0

def test_all_odd_positive_numbers():
    assert double_the_difference([1, 3, 5]) == 1 + 9 + 25

def test_all_negative_numbers():
    assert double_the_difference([-1, -3, -5, -7]) == 0

def test_mixed_positive_negative():
    assert double_the_difference([1, -1, 3, -3, 5, -5]) == 1 + 9 + 25

def test_with_floats():
    assert double_the_difference([1.5, 2.5, 3.5]) == 0

def test_with_mixed_floats_and_integers():
    assert double_the_difference([1, 2.5, 3, 4.0]) == 1 + 9

def test_with_zero_and_positives():
    assert double_the_difference([0, 1, 2, 3]) == 1 + 9

def test_large_odd_number():
    assert double_the_difference([99]) == 9801

def test_multiple_large_odd_numbers():
    assert double_the_difference([11, 13, 15]) == 121 + 169 + 225

def test_with_negative_floats():
    assert double_the_difference([-1.5, -2.5]) == 0

def test_with_positive_floats():
    assert double_the_difference([1.1, 3.3, 5.5]) == 0

def test_mixed_integers_floats_negatives():
    assert double_the_difference([1, -2, 3.5, 4, 5, -6.7, 7]) == 1 + 25 + 49

def test_only_zeros():
    assert double_the_difference([0, 0, 0]) == 0

def test_one_as_smallest_odd():
    assert double_the_difference([1]) == 1

def test_large_list_all_even():
    assert double_the_difference([2, 4, 6, 8, 10, 12, 14, 16]) == 0

def test_large_list_mixed():
    assert double_the_difference([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == 1 + 9 + 25 + 49 + 81

def test_negative_zero_positive():
    assert double_the_difference([-5, 0, 5]) == 25

def test_float_that_looks_like_int():
    assert double_the_difference([3.0, 5.0]) == 0

def test_very_small_float():
    assert double_the_difference([0.1, 0.3, 0.5]) == 0
