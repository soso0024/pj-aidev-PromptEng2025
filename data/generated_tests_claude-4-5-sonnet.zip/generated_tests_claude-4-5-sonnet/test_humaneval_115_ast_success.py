# Test cases for HumanEval/115
# Generated using Claude API


def max_fill(grid, capacity):
    import math
    """
    You are given a rectangular grid of wells. Each row represents a single well,
    and each 1 in a row represents a single unit of water.
    Each well has a corresponding bucket that can be used to extract water from it, 
    and all buckets have the same capacity.
    Your task is to use the buckets to empty the wells.
    Output the number of times you need to lower the buckets.

    Example 1:
        Input: 
            grid : [[0,0,1,0], [0,1,0,0], [1,1,1,1]]
            bucket_capacity : 1
        Output: 6

    Example 2:
        Input: 
            grid : [[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]]
            bucket_capacity : 2
        Output: 5
    
    Example 3:
        Input: 
            grid : [[0,0,0], [0,0,0]]
            bucket_capacity : 5
        Output: 0

    Constraints:
        * all wells have the same length
        * 1 <= grid.length <= 10^2
        * 1 <= grid[:,1].length <= 10^2
        * grid[i][j] -> 0 | 1
        * 1 <= capacity <= 10
    """

    return sum([math.ceil(sum(arr)/capacity) for arr in grid])


# Generated test cases:
import pytest
import math


def max_fill(grid, capacity):
    return sum([math.ceil(sum(arr)/capacity) for arr in grid])


def test_max_fill_basic():
    assert max_fill([[0, 0, 1, 0], [0, 1, 0, 0], [1, 1, 1, 1]], 1) == 6


def test_max_fill_basic_capacity_2():
    assert max_fill([[0, 0, 1, 0], [0, 1, 0, 0], [1, 1, 1, 1]], 2) == 4


def test_max_fill_empty_grid():
    assert max_fill([], 1) == 0


def test_max_fill_all_zeros():
    assert max_fill([[0, 0, 0], [0, 0, 0]], 1) == 0


def test_max_fill_single_row():
    assert max_fill([[1, 1, 1, 1, 1]], 2) == 3


def test_max_fill_single_element():
    assert max_fill([[1]], 1) == 1


def test_max_fill_large_capacity():
    assert max_fill([[1, 1, 1], [1, 1, 1]], 10) == 2


def test_max_fill_exact_capacity():
    assert max_fill([[2, 2], [3, 3]], 4) == 3


def test_max_fill_capacity_larger_than_sum():
    assert max_fill([[1, 2], [3, 4]], 100) == 2


def test_max_fill_mixed_values():
    assert max_fill([[0, 1, 1], [2, 2, 2], [0, 0, 0]], 3) == 3


def test_max_fill_capacity_one():
    assert max_fill([[5, 3, 2], [1, 1, 1]], 1) == 13


def test_max_fill_single_row_single_element_zero():
    assert max_fill([[0]], 1) == 0


def test_max_fill_multiple_rows_different_sums():
    assert max_fill([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 5) == 10


def test_max_fill_capacity_equals_row_sum():
    assert max_fill([[3, 3, 3], [6, 6, 6]], 9) == 3


def test_max_fill_fractional_division():
    assert max_fill([[1, 1, 1], [2, 2, 2]], 4) == 3


def test_max_fill_large_grid():
    grid = [[1] * 10 for _ in range(100)]
    assert max_fill(grid, 5) == 200


def test_max_fill_varying_row_lengths():
    assert max_fill([[1, 2], [3, 4, 5], [6]], 3) == 7


def test_max_fill_high_capacity():
    assert max_fill([[10, 20, 30], [5, 5, 5]], 1000) == 2