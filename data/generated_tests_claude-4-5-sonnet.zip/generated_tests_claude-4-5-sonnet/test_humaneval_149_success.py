# Test cases for HumanEval/149
# Generated using Claude API


def sorted_list_sum(lst):
    """Write a function that accepts a list of strings as a parameter,
    deletes the strings that have odd lengths from it,
    and returns the resulted list with a sorted order,
    The list is always a list of strings and never an array of numbers,
    and it may contain duplicates.
    The order of the list should be ascending by length of each word, and you
    should return the list sorted by that rule.
    If two words have the same length, sort the list alphabetically.
    The function should return a list of strings in sorted order.
    You may assume that all words will have the same length.
    For example:
    assert list_sort(["aa", "a", "aaa"]) => ["aa"]
    assert list_sort(["ab", "a", "aaa", "cd"]) => ["ab", "cd"]
    """

    lst.sort()
    new_lst = []
    for i in lst:
        if len(i)%2 == 0:
            new_lst.append(i)
    return sorted(new_lst, key=len)


# Generated test cases:
import pytest


def sorted_list_sum(lst):
    lst.sort()
    new_lst = []
    for i in lst:
        if len(i)%2 == 0:
            new_lst.append(i)
    return sorted(new_lst, key=len)


def test_empty_list():
    assert sorted_list_sum([]) == []


def test_single_even_length_string():
    assert sorted_list_sum(["ab"]) == ["ab"]


def test_single_odd_length_string():
    assert sorted_list_sum(["abc"]) == []


def test_all_odd_length_strings():
    assert sorted_list_sum(["a", "abc", "abcde"]) == []


def test_all_even_length_strings():
    assert sorted_list_sum(["ab", "abcd", "abcdef"]) == ["ab", "abcd", "abcdef"]


def test_mixed_odd_even_length_strings():
    assert sorted_list_sum(["a", "ab", "abc", "abcd"]) == ["ab", "abcd"]


def test_unsorted_even_length_strings():
    assert sorted_list_sum(["abcd", "ab", "abcdef"]) == ["ab", "abcd", "abcdef"]


def test_unsorted_mixed_strings():
    assert sorted_list_sum(["xyz", "ab", "hello", "cd"]) == ["ab", "cd"]


def test_strings_same_length():
    assert sorted_list_sum(["ab", "cd", "ef"]) == ["ab", "cd", "ef"]


def test_strings_same_length_unsorted():
    assert sorted_list_sum(["zz", "aa", "mm"]) == ["aa", "mm", "zz"]


def test_complex_case():
    assert sorted_list_sum(["aa", "a", "aaa"]) == ["aa"]


def test_complex_case_2():
    assert sorted_list_sum(["ab", "a", "aaa", "cd"]) == ["ab", "cd"]


def test_alphabetical_and_length_sorting():
    assert sorted_list_sum(["school", "AI", "asdf", "b"]) == ["AI", "asdf", "school"]


def test_reverse_alphabetical_order():
    assert sorted_list_sum(["zz", "yy", "xx", "ww"]) == ["ww", "xx", "yy", "zz"]


def test_duplicate_strings():
    assert sorted_list_sum(["ab", "ab", "cd", "cd"]) == ["ab", "ab", "cd", "cd"]


def test_empty_string():
    assert sorted_list_sum([""]) == [""]


def test_multiple_empty_strings():
    assert sorted_list_sum(["", "", ""]) == ["", "", ""]


def test_empty_and_non_empty_strings():
    assert sorted_list_sum(["", "a", "ab"]) == ["", "ab"]


def test_length_priority_over_alphabetical():
    assert sorted_list_sum(["zzzz", "aa"]) == ["aa", "zzzz"]


@pytest.mark.parametrize("input_list,expected", [
    (["aa", "ab", "bb"], ["aa", "ab", "bb"]),
    (["d", "b", "c", "a"], []),
    (["d", "dcba", "abcd", "a"], ["abcd", "dcba"]),
    (["AI", "ai", "au"], ["AI", "ai", "au"]),
    (["a", "b", "b", "c", "c", "a"], []),
    (["aaaa", "bbbb", "dd", "cc"], ["cc", "dd", "aaaa", "bbbb"]),
])
def test_parametrized_cases(input_list, expected):
    assert sorted_list_sum(input_list) == expected
