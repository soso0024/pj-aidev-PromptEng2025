# Test cases for HumanEval/53
# Generated using Claude API



def add(x: int, y: int):
    """Add two numbers x and y
    >>> add(2, 3)
    5
    >>> add(5, 7)
    12
    """

    return x + y


# Generated test cases:
import pytest

def add(x: int, y: int):
    return x + y

def test_add_positive_numbers():
    assert add(2, 3) == 5
    assert add(5, 7) == 12

def test_add_negative_numbers():
    assert add(-2, -3) == -5
    assert add(-5, -7) == -12

def test_add_mixed_signs():
    assert add(-2, 3) == 1
    assert add(5, -7) == -2
    assert add(-10, 10) == 0

def test_add_with_zero():
    assert add(0, 0) == 0
    assert add(0, 5) == 5
    assert add(5, 0) == 5
    assert add(0, -5) == -5
    assert add(-5, 0) == -5

def test_add_large_numbers():
    assert add(1000000, 2000000) == 3000000
    assert add(999999999, 1) == 1000000000

def test_add_commutative():
    assert add(3, 5) == add(5, 3)
    assert add(-3, 5) == add(5, -3)

@pytest.mark.parametrize("x,y,expected", [
    (1, 1, 2),
    (10, 20, 30),
    (100, 200, 300),
    (-1, -1, -2),
    (-10, 10, 0),
    (0, 0, 0),
    (1, -1, 0),
    (999, 1, 1000),
])
def test_add_parametrized(x, y, expected):
    assert add(x, y) == expected
