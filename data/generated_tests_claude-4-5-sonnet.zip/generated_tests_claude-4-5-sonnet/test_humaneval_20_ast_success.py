# Test cases for HumanEval/20
# Generated using Claude API

from typing import List, Tuple


def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    """ From a supplied list of numbers (of length at least two) select and return two that are the closest to each
    other and return them in order (smaller number, larger number).
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.2])
    (2.0, 2.2)
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.0])
    (2.0, 2.0)
    """

    closest_pair = None
    distance = None

    for idx, elem in enumerate(numbers):
        for idx2, elem2 in enumerate(numbers):
            if idx != idx2:
                if distance is None:
                    distance = abs(elem - elem2)
                    closest_pair = tuple(sorted([elem, elem2]))
                else:
                    new_distance = abs(elem - elem2)
                    if new_distance < distance:
                        distance = new_distance
                        closest_pair = tuple(sorted([elem, elem2]))

    return closest_pair


# Generated test cases:
import pytest
from typing import List, Tuple


def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    closest_pair = None
    distance = None

    for idx, elem in enumerate(numbers):
        for idx2, elem2 in enumerate(numbers):
            if idx != idx2:
                if distance is None:
                    distance = abs(elem - elem2)
                    closest_pair = tuple(sorted([elem, elem2]))
                else:
                    new_distance = abs(elem - elem2)
                    if new_distance < distance:
                        distance = new_distance
                        closest_pair = tuple(sorted([elem, elem2]))

    return closest_pair


@pytest.mark.parametrize("numbers,expected", [
    ([1.0, 2.0, 3.0, 4.0], (1.0, 2.0)),
    ([1.0, 2.0, 3.9, 4.0], (3.9, 4.0)),
    ([1.0, 2.0, 5.9, 4.0], (1.0, 2.0)),
    ([1.1, 2.2, 3.3, 4.4, 5.5], (2.2, 3.3)),
    ([10.0, 20.0, 30.0, 40.0], (10.0, 20.0)),
    ([1.0, 1.5, 2.0, 2.5], (1.0, 1.5)),
    ([5.0, 3.0, 1.0, 2.0], (2.0, 3.0)),
    ([100.0, 200.0, 150.0], (100.0, 150.0)),
    ([-5.0, -3.0, -1.0], (-5.0, -3.0)),
    ([-10.0, -5.0, 0.0, 5.0], (-10.0, -5.0)),
    ([0.0, 1.0], (0.0, 1.0)),
    ([5.0, 5.1], (5.0, 5.1)),
    ([1.0, 1.0001, 2.0], (1.0, 1.0001)),
    ([0.1, 0.2, 0.3, 0.4], (0.2, 0.3)),
    ([1.5, 2.5, 3.5, 4.5], (1.5, 2.5)),
])
def test_find_closest_elements_parametrized(numbers, expected):
    result = find_closest_elements(numbers)
    assert result == expected


def test_find_closest_elements_two_elements():
    assert find_closest_elements([1.0, 2.0]) == (1.0, 2.0)


def test_find_closest_elements_three_elements():
    assert find_closest_elements([1.0, 2.0, 3.0]) == (1.0, 2.0)


def test_find_closest_elements_negative_numbers():
    assert find_closest_elements([-1.0, -2.0, -3.0]) == (-2.0, -1.0)


def test_find_closest_elements_mixed_positive_negative():
    assert find_closest_elements([-1.0, 0.0, 1.0]) == (-1.0, 0.0)


def test_find_closest_elements_large_gap():
    assert find_closest_elements([1.0, 100.0, 200.0]) == (1.0, 100.0)


def test_find_closest_elements_small_differences():
    assert find_closest_elements([1.0, 1.01, 1.02]) == (1.0, 1.01)


def test_find_closest_elements_unsorted_input():
    assert find_closest_elements([5.0, 1.0, 3.0, 2.0]) == (1.0, 2.0)


def test_find_closest_elements_reverse_sorted():
    assert find_closest_elements([5.0, 4.0, 3.0, 2.0, 1.0]) == (4.0, 5.0)


def test_find_closest_elements_decimals():
    assert find_closest_elements([0.5, 1.5, 2.5, 3.5]) == (0.5, 1.5)


def test_find_closest_elements_very_close():
    result = find_closest_elements([1.0, 1.0000001, 2.0])
    assert result == (1.0, 1.0000001)


def test_find_closest_elements_all_negative():
    assert find_closest_elements([-10.0, -20.0, -30.0]) == (-20.0, -10.0)


def test_find_closest_elements_zero_included():
    assert find_closest_elements([0.0, 5.0, 10.0]) == (0.0, 5.0)


def test_find_closest_elements_large_numbers():
    assert find_closest_elements([1000.0, 2000.0, 3000.0]) == (1000.0, 2000.0)


def test_find_closest_elements_fractional():
    assert find_closest_elements([0.1, 0.2, 0.5, 1.0]) == (0.1, 0.2)