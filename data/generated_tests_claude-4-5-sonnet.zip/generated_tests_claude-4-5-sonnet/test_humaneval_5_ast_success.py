# Test cases for HumanEval/5
# Generated using Claude API

from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """ Insert a number 'delimeter' between every two consecutive elements of input list `numbers'
    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """

    if not numbers:
        return []

    result = []

    for n in numbers[:-1]:
        result.append(n)
        result.append(delimeter)

    result.append(numbers[-1])

    return result


# Generated test cases:
import pytest
from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    if not numbers:
        return []

    result = []

    for n in numbers[:-1]:
        result.append(n)
        result.append(delimeter)

    result.append(numbers[-1])

    return result


@pytest.mark.parametrize("numbers,delimeter,expected", [
    ([], 4, []),
    ([1], 4, [1]),
    ([1, 2], 4, [1, 4, 2]),
    ([1, 2, 3], 4, [1, 4, 2, 4, 3]),
    ([1, 2, 3, 4], 0, [1, 0, 2, 0, 3, 0, 4]),
    ([5, 6, 7], 1, [5, 1, 6, 1, 7]),
    ([10], 99, [10]),
    ([1, 1, 1], 2, [1, 2, 1, 2, 1]),
    ([0, 0, 0], 1, [0, 1, 0, 1, 0]),
    ([-1, -2, -3], 0, [-1, 0, -2, 0, -3]),
    ([100, 200, 300, 400, 500], 0, [100, 0, 200, 0, 300, 0, 400, 0, 500]),
    ([1, 2], -1, [1, -1, 2]),
    ([-5, -10], -1, [-5, -1, -10]),
    ([0], 0, [0]),
    ([1, 2, 3, 4, 5], 10, [1, 10, 2, 10, 3, 10, 4, 10, 5]),
])
def test_intersperse_parametrized(numbers, delimeter, expected):
    assert intersperse(numbers, delimeter) == expected


def test_intersperse_empty_list():
    assert intersperse([], 5) == []


def test_intersperse_single_element():
    assert intersperse([7], 3) == [7]


def test_intersperse_two_elements():
    assert intersperse([1, 2], 0) == [1, 0, 2]


def test_intersperse_multiple_elements():
    assert intersperse([1, 2, 3, 4, 5], 0) == [1, 0, 2, 0, 3, 0, 4, 0, 5]


def test_intersperse_negative_numbers():
    assert intersperse([-1, -2, -3], -4) == [-1, -4, -2, -4, -3]


def test_intersperse_mixed_numbers():
    assert intersperse([-1, 0, 1], 5) == [-1, 5, 0, 5, 1]


def test_intersperse_large_delimeter():
    assert intersperse([1, 2, 3], 1000) == [1, 1000, 2, 1000, 3]


def test_intersperse_zero_delimeter():
    assert intersperse([5, 10, 15], 0) == [5, 0, 10, 0, 15]


def test_intersperse_all_same_numbers():
    assert intersperse([5, 5, 5, 5], 1) == [5, 1, 5, 1, 5, 1, 5]


def test_intersperse_preserves_original_list():
    original = [1, 2, 3]
    result = intersperse(original, 0)
    assert original == [1, 2, 3]
    assert result == [1, 0, 2, 0, 3]
