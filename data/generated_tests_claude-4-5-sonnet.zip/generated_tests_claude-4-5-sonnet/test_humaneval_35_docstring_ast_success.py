# Test cases for HumanEval/35
# Generated using Claude API



def max_element(l: list):
    """Return maximum element in the list.
    >>> max_element([1, 2, 3])
    3
    >>> max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    123
    """

    m = l[0]
    for e in l:
        if e > m:
            m = e
    return m


# Generated test cases:
import pytest

def max_element(l: list):
    m = l[0]
    for e in l:
        if e > m:
            m = e
    return m

def test_max_element_simple():
    assert max_element([1, 2, 3]) == 3

def test_max_element_mixed():
    assert max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10]) == 123

def test_max_element_single():
    assert max_element([42]) == 42

def test_max_element_all_negative():
    assert max_element([-1, -2, -3, -4]) == -1

def test_max_element_all_same():
    assert max_element([5, 5, 5, 5]) == 5

def test_max_element_max_at_start():
    assert max_element([10, 1, 2, 3]) == 10

def test_max_element_max_at_end():
    assert max_element([1, 2, 3, 10]) == 10

def test_max_element_max_in_middle():
    assert max_element([1, 2, 10, 3, 4]) == 10

def test_max_element_with_zero():
    assert max_element([0, -1, -2]) == 0

def test_max_element_with_duplicates():
    assert max_element([1, 3, 3, 2]) == 3

def test_max_element_large_numbers():
    assert max_element([1000000, 999999, 1000001]) == 1000001

def test_max_element_floats():
    assert max_element([1.5, 2.7, 2.3]) == 2.7

def test_max_element_negative_floats():
    assert max_element([-1.5, -2.7, -2.3]) == -1.5

def test_max_element_mixed_int_float():
    assert max_element([1, 2.5, 2, 3]) == 3

@pytest.mark.parametrize("input_list,expected", [
    ([1, 2, 3], 3),
    ([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10], 123),
    ([42], 42),
    ([-1, -2, -3], -1),
    ([0], 0),
    ([100, 50, 75], 100),
])
def test_max_element_parametrized(input_list, expected):
    assert max_element(input_list) == expected

def test_max_element_empty_list_raises():
    with pytest.raises(IndexError):
        max_element([])
