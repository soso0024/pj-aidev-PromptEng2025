# Test cases for HumanEval/77
# Generated using Claude API


def iscube(a):
    '''
    Write a function that takes an integer a and returns True 
    if this ingeger is a cube of some integer number.
    Note: you may assume the input is always valid.
    Examples:
    iscube(1) ==> True
    iscube(2) ==> False
    iscube(-1) ==> True
    iscube(64) ==> True
    iscube(0) ==> True
    iscube(180) ==> False
    '''

    a = abs(a)
    return int(round(a ** (1. / 3))) ** 3 == a


# Generated test cases:
import pytest

def iscube(a):
    a = abs(a)
    return int(round(a ** (1. / 3))) ** 3 == a

def test_iscube_one():
    assert iscube(1) == True

def test_iscube_two():
    assert iscube(2) == False

def test_iscube_negative_one():
    assert iscube(-1) == True

def test_iscube_sixty_four():
    assert iscube(64) == True

def test_iscube_zero():
    assert iscube(0) == True

def test_iscube_one_eighty():
    assert iscube(180) == False

def test_iscube_eight():
    assert iscube(8) == True

def test_iscube_negative_eight():
    assert iscube(-8) == True

def test_iscube_twenty_seven():
    assert iscube(27) == True

def test_iscube_negative_twenty_seven():
    assert iscube(-27) == True

def test_iscube_one_twenty_five():
    assert iscube(125) == True

def test_iscube_negative_one_twenty_five():
    assert iscube(-125) == True

def test_iscube_two_sixteen():
    assert iscube(216) == True

def test_iscube_negative_two_sixteen():
    assert iscube(-216) == True

def test_iscube_three_forty_three():
    assert iscube(343) == True

def test_iscube_five_twelve():
    assert iscube(512) == True

def test_iscube_seven_twenty_nine():
    assert iscube(729) == True

def test_iscube_one_thousand():
    assert iscube(1000) == True

def test_iscube_negative_one_thousand():
    assert iscube(-1000) == True

def test_iscube_ten():
    assert iscube(10) == False

def test_iscube_hundred():
    assert iscube(100) == False

def test_iscube_negative_hundred():
    assert iscube(-100) == False

def test_iscube_three():
    assert iscube(3) == False

def test_iscube_negative_three():
    assert iscube(-3) == False

@pytest.mark.parametrize("input_val,expected", [
    (0, True),
    (1, True),
    (-1, True),
    (8, True),
    (-8, True),
    (27, True),
    (-27, True),
    (64, True),
    (-64, True),
    (125, True),
    (-125, True),
    (216, True),
    (-216, True),
    (343, True),
    (-343, True),
    (512, True),
    (-512, True),
    (729, True),
    (-729, True),
    (1000, True),
    (-1000, True),
    (2, False),
    (3, False),
    (10, False),
    (100, False),
    (180, False),
    (-2, False),
    (-3, False),
    (-10, False),
    (-100, False),
    (-180, False),
])
def test_iscube_parametrized(input_val, expected):
    assert iscube(input_val) == expected
