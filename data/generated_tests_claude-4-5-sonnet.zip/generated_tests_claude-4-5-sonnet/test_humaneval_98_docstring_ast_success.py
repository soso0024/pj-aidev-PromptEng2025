# Test cases for HumanEval/98
# Generated using Claude API


def count_upper(s):
    """
    Given a string s, count the number of uppercase vowels in even indices.
    
    For example:
    count_upper('aBCdEf') returns 1
    count_upper('abcdefg') returns 0
    count_upper('dBBE') returns 0
    """

    count = 0
    for i in range(0,len(s),2):
        if s[i] in "AEIOU":
            count += 1
    return count


# Generated test cases:
import pytest

def count_upper(s):
    count = 0
    for i in range(0,len(s),2):
        if s[i] in "AEIOU":
            count += 1
    return count

def test_count_upper_example1():
    assert count_upper('aBCdEf') == 1

def test_count_upper_example2():
    assert count_upper('abcdefg') == 0

def test_count_upper_example3():
    assert count_upper('dBBE') == 0

def test_count_upper_empty_string():
    assert count_upper('') == 0

def test_count_upper_single_uppercase_vowel():
    assert count_upper('A') == 1

def test_count_upper_single_lowercase_vowel():
    assert count_upper('a') == 0

def test_count_upper_single_uppercase_consonant():
    assert count_upper('B') == 0

def test_count_upper_all_uppercase_vowels_even():
    assert count_upper('AEIOU') == 3

def test_count_upper_all_uppercase_vowels_odd():
    assert count_upper('xAxExI') == 0

def test_count_upper_mixed_even_odd():
    assert count_upper('AaEeIiOoUu') == 5

def test_count_upper_only_consonants():
    assert count_upper('BCDFG') == 0

def test_count_upper_lowercase_vowels_even():
    assert count_upper('aeiou') == 0

def test_count_upper_uppercase_vowels_at_even_indices():
    assert count_upper('AxExIxOxU') == 5

def test_count_upper_uppercase_vowels_at_odd_indices():
    assert count_upper('xAxExIxO') == 0

def test_count_upper_two_chars_uppercase_vowel_first():
    assert count_upper('Ab') == 1

def test_count_upper_two_chars_uppercase_vowel_second():
    assert count_upper('aE') == 0

def test_count_upper_long_string_no_vowels():
    assert count_upper('BcDfGhJkLmNpQrStVwXyZ') == 0

def test_count_upper_long_string_with_vowels():
    assert count_upper('AaBbEeCcIiDdOoFfUuGg') == 5

def test_count_upper_all_same_uppercase_vowel():
    assert count_upper('AAAA') == 2

def test_count_upper_alternating_uppercase_vowel_consonant():
    assert count_upper('AbAbAbAb') == 4

@pytest.mark.parametrize("input_str,expected", [
    ('', 0),
    ('A', 1),
    ('a', 0),
    ('AA', 1),
    ('AaA', 2),
    ('AaAa', 2),
    ('AEIOU', 3),
    ('aeiou', 0),
    ('aBCdEf', 1),
    ('EBCDAF', 2),
    ('xAxExI', 0),
    ('AxExIxOxU', 5),
    ('BCDFG', 0),
    ('EbCdEf', 2),
    ('OxIxExAx', 4),
])
def test_count_upper_parametrized(input_str, expected):
    assert count_upper(input_str) == expected