# Test cases for HumanEval/11
# Generated using Claude API

from typing import List


def string_xor(a: str, b: str) -> str:
    """ Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.
    >>> string_xor('010', '110')
    '100'
    """

    def xor(i, j):
        if i == j:
            return '0'
        else:
            return '1'

    return ''.join(xor(x, y) for x, y in zip(a, b))


# Generated test cases:
import pytest
from typing import List


def string_xor(a: str, b: str) -> str:
    def xor(i, j):
        if i == j:
            return '0'
        else:
            return '1'

    return ''.join(xor(x, y) for x, y in zip(a, b))


@pytest.mark.parametrize("a,b,expected", [
    ("010", "110", "100"),
    ("0", "0", "0"),
    ("1", "1", "0"),
    ("0", "1", "1"),
    ("1", "0", "1"),
    ("00", "00", "00"),
    ("11", "11", "00"),
    ("01", "10", "11"),
    ("10", "01", "11"),
    ("000", "000", "000"),
    ("111", "111", "000"),
    ("101", "010", "111"),
    ("1010", "1100", "0110"),
    ("00000", "11111", "11111"),
    ("10101", "01010", "11111"),
    ("11110000", "10101010", "01011010"),
    ("1", "0", "1"),
    ("0000000000", "0000000000", "0000000000"),
    ("1111111111", "1111111111", "0000000000"),
    ("1010101010", "0101010101", "1111111111"),
])
def test_string_xor_parametrized(a, b, expected):
    assert string_xor(a, b) == expected


def test_string_xor_single_bit_same():
    assert string_xor("0", "0") == "0"
    assert string_xor("1", "1") == "0"


def test_string_xor_single_bit_different():
    assert string_xor("0", "1") == "1"
    assert string_xor("1", "0") == "1"


def test_string_xor_multiple_bits():
    assert string_xor("010", "110") == "100"
    assert string_xor("1010", "1100") == "0110"


def test_string_xor_all_zeros():
    assert string_xor("000", "000") == "000"
    assert string_xor("0000", "0000") == "0000"


def test_string_xor_all_ones():
    assert string_xor("111", "111") == "000"
    assert string_xor("1111", "1111") == "0000"


def test_string_xor_alternating_patterns():
    assert string_xor("10101", "01010") == "11111"
    assert string_xor("101010", "010101") == "111111"


def test_string_xor_long_strings():
    assert string_xor("10101010", "01010101") == "11111111"
    assert string_xor("11110000", "10101010") == "01011010"


def test_string_xor_empty_strings():
    assert string_xor("", "") == ""
