# Test cases for HumanEval/5
# Generated using Claude API

from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """ Insert a number 'delimeter' between every two consecutive elements of input list `numbers'
    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """

    if not numbers:
        return []

    result = []

    for n in numbers[:-1]:
        result.append(n)
        result.append(delimeter)

    result.append(numbers[-1])

    return result


# Generated test cases:
import pytest
from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    if not numbers:
        return []

    result = []

    for n in numbers[:-1]:
        result.append(n)
        result.append(delimeter)

    result.append(numbers[-1])

    return result


class TestIntersperse:
    def test_empty_list(self):
        assert intersperse([], 4) == []
    
    def test_empty_list_with_zero_delimiter(self):
        assert intersperse([], 0) == []
    
    def test_single_element(self):
        assert intersperse([1], 4) == [1]
    
    def test_single_element_with_zero(self):
        assert intersperse([0], 5) == [0]
    
    def test_two_elements(self):
        assert intersperse([1, 2], 4) == [1, 4, 2]
    
    def test_three_elements(self):
        assert intersperse([1, 2, 3], 4) == [1, 4, 2, 4, 3]
    
    def test_multiple_elements(self):
        assert intersperse([1, 2, 3, 4, 5], 0) == [1, 0, 2, 0, 3, 0, 4, 0, 5]
    
    def test_negative_numbers(self):
        assert intersperse([-1, -2, -3], -4) == [-1, -4, -2, -4, -3]
    
    def test_mixed_positive_negative(self):
        assert intersperse([1, -2, 3], 0) == [1, 0, -2, 0, 3]
    
    def test_zero_delimiter(self):
        assert intersperse([1, 2, 3], 0) == [1, 0, 2, 0, 3]
    
    def test_zero_elements(self):
        assert intersperse([0, 0, 0], 1) == [0, 1, 0, 1, 0]
    
    def test_large_numbers(self):
        assert intersperse([1000000, 2000000], 999999) == [1000000, 999999, 2000000]
    
    def test_same_number_and_delimiter(self):
        assert intersperse([5, 5, 5], 5) == [5, 5, 5, 5, 5]
    
    @pytest.mark.parametrize("numbers,delimeter,expected", [
        ([], 1, []),
        ([1], 2, [1]),
        ([1, 2], 3, [1, 3, 2]),
        ([1, 2, 3], 4, [1, 4, 2, 4, 3]),
        ([10, 20, 30, 40], 5, [10, 5, 20, 5, 30, 5, 40]),
        ([0], 0, [0]),
        ([-1, -2], -3, [-1, -3, -2]),
    ])
    def test_parametrized(self, numbers, delimeter, expected):
        assert intersperse(numbers, delimeter) == expected
