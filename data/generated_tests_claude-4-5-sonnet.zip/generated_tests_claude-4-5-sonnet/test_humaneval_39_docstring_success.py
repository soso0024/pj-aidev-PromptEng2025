# Test cases for HumanEval/39
# Generated using Claude API



def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """

    import math

    def is_prime(p):
        if p < 2:
            return False
        for k in range(2, min(int(math.sqrt(p)) + 1, p - 1)):
            if p % k == 0:
                return False
        return True
    f = [0, 1]
    while True:
        f.append(f[-1] + f[-2])
        if is_prime(f[-1]):
            n -= 1
        if n == 0:
            return f[-1]


# Generated test cases:
import pytest
import math


def prime_fib(n: int):
    def is_prime(p):
        if p < 2:
            return False
        for k in range(2, min(int(math.sqrt(p)) + 1, p - 1)):
            if p % k == 0:
                return False
        return True
    f = [0, 1]
    while True:
        f.append(f[-1] + f[-2])
        if is_prime(f[-1]):
            n -= 1
        if n == 0:
            return f[-1]


@pytest.mark.parametrize("n,expected", [
    (1, 2),
    (2, 3),
    (3, 5),
    (4, 13),
    (5, 89),
])
def test_prime_fib_basic_cases(n, expected):
    assert prime_fib(n) == expected


def test_prime_fib_first():
    assert prime_fib(1) == 2


def test_prime_fib_second():
    assert prime_fib(2) == 3


def test_prime_fib_third():
    assert prime_fib(3) == 5


def test_prime_fib_fourth():
    assert prime_fib(4) == 13


def test_prime_fib_fifth():
    assert prime_fib(5) == 89


def test_prime_fib_sixth():
    assert prime_fib(6) == 233


def test_prime_fib_seventh():
    assert prime_fib(7) == 1597


def test_prime_fib_returns_int():
    result = prime_fib(1)
    assert isinstance(result, int)


def test_prime_fib_positive_result():
    for i in range(1, 6):
        assert prime_fib(i) > 0


def test_prime_fib_increasing():
    results = [prime_fib(i) for i in range(1, 6)]
    for i in range(len(results) - 1):
        assert results[i] < results[i + 1]


def test_prime_fib_all_prime():
    def is_prime(p):
        if p < 2:
            return False
        for k in range(2, min(int(math.sqrt(p)) + 1, p - 1)):
            if p % k == 0:
                return False
        return True
    
    for i in range(1, 6):
        result = prime_fib(i)
        assert is_prime(result)


def test_prime_fib_all_fibonacci():
    def is_fibonacci(num):
        a, b = 0, 1
        while b < num:
            a, b = b, a + b
        return b == num
    
    for i in range(1, 6):
        result = prime_fib(i)
        assert is_fibonacci(result)
