# Test cases for HumanEval/36
# Generated using Claude API



def fizz_buzz(n: int):
    """Return the number of times the digit 7 appears in integers less than n which are divisible by 11 or 13.
    >>> fizz_buzz(50)
    0
    >>> fizz_buzz(78)
    2
    >>> fizz_buzz(79)
    3
    """

    ns = []
    for i in range(n):
        if i % 11 == 0 or i % 13 == 0:
            ns.append(i)
    s = ''.join(list(map(str, ns)))
    ans = 0
    for c in s:
        ans += (c == '7')
    return ans


# Generated test cases:
import pytest

def fizz_buzz(n: int):
    ns = []
    for i in range(n):
        if i % 11 == 0 or i % 13 == 0:
            ns.append(i)
    s = ''.join(list(map(str, ns)))
    ans = 0
    for c in s:
        ans += (c == '7')
    return ans

def test_fizz_buzz_50():
    assert fizz_buzz(50) == 0

def test_fizz_buzz_78():
    assert fizz_buzz(78) == 2

def test_fizz_buzz_79():
    assert fizz_buzz(79) == 3

def test_fizz_buzz_0():
    assert fizz_buzz(0) == 0

def test_fizz_buzz_1():
    assert fizz_buzz(1) == 0

def test_fizz_buzz_11():
    assert fizz_buzz(11) == 0

def test_fizz_buzz_12():
    assert fizz_buzz(12) == 0

def test_fizz_buzz_13():
    assert fizz_buzz(13) == 0

def test_fizz_buzz_14():
    assert fizz_buzz(14) == 0

def test_fizz_buzz_77():
    assert fizz_buzz(77) == 0

def test_fizz_buzz_78_detailed():
    assert fizz_buzz(78) == 2

def test_fizz_buzz_100():
    assert fizz_buzz(100) == 3

def test_fizz_buzz_200():
    assert fizz_buzz(200) == 6

def test_fizz_buzz_with_77_included():
    assert fizz_buzz(78) == 2

def test_fizz_buzz_with_77_and_78():
    assert fizz_buzz(79) == 3

def test_fizz_buzz_negative():
    assert fizz_buzz(-10) == 0

def test_fizz_buzz_large_number():
    result = fizz_buzz(1000)
    assert isinstance(result, int)
    assert result >= 0

@pytest.mark.parametrize("n,expected", [
    (0, 0),
    (1, 0),
    (11, 0),
    (13, 0),
    (50, 0),
    (78, 2),
    (79, 3),
    (100, 3),
])
def test_fizz_buzz_parametrized(n, expected):
    assert fizz_buzz(n) == expected

def test_fizz_buzz_22():
    assert fizz_buzz(22) == 0

def test_fizz_buzz_26():
    assert fizz_buzz(26) == 0

def test_fizz_buzz_33():
    assert fizz_buzz(33) == 0

def test_fizz_buzz_44():
    assert fizz_buzz(44) == 0

def test_fizz_buzz_55():
    assert fizz_buzz(55) == 0

def test_fizz_buzz_66():
    assert fizz_buzz(66) == 0

def test_fizz_buzz_88():
    assert fizz_buzz(88) == 3