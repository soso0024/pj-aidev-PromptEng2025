# Test cases for HumanEval/51
# Generated using Claude API



def remove_vowels(text):
    """
    remove_vowels is a function that takes string and returns string without vowels.
    >>> remove_vowels('')
    ''
    >>> remove_vowels("abcdef\nghijklm")
    'bcdf\nghjklm'
    >>> remove_vowels('abcdef')
    'bcdf'
    >>> remove_vowels('aaaaa')
    ''
    >>> remove_vowels('aaBAA')
    'B'
    >>> remove_vowels('zbcd')
    'zbcd'
    """

    return "".join([s for s in text if s.lower() not in ["a", "e", "i", "o", "u"]])


# Generated test cases:
import pytest


def remove_vowels(text):
    return "".join([s for s in text if s.lower() not in ["a", "e", "i", "o", "u"]])


def test_remove_vowels_empty_string():
    assert remove_vowels("") == ""


def test_remove_vowels_no_vowels():
    assert remove_vowels("bcdfg") == "bcdfg"


def test_remove_vowels_only_vowels():
    assert remove_vowels("aeiou") == ""


def test_remove_vowels_mixed_case_vowels():
    assert remove_vowels("AEIOUaeiou") == ""


def test_remove_vowels_simple_word():
    assert remove_vowels("hello") == "hll"


def test_remove_vowels_sentence():
    assert remove_vowels("Hello World") == "Hll Wrld"


def test_remove_vowels_with_numbers():
    assert remove_vowels("abc123def") == "bc123df"


def test_remove_vowels_with_special_chars():
    assert remove_vowels("a!b@c#e$i%") == "!b@c#$%"


def test_remove_vowels_uppercase():
    assert remove_vowels("HELLO") == "HLL"


def test_remove_vowels_mixed_case():
    assert remove_vowels("HeLLo WoRLd") == "HLL WRLd"


def test_remove_vowels_with_spaces():
    assert remove_vowels("a e i o u") == "    "


def test_remove_vowels_single_vowel():
    assert remove_vowels("a") == ""


def test_remove_vowels_single_consonant():
    assert remove_vowels("b") == "b"


def test_remove_vowels_repeated_vowels():
    assert remove_vowels("aaaeeeiiiooo") == ""


def test_remove_vowels_repeated_consonants():
    assert remove_vowels("bbbcccdddfff") == "bbbcccdddfff"


@pytest.mark.parametrize("input_text,expected", [
    ("", ""),
    ("a", ""),
    ("b", "b"),
    ("aeiou", ""),
    ("AEIOU", ""),
    ("bcdfg", "bcdfg"),
    ("hello", "hll"),
    ("HELLO", "HLL"),
    ("Hello World", "Hll Wrld"),
    ("Python", "Pythn"),
    ("123", "123"),
    ("!@#$%", "!@#$%"),
    ("a1e2i3o4u5", "12345"),
    ("The quick brown fox", "Th qck brwn fx"),
])
def test_remove_vowels_parametrized(input_text, expected):
    assert remove_vowels(input_text) == expected


def test_remove_vowels_long_string():
    input_str = "The quick brown fox jumps over the lazy dog"
    expected = "Th qck brwn fx jmps vr th lzy dg"
    assert remove_vowels(input_str) == expected


def test_remove_vowels_with_newlines():
    assert remove_vowels("hello\nworld") == "hll\nwrld"


def test_remove_vowels_with_tabs():
    assert remove_vowels("hello\tworld") == "hll\twrld"


def test_remove_vowels_unicode_non_vowels():
    assert remove_vowels("café") == "cfé"


def test_remove_vowels_all_uppercase_vowels():
    assert remove_vowels("AEIOU") == ""


def test_remove_vowels_alternating():
    assert remove_vowels("ababab") == "bbb"