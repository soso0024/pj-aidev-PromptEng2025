# Test cases for HumanEval/49
# Generated using Claude API



def modp(n: int, p: int):
    """Return 2^n modulo p (be aware of numerics).
    >>> modp(3, 5)
    3
    >>> modp(1101, 101)
    2
    >>> modp(0, 101)
    1
    >>> modp(3, 11)
    8
    >>> modp(100, 101)
    1
    """

    ret = 1
    for i in range(n):
        ret = (2 * ret) % p
    return ret


# Generated test cases:
import pytest

def modp(n: int, p: int):
    ret = 1
    for i in range(n):
        ret = (2 * ret) % p
    return ret

@pytest.mark.parametrize("n,p,expected", [
    (3, 5, 3),
    (1101, 101, 2),
    (0, 101, 1),
    (3, 11, 8),
    (100, 101, 1),
    (1, 2, 0),
    (1, 3, 2),
    (2, 3, 1),
    (4, 5, 1),
    (5, 7, 4),
    (10, 13, 10),
    (0, 2, 1),
    (0, 1000, 1),
    (1, 1000, 2),
    (2, 1000, 4),
    (3, 1000, 8),
    (10, 1000, 24),
    (50, 97, 4),
    (7, 13, 11),
    (8, 13, 9),
    (15, 17, 9),
    (20, 23, 6),
    (1, 5, 2),
    (2, 5, 4),
    (4, 5, 1),
    (5, 5, 2),
    (6, 5, 4),
    (10, 11, 1),
    (11, 11, 2),
    (12, 11, 4),
])
def test_modp_parametrized(n, p, expected):
    assert modp(n, p) == expected

def test_modp_zero_exponent():
    assert modp(0, 5) == 1
    assert modp(0, 100) == 1
    assert modp(0, 2) == 1

def test_modp_small_values():
    assert modp(1, 2) == 0
    assert modp(1, 3) == 2
    assert modp(2, 3) == 1

def test_modp_large_exponent():
    assert modp(1000, 101) == 1
    assert modp(500, 97) == 6

def test_modp_power_of_two_modulo():
    assert modp(10, 1024) == 0
    assert modp(5, 32) == 0

def test_modp_prime_modulo():
    assert modp(6, 7) == 1
    assert modp(10, 11) == 1
    assert modp(12, 13) == 1

def test_modp_consistency():
    for n in range(20):
        for p in [2, 3, 5, 7, 11, 13]:
            result = modp(n, p)
            assert 0 <= result < p
            assert result == pow(2, n, p)