# Test cases for HumanEval/108
# Generated using Claude API


def count_nums(arr):
    """
    Write a function count_nums which takes an array of integers and returns
    the number of elements which has a sum of digits > 0.
    If a number is negative, then its first signed digit will be negative:
    e.g. -123 has signed digits -1, 2, and 3.
    >>> count_nums([]) == 0
    >>> count_nums([-1, 11, -11]) == 1
    >>> count_nums([1, 1, 2]) == 3
    """

    def digits_sum(n):
        neg = 1
        if n < 0: n, neg = -1 * n, -1 
        n = [int(i) for i in str(n)]
        n[0] = n[0] * neg
        return sum(n)
    return len(list(filter(lambda x: x > 0, [digits_sum(i) for i in arr])))


# Generated test cases:
import pytest

def count_nums(arr):
    def digits_sum(n):
        neg = 1
        if n < 0: n, neg = -1 * n, -1 
        n = [int(i) for i in str(n)]
        n[0] = n[0] * neg
        return sum(n)
    return len(list(filter(lambda x: x > 0, [digits_sum(i) for i in arr])))

@pytest.mark.parametrize("arr,expected", [
    ([], 0),
    ([1, 2, 3], 3),
    ([-1, -2, -3], 0),
    ([0], 0),
    ([1, 1, 2, -2, 3, 4, 5], 6),
    ([-1, 11, -11], 1),
    ([1, 6, 9, -6, 0, 1, 5], 5),
    ([0, 0, 0], 0),
    ([10, 20, 30], 3),
    ([-10, -20, -30], 0),
    ([12, 3, 4, -5, -12, -7, 14, -11], 5),
    ([100], 1),
    ([-100], 0),
    ([99, -99], 1),
    ([1], 1),
    ([-1], 0),
    ([123, 456, 789], 3),
    ([-123, -456, -789], 3),
    ([10, -10], 1),
    ([11, -11], 1),
    ([19, -19], 2),
    ([20, -20], 1),
    ([21, -21], 1),
    ([9, -9], 1),
    ([8, -8], 1),
    ([1, 2, 3, 4, 5, 6, 7, 8, 9], 9),
    ([-1, -2, -3, -4, -5, -6, -7, -8, -9], 0),
    ([0, 1, 2, 3], 3),
    ([0, -1, -2, -3], 0),
    ([1000, 2000, 3000], 3),
    ([-1000, -2000, -3000], 0),
    ([15, -15], 2),
    ([101, -101], 1),
    ([111, -111], 2),
    ([1234, -1234], 2),
    ([5, 10, 15, 20], 4),
    ([-5, -10, -15, -20], 1),
    ([7], 1),
    ([-7], 0),
    ([50, -50], 1),
    ([99, 100, 101], 3),
    ([-99, -100, -101], 0),
])
def test_count_nums(arr, expected):
    assert count_nums(arr) == expected

def test_count_nums_empty_list():
    assert count_nums([]) == 0

def test_count_nums_single_positive():
    assert count_nums([5]) == 1

def test_count_nums_single_negative():
    assert count_nums([-5]) == 0

def test_count_nums_single_zero():
    assert count_nums([0]) == 0

def test_count_nums_all_positive():
    assert count_nums([1, 2, 3, 4, 5]) == 5

def test_count_nums_all_negative():
    assert count_nums([-1, -2, -3, -4, -5]) == 0

def test_count_nums_mixed():
    assert count_nums([1, -1, 2, -2, 3, -3]) == 3

def test_count_nums_with_zeros():
    assert count_nums([0, 0, 1, 2, 0]) == 2

def test_count_nums_large_numbers():
    assert count_nums([9999, -9999, 8888]) == 3

def test_count_nums_negative_with_positive_digit_sum():
    assert count_nums([-10]) == 0

def test_count_nums_negative_with_negative_digit_sum():
    assert count_nums([-11]) == 0