# Test cases for HumanEval/120
# Generated using Claude API


def maximum(arr, k):
    """
    Given an array arr of integers and a positive integer k, return a sorted list 
    of length k with the maximum k numbers in arr.

    Example 1:

        Input: arr = [-3, -4, 5], k = 3
        Output: [-4, -3, 5]

    Example 2:

        Input: arr = [4, -4, 4], k = 2
        Output: [4, 4]

    Example 3:

        Input: arr = [-3, 2, 1, 2, -1, -2, 1], k = 1
        Output: [2]

    Note:
        1. The length of the array will be in the range of [1, 1000].
        2. The elements in the array will be in the range of [-1000, 1000].
        3. 0 <= k <= len(arr)
    """

    if k == 0:
        return []
    arr.sort()
    ans = arr[-k:]
    return ans


# Generated test cases:
import pytest


def maximum(arr, k):
    if k == 0:
        return []
    arr.sort()
    ans = arr[-k:]
    return ans


@pytest.mark.parametrize("arr,k,expected", [
    ([-3, -4, 5], 3, [-4, -3, 5]),
    ([4, -4, 4], 2, [4, 4]),
    ([-3, 2, 1, 2, -1, -2, 1], 1, [2]),
    ([1, 2, 3, 4, 5], 0, []),
    ([5], 1, [5]),
    ([1, 2, 3, 4, 5], 5, [1, 2, 3, 4, 5]),
    ([10, 9, 8, 7, 6, 5, 4, 3, 2, 1], 3, [8, 9, 10]),
    ([-1, -2, -3, -4, -5], 2, [-2, -1]),
    ([0, 0, 0, 0], 2, [0, 0]),
    ([100, -100, 50, -50, 0], 3, [0, 50, 100]),
    ([1], 0, []),
    ([5, 5, 5, 5, 5], 3, [5, 5, 5]),
    ([-1000, 1000], 2, [-1000, 1000]),
    ([-1000, 1000], 1, [1000]),
    ([1, 2, 3], 1, [3]),
    ([3, 2, 1], 1, [3]),
    ([1, 1, 1, 2, 2, 2], 3, [2, 2, 2]),
    ([7, 6, 5, 4, 3, 2, 1], 4, [4, 5, 6, 7]),
    ([-5, -10, -3, -8, -1], 3, [-5, -3, -1]),
    ([0], 1, [0]),
    ([0], 0, []),
    ([100, 200, 300, 400, 500], 2, [400, 500]),
    ([-100, -200, -300], 1, [-100]),
])
def test_maximum(arr, k, expected):
    assert maximum(arr, k) == expected


def test_maximum_empty_k():
    assert maximum([1, 2, 3, 4, 5], 0) == []


def test_maximum_single_element():
    assert maximum([42], 1) == [42]


def test_maximum_all_elements():
    arr = [3, 1, 4, 1, 5, 9, 2, 6]
    k = len(arr)
    result = maximum(arr, k)
    assert result == sorted(arr)


def test_maximum_negative_numbers():
    assert maximum([-10, -20, -5, -15], 2) == [-10, -5]


def test_maximum_mixed_numbers():
    assert maximum([-5, 0, 5, -10, 10], 3) == [0, 5, 10]


def test_maximum_duplicates():
    assert maximum([3, 3, 3, 1, 1], 3) == [3, 3, 3]


def test_maximum_large_k():
    arr = [1, 2, 3]
    assert maximum(arr, 3) == [1, 2, 3]


def test_maximum_preserves_order_in_result():
    arr = [5, 1, 9, 3, 7]
    result = maximum(arr, 3)
    assert result == [5, 7, 9]
    assert result == sorted(result)
