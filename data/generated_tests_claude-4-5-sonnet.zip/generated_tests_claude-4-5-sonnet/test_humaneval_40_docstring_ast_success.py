# Test cases for HumanEval/40
# Generated using Claude API



def triples_sum_to_zero(l: list):
    """
    triples_sum_to_zero takes a list of integers as an input.
    it returns True if there are three distinct elements in the list that
    sum to zero, and False otherwise.

    >>> triples_sum_to_zero([1, 3, 5, 0])
    False
    >>> triples_sum_to_zero([1, 3, -2, 1])
    True
    >>> triples_sum_to_zero([1, 2, 3, 7])
    False
    >>> triples_sum_to_zero([2, 4, -5, 3, 9, 7])
    True
    >>> triples_sum_to_zero([1])
    False
    """

    for i in range(len(l)):
        for j in range(i + 1, len(l)):
            for k in range(j + 1, len(l)):
                if l[i] + l[j] + l[k] == 0:
                    return True
    return False


# Generated test cases:
import pytest

def triples_sum_to_zero(l: list):
    for i in range(len(l)):
        for j in range(i + 1, len(l)):
            for k in range(j + 1, len(l)):
                if l[i] + l[j] + l[k] == 0:
                    return True
    return False

def test_triples_sum_to_zero_example_1():
    assert triples_sum_to_zero([1, 3, 5, 0]) == False

def test_triples_sum_to_zero_example_2():
    assert triples_sum_to_zero([1, 3, -2, 1]) == True

def test_triples_sum_to_zero_example_3():
    assert triples_sum_to_zero([1, 2, 3, 7]) == False

def test_triples_sum_to_zero_example_4():
    assert triples_sum_to_zero([2, 4, -5, 3, 9, 7]) == True

def test_triples_sum_to_zero_example_5():
    assert triples_sum_to_zero([1]) == False

def test_triples_sum_to_zero_empty_list():
    assert triples_sum_to_zero([]) == False

def test_triples_sum_to_zero_two_elements():
    assert triples_sum_to_zero([1, -1]) == False

def test_triples_sum_to_zero_three_elements_sum_zero():
    assert triples_sum_to_zero([1, -1, 0]) == True

def test_triples_sum_to_zero_three_elements_no_sum():
    assert triples_sum_to_zero([1, 2, 3]) == False

def test_triples_sum_to_zero_all_zeros():
    assert triples_sum_to_zero([0, 0, 0]) == True

def test_triples_sum_to_zero_with_duplicates():
    assert triples_sum_to_zero([1, 1, -2]) == True

def test_triples_sum_to_zero_negative_numbers():
    assert triples_sum_to_zero([-1, -2, -3]) == False

def test_triples_sum_to_zero_mixed_positive_negative():
    assert triples_sum_to_zero([5, -5, 0]) == True

def test_triples_sum_to_zero_large_list_with_triple():
    assert triples_sum_to_zero([1, 2, 3, 4, 5, -6]) == True

def test_triples_sum_to_zero_large_list_without_triple():
    assert triples_sum_to_zero([1, 2, 3, 4, 5, 6]) == False

def test_triples_sum_to_zero_multiple_valid_triples():
    assert triples_sum_to_zero([1, -1, 0, 2, -2]) == True

def test_triples_sum_to_zero_at_beginning():
    assert triples_sum_to_zero([1, 2, -3, 4, 5]) == True

def test_triples_sum_to_zero_at_end():
    assert triples_sum_to_zero([4, 5, 1, 2, -3]) == True

def test_triples_sum_to_zero_single_zero():
    assert triples_sum_to_zero([0]) == False

def test_triples_sum_to_zero_two_zeros():
    assert triples_sum_to_zero([0, 0]) == False

def test_triples_sum_to_zero_four_zeros():
    assert triples_sum_to_zero([0, 0, 0, 0]) == True

def test_triples_sum_to_zero_large_numbers():
    assert triples_sum_to_zero([1000, -500, -500]) == True

def test_triples_sum_to_zero_no_triple_large_numbers():
    assert triples_sum_to_zero([1000, 2000, 3000]) == False

@pytest.mark.parametrize("input_list,expected", [
    ([1, 3, 5, 0], False),
    ([1, 3, -2, 1], True),
    ([1, 2, 3, 7], False),
    ([2, 4, -5, 3, 9, 7], True),
    ([1], False),
    ([], False),
    ([0, 0, 0], True),
    ([1, -1, 0], True),
    ([-1, -2, 3], True),
    ([10, -5, -5], True),
])
def test_triples_sum_to_zero_parametrized(input_list, expected):
    assert triples_sum_to_zero(input_list) == expected
