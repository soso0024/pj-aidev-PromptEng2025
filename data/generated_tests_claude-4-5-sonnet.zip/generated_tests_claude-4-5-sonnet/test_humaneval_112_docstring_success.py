# Test cases for HumanEval/112
# Generated using Claude API


def reverse_delete(s,c):
    """Task
    We are given two strings s and c, you have to deleted all the characters in s that are equal to any character in c
    then check if the result string is palindrome.
    A string is called palindrome if it reads the same backward as forward.
    You should return a tuple containing the result string and True/False for the check.
    Example
    For s = "abcde", c = "ae", the result should be ('bcd',False)
    For s = "abcdef", c = "b"  the result should be ('acdef',False)
    For s = "abcdedcba", c = "ab", the result should be ('cdedc',True)
    """

    s = ''.join([char for char in s if char not in c])
    return (s,s[::-1] == s)


# Generated test cases:
import pytest

def reverse_delete(s,c):
    s = ''.join([char for char in s if char not in c])
    return (s,s[::-1] == s)

@pytest.mark.parametrize("s,c,expected", [
    ("abcde", "ae", ("bcd", False)),
    ("abcdef", "b", ("acdef", False)),
    ("abcdedcba", "ab", ("cdedc", True)),
    ("", "", ("", True)),
    ("", "abc", ("", True)),
    ("abc", "", ("abc", False)),
    ("aaa", "a", ("", True)),
    ("abcba", "d", ("abcba", True)),
    ("racecar", "xyz", ("racecar", True)),
    ("hello", "l", ("heo", False)),
    ("aabbcc", "abc", ("", True)),
    ("abcdefg", "abcdefg", ("", True)),
    ("a", "a", ("", True)),
    ("a", "b", ("a", True)),
    ("aa", "a", ("", True)),
    ("ab", "a", ("b", True)),
    ("ab", "b", ("a", True)),
    ("aba", "b", ("aa", True)),
    ("abba", "b", ("aa", True)),
    ("abcba", "c", ("abba", True)),
    ("abcba", "b", ("aca", True)),
    ("12321", "2", ("131", True)),
    ("12321", "1", ("232", True)),
    ("12321", "3", ("1221", True)),
    ("abcdefghijklmnopqrstuvwxyz", "aeiou", ("bcdfghjklmnpqrstvwxyz", False)),
    ("racecar", "r", ("aceca", True)),
    ("racecar", "e", ("raccar", True)),
    ("noon", "n", ("oo", True)),
    ("noon", "o", ("nn", True)),
    ("level", "e", ("lvl", True)),
    ("level", "l", ("eve", True)),
    ("aabbaa", "b", ("aaaa", True)),
    ("aabbaa", "a", ("bb", True)),
    ("xyz", "xyz", ("", True)),
    ("abcdefedcba", "f", ("abcdeedcba", True)),
    ("abcdefedcba", "e", ("abcdfdcba", True)),
])
def test_reverse_delete(s, c, expected):
    assert reverse_delete(s, c) == expected

def test_reverse_delete_single_char_palindrome():
    assert reverse_delete("x", "y") == ("x", True)

def test_reverse_delete_all_same_chars():
    assert reverse_delete("aaaa", "a") == ("", True)

def test_reverse_delete_no_deletion():
    assert reverse_delete("abcba", "xyz") == ("abcba", True)

def test_reverse_delete_complete_deletion():
    assert reverse_delete("abc", "abc") == ("", True)

def test_reverse_delete_multiple_chars_to_delete():
    assert reverse_delete("abcdefg", "bdf") == ("aceg", False)

def test_reverse_delete_palindrome_result():
    assert reverse_delete("abccba", "d") == ("abccba", True)

def test_reverse_delete_non_palindrome_result():
    assert reverse_delete("abcdef", "f") == ("abcde", False)