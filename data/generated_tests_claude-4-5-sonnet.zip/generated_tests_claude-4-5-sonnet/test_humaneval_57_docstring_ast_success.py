# Test cases for HumanEval/57
# Generated using Claude API



def monotonic(l: list):
    """Return True is list elements are monotonically increasing or decreasing.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """

    if l == sorted(l) or l == sorted(l, reverse=True):
        return True
    return False


# Generated test cases:
import pytest

def monotonic(l: list):
    """Return True is list elements are monotonically increasing or decreasing.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """
    if l == sorted(l) or l == sorted(l, reverse=True):
        return True
    return False

@pytest.mark.parametrize("input_list,expected", [
    ([1, 2, 4, 20], True),
    ([1, 20, 4, 10], False),
    ([4, 1, 0, -10], True),
    ([], True),
    ([1], True),
    ([1, 1], True),
    ([1, 1, 1, 1], True),
    ([1, 2, 2, 3], True),
    ([3, 2, 2, 1], True),
    ([1, 2, 3, 4, 5], True),
    ([5, 4, 3, 2, 1], True),
    ([1, 3, 2, 4], False),
    ([1, 2, 1], False),
    ([-5, -4, -3, -2, -1], True),
    ([-1, -2, -3, -4, -5], True),
    ([0, 0, 0], True),
    ([1, 2, 3, 2, 1], False),
    ([-10, -5, 0, 5, 10], True),
    ([10, 5, 0, -5, -10], True),
    ([1.5, 2.5, 3.5], True),
    ([3.5, 2.5, 1.5], True),
    ([1.5, 3.5, 2.5], False),
    ([0], True),
    ([100, 100, 100], True),
    ([1, 2, 3, 3, 4], True),
    ([4, 3, 3, 2, 1], True),
    ([1, 3, 2], False),
    ([2, 1, 3], False),
    ([5, 5, 4, 4, 3, 3], True),
    ([1, 1, 2, 2, 3, 3], True),
])
def test_monotonic(input_list, expected):
    assert monotonic(input_list) == expected

def test_monotonic_empty_list():
    assert monotonic([]) == True

def test_monotonic_single_element():
    assert monotonic([42]) == True

def test_monotonic_two_equal_elements():
    assert monotonic([5, 5]) == True

def test_monotonic_increasing():
    assert monotonic([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == True

def test_monotonic_decreasing():
    assert monotonic([10, 9, 8, 7, 6, 5, 4, 3, 2, 1]) == True

def test_monotonic_not_monotonic():
    assert monotonic([1, 3, 2, 4, 5]) == False

def test_monotonic_with_duplicates_increasing():
    assert monotonic([1, 1, 2, 2, 3, 3]) == True

def test_monotonic_with_duplicates_decreasing():
    assert monotonic([3, 3, 2, 2, 1, 1]) == True

def test_monotonic_all_same():
    assert monotonic([7, 7, 7, 7, 7]) == True

def test_monotonic_negative_numbers_increasing():
    assert monotonic([-10, -5, -1, 0, 5]) == True

def test_monotonic_negative_numbers_decreasing():
    assert monotonic([5, 0, -1, -5, -10]) == True

def test_monotonic_floats_increasing():
    assert monotonic([0.1, 0.2, 0.3, 0.4]) == True

def test_monotonic_floats_decreasing():
    assert monotonic([0.4, 0.3, 0.2, 0.1]) == True

def test_monotonic_mixed_positive_negative():
    assert monotonic([-3, -1, 0, 2, 5]) == True
