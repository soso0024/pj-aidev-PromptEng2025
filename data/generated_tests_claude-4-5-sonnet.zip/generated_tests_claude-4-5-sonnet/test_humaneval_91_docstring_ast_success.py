# Test cases for HumanEval/91
# Generated using Claude API


def is_bored(S):
    """
    You'll be given a string of words, and your task is to count the number
    of boredoms. A boredom is a sentence that starts with the word "I".
    Sentences are delimited by '.', '?' or '!'.
   
    For example:
    >>> is_bored("Hello world")
    0
    >>> is_bored("The sky is blue. The sun is shining. I love this weather")
    1
    """

    import re
    sentences = re.split(r'[.?!]\s*', S)
    return sum(sentence[0:2] == 'I ' for sentence in sentences)


# Generated test cases:
import pytest


def is_bored(S):
    import re
    sentences = re.split(r'[.?!]\s*', S)
    return sum(sentence[0:2] == 'I ' for sentence in sentences if len(sentence) >= 2)


@pytest.mark.parametrize("input_str,expected", [
    ("Hello world", 0),
    ("The sky is blue. The sun is shining. I love this weather", 1),
    ("I am happy. I am sad. I am bored", 3),
    ("I love coding", 1),
    ("", 0),
    ("I am here. You are there. I am everywhere", 2),
    ("I am. I go. I see", 3),
    ("I am happy? I am sad! I am bored.", 3),
    ("The weather is nice. I think so", 1),
    ("You are great. He is good. She is fine", 0),
    ("I.", 0),
    ("I?", 0),
    ("I!", 0),
    ("I", 0),
    ("I ", 1),
    ("It is nice. I am here", 1),
    ("Is it true? I think so", 1),
    ("Is it true? It is", 0),
    ("I love this. I hate that. I don't care", 3),
    ("I.I.I", 0),
    ("I?I!I.", 0),
    ("I am here.I am there", 2),
    ("I am here. I am there", 2),
    ("I am here.  I am there", 2),
    ("I am here.   I am there", 2),
    ("No sentences here", 0),
    ("A sentence. Another one. Yet another", 0),
    ("I", 0),
    ("Interesting. I agree", 1),
    ("I agree. Interesting", 1),
    ("I. You. I", 0),
    ("I? You! I.", 0),
    ("   I am here", 0),
    ("I  am here", 1),
    ("Iam here", 0),
    ("I\tam here", 0),
    ("The end. I think. Or not? I guess", 2),
    ("Multiple delimiters... I see! Really? I do", 2),
    ("I love you. Do you love me? I hope so! Maybe", 2),
    (".", 0),
    ("?", 0),
    ("!", 0),
    ("...", 0),
    ("???", 0),
    ("!!!", 0),
    (".I am here", 1),
    ("?I am here", 1),
    ("!I am here", 1),
    ("Hello. I am here. Goodbye", 1),
    ("I. I. I. I. I", 0),
])
def test_is_bored_parametrized(input_str, expected):
    assert is_bored(input_str) == expected


def test_is_bored_empty_string():
    assert is_bored("") == 0


def test_is_bored_no_boredom():
    assert is_bored("Hello world") == 0


def test_is_bored_single_boredom():
    assert is_bored("The sky is blue. The sun is shining. I love this weather") == 1


def test_is_bored_multiple_boredoms():
    assert is_bored("I am happy. I am sad. I am bored") == 3


def test_is_bored_different_delimiters():
    assert is_bored("I am happy? I am sad! I am bored.") == 3


def test_is_bored_no_space_after_delimiter():
    assert is_bored("I am here.I am there") == 2


def test_is_bored_multiple_spaces_after_delimiter():
    assert is_bored("I am here.   I am there") == 2


def test_is_bored_single_i():
    assert is_bored("I") == 0


def test_is_bored_i_with_space():
    assert is_bored("I ") == 1


def test_is_bored_i_without_space():
    assert is_bored("Iam here") == 0


def test_is_bored_only_delimiters():
    assert is_bored("...") == 0


def test_is_bored_i_after_delimiter():
    assert is_bored(".I am here") == 1


def test_is_bored_mixed_sentences():
    assert is_bored("Hello. I am here. You are there. I am everywhere") == 2