# Test cases for HumanEval/48
# Generated using Claude API



def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """

    for i in range(len(text)):
        if text[i] != text[len(text) - 1 - i]:
            return False
    return True


# Generated test cases:
import pytest

def is_palindrome(text: str):
    for i in range(len(text)):
        if text[i] != text[len(text) - 1 - i]:
            return False
    return True

def test_empty_string():
    assert is_palindrome("") == True

def test_single_character():
    assert is_palindrome("a") == True

def test_two_same_characters():
    assert is_palindrome("aa") == True

def test_two_different_characters():
    assert is_palindrome("ab") == False

def test_odd_length_palindrome():
    assert is_palindrome("racecar") == True

def test_even_length_palindrome():
    assert is_palindrome("abba") == True

def test_not_palindrome():
    assert is_palindrome("hello") == False

def test_palindrome_with_spaces():
    assert is_palindrome("a b a") == True

def test_not_palindrome_with_spaces():
    assert is_palindrome("a b c") == False

def test_numeric_string_palindrome():
    assert is_palindrome("12321") == True

def test_numeric_string_not_palindrome():
    assert is_palindrome("12345") == False

def test_mixed_case_not_palindrome():
    assert is_palindrome("Aa") == False

def test_palindrome_lowercase():
    assert is_palindrome("aba") == True

def test_long_palindrome():
    assert is_palindrome("abcdefedcba") == True

def test_long_not_palindrome():
    assert is_palindrome("abcdefghijk") == False

@pytest.mark.parametrize("text,expected", [
    ("", True),
    ("a", True),
    ("aa", True),
    ("ab", False),
    ("aba", True),
    ("abc", False),
    ("racecar", True),
    ("hello", False),
    ("noon", True),
    ("12321", True),
    ("123456", False),
    ("aabbaa", True),
    ("aabbba", False),
])
def test_palindrome_parametrized(text, expected):
    assert is_palindrome(text) == expected
