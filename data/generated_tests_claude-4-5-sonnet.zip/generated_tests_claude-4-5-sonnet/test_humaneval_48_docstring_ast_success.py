# Test cases for HumanEval/48
# Generated using Claude API



def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """

    for i in range(len(text)):
        if text[i] != text[len(text) - 1 - i]:
            return False
    return True


# Generated test cases:
import pytest

def is_palindrome(text: str):
    for i in range(len(text)):
        if text[i] != text[len(text) - 1 - i]:
            return False
    return True

def test_is_palindrome_empty_string():
    assert is_palindrome('') == True

def test_is_palindrome_single_character():
    assert is_palindrome('a') == True

def test_is_palindrome_two_same_characters():
    assert is_palindrome('aa') == True

def test_is_palindrome_two_different_characters():
    assert is_palindrome('ab') == False

def test_is_palindrome_odd_length_palindrome():
    assert is_palindrome('aba') == True

def test_is_palindrome_even_length_palindrome():
    assert is_palindrome('abba') == True

def test_is_palindrome_all_same_characters():
    assert is_palindrome('aaaaa') == True

def test_is_palindrome_not_palindrome():
    assert is_palindrome('zbcd') == False

def test_is_palindrome_long_palindrome():
    assert is_palindrome('racecar') == True

def test_is_palindrome_long_not_palindrome():
    assert is_palindrome('racecars') == False

def test_is_palindrome_numeric_string():
    assert is_palindrome('12321') == True

def test_is_palindrome_numeric_not_palindrome():
    assert is_palindrome('12345') == False

def test_is_palindrome_mixed_case_not_palindrome():
    assert is_palindrome('Aba') == False

def test_is_palindrome_with_spaces_not_palindrome():
    assert is_palindrome('a b a') == True

def test_is_palindrome_special_characters():
    assert is_palindrome('!@#@!') == True

@pytest.mark.parametrize("text,expected", [
    ('', True),
    ('a', True),
    ('aa', True),
    ('ab', False),
    ('aba', True),
    ('abba', True),
    ('aaaaa', True),
    ('zbcd', False),
    ('racecar', True),
    ('hello', False),
    ('noon', True),
    ('12321', True),
    ('123456', False),
    ('madam', True),
    ('python', False)
])
def test_is_palindrome_parametrized(text, expected):
    assert is_palindrome(text) == expected
