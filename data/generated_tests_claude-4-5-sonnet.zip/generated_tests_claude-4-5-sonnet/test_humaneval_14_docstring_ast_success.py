# Test cases for HumanEval/14
# Generated using Claude API

from typing import List


def all_prefixes(string: str) -> List[str]:
    """ Return list of all prefixes from shortest to longest of the input string
    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """

    result = []

    for i in range(len(string)):
        result.append(string[:i+1])
    return result


# Generated test cases:
import pytest
from typing import List


def all_prefixes(string: str) -> List[str]:
    result = []
    for i in range(len(string)):
        result.append(string[:i+1])
    return result


@pytest.mark.parametrize("input_string,expected", [
    ("abc", ["a", "ab", "abc"]),
    ("a", ["a"]),
    ("", []),
    ("hello", ["h", "he", "hel", "hell", "hello"]),
    ("x", ["x"]),
    ("12", ["1", "12"]),
    ("test", ["t", "te", "tes", "test"]),
    ("a b", ["a", "a ", "a b"]),
    ("123456", ["1", "12", "123", "1234", "12345", "123456"]),
    ("  ", [" ", "  "]),
    ("\n", ["\n"]),
    ("\t\n", ["\t", "\t\n"]),
    ("special!@#", ["s", "sp", "spe", "spec", "speci", "specia", "special", "special!", "special!@", "special!@#"]),
])
def test_all_prefixes_parametrized(input_string, expected):
    assert all_prefixes(input_string) == expected


def test_all_prefixes_empty_string():
    assert all_prefixes("") == []


def test_all_prefixes_single_char():
    assert all_prefixes("a") == ["a"]


def test_all_prefixes_multiple_chars():
    assert all_prefixes("abc") == ["a", "ab", "abc"]


def test_all_prefixes_with_spaces():
    assert all_prefixes("a b c") == ["a", "a ", "a b", "a b ", "a b c"]


def test_all_prefixes_with_numbers():
    assert all_prefixes("123") == ["1", "12", "123"]


def test_all_prefixes_with_special_chars():
    assert all_prefixes("!@#") == ["!", "!@", "!@#"]


def test_all_prefixes_unicode():
    assert all_prefixes("αβγ") == ["α", "αβ", "αβγ"]


def test_all_prefixes_return_type():
    result = all_prefixes("test")
    assert isinstance(result, list)
    assert all(isinstance(item, str) for item in result)


def test_all_prefixes_length():
    input_str = "hello"
    result = all_prefixes(input_str)
    assert len(result) == len(input_str)


def test_all_prefixes_order():
    result = all_prefixes("abc")
    for i in range(len(result)):
        assert len(result[i]) == i + 1
