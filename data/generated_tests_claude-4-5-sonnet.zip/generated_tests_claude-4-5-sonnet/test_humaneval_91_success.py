# Test cases for HumanEval/91
# Generated using Claude API


def is_bored(S):
    """
    You'll be given a string of words, and your task is to count the number
    of boredoms. A boredom is a sentence that starts with the word "I".
    Sentences are delimited by '.', '?' or '!'.
   
    For example:
    >>> is_bored("Hello world")
    0
    >>> is_bored("The sky is blue. The sun is shining. I love this weather")
    1
    """

    import re
    sentences = re.split(r'[.?!]\s*', S)
    return sum(sentence[0:2] == 'I ' for sentence in sentences)


# Generated test cases:
import pytest
import re


def is_bored(S):
    sentences = re.split(r'[.?!]\s*', S)
    return sum(sentence[0:2] == 'I ' for sentence in sentences if len(sentence) >= 2)


@pytest.mark.parametrize("input_str,expected", [
    ("", 0),
    ("I am bored.", 1),
    ("I am bored. I am tired.", 2),
    ("I am bored? I am tired!", 2),
    ("I am bored.I am tired.", 2),
    ("I am bored?I am tired!", 2),
    ("I am bored. You are not.", 1),
    ("You are not bored. I am.", 1),
    ("I am bored. You are not. I am tired.", 2),
    ("Hello. How are you?", 0),
    ("Hello. How are you? I am fine.", 1),
    ("I love coding.", 1),
    ("I love coding. I love testing.", 2),
    ("I love coding! I love testing? I love debugging.", 3),
    ("Is this working?", 0),
    ("It is working.", 0),
    ("I.", 0),
    ("I?", 0),
    ("I!", 0),
    ("I", 0),
    ("I ", 1),
    ("I  am bored.", 1),
    ("I\tam bored.", 0),
    ("I\nam bored.", 0),
    (" I am bored.", 0),
    ("  I am bored.", 0),
    ("a. I am bored.", 1),
    ("a.I am bored.", 1),
    ("I am bored. a. I am tired.", 2),
    ("I am bored.a.I am tired.", 2),
    ("I am bored...I am tired.", 2),
    ("I am bored???I am tired.", 2),
    ("I am bored!!!I am tired.", 2),
    ("I am bored.  I am tired.", 2),
    ("I am bored.   I am tired.", 2),
    ("I am bored.\tI am tired.", 2),
    ("I am bored.\nI am tired.", 2),
    ("I. I. I.", 0),
    ("I? I! I.", 0),
    ("Iam bored.", 0),
    ("I.am bored.", 0),
    ("Iambored.", 0),
    ("The sky is blue. I like it.", 1),
    ("The sky is blue. I like it. I really do.", 2),
    ("I think. Therefore I am.", 1),
    ("I think? Therefore I am!", 1),
    (".", 0),
    ("?", 0),
    ("!", 0),
    ("...", 0),
    ("???", 0),
    ("!!!", 0),
    ("I am here. ", 1),
    ("I am here? ", 1),
    ("I am here! ", 1),
    ("I am here.  ", 1),
    ("I  ", 1),
    ("I   ", 1),
])
def test_is_bored_parametrized(input_str, expected):
    assert is_bored(input_str) == expected


def test_is_bored_empty_string():
    assert is_bored("") == 0


def test_is_bored_single_sentence_starting_with_i():
    assert is_bored("I am bored.") == 1


def test_is_bored_single_sentence_not_starting_with_i():
    assert is_bored("You are bored.") == 0


def test_is_bored_multiple_sentences_all_starting_with_i():
    assert is_bored("I am bored. I am tired. I am sleepy.") == 3


def test_is_bored_multiple_sentences_mixed():
    assert is_bored("I am bored. You are not. I am tired.") == 2


def test_is_bored_different_punctuation():
    assert is_bored("I am bored? I am tired! I am sleepy.") == 3


def test_is_bored_no_space_after_punctuation():
    assert is_bored("I am bored.I am tired.") == 2


def test_is_bored_multiple_spaces():
    assert is_bored("I am bored.  I am tired.") == 2


def test_is_bored_only_i():
    assert is_bored("I") == 0


def test_is_bored_i_with_space():
    assert is_bored("I ") == 1


def test_is_bored_i_with_punctuation():
    assert is_bored("I.") == 0


def test_is_bored_leading_space():
    assert is_bored(" I am bored.") == 0


def test_is_bored_it_vs_i():
    assert is_bored("It is working.") == 0


def test_is_bored_no_punctuation():
    assert is_bored("I am bored") == 1


def test_is_bored_only_punctuation():
    assert is_bored("...") == 0