# Test cases for HumanEval/64
# Generated using Claude API


FIX = """
Add more test cases.
"""

def vowels_count(s):
    """Write a function vowels_count which takes a string representing
    a word as input and returns the number of vowels in the string.
    Vowels in this case are 'a', 'e', 'i', 'o', 'u'. Here, 'y' is also a
    vowel, but only when it is at the end of the given word.

    Example:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    """

    vowels = "aeiouAEIOU"
    n_vowels = sum(c in vowels for c in s)
    if s[-1] == 'y' or s[-1] == 'Y':
        n_vowels += 1
    return n_vowels


# Generated test cases:
import pytest

def vowels_count(s):
    vowels = "aeiouAEIOU"
    n_vowels = sum(c in vowels for c in s)
    if s[-1] == 'y' or s[-1] == 'Y':
        n_vowels += 1
    return n_vowels

def test_vowels_count_basic():
    assert vowels_count("hello") == 2

def test_vowels_count_with_y_at_end():
    assert vowels_count("happy") == 2

def test_vowels_count_with_Y_at_end():
    assert vowels_count("happY") == 2

def test_vowels_count_all_vowels():
    assert vowels_count("aeiou") == 5

def test_vowels_count_all_vowels_uppercase():
    assert vowels_count("AEIOU") == 5

def test_vowels_count_mixed_case():
    assert vowels_count("AeIoU") == 5

def test_vowels_count_no_vowels():
    assert vowels_count("bcdfg") == 0

def test_vowels_count_no_vowels_with_y():
    assert vowels_count("bcdfgy") == 1

def test_vowels_count_single_vowel():
    assert vowels_count("a") == 1

def test_vowels_count_single_y():
    assert vowels_count("y") == 1

def test_vowels_count_single_Y():
    assert vowels_count("Y") == 1

def test_vowels_count_single_consonant():
    assert vowels_count("b") == 0

def test_vowels_count_y_in_middle():
    assert vowels_count("python") == 1

def test_vowels_count_y_at_start():
    assert vowels_count("yellow") == 2

def test_vowels_count_multiple_y():
    assert vowels_count("yay") == 2

def test_vowels_count_long_string():
    assert vowels_count("beautiful") == 5

def test_vowels_count_long_string_with_y():
    assert vowels_count("beauty") == 4

def test_vowels_count_all_same_vowel():
    assert vowels_count("aaaa") == 4

def test_vowels_count_consonants_only():
    assert vowels_count("bcdfghjklmnpqrstvwxz") == 0

def test_vowels_count_vowels_and_consonants():
    assert vowels_count("abcde") == 2

def test_vowels_count_uppercase_string():
    assert vowels_count("HELLO") == 2

def test_vowels_count_uppercase_with_Y():
    assert vowels_count("HAPPY") == 2

@pytest.mark.parametrize("input_str,expected", [
    ("abracadabra", 5),
    ("sky", 1),
    ("SKY", 1),
    ("rhythm", 0),
    ("rhythmy", 1),
    ("aaa", 3),
    ("bbb", 0),
    ("bbby", 1),
    ("aeiouAEIOU", 10),
    ("xyz", 0),
    ("xyZ", 0),
    ("xYz", 0),
    ("xYZ", 0),
    ("toy", 2),
    ("TOY", 2),
    ("boy", 2),
    ("BOY", 2),
])
def test_vowels_count_parametrized(input_str, expected):
    assert vowels_count(input_str) == expected
