# Test cases for HumanEval/99
# Generated using Claude API


def closest_integer(value):
    '''
    Create a function that takes a value (string) representing a number
    and returns the closest integer to it. If the number is equidistant
    from two integers, round it away from zero.

    Examples
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15

    Note:
    Rounding away from zero means that if the given number is equidistant
    from two integers, the one you should return is the one that is the
    farthest from zero. For example closest_integer("14.5") should
    return 15 and closest_integer("-14.5") should return -15.
    '''

    from math import floor, ceil

    if value.count('.') == 1:
        # remove trailing zeros
        while (value[-1] == '0'):
            value = value[:-1]

    num = float(value)
    if value[-2:] == '.5':
        if num > 0:
            res = ceil(num)
        else:
            res = floor(num)
    elif len(value) > 0:
        res = int(round(num))
    else:
        res = 0

    return res



# Generated test cases:
import pytest
from math import floor, ceil

def closest_integer(value):

    if value.count('.') == 1:
        # remove trailing zeros
        while (value[-1] == '0'):
            value = value[:-1]

    num = float(value)
    if value[-2:] == '.5':
        if num > 0:
            res = ceil(num)
        else:
            res = floor(num)
    elif len(value) > 0:
        res = int(round(num))
    else:
        res = 0

    return res


@pytest.mark.parametrize("value,expected", [
    ("10", 10),
    ("15.3", 15),
    ("14.5", 15),
    ("-14.5", -15),
    ("0", 0),
    ("0.0", 0),
    ("1", 1),
    ("-1", -1),
    ("1.4", 1),
    ("1.6", 2),
    ("-1.4", -1),
    ("-1.6", -2),
    ("2.5", 3),
    ("-2.5", -3),
    ("3.5", 4),
    ("-3.5", -4),
    ("100.5", 101),
    ("-100.5", -101),
    ("0.5", 1),
    ("-0.5", -1),
    ("10.0", 10),
    ("10.00", 10),
    ("10.000", 10),
    ("15.49", 15),
    ("15.51", 16),
    ("-15.49", -15),
    ("-15.51", -16),
    ("99.9", 100),
    ("-99.9", -100),
    ("0.1", 0),
    ("0.9", 1),
    ("-0.1", 0),
    ("-0.9", -1),
    ("1.5", 2),
    ("-1.5", -2),
    ("123.456", 123),
    ("-123.456", -123),
    ("1000", 1000),
    ("-1000", -1000),
    ("1000.5", 1001),
    ("-1000.5", -1001),
])
def test_closest_integer(value, expected):
    assert closest_integer(value) == expected


def test_closest_integer_positive_half():
    assert closest_integer("0.5") == 1
    assert closest_integer("1.5") == 2
    assert closest_integer("2.5") == 3


def test_closest_integer_negative_half():
    assert closest_integer("-0.5") == -1
    assert closest_integer("-1.5") == -2
    assert closest_integer("-2.5") == -3


def test_closest_integer_whole_numbers():
    assert closest_integer("5") == 5
    assert closest_integer("-5") == -5
    assert closest_integer("0") == 0


def test_closest_integer_trailing_zeros():
    assert closest_integer("10.50") == 11
    assert closest_integer("-10.50") == -11
    assert closest_integer("10.500") == 11
    assert closest_integer("-10.500") == -11


def test_closest_integer_near_half():
    assert closest_integer("10.49") == 10
    assert closest_integer("10.51") == 11
    assert closest_integer("-10.49") == -10
    assert closest_integer("-10.51") == -11


def test_closest_integer_large_numbers():
    assert closest_integer("999999.5") == 1000000
    assert closest_integer("-999999.5") == -1000000
