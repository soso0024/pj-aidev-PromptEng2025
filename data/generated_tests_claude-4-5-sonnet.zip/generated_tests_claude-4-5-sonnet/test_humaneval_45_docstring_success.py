# Test cases for HumanEval/45
# Generated using Claude API



def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """

    return a * h / 2.0


# Generated test cases:
import pytest

def triangle_area(a, h):
    return a * h / 2.0

def test_triangle_area_basic():
    assert triangle_area(5, 3) == 7.5

def test_triangle_area_integers():
    assert triangle_area(10, 4) == 20.0

def test_triangle_area_floats():
    assert triangle_area(5.5, 4.0) == 11.0

def test_triangle_area_zero_base():
    assert triangle_area(0, 5) == 0.0

def test_triangle_area_zero_height():
    assert triangle_area(5, 0) == 0.0

def test_triangle_area_both_zero():
    assert triangle_area(0, 0) == 0.0

def test_triangle_area_one_base():
    assert triangle_area(1, 1) == 0.5

def test_triangle_area_large_numbers():
    assert triangle_area(1000, 2000) == 1000000.0

def test_triangle_area_small_decimals():
    assert triangle_area(0.1, 0.2) == pytest.approx(0.01)

def test_triangle_area_negative_base():
    assert triangle_area(-5, 3) == -7.5

def test_triangle_area_negative_height():
    assert triangle_area(5, -3) == -7.5

def test_triangle_area_both_negative():
    assert triangle_area(-5, -3) == 7.5

@pytest.mark.parametrize("a,h,expected", [
    (5, 3, 7.5),
    (10, 4, 20.0),
    (0, 5, 0.0),
    (5, 0, 0.0),
    (1, 1, 0.5),
    (2, 6, 6.0),
    (7, 2, 7.0),
    (100, 50, 2500.0),
    (0.5, 0.4, 0.1),
])
def test_triangle_area_parametrized(a, h, expected):
    assert triangle_area(a, h) == pytest.approx(expected)

def test_triangle_area_returns_float():
    result = triangle_area(5, 3)
    assert isinstance(result, float)

def test_triangle_area_precision():
    result = triangle_area(3, 7)
    assert result == 10.5
