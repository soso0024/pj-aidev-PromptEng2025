# Test cases for HumanEval/117
# Generated using Claude API


def select_words(s, n):
    """Given a string s and a natural number n, you have been tasked to implement 
    a function that returns a list of all words from string s that contain exactly 
    n consonants, in order these words appear in the string s.
    If the string s is empty then the function should return an empty list.
    Note: you may assume the input string contains only letters and spaces.
    Examples:
    select_words("Mary had a little lamb", 4) ==> ["little"]
    select_words("Mary had a little lamb", 3) ==> ["Mary", "lamb"]
    select_words("simple white space", 2) ==> []
    select_words("Hello world", 4) ==> ["world"]
    select_words("Uncle sam", 3) ==> ["Uncle"]
    """

    result = []
    for word in s.split():
        n_consonants = 0
        for i in range(0, len(word)):
            if word[i].lower() not in ["a","e","i","o","u"]:
                n_consonants += 1 
        if n_consonants == n:
            result.append(word)
    return result



# Generated test cases:
import pytest

def select_words(s, n):
    result = []
    for word in s.split():
        n_consonants = 0
        for i in range(0, len(word)):
            if word[i].lower() not in ["a","e","i","o","u"]:
                n_consonants += 1 
        if n_consonants == n:
            result.append(word)
    return result

@pytest.mark.parametrize("s,n,expected", [
    ("Mary had a little lamb", 4, ["little"]),
    ("Mary had a little lamb", 3, ["Mary", "lamb"]),
    ("simple white space", 2, []),
    ("Hello world", 4, ["world"]),
    ("Uncle sam", 3, ["Uncle"]),
    ("", 0, []),
    ("", 5, []),
    ("a", 0, ["a"]),
    ("a", 1, []),
    ("b", 1, ["b"]),
    ("b", 0, []),
    ("aeiou", 0, ["aeiou"]),
    ("bcdfg", 5, ["bcdfg"]),
    ("AEIOU", 0, ["AEIOU"]),
    ("BCDFG", 5, ["BCDFG"]),
    ("aEiOu", 0, ["aEiOu"]),
    ("BcDfG", 5, ["BcDfG"]),
    ("a e i o u", 0, ["a", "e", "i", "o", "u"]),
    ("b c d f g", 1, ["b", "c", "d", "f", "g"]),
    ("ab cd ef", 1, ["ab", "ef"]),
    ("abc def ghi", 2, ["abc", "def", "ghi"]),
    ("test", 3, ["test"]),
    ("test", 2, []),
    ("programming", 8, ["programming"]),
    ("programming", 7, []),
    ("one two three", 1, ["one"]),
    ("one two three", 2, ["two"]),
    ("one two three", 3, ["three"]),
    ("AAA BBB CCC", 3, ["BBB", "CCC"]),
    ("aaa bbb ccc", 3, ["bbb", "ccc"]),
    ("The quick brown fox", 3, ["quick"]),
    ("The quick brown fox", 2, ["The", "fox"]),
    ("a b c d e f g h i j k l m n o p q r s t u v w x y z", 1, ["b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "n", "p", "q", "r", "s", "t", "v", "w", "x", "y", "z"]),
    ("Python", 5, ["Python"]),
    ("Python", 4, []),
    ("rhythm", 6, ["rhythm"]),
    ("sky", 3, ["sky"]),
    ("fly", 3, ["fly"]),
    ("by", 2, ["by"]),
    ("my", 2, ["my"]),
    ("gym", 3, ["gym"]),
    ("   ", 0, []),
    ("word", 3, ["word"]),
    ("word", 4, []),
    ("aaa", 0, ["aaa"]),
    ("zzz", 3, ["zzz"]),
    ("AaAa", 0, ["AaAa"]),
    ("BbBb", 2, []),
])
def test_select_words(s, n, expected):
    assert select_words(s, n) == expected

def test_empty_string():
    assert select_words("", 0) == []
    assert select_words("", 1) == []
    assert select_words("", 100) == []

def test_single_word():
    assert select_words("hello", 3) == ["hello"]
    assert select_words("hello", 2) == []

def test_all_vowels():
    assert select_words("aeiou AEIOU", 0) == ["aeiou", "AEIOU"]

def test_all_consonants():
    assert select_words("bcdfg BCDFG", 5) == ["bcdfg", "BCDFG"]

def test_mixed_case():
    assert select_words("HeLLo WoRLd", 3) == ["HeLLo"]
    assert select_words("HeLLo WoRLd", 4) == ["WoRLd"]

def test_zero_consonants():
    assert select_words("I a", 0) == ["I", "a"]
    assert select_words("bee see", 0) == []

def test_large_n():
    assert select_words("hello world", 100) == []