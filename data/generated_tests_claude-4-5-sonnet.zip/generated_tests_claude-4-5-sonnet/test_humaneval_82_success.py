# Test cases for HumanEval/82
# Generated using Claude API


def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise
    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """

    l = len(string)
    if l == 0 or l == 1:
        return False
    for i in range(2, l):
        if l % i == 0:
            return False
    return True


# Generated test cases:
import pytest

def prime_length(string):
    l = len(string)
    if l == 0 or l == 1:
        return False
    for i in range(2, l):
        if l % i == 0:
            return False
    return True


@pytest.mark.parametrize("string,expected", [
    ("", False),
    ("a", False),
    ("ab", True),
    ("abc", True),
    ("abcd", False),
    ("abcde", True),
    ("abcdef", False),
    ("abcdefg", True),
    ("abcdefgh", False),
    ("abcdefghi", False),
    ("abcdefghij", False),
    ("abcdefghijk", True),
    ("abcdefghijkl", False),
    ("abcdefghijklm", True),
    ("abcdefghijklmn", False),
    ("abcdefghijklmno", False),
    ("abcdefghijklmnop", False),
    ("abcdefghijklmnopq", True),
    ("abcdefghijklmnopqr", False),
    ("abcdefghijklmnopqrs", True),
    ("abcdefghijklmnopqrst", False),
    ("abcdefghijklmnopqrstu", False),
    ("abcdefghijklmnopqrstuv", False),
    ("abcdefghijklmnopqrstuvw", True),
    ("abcdefghijklmnopqrstuvwx", False),
    ("abcdefghijklmnopqrstuvwxy", False),
    ("abcdefghijklmnopqrstuvwxyz", False),
    ("abcdefghijklmnopqrstuvwxyz1234567", False),
    ("  ", True),
    ("   ", True),
    ("    ", False),
    ("     ", True),
    ("      ", False),
    ("123", True),
    ("1234", False),
    ("12345", True),
    ("!@#$%", True),
    ("!@#$", False),
])
def test_prime_length_parametrized(string, expected):
    assert prime_length(string) == expected


def test_prime_length_empty_string():
    assert prime_length("") == False


def test_prime_length_single_char():
    assert prime_length("x") == False


def test_prime_length_two_chars():
    assert prime_length("xy") == True


def test_prime_length_three_chars():
    assert prime_length("xyz") == True


def test_prime_length_four_chars():
    assert prime_length("wxyz") == False


def test_prime_length_five_chars():
    assert prime_length("vwxyz") == True


def test_prime_length_six_chars():
    assert prime_length("uvwxyz") == False


def test_prime_length_seven_chars():
    assert prime_length("tuvwxyz") == True


def test_prime_length_eight_chars():
    assert prime_length("stuvwxyz") == False


def test_prime_length_nine_chars():
    assert prime_length("rstuvwxyz") == False


def test_prime_length_ten_chars():
    assert prime_length("qrstuvwxyz") == False


def test_prime_length_eleven_chars():
    assert prime_length("pqrstuvwxyz") == True


def test_prime_length_special_chars():
    assert prime_length("!@") == True
    assert prime_length("!@#") == True
    assert prime_length("!@#$") == False


def test_prime_length_numbers():
    assert prime_length("12") == True
    assert prime_length("123") == True
    assert prime_length("1234") == False


def test_prime_length_mixed():
    assert prime_length("a1") == True
    assert prime_length("a1b") == True
    assert prime_length("a1b2") == False


def test_prime_length_spaces():
    assert prime_length(" ") == False
    assert prime_length("  ") == True
    assert prime_length("   ") == True
    assert prime_length("    ") == False


def test_prime_length_unicode():
    assert prime_length("αβ") == True
    assert prime_length("αβγ") == True
    assert prime_length("αβγδ") == False