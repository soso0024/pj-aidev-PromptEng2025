# Test cases for HumanEval/96
# Generated using Claude API


def count_up_to(n):
    """Implement a function that takes an non-negative integer and returns an array of the first n
    integers that are prime numbers and less than n.
    for example:
    count_up_to(5) => [2,3]
    count_up_to(11) => [2,3,5,7]
    count_up_to(0) => []
    count_up_to(20) => [2,3,5,7,11,13,17,19]
    count_up_to(1) => []
    count_up_to(18) => [2,3,5,7,11,13,17]
    """

    primes = []
    for i in range(2, n):
        is_prime = True
        for j in range(2, i):
            if i % j == 0:
                is_prime = False
                break
        if is_prime:
            primes.append(i)
    return primes



# Generated test cases:
import pytest

def count_up_to(n):
    primes = []
    for i in range(2, n):
        is_prime = True
        for j in range(2, i):
            if i % j == 0:
                is_prime = False
                break
        if is_prime:
            primes.append(i)
    return primes


@pytest.mark.parametrize("n,expected", [
    (5, [2, 3]),
    (11, [2, 3, 5, 7]),
    (0, []),
    (20, [2, 3, 5, 7, 11, 13, 17, 19]),
    (1, []),
    (18, [2, 3, 5, 7, 11, 13, 17]),
])
def test_count_up_to_examples(n, expected):
    assert count_up_to(n) == expected


def test_count_up_to_zero():
    assert count_up_to(0) == []


def test_count_up_to_one():
    assert count_up_to(1) == []


def test_count_up_to_two():
    assert count_up_to(2) == []


def test_count_up_to_three():
    assert count_up_to(3) == [2]


def test_count_up_to_four():
    assert count_up_to(4) == [2, 3]


def test_count_up_to_small_primes():
    assert count_up_to(10) == [2, 3, 5, 7]


def test_count_up_to_larger_number():
    assert count_up_to(30) == [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]


def test_count_up_to_50():
    expected = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]
    assert count_up_to(50) == expected


def test_count_up_to_returns_list():
    result = count_up_to(10)
    assert isinstance(result, list)


def test_count_up_to_all_elements_are_prime():
    result = count_up_to(30)
    for num in result:
        assert is_prime_helper(num)


def test_count_up_to_all_elements_less_than_n():
    n = 25
    result = count_up_to(n)
    for num in result:
        assert num < n


def test_count_up_to_ordered():
    result = count_up_to(30)
    assert result == sorted(result)


def is_prime_helper(n):
    if n < 2:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True


def test_count_up_to_100():
    result = count_up_to(100)
    assert len(result) == 25
    assert result[0] == 2
    assert result[-1] == 97
