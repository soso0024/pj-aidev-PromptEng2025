# Test cases for HumanEval/38
# Generated using Claude API



def encode_cyclic(s: str):
    """
    returns encoded string by cycling groups of three characters.
    """
    # split string to groups. Each of length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # cycle elements in each group. Unless group has fewer elements than 3.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def decode_cyclic(s: str):
    """
    takes as input string encoded with encode_cyclic function. Returns decoded string.
    """

    return encode_cyclic(encode_cyclic(s))


# Generated test cases:
import pytest


def encode_cyclic(s: str):
    """
    returns encoded string by cycling groups of three characters.
    """
    # split string to groups. Each of length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # cycle elements in each group. Unless group has fewer elements than 3.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def decode_cyclic(s: str):
    """
    takes as input string encoded with encode_cyclic function. Returns decoded string.
    """
    return encode_cyclic(encode_cyclic(s))


class TestEncodeCyclic:
    def test_encode_empty_string(self):
        assert encode_cyclic("") == ""

    def test_encode_single_character(self):
        assert encode_cyclic("a") == "a"

    def test_encode_two_characters(self):
        assert encode_cyclic("ab") == "ab"

    def test_encode_three_characters(self):
        assert encode_cyclic("abc") == "bca"

    def test_encode_four_characters(self):
        assert encode_cyclic("abcd") == "bcad"

    def test_encode_five_characters(self):
        assert encode_cyclic("abcde") == "bcade"

    def test_encode_six_characters(self):
        assert encode_cyclic("abcdef") == "bcaefd"

    def test_encode_nine_characters(self):
        assert encode_cyclic("abcdefghi") == "bcaefdhig"

    def test_encode_with_numbers(self):
        assert encode_cyclic("123456") == "231564"

    def test_encode_with_special_characters(self):
        assert encode_cyclic("!@#$%^") == "@#!%^$"

    def test_encode_with_spaces(self):
        assert encode_cyclic("a b c") == " ba c"

    def test_encode_with_mixed_content(self):
        assert encode_cyclic("abc123") == "bca231"


class TestDecodeCyclic:
    def test_decode_empty_string(self):
        assert decode_cyclic("") == ""

    def test_decode_single_character(self):
        assert decode_cyclic("a") == "a"

    def test_decode_two_characters(self):
        assert decode_cyclic("ab") == "ab"

    def test_decode_three_characters(self):
        encoded = encode_cyclic("abc")
        assert decode_cyclic(encoded) == "abc"

    def test_decode_four_characters(self):
        encoded = encode_cyclic("abcd")
        assert decode_cyclic(encoded) == "abcd"

    def test_decode_five_characters(self):
        encoded = encode_cyclic("abcde")
        assert decode_cyclic(encoded) == "abcde"

    def test_decode_six_characters(self):
        encoded = encode_cyclic("abcdef")
        assert decode_cyclic(encoded) == "abcdef"

    def test_decode_nine_characters(self):
        encoded = encode_cyclic("abcdefghi")
        assert decode_cyclic(encoded) == "abcdefghi"

    def test_decode_with_numbers(self):
        original = "123456"
        encoded = encode_cyclic(original)
        assert decode_cyclic(encoded) == original

    def test_decode_with_special_characters(self):
        original = "!@#$%^"
        encoded = encode_cyclic(original)
        assert decode_cyclic(encoded) == original

    def test_decode_with_spaces(self):
        original = "a b c"
        encoded = encode_cyclic(original)
        assert decode_cyclic(encoded) == original

    def test_decode_with_mixed_content(self):
        original = "abc123"
        encoded = encode_cyclic(original)
        assert decode_cyclic(encoded) == original

    def test_decode_long_string(self):
        original = "abcdefghijklmnopqrstuvwxyz"
        encoded = encode_cyclic(original)
        assert decode_cyclic(encoded) == original

    def test_decode_repeated_characters(self):
        original = "aaaaaa"
        encoded = encode_cyclic(original)
        assert decode_cyclic(encoded) == original

    def test_decode_unicode_characters(self):
        original = "café"
        encoded = encode_cyclic(original)
        assert decode_cyclic(encoded) == original


class TestRoundTrip:
    @pytest.mark.parametrize("original", [
        "",
        "a",
        "ab",
        "abc",
        "abcd",
        "abcde",
        "abcdef",
        "abcdefghi",
        "The quick brown fox",
        "123!@#",
        "   ",
        "a" * 100,
    ])
    def test_encode_decode_roundtrip(self, original):
        encoded = encode_cyclic(original)
        decoded = decode_cyclic(encoded)
        assert decoded == original

    def test_double_encode_decode(self):
        original = "hello"
        double_encoded = encode_cyclic(encode_cyclic(original))
        assert decode_cyclic(double_encoded) == encode_cyclic(original)

    def test_triple_encode_decode(self):
        original = "world"
        triple_encoded = encode_cyclic(encode_cyclic(encode_cyclic(original)))
        decoded = decode_cyclic(triple_encoded)
        assert decoded == encode_cyclic(encode_cyclic(original))