# Test cases for HumanEval/13
# Generated using Claude API



def greatest_common_divisor(a: int, b: int) -> int:
    """ Return a greatest common divisor of two integers a and b
    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """

    while b:
        a, b = b, a % b
    return a


# Generated test cases:
import pytest


def greatest_common_divisor(a: int, b: int) -> int:
    """ Return a greatest common divisor of two integers a and b
    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """
    while b:
        a, b = b, a % b
    return a


class TestGreatestCommonDivisor:
    
    @pytest.mark.parametrize("a,b,expected", [
        (3, 5, 1),
        (25, 15, 5),
        (12, 8, 4),
        (48, 18, 6),
        (100, 50, 50),
        (17, 19, 1),
        (0, 5, 5),
        (5, 0, 5),
        (0, 0, 0),
        (1, 1, 1),
        (1, 100, 1),
        (100, 1, 1),
        (21, 14, 7),
        (1071, 462, 21),
        (2, 4, 2),
        (4, 2, 2),
    ])
    def test_gcd_various_cases(self, a, b, expected):
        assert greatest_common_divisor(a, b) == expected
    
    def test_gcd_same_numbers(self):
        assert greatest_common_divisor(5, 5) == 5
        assert greatest_common_divisor(100, 100) == 100
    
    def test_gcd_coprime_numbers(self):
        assert greatest_common_divisor(7, 11) == 1
        assert greatest_common_divisor(13, 17) == 1
    
    def test_gcd_one_divides_other(self):
        assert greatest_common_divisor(10, 5) == 5
        assert greatest_common_divisor(5, 10) == 5
        assert greatest_common_divisor(20, 4) == 4
    
    def test_gcd_with_one(self):
        assert greatest_common_divisor(1, 5) == 1
        assert greatest_common_divisor(5, 1) == 1
        assert greatest_common_divisor(1, 1) == 1
    
    def test_gcd_with_zero(self):
        assert greatest_common_divisor(0, 10) == 10
        assert greatest_common_divisor(10, 0) == 10
    
    def test_gcd_large_numbers(self):
        assert greatest_common_divisor(1000000, 500000) == 500000
        assert greatest_common_divisor(123456, 789012) == 12
    
    def test_gcd_negative_numbers(self):
        assert greatest_common_divisor(-12, 8) == -4
        assert greatest_common_divisor(12, -8) == -4
        assert greatest_common_divisor(-12, -8) == -4
    
    def test_gcd_docstring_examples(self):
        assert greatest_common_divisor(3, 5) == 1
        assert greatest_common_divisor(25, 15) == 5