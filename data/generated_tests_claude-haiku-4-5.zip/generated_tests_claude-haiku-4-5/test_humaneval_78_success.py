# Test cases for HumanEval/78
# Generated using Claude API


def hex_key(num):
    """You have been tasked to write a function that receives 
    a hexadecimal number as a string and counts the number of hexadecimal 
    digits that are primes (prime number, or a prime, is a natural number 
    greater than 1 that is not a product of two smaller natural numbers).
    Hexadecimal digits are 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, A, B, C, D, E, F.
    Prime numbers are 2, 3, 5, 7, 11, 13, 17,...
    So you have to determine a number of the following digits: 2, 3, 5, 7, 
    B (=decimal 11), D (=decimal 13).
    Note: you may assume the input is always correct or empty string, 
    and symbols A,B,C,D,E,F are always uppercase.
    Examples:
    For num = "AB" the output should be 1.
    For num = "1077E" the output should be 2.
    For num = "ABED1A33" the output should be 4.
    For num = "123456789ABCDEF0" the output should be 6.
    For num = "2020" the output should be 2.
    """

    primes = ('2', '3', '5', '7', 'B', 'D')
    total = 0
    for i in range(0, len(num)):
        if num[i] in primes:
            total += 1
    return total


# Generated test cases:
import pytest


def hex_key(num):
    primes = ('2', '3', '5', '7', 'B', 'D')
    total = 0
    for i in range(0, len(num)):
        if num[i] in primes:
            total += 1
    return total


class TestHexKey:
    
    @pytest.mark.parametrize("input_val,expected", [
        ("", 0),
        ("1", 0),
        ("2", 1),
        ("3", 1),
        ("5", 1),
        ("7", 1),
        ("B", 1),
        ("D", 1),
        ("A", 0),
        ("C", 0),
        ("E", 0),
        ("F", 0),
        ("0", 0),
        ("4", 0),
        ("6", 0),
        ("8", 0),
        ("9", 0),
    ])
    def test_single_characters(self, input_val, expected):
        assert hex_key(input_val) == expected
    
    @pytest.mark.parametrize("input_val,expected", [
        ("2357BD", 6),
        ("2357", 4),
        ("BD", 2),
        ("ABCDEF", 2),
        ("123456789ABCDEF", 6),
        ("2D2D2D", 6),
        ("3B5D7", 5),
    ])
    def test_multiple_prime_hex_digits(self, input_val, expected):
        assert hex_key(input_val) == expected
    
    @pytest.mark.parametrize("input_val,expected", [
        ("ACE", 0),
        ("FFF", 0),
        ("111", 0),
        ("468", 0),
        ("9AC", 0),
    ])
    def test_no_prime_hex_digits(self, input_val, expected):
        assert hex_key(input_val) == expected
    
    @pytest.mark.parametrize("input_val,expected", [
        ("2A3B5C7D", 6),
        ("1F2E3D4C5B6A7", 6),
        ("ABCDEF2357BD", 8),
        ("2X3Y5Z7", 4),
    ])
    def test_mixed_prime_and_non_prime(self, input_val, expected):
        assert hex_key(input_val) == expected
    
    def test_empty_string(self):
        assert hex_key("") == 0
    
    def test_all_primes(self):
        assert hex_key("2357BD") == 6
    
    def test_long_string_with_primes(self):
        assert hex_key("2357BD2357BD2357BD") == 18
    
    def test_long_string_without_primes(self):
        assert hex_key("ACEFACEFACEF") == 0
    
    def test_case_sensitivity_uppercase(self):
        assert hex_key("B") == 1
        assert hex_key("D") == 1
    
    def test_lowercase_letters_not_counted(self):
        assert hex_key("b") == 0
        assert hex_key("d") == 0
        assert hex_key("2b3d5") == 3
    
    def test_mixed_case(self):
        assert hex_key("2B3D5b7d") == 6
    
    def test_single_prime_at_start(self):
        assert hex_key("2ACEF") == 1
    
    def test_single_prime_at_end(self):
        assert hex_key("ACEF2") == 1
    
    def test_single_prime_in_middle(self):
        assert hex_key("AC2EF") == 1
    
    def test_alternating_prime_non_prime(self):
        assert hex_key("2A3C5E7F") == 4
    
    def test_consecutive_primes(self):
        assert hex_key("2357BD") == 6
    
    def test_consecutive_non_primes(self):
        assert hex_key("ACEF") == 0
    
    def test_numeric_non_primes(self):
        assert hex_key("0146890") == 0
    
    def test_numeric_primes(self):
        assert hex_key("235723572357") == 12
    
    def test_very_long_string(self):
        long_string = "2357BD" * 100
        assert hex_key(long_string) == 600
    
    def test_single_character_prime_2(self):
        assert hex_key("2") == 1
    
    def test_single_character_prime_3(self):
        assert hex_key("3") == 1
    
    def test_single_character_prime_5(self):
        assert hex_key("5") == 1
    
    def test_single_character_prime_7(self):
        assert hex_key("7") == 1
    
    def test_single_character_prime_B(self):
        assert hex_key("B") == 1
    
    def test_single_character_prime_D(self):
        assert hex_key("D") == 1