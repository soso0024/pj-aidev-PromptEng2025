# Test cases for HumanEval/159
# Generated using Claude API


def eat(number, need, remaining):
    """
    You're a hungry rabbit, and you already have eaten a certain number of carrots,
    but now you need to eat more carrots to complete the day's meals.
    you should return an array of [ total number of eaten carrots after your meals,
                                    the number of carrots left after your meals ]
    if there are not enough remaining carrots, you will eat all remaining carrots, but will still be hungry.
    
    Example:
    * eat(5, 6, 10) -> [11, 4]
    * eat(4, 8, 9) -> [12, 1]
    * eat(1, 10, 10) -> [11, 0]
    * eat(2, 11, 5) -> [7, 0]
    
    Variables:
    @number : integer
        the number of carrots that you have eaten.
    @need : integer
        the number of carrots that you need to eat.
    @remaining : integer
        the number of remaining carrots thet exist in stock
    
    Constrain:
    * 0 <= number <= 1000
    * 0 <= need <= 1000
    * 0 <= remaining <= 1000

    Have fun :)
    """

    if(need <= remaining):
        return [ number + need , remaining-need ]
    else:
        return [ number + remaining , 0]


# Generated test cases:
import pytest


class TestEat:
    
    @pytest.mark.parametrize("number,need,remaining,expected", [
        (5, 6, 10, [11, 4]),
        (4, 8, 9, [12, 1]),
        (1, 10, 10, [11, 0]),
        (2, 11, 5, [7, 0]),
    ])
    def test_examples_from_docstring(self, number, need, remaining, expected):
        from test_humaneval_159_docstring_ast import eat
        assert eat(number, need, remaining) == expected
    
    @pytest.mark.parametrize("number,need,remaining,expected", [
        (0, 0, 0, [0, 0]),
        (0, 0, 5, [0, 5]),
        (0, 5, 0, [0, 0]),
        (5, 0, 0, [5, 0]),
    ])
    def test_zero_values(self, number, need, remaining, expected):
        assert eat(number, need, remaining) == expected
    
    @pytest.mark.parametrize("number,need,remaining,expected", [
        (0, 5, 5, [5, 0]),
        (10, 5, 5, [15, 0]),
        (100, 50, 50, [150, 0]),
    ])
    def test_need_equals_remaining(self, number, need, remaining, expected):
        assert eat(number, need, remaining) == expected
    
    @pytest.mark.parametrize("number,need,remaining,expected", [
        (0, 10, 5, [5, 0]),
        (5, 20, 10, [15, 0]),
        (100, 500, 200, [300, 0]),
    ])
    def test_need_greater_than_remaining(self, number, need, remaining, expected):
        assert eat(number, need, remaining) == expected
    
    @pytest.mark.parametrize("number,need,remaining,expected", [
        (0, 5, 10, [5, 5]),
        (10, 5, 20, [15, 15]),
        (50, 30, 100, [80, 70]),
    ])
    def test_need_less_than_remaining(self, number, need, remaining, expected):
        assert eat(number, need, remaining) == expected
    
    @pytest.mark.parametrize("number,need,remaining,expected", [
        (1000, 0, 0, [1000, 0]),
        (1000, 1000, 1000, [2000, 0]),
        (500, 500, 500, [1000, 0]),
    ])
    def test_maximum_constraint_values(self, number, need, remaining, expected):
        assert eat(number, need, remaining) == expected
    
    @pytest.mark.parametrize("number,need,remaining,expected", [
        (1, 1, 1, [2, 0]),
        (1, 1, 2, [2, 1]),
        (1, 2, 1, [2, 0]),
    ])
    def test_small_values(self, number, need, remaining, expected):
        assert eat(number, need, remaining) == expected
    
    @pytest.mark.parametrize("number,need,remaining,expected", [
        (999, 1, 1, [1000, 0]),
        (500, 250, 250, [750, 0]),
        (750, 100, 200, [850, 100]),
    ])
    def test_large_values(self, number, need, remaining, expected):
        assert eat(number, need, remaining) == expected
    
    def test_return_type_is_list(self):
        result = eat(5, 6, 10)
        assert isinstance(result, list)
        assert len(result) == 2
    
    def test_return_values_are_integers(self):
        result = eat(5, 6, 10)
        assert isinstance(result[0], int)
        assert isinstance(result[1], int)
    
    @pytest.mark.parametrize("number,need,remaining", [
        (0, 0, 0),
        (1000, 1000, 1000),
        (500, 500, 500),
        (100, 200, 50),
        (50, 100, 200),
    ])
    def test_total_eaten_plus_remaining_consistency(self, number, need, remaining):
        total_eaten, remaining_after = eat(number, need, remaining)
        assert total_eaten >= number
        assert remaining_after >= 0
        assert remaining_after <= remaining