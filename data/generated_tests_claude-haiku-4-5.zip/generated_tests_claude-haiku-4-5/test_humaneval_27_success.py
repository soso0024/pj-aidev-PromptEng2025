# Test cases for HumanEval/27
# Generated using Claude API



def flip_case(string: str) -> str:
    """ For a given string, flip lowercase characters to uppercase and uppercase to lowercase.
    >>> flip_case('Hello')
    'hELLO'
    """

    return string.swapcase()


# Generated test cases:
import pytest


class TestFlipCase:
    def flip_case(self, string: str) -> str:
        return string.swapcase()

    def test_empty_string(self):
        assert self.flip_case("") == ""

    def test_all_lowercase(self):
        assert self.flip_case("hello") == "HELLO"

    def test_all_uppercase(self):
        assert self.flip_case("HELLO") == "hello"

    def test_mixed_case(self):
        assert self.flip_case("HeLLo") == "hEllO"

    def test_single_lowercase_letter(self):
        assert self.flip_case("a") == "A"

    def test_single_uppercase_letter(self):
        assert self.flip_case("A") == "a"

    def test_with_numbers(self):
        assert self.flip_case("Hello123") == "hELLO123"

    def test_with_special_characters(self):
        assert self.flip_case("Hello!@#$") == "hELLO!@#$"

    def test_with_spaces(self):
        assert self.flip_case("Hello World") == "hELLO wORLD"

    def test_with_tabs_and_newlines(self):
        assert self.flip_case("Hello\tWorld\n") == "hELLO\twORLD\n"

    def test_with_mixed_content(self):
        assert self.flip_case("PyThOn 3.9!") == "pYtHoN 3.9!"

    def test_only_numbers(self):
        assert self.flip_case("12345") == "12345"

    def test_only_special_characters(self):
        assert self.flip_case("!@#$%^&*()") == "!@#$%^&*()"

    def test_only_spaces(self):
        assert self.flip_case("     ") == "     "

    def test_unicode_lowercase(self):
        assert self.flip_case("café") == "CAFÉ"

    def test_unicode_uppercase(self):
        assert self.flip_case("CAFÉ") == "café"

    def test_long_string(self):
        long_string = "aBcDeFgHiJkLmNoPqRsTuVwXyZ" * 100
        expected = "AbCdEfGhIjKlMnOpQrStUvWxYz" * 100
        assert self.flip_case(long_string) == expected

    @pytest.mark.parametrize("input_str,expected", [
        ("abc", "ABC"),
        ("ABC", "abc"),
        ("aBc", "AbC"),
        ("123", "123"),
        ("!@#", "!@#"),
        ("a1B2c3", "A1b2C3"),
        ("", ""),
        (" ", " "),
        ("a b c", "A B C"),
    ])
    def test_parametrized_cases(self, input_str, expected):
        assert self.flip_case(input_str) == expected

    def test_return_type_is_string(self):
        result = self.flip_case("test")
        assert isinstance(result, str)

    def test_original_string_unchanged(self):
        original = "TestString"
        self.flip_case(original)
        assert original == "TestString"

    def test_consecutive_calls(self):
        original = "TestString"
        first_flip = self.flip_case(original)
        second_flip = self.flip_case(first_flip)
        assert second_flip == original

    def test_with_punctuation(self):
        assert self.flip_case("Hello, World!") == "hELLO, wORLD!"

    def test_with_quotes(self):
        assert self.flip_case('He said "Hello"') == 'hE SAID "hELLO"'

    def test_with_parentheses(self):
        assert self.flip_case("(Hello)") == "(hELLO)"

    def test_with_brackets(self):
        assert self.flip_case("[Hello]") == "[hELLO]"

    def test_with_braces(self):
        assert self.flip_case("{Hello}") == "{hELLO}"