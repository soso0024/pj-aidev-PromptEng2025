# Test cases for HumanEval/2
# Generated using Claude API



def truncate_number(number: float) -> float:
    """ Given a positive floating point number, it can be decomposed into
    and integer part (largest integer smaller than given number) and decimals
    (leftover part always smaller than 1).

    Return the decimal part of the number.
    >>> truncate_number(3.5)
    0.5
    """

    return number % 1.0


# Generated test cases:
import pytest


def truncate_number(number: float) -> float:
    return number % 1.0


class TestTruncateNumber:
    
    def test_positive_integer(self):
        assert truncate_number(5.0) == 0.0
    
    def test_positive_decimal(self):
        assert truncate_number(5.7) == pytest.approx(0.7)
    
    def test_positive_small_decimal(self):
        assert truncate_number(0.5) == pytest.approx(0.5)
    
    def test_positive_very_small_decimal(self):
        assert truncate_number(0.001) == pytest.approx(0.001)
    
    def test_negative_integer(self):
        result = truncate_number(-5.0)
        assert result == pytest.approx(0.0)
    
    def test_negative_decimal(self):
        result = truncate_number(-5.7)
        assert result == pytest.approx(0.3, abs=1e-6)
    
    def test_negative_small_decimal(self):
        result = truncate_number(-0.5)
        assert result == pytest.approx(0.5)
    
    def test_zero(self):
        assert truncate_number(0.0) == 0.0
    
    def test_one(self):
        assert truncate_number(1.0) == 0.0
    
    def test_just_below_one(self):
        assert truncate_number(0.9999) == pytest.approx(0.9999)
    
    def test_just_above_one(self):
        assert truncate_number(1.0001) == pytest.approx(0.0001)
    
    def test_large_positive_number(self):
        assert truncate_number(1000.5) == pytest.approx(0.5)
    
    def test_large_negative_number(self):
        result = truncate_number(-1000.5)
        assert result == pytest.approx(0.5)
    
    def test_very_small_positive(self):
        assert truncate_number(0.0001) == pytest.approx(0.0001)
    
    def test_very_small_negative(self):
        result = truncate_number(-0.0001)
        assert result == pytest.approx(0.9999)
    
    @pytest.mark.parametrize("number,expected", [
        (3.14, pytest.approx(0.14)),
        (2.71, pytest.approx(0.71)),
        (10.99, pytest.approx(0.99)),
        (0.25, pytest.approx(0.25)),
        (100.001, pytest.approx(0.001)),
    ])
    def test_various_positive_decimals(self, number, expected):
        assert truncate_number(number) == expected
    
    @pytest.mark.parametrize("number,expected", [
        (-3.14, pytest.approx(0.86, abs=1e-6)),
        (-2.71, pytest.approx(0.29, abs=1e-6)),
        (-10.99, pytest.approx(0.01, abs=1e-6)),
        (-0.25, pytest.approx(0.75)),
        (-100.001, pytest.approx(0.999, abs=1e-6)),
    ])
    def test_various_negative_decimals(self, number, expected):
        assert truncate_number(number) == expected
    
    def test_return_type_is_float(self):
        result = truncate_number(5.5)
        assert isinstance(result, float)
    
    def test_result_always_between_zero_and_one(self):
        test_values = [0.0, 0.5, 1.0, 5.7, -5.7, 100.001, -100.001]
        for value in test_values:
            result = truncate_number(value)
            assert 0.0 <= result < 1.0 or result == pytest.approx(0.0)
