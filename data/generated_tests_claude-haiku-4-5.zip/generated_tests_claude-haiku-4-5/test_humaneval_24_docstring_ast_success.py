# Test cases for HumanEval/24
# Generated using Claude API



def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    >>> largest_divisor(15)
    5
    """

    for i in reversed(range(n)):
        if n % i == 0:
            return i


# Generated test cases:
import pytest


def largest_divisor(n: int) -> int:
    for i in reversed(range(n)):
        if n % i == 0:
            return i


class TestLargestDivisor:
    
    def test_example_case(self):
        assert largest_divisor(15) == 5
    
    def test_prime_number(self):
        assert largest_divisor(7) == 1
    
    def test_even_number(self):
        assert largest_divisor(10) == 5
    
    def test_power_of_two(self):
        assert largest_divisor(8) == 4
    
    def test_small_number_two(self):
        assert largest_divisor(2) == 1
    
    def test_small_number_three(self):
        assert largest_divisor(3) == 1
    
    def test_composite_number(self):
        assert largest_divisor(12) == 6
    
    def test_composite_number_20(self):
        assert largest_divisor(20) == 10
    
    def test_composite_number_100(self):
        assert largest_divisor(100) == 50
    
    def test_large_prime(self):
        assert largest_divisor(97) == 1
    
    def test_perfect_square(self):
        assert largest_divisor(16) == 8
    
    def test_number_with_many_divisors(self):
        assert largest_divisor(24) == 12
    
    def test_number_60(self):
        assert largest_divisor(60) == 30
    
    def test_number_with_odd_divisor(self):
        assert largest_divisor(21) == 7
    
    def test_number_with_odd_divisor_25(self):
        assert largest_divisor(25) == 5
    
    @pytest.mark.parametrize("n,expected", [
        (2, 1),
        (3, 1),
        (4, 2),
        (5, 1),
        (6, 3),
        (9, 3),
        (10, 5),
        (15, 5),
        (18, 9),
        (30, 15),
        (50, 25),
        (99, 33),
        (144, 72),
    ])
    def test_parametrized_cases(self, n, expected):
        assert largest_divisor(n) == expected
