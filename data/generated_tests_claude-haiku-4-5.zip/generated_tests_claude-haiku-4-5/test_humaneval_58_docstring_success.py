# Test cases for HumanEval/58
# Generated using Claude API



def common(l1: list, l2: list):
    """Return sorted unique common elements for two lists.
    >>> common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121])
    [1, 5, 653]
    >>> common([5, 3, 2, 8], [3, 2])
    [2, 3]

    """

    ret = set()
    for e1 in l1:
        for e2 in l2:
            if e1 == e2:
                ret.add(e1)
    return sorted(list(ret))


# Generated test cases:
import pytest


def common(l1: list, l2: list):
    ret = set()
    for e1 in l1:
        for e2 in l2:
            if e1 == e2:
                ret.add(e1)
    return sorted(list(ret))


class TestCommon:
    def test_basic_common_elements(self):
        assert common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121]) == [1, 5, 653]

    def test_basic_common_elements_2(self):
        assert common([5, 3, 2, 8], [3, 2]) == [2, 3]

    def test_empty_first_list(self):
        assert common([], [1, 2, 3]) == []

    def test_empty_second_list(self):
        assert common([1, 2, 3], []) == []

    def test_both_empty_lists(self):
        assert common([], []) == []

    def test_no_common_elements(self):
        assert common([1, 2, 3], [4, 5, 6]) == []

    def test_all_common_elements(self):
        assert common([1, 2, 3], [1, 2, 3]) == [1, 2, 3]

    def test_single_common_element(self):
        assert common([1, 2, 3], [3, 4, 5]) == [3]

    def test_duplicates_in_first_list(self):
        assert common([1, 1, 2, 2, 3], [2, 3, 4]) == [2, 3]

    def test_duplicates_in_second_list(self):
        assert common([1, 2, 3], [2, 2, 3, 3, 4]) == [2, 3]

    def test_duplicates_in_both_lists(self):
        assert common([1, 1, 2, 2, 3, 3], [2, 2, 3, 3, 4, 4]) == [2, 3]

    def test_negative_numbers(self):
        assert common([-1, -2, 3], [-2, 4, 5]) == [-2]

    def test_mixed_positive_negative(self):
        assert common([-5, -1, 0, 1, 5], [-5, 0, 5, 10]) == [-5, 0, 5]

    def test_strings(self):
        assert common(["a", "b", "c"], ["b", "c", "d"]) == ["b", "c"]

    def test_strings_with_duplicates(self):
        assert common(["a", "a", "b"], ["b", "b", "c"]) == ["b"]

    def test_floats(self):
        assert common([1.5, 2.5, 3.5], [2.5, 3.5, 4.5]) == [2.5, 3.5]

    def test_mixed_types_numbers(self):
        assert common([1, 2.0, 3], [2.0, 3, 4]) == [2.0, 3]

    def test_single_element_lists(self):
        assert common([1], [1]) == [1]

    def test_single_element_no_match(self):
        assert common([1], [2]) == []

    def test_large_lists(self):
        l1 = list(range(1000))
        l2 = list(range(500, 1500))
        result = common(l1, l2)
        assert result == list(range(500, 1000))

    def test_result_is_sorted(self):
        result = common([5, 1, 3, 2, 4], [4, 2, 5, 1, 3])
        assert result == sorted(result)

    def test_result_has_no_duplicates(self):
        result = common([1, 1, 1, 2, 2], [1, 2, 2, 2])
        assert len(result) == len(set(result))

    def test_zero_in_common(self):
        assert common([0, 1, 2], [0, 3, 4]) == [0]

    def test_boolean_values(self):
        assert common([True, False, 1], [False, 2]) == [False]

    @pytest.mark.parametrize("l1,l2,expected", [
        ([1, 2, 3], [1, 2, 3], [1, 2, 3]),
        ([1, 2], [3, 4], []),
        ([5], [5], [5]),
        ([], [], []),
        ([1, 2, 3, 4, 5], [3, 4, 5, 6, 7], [3, 4, 5]),
    ])
    def test_parametrized_cases(self, l1, l2, expected):
        assert common(l1, l2) == expected
