# Test cases for HumanEval/146
# Generated using Claude API


def specialFilter(nums):
    """Write a function that takes an array of numbers as input and returns 
    the number of elements in the array that are greater than 10 and both 
    first and last digits of a number are odd (1, 3, 5, 7, 9).
    For example:
    specialFilter([15, -73, 14, -15]) => 1 
    specialFilter([33, -2, -3, 45, 21, 109]) => 2
    """

    
    count = 0
    for num in nums:
        if num > 10:
            odd_digits = (1, 3, 5, 7, 9)
            number_as_string = str(num)
            if int(number_as_string[0]) in odd_digits and int(number_as_string[-1]) in odd_digits:
                count += 1
        
    return count 


# Generated test cases:
import pytest


class TestSpecialFilter:
    
    def test_empty_list(self):
        from test_humaneval_146_ast import specialFilter
        assert specialFilter([]) == 0
    
    def test_single_element_greater_than_10_both_odd(self):
        assert specialFilter([11]) == 1
    
    def test_single_element_greater_than_10_first_odd_last_even(self):
        assert specialFilter([12]) == 0
    
    def test_single_element_greater_than_10_first_even_last_odd(self):
        assert specialFilter([21]) == 0
    
    def test_single_element_greater_than_10_both_even(self):
        assert specialFilter([22]) == 0
    
    def test_single_element_less_than_or_equal_10(self):
        assert specialFilter([10]) == 0
        assert specialFilter([5]) == 0
        assert specialFilter([0]) == 0
    
    def test_multiple_elements_all_valid(self):
        assert specialFilter([11, 13, 15, 17, 19]) == 5
    
    def test_multiple_elements_mixed(self):
        assert specialFilter([11, 12, 13, 14, 15]) == 3
    
    def test_multiple_elements_none_valid(self):
        assert specialFilter([20, 22, 24, 26, 28]) == 0
    
    def test_three_digit_numbers_both_odd(self):
        assert specialFilter([111, 131, 151, 171, 191]) == 5
    
    def test_three_digit_numbers_mixed(self):
        assert specialFilter([111, 121, 131, 141, 151]) == 5
    
    def test_large_numbers_both_odd(self):
        assert specialFilter([1111, 3333, 5555, 7777, 9999]) == 5
    
    def test_large_numbers_mixed(self):
        assert specialFilter([1111, 2222, 3333, 4444, 5555]) == 3
    
    def test_numbers_with_zero_in_middle(self):
        assert specialFilter([101, 303, 505, 707, 909]) == 5
    
    def test_numbers_with_zero_in_middle_mixed(self):
        assert specialFilter([101, 202, 303, 404, 505]) == 3
    
    def test_boundary_value_10(self):
        assert specialFilter([10]) == 0
    
    def test_boundary_value_11(self):
        assert specialFilter([11]) == 1
    
    def test_negative_numbers(self):
        assert specialFilter([-11, -13, -15]) == 0
    
    def test_negative_numbers_greater_than_10(self):
        assert specialFilter([-5, -3, -1]) == 0
    
    def test_mixed_positive_and_negative(self):
        assert specialFilter([-11, 11, -13, 13]) == 2
    
    def test_all_odd_first_digit_even_last_digit(self):
        assert specialFilter([12, 14, 16, 18]) == 0
    
    def test_all_even_first_digit_odd_last_digit(self):
        assert specialFilter([21, 23, 25, 27, 29]) == 0
    
    def test_two_digit_numbers_all_combinations(self):
        assert specialFilter([11, 13, 15, 17, 19, 31, 33, 35, 37, 39, 51, 53, 55, 57, 59, 71, 73, 75, 77, 79, 91, 93, 95, 97, 99]) == 25
    
    def test_numbers_ending_with_1(self):
        assert specialFilter([11, 21, 31, 41, 51, 61, 71, 81, 91]) == 5
    
    def test_numbers_ending_with_3(self):
        assert specialFilter([13, 23, 33, 43, 53, 63, 73, 83, 93]) == 5
    
    def test_numbers_ending_with_5(self):
        assert specialFilter([15, 25, 35, 45, 55, 65, 75, 85, 95]) == 5
    
    def test_numbers_ending_with_7(self):
        assert specialFilter([17, 27, 37, 47, 57, 67, 77, 87, 97]) == 5
    
    def test_numbers_ending_with_9(self):
        assert specialFilter([19, 29, 39, 49, 59, 69, 79, 89, 99]) == 5
    
    def test_numbers_starting_with_1(self):
        assert specialFilter([11, 13, 15, 17, 19]) == 5
    
    def test_numbers_starting_with_3(self):
        assert specialFilter([31, 33, 35, 37, 39]) == 5
    
    def test_numbers_starting_with_5(self):
        assert specialFilter([51, 53, 55, 57, 59]) == 5
    
    def test_numbers_starting_with_7(self):
        assert specialFilter([71, 73, 75, 77, 79]) == 5
    
    def test_numbers_starting_with_9(self):
        assert specialFilter([91, 93, 95, 97, 99]) == 5
    
    def test_very_large_numbers(self):
        assert specialFilter([123456789, 987654321, 111111111]) == 3
    
    def test_single_digit_numbers(self):
        assert specialFilter([1, 3, 5, 7, 9]) == 0
    
    def test_exactly_10(self):
        assert specialFilter([10, 10, 10]) == 0
    
    def test_mixed_valid_and_invalid_large_list(self):
        result = specialFilter([11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25])
        assert result == 5

    @pytest.mark.parametrize("nums,expected", [
        ([11], 1),
        ([12], 0),
        ([21], 0),
        ([22], 0),
        ([111], 1),
        ([131], 1),
        ([151], 1),
        ([171], 1),
        ([191], 1),
        ([101], 1),
        ([303], 1),
        ([505], 1),
        ([707], 1),
        ([909], 1),
        ([10], 0),
        ([9], 0),
        ([], 0),
        ([11, 13, 15, 17, 19], 5),
        ([12, 14, 16, 18, 20], 0),
        ([21, 23, 25, 27, 29], 0),
    ])
    def test_parametrized_cases(self, nums, expected):
        assert specialFilter(nums) == expected