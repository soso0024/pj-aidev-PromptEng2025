# Test cases for HumanEval/98
# Generated using Claude API


def count_upper(s):
    """
    Given a string s, count the number of uppercase vowels in even indices.
    
    For example:
    count_upper('aBCdEf') returns 1
    count_upper('abcdefg') returns 0
    count_upper('dBBE') returns 0
    """

    count = 0
    for i in range(0,len(s),2):
        if s[i] in "AEIOU":
            count += 1
    return count


# Generated test cases:
import pytest


class TestCountUpper:
    def test_empty_string(self):
        from test_humaneval_98_ast import count_upper
        assert count_upper("") == 0

    def test_single_uppercase_vowel(self):
        assert count_upper("A") == 1

    def test_single_uppercase_consonant(self):
        assert count_upper("B") == 0

    def test_single_lowercase_vowel(self):
        assert count_upper("a") == 0

    def test_all_uppercase_vowels_at_even_indices(self):
        assert count_upper("AEIOU") == 3

    def test_all_uppercase_consonants(self):
        assert count_upper("BCDFG") == 0

    def test_mixed_case_vowels(self):
        assert count_upper("AaBbEe") == 2

    def test_vowels_at_odd_indices_not_counted(self):
        assert count_upper("bAeIoU") == 0

    def test_alternating_vowel_consonant(self):
        assert count_upper("ABCDEF") == 2

    def test_long_string_with_vowels_at_even_indices(self):
        assert count_upper("AEBICOD") == 1

    def test_long_string_no_vowels_at_even_indices(self):
        assert count_upper("bBdDfF") == 0

    def test_string_with_numbers_and_special_chars(self):
        assert count_upper("A1E2I3O4U5") == 5

    def test_string_with_only_lowercase(self):
        assert count_upper("aeiou") == 0

    def test_string_with_uppercase_at_odd_positions(self):
        assert count_upper("bAdEfI") == 0

    def test_two_character_string_with_vowel(self):
        assert count_upper("AX") == 1

    def test_two_character_string_without_vowel(self):
        assert count_upper("BX") == 0

    def test_three_character_string(self):
        assert count_upper("AXE") == 2

    def test_four_character_string(self):
        assert count_upper("AXEY") == 2

    def test_string_with_all_vowels_uppercase(self):
        assert count_upper("AEIOUAEIOU") == 5

    def test_string_with_mixed_vowels_and_consonants(self):
        assert count_upper("ABCDEFGHIJ") == 3

    @pytest.mark.parametrize("input_str,expected", [
        ("", 0),
        ("A", 1),
        ("B", 0),
        ("AA", 1),
        ("AB", 1),
        ("BA", 0),
        ("AEIOU", 3),
        ("aeiou", 0),
        ("AaBbCc", 1),
        ("BCDFG", 0),
    ])
    def test_parametrized_cases(self, input_str, expected):
        assert count_upper(input_str) == expected

    def test_very_long_string(self):
        s = "A" * 1000
        assert count_upper(s) == 500

    def test_very_long_string_no_vowels(self):
        s = "B" * 1000
        assert count_upper(s) == 0

    def test_alternating_vowel_consonant_long(self):
        s = "AB" * 500
        assert count_upper(s) == 500

    def test_string_with_spaces(self):
        assert count_upper("A B E I O U") == 5

    def test_string_with_tabs(self):
        assert count_upper("A\tE\tI") == 3

    def test_string_with_newlines(self):
        assert count_upper("A\nE\nI") == 3

    def test_only_consonants_uppercase(self):
        assert count_upper("BCDFGHJKLMNPQRSTVWXYZ") == 0

    def test_only_vowels_uppercase(self):
        assert count_upper("AEIOUAEIOU") == 5

    def test_pattern_vowel_consonant_repeated(self):
        assert count_upper("ABABAB") == 3

    def test_pattern_consonant_vowel_repeated(self):
        assert count_upper("BABABA") == 0