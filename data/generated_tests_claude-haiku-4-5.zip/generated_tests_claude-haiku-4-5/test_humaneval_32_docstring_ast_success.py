# Test cases for HumanEval/32
# Generated using Claude API

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


def find_zero(xs: list):
    """ xs are coefficients of a polynomial.
    find_zero find x such that poly(x) = 0.
    find_zero returns only only zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.
    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0
    """

    begin, end = -1., 1.
    while poly(xs, begin) * poly(xs, end) > 0:
        begin *= 2.0
        end *= 2.0
    while end - begin > 1e-10:
        center = (begin + end) / 2.0
        if poly(xs, center) * poly(xs, begin) > 0:
            begin = center
        else:
            end = center
    return begin


# Generated test cases:
import pytest
import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


def find_zero(xs: list):
    """ xs are coefficients of a polynomial.
    find_zero find x such that poly(x) = 0.
    find_zero returns only only zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.
    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0
    """
    begin, end = -1., 1.
    while poly(xs, begin) * poly(xs, end) > 0:
        begin *= 2.0
        end *= 2.0
    while end - begin > 1e-10:
        center = (begin + end) / 2.0
        if poly(xs, center) * poly(xs, begin) > 0:
            begin = center
        else:
            end = center
    return begin


class TestFindZero:
    
    def test_linear_polynomial_simple(self):
        """Test finding zero of simple linear polynomial: 1 + 2x = 0"""
        result = find_zero([1, 2])
        assert abs(result - (-0.5)) < 1e-6
    
    def test_linear_polynomial_negative_slope(self):
        """Test finding zero of linear polynomial with negative slope: 5 - 2x = 0"""
        result = find_zero([5, -2])
        assert abs(result - 2.5) < 1e-6
    
    def test_cubic_polynomial(self):
        """Test finding zero of cubic polynomial: -6 + 11x - 6x^2 + x^3 = 0"""
        result = find_zero([-6, 11, -6, 1])
        assert abs(result - 1.0) < 1e-6
    
    def test_quadratic_polynomial(self):
        """Test finding zero of quadratic polynomial: -2 + x + x^2 = 0"""
        result = find_zero([-2, 1, 1])
        zero_value = poly([-2, 1, 1], result)
        assert abs(zero_value) < 1e-6
    
    def test_quadratic_polynomial_two_roots(self):
        """Test finding one zero of quadratic with two roots: -6 + x + x^2 = 0"""
        result = find_zero([-6, 1, 1])
        zero_value = poly([-6, 1, 1], result)
        assert abs(zero_value) < 1e-6
    
    def test_polynomial_with_large_coefficients(self):
        """Test polynomial with large coefficients: -1000 + 100x + x^2 = 0"""
        result = find_zero([-1000, 100, 1])
        zero_value = poly([-1000, 100, 1], result)
        assert abs(zero_value) < 1e-6
    
    def test_polynomial_negative_zero(self):
        """Test finding negative zero: 1 - x = 0 should give x = 1, but test negative case"""
        result = find_zero([1, -1])
        zero_value = poly([1, -1], result)
        assert abs(zero_value) < 1e-6
    
    def test_polynomial_degree_four(self):
        """Test finding zero of degree 4 polynomial"""
        result = find_zero([-1, 0, 0, 0, 1])
        zero_value = poly([-1, 0, 0, 0, 1], result)
        assert abs(zero_value) < 1e-6
    
    def test_polynomial_with_zero_middle_coefficients(self):
        """Test polynomial with zero coefficients in middle: -8 + x^3 = 0"""
        result = find_zero([-8, 0, 0, 1])
        zero_value = poly([-8, 0, 0, 1], result)
        assert abs(zero_value) < 1e-6
    
    def test_polynomial_result_is_valid_zero(self):
        """Verify that the returned value actually makes poly equal to zero"""
        coeffs = [3, -7, 2, 1]
        result = find_zero(coeffs)
        zero_value = poly(coeffs, result)
        assert abs(zero_value) < 1e-6
    
    def test_polynomial_high_degree(self):
        """Test finding zero of higher degree polynomial"""
        result = find_zero([-1, 0, 0, 0, 0, 1])
        zero_value = poly([-1, 0, 0, 0, 0, 1], result)
        assert abs(zero_value) < 1e-6
    
    def test_polynomial_alternating_signs(self):
        """Test polynomial with alternating sign coefficients"""
        result = find_zero([1, -1, 1, -1])
        zero_value = poly([1, -1, 1, -1], result)
        assert abs(zero_value) < 1e-6
    
    def test_polynomial_all_positive_except_constant(self):
        """Test polynomial: -10 + 2x + 3x^2 + x^3 = 0"""
        result = find_zero([-10, 2, 3, 1])
        zero_value = poly([-10, 2, 3, 1], result)
        assert abs(zero_value) < 1e-6
    
    def test_polynomial_fractional_coefficients(self):
        """Test polynomial with fractional coefficients"""
        result = find_zero([-0.5, 0.25, 0.1])
        zero_value = poly([-0.5, 0.25, 0.1], result)
        assert abs(zero_value) < 1e-6
    
    def test_polynomial_very_small_constant(self):
        """Test polynomial with very small constant term"""
        result = find_zero([-1e-8, 1, 1])
        zero_value = poly([-1e-8, 1, 1], result)
        assert abs(zero_value) < 1e-6


class TestPolyFunction:
    
    def test_poly_constant(self):
        """Test poly with constant polynomial"""
        assert poly([5], 0) == 5
        assert poly([5], 10) == 5
    
    def test_poly_linear(self):
        """Test poly with linear polynomial"""
        assert poly([1, 2], 0) == 1
        assert poly([1, 2], 1) == 3
        assert poly([1, 2], -0.5) == 0
    
    def test_poly_quadratic(self):
        """Test poly with quadratic polynomial"""
        assert poly([0, 0, 1], 2) == 4
        assert poly([0, 0, 1], 3) == 9
    
    def test_poly_cubic(self):
        """Test poly with cubic polynomial"""
        assert poly([-6, 11, -6, 1], 1) == 0
        assert poly([-6, 11, -6, 1], 2) == 0
        assert poly([-6, 11, -6, 1], 3) == 0