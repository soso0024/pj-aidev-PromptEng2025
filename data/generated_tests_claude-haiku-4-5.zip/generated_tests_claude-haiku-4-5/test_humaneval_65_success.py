# Test cases for HumanEval/65
# Generated using Claude API


def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.
    >>> circular_shift(12, 1)
    "21"
    >>> circular_shift(12, 2)
    "12"
    """

    s = str(x)
    if shift > len(s):
        return s[::-1]
    else:
        return s[len(s) - shift:] + s[:len(s) - shift]


# Generated test cases:
import pytest


def circular_shift(x, shift):
    s = str(x)
    if shift > len(s):
        return s[::-1]
    else:
        return s[len(s) - shift:] + s[:len(s) - shift]


class TestCircularShift:
    
    @pytest.mark.parametrize("x,shift,expected", [
        (12345, 0, "12345"),
        (12345, 1, "51234"),
        (12345, 2, "45123"),
        (12345, 3, "34512"),
        (12345, 4, "23451"),
        (12345, 5, "12345"),
    ])
    def test_normal_cases(self, x, shift, expected):
        assert circular_shift(x, shift) == expected
    
    @pytest.mark.parametrize("x,shift,expected", [
        (12345, 6, "54321"),
        (12345, 10, "54321"),
        (12345, 100, "54321"),
        (123, 5, "321"),
        (1, 2, "1"),
    ])
    def test_shift_greater_than_length(self, x, shift, expected):
        assert circular_shift(x, shift) == expected
    
    @pytest.mark.parametrize("x,shift,expected", [
        (0, 0, "0"),
        (0, 1, "0"),
        (0, 5, "0"),
    ])
    def test_zero_input(self, x, shift, expected):
        assert circular_shift(x, shift) == expected
    
    @pytest.mark.parametrize("x,shift,expected", [
        (1, 0, "1"),
        (1, 1, "1"),
        (1, 5, "1"),
        (9, 0, "9"),
        (9, 1, "9"),
    ])
    def test_single_digit(self, x, shift, expected):
        assert circular_shift(x, shift) == expected
    
    @pytest.mark.parametrize("x,shift,expected", [
        (-123, 0, "-123"),
        (-123, 1, "3-12"),
        (-123, 2, "23-1"),
        (-123, 4, "-123"),
    ])
    def test_negative_numbers(self, x, shift, expected):
        assert circular_shift(x, shift) == expected
    
    @pytest.mark.parametrize("x,shift,expected", [
        ("hello", 0, "hello"),
        ("hello", 1, "ohell"),
        ("hello", 2, "lohel"),
        ("hello", 5, "hello"),
        ("hello", 6, "olleh"),
    ])
    def test_string_input(self, x, shift, expected):
        assert circular_shift(x, shift) == expected
    
    @pytest.mark.parametrize("x,shift,expected", [
        (100, 0, "100"),
        (100, 1, "010"),
        (100, 2, "001"),
        (100, 4, "001"),
    ])
    def test_numbers_with_zeros(self, x, shift, expected):
        assert circular_shift(x, shift) == expected
    
    @pytest.mark.parametrize("x,shift,expected", [
        (1000000, 0, "1000000"),
        (1000000, 1, "0100000"),
        (1000000, 7, "1000000"),
        (1000000, 8, "0000001"),
    ])
    def test_large_numbers(self, x, shift, expected):
        assert circular_shift(x, shift) == expected
    
    def test_two_digit_number(self):
        assert circular_shift(12, 0) == "12"
        assert circular_shift(12, 1) == "21"
        assert circular_shift(12, 2) == "12"
        assert circular_shift(12, 3) == "21"
    
    def test_three_digit_number(self):
        assert circular_shift(123, 0) == "123"
        assert circular_shift(123, 1) == "312"
        assert circular_shift(123, 2) == "231"
        assert circular_shift(123, 3) == "123"
        assert circular_shift(123, 4) == "321"