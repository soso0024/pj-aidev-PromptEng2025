# Test cases for HumanEval/108
# Generated using Claude API


def count_nums(arr):
    """
    Write a function count_nums which takes an array of integers and returns
    the number of elements which has a sum of digits > 0.
    If a number is negative, then its first signed digit will be negative:
    e.g. -123 has signed digits -1, 2, and 3.
    >>> count_nums([]) == 0
    >>> count_nums([-1, 11, -11]) == 1
    >>> count_nums([1, 1, 2]) == 3
    """

    def digits_sum(n):
        neg = 1
        if n < 0: n, neg = -1 * n, -1 
        n = [int(i) for i in str(n)]
        n[0] = n[0] * neg
        return sum(n)
    return len(list(filter(lambda x: x > 0, [digits_sum(i) for i in arr])))


# Generated test cases:
import pytest


class TestCountNums:
    
    def test_empty_array(self):
        from test_humaneval_108_docstring_ast import count_nums
        assert count_nums([]) == 0
    
    def test_single_positive_number(self):
        assert count_nums([1]) == 1
    
    def test_single_negative_number(self):
        assert count_nums([-1]) == 0
    
    def test_single_zero(self):
        assert count_nums([0]) == 0
    
    def test_docstring_example_1(self):
        assert count_nums([]) == 0
    
    def test_docstring_example_2(self):
        assert count_nums([-1, 11, -11]) == 1
    
    def test_docstring_example_3(self):
        assert count_nums([1, 1, 2]) == 3
    
    def test_all_positive_single_digits(self):
        assert count_nums([1, 2, 3, 4, 5]) == 5
    
    def test_all_negative_single_digits(self):
        assert count_nums([-1, -2, -3, -4, -5]) == 0
    
    def test_mixed_positive_and_negative(self):
        assert count_nums([1, -1, 2, -2, 3, -3]) == 3
    
    def test_positive_multi_digit_numbers(self):
        assert count_nums([10, 20, 30]) == 3
    
    def test_negative_multi_digit_numbers(self):
        assert count_nums([-10, -20, -30]) == 0
    
    def test_negative_number_with_positive_digit_sum(self):
        assert count_nums([-123]) == 1
    
    def test_positive_number_with_positive_digit_sum(self):
        assert count_nums([123]) == 1
    
    def test_negative_number_digit_sum_calculation(self):
        assert count_nums([-1, 11, -11]) == 1
    
    def test_zero_in_middle(self):
        assert count_nums([1, 0, 1]) == 2
    
    def test_large_positive_numbers(self):
        assert count_nums([999, 1000, 10000]) == 3
    
    def test_large_negative_numbers(self):
        assert count_nums([-999, -1000, -10000]) == 1
    
    def test_number_with_zero_digit_sum(self):
        assert count_nums([10, -10]) == 1
    
    def test_negative_with_larger_positive_digits(self):
        assert count_nums([-19]) == 1
    
    def test_negative_with_smaller_positive_digits(self):
        assert count_nums([-91]) == 0
    
    def test_mixed_complex_case(self):
        assert count_nums([12, -12, 100, -100, 5, -5]) == 4
    
    def test_all_zeros(self):
        assert count_nums([0, 0, 0]) == 0
    
    def test_single_large_positive(self):
        assert count_nums([123456789]) == 1
    
    def test_single_large_negative(self):
        assert count_nums([-123456789]) == 1
    
    def test_negative_number_with_sum_exactly_zero(self):
        assert count_nums([-10]) == 0
    
    def test_positive_number_with_sum_exactly_zero(self):
        assert count_nums([10]) == 1
    
    def test_negative_two_digit_positive_sum(self):
        assert count_nums([-29]) == 1
    
    def test_negative_two_digit_negative_sum(self):
        assert count_nums([-92]) == 0
    
    def test_multiple_negatives_one_positive_sum(self):
        assert count_nums([-19, -28, -37]) == 3
    
    def test_multiple_negatives_all_negative_sum(self):
        assert count_nums([-91, -82, -73]) == 0
    
    @pytest.mark.parametrize("arr,expected", [
        ([], 0),
        ([1], 1),
        ([-1], 0),
        ([0], 0),
        ([1, 2, 3], 3),
        ([-1, -2, -3], 0),
        ([1, -1], 1),
        ([-1, 11, -11], 1),
        ([1, 1, 2], 3),
        ([10, 20, 30], 3),
        ([-10, -20, -30], 0),
        ([123, -123], 2),
        ([-19, 19], 2),
        ([0, 0, 0], 0),
        ([100, -100], 1),
    ])
    def test_parametrized_cases(self, arr, expected):
        assert count_nums(arr) == expected