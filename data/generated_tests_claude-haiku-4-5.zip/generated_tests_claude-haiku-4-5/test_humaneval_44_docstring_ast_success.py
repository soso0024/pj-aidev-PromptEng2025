# Test cases for HumanEval/44
# Generated using Claude API



def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """

    ret = ""
    while x > 0:
        ret = str(x % base) + ret
        x //= base
    return ret


# Generated test cases:
import pytest


def change_base(x: int, base: int):
    ret = ""
    while x > 0:
        ret = str(x % base) + ret
        x //= base
    return ret


class TestChangeBase:
    
    def test_example_8_to_base_3(self):
        assert change_base(8, 3) == '22'
    
    def test_example_8_to_base_2(self):
        assert change_base(8, 2) == '1000'
    
    def test_example_7_to_base_2(self):
        assert change_base(7, 2) == '111'
    
    def test_zero_input(self):
        assert change_base(0, 2) == ''
    
    def test_zero_input_base_3(self):
        assert change_base(0, 3) == ''
    
    def test_one_to_any_base(self):
        assert change_base(1, 2) == '1'
        assert change_base(1, 3) == '1'
        assert change_base(1, 9) == '1'
    
    def test_base_2_conversions(self):
        assert change_base(1, 2) == '1'
        assert change_base(2, 2) == '10'
        assert change_base(3, 2) == '11'
        assert change_base(4, 2) == '100'
        assert change_base(5, 2) == '101'
        assert change_base(15, 2) == '1111'
        assert change_base(16, 2) == '10000'
    
    def test_base_3_conversions(self):
        assert change_base(1, 3) == '1'
        assert change_base(3, 3) == '10'
        assert change_base(9, 3) == '100'
        assert change_base(27, 3) == '1000'
    
    def test_base_4_conversions(self):
        assert change_base(4, 4) == '10'
        assert change_base(16, 4) == '100'
    
    def test_base_5_conversions(self):
        assert change_base(5, 5) == '10'
        assert change_base(25, 5) == '100'
    
    def test_base_9_conversions(self):
        assert change_base(9, 9) == '10'
        assert change_base(81, 9) == '100'
    
    def test_large_numbers(self):
        assert change_base(100, 2) == '1100100'
        assert change_base(1000, 2) == '1111101000'
        assert change_base(255, 2) == '11111111'
    
    def test_various_bases(self):
        assert change_base(10, 2) == '1010'
        assert change_base(10, 3) == '101'
        assert change_base(10, 4) == '22'
        assert change_base(10, 5) == '20'
        assert change_base(10, 6) == '14'
        assert change_base(10, 7) == '13'
        assert change_base(10, 8) == '12'
        assert change_base(10, 9) == '11'
    
    def test_power_of_base_numbers(self):
        assert change_base(2, 2) == '10'
        assert change_base(4, 2) == '100'
        assert change_base(8, 2) == '1000'
        assert change_base(16, 2) == '10000'
        assert change_base(32, 2) == '100000'
    
    @pytest.mark.parametrize("x,base,expected", [
        (8, 3, '22'),
        (8, 2, '1000'),
        (7, 2, '111'),
        (1, 2, '1'),
        (2, 2, '10'),
        (3, 2, '11'),
        (15, 2, '1111'),
        (27, 3, '1000'),
        (100, 2, '1100100'),
    ])
    def test_parametrized_conversions(self, x, base, expected):
        assert change_base(x, base) == expected
