# Test cases for HumanEval/1
# Generated using Claude API

from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """ Input to this function is a string containing multiple groups of nested parentheses. Your goal is to
    separate those group into separate strings and return the list of those.
    Separate groups are balanced (each open brace is properly closed) and not nested within each other
    Ignore any spaces in the input string.
    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """

    result = []
    current_string = []
    current_depth = 0

    for c in paren_string:
        if c == '(':
            current_depth += 1
            current_string.append(c)
        elif c == ')':
            current_depth -= 1
            current_string.append(c)

            if current_depth == 0:
                result.append(''.join(current_string))
                current_string.clear()

    return result


# Generated test cases:
import pytest
from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    result = []
    current_string = []
    current_depth = 0

    for c in paren_string:
        if c == '(':
            current_depth += 1
            current_string.append(c)
        elif c == ')':
            current_depth -= 1
            current_string.append(c)

            if current_depth == 0:
                result.append(''.join(current_string))
                current_string.clear()

    return result


class TestSeparateParenGroups:
    
    def test_example_from_docstring(self):
        result = separate_paren_groups('( ) (( )) (( )( ))')
        assert result == ['()', '(())', '(()())']
    
    def test_single_group(self):
        result = separate_paren_groups('()')
        assert result == ['()']
    
    def test_single_nested_group(self):
        result = separate_paren_groups('(())')
        assert result == ['(())']
    
    def test_multiple_simple_groups(self):
        result = separate_paren_groups('()()()') 
        assert result == ['()', '()', '()']
    
    def test_multiple_nested_groups(self):
        result = separate_paren_groups('(())(())')
        assert result == ['(())', '(())']
    
    def test_deeply_nested_single_group(self):
        result = separate_paren_groups('(((())))') 
        assert result == ['(((())))']
    
    def test_complex_nesting(self):
        result = separate_paren_groups('(()())()(())')
        assert result == ['(()())', '()', '(())']
    
    def test_with_spaces_only(self):
        result = separate_paren_groups('   ')
        assert result == []
    
    def test_with_spaces_between_groups(self):
        result = separate_paren_groups('( ) ( ) ( )')
        assert result == ['()', '()', '()']
    
    def test_with_spaces_inside_groups(self):
        result = separate_paren_groups('( ( ) ) ( ( ) ( ) )')
        assert result == ['(())', '(()())']
    
    def test_empty_string(self):
        result = separate_paren_groups('')
        assert result == []
    
    def test_single_open_paren_group(self):
        result = separate_paren_groups('()')
        assert result == ['()']
    
    def test_many_groups(self):
        result = separate_paren_groups('()()()()()') 
        assert result == ['()', '()', '()', '()', '()']
    
    def test_alternating_simple_and_nested(self):
        result = separate_paren_groups('()(())()(()())')
        assert result == ['()', '(())', '()', '(()())']
    
    def test_very_deeply_nested(self):
        result = separate_paren_groups('((((((()))))))') 
        assert result == ['((((((()))))))']
    
    def test_mixed_depth_groups(self):
        result = separate_paren_groups('()(())(((())))()')
        assert result == ['()', '(())', '(((())))', '()']
    
    def test_spaces_everywhere(self):
        result = separate_paren_groups('  (  )  (  (  )  )  ')
        assert result == ['()', '(())']
    
    def test_single_group_with_multiple_levels(self):
        result = separate_paren_groups('(()()())')
        assert result == ['(()()())']
    
    def test_two_groups_different_depths(self):
        result = separate_paren_groups('()(())')
        assert result == ['()', '(())']
    
    def test_complex_pattern(self):
        result = separate_paren_groups('()()(())(()())()')
        assert result == ['()', '()', '(())', '(()())', '()']


@pytest.mark.parametrize("input_str,expected", [
    ('()', ['()']),
    ('(())', ['(())']),
    ('()()()' , ['()', '()', '()']),
    ('( ) (( )) (( )( ))', ['()', '(())', '(()())']),
    ('', []),
    ('   ', []),
    ('()(())()(())', ['()', '(())', '()', '(())']),
    ('((()))', ['((()))']),
    ('()()()()()' , ['()', '()', '()', '()', '()']),
    ('(()())', ['(()())']),
])
def test_separate_paren_groups_parametrized(input_str, expected):
    assert separate_paren_groups(input_str) == expected