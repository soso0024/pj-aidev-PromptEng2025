# Test cases for HumanEval/119
# Generated using Claude API


def match_parens(lst):
    '''
    You are given a list of two strings, both strings consist of open
    parentheses '(' or close parentheses ')' only.
    Your job is to check if it is possible to concatenate the two strings in
    some order, that the resulting string will be good.
    A string S is considered to be good if and only if all parentheses in S
    are balanced. For example: the string '(())()' is good, while the string
    '())' is not.
    Return 'Yes' if there's a way to make a good string, and return 'No' otherwise.

    Examples:
    match_parens(['()(', ')']) == 'Yes'
    match_parens([')', ')']) == 'No'
    '''

    def check(s):
        val = 0
        for i in s:
            if i == '(':
                val = val + 1
            else:
                val = val - 1
            if val < 0:
                return False
        return True if val == 0 else False

    S1 = lst[0] + lst[1]
    S2 = lst[1] + lst[0]
    return 'Yes' if check(S1) or check(S2) else 'No'


# Generated test cases:
import pytest


def match_parens(lst):
    def check(s):
        val = 0
        for i in s:
            if i == '(':
                val = val + 1
            else:
                val = val - 1
            if val < 0:
                return False
        return True if val == 0 else False

    S1 = lst[0] + lst[1]
    S2 = lst[1] + lst[0]
    return 'Yes' if check(S1) or check(S2) else 'No'


class TestMatchParens:
    
    @pytest.mark.parametrize("input_list,expected", [
        (['()(', ')'], 'Yes'),
        ([')', ')'], 'No'),
        (['(', ')'], 'Yes'),
        ([')', '('], 'Yes'),
        (['((', '))'], 'Yes'),
        (['()', '()'], 'Yes'),
        (['(((', ')))'], 'Yes'),
        (['(()', '())'], 'Yes'),
        (['(', '('], 'No'),
        ([')', ')'], 'No'),
        (['', ''], 'Yes'),
        (['()', ''], 'Yes'),
        (['', '()'], 'Yes'),
        (['(', ''], 'No'),
        (['', ')'], 'No'),
        (['())(', '()'], 'No'),
        (['(())', '()'], 'Yes'),
        (['()())', '('], 'Yes'),
        (['((((', '))))'], 'Yes'),
        (['))))', '(((('], 'Yes'),
        (['()()(', ')'], 'Yes'),
        (['(()(', '))'], 'Yes'),
        (['())', '('], 'Yes'),
        (['(', '))'], 'No'),
        (['))))', '(('], 'No'),
    ])
    def test_match_parens(self, input_list, expected):
        assert match_parens(input_list) == expected
    
    def test_basic_yes_case(self):
        assert match_parens(['()(', ')']) == 'Yes'
    
    def test_basic_no_case(self):
        assert match_parens([')', ')']) == 'No'
    
    def test_single_pair(self):
        assert match_parens(['(', ')']) == 'Yes'
    
    def test_reversed_single_pair(self):
        assert match_parens([')', '(']) == 'Yes'
    
    def test_both_open(self):
        assert match_parens(['(', '(']) == 'No'
    
    def test_both_close(self):
        assert match_parens([')', ')']) == 'No'
    
    def test_empty_strings(self):
        assert match_parens(['', '']) == 'Yes'
    
    def test_one_empty_valid(self):
        assert match_parens(['()', '']) == 'Yes'
    
    def test_one_empty_invalid_open(self):
        assert match_parens(['(', '']) == 'No'
    
    def test_one_empty_invalid_close(self):
        assert match_parens(['', ')']) == 'No'
    
    def test_multiple_pairs_balanced(self):
        assert match_parens(['(())', '()']) == 'Yes'
    
    def test_multiple_pairs_unbalanced(self):
        assert match_parens(['(()', '())']) == 'Yes'
    
    def test_long_sequence_balanced(self):
        assert match_parens(['((((', '))))']) == 'Yes'
    
    def test_long_sequence_unbalanced(self):
        assert match_parens(['))))', '((((']) == 'Yes'
    
    def test_complex_case_1(self):
        assert match_parens(['()()(', ')']) == 'Yes'
    
    def test_complex_case_2(self):
        assert match_parens(['(()(', '))']) == 'Yes'
    
    def test_complex_case_3(self):
        assert match_parens(['())', '(']) == 'Yes'
    
    def test_complex_case_4(self):
        assert match_parens(['(', '))']) == 'No'
    
    def test_complex_case_5(self):
        assert match_parens(['))))', '((']) == 'No'