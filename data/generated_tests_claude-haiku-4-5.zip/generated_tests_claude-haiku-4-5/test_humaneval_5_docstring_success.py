# Test cases for HumanEval/5
# Generated using Claude API

from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """ Insert a number 'delimeter' between every two consecutive elements of input list `numbers'
    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """

    if not numbers:
        return []

    result = []

    for n in numbers[:-1]:
        result.append(n)
        result.append(delimeter)

    result.append(numbers[-1])

    return result


# Generated test cases:
import pytest
from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    if not numbers:
        return []

    result = []

    for n in numbers[:-1]:
        result.append(n)
        result.append(delimeter)

    result.append(numbers[-1])

    return result


class TestIntersperse:
    def test_empty_list(self):
        assert intersperse([], 4) == []

    def test_single_element(self):
        assert intersperse([1], 4) == [1]

    def test_two_elements(self):
        assert intersperse([1, 2], 4) == [1, 4, 2]

    def test_three_elements(self):
        assert intersperse([1, 2, 3], 4) == [1, 4, 2, 4, 3]

    def test_multiple_elements(self):
        assert intersperse([1, 2, 3, 4, 5], 0) == [1, 0, 2, 0, 3, 0, 4, 0, 5]

    def test_negative_delimiter(self):
        assert intersperse([1, 2, 3], -1) == [1, -1, 2, -1, 3]

    def test_negative_numbers(self):
        assert intersperse([-1, -2, -3], 0) == [-1, 0, -2, 0, -3]

    def test_zero_delimiter(self):
        assert intersperse([5, 10, 15], 0) == [5, 0, 10, 0, 15]

    def test_large_delimiter(self):
        assert intersperse([1, 2], 1000) == [1, 1000, 2]

    def test_all_same_numbers(self):
        assert intersperse([5, 5, 5], 1) == [5, 1, 5, 1, 5]

    def test_delimiter_same_as_number(self):
        assert intersperse([1, 1, 1], 1) == [1, 1, 1, 1, 1]

    @pytest.mark.parametrize("numbers,delimeter,expected", [
        ([], 4, []),
        ([1], 4, [1]),
        ([1, 2], 4, [1, 4, 2]),
        ([1, 2, 3], 4, [1, 4, 2, 4, 3]),
        ([10, 20, 30, 40], 5, [10, 5, 20, 5, 30, 5, 40]),
        ([-5, -10], 0, [-5, 0, -10]),
        ([100], 99, [100]),
        ([1, 2, 3, 4, 5, 6], 0, [1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6]),
    ])
    def test_parametrized_cases(self, numbers, delimeter, expected):
        assert intersperse(numbers, delimeter) == expected

    def test_return_type_is_list(self):
        result = intersperse([1, 2, 3], 4)
        assert isinstance(result, list)

    def test_original_list_not_modified(self):
        original = [1, 2, 3]
        original_copy = original.copy()
        intersperse(original, 4)
        assert original == original_copy

    def test_long_list(self):
        numbers = list(range(1, 11))
        result = intersperse(numbers, 0)
        expected = [1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, 7, 0, 8, 0, 9, 0, 10]
        assert result == expected

    def test_result_length(self):
        numbers = [1, 2, 3, 4]
        result = intersperse(numbers, 5)
        assert len(result) == 2 * len(numbers) - 1

    def test_result_length_single_element(self):
        result = intersperse([1], 5)
        assert len(result) == 1

    def test_result_length_empty(self):
        result = intersperse([], 5)
        assert len(result) == 0
