# Test cases for HumanEval/122
# Generated using Claude API


def add_elements(arr, k):
    """
    Given a non-empty array of integers arr and an integer k, return
    the sum of the elements with at most two digits from the first k elements of arr.

    Example:

        Input: arr = [111,21,3,4000,5,6,7,8,9], k = 4
        Output: 24 # sum of 21 + 3

    Constraints:
        1. 1 <= len(arr) <= 100
        2. 1 <= k <= len(arr)
    """

    return sum(elem for elem in arr[:k] if len(str(elem)) <= 2)


# Generated test cases:
import pytest


def add_elements(arr, k):
    return sum(elem for elem in arr[:k] if len(str(elem)) <= 2)


class TestAddElements:
    
    def test_empty_array(self):
        assert add_elements([], 0) == 0
    
    def test_k_zero(self):
        assert add_elements([1, 2, 3, 4, 5], 0) == 0
    
    def test_k_greater_than_array_length(self):
        assert add_elements([1, 2, 3], 10) == 6
    
    def test_single_digit_numbers(self):
        assert add_elements([1, 2, 3, 4, 5], 3) == 6
    
    def test_two_digit_numbers(self):
        assert add_elements([10, 20, 30], 3) == 60
    
    def test_mixed_single_and_two_digit(self):
        assert add_elements([1, 10, 2, 20, 3], 5) == 36
    
    def test_three_digit_numbers_excluded(self):
        assert add_elements([1, 100, 2, 200, 3], 5) == 6
    
    def test_negative_single_digit(self):
        assert add_elements([-1, -2, -3], 3) == -6
    
    def test_negative_two_digit(self):
        assert add_elements([-10, -20, -30], 3) == 0
    
    def test_negative_three_digit_excluded(self):
        assert add_elements([-1, -100, -2, -200, -3], 5) == -6
    
    def test_zero_in_array(self):
        assert add_elements([0, 1, 2], 3) == 3
    
    def test_k_equals_one(self):
        assert add_elements([5, 100, 200], 1) == 5
    
    def test_k_equals_one_with_three_digit(self):
        assert add_elements([100, 1, 2], 1) == 0
    
    def test_all_three_digit_numbers(self):
        assert add_elements([100, 200, 300, 400], 4) == 0
    
    def test_mixed_positive_negative(self):
        assert add_elements([-5, 10, -20, 3], 4) == 8
    
    def test_large_k_with_mixed_values(self):
        assert add_elements([1, 2, 3, 100, 200, 4, 5], 7) == 15
    
    def test_boundary_99_included(self):
        assert add_elements([99, 100], 2) == 99
    
    def test_boundary_negative_99_included(self):
        assert add_elements([-99, -100], 2) == 0
    
    def test_single_element_array_single_digit(self):
        assert add_elements([7], 1) == 7
    
    def test_single_element_array_three_digit(self):
        assert add_elements([123], 1) == 0
    
    def test_all_single_digit_numbers(self):
        assert add_elements([1, 2, 3, 4, 5, 6, 7, 8, 9], 9) == 45
    
    def test_alternating_valid_invalid(self):
        assert add_elements([1, 100, 2, 200, 3, 300], 6) == 6
    
    def test_k_equals_array_length(self):
        assert add_elements([1, 2, 3, 4, 5], 5) == 15
    
    def test_negative_k_behavior(self):
        assert add_elements([1, 2, 3, 4, 5], -1) == 10
    
    def test_float_like_numbers_as_strings(self):
        assert add_elements([1, 2, 3], 3) == 6
    
    def test_large_two_digit_numbers(self):
        assert add_elements([99, 98, 97], 3) == 294
    
    def test_large_three_digit_numbers_excluded(self):
        assert add_elements([999, 998, 997], 3) == 0
    
    @pytest.mark.parametrize("arr,k,expected", [
        ([1, 2, 3], 2, 3),
        ([10, 20, 30], 2, 30),
        ([1, 100, 2], 3, 3),
        ([], 5, 0),
        ([5], 1, 5),
        ([100], 1, 0),
        ([-1, -2, -3], 2, -3),
        ([0, 0, 0], 3, 0),
    ])
    def test_parametrized_cases(self, arr, k, expected):
        assert add_elements(arr, k) == expected