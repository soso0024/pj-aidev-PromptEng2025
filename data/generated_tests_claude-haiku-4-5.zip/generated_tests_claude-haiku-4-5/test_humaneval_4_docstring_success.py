# Test cases for HumanEval/4
# Generated using Claude API

from typing import List


def mean_absolute_deviation(numbers: List[float]) -> float:
    """ For a given list of input numbers, calculate Mean Absolute Deviation
    around the mean of this dataset.
    Mean Absolute Deviation is the average absolute difference between each
    element and a centerpoint (mean in this case):
    MAD = average | x - x_mean |
    >>> mean_absolute_deviation([1.0, 2.0, 3.0, 4.0])
    1.0
    """

    mean = sum(numbers) / len(numbers)
    return sum(abs(x - mean) for x in numbers) / len(numbers)


# Generated test cases:
import pytest
from typing import List


def mean_absolute_deviation(numbers: List[float]) -> float:
    mean = sum(numbers) / len(numbers)
    return sum(abs(x - mean) for x in numbers) / len(numbers)


class TestMeanAbsoluteDeviation:
    
    def test_basic_example_from_docstring(self):
        result = mean_absolute_deviation([1.0, 2.0, 3.0, 4.0])
        assert result == 1.0
    
    def test_single_element(self):
        result = mean_absolute_deviation([5.0])
        assert result == 0.0
    
    def test_two_elements(self):
        result = mean_absolute_deviation([1.0, 3.0])
        assert result == 1.0
    
    def test_identical_elements(self):
        result = mean_absolute_deviation([5.0, 5.0, 5.0, 5.0])
        assert result == 0.0
    
    def test_negative_numbers(self):
        result = mean_absolute_deviation([-2.0, -1.0, 0.0, 1.0, 2.0])
        assert result == 1.2
    
    def test_mixed_positive_negative(self):
        result = mean_absolute_deviation([-5.0, 5.0])
        assert result == 5.0
    
    def test_all_negative_numbers(self):
        result = mean_absolute_deviation([-4.0, -3.0, -2.0, -1.0])
        assert result == 1.0
    
    def test_decimal_numbers(self):
        result = mean_absolute_deviation([1.5, 2.5, 3.5])
        assert result == pytest.approx(2.0 / 3.0)
    
    def test_large_numbers(self):
        result = mean_absolute_deviation([1000.0, 2000.0, 3000.0])
        assert result == pytest.approx(666.666666, rel=1e-5)
    
    def test_very_small_numbers(self):
        result = mean_absolute_deviation([0.001, 0.002, 0.003])
        assert result == pytest.approx(0.000666666, rel=1e-5)
    
    def test_zero_values(self):
        result = mean_absolute_deviation([0.0, 0.0, 0.0])
        assert result == 0.0
    
    def test_with_zero_and_nonzero(self):
        result = mean_absolute_deviation([0.0, 2.0])
        assert result == 1.0
    
    @pytest.mark.parametrize("numbers,expected", [
        ([1.0, 2.0, 3.0, 4.0], 1.0),
        ([10.0], 0.0),
        ([1.0, 1.0, 1.0], 0.0),
        ([-1.0, 1.0], 1.0),
        ([0.0, 4.0], 2.0),
    ])
    def test_parametrized_cases(self, numbers, expected):
        result = mean_absolute_deviation(numbers)
        assert result == pytest.approx(expected)
    
    def test_symmetric_distribution(self):
        result = mean_absolute_deviation([1.0, 2.0, 3.0, 4.0, 5.0])
        assert result == 1.2
    
    def test_skewed_distribution(self):
        result = mean_absolute_deviation([1.0, 1.0, 1.0, 10.0])
        assert result == pytest.approx(3.375)
    
    def test_float_precision(self):
        result = mean_absolute_deviation([1.1, 2.2, 3.3])
        assert isinstance(result, float)
        assert result > 0
    
    def test_large_list(self):
        numbers = [float(i) for i in range(1, 101)]
        result = mean_absolute_deviation(numbers)
        assert result == pytest.approx(25.0)
    
    def test_alternating_values(self):
        result = mean_absolute_deviation([1.0, 10.0, 1.0, 10.0])
        assert result == pytest.approx(4.5)