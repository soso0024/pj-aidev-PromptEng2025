# Test cases for HumanEval/6
# Generated using Claude API

from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """

    def parse_paren_group(s):
        depth = 0
        max_depth = 0
        for c in s:
            if c == '(':
                depth += 1
                max_depth = max(depth, max_depth)
            else:
                depth -= 1

        return max_depth

    return [parse_paren_group(x) for x in paren_string.split(' ') if x]


# Generated test cases:
import pytest
from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    def parse_paren_group(s):
        depth = 0
        max_depth = 0
        for c in s:
            if c == '(':
                depth += 1
                max_depth = max(depth, max_depth)
            else:
                depth -= 1

        return max_depth

    return [parse_paren_group(x) for x in paren_string.split(' ') if x]


class TestParseNestedParens:
    
    def test_example_from_docstring(self):
        result = parse_nested_parens('(()()) ((())) () ((())()())')
        assert result == [2, 3, 1, 3]
    
    def test_single_group_single_level(self):
        result = parse_nested_parens('()')
        assert result == [1]
    
    def test_single_group_two_levels(self):
        result = parse_nested_parens('(())')
        assert result == [2]
    
    def test_single_group_three_levels(self):
        result = parse_nested_parens('((()))')
        assert result == [3]
    
    def test_multiple_groups_single_level(self):
        result = parse_nested_parens('() () ()')
        assert result == [1, 1, 1]
    
    def test_multiple_groups_varying_levels(self):
        result = parse_nested_parens('() (()) ((()))')
        assert result == [1, 2, 3]
    
    def test_empty_string(self):
        result = parse_nested_parens('')
        assert result == []
    
    def test_only_spaces(self):
        result = parse_nested_parens('   ')
        assert result == []
    
    def test_single_empty_group(self):
        result = parse_nested_parens('()')
        assert result == [1]
    
    def test_nested_with_multiple_opens_closes(self):
        result = parse_nested_parens('()()()')
        assert result == [1]
    
    def test_deeply_nested(self):
        result = parse_nested_parens('((((((()))))))')
        assert result == [7]
    
    def test_multiple_groups_with_extra_spaces(self):
        result = parse_nested_parens('()  ()   ()')
        assert result == [1, 1, 1]
    
    def test_complex_nesting_pattern(self):
        result = parse_nested_parens('(()()()) ()()()')
        assert result == [2, 1]
    
    def test_alternating_pattern(self):
        result = parse_nested_parens('()()()()')
        assert result == [1]
    
    def test_pyramid_pattern(self):
        result = parse_nested_parens('(((())))')
        assert result == [4]
    
    def test_mixed_complex_groups(self):
        result = parse_nested_parens('(())(()) ((()))(())')
        assert result == [2, 3]
    
    def test_single_open_close_pair(self):
        result = parse_nested_parens('()')
        assert result == [1]
    
    def test_many_groups(self):
        result = parse_nested_parens('() () () () ()')
        assert result == [1, 1, 1, 1, 1]
    
    def test_increasing_nesting(self):
        result = parse_nested_parens('() (()) ((())) (((())))') 
        assert result == [1, 2, 3, 4]
    
    def test_decreasing_nesting(self):
        result = parse_nested_parens('(((()))) (()) ()')
        assert result == [4, 2, 1]
    
    def test_group_with_balanced_nested_structure(self):
        result = parse_nested_parens('(()(()))')
        assert result == [3]
    
    def test_multiple_peaks_in_group(self):
        result = parse_nested_parens('(())(())')
        assert result == [2]
    
    def test_asymmetric_nesting(self):
        result = parse_nested_parens('((()(())))')
        assert result == [4]
    
    def test_single_space_separated_groups(self):
        result = parse_nested_parens('(()) (())')
        assert result == [2, 2]
    
    def test_very_deep_nesting(self):
        deep_paren = '(' * 10 + ')' * 10
        result = parse_nested_parens(deep_paren)
        assert result == [10]
    
    def test_multiple_very_deep_groups(self):
        group1 = '(' * 5 + ')' * 5
        group2 = '(' * 3 + ')' * 3
        result = parse_nested_parens(f'{group1} {group2}')
        assert result == [5, 3]


@pytest.mark.parametrize("input_str,expected", [
    ('(()()) ((())) () ((())()())', [2, 3, 1, 3]),
    ('()', [1]),
    ('(())', [2]),
    ('((()))', [3]),
    ('() () ()', [1, 1, 1]),
    ('', []),
    ('()()()', [1]),
    ('((((()))))', [5]),
    ('() (()) ((()))', [1, 2, 3]),
    ('(())(())', [2]),
])
def test_parse_nested_parens_parametrized(input_str, expected):
    assert parse_nested_parens(input_str) == expected