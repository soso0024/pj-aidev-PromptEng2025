# Test cases for HumanEval/61
# Generated using Claude API



def correct_bracketing(brackets: str):
    """ brackets is a string of "(" and ")".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """

    depth = 0
    for b in brackets:
        if b == "(":
            depth += 1
        else:
            depth -= 1
        if depth < 0:
            return False
    return depth == 0


# Generated test cases:
import pytest


def correct_bracketing(brackets: str):
    depth = 0
    for b in brackets:
        if b == "(":
            depth += 1
        else:
            depth -= 1
        if depth < 0:
            return False
    return depth == 0


class TestCorrectBracketing:
    
    @pytest.mark.parametrize("brackets,expected", [
        ("", True),
        ("()", True),
        ("(())", True),
        ("()()", True),
        ("((()))", True),
        ("()()()", True),
        ("(()(()))", True),
    ])
    def test_valid_brackets(self, brackets, expected):
        assert correct_bracketing(brackets) == expected
    
    @pytest.mark.parametrize("brackets,expected", [
        ("(", False),
        (")", False),
        ("(()", False),
        ("())", False),
        (")(", False),
        ("))(", False),
        ("(()(", False),
        ("()())", False),
    ])
    def test_invalid_brackets(self, brackets, expected):
        assert correct_bracketing(brackets) == expected
    
    def test_empty_string(self):
        assert correct_bracketing("") == True
    
    def test_single_open_bracket(self):
        assert correct_bracketing("(") == False
    
    def test_single_close_bracket(self):
        assert correct_bracketing(")") == False
    
    def test_multiple_open_brackets(self):
        assert correct_bracketing("(((") == False
    
    def test_multiple_close_brackets(self):
        assert correct_bracketing(")))") == False
    
    def test_close_before_open(self):
        assert correct_bracketing(")(") == False
    
    def test_nested_brackets(self):
        assert correct_bracketing("(((())))") == True
    
    def test_alternating_brackets(self):
        assert correct_bracketing("()()()()") == True
    
    def test_complex_valid_pattern(self):
        assert correct_bracketing("(())(())") == True
    
    def test_complex_invalid_pattern_extra_close(self):
        assert correct_bracketing("(())(()))") == False
    
    def test_complex_invalid_pattern_extra_open(self):
        assert correct_bracketing("((())((())") == False
    
    def test_close_bracket_at_start(self):
        assert correct_bracketing(")()") == False
    
    def test_unbalanced_with_valid_start(self):
        assert correct_bracketing("(()") == False
    
    def test_long_valid_sequence(self):
        assert correct_bracketing("()" * 100) == True
    
    def test_long_invalid_sequence_extra_close(self):
        assert correct_bracketing("()" * 50 + ")") == False
    
    def test_long_invalid_sequence_extra_open(self):
        assert correct_bracketing("(" * 50 + ")" * 49) == False


if __name__ == "__main__":
    pytest.main([__file__, "-v"])