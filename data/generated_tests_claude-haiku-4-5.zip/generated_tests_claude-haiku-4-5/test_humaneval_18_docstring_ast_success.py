# Test cases for HumanEval/18
# Generated using Claude API



def how_many_times(string: str, substring: str) -> int:
    """ Find how many times a given substring can be found in the original string. Count overlaping cases.
    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """

    times = 0

    for i in range(len(string) - len(substring) + 1):
        if string[i:i+len(substring)] == substring:
            times += 1

    return times


# Generated test cases:
import pytest


def how_many_times(string: str, substring: str) -> int:
    times = 0
    for i in range(len(string) - len(substring) + 1):
        if string[i:i+len(substring)] == substring:
            times += 1
    return times


class TestHowManyTimes:
    
    def test_empty_string_with_substring(self):
        assert how_many_times('', 'a') == 0
    
    def test_single_character_match(self):
        assert how_many_times('aaa', 'a') == 3
    
    def test_overlapping_substrings(self):
        assert how_many_times('aaaa', 'aa') == 3
    
    def test_no_match(self):
        assert how_many_times('hello', 'x') == 0
    
    def test_single_match(self):
        assert how_many_times('hello', 'hello') == 1
    
    def test_substring_longer_than_string(self):
        assert how_many_times('hi', 'hello') == 0
    
    def test_empty_substring(self):
        assert how_many_times('hello', '') == 6
    
    def test_both_empty(self):
        assert how_many_times('', '') == 1
    
    def test_multiple_non_overlapping_matches(self):
        assert how_many_times('abcabc', 'abc') == 2
    
    def test_multiple_overlapping_matches(self):
        assert how_many_times('aaaa', 'aaa') == 2
    
    def test_substring_at_start(self):
        assert how_many_times('hello world', 'hello') == 1
    
    def test_substring_at_end(self):
        assert how_many_times('hello world', 'world') == 1
    
    def test_substring_in_middle(self):
        assert how_many_times('hello world', 'lo wo') == 1
    
    def test_repeated_pattern(self):
        assert how_many_times('ababab', 'ab') == 3
    
    def test_repeated_pattern_overlapping(self):
        assert how_many_times('aaaaaa', 'aaa') == 4
    
    def test_case_sensitive(self):
        assert how_many_times('Hello', 'hello') == 0
    
    def test_case_sensitive_match(self):
        assert how_many_times('Hello', 'Hello') == 1
    
    def test_special_characters(self):
        assert how_many_times('!!!', '!') == 3
    
    def test_special_characters_substring(self):
        assert how_many_times('a!b!c!', '!') == 3
    
    def test_spaces_in_string(self):
        assert how_many_times('a b a b a', 'a b') == 2
    
    def test_single_character_string_and_substring(self):
        assert how_many_times('a', 'a') == 1
    
    def test_single_character_no_match(self):
        assert how_many_times('a', 'b') == 0
    
    def test_long_string_short_substring(self):
        assert how_many_times('abcdefghijklmnopqrstuvwxyz', 'a') == 1
    
    def test_long_string_multiple_matches(self):
        assert how_many_times('abcabcabcabc', 'abc') == 4
    
    def test_numbers_as_string(self):
        assert how_many_times('123123123', '123') == 3
    
    def test_numbers_overlapping(self):
        assert how_many_times('111', '11') == 2
    
    def test_mixed_alphanumeric(self):
        assert how_many_times('a1b2a1b2', 'a1') == 2
    
    def test_newline_characters(self):
        assert how_many_times('a\na\na', 'a\n') == 2
    
    def test_tab_characters(self):
        assert how_many_times('a\ta\ta', 'a\t') == 2


@pytest.mark.parametrize("string,substring,expected", [
    ('', 'a', 0),
    ('aaa', 'a', 3),
    ('aaaa', 'aa', 3),
    ('hello', 'x', 0),
    ('hello', 'hello', 1),
    ('hi', 'hello', 0),
    ('hello', '', 6),
    ('', '', 1),
    ('abcabc', 'abc', 2),
    ('aaaa', 'aaa', 2),
    ('hello world', 'hello', 1),
    ('hello world', 'world', 1),
    ('hello world', 'lo wo', 1),
    ('ababab', 'ab', 3),
    ('aaaaaa', 'aaa', 4),
    ('Hello', 'hello', 0),
    ('Hello', 'Hello', 1),
    ('!!!', '!', 3),
    ('a!b!c!', '!', 3),
    ('a b a b a', 'a b', 2),
    ('a', 'a', 1),
    ('a', 'b', 0),
    ('abcdefghijklmnopqrstuvwxyz', 'a', 1),
    ('abcabcabcabc', 'abc', 4),
    ('123123123', '123', 3),
    ('111', '11', 2),
    ('a1b2a1b2', 'a1', 2),
])
def test_how_many_times_parametrized(string, substring, expected):
    assert how_many_times(string, substring) == expected
