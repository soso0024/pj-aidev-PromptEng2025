# Test cases for HumanEval/13
# Generated using Claude API



def greatest_common_divisor(a: int, b: int) -> int:
    """ Return a greatest common divisor of two integers a and b
    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """

    while b:
        a, b = b, a % b
    return a


# Generated test cases:
import pytest


def greatest_common_divisor(a: int, b: int) -> int:
    """ Return a greatest common divisor of two integers a and b
    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """
    while b:
        a, b = b, a % b
    return a


class TestGreatestCommonDivisor:
    
    @pytest.mark.parametrize("a,b,expected", [
        (3, 5, 1),
        (25, 15, 5),
        (12, 8, 4),
        (48, 18, 6),
        (100, 50, 50),
        (17, 19, 1),
        (0, 5, 5),
        (5, 0, 5),
        (0, 0, 0),
        (1, 1, 1),
        (1, 100, 1),
        (100, 1, 1),
        (2, 4, 2),
        (4, 2, 2),
        (21, 14, 7),
        (1071, 462, 21),
        (270, 192, 6),
        (1000, 625, 125),
        (13, 13, 13),
        (7, 7, 7),
    ])
    def test_gcd_various_cases(self, a, b, expected):
        assert greatest_common_divisor(a, b) == expected
    
    def test_gcd_commutative(self):
        assert greatest_common_divisor(25, 15) == greatest_common_divisor(15, 25)
    
    def test_gcd_with_zero_first(self):
        assert greatest_common_divisor(0, 10) == 10
    
    def test_gcd_with_zero_second(self):
        assert greatest_common_divisor(10, 0) == 10
    
    def test_gcd_both_zero(self):
        assert greatest_common_divisor(0, 0) == 0
    
    def test_gcd_same_numbers(self):
        assert greatest_common_divisor(42, 42) == 42
    
    def test_gcd_coprime_numbers(self):
        assert greatest_common_divisor(7, 11) == 1
    
    def test_gcd_one_is_divisor(self):
        assert greatest_common_divisor(20, 5) == 5
    
    def test_gcd_large_numbers(self):
        assert greatest_common_divisor(123456, 789012) == 12
    
    def test_gcd_consecutive_numbers(self):
        assert greatest_common_divisor(10, 11) == 1
    
    def test_gcd_powers_of_two(self):
        assert greatest_common_divisor(16, 32) == 16
    
    def test_gcd_negative_first(self):
        assert greatest_common_divisor(-25, 15) == 5
    
    def test_gcd_negative_second(self):
        assert greatest_common_divisor(25, -15) == -5
    
    def test_gcd_both_negative(self):
        assert greatest_common_divisor(-25, -15) == -5
    
    def test_gcd_negative_zero(self):
        assert greatest_common_divisor(-5, 0) == -5
    
    def test_gcd_one_and_any_number(self):
        assert greatest_common_divisor(1, 999) == 1
    
    def test_gcd_fibonacci_numbers(self):
        assert greatest_common_divisor(89, 55) == 1
    
    def test_gcd_multiples(self):
        assert greatest_common_divisor(60, 90) == 30