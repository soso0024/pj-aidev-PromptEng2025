# Test cases for HumanEval/90
# Generated using Claude API


def next_smallest(lst):
    """
    You are given a list of integers.
    Write a function next_smallest() that returns the 2nd smallest element of the list.
    Return None if there is no such element.
    
    next_smallest([1, 2, 3, 4, 5]) == 2
    next_smallest([5, 1, 4, 3, 2]) == 2
    next_smallest([]) == None
    next_smallest([1, 1]) == None
    """

    lst = sorted(set(lst))
    return None if len(lst) < 2 else lst[1]


# Generated test cases:
import pytest


def next_smallest(lst):
    lst = sorted(set(lst))
    return None if len(lst) < 2 else lst[1]


class TestNextSmallest:
    
    def test_empty_list(self):
        assert next_smallest([]) is None
    
    def test_single_element(self):
        assert next_smallest([1]) is None
    
    def test_two_elements(self):
        assert next_smallest([1, 2]) == 2
    
    def test_two_elements_reversed(self):
        assert next_smallest([2, 1]) == 2
    
    def test_multiple_elements(self):
        assert next_smallest([1, 2, 3, 4, 5]) == 2
    
    def test_multiple_elements_unordered(self):
        assert next_smallest([5, 1, 3, 2, 4]) == 2
    
    def test_duplicates(self):
        assert next_smallest([1, 1, 1, 2, 2, 3]) == 2
    
    def test_all_duplicates(self):
        assert next_smallest([5, 5, 5, 5]) is None
    
    def test_negative_numbers(self):
        assert next_smallest([-5, -1, 0, 3]) == -1
    
    def test_negative_and_positive(self):
        assert next_smallest([-10, -5, 0, 5, 10]) == -5
    
    def test_large_numbers(self):
        assert next_smallest([1000000, 999999, 1000001]) == 1000000
    
    def test_floats(self):
        assert next_smallest([1.5, 2.5, 3.5]) == 2.5
    
    def test_mixed_int_float(self):
        assert next_smallest([1, 2.5, 3]) == 2.5
    
    def test_unsorted_list(self):
        assert next_smallest([10, 5, 20, 15]) == 10
    
    def test_duplicates_with_multiple_elements(self):
        assert next_smallest([3, 1, 3, 2, 1]) == 2
    
    def test_single_duplicate_pair(self):
        assert next_smallest([1, 1]) is None
    
    def test_negative_duplicates(self):
        assert next_smallest([-1, -1, -2, -3]) == -2
    
    def test_zero_in_list(self):
        assert next_smallest([0, 1, 2]) == 1
    
    def test_zero_and_negative(self):
        assert next_smallest([-1, 0, 1]) == 0
    
    def test_very_small_floats(self):
        assert next_smallest([0.001, 0.002, 0.003]) == 0.002
    
    @pytest.mark.parametrize("input_list,expected", [
        ([1, 2], 2),
        ([2, 1], 2),
        ([5, 3, 1, 4, 2], 2),
        ([10, 10, 20], 20),
        ([-5, -10, 0], -5),
        ([100], None),
        ([], None),
    ])
    def test_parametrized_cases(self, input_list, expected):
        assert next_smallest(input_list) == expected
