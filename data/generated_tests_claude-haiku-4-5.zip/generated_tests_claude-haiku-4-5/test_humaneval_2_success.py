# Test cases for HumanEval/2
# Generated using Claude API



def truncate_number(number: float) -> float:
    """ Given a positive floating point number, it can be decomposed into
    and integer part (largest integer smaller than given number) and decimals
    (leftover part always smaller than 1).

    Return the decimal part of the number.
    >>> truncate_number(3.5)
    0.5
    """

    return number % 1.0


# Generated test cases:
import pytest


class TestTruncateNumber:
    
    def test_positive_integer(self):
        assert truncate_number(5) == 0.0
    
    def test_positive_float_with_decimal(self):
        assert truncate_number(5.7) == pytest.approx(0.7)
    
    def test_positive_float_small_decimal(self):
        assert truncate_number(3.14159) == pytest.approx(0.14159)
    
    def test_negative_integer(self):
        result = truncate_number(-5)
        assert result == 0.0
    
    def test_negative_float_with_decimal(self):
        result = truncate_number(-5.7)
        assert result == pytest.approx(0.3)
    
    def test_negative_float_small_decimal(self):
        result = truncate_number(-3.14159)
        assert result == pytest.approx(0.85841, rel=1e-4)
    
    def test_zero(self):
        assert truncate_number(0) == 0.0
    
    def test_zero_float(self):
        assert truncate_number(0.0) == 0.0
    
    def test_one(self):
        assert truncate_number(1.0) == 0.0
    
    def test_negative_one(self):
        assert truncate_number(-1.0) == 0.0
    
    def test_very_small_positive_decimal(self):
        assert truncate_number(0.0001) == pytest.approx(0.0001)
    
    def test_very_small_negative_decimal(self):
        result = truncate_number(-0.0001)
        assert result == pytest.approx(0.9999)
    
    def test_decimal_close_to_one(self):
        assert truncate_number(0.9999) == pytest.approx(0.9999)
    
    def test_large_positive_number(self):
        assert truncate_number(1000000.5) == pytest.approx(0.5)
    
    def test_large_negative_number(self):
        result = truncate_number(-1000000.5)
        assert result == pytest.approx(0.5)
    
    def test_half(self):
        assert truncate_number(0.5) == 0.5
    
    def test_negative_half(self):
        result = truncate_number(-0.5)
        assert result == 0.5
    
    def test_quarter(self):
        assert truncate_number(0.25) == 0.25
    
    def test_negative_quarter(self):
        result = truncate_number(-0.25)
        assert result == pytest.approx(0.75)
    
    def test_three_quarters(self):
        assert truncate_number(0.75) == 0.75
    
    def test_negative_three_quarters(self):
        result = truncate_number(-0.75)
        assert result == pytest.approx(0.25)


@pytest.mark.parametrize("input_val,expected", [
    (5, 0.0),
    (5.7, 0.7),
    (0, 0.0),
    (1.0, 0.0),
    (0.5, 0.5),
    (0.123, 0.123),
    (10.999, 0.999),
])
def test_truncate_number_positive_cases(input_val, expected):
    assert truncate_number(input_val) == pytest.approx(expected)


@pytest.mark.parametrize("input_val,expected", [
    (-5, 0.0),
    (-5.7, 0.3),
    (-1.0, 0.0),
    (-0.5, 0.5),
    (-0.123, 0.877),
    (-10.999, 0.001),
])
def test_truncate_number_negative_cases(input_val, expected):
    assert truncate_number(input_val) == pytest.approx(expected, rel=1e-4)


def test_truncate_number_returns_float():
    result = truncate_number(5)
    assert isinstance(result, float)


def test_truncate_number_result_in_range():
    for num in [0, 0.5, 1.0, 5.7, -3.2, 100.999]:
        result = truncate_number(num)
        assert 0.0 <= result < 1.0 or result == 0.0


def truncate_number(number: float) -> float:
    return number % 1.0