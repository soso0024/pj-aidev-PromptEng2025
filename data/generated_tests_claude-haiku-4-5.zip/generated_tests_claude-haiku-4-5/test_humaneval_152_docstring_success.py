# Test cases for HumanEval/152
# Generated using Claude API


def compare(game,guess):
    """I think we all remember that feeling when the result of some long-awaited
    event is finally known. The feelings and thoughts you have at that moment are
    definitely worth noting down and comparing.
    Your task is to determine if a person correctly guessed the results of a number of matches.
    You are given two arrays of scores and guesses of equal length, where each index shows a match. 
    Return an array of the same length denoting how far off each guess was. If they have guessed correctly,
    the value is 0, and if not, the value is the absolute difference between the guess and the score.
    
    
    example:

    compare([1,2,3,4,5,1],[1,2,3,4,2,-2]) -> [0,0,0,0,3,3]
    compare([0,5,0,0,0,4],[4,1,1,0,0,-2]) -> [4,4,1,0,0,6]
    """

    return [abs(x-y) for x,y in zip(game,guess)]


# Generated test cases:
import pytest


def compare(game, guess):
    return [abs(x - y) for x, y in zip(game, guess)]


class TestCompare:
    def test_example_1(self):
        result = compare([1, 2, 3, 4, 5, 1], [1, 2, 3, 4, 2, -2])
        assert result == [0, 0, 0, 0, 3, 3]

    def test_example_2(self):
        result = compare([0, 5, 0, 0, 0, 4], [4, 1, 1, 0, 0, -2])
        assert result == [4, 4, 1, 0, 0, 6]

    def test_empty_arrays(self):
        result = compare([], [])
        assert result == []

    def test_single_element_correct(self):
        result = compare([5], [5])
        assert result == [0]

    def test_single_element_incorrect(self):
        result = compare([5], [3])
        assert result == [2]

    def test_all_correct(self):
        result = compare([1, 2, 3, 4, 5], [1, 2, 3, 4, 5])
        assert result == [0, 0, 0, 0, 0]

    def test_all_incorrect(self):
        result = compare([1, 2, 3], [4, 5, 6])
        assert result == [3, 3, 3]

    def test_negative_numbers(self):
        result = compare([-1, -2, -3], [-1, -2, -3])
        assert result == [0, 0, 0]

    def test_negative_numbers_incorrect(self):
        result = compare([-5, -10, 0], [-3, -15, 5])
        assert result == [2, 5, 5]

    def test_mixed_positive_negative(self):
        result = compare([10, -5, 0, 3], [5, -5, -2, 3])
        assert result == [5, 0, 2, 0]

    def test_large_differences(self):
        result = compare([100, 200], [0, 50])
        assert result == [100, 150]

    def test_zero_values(self):
        result = compare([0, 0, 0], [0, 0, 0])
        assert result == [0, 0, 0]

    def test_zero_vs_nonzero(self):
        result = compare([0, 0, 0], [5, -5, 10])
        assert result == [5, 5, 10]

    @pytest.mark.parametrize("game,guess,expected", [
        ([1, 2, 3], [1, 2, 3], [0, 0, 0]),
        ([5, 10, 15], [3, 8, 12], [2, 2, 3]),
        ([-1, -2, -3], [1, 2, 3], [2, 4, 6]),
        ([0], [0], [0]),
        ([100], [50], [50]),
    ])
    def test_parametrized_cases(self, game, guess, expected):
        result = compare(game, guess)
        assert result == expected

    def test_long_arrays(self):
        game = list(range(100))
        guess = list(range(100))
        result = compare(game, guess)
        assert result == [0] * 100

    def test_long_arrays_with_differences(self):
        game = list(range(50))
        guess = list(range(1, 51))
        result = compare(game, guess)
        assert result == [1] * 50

    def test_return_type_is_list(self):
        result = compare([1, 2], [1, 2])
        assert isinstance(result, list)

    def test_return_length_matches_input(self):
        game = [1, 2, 3, 4, 5]
        guess = [1, 1, 1, 1, 1]
        result = compare(game, guess)
        assert len(result) == len(game)

    def test_all_elements_are_non_negative(self):
        result = compare([1, 2, 3], [5, 1, 0])
        assert all(x >= 0 for x in result)
