# Test cases for HumanEval/104
# Generated using Claude API


def unique_digits(x):
    """Given a list of positive integers x. return a sorted list of all 
    elements that hasn't any even digit.

    Note: Returned list should be sorted in increasing order.
    
    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """

    odd_digit_elements = []
    for i in x:
        if all (int(c) % 2 == 1 for c in str(i)):
            odd_digit_elements.append(i)
    return sorted(odd_digit_elements)


# Generated test cases:
import pytest


def unique_digits(x):
    odd_digit_elements = []
    for i in x:
        if all (int(c) % 2 == 1 for c in str(i)):
            odd_digit_elements.append(i)
    return sorted(odd_digit_elements)


class TestUniqueDigits:
    
    def test_example_case_1(self):
        assert unique_digits([15, 33, 1422, 1]) == [1, 15, 33]
    
    def test_example_case_2(self):
        assert unique_digits([152, 323, 1422, 10]) == []
    
    def test_empty_list(self):
        assert unique_digits([]) == []
    
    def test_single_odd_digit(self):
        assert unique_digits([1]) == [1]
    
    def test_single_even_digit(self):
        assert unique_digits([2]) == []
    
    def test_all_odd_digits(self):
        assert unique_digits([1, 3, 5, 7, 9]) == [1, 3, 5, 7, 9]
    
    def test_all_even_digits(self):
        assert unique_digits([2, 4, 6, 8]) == []
    
    def test_mixed_single_digits(self):
        assert unique_digits([1, 2, 3, 4, 5]) == [1, 3, 5]
    
    def test_multi_digit_all_odd(self):
        assert unique_digits([11, 33, 55, 77, 99]) == [11, 33, 55, 77, 99]
    
    def test_multi_digit_all_even(self):
        assert unique_digits([22, 44, 66, 88]) == []
    
    def test_multi_digit_mixed(self):
        assert unique_digits([11, 12, 13, 14, 15]) == [11, 13, 15]
    
    def test_large_numbers_odd_digits(self):
        assert unique_digits([135, 579, 1357]) == [135, 579, 1357]
    
    def test_large_numbers_with_even(self):
        assert unique_digits([135, 246, 579, 1357]) == [135, 579, 1357]
    
    def test_unsorted_input(self):
        assert unique_digits([99, 11, 55, 33]) == [11, 33, 55, 99]
    
    def test_duplicates_in_input(self):
        assert unique_digits([11, 11, 33, 33]) == [11, 11, 33, 33]
    
    def test_single_digit_nine(self):
        assert unique_digits([9]) == [9]
    
    def test_single_digit_zero(self):
        assert unique_digits([0]) == []
    
    def test_number_with_zero(self):
        assert unique_digits([101, 103, 105]) == []
    
    def test_number_with_one_even_digit(self):
        assert unique_digits([111, 112, 113]) == [111, 113]
    
    def test_large_list(self):
        result = unique_digits([1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 2, 4, 6, 8])
        assert result == [1, 3, 5, 7, 9, 11, 13, 15, 17, 19]
    
    def test_very_large_number_all_odd(self):
        assert unique_digits([13579]) == [13579]
    
    def test_very_large_number_with_even(self):
        assert unique_digits([135792]) == []
    
    @pytest.mark.parametrize("input_list,expected", [
        ([1], [1]),
        ([2], []),
        ([11, 22], [11]),
        ([111, 222, 333], [111, 333]),
        ([1, 3, 5, 7, 9, 11, 13, 15, 17, 19], [1, 3, 5, 7, 9, 11, 13, 15, 17, 19]),
    ])
    def test_parametrized_cases(self, input_list, expected):
        assert unique_digits(input_list) == expected