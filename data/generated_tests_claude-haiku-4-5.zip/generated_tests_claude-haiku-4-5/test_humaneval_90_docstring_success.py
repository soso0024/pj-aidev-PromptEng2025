# Test cases for HumanEval/90
# Generated using Claude API


def next_smallest(lst):
    """
    You are given a list of integers.
    Write a function next_smallest() that returns the 2nd smallest element of the list.
    Return None if there is no such element.
    
    next_smallest([1, 2, 3, 4, 5]) == 2
    next_smallest([5, 1, 4, 3, 2]) == 2
    next_smallest([]) == None
    next_smallest([1, 1]) == None
    """

    lst = sorted(set(lst))
    return None if len(lst) < 2 else lst[1]


# Generated test cases:
import pytest


def next_smallest(lst):
    lst = sorted(set(lst))
    return None if len(lst) < 2 else lst[1]


@pytest.mark.parametrize("input_list,expected", [
    ([1, 2, 3, 4, 5], 2),
    ([5, 1, 4, 3, 2], 2),
    ([10, 20, 30], 20),
    ([3, 1, 2], 2),
    ([-5, -1, -3], -3),
    ([-10, 0, 10], 0),
    ([100, 1, 50], 50),
    ([1, 1, 2, 3], 2),
    ([5, 5, 5, 1], 5),
    ([2, 1, 1, 1], 2),
])
def test_next_smallest_normal_cases(input_list, expected):
    assert next_smallest(input_list) == expected


@pytest.mark.parametrize("input_list,expected", [
    ([], None),
    ([1], None),
    ([1, 1], None),
    ([5, 5, 5], None),
    ([1, 1, 1, 1], None),
])
def test_next_smallest_edge_cases(input_list, expected):
    assert next_smallest(input_list) == expected


@pytest.mark.parametrize("input_list,expected", [
    ([2, 2], None),
    ([10, 10, 10], None),
    ([0, 0], None),
    ([-1, -1], None),
])
def test_next_smallest_duplicates_only(input_list, expected):
    assert next_smallest(input_list) == expected


@pytest.mark.parametrize("input_list,expected", [
    ([1, 2], 2),
    ([2, 1], 2),
    ([0, 1], 1),
    ([-1, 0], 0),
])
def test_next_smallest_two_elements(input_list, expected):
    assert next_smallest(input_list) == expected


@pytest.mark.parametrize("input_list,expected", [
    ([-100, -50, -1, 0, 1, 50, 100], -50),
    ([-5, -4, -3, -2, -1], -4),
    ([0, 1, 2, 3, 4], 1),
])
def test_next_smallest_mixed_ranges(input_list, expected):
    assert next_smallest(input_list) == expected


@pytest.mark.parametrize("input_list,expected", [
    ([1, 1, 1, 2, 2, 2, 3, 3, 3], 2),
    ([5, 5, 1, 1, 3, 3], 3),
    ([10, 10, 10, 20, 20, 20], 20),
])
def test_next_smallest_multiple_duplicates(input_list, expected):
    assert next_smallest(input_list) == expected


def test_next_smallest_large_list():
    large_list = list(range(1000, 0, -1))
    assert next_smallest(large_list) == 2


def test_next_smallest_unsorted_list():
    unsorted = [50, 10, 30, 20, 40]
    assert next_smallest(unsorted) == 20


def test_next_smallest_negative_numbers():
    assert next_smallest([-5, -10, -1]) == -5


def test_next_smallest_single_duplicate_pair():
    assert next_smallest([1, 1, 2]) == 2