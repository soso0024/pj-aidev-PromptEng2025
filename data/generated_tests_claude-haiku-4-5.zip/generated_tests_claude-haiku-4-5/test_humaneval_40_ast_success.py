# Test cases for HumanEval/40
# Generated using Claude API



def triples_sum_to_zero(l: list):
    """
    triples_sum_to_zero takes a list of integers as an input.
    it returns True if there are three distinct elements in the list that
    sum to zero, and False otherwise.

    >>> triples_sum_to_zero([1, 3, 5, 0])
    False
    >>> triples_sum_to_zero([1, 3, -2, 1])
    True
    >>> triples_sum_to_zero([1, 2, 3, 7])
    False
    >>> triples_sum_to_zero([2, 4, -5, 3, 9, 7])
    True
    >>> triples_sum_to_zero([1])
    False
    """

    for i in range(len(l)):
        for j in range(i + 1, len(l)):
            for k in range(j + 1, len(l)):
                if l[i] + l[j] + l[k] == 0:
                    return True
    return False


# Generated test cases:
import pytest


class TestTriplessSumToZero:
    
    def test_empty_list(self):
        from test_humaneval_40_ast import triples_sum_to_zero
        assert triples_sum_to_zero([]) == False
    
    def test_single_element(self):
        assert triples_sum_to_zero([1]) == False
    
    def test_two_elements(self):
        assert triples_sum_to_zero([1, 2]) == False
    
    def test_three_elements_sum_to_zero(self):
        assert triples_sum_to_zero([1, -1, 0]) == True
    
    def test_three_elements_no_sum_to_zero(self):
        assert triples_sum_to_zero([1, 2, 3]) == False
    
    def test_three_negative_elements(self):
        assert triples_sum_to_zero([-1, -2, -3]) == False
    
    def test_three_negative_elements_sum_to_zero(self):
        assert triples_sum_to_zero([-1, -2, 3]) == True
    
    def test_multiple_triples_first_sums_to_zero(self):
        assert triples_sum_to_zero([1, -1, 0, 5, 10]) == True
    
    def test_multiple_triples_middle_sums_to_zero(self):
        assert triples_sum_to_zero([5, 1, -1, 0, 10]) == True
    
    def test_multiple_triples_last_sums_to_zero(self):
        assert triples_sum_to_zero([5, 10, 1, -1, 0]) == True
    
    def test_no_triple_sums_to_zero(self):
        assert triples_sum_to_zero([1, 2, 3, 4, 5]) == False
    
    def test_all_zeros(self):
        assert triples_sum_to_zero([0, 0, 0]) == True
    
    def test_two_zeros_and_positive(self):
        assert triples_sum_to_zero([0, 0, 1]) == False
    
    def test_large_positive_and_negative(self):
        assert triples_sum_to_zero([100, -50, -50]) == True
    
    def test_large_list_no_triple(self):
        assert triples_sum_to_zero([1, 2, 3, 4, 5, 6, 7, 8, 9]) == False
    
    def test_large_list_with_triple(self):
        assert triples_sum_to_zero([1, 2, 3, 4, 5, -3, -2, -1]) == True
    
    def test_negative_zero_positive(self):
        assert triples_sum_to_zero([-5, 0, 5]) == True
    
    def test_duplicate_elements_sum_to_zero(self):
        assert triples_sum_to_zero([1, 1, -2]) == True
    
    def test_duplicate_elements_no_sum(self):
        assert triples_sum_to_zero([1, 1, 1]) == False
    
    def test_mixed_duplicates(self):
        assert triples_sum_to_zero([2, 2, -4]) == True
    
    def test_four_elements_with_valid_triple(self):
        assert triples_sum_to_zero([1, 2, -3, 4]) == True
    
    def test_four_elements_no_valid_triple(self):
        assert triples_sum_to_zero([1, 2, 3, 4]) == False
    
    def test_negative_numbers_only(self):
        assert triples_sum_to_zero([-1, -2, -3, -4]) == False
    
    def test_single_zero_with_others(self):
        assert triples_sum_to_zero([0, 1, 2]) == False
    
    def test_fractional_like_integers(self):
        assert triples_sum_to_zero([1, 2, -3]) == True
    
    def test_very_large_numbers(self):
        assert triples_sum_to_zero([1000000, -500000, -500000]) == True
    
    def test_very_small_numbers(self):
        assert triples_sum_to_zero([-1000000, 500000, 500000]) == True


@pytest.mark.parametrize("input_list,expected", [
    ([], False),
    ([1], False),
    ([1, 2], False),
    ([1, -1, 0], True),
    ([1, 2, 3], False),
    ([-1, -2, -3], False),
    ([-1, -2, 3], True),
    ([1, -1, 0, 5, 10], True),
    ([5, 1, -1, 0, 10], True),
    ([5, 10, 1, -1, 0], True),
    ([1, 2, 3, 4, 5], False),
    ([0, 0, 0], True),
    ([0, 0, 1], False),
    ([100, -50, -50], True),
    ([1, 2, 3, 4, 5, 6, 7, 8, 9], False),
    ([1, 2, 3, 4, 5, -3, -2, -1], True),
    ([-5, 0, 5], True),
    ([1, 1, -2], True),
    ([1, 1, 1], False),
    ([2, 2, -4], True),
    ([1, 2, -3, 4], True),
    ([1, 2, 3, 4], False),
    ([-1, -2, -3, -4], False),
    ([0, 1, 2], False),
    ([1, 2, -3], True),
])
def test_triples_sum_to_zero_parametrized(input_list, expected):
    assert triples_sum_to_zero(input_list) == expected