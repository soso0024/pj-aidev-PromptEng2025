# Test cases for HumanEval/104
# Generated using Claude API


def unique_digits(x):
    """Given a list of positive integers x. return a sorted list of all 
    elements that hasn't any even digit.

    Note: Returned list should be sorted in increasing order.
    
    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """

    odd_digit_elements = []
    for i in x:
        if all (int(c) % 2 == 1 for c in str(i)):
            odd_digit_elements.append(i)
    return sorted(odd_digit_elements)


# Generated test cases:
import pytest


class TestUniqueDigits:
    
    def test_empty_list(self):
        from test_humaneval_104_ast import unique_digits
        assert unique_digits([]) == []
    
    def test_single_odd_digit_number(self):
        assert unique_digits([1]) == [1]
    
    def test_single_even_digit_number(self):
        assert unique_digits([2]) == []
    
    def test_all_odd_digit_numbers(self):
        assert unique_digits([1, 3, 5, 7, 9]) == [1, 3, 5, 7, 9]
    
    def test_all_even_digit_numbers(self):
        assert unique_digits([2, 4, 6, 8]) == []
    
    def test_mixed_odd_and_even_digit_numbers(self):
        assert unique_digits([1, 2, 3, 4, 5]) == [1, 3, 5]
    
    def test_multi_digit_all_odd(self):
        assert unique_digits([135, 579, 111]) == [111, 135, 579]
    
    def test_multi_digit_with_even(self):
        assert unique_digits([135, 246, 579]) == [135, 579]
    
    def test_multi_digit_all_even(self):
        assert unique_digits([246, 468, 200]) == []
    
    def test_sorting_order(self):
        assert unique_digits([9, 1, 5, 3, 7]) == [1, 3, 5, 7, 9]
    
    def test_zero(self):
        assert unique_digits([0]) == []
    
    def test_zero_with_others(self):
        assert unique_digits([0, 1, 3, 5]) == [1, 3, 5]
    
    def test_large_odd_digit_number(self):
        assert unique_digits([13579]) == [13579]
    
    def test_large_even_digit_number(self):
        assert unique_digits([24680]) == []
    
    def test_large_mixed_digit_number(self):
        assert unique_digits([12345]) == []
    
    def test_duplicate_numbers(self):
        assert unique_digits([1, 1, 3, 3, 5, 5]) == [1, 1, 3, 3, 5, 5]
    
    def test_duplicate_odd_digit_numbers(self):
        assert unique_digits([135, 135, 579, 579]) == [135, 135, 579, 579]
    
    def test_single_digit_one(self):
        assert unique_digits([1]) == [1]
    
    def test_single_digit_nine(self):
        assert unique_digits([9]) == [9]
    
    def test_single_digit_three(self):
        assert unique_digits([3]) == [3]
    
    def test_single_digit_five(self):
        assert unique_digits([5]) == [5]
    
    def test_single_digit_seven(self):
        assert unique_digits([7]) == [7]
    
    def test_number_with_zero_digit(self):
        assert unique_digits([101, 103, 105]) == []
    
    def test_all_ones(self):
        assert unique_digits([1, 11, 111, 1111]) == [1, 11, 111, 1111]
    
    def test_all_threes(self):
        assert unique_digits([3, 33, 333]) == [3, 33, 333]
    
    def test_mixed_single_and_multi_digit(self):
        assert unique_digits([1, 135, 3, 579, 5]) == [1, 3, 5, 135, 579]
    
    def test_large_list_all_odd(self):
        result = unique_digits([1, 3, 5, 7, 9, 11, 13, 15, 17, 19])
        assert result == [1, 3, 5, 7, 9, 11, 13, 15, 17, 19]
    
    def test_large_list_mixed(self):
        result = unique_digits([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        assert result == [1, 3, 5, 7, 9]
    
    def test_number_nine_nine_nine(self):
        assert unique_digits([999]) == [999]
    
    def test_number_one_one_one(self):
        assert unique_digits([111]) == [111]
    
    def test_number_five_five_five(self):
        assert unique_digits([555]) == [555]


@pytest.mark.parametrize("input_list,expected", [
    ([], []),
    ([1], [1]),
    ([2], []),
    ([1, 3, 5, 7, 9], [1, 3, 5, 7, 9]),
    ([2, 4, 6, 8], []),
    ([1, 2, 3, 4, 5], [1, 3, 5]),
    ([135, 579, 111], [111, 135, 579]),
    ([9, 1, 5, 3, 7], [1, 3, 5, 7, 9]),
    ([0], []),
    ([13579], [13579]),
    ([1, 1, 3, 3, 5, 5], [1, 1, 3, 3, 5, 5]),
])
def test_unique_digits_parametrized(input_list, expected):
    assert unique_digits(input_list) == expected