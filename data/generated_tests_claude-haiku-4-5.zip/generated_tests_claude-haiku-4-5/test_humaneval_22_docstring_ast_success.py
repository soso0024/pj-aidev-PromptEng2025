# Test cases for HumanEval/22
# Generated using Claude API

from typing import List, Any


def filter_integers(values: List[Any]) -> List[int]:
    """ Filter given list of any python values only for integers
    >>> filter_integers(['a', 3.14, 5])
    [5]
    >>> filter_integers([1, 2, 3, 'abc', {}, []])
    [1, 2, 3]
    """

    return [x for x in values if isinstance(x, int)]


# Generated test cases:
import pytest
from typing import List, Any


def filter_integers(values: List[Any]) -> List[int]:
    return [x for x in values if isinstance(x, int)]


class TestFilterIntegers:
    def test_empty_list(self):
        assert filter_integers([]) == []

    def test_only_integers(self):
        assert filter_integers([1, 2, 3]) == [1, 2, 3]

    def test_only_non_integers(self):
        assert filter_integers(['a', 'b', 'c']) == []

    def test_mixed_types_with_integers(self):
        assert filter_integers([1, 2, 3, 'abc', {}, []]) == [1, 2, 3]

    def test_mixed_types_with_floats(self):
        assert filter_integers(['a', 3.14, 5]) == [5]

    def test_negative_integers(self):
        assert filter_integers([-1, -2, -3]) == [-1, -2, -3]

    def test_zero(self):
        assert filter_integers([0, 1, 2]) == [0, 1, 2]

    def test_mixed_positive_negative_zero(self):
        assert filter_integers([-5, 0, 5, 'x', 3.14]) == [-5, 0, 5]

    def test_floats_not_included(self):
        assert filter_integers([1.0, 2.5, 3]) == [3]

    def test_strings_not_included(self):
        assert filter_integers(['1', '2', 3]) == [3]

    def test_none_not_included(self):
        assert filter_integers([1, None, 2]) == [1, 2]

    def test_booleans_included(self):
        assert filter_integers([True, False, 1, 2]) == [True, False, 1, 2]

    def test_lists_not_included(self):
        assert filter_integers([[1], [2], 3]) == [3]

    def test_dicts_not_included(self):
        assert filter_integers([{'a': 1}, 2]) == [2]

    def test_tuples_not_included(self):
        assert filter_integers([(1, 2), 3]) == [3]

    def test_sets_not_included(self):
        assert filter_integers([{1, 2}, 3]) == [3]

    def test_large_integers(self):
        assert filter_integers([1000000, 2000000, 'x']) == [1000000, 2000000]

    def test_very_large_integers(self):
        assert filter_integers([10**100, 10**200, 3.14]) == [10**100, 10**200]

    def test_preserves_order(self):
        assert filter_integers([5, 'a', 3, 'b', 1]) == [5, 3, 1]

    def test_duplicate_integers(self):
        assert filter_integers([1, 1, 2, 2, 3]) == [1, 1, 2, 2, 3]

    def test_mixed_with_complex_numbers(self):
        assert filter_integers([1, 2+3j, 3]) == [1, 3]

    def test_mixed_with_bytes(self):
        assert filter_integers([1, b'hello', 2]) == [1, 2]

    @pytest.mark.parametrize("input_list,expected", [
        ([1, 2, 3], [1, 2, 3]),
        ([], []),
        (['a', 'b'], []),
        ([1, 'a', 2, 'b', 3], [1, 2, 3]),
        ([0], [0]),
        ([-1, -2, -3], [-1, -2, -3]),
    ])
    def test_parametrized_cases(self, input_list, expected):
        assert filter_integers(input_list) == expected
