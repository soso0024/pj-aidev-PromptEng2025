# Test cases for HumanEval/52
# Generated using Claude API



def below_threshold(l: list, t: int):
    """Return True if all numbers in the list l are below threshold t.
    >>> below_threshold([1, 2, 4, 10], 100)
    True
    >>> below_threshold([1, 20, 4, 10], 5)
    False
    """

    for e in l:
        if e >= t:
            return False
    return True


# Generated test cases:
import pytest


def below_threshold(l: list, t: int):
    for e in l:
        if e >= t:
            return False
    return True


class TestBelowThreshold:
    def test_empty_list(self):
        assert below_threshold([], 0) is True
        assert below_threshold([], 100) is True
        assert below_threshold([], -100) is True

    def test_all_elements_below_threshold(self):
        assert below_threshold([1, 2, 3], 5) is True
        assert below_threshold([0, 1, 2], 3) is True
        assert below_threshold([-5, -3, -1], 0) is True

    def test_all_elements_above_threshold(self):
        assert below_threshold([5, 6, 7], 3) is False
        assert below_threshold([10, 20, 30], 5) is False
        assert below_threshold([1, 2, 3], 0) is False

    def test_element_equal_to_threshold(self):
        assert below_threshold([5], 5) is False
        assert below_threshold([1, 2, 5], 5) is False
        assert below_threshold([5, 6, 7], 5) is False

    def test_mixed_elements(self):
        assert below_threshold([1, 2, 3, 4], 5) is True
        assert below_threshold([1, 2, 3, 5], 5) is False
        assert below_threshold([1, 2, 3, 4, 6], 5) is False

    def test_single_element_below(self):
        assert below_threshold([3], 5) is True

    def test_single_element_above(self):
        assert below_threshold([5], 3) is False

    def test_single_element_equal(self):
        assert below_threshold([5], 5) is False

    def test_negative_numbers(self):
        assert below_threshold([-10, -5, -1], 0) is True
        assert below_threshold([-10, -5, -1], -2) is False
        assert below_threshold([-10, -5, -1], -10) is False

    def test_negative_threshold(self):
        assert below_threshold([-5, -3, -1], -10) is False
        assert below_threshold([-5, -3, -1], -5) is False

    def test_zero_threshold(self):
        assert below_threshold([-1, -2, -3], 0) is True
        assert below_threshold([0, 1, 2], 0) is False
        assert below_threshold([-1, 0, 1], 0) is False

    def test_large_numbers(self):
        assert below_threshold([1000, 2000, 3000], 5000) is True
        assert below_threshold([1000, 2000, 3000], 2500) is False

    def test_float_like_integers(self):
        assert below_threshold([1, 2, 3], 4) is True
        assert below_threshold([1, 2, 3], 3) is False

    @pytest.mark.parametrize("lst,threshold,expected", [
        ([1, 2, 3], 4, True),
        ([1, 2, 3], 3, False),
        ([1, 2, 3], 2, False),
        ([], 0, True),
        ([0], 1, True),
        ([0], 0, False),
        ([-1, -2, -3], 0, True),
        ([-1, -2, -3], -1, False),
    ])
    def test_parametrized(self, lst, threshold, expected):
        assert below_threshold(lst, threshold) is expected

    def test_first_element_triggers_false(self):
        assert below_threshold([5, 1, 2, 3], 4) is False

    def test_last_element_triggers_false(self):
        assert below_threshold([1, 2, 3, 5], 4) is False

    def test_middle_element_triggers_false(self):
        assert below_threshold([1, 2, 5, 3], 4) is False

    def test_duplicate_elements_all_below(self):
        assert below_threshold([2, 2, 2, 2], 3) is True

    def test_duplicate_elements_all_above(self):
        assert below_threshold([5, 5, 5, 5], 3) is False

    def test_duplicate_elements_equal_to_threshold(self):
        assert below_threshold([5, 5, 5], 5) is False