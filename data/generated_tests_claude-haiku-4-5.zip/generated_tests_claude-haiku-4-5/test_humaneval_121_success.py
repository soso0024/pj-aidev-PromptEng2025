# Test cases for HumanEval/121
# Generated using Claude API


def solution(lst):
    """Given a non-empty list of integers, return the sum of all of the odd elements that are in even positions.
    

    Examples
    solution([5, 8, 7, 1]) ==> 12
    solution([3, 3, 3, 3, 3]) ==> 9
    solution([30, 13, 24, 321]) ==>0
    """

    return sum([x for idx, x in enumerate(lst) if idx%2==0 and x%2==1])


# Generated test cases:
import pytest


def solution(lst):
    return sum([x for idx, x in enumerate(lst) if idx%2==0 and x%2==1])


class TestSolution:
    
    def test_empty_list(self):
        assert solution([]) == 0
    
    def test_single_odd_element_at_index_0(self):
        assert solution([1]) == 1
    
    def test_single_even_element_at_index_0(self):
        assert solution([2]) == 0
    
    def test_two_elements_both_odd_at_even_indices(self):
        assert solution([1, 3]) == 1
    
    def test_two_elements_first_odd_second_even(self):
        assert solution([1, 2]) == 1
    
    def test_two_elements_first_even_second_odd(self):
        assert solution([2, 1]) == 0
    
    def test_two_elements_both_even(self):
        assert solution([2, 4]) == 0
    
    def test_multiple_elements_alternating(self):
        assert solution([1, 2, 3, 4, 5, 6]) == 1 + 3 + 5
    
    def test_multiple_elements_all_odd(self):
        assert solution([1, 3, 5, 7, 9]) == 1 + 5 + 9
    
    def test_multiple_elements_all_even(self):
        assert solution([2, 4, 6, 8]) == 0
    
    def test_multiple_elements_odd_at_even_indices(self):
        assert solution([1, 100, 3, 100, 5]) == 1 + 3 + 5
    
    def test_multiple_elements_even_at_even_indices(self):
        assert solution([2, 1, 4, 3, 6, 5]) == 0
    
    def test_large_odd_numbers(self):
        assert solution([999, 2, 1001, 4]) == 999 + 1001
    
    def test_negative_odd_numbers(self):
        assert solution([-1, 2, -3, 4]) == -1 + (-3)
    
    def test_negative_even_numbers(self):
        assert solution([-2, -1, -4, -3]) == 0
    
    def test_mixed_positive_negative_odd(self):
        assert solution([1, 2, -3, 4, 5]) == 1 + (-3) + 5
    
    def test_zero_at_even_index(self):
        assert solution([0, 1, 2, 3]) == 0
    
    def test_zero_at_odd_index(self):
        assert solution([1, 0, 3, 2]) == 1 + 3
    
    def test_only_zeros(self):
        assert solution([0, 0, 0, 0]) == 0
    
    def test_single_zero(self):
        assert solution([0]) == 0
    
    def test_long_list(self):
        lst = list(range(1, 101))
        result = solution(lst)
        expected = sum([x for x in lst if lst.index(x) % 2 == 0 and x % 2 == 1])
        assert result == expected
    
    def test_alternating_pattern_long(self):
        lst = [1, 2] * 50
        assert solution(lst) == 1 * 50
    
    def test_index_0_is_even_index_1_is_odd(self):
        assert solution([7, 8, 9, 10]) == 7 + 9
    
    def test_all_odd_numbers_at_odd_indices(self):
        assert solution([2, 1, 4, 3, 6, 5]) == 0
    
    def test_large_list_with_pattern(self):
        lst = [i for i in range(1, 1001)]
        result = solution(lst)
        expected = sum([i for i in range(1, 1001) if (i-1) % 2 == 0 and i % 2 == 1])
        assert result == expected


@pytest.mark.parametrize("input_list,expected", [
    ([], 0),
    ([1], 1),
    ([2], 0),
    ([1, 2], 1),
    ([2, 1], 0),
    ([1, 2, 3, 4], 1 + 3),
    ([2, 4, 6, 8], 0),
    ([1, 3, 5, 7], 1 + 5),
    ([0, 1, 0, 1], 0),
    ([-1, 2, -3, 4], -1 + (-3)),
])
def test_solution_parametrized(input_list, expected):
    assert solution(input_list) == expected
