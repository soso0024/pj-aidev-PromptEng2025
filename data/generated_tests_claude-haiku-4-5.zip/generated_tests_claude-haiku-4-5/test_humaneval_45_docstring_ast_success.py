# Test cases for HumanEval/45
# Generated using Claude API



def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """

    return a * h / 2.0


# Generated test cases:
import pytest


def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """
    return a * h / 2.0


class TestTriangleArea:
    
    def test_basic_example(self):
        """Test the example from docstring"""
        assert triangle_area(5, 3) == 7.5
    
    def test_integer_inputs(self):
        """Test with integer inputs"""
        assert triangle_area(4, 6) == 12.0
    
    def test_float_inputs(self):
        """Test with float inputs"""
        assert triangle_area(2.5, 4.0) == 5.0
    
    def test_small_values(self):
        """Test with small values"""
        assert triangle_area(1, 1) == 0.5
    
    def test_large_values(self):
        """Test with large values"""
        assert triangle_area(1000, 2000) == 1000000.0
    
    def test_zero_base(self):
        """Test with zero base"""
        assert triangle_area(0, 5) == 0.0
    
    def test_zero_height(self):
        """Test with zero height"""
        assert triangle_area(5, 0) == 0.0
    
    def test_both_zero(self):
        """Test with both base and height as zero"""
        assert triangle_area(0, 0) == 0.0
    
    def test_negative_base(self):
        """Test with negative base"""
        assert triangle_area(-5, 3) == -7.5
    
    def test_negative_height(self):
        """Test with negative height"""
        assert triangle_area(5, -3) == -7.5
    
    def test_both_negative(self):
        """Test with both negative"""
        assert triangle_area(-5, -3) == 7.5
    
    def test_decimal_precision(self):
        """Test decimal precision"""
        result = triangle_area(3, 7)
        assert result == 10.5
    
    def test_very_small_values(self):
        """Test with very small values"""
        result = triangle_area(0.001, 0.002)
        assert abs(result - 0.000001) < 1e-9
    
    def test_mixed_sign_values(self):
        """Test with mixed positive and negative"""
        assert triangle_area(-10, 4) == -20.0
        assert triangle_area(10, -4) == -20.0
    
    @pytest.mark.parametrize("a,h,expected", [
        (5, 3, 7.5),
        (10, 2, 10.0),
        (4, 4, 8.0),
        (1, 1, 0.5),
        (100, 50, 2500.0),
        (0.5, 0.5, 0.125),
    ])
    def test_parametrized_valid_inputs(self, a, h, expected):
        """Test various valid input combinations"""
        assert triangle_area(a, h) == expected
    
    def test_return_type_is_float(self):
        """Test that return type is float"""
        result = triangle_area(5, 3)
        assert isinstance(result, float)
    
    def test_commutative_property(self):
        """Test that base and height are interchangeable"""
        assert triangle_area(5, 3) == triangle_area(3, 5)
