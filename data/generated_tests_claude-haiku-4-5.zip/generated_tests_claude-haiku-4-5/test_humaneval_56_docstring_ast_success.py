# Test cases for HumanEval/56
# Generated using Claude API



def correct_bracketing(brackets: str):
    """ brackets is a string of "<" and ">".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """

    depth = 0
    for b in brackets:
        if b == "<":
            depth += 1
        else:
            depth -= 1
        if depth < 0:
            return False
    return depth == 0


# Generated test cases:
import pytest


def correct_bracketing(brackets: str):
    depth = 0
    for b in brackets:
        if b == "<":
            depth += 1
        else:
            depth -= 1
        if depth < 0:
            return False
    return depth == 0


class TestCorrectBracketing:
    
    @pytest.mark.parametrize("brackets,expected", [
        ("<", False),
        ("<>", True),
        ("<<><>>", True),
        ("><<>", False),
    ])
    def test_docstring_examples(self, brackets, expected):
        assert correct_bracketing(brackets) == expected
    
    def test_empty_string(self):
        assert correct_bracketing("") == True
    
    def test_single_opening_bracket(self):
        assert correct_bracketing("<") == False
    
    def test_single_closing_bracket(self):
        assert correct_bracketing(">") == False
    
    def test_simple_pair(self):
        assert correct_bracketing("<>") == True
    
    def test_multiple_pairs(self):
        assert correct_bracketing("<><>") == True
    
    def test_nested_brackets(self):
        assert correct_bracketing("<<>>") == True
    
    def test_deeply_nested_brackets(self):
        assert correct_bracketing("<<<>>>") == True
    
    def test_closing_before_opening(self):
        assert correct_bracketing("><") == False
    
    def test_extra_closing_bracket(self):
        assert correct_bracketing("<>>") == False
    
    def test_extra_opening_bracket(self):
        assert correct_bracketing("<<>") == False
    
    def test_multiple_extra_closing_brackets(self):
        assert correct_bracketing("<>>>") == False
    
    def test_multiple_extra_opening_brackets(self):
        assert correct_bracketing("<<<>") == False
    
    def test_alternating_brackets(self):
        assert correct_bracketing("<><><>") == True
    
    def test_complex_valid_pattern(self):
        assert correct_bracketing("<<><>>") == True
    
    def test_complex_invalid_pattern_1(self):
        assert correct_bracketing("><<>") == False
    
    def test_complex_invalid_pattern_2(self):
        assert correct_bracketing("<><>>") == False
    
    def test_complex_invalid_pattern_3(self):
        assert correct_bracketing("<<><>") == False
    
    def test_many_opening_brackets(self):
        assert correct_bracketing("<" * 10) == False
    
    def test_many_closing_brackets(self):
        assert correct_bracketing(">" * 10) == False
    
    def test_many_valid_pairs(self):
        assert correct_bracketing("<>" * 10) == True
    
    def test_many_nested_brackets(self):
        assert correct_bracketing("<" * 5 + ">" * 5) == True
    
    def test_unbalanced_nested_brackets(self):
        assert correct_bracketing("<" * 5 + ">" * 4) == False
    
    def test_closing_bracket_early(self):
        assert correct_bracketing("<><>>") == False
    
    def test_mixed_valid_invalid(self):
        assert correct_bracketing("<><><") == False
