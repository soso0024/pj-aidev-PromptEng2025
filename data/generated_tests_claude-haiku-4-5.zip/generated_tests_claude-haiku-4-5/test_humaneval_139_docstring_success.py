# Test cases for HumanEval/139
# Generated using Claude API


def special_factorial(n):
    """The Brazilian factorial is defined as:
    brazilian_factorial(n) = n! * (n-1)! * (n-2)! * ... * 1!
    where n > 0

    For example:
    >>> special_factorial(4)
    288

    The function will receive an integer as input and should return the special
    factorial of this integer.
    """

    fact_i = 1
    special_fact = 1
    for i in range(1, n+1):
        fact_i *= i
        special_fact *= fact_i
    return special_fact


# Generated test cases:
import pytest


def special_factorial(n):
    fact_i = 1
    special_fact = 1
    for i in range(1, n+1):
        fact_i *= i
        special_fact *= fact_i
    return special_fact


class TestSpecialFactorial:
    
    @pytest.mark.parametrize("n,expected", [
        (1, 1),
        (2, 2),
        (3, 12),
        (4, 288),
        (5, 34560),
    ])
    def test_special_factorial_basic_cases(self, n, expected):
        assert special_factorial(n) == expected
    
    def test_special_factorial_one(self):
        assert special_factorial(1) == 1
    
    def test_special_factorial_two(self):
        assert special_factorial(2) == 2
    
    def test_special_factorial_three(self):
        assert special_factorial(3) == 12
    
    def test_special_factorial_four(self):
        assert special_factorial(4) == 288
    
    def test_special_factorial_five(self):
        assert special_factorial(5) == 34560
    
    def test_special_factorial_six(self):
        result = special_factorial(6)
        assert result == 24883200
    
    def test_special_factorial_large_number(self):
        result = special_factorial(10)
        assert isinstance(result, int)
        assert result > 0
    
    def test_special_factorial_returns_integer(self):
        result = special_factorial(3)
        assert isinstance(result, int)
    
    def test_special_factorial_positive_result(self):
        for n in range(1, 8):
            assert special_factorial(n) > 0
    
    def test_special_factorial_increasing_sequence(self):
        prev = special_factorial(1)
        for n in range(2, 7):
            current = special_factorial(n)
            assert current > prev
            prev = current
    
    def test_special_factorial_seven(self):
        result = special_factorial(7)
        assert result == 125411328000
    
    def test_special_factorial_eight(self):
        result = special_factorial(8)
        assert isinstance(result, int)
        assert result > special_factorial(7)
