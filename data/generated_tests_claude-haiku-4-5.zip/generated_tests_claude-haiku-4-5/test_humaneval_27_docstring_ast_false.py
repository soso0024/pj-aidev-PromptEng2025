# Test cases for HumanEval/27
# Generated using Claude API



def flip_case(string: str) -> str:
    """ For a given string, flip lowercase characters to uppercase and uppercase to lowercase.
    >>> flip_case('Hello')
    'hELLO'
    """

    return string.swapcase()


# Generated test cases:
import pytest


def flip_case(string: str) -> str:
    """ For a given string, flip lowercase characters to uppercase and uppercase to lowercase.
    >>> flip_case('Hello')
    'hELLO'
    """

    return string.swapcase()


class TestFlipCase:
    def test_basic_hello(self):
        assert flip_case('Hello') == 'hELLO'
    
    def test_all_lowercase(self):
        assert flip_case('hello') == 'HELLO'
    
    def test_all_uppercase(self):
        assert flip_case('HELLO') == 'hello'
    
    def test_empty_string(self):
        assert flip_case('') == ''
    
    def test_mixed_case(self):
        assert flip_case('HeLLo WoRLd') == 'hEllO wOrLd'
    
    def test_with_numbers(self):
        assert flip_case('Hello123World') == 'hELLO123wORLD'
    
    def test_with_special_characters(self):
        assert flip_case('Hello!@#$%World') == 'hELLO!@#$%wORLD'
    
    def test_single_lowercase_letter(self):
        assert flip_case('a') == 'A'
    
    def test_single_uppercase_letter(self):
        assert flip_case('A') == 'a'
    
    def test_single_number(self):
        assert flip_case('5') == '5'
    
    def test_single_special_char(self):
        assert flip_case('!') == '!'
    
    def test_spaces_only(self):
        assert flip_case('   ') == '   '
    
    def test_mixed_with_spaces(self):
        assert flip_case('Hello World') == 'hELLO wORLD'
    
    def test_tabs_and_newlines(self):
        assert flip_case('Hello\tWorld\nTest') == 'hELLO\twORLD\ntEST'
    
    def test_unicode_letters(self):
        assert flip_case('Café') == 'cAFÉ'
    
    def test_alternating_case(self):
        assert flip_case('AbCdEfGh') == 'aBcDeFgH'
    
    def test_long_string(self):
        long_string = 'A' * 1000 + 'a' * 1000
        expected = 'a' * 1000 + 'A' * 1000
        assert flip_case(long_string) == expected
    
    def test_numbers_and_special_chars_only(self):
        assert flip_case('123!@#$%^&*()') == '123!@#$%^&*()'
    
    def test_mixed_punctuation(self):
        assert flip_case('Hello, World! How Are You?') == 'hELLO, wORLD! hOW aRE yOU?'


@pytest.mark.parametrize("input_str,expected", [
    ('Hello', 'hELLO'),
    ('hello', 'HELLO'),
    ('HELLO', 'hello'),
    ('', ''),
    ('a', 'A'),
    ('Z', 'z'),
    ('123', '123'),
    ('!@#', '!@#'),
    ('HeLLo', 'hEllO'),
    ('Test123ABC', 'tEST123abc'),
])
def test_flip_case_parametrized(input_str, expected):
    assert flip_case(input_str) == expected


def test_flip_case_idempotent_double_flip():
    original = 'Hello World'
    flipped_once = flip_case(original)
    flipped_twice = flip_case(flipped_once)
    assert flipped_twice == original


def test_flip_case_preserves_length():
    test_strings = ['Hello', 'WORLD', 'Test123', '!@#$%', '']
    for test_str in test_strings:
        assert len(flip_case(test_str)) == len(test_str)