# Test cases for HumanEval/102
# Generated using Claude API


def choose_num(x, y):
    """This function takes two positive numbers x and y and returns the
    biggest even integer number that is in the range [x, y] inclusive. If 
    there's no such number, then the function should return -1.

    For example:
    choose_num(12, 15) = 14
    choose_num(13, 12) = -1
    """

    if x > y:
        return -1
    if y % 2 == 0:
        return y
    if x == y:
        return -1
    return y - 1


# Generated test cases:
import pytest


class TestChooseNum:
    
    @pytest.mark.parametrize("x,y,expected", [
        (1, 2, 2),
        (1, 4, 4),
        (5, 10, 10),
        (0, 100, 100),
        (1, 1000, 1000),
    ])
    def test_y_is_even(self, x, y, expected):
        from test_humaneval_102_ast import choose_num
        assert choose_num(x, y) == expected
    
    @pytest.mark.parametrize("x,y,expected", [
        (1, 3, 2),
        (2, 5, 4),
        (0, 7, 6),
        (10, 15, 14),
        (1, 99, 98),
    ])
    def test_y_is_odd_x_less_than_y(self, x, y, expected):
        assert choose_num(x, y) == expected
    
    @pytest.mark.parametrize("x,y,expected", [
        (5, 5, -1),
        (1, 1, -1),
    ])
    def test_x_equals_y(self, x, y, expected):
        assert choose_num(x, y) == expected
    
    @pytest.mark.parametrize("x,y,expected", [
        (5, 1, -1),
        (10, 5, -1),
        (100, 50, -1),
        (2, 1, -1),
        (1000, 1, -1),
    ])
    def test_x_greater_than_y(self, x, y, expected):
        assert choose_num(x, y) == expected
    
    def test_x_zero_y_even(self):
        assert choose_num(0, 2) == 2
    
    def test_x_zero_y_odd(self):
        assert choose_num(0, 3) == 2
    
    def test_negative_x_positive_y_even(self):
        assert choose_num(-5, 10) == 10
    
    def test_negative_x_positive_y_odd(self):
        assert choose_num(-5, 11) == 10
    
    def test_both_negative_x_greater(self):
        assert choose_num(-1, -5) == -1
    
    def test_both_negative_x_less_y_even(self):
        assert choose_num(-10, -2) == -2
    
    def test_both_negative_x_less_y_odd(self):
        assert choose_num(-10, -3) == -4
    
    def test_both_negative_equal(self):
        assert choose_num(-5, -5) == -1
    
    def test_large_even_numbers(self):
        assert choose_num(1000000, 2000000) == 2000000
    
    def test_large_odd_numbers(self):
        assert choose_num(1000000, 2000001) == 2000000
    
    def test_consecutive_numbers_even(self):
        assert choose_num(1, 2) == 2
    
    def test_consecutive_numbers_odd(self):
        assert choose_num(1, 2) == 2
    
    def test_x_one_y_two(self):
        assert choose_num(1, 2) == 2
    
    def test_x_zero_y_zero(self):
        assert choose_num(0, 0) == 0
    
    def test_x_negative_one_y_zero(self):
        assert choose_num(-1, 0) == 0
    
    def test_x_negative_one_y_one(self):
        assert choose_num(-1, 1) == 0