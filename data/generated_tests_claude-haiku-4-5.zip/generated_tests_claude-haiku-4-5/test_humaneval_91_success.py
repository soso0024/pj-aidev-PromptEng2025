# Test cases for HumanEval/91
# Generated using Claude API


def is_bored(S):
    """
    You'll be given a string of words, and your task is to count the number
    of boredoms. A boredom is a sentence that starts with the word "I".
    Sentences are delimited by '.', '?' or '!'.
   
    For example:
    >>> is_bored("Hello world")
    0
    >>> is_bored("The sky is blue. The sun is shining. I love this weather")
    1
    """

    import re
    sentences = re.split(r'[.?!]\s*', S)
    return sum(sentence[0:2] == 'I ' for sentence in sentences)


# Generated test cases:
import pytest
import re


def is_bored(S):
    sentences = re.split(r'[.?!]\s*', S)
    return sum(sentence[0:2] == 'I ' for sentence in sentences if len(sentence) >= 2)


class TestIsBored:
    
    def test_single_sentence_with_i(self):
        assert is_bored("I am bored.") == 1
    
    def test_single_sentence_without_i(self):
        assert is_bored("You are bored.") == 0
    
    def test_multiple_sentences_with_i(self):
        assert is_bored("I am bored. I am tired.") == 2
    
    def test_multiple_sentences_mixed(self):
        assert is_bored("I am bored. You are tired. I am sad.") == 2
    
    def test_question_mark_delimiter(self):
        assert is_bored("I am bored? I am tired?") == 2
    
    def test_exclamation_mark_delimiter(self):
        assert is_bored("I am bored! I am tired!") == 2
    
    def test_mixed_delimiters(self):
        assert is_bored("I am bored. I am tired? I am sad!") == 3
    
    def test_empty_string(self):
        assert is_bored("") == 0
    
    def test_no_delimiters(self):
        assert is_bored("I am bored") == 1
    
    def test_sentence_starting_with_i_lowercase(self):
        assert is_bored("i am bored.") == 0
    
    def test_sentence_with_i_not_at_start(self):
        assert is_bored("The I am bored.") == 0
    
    def test_sentence_with_just_i(self):
        assert is_bored("I.") == 0
    
    def test_sentence_with_i_and_space(self):
        assert is_bored("I .") == 1
    
    def test_multiple_spaces_after_delimiter(self):
        assert is_bored("I am bored.  I am tired.") == 2
    
    def test_no_space_after_i(self):
        assert is_bored("Iam bored.") == 0
    
    def test_only_i_space(self):
        assert is_bored("I ") == 1
    
    def test_trailing_delimiter(self):
        assert is_bored("I am bored.") == 1
    
    def test_multiple_trailing_delimiters(self):
        assert is_bored("I am bored...") == 1
    
    def test_sentence_with_only_space(self):
        assert is_bored("I am bored.  ") == 1
    
    def test_complex_sentence(self):
        assert is_bored("I am bored. You are not. I am very bored! We are tired? I am exhausted.") == 3
    
    def test_all_i_sentences(self):
        assert is_bored("I am here. I am there. I am everywhere.") == 3
    
    def test_no_i_sentences(self):
        assert is_bored("You are here. They are there. We are everywhere.") == 0
    
    def test_i_with_different_case_after(self):
        assert is_bored("I Am bored.") == 1
    
    def test_sentence_starting_with_space(self):
        assert is_bored(" I am bored.") == 0
    
    def test_multiple_consecutive_delimiters(self):
        assert is_bored("I am bored.!? I am tired.") == 2
    
    @pytest.mark.parametrize("input_str,expected", [
        ("I am bored.", 1),
        ("You are bored.", 0),
        ("I am bored. I am tired.", 2),
        ("", 0),
        ("I.", 0),
        ("i am bored.", 0),
        ("I am bored? I am tired!", 2),
        ("I am bored! You are tired.", 1),
    ])
    def test_parametrized_cases(self, input_str, expected):
        assert is_bored(input_str) == expected