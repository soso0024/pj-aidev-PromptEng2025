# Test cases for HumanEval/94
# Generated using Claude API



def skjkasdkd(lst):
    """You are given a list of integers.
    You need to find the largest prime value and return the sum of its digits.

    Examples:
    For lst = [0,3,2,1,3,5,7,4,5,5,5,2,181,32,4,32,3,2,32,324,4,3] the output should be 10
    For lst = [1,0,1,8,2,4597,2,1,3,40,1,2,1,2,4,2,5,1] the output should be 25
    For lst = [1,3,1,32,5107,34,83278,109,163,23,2323,32,30,1,9,3] the output should be 13
    For lst = [0,724,32,71,99,32,6,0,5,91,83,0,5,6] the output should be 11
    For lst = [0,81,12,3,1,21] the output should be 3
    For lst = [0,8,1,2,1,7] the output should be 7
    """

    def isPrime(n):
        for i in range(2,int(n**0.5)+1):
            if n%i==0:
                return False

        return True
    maxx = 0
    i = 0
    while i < len(lst):
        if(lst[i] > maxx and isPrime(lst[i])):
            maxx = lst[i]
        i+=1
    result = sum(int(digit) for digit in str(maxx))
    return result



# Generated test cases:
import pytest


def skjkasdkd(lst):
    """You are given a list of integers.
    You need to find the largest prime value and return the sum of its digits.

    Examples:
    For lst = [0,3,2,1,3,5,7,4,5,5,5,2,181,32,4,32,3,2,32,324,4,3] the output should be 10
    For lst = [1,0,1,8,2,4597,2,1,3,40,1,2,1,2,4,2,5,1] the output should be 25
    For lst = [1,3,1,32,5107,34,83278,109,163,23,2323,32,30,1,9,3] the output should be 13
    For lst = [0,724,32,71,99,32,6,0,5,91,83,0,5,6] the output should be 11
    For lst = [0,81,12,3,1,21] the output should be 3
    For lst = [0,8,1,2,1,7] the output should be 7
    """
    def isPrime(n):
        if n < 2:
            return False
        for i in range(2, int(n**0.5)+1):
            if n % i == 0:
                return False
        return True
    
    maxx = 0
    i = 0
    while i < len(lst):
        if lst[i] > maxx and isPrime(lst[i]):
            maxx = lst[i]
        i += 1
    result = sum(int(digit) for digit in str(maxx))
    return result


class TestSkjkasdkd:
    
    @pytest.mark.parametrize("lst,expected", [
        ([0,3,2,1,3,5,7,4,5,5,5,2,181,32,4,32,3,2,32,324,4,3], 10),
        ([1,0,1,8,2,4597,2,1,3,40,1,2,1,2,4,2,5,1], 25),
        ([1,3,1,32,5107,34,83278,109,163,23,2323,32,30,1,9,3], 13),
        ([0,724,32,71,99,32,6,0,5,91,83,0,5,6], 11),
        ([0,81,12,3,1,21], 3),
        ([0,8,1,2,1,7], 7),
    ])
    def test_provided_examples(self, lst, expected):
        assert skjkasdkd(lst) == expected
    
    def test_single_prime(self):
        assert skjkasdkd([2]) == 2
    
    def test_single_non_prime(self):
        assert skjkasdkd([4]) == 0
    
    def test_all_zeros(self):
        assert skjkasdkd([0, 0, 0]) == 0
    
    def test_all_non_primes(self):
        assert skjkasdkd([4, 6, 8, 9, 10]) == 0
    
    def test_single_digit_primes(self):
        assert skjkasdkd([2, 3, 5, 7]) == 7
    
    def test_two_digit_prime(self):
        assert skjkasdkd([11, 13, 17, 19]) == 10
    
    def test_large_prime(self):
        assert skjkasdkd([97]) == 16
    
    def test_mixed_with_duplicates(self):
        assert skjkasdkd([2, 2, 2, 3, 3, 5, 5]) == 5
    
    def test_prime_with_larger_non_primes(self):
        assert skjkasdkd([2, 100, 200, 300]) == 2
    
    def test_multiple_primes_ascending(self):
        assert skjkasdkd([2, 3, 5, 7, 11, 13]) == 4
    
    def test_multiple_primes_descending(self):
        assert skjkasdkd([13, 11, 7, 5, 3, 2]) == 4
    
    def test_multiple_primes_random_order(self):
        assert skjkasdkd([5, 2, 13, 3, 11, 7]) == 4
    
    def test_large_list_with_one_prime(self):
        assert skjkasdkd([4, 6, 8, 9, 10, 12, 14, 15, 16, 17]) == 8
    
    def test_prime_23(self):
        assert skjkasdkd([23]) == 5
    
    def test_prime_29(self):
        assert skjkasdkd([29]) == 11
    
    def test_prime_31(self):
        assert skjkasdkd([31]) == 4
    
    def test_prime_37(self):
        assert skjkasdkd([37]) == 10
    
    def test_prime_41(self):
        assert skjkasdkd([41]) == 5
    
    def test_prime_43(self):
        assert skjkasdkd([43]) == 7
    
    def test_prime_47(self):
        assert skjkasdkd([47]) == 11
    
    def test_prime_53(self):
        assert skjkasdkd([53]) == 8
    
    def test_prime_59(self):
        assert skjkasdkd([59]) == 14
    
    def test_prime_61(self):
        assert skjkasdkd([61]) == 7
    
    def test_prime_67(self):
        assert skjkasdkd([67]) == 13
    
    def test_prime_71(self):
        assert skjkasdkd([71]) == 8
    
    def test_prime_73(self):
        assert skjkasdkd([73]) == 10
    
    def test_prime_79(self):
        assert skjkasdkd([79]) == 16
    
    def test_prime_83(self):
        assert skjkasdkd([83]) == 11
    
    def test_prime_89(self):
        assert skjkasdkd([89]) == 17
    
    def test_three_digit_prime_101(self):
        assert skjkasdkd([101]) == 2
    
    def test_three_digit_prime_103(self):
        assert skjkasdkd([103]) == 4
    
    def test_three_digit_prime_107(self):
        assert skjkasdkd([107]) == 8
    
    def test_three_digit_prime_109(self):
        assert skjkasdkd([109]) == 10
    
    def test_three_digit_prime_113(self):
        assert skjkasdkd([113]) == 5
    
    def test_mixed_list_with_zero_and_primes(self):
        assert skjkasdkd([0, 2, 3, 5]) == 5
    
    def test_mixed_list_with_one_and_primes(self):
        assert skjkasdkd([1, 2, 3, 5]) == 5
    
    def test_negative_numbers_ignored(self):
        assert skjkasdkd([-5, -3, 2, 3, 5]) == 5
    
    def test_one_is_not_prime(self):
        assert skjkasdkd([1, 1, 1]) == 0