# Test cases for HumanEval/158
# Generated using Claude API


def find_max(words):
    """Write a function that accepts a list of strings.
    The list contains different words. Return the word with maximum number
    of unique characters. If multiple strings have maximum number of unique
    characters, return the one which comes first in lexicographical order.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb" ,"cc"]) == ""aaaaaaa"
    """

    return sorted(words, key = lambda x: (-len(set(x)), x))[0]


# Generated test cases:
import pytest


def find_max(words):
    return sorted(words, key = lambda x: (-len(set(x)), x))[0]


class TestFindMax:
    def test_single_word(self):
        assert find_max(["hello"]) == "hello"
    
    def test_word_with_most_unique_chars(self):
        assert find_max(["aaa", "abc", "ab"]) == "abc"
    
    def test_same_unique_char_count_alphabetical_order(self):
        assert find_max(["abc", "def"]) == "abc"
    
    def test_same_unique_char_count_reverse_alphabetical(self):
        assert find_max(["xyz", "abc"]) == "abc"
    
    def test_repeated_characters(self):
        assert find_max(["aaa", "bbb", "ccc"]) == "aaa"
    
    def test_mixed_unique_and_repeated(self):
        assert find_max(["aabbcc", "abcdef", "aaa"]) == "abcdef"
    
    def test_single_character_words(self):
        assert find_max(["a", "b", "c"]) == "a"
    
    def test_empty_string_in_list(self):
        result = find_max(["", "a", "ab"])
        assert result == "ab"
    
    def test_two_words_same_unique_count(self):
        assert find_max(["ab", "ba"]) == "ab"
    
    def test_long_word_vs_short_word(self):
        assert find_max(["abcdefghij", "aabbccdd"]) == "abcdefghij"
    
    def test_word_with_all_same_character(self):
        assert find_max(["aaaa", "abcd"]) == "abcd"
    
    def test_case_sensitive(self):
        assert find_max(["Abc", "abc"]) == "Abc"
    
    def test_special_characters(self):
        assert find_max(["a!b@c#", "aaa", "abc"]) == "a!b@c#"
    
    def test_numbers_as_strings(self):
        assert find_max(["111", "123", "12"]) == "123"
    
    def test_whitespace_characters(self):
        result = find_max(["a b c", "abc", "aaa"])
        assert result == "a b c"
    
    def test_unicode_characters(self):
        assert find_max(["café", "aaa", "ab"]) == "café"
    
    def test_very_long_word(self):
        long_word = "abcdefghijklmnopqrstuvwxyz"
        assert find_max([long_word, "aaa"]) == long_word
    
    def test_identical_words(self):
        assert find_max(["test", "test", "test"]) == "test"
    
    def test_word_with_duplicates_at_end(self):
        assert find_max(["abcabc", "abcdef"]) == "abcdef"
    
    def test_alphabetical_tiebreaker(self):
        assert find_max(["xyz", "uvw", "abc"]) == "abc"
    
    def test_multiple_words_different_unique_counts(self):
        assert find_max(["a", "ab", "abc", "abcd"]) == "abcd"
    
    def test_words_with_punctuation(self):
        assert find_max(["hello!", "world?", "test."]) == "world?"
    
    def test_empty_string_only(self):
        assert find_max([""]) == ""
    
    def test_multiple_empty_strings(self):
        assert find_max(["", "", ""]) == ""
    
    def test_mixed_empty_and_nonempty(self):
        assert find_max(["", "a"]) == "a"
    
    def test_word_with_newline(self):
        result = find_max(["a\nb", "aaa"])
        assert result == "a\nb"
    
    def test_word_with_tab(self):
        result = find_max(["a\tb", "aaa"])
        assert result == "a\tb"


@pytest.mark.parametrize("words,expected", [
    (["hello"], "hello"),
    (["aaa", "abc", "ab"], "abc"),
    (["abc", "def"], "abc"),
    (["aabbcc", "abcdef", "aaa"], "abcdef"),
    (["a", "b", "c"], "a"),
    (["ab", "ba"], "ab"),
    (["abcdefghij", "aabbccdd"], "abcdefghij"),
    (["aaaa", "abcd"], "abcd"),
    (["111", "123", "12"], "123"),
    (["test", "test", "test"], "test"),
])
def test_find_max_parametrized(words, expected):
    assert find_max(words) == expected