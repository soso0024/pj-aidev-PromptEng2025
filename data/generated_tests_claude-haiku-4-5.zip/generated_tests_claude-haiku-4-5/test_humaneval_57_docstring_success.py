# Test cases for HumanEval/57
# Generated using Claude API



def monotonic(l: list):
    """Return True is list elements are monotonically increasing or decreasing.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """

    if l == sorted(l) or l == sorted(l, reverse=True):
        return True
    return False


# Generated test cases:
import pytest


def monotonic(l: list):
    if l == sorted(l) or l == sorted(l, reverse=True):
        return True
    return False


class TestMonotonic:
    
    @pytest.mark.parametrize("input_list,expected", [
        ([1, 2, 4, 20], True),
        ([1, 20, 4, 10], False),
        ([4, 1, 0, -10], True),
        ([], True),
        ([1], True),
        ([1, 1], True),
        ([1, 1, 1, 1], True),
        ([1, 2, 3, 4, 5], True),
        ([5, 4, 3, 2, 1], True),
        ([1, 3, 2, 4], False),
        ([5, 5, 4, 4, 3], True),
        ([1, 1, 2, 2, 3], True),
        ([3, 2, 2, 1, 1], True),
        ([-5, -3, -1, 0, 2], True),
        ([2, 0, -1, -3, -5], True),
        ([-1, -2, -3], True),
        ([-3, -2, -1], True),
        ([0, 0, 0], True),
        ([1, 2, 2, 3], True),
        ([3, 2, 2, 1], True),
        ([1, 2, 1], False),
        ([2, 1, 2], False),
        ([1, 3, 2, 5, 4], False),
        ([10, 5, 3, 1, 0, -5], True),
        ([0, 1, 2, 3, 4, 5], True),
    ])
    def test_monotonic_various_cases(self, input_list, expected):
        assert monotonic(input_list) == expected
    
    def test_monotonic_empty_list(self):
        assert monotonic([]) is True
    
    def test_monotonic_single_element(self):
        assert monotonic([42]) is True
    
    def test_monotonic_two_elements_increasing(self):
        assert monotonic([1, 2]) is True
    
    def test_monotonic_two_elements_decreasing(self):
        assert monotonic([2, 1]) is True
    
    def test_monotonic_two_elements_equal(self):
        assert monotonic([5, 5]) is True
    
    def test_monotonic_increasing_sequence(self):
        assert monotonic([1, 2, 3, 4, 5]) is True
    
    def test_monotonic_decreasing_sequence(self):
        assert monotonic([5, 4, 3, 2, 1]) is True
    
    def test_monotonic_non_monotonic(self):
        assert monotonic([1, 3, 2, 4]) is False
    
    def test_monotonic_with_duplicates_increasing(self):
        assert monotonic([1, 1, 2, 2, 3, 3]) is True
    
    def test_monotonic_with_duplicates_decreasing(self):
        assert monotonic([3, 3, 2, 2, 1, 1]) is True
    
    def test_monotonic_with_negative_numbers_increasing(self):
        assert monotonic([-5, -3, -1, 0, 2]) is True
    
    def test_monotonic_with_negative_numbers_decreasing(self):
        assert monotonic([2, 0, -1, -3, -5]) is True
    
    def test_monotonic_all_same_elements(self):
        assert monotonic([7, 7, 7, 7, 7]) is True
    
    def test_monotonic_large_increasing_list(self):
        assert monotonic(list(range(1000))) is True
    
    def test_monotonic_large_decreasing_list(self):
        assert monotonic(list(range(1000, 0, -1))) is True
    
    def test_monotonic_large_non_monotonic_list(self):
        test_list = list(range(500)) + list(range(500, 0, -1))
        assert monotonic(test_list) is False
    
    def test_monotonic_floats_increasing(self):
        assert monotonic([1.1, 2.2, 3.3, 4.4]) is True
    
    def test_monotonic_floats_decreasing(self):
        assert monotonic([4.4, 3.3, 2.2, 1.1]) is True
    
    def test_monotonic_floats_non_monotonic(self):
        assert monotonic([1.1, 3.3, 2.2, 4.4]) is False
    
    def test_monotonic_mixed_int_float_increasing(self):
        assert monotonic([1, 2.5, 3, 4.5, 5]) is True
    
    def test_monotonic_mixed_int_float_decreasing(self):
        assert monotonic([5, 4.5, 3, 2.5, 1]) is True
