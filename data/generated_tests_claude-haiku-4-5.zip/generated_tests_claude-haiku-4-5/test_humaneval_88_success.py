# Test cases for HumanEval/88
# Generated using Claude API


def sort_array(array):
    """
    Given an array of non-negative integers, return a copy of the given array after sorting,
    you will sort the given array in ascending order if the sum( first index value, last index value) is odd,
    or sort it in descending order if the sum( first index value, last index value) is even.

    Note:
    * don't change the given array.

    Examples:
    * sort_array([]) => []
    * sort_array([5]) => [5]
    * sort_array([2, 4, 3, 0, 1, 5]) => [0, 1, 2, 3, 4, 5]
    * sort_array([2, 4, 3, 0, 1, 5, 6]) => [6, 5, 4, 3, 2, 1, 0]
    """

    return [] if len(array) == 0 else sorted(array, reverse= (array[0]+array[-1]) % 2 == 0) 


# Generated test cases:
import pytest


def sort_array(array):
    return [] if len(array) == 0 else sorted(array, reverse=(array[0]+array[-1]) % 2 == 0)


class TestSortArray:
    
    def test_empty_array(self):
        assert sort_array([]) == []
    
    def test_single_element(self):
        assert sort_array([5]) == [5]
    
    def test_two_elements_even_sum(self):
        result = sort_array([2, 4])
        assert result == [4, 2]
    
    def test_two_elements_odd_sum(self):
        result = sort_array([2, 3])
        assert result == [2, 3]
    
    def test_multiple_elements_even_sum_descending(self):
        result = sort_array([1, 2, 3, 4, 5])
        assert result == [5, 4, 3, 2, 1]
    
    def test_multiple_elements_odd_sum_ascending(self):
        result = sort_array([1, 2, 3, 4, 6])
        assert result == [1, 2, 3, 4, 6]
    
    def test_negative_numbers_even_sum(self):
        result = sort_array([-2, 1, 3, -4])
        assert result == [3, 1, -2, -4]
    
    def test_negative_numbers_odd_sum(self):
        result = sort_array([-2, 1, 3, -3])
        assert result == [-3, -2, 1, 3]
    
    def test_all_same_elements(self):
        result = sort_array([5, 5, 5, 5])
        assert result == [5, 5, 5, 5]
    
    def test_zeros(self):
        result = sort_array([0, 0, 0])
        assert result == [0, 0, 0]
    
    def test_mixed_with_zero_even_sum(self):
        result = sort_array([0, 1, 2, 3])
        assert result == [0, 1, 2, 3]
    
    def test_mixed_with_zero_odd_sum(self):
        result = sort_array([0, 1, 2, 4])
        assert result == [4, 2, 1, 0]
    
    def test_large_numbers_even_sum(self):
        result = sort_array([100, 50, 75, 25])
        assert result == [25, 50, 75, 100]
    
    def test_large_numbers_odd_sum(self):
        result = sort_array([100, 50, 75, 24])
        assert result == [100, 75, 50, 24]
    
    def test_negative_and_positive_even_sum(self):
        result = sort_array([-5, 1, 2, 3, 5])
        assert result == [5, 3, 2, 1, -5]
    
    def test_negative_and_positive_odd_sum(self):
        result = sort_array([-5, 1, 2, 3, 4])
        assert result == [-5, 1, 2, 3, 4]
    
    def test_duplicates_even_sum(self):
        result = sort_array([2, 1, 2, 1, 2])
        assert result == [2, 2, 2, 1, 1]
    
    def test_duplicates_odd_sum(self):
        result = sort_array([2, 1, 2, 1, 3])
        assert result == [1, 1, 2, 2, 3]
    
    def test_first_and_last_same_even(self):
        result = sort_array([4, 1, 2, 3, 4])
        assert result == [4, 4, 3, 2, 1]
    
    def test_first_and_last_same_odd(self):
        result = sort_array([3, 1, 2, 3, 4])
        assert result == [1, 2, 3, 3, 4]
    
    @pytest.mark.parametrize("array,expected", [
        ([1], [1]),
        ([10], [10]),
        ([-5], [-5]),
        ([0], [0]),
    ])
    def test_single_element_parametrized(self, array, expected):
        assert sort_array(array) == expected
    
    @pytest.mark.parametrize("array,expected", [
        ([2, 2], [2, 2]),
        ([1, 1], [1, 1]),
        ([5, 5], [5, 5]),
    ])
    def test_identical_pairs(self, array, expected):
        assert sort_array(array) == expected