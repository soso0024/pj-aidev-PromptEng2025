# Test cases for HumanEval/102
# Generated using Claude API


def choose_num(x, y):
    """This function takes two positive numbers x and y and returns the
    biggest even integer number that is in the range [x, y] inclusive. If 
    there's no such number, then the function should return -1.

    For example:
    choose_num(12, 15) = 14
    choose_num(13, 12) = -1
    """

    if x > y:
        return -1
    if y % 2 == 0:
        return y
    if x == y:
        return -1
    return y - 1


# Generated test cases:
import pytest


def choose_num(x, y):
    if x > y:
        return -1
    if y % 2 == 0:
        return y
    if x == y:
        return -1
    return y - 1


class TestChooseNum:
    
    @pytest.mark.parametrize("x,y,expected", [
        (1, 2, 2),
        (1, 4, 4),
        (5, 10, 10),
        (0, 100, 100),
        (1, 1000000, 1000000),
    ])
    def test_y_is_even(self, x, y, expected):
        assert choose_num(x, y) == expected
    
    @pytest.mark.parametrize("x,y,expected", [
        (1, 3, 2),
        (2, 5, 4),
        (0, 7, 6),
        (10, 15, 14),
        (1, 999999, 999998),
    ])
    def test_y_is_odd_return_y_minus_1(self, x, y, expected):
        assert choose_num(x, y) == expected
    
    @pytest.mark.parametrize("x,y,expected", [
        (5, 5, -1),
        (1, 1, -1),
        (-5, -5, -1),
    ])
    def test_x_equals_y(self, x, y, expected):
        assert choose_num(x, y) == expected
    
    @pytest.mark.parametrize("x,y,expected", [
        (5, 3, -1),
        (10, 5, -1),
        (100, 50, -1),
        (1, 0, -1),
        (5, -5, -1),
    ])
    def test_x_greater_than_y(self, x, y, expected):
        assert choose_num(x, y) == expected
    
    @pytest.mark.parametrize("x,y,expected", [
        (0, 2, 2),
        (0, 1, 0),
        (-5, 4, 4),
        (-10, -2, -2),
        (-1, 0, 0),
    ])
    def test_negative_and_zero_values(self, x, y, expected):
        assert choose_num(x, y) == expected
    
    def test_x_zero_y_even(self):
        assert choose_num(0, 6) == 6
    
    def test_x_zero_y_odd(self):
        assert choose_num(0, 5) == 4
    
    def test_large_even_numbers(self):
        assert choose_num(1000000, 2000000) == 2000000
    
    def test_large_odd_numbers(self):
        assert choose_num(1000000, 2000001) == 2000000
    
    def test_consecutive_numbers_even_y(self):
        assert choose_num(4, 6) == 6
    
    def test_consecutive_numbers_odd_y(self):
        assert choose_num(4, 5) == 4
    
    def test_x_negative_y_positive_even(self):
        assert choose_num(-100, 50) == 50
    
    def test_x_negative_y_positive_odd(self):
        assert choose_num(-100, 51) == 50
    
    def test_both_negative_x_less_than_y(self):
        assert choose_num(-10, -2) == -2
    
    def test_both_negative_x_less_than_y_odd(self):
        assert choose_num(-10, -3) == -4
    
    def test_x_one_less_than_y_even(self):
        assert choose_num(9, 10) == 10
    
    def test_x_one_less_than_y_odd(self):
        assert choose_num(9, 11) == 10
    
    def test_x_equals_y_even_zero(self):
        assert choose_num(0, 0) == 0
    
    def test_x_equals_y_even_hundred(self):
        assert choose_num(100, 100) == 100