# Test cases for HumanEval/17
# Generated using Claude API

from typing import List


def parse_music(music_string: str) -> List[int]:
    """ Input to this function is a string representing musical notes in a special ASCII format.
    Your task is to parse this string and return list of integers corresponding to how many beats does each
    not last.

    Here is a legend:
    'o' - whole note, lasts four beats
    'o|' - half note, lasts two beats
    '.|' - quater note, lasts one beat

    >>> parse_music('o o| .| o| o| .| .| .| .| o o')
    [4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4]
    """

    note_map = {'o': 4, 'o|': 2, '.|': 1}
    return [note_map[x] for x in music_string.split(' ') if x]


# Generated test cases:
import pytest
from typing import List


def parse_music(music_string: str) -> List[int]:
    note_map = {'o': 4, 'o|': 2, '.|': 1}
    return [note_map[x] for x in music_string.split(' ') if x]


class TestParseMusic:
    def test_example_from_docstring(self):
        result = parse_music('o o| .| o| o| .| .| .| .| o o')
        assert result == [4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4]

    def test_single_whole_note(self):
        result = parse_music('o')
        assert result == [4]

    def test_single_half_note(self):
        result = parse_music('o|')
        assert result == [2]

    def test_single_quarter_note(self):
        result = parse_music('.|')
        assert result == [1]

    def test_all_whole_notes(self):
        result = parse_music('o o o o')
        assert result == [4, 4, 4, 4]

    def test_all_half_notes(self):
        result = parse_music('o| o| o|')
        assert result == [2, 2, 2]

    def test_all_quarter_notes(self):
        result = parse_music('.| .| .| .|')
        assert result == [1, 1, 1, 1]

    def test_mixed_notes(self):
        result = parse_music('o o| .| o')
        assert result == [4, 2, 1, 4]

    def test_extra_spaces(self):
        result = parse_music('o  o|  .|')
        assert result == [4, 2, 1]

    def test_leading_space(self):
        result = parse_music(' o o|')
        assert result == [4, 2]

    def test_trailing_space(self):
        result = parse_music('o o| ')
        assert result == [4, 2]

    def test_multiple_consecutive_spaces(self):
        result = parse_music('o   o|   .|')
        assert result == [4, 2, 1]

    def test_two_notes(self):
        result = parse_music('o o|')
        assert result == [4, 2]

    def test_long_sequence(self):
        result = parse_music('o o| .| o o| .| o o| .| o o| .|')
        assert result == [4, 2, 1, 4, 2, 1, 4, 2, 1, 4, 2, 1]

    @pytest.mark.parametrize("music_input,expected", [
        ('o', [4]),
        ('o|', [2]),
        ('.|', [1]),
        ('o o', [4, 4]),
        ('o| o|', [2, 2]),
        ('.| .|', [1, 1]),
        ('o o| .|', [4, 2, 1]),
        ('o| .| o', [2, 1, 4]),
        ('.| o| o', [1, 2, 4]),
    ])
    def test_parametrized_cases(self, music_input, expected):
        assert parse_music(music_input) == expected

    def test_empty_string(self):
        result = parse_music('')
        assert result == []

    def test_only_spaces(self):
        result = parse_music('   ')
        assert result == []

    def test_single_space(self):
        result = parse_music(' ')
        assert result == []
