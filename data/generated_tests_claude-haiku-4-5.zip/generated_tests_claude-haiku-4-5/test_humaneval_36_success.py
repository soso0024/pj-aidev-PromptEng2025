# Test cases for HumanEval/36
# Generated using Claude API



def fizz_buzz(n: int):
    """Return the number of times the digit 7 appears in integers less than n which are divisible by 11 or 13.
    >>> fizz_buzz(50)
    0
    >>> fizz_buzz(78)
    2
    >>> fizz_buzz(79)
    3
    """

    ns = []
    for i in range(n):
        if i % 11 == 0 or i % 13 == 0:
            ns.append(i)
    s = ''.join(list(map(str, ns)))
    ans = 0
    for c in s:
        ans += (c == '7')
    return ans


# Generated test cases:
import pytest


class TestFizzBuzz:
    
    def test_zero(self):
        from test_humaneval_36 import fizz_buzz
        assert fizz_buzz(0) == 0
    
    def test_one(self):
        assert fizz_buzz(1) == 0
    
    def test_small_number_no_multiples(self):
        assert fizz_buzz(10) == 0
    
    def test_includes_zero(self):
        result = fizz_buzz(12)
        assert result == 0
    
    def test_includes_eleven(self):
        result = fizz_buzz(12)
        assert result == 0
    
    def test_includes_thirteen(self):
        result = fizz_buzz(14)
        assert result == 0
    
    def test_includes_twenty_two(self):
        result = fizz_buzz(23)
        assert result == 0
    
    def test_includes_twenty_six(self):
        result = fizz_buzz(27)
        assert result == 0
    
    def test_seventy_in_range(self):
        result = fizz_buzz(71)
        assert result >= 0
    
    def test_multiple_sevens(self):
        result = fizz_buzz(100)
        assert isinstance(result, int)
        assert result >= 0
    
    def test_range_with_77(self):
        result = fizz_buzz(78)
        assert result >= 1
    
    def test_range_with_117(self):
        result = fizz_buzz(118)
        assert result >= 1
    
    def test_range_with_170(self):
        result = fizz_buzz(171)
        assert result >= 1
    
    def test_range_with_171(self):
        result = fizz_buzz(172)
        assert result >= 1
    
    def test_range_with_176(self):
        result = fizz_buzz(177)
        assert result >= 1
    
    def test_range_with_177(self):
        result = fizz_buzz(178)
        assert result >= 1
    
    def test_large_range(self):
        result = fizz_buzz(1000)
        assert isinstance(result, int)
        assert result >= 0
    
    def test_very_large_range(self):
        result = fizz_buzz(10000)
        assert isinstance(result, int)
        assert result >= 0
    
    @pytest.mark.parametrize("n,expected_min", [
        (0, 0),
        (1, 0),
        (11, 0),
        (13, 0),
        (22, 0),
        (26, 0),
        (33, 0),
        (39, 0),
        (44, 0),
        (52, 0),
        (55, 0),
        (65, 0),
        (66, 0),
        (78, 1),
        (117, 1),
        (130, 1),
        (170, 1),
        (171, 1),
        (176, 1),
        (177, 1),
    ])
    def test_parametrized_ranges(self, n, expected_min):
        result = fizz_buzz(n)
        assert result >= expected_min
    
    def test_return_type_is_int(self):
        result = fizz_buzz(50)
        assert isinstance(result, int)
    
    def test_return_is_non_negative(self):
        result = fizz_buzz(200)
        assert result >= 0
    
    def test_consecutive_calls_same_result(self):
        result1 = fizz_buzz(100)
        result2 = fizz_buzz(100)
        assert result1 == result2
    
    def test_increasing_n_increases_or_maintains_result(self):
        result1 = fizz_buzz(50)
        result2 = fizz_buzz(100)
        assert result2 >= result1
    
    def test_specific_case_77(self):
        result = fizz_buzz(78)
        assert result >= 1
    
    def test_specific_case_117(self):
        result = fizz_buzz(118)
        assert result >= 1
    
    def test_specific_case_170_171(self):
        result = fizz_buzz(172)
        assert result >= 1
    
    def test_specific_case_176_177(self):
        result = fizz_buzz(178)
        assert result >= 1