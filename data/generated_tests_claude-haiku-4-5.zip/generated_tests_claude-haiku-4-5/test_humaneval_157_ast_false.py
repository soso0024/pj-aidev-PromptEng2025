# Test cases for HumanEval/157
# Generated using Claude API


def right_angle_triangle(a, b, c):
    '''
    Given the lengths of the three sides of a triangle. Return True if the three
    sides form a right-angled triangle, False otherwise.
    A right-angled triangle is a triangle in which one angle is right angle or 
    90 degree.
    Example:
    right_angle_triangle(3, 4, 5) == True
    right_angle_triangle(1, 2, 3) == False
    '''

    return a*a == b*b + c*c or b*b == a*a + c*c or c*c == a*a + b*b


# Generated test cases:
import pytest


class TestRightAngleTriangle:
    
    @pytest.mark.parametrize("a,b,c,expected", [
        (3, 4, 5, True),
        (5, 3, 4, True),
        (4, 5, 3, True),
        (5, 4, 3, True),
        (3, 5, 4, True),
        (4, 3, 5, True),
        (5, 12, 13, True),
        (13, 5, 12, True),
        (12, 13, 5, True),
        (8, 15, 17, True),
        (17, 8, 15, True),
        (15, 17, 8, True),
        (7, 24, 25, True),
        (25, 7, 24, True),
        (24, 25, 7, True),
        (20, 21, 29, True),
        (29, 20, 21, True),
        (21, 29, 20, True),
        (1, 1, 1, False),
        (1, 2, 3, False),
        (2, 3, 4, False),
        (1, 1, 2, False),
        (5, 5, 5, False),
        (10, 10, 10, False),
        (1, 2, 4, False),
        (3, 3, 3, False),
    ])
    def test_right_angle_triangle(self, a, b, c, expected):
        from test_humaneval_157_ast import right_angle_triangle
        assert right_angle_triangle(a, b, c) == expected
    
    def test_classic_3_4_5_triangle(self):
        assert right_angle_triangle(3, 4, 5) is True
    
    def test_classic_5_12_13_triangle(self):
        assert right_angle_triangle(5, 12, 13) is True
    
    def test_classic_8_15_17_triangle(self):
        assert right_angle_triangle(8, 15, 17) is True
    
    def test_hypotenuse_first_position(self):
        assert right_angle_triangle(5, 3, 4) is True
    
    def test_hypotenuse_second_position(self):
        assert right_angle_triangle(3, 5, 4) is True
    
    def test_hypotenuse_third_position(self):
        assert right_angle_triangle(3, 4, 5) is True
    
    def test_not_right_triangle_1_1_1(self):
        assert right_angle_triangle(1, 1, 1) is False
    
    def test_not_right_triangle_1_2_3(self):
        assert right_angle_triangle(1, 2, 3) is False
    
    def test_not_right_triangle_2_3_4(self):
        assert right_angle_triangle(2, 3, 4) is False
    
    def test_zero_values(self):
        assert right_angle_triangle(0, 0, 0) is True
    
    def test_single_zero(self):
        assert right_angle_triangle(0, 3, 4) is False
    
    def test_single_zero_second_position(self):
        assert right_angle_triangle(3, 0, 4) is False
    
    def test_single_zero_third_position(self):
        assert right_angle_triangle(3, 4, 0) is False
    
    def test_negative_values(self):
        assert right_angle_triangle(-3, -4, -5) is True
    
    def test_negative_and_positive_mix(self):
        assert right_angle_triangle(-3, 4, 5) is True
    
    def test_negative_hypotenuse(self):
        assert right_angle_triangle(3, 4, -5) is True
    
    def test_large_numbers(self):
        assert right_angle_triangle(300, 400, 500) is True
    
    def test_large_numbers_not_triangle(self):
        assert right_angle_triangle(100, 200, 300) is False
    
    def test_float_values(self):
        assert right_angle_triangle(3.0, 4.0, 5.0) is True
    
    def test_float_values_not_triangle(self):
        assert right_angle_triangle(1.5, 2.5, 3.5) is False
    
    def test_very_small_values(self):
        assert right_angle_triangle(0.3, 0.4, 0.5) is True
    
    def test_isosceles_right_triangle(self):
        result = right_angle_triangle(1, 1, 1.414213562373095)
        assert result == True
    
    def test_order_independence_1(self):
        result1 = right_angle_triangle(3, 4, 5)
        result2 = right_angle_triangle(4, 3, 5)
        result3 = right_angle_triangle(5, 3, 4)
        assert result1 == result2 == result3 == True
    
    def test_order_independence_2(self):
        result1 = right_angle_triangle(5, 12, 13)
        result2 = right_angle_triangle(12, 5, 13)
        result3 = right_angle_triangle(13, 5, 12)
        assert result1 == result2 == result3 == True