# Test cases for HumanEval/117
# Generated using Claude API


def select_words(s, n):
    """Given a string s and a natural number n, you have been tasked to implement 
    a function that returns a list of all words from string s that contain exactly 
    n consonants, in order these words appear in the string s.
    If the string s is empty then the function should return an empty list.
    Note: you may assume the input string contains only letters and spaces.
    Examples:
    select_words("Mary had a little lamb", 4) ==> ["little"]
    select_words("Mary had a little lamb", 3) ==> ["Mary", "lamb"]
    select_words("simple white space", 2) ==> []
    select_words("Hello world", 4) ==> ["world"]
    select_words("Uncle sam", 3) ==> ["Uncle"]
    """

    result = []
    for word in s.split():
        n_consonants = 0
        for i in range(0, len(word)):
            if word[i].lower() not in ["a","e","i","o","u"]:
                n_consonants += 1 
        if n_consonants == n:
            result.append(word)
    return result



# Generated test cases:
import pytest


def select_words(s, n):
    """Given a string s and a natural number n, you have been tasked to implement 
    a function that returns a list of all words from string s that contain exactly 
    n consonants, in order these words appear in the string s.
    If the string s is empty then the function should return an empty list.
    Note: you may assume the input string contains only letters and spaces.
    Examples:
    select_words("Mary had a little lamb", 4) ==> ["little"]
    select_words("Mary had a little lamb", 3) ==> ["Mary", "lamb"]
    select_words("simple white space", 2) ==> []
    select_words("Hello world", 4) ==> ["world"]
    select_words("Uncle sam", 3) ==> ["Uncle"]
    """

    result = []
    for word in s.split():
        n_consonants = 0
        for i in range(0, len(word)):
            if word[i].lower() not in ["a","e","i","o","u"]:
                n_consonants += 1 
        if n_consonants == n:
            result.append(word)
    return result


class TestSelectWords:
    
    def test_example_1(self):
        assert select_words("Mary had a little lamb", 4) == ["little"]
    
    def test_example_2(self):
        assert select_words("Mary had a little lamb", 3) == ["Mary", "lamb"]
    
    def test_example_3(self):
        assert select_words("simple white space", 2) == []
    
    def test_example_4(self):
        assert select_words("Hello world", 4) == ["world"]
    
    def test_example_5(self):
        assert select_words("Uncle sam", 3) == ["Uncle"]
    
    def test_empty_string(self):
        assert select_words("", 0) == []
    
    def test_empty_string_nonzero_n(self):
        assert select_words("", 5) == []
    
    def test_single_word_matching(self):
        assert select_words("hello", 3) == ["hello"]
    
    def test_single_word_not_matching(self):
        assert select_words("hello", 2) == []
    
    def test_all_vowels(self):
        assert select_words("aeiou", 0) == ["aeiou"]
    
    def test_all_consonants(self):
        assert select_words("bcdfg", 5) == ["bcdfg"]
    
    def test_multiple_spaces(self):
        assert select_words("hello  world", 3) == ["hello"]
    
    def test_uppercase_letters(self):
        assert select_words("HELLO WORLD", 3) == ["HELLO"]
    
    def test_mixed_case(self):
        assert select_words("HeLLo WoRLd", 3) == ["HeLLo"]
    
    def test_single_letter_words(self):
        assert select_words("a b c d e", 0) == ["a", "e"]
    
    def test_single_letter_words_consonants(self):
        assert select_words("a b c d e", 1) == ["b", "c", "d"]
    
    def test_no_matching_words(self):
        assert select_words("cat dog bird", 5) == []
    
    def test_all_matching_words(self):
        assert select_words("cat dog", 2) == ["cat", "dog"]
    
    def test_zero_consonants(self):
        assert select_words("a e i o u", 0) == ["a", "e", "i", "o", "u"]
    
    def test_large_n(self):
        assert select_words("hello world", 100) == []
    
    def test_word_with_y(self):
        assert select_words("yes my", 2) == ["yes", "my"]
    
    def test_word_with_y_as_consonant(self):
        assert select_words("gym", 3) == ["gym"]
    
    def test_preserves_order(self):
        assert select_words("apple banana cherry date", 3) == ["apple", "banana"]
    
    def test_repeated_words(self):
        assert select_words("hello hello world", 3) == ["hello", "hello"]
    
    def test_single_consonant_word(self):
        assert select_words("b", 1) == ["b"]
    
    def test_complex_sentence(self):
        result = select_words("The quick brown fox jumps", 3)
        assert "quick" in result
        assert len(result) >= 1
    
    def test_n_equals_zero(self):
        assert select_words("aaa eee", 0) == ["aaa", "eee"]
    
    def test_words_with_apostrophes_treated_as_consonants(self):
        result = select_words("don't can't", 3)
        assert isinstance(result, list)
    
    @pytest.mark.parametrize("s,n,expected", [
        ("Mary had a little lamb", 4, ["little"]),
        ("Mary had a little lamb", 3, ["Mary", "lamb"]),
        ("simple white space", 2, []),
        ("Hello world", 4, ["world"]),
        ("Uncle sam", 3, ["Uncle"]),
        ("", 0, []),
        ("a", 0, ["a"]),
        ("b", 1, ["b"]),
        ("aeiou", 0, ["aeiou"]),
        ("bcdfg", 5, ["bcdfg"]),
    ])
    def test_parametrized_cases(self, s, n, expected):
        assert select_words(s, n) == expected