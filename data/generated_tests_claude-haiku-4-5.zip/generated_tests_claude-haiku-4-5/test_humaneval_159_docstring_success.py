# Test cases for HumanEval/159
# Generated using Claude API


def eat(number, need, remaining):
    """
    You're a hungry rabbit, and you already have eaten a certain number of carrots,
    but now you need to eat more carrots to complete the day's meals.
    you should return an array of [ total number of eaten carrots after your meals,
                                    the number of carrots left after your meals ]
    if there are not enough remaining carrots, you will eat all remaining carrots, but will still be hungry.
    
    Example:
    * eat(5, 6, 10) -> [11, 4]
    * eat(4, 8, 9) -> [12, 1]
    * eat(1, 10, 10) -> [11, 0]
    * eat(2, 11, 5) -> [7, 0]
    
    Variables:
    @number : integer
        the number of carrots that you have eaten.
    @need : integer
        the number of carrots that you need to eat.
    @remaining : integer
        the number of remaining carrots thet exist in stock
    
    Constrain:
    * 0 <= number <= 1000
    * 0 <= need <= 1000
    * 0 <= remaining <= 1000

    Have fun :)
    """

    if(need <= remaining):
        return [ number + need , remaining-need ]
    else:
        return [ number + remaining , 0]


# Generated test cases:
import pytest


def eat(number, need, remaining):
    if(need <= remaining):
        return [ number + need , remaining-need ]
    else:
        return [ number + remaining , 0]


@pytest.mark.parametrize("number,need,remaining,expected", [
    (5, 6, 10, [11, 4]),
    (4, 8, 9, [12, 1]),
    (1, 10, 10, [11, 0]),
    (2, 11, 5, [7, 0]),
])
def test_eat_examples(number, need, remaining, expected):
    assert eat(number, need, remaining) == expected


def test_eat_enough_carrots():
    assert eat(5, 6, 10) == [11, 4]


def test_eat_not_enough_carrots():
    assert eat(2, 11, 5) == [7, 0]


def test_eat_exact_need():
    assert eat(1, 10, 10) == [11, 0]


def test_eat_zero_need():
    assert eat(5, 0, 10) == [5, 10]


def test_eat_zero_remaining():
    assert eat(5, 10, 0) == [5, 0]


def test_eat_zero_number():
    assert eat(0, 5, 10) == [5, 5]


def test_eat_all_zeros():
    assert eat(0, 0, 0) == [0, 0]


def test_eat_large_numbers():
    assert eat(1000, 1000, 1000) == [2000, 0]


def test_eat_need_greater_than_remaining():
    assert eat(10, 20, 5) == [15, 0]


def test_eat_need_less_than_remaining():
    assert eat(10, 5, 20) == [15, 15]


def test_eat_one_carrot_need():
    assert eat(5, 1, 10) == [6, 9]


def test_eat_one_carrot_remaining():
    assert eat(5, 10, 1) == [6, 0]


def test_eat_need_equals_remaining():
    assert eat(3, 7, 7) == [10, 0]


def test_eat_need_one_more_than_remaining():
    assert eat(3, 8, 7) == [10, 0]


def test_eat_high_number_low_need():
    assert eat(500, 1, 100) == [501, 99]


def test_eat_low_number_high_need():
    assert eat(1, 999, 1000) == [1000, 1]


def test_eat_boundary_values():
    assert eat(1000, 0, 1000) == [1000, 1000]
    assert eat(0, 1000, 1000) == [1000, 0]
    assert eat(1000, 1000, 1000) == [2000, 0]