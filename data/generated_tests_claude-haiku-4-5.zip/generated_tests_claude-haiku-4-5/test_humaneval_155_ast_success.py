# Test cases for HumanEval/155
# Generated using Claude API


def even_odd_count(num):
    """Given an integer. return a tuple that has the number of even and odd digits respectively.

     Example:
        even_odd_count(-12) ==> (1, 1)
        even_odd_count(123) ==> (1, 2)
    """

    even_count = 0
    odd_count = 0
    for i in str(abs(num)):
        if int(i)%2==0:
            even_count +=1
        else:
            odd_count +=1
    return (even_count, odd_count)


# Generated test cases:
import pytest


def even_odd_count(num):
    even_count = 0
    odd_count = 0
    for i in str(abs(num)):
        if int(i)%2==0:
            even_count +=1
        else:
            odd_count +=1
    return (even_count, odd_count)


@pytest.mark.parametrize("num,expected", [
    (0, (1, 0)),
    (1, (0, 1)),
    (2, (1, 0)),
    (10, (1, 1)),
    (123, (1, 2)),
    (246, (3, 0)),
    (135, (0, 3)),
    (2468, (4, 0)),
    (13579, (0, 5)),
    (1234567890, (5, 5)),
])
def test_even_odd_count_positive(num, expected):
    assert even_odd_count(num) == expected


@pytest.mark.parametrize("num,expected", [
    (-1, (0, 1)),
    (-10, (1, 1)),
    (-123, (1, 2)),
    (-246, (3, 0)),
    (-135, (0, 3)),
    (-2468, (4, 0)),
    (-13579, (0, 5)),
])
def test_even_odd_count_negative(num, expected):
    assert even_odd_count(num) == expected


def test_even_odd_count_single_digit_even():
    assert even_odd_count(2) == (1, 0)
    assert even_odd_count(4) == (1, 0)
    assert even_odd_count(6) == (1, 0)
    assert even_odd_count(8) == (1, 0)


def test_even_odd_count_single_digit_odd():
    assert even_odd_count(1) == (0, 1)
    assert even_odd_count(3) == (0, 1)
    assert even_odd_count(5) == (0, 1)
    assert even_odd_count(7) == (0, 1)
    assert even_odd_count(9) == (0, 1)


def test_even_odd_count_all_even_digits():
    assert even_odd_count(2468) == (4, 0)
    assert even_odd_count(20) == (2, 0)
    assert even_odd_count(2222) == (4, 0)


def test_even_odd_count_all_odd_digits():
    assert even_odd_count(13579) == (0, 5)
    assert even_odd_count(111) == (0, 3)
    assert even_odd_count(9) == (0, 1)


def test_even_odd_count_mixed_digits():
    assert even_odd_count(12345) == (2, 3)
    assert even_odd_count(98765) == (2, 3)
    assert even_odd_count(24681357) == (4, 4)


def test_even_odd_count_large_numbers():
    assert even_odd_count(123456789) == (4, 5)
    assert even_odd_count(9876543210) == (5, 5)


def test_even_odd_count_return_type():
    result = even_odd_count(123)
    assert isinstance(result, tuple)
    assert len(result) == 2
    assert isinstance(result[0], int)
    assert isinstance(result[1], int)


def test_even_odd_count_zero():
    assert even_odd_count(0) == (1, 0)


def test_even_odd_count_negative_zero():
    assert even_odd_count(-0) == (1, 0)


def test_even_odd_count_symmetry_positive_negative():
    positive_result = even_odd_count(12345)
    negative_result = even_odd_count(-12345)
    assert positive_result == negative_result


def test_even_odd_count_repeated_digits():
    assert even_odd_count(1111) == (0, 4)
    assert even_odd_count(2222) == (4, 0)
    assert even_odd_count(1212) == (2, 2)


def test_even_odd_count_leading_zeros_effect():
    assert even_odd_count(100) == (2, 1)
    assert even_odd_count(1000) == (3, 1)
    assert even_odd_count(101) == (1, 2)