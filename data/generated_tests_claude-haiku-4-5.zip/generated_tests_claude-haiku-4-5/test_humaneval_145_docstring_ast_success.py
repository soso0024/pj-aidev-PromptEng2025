# Test cases for HumanEval/145
# Generated using Claude API


def order_by_points(nums):
    """
    Write a function which sorts the given list of integers
    in ascending order according to the sum of their digits.
    Note: if there are several items with similar sum of their digits,
    order them based on their index in original list.

    For example:
    >>> order_by_points([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    >>> order_by_points([]) == []
    """

    def digits_sum(n):
        neg = 1
        if n < 0: n, neg = -1 * n, -1 
        n = [int(i) for i in str(n)]
        n[0] = n[0] * neg
        return sum(n)
    return sorted(nums, key=digits_sum)


# Generated test cases:
import pytest


def order_by_points(nums):
    def digits_sum(n):
        neg = 1
        if n < 0: n, neg = -1 * n, -1 
        n = [int(i) for i in str(n)]
        n[0] = n[0] * neg
        return sum(n)
    return sorted(nums, key=digits_sum)


class TestOrderByPoints:
    
    def test_empty_list(self):
        assert order_by_points([]) == []
    
    def test_single_element(self):
        assert order_by_points([5]) == [5]
    
    def test_single_digit_positive(self):
        assert order_by_points([3, 1, 2]) == [1, 2, 3]
    
    def test_single_digit_negative(self):
        assert order_by_points([-3, -1, -2]) == [-3, -2, -1]
    
    def test_mixed_single_digits(self):
        assert order_by_points([5, -3, 2, -1]) == [-3, -1, 2, 5]
    
    def test_multi_digit_positive(self):
        assert order_by_points([10, 11, 12]) == [10, 11, 12]
    
    def test_multi_digit_negative(self):
        assert order_by_points([-10, -11, -12]) == [-10, -11, -12]
    
    def test_example_case(self):
        assert order_by_points([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    
    def test_same_digit_sum_preserves_order(self):
        assert order_by_points([10, 1, 100]) == [10, 1, 100]
    
    def test_same_digit_sum_negative(self):
        assert order_by_points([-10, -1, -100]) == [-10, -1, -100]
    
    def test_zero(self):
        assert order_by_points([0]) == [0]
    
    def test_zero_with_others(self):
        assert order_by_points([5, 0, 3]) == [0, 3, 5]
    
    def test_large_numbers(self):
        assert order_by_points([999, 1, 100]) == [1, 100, 999]
    
    def test_large_negative_numbers(self):
        assert order_by_points([-999, -1, -100]) == [-1, -100, -999]
    
    def test_mixed_large_numbers(self):
        result = order_by_points([123, -123, 456, -456])
        assert result == [-123, 123, -456, 456]
    
    def test_duplicates(self):
        assert order_by_points([5, 5, 3, 3]) == [3, 3, 5, 5]
    
    def test_duplicates_with_negatives(self):
        assert order_by_points([-5, 5, -5, 5]) == [-5, -5, 5, 5]
    
    def test_digit_sum_calculation_positive(self):
        assert order_by_points([19, 28, 37]) == [19, 28, 37]
    
    def test_digit_sum_calculation_negative(self):
        assert order_by_points([-19, -28, -37]) == [-37, -28, -19]
    
    def test_complex_mixed_case(self):
        result = order_by_points([100, -100, 50, -50, 1, -1])
        assert result == [-50, -100, -1, 100, 1, 50]
    
    def test_preserves_original_order_for_equal_sums(self):
        assert order_by_points([11, 20, 101]) == [11, 20, 101]
    
    def test_negative_preserves_original_order_for_equal_sums(self):
        assert order_by_points([-11, -20, -101]) == [-20, -11, -101]
    
    def test_two_elements(self):
        assert order_by_points([15, 24]) == [15, 24]
    
    def test_two_elements_reverse(self):
        assert order_by_points([24, 15]) == [24, 15]
    
    def test_all_same_digit_sum(self):
        assert order_by_points([10, 1, 100, 1000]) == [10, 1, 100, 1000]
    
    def test_negative_all_same_digit_sum(self):
        assert order_by_points([-10, -1, -100, -1000]) == [-10, -1, -100, -1000]


@pytest.mark.parametrize("input_list,expected", [
    ([], []),
    ([1], [1]),
    ([1, 2, 3], [1, 2, 3]),
    ([3, 2, 1], [1, 2, 3]),
    ([-1, -2, -3], [-3, -2, -1]),
    ([1, 11, -1, -11, -12], [-1, -11, 1, -12, 11]),
    ([0], [0]),
    ([0, 1, -1], [-1, 0, 1]),
    ([10, 11, 12], [10, 11, 12]),
    ([12, 11, 10], [10, 11, 12]),
])
def test_order_by_points_parametrized(input_list, expected):
    assert order_by_points(input_list) == expected