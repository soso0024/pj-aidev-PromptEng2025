# Test cases for HumanEval/89
# Generated using Claude API


def encrypt(s):
    """Create a function encrypt that takes a string as an argument and
    returns a string encrypted with the alphabet being rotated. 
    The alphabet should be rotated in a manner such that the letters 
    shift down by two multiplied to two places.
    For example:
    encrypt('hi') returns 'lm'
    encrypt('asdfghjkl') returns 'ewhjklnop'
    encrypt('gf') returns 'kj'
    encrypt('et') returns 'ix'
    """

    d = 'abcdefghijklmnopqrstuvwxyz'
    out = ''
    for c in s:
        if c in d:
            out += d[(d.index(c)+2*2) % 26]
        else:
            out += c
    return out


# Generated test cases:
import pytest


def encrypt(s):
    d = 'abcdefghijklmnopqrstuvwxyz'
    out = ''
    for c in s:
        if c in d:
            out += d[(d.index(c)+2*2) % 26]
        else:
            out += c
    return out


@pytest.mark.parametrize("input_str,expected", [
    ("hi", "lm"),
    ("asdfghjkl", "ewhjklnop"),
    ("gf", "kj"),
    ("et", "ix"),
])
def test_encrypt_basic_cases(input_str, expected):
    assert encrypt(input_str) == expected


def test_encrypt_single_character():
    assert encrypt("a") == "e"
    assert encrypt("b") == "f"
    assert encrypt("z") == "d"


def test_encrypt_empty_string():
    assert encrypt("") == ""


def test_encrypt_all_alphabet():
    result = encrypt("abcdefghijklmnopqrstuvwxyz")
    assert result == "efghijklmnopqrstuvwxyzabcd"


def test_encrypt_with_uppercase():
    assert encrypt("A") == "A"
    assert encrypt("HI") == "HI"
    assert encrypt("Hi") == "Hm"


def test_encrypt_with_numbers():
    assert encrypt("a1b2c3") == "e1f2g3"
    assert encrypt("123") == "123"


def test_encrypt_with_special_characters():
    assert encrypt("a!b@c#") == "e!f@g#"
    assert encrypt("hello, world!") == "lipps, asvph!"


def test_encrypt_with_spaces():
    assert encrypt("a b c") == "e f g"
    assert encrypt("hello world") == "lipps asvph"


def test_encrypt_wrapping():
    assert encrypt("xyz") == "bcd"
    assert encrypt("yz") == "cd"
    assert encrypt("z") == "d"


def test_encrypt_repeated_characters():
    assert encrypt("aaa") == "eee"
    assert encrypt("zzz") == "ddd"


def test_encrypt_mixed_content():
    assert encrypt("The Quick Brown Fox!") == "Tli Qymgo Bvsar Fsb!"


def test_encrypt_long_string():
    long_string = "abcdefghijklmnopqrstuvwxyz" * 3
    expected = "efghijklmnopqrstuvwxyzabcd" * 3
    assert encrypt(long_string) == expected


def test_encrypt_punctuation_only():
    assert encrypt("!@#$%^&*()") == "!@#$%^&*()"


def test_encrypt_newlines_and_tabs():
    assert encrypt("a\nb\tc") == "e\nf\tg"


def test_encrypt_vowels():
    assert encrypt("aeiou") == "eimsy"


def test_encrypt_consonants():
    assert encrypt("bcdfg") == "fghjk"