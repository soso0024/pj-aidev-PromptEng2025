# Test cases for HumanEval/14
# Generated using Claude API

from typing import List


def all_prefixes(string: str) -> List[str]:
    """ Return list of all prefixes from shortest to longest of the input string
    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """

    result = []

    for i in range(len(string)):
        result.append(string[:i+1])
    return result


# Generated test cases:
import pytest
from typing import List


def all_prefixes(string: str) -> List[str]:
    result = []
    for i in range(len(string)):
        result.append(string[:i+1])
    return result


class TestAllPrefixes:
    def test_basic_example(self):
        assert all_prefixes('abc') == ['a', 'ab', 'abc']

    def test_single_character(self):
        assert all_prefixes('a') == ['a']

    def test_empty_string(self):
        assert all_prefixes('') == []

    def test_two_characters(self):
        assert all_prefixes('ab') == ['a', 'ab']

    def test_long_string(self):
        assert all_prefixes('hello') == ['h', 'he', 'hel', 'hell', 'hello']

    def test_repeated_characters(self):
        assert all_prefixes('aaa') == ['a', 'aa', 'aaa']

    def test_special_characters(self):
        assert all_prefixes('!@#') == ['!', '!@', '!@#']

    def test_numbers_as_string(self):
        assert all_prefixes('123') == ['1', '12', '123']

    def test_mixed_alphanumeric(self):
        assert all_prefixes('a1b2') == ['a', 'a1', 'a1b', 'a1b2']

    def test_spaces_in_string(self):
        assert all_prefixes('a b') == ['a', 'a ', 'a b']

    def test_unicode_characters(self):
        assert all_prefixes('café') == ['c', 'ca', 'caf', 'café']

    def test_return_type_is_list(self):
        result = all_prefixes('test')
        assert isinstance(result, list)

    def test_all_elements_are_strings(self):
        result = all_prefixes('abc')
        assert all(isinstance(item, str) for item in result)

    def test_prefixes_are_ordered(self):
        result = all_prefixes('abcd')
        for i in range(len(result) - 1):
            assert len(result[i]) < len(result[i + 1])

    def test_each_prefix_is_substring_from_start(self):
        string = 'testing'
        result = all_prefixes(string)
        for prefix in result:
            assert string.startswith(prefix)

    def test_last_element_equals_original_string(self):
        string = 'hello'
        result = all_prefixes(string)
        assert result[-1] == string

    def test_result_length_equals_string_length(self):
        string = 'python'
        result = all_prefixes(string)
        assert len(result) == len(string)

    @pytest.mark.parametrize("input_str,expected", [
        ('x', ['x']),
        ('xy', ['x', 'xy']),
        ('xyz', ['x', 'xy', 'xyz']),
        ('a', ['a']),
        ('ab', ['a', 'ab']),
    ])
    def test_various_strings(self, input_str, expected):
        assert all_prefixes(input_str) == expected

    def test_whitespace_only(self):
        assert all_prefixes('   ') == [' ', '  ', '   ']

    def test_newline_character(self):
        assert all_prefixes('a\nb') == ['a', 'a\n', 'a\nb']

    def test_tab_character(self):
        assert all_prefixes('a\tb') == ['a', 'a\t', 'a\tb']
