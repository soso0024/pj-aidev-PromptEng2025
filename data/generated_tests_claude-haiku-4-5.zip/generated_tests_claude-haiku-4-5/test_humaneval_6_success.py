# Test cases for HumanEval/6
# Generated using Claude API

from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """

    def parse_paren_group(s):
        depth = 0
        max_depth = 0
        for c in s:
            if c == '(':
                depth += 1
                max_depth = max(depth, max_depth)
            else:
                depth -= 1

        return max_depth

    return [parse_paren_group(x) for x in paren_string.split(' ') if x]


# Generated test cases:
import pytest
from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    def parse_paren_group(s):
        depth = 0
        max_depth = 0
        for c in s:
            if c == '(':
                depth += 1
                max_depth = max(depth, max_depth)
            else:
                depth -= 1

        return max_depth

    return [parse_paren_group(x) for x in paren_string.split(' ') if x]


class TestParseNestedParens:
    
    def test_single_group_single_paren(self):
        assert parse_nested_parens("()") == [1]
    
    def test_single_group_nested_parens(self):
        assert parse_nested_parens("(())") == [2]
    
    def test_single_group_deeply_nested(self):
        assert parse_nested_parens("(((())))") == [4]
    
    def test_multiple_groups_single_depth(self):
        assert parse_nested_parens("() () ()") == [1, 1, 1]
    
    def test_multiple_groups_varying_depth(self):
        assert parse_nested_parens("() (()) ((()))") == [1, 2, 3]
    
    def test_multiple_groups_mixed_depth(self):
        assert parse_nested_parens("(()) () ((())) ()") == [2, 1, 3, 1]
    
    def test_empty_string(self):
        assert parse_nested_parens("") == []
    
    def test_single_space(self):
        assert parse_nested_parens(" ") == []
    
    def test_multiple_spaces_between_groups(self):
        assert parse_nested_parens("()  ()") == [1, 1]
    
    def test_leading_space(self):
        assert parse_nested_parens(" ()") == [1]
    
    def test_trailing_space(self):
        assert parse_nested_parens("() ") == [1]
    
    def test_leading_and_trailing_spaces(self):
        assert parse_nested_parens(" () () ") == [1, 1]
    
    def test_complex_nesting_pattern(self):
        assert parse_nested_parens("(()()) ((())) (()) ()") == [2, 3, 2, 1]
    
    def test_single_open_paren(self):
        assert parse_nested_parens("(") == [1]
    
    def test_single_close_paren(self):
        assert parse_nested_parens(")") == [0]
    
    def test_unbalanced_parens_more_open(self):
        assert parse_nested_parens("(((") == [3]
    
    def test_unbalanced_parens_more_close(self):
        assert parse_nested_parens(")))") == [0]
    
    def test_mixed_unbalanced(self):
        assert parse_nested_parens("(()") == [2]
    
    def test_close_before_open(self):
        assert parse_nested_parens(")(") == [0]
    
    def test_alternating_parens(self):
        assert parse_nested_parens("()()()") == [1]
    
    def test_nested_with_alternating(self):
        assert parse_nested_parens("(())() ()(())") == [2, 2]
    
    def test_very_deep_nesting(self):
        deep_string = "(" * 10 + ")" * 10
        assert parse_nested_parens(deep_string) == [10]
    
    def test_multiple_very_deep_groups(self):
        group1 = "(" * 5 + ")" * 5
        group2 = "(" * 3 + ")" * 3
        assert parse_nested_parens(f"{group1} {group2}") == [5, 3]
    
    @pytest.mark.parametrize("input_str,expected", [
        ("()", [1]),
        ("(())", [2]),
        ("() ()", [1, 1]),
        ("(()) (())", [2, 2]),
        ("((()))", [3]),
        ("() () () ()", [1, 1, 1, 1]),
        ("()()()", [1]),
        ("(()(()))", [3]),
    ])
    def test_parametrized_valid_cases(self, input_str, expected):
        assert parse_nested_parens(input_str) == expected
    
    @pytest.mark.parametrize("input_str,expected", [
        ("", []),
        ("   ", []),
        ("(", [1]),
        (")", [0]),
        (")))((", [0]),
    ])
    def test_parametrized_edge_cases(self, input_str, expected):
        assert parse_nested_parens(input_str) == expected
