# Test cases for HumanEval/144
# Generated using Claude API


def simplify(x, n):
    """Your task is to implement a function that will simplify the expression
    x * n. The function returns True if x * n evaluates to a whole number and False
    otherwise. Both x and n, are string representation of a fraction, and have the following format,
    <numerator>/<denominator> where both numerator and denominator are positive whole numbers.

    You can assume that x, and n are valid fractions, and do not have zero as denominator.

    simplify("1/5", "5/1") = True
    simplify("1/6", "2/1") = False
    simplify("7/10", "10/2") = False
    """

    a, b = x.split("/")
    c, d = n.split("/")
    numerator = int(a) * int(c)
    denom = int(b) * int(d)
    if (numerator/denom == int(numerator/denom)):
        return True
    return False


# Generated test cases:
import pytest


class TestSimplify:
    
    @pytest.mark.parametrize("x,n,expected", [
        ("1/2", "2/1", True),
        ("1/2", "4/1", True),
        ("2/3", "3/2", True),
        ("1/3", "3/1", True),
        ("5/1", "1/5", True),
        ("10/2", "1/5", True),
    ])
    def test_simplify_returns_true(self, x, n, expected):
        from test_humaneval_144 import simplify
        assert simplify(x, n) == expected
    
    @pytest.mark.parametrize("x,n,expected", [
        ("1/2", "1/2", False),
        ("1/3", "1/2", False),
        ("2/5", "3/7", False),
        ("1/4", "1/3", False),
        ("3/5", "2/3", False),
    ])
    def test_simplify_returns_false(self, x, n, expected):
        assert simplify(x, n) == expected
    
    def test_simplify_with_one_numerator(self):
        assert simplify("1/1", "1/1") == True
    
    def test_simplify_with_large_numbers(self):
        assert simplify("100/10", "1/10") == True
    
    def test_simplify_with_large_numbers_false(self):
        assert simplify("100/7", "1/10") == False
    
    def test_simplify_result_is_integer(self):
        assert simplify("6/2", "4/3") == True
    
    def test_simplify_result_is_not_integer(self):
        assert simplify("1/2", "1/3") == False
    
    def test_simplify_with_negative_numbers(self):
        assert simplify("-1/2", "2/1") == True
    
    def test_simplify_with_both_negative(self):
        assert simplify("-2/3", "-3/2") == True
    
    def test_simplify_with_negative_denominator(self):
        assert simplify("1/2", "4/-1") == True
    
    def test_simplify_zero_numerator(self):
        assert simplify("0/1", "5/1") == True
    
    def test_simplify_with_same_fractions(self):
        assert simplify("2/4", "2/4") == False
    
    def test_simplify_with_reciprocals(self):
        assert simplify("3/4", "4/3") == True
    
    def test_simplify_with_unit_fractions(self):
        assert simplify("1/5", "5/1") == True
    
    def test_simplify_complex_case_true(self):
        assert simplify("7/2", "8/7") == True
    
    def test_simplify_complex_case_false(self):
        assert simplify("7/2", "3/7") == False