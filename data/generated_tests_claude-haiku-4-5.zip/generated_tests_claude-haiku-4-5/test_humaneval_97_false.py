# Test cases for HumanEval/97
# Generated using Claude API


def multiply(a, b):
    """Complete the function that takes two integers and returns 
    the product of their unit digits.
    Assume the input is always valid.
    Examples:
    multiply(148, 412) should return 16.
    multiply(19, 28) should return 72.
    multiply(2020, 1851) should return 0.
    multiply(14,-15) should return 20.
    """

    return abs(a % 10) * abs(b % 10)


# Generated test cases:
import pytest


class TestMultiply:
    
    @pytest.mark.parametrize("a,b,expected", [
        (0, 0, 0),
        (1, 1, 1),
        (5, 3, 15),
        (7, 8, 56),
        (9, 9, 81),
    ])
    def test_positive_single_digits(self, a, b, expected):
        from test_humaneval_97 import multiply
        assert multiply(a, b) == expected
    
    @pytest.mark.parametrize("a,b,expected", [
        (-1, -1, 1),
        (-5, -3, 15),
        (-7, -8, 56),
        (-9, -9, 81),
    ])
    def test_negative_single_digits(self, a, b, expected):
        assert multiply(a, b) == expected
    
    @pytest.mark.parametrize("a,b,expected", [
        (5, -3, 15),
        (-5, 3, 15),
        (7, -8, 56),
        (-7, 8, 56),
    ])
    def test_mixed_sign_single_digits(self, a, b, expected):
        assert multiply(a, b) == expected
    
    @pytest.mark.parametrize("a,b,expected", [
        (10, 10, 0),
        (11, 12, 2),
        (23, 45, 15),
        (99, 99, 81),
        (100, 200, 0),
    ])
    def test_multi_digit_numbers(self, a, b, expected):
        assert multiply(a, b) == expected
    
    @pytest.mark.parametrize("a,b,expected", [
        (-10, -10, 0),
        (-11, -12, 2),
        (-23, -45, 15),
        (-99, -99, 81),
        (-100, -200, 0),
    ])
    def test_negative_multi_digit_numbers(self, a, b, expected):
        assert multiply(a, b) == expected
    
    @pytest.mark.parametrize("a,b,expected", [
        (0, 5, 0),
        (5, 0, 0),
        (0, -5, 0),
        (-5, 0, 0),
        (0, 0, 0),
    ])
    def test_zero_cases(self, a, b, expected):
        assert multiply(a, b) == expected
    
    @pytest.mark.parametrize("a,b,expected", [
        (10, 0, 0),
        (20, 30, 0),
        (100, 50, 0),
        (1000, 2000, 0),
    ])
    def test_multiples_of_ten(self, a, b, expected):
        assert multiply(a, b) == expected
    
    @pytest.mark.parametrize("a,b,expected", [
        (1234, 5678, 32),
        (9876, 5432, 12),
        (111, 222, 2),
        (505, 707, 35),
    ])
    def test_large_numbers(self, a, b, expected):
        assert multiply(a, b) == expected
    
    @pytest.mark.parametrize("a,b,expected", [
        (-1234, 5678, 32),
        (9876, -5432, 12),
        (-111, -222, 2),
        (-505, 707, 35),
    ])
    def test_large_numbers_with_negatives(self, a, b, expected):
        assert multiply(a, b) == expected
    
    def test_commutative_property(self):
        assert multiply(3, 7) == multiply(7, 3)
        assert multiply(-5, 8) == multiply(8, -5)
        assert multiply(12, 34) == multiply(34, 12)
    
    def test_with_integers_only(self):
        assert multiply(3, 7) == 21
        assert multiply(5, 8) == 40
    
    def test_edge_case_nine(self):
        assert multiply(9, 9) == 81
        assert multiply(-9, -9) == 81
        assert multiply(19, 29) == 81
        assert multiply(-19, -29) == 81