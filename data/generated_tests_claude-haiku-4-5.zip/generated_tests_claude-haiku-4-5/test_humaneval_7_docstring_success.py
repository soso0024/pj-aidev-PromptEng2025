# Test cases for HumanEval/7
# Generated using Claude API

from typing import List


def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """ Filter an input list of strings only for ones that contain given substring
    >>> filter_by_substring([], 'a')
    []
    >>> filter_by_substring(['abc', 'bacd', 'cde', 'array'], 'a')
    ['abc', 'bacd', 'array']
    """

    return [x for x in strings if substring in x]


# Generated test cases:
import pytest
from typing import List


def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    return [x for x in strings if substring in x]


class TestFilterBySubstring:
    
    def test_empty_list(self):
        assert filter_by_substring([], 'a') == []
    
    def test_empty_substring(self):
        assert filter_by_substring(['abc', 'def', 'ghi'], '') == ['abc', 'def', 'ghi']
    
    def test_no_matches(self):
        assert filter_by_substring(['abc', 'def', 'ghi'], 'z') == []
    
    def test_single_match(self):
        assert filter_by_substring(['abc', 'def', 'ghi'], 'a') == ['abc']
    
    def test_multiple_matches(self):
        assert filter_by_substring(['abc', 'bacd', 'cde', 'array'], 'a') == ['abc', 'bacd', 'array']
    
    def test_substring_at_start(self):
        assert filter_by_substring(['apple', 'application', 'banana'], 'app') == ['apple', 'application']
    
    def test_substring_at_end(self):
        assert filter_by_substring(['cat', 'bat', 'rat', 'dog'], 'at') == ['cat', 'bat', 'rat']
    
    def test_substring_in_middle(self):
        assert filter_by_substring(['hello', 'world', 'help'], 'ell') == ['hello']
    
    def test_case_sensitive(self):
        assert filter_by_substring(['Apple', 'apple', 'APPLE'], 'app') == ['apple']
    
    def test_substring_equals_string(self):
        assert filter_by_substring(['abc', 'def', 'abc'], 'abc') == ['abc', 'abc']
    
    def test_single_character_substring(self):
        assert filter_by_substring(['a', 'b', 'c', 'ab', 'bc'], 'b') == ['b', 'ab', 'bc']
    
    def test_single_string_in_list(self):
        assert filter_by_substring(['hello'], 'ell') == ['hello']
    
    def test_single_string_no_match(self):
        assert filter_by_substring(['hello'], 'xyz') == []
    
    def test_special_characters_in_substring(self):
        assert filter_by_substring(['hello-world', 'hello_world', 'helloworld'], '-') == ['hello-world']
    
    def test_special_characters_in_strings(self):
        assert filter_by_substring(['test@email.com', 'user@domain.org', 'noatsign'], '@') == ['test@email.com', 'user@domain.org']
    
    def test_numbers_in_substring(self):
        assert filter_by_substring(['abc123', 'def456', 'ghi789'], '123') == ['abc123']
    
    def test_whitespace_in_substring(self):
        assert filter_by_substring(['hello world', 'helloworld', 'hello  world'], ' ') == ['hello world', 'hello  world']
    
    def test_whitespace_only_substring(self):
        assert filter_by_substring(['a b', 'ab', 'a  b'], ' ') == ['a b', 'a  b']
    
    def test_duplicate_strings(self):
        assert filter_by_substring(['abc', 'abc', 'def', 'abc'], 'ab') == ['abc', 'abc', 'abc']
    
    def test_long_substring(self):
        assert filter_by_substring(['thequickbrownfox', 'quickbrownfox', 'thequick'], 'quickbrown') == ['thequickbrownfox', 'quickbrownfox']
    
    @pytest.mark.parametrize("strings,substring,expected", [
        (['abc', 'bacd', 'cde', 'array'], 'a', ['abc', 'bacd', 'array']),
        ([], 'a', []),
        (['test'], 'test', ['test']),
        (['a', 'b', 'c'], 'x', []),
        (['xyz', 'xyzabc', 'abcxyz'], 'xyz', ['xyz', 'xyzabc', 'abcxyz']),
    ])
    def test_parametrized(self, strings, substring, expected):
        assert filter_by_substring(strings, substring) == expected