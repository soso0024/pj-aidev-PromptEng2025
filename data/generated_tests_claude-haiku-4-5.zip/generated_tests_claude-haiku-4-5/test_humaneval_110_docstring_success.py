# Test cases for HumanEval/110
# Generated using Claude API


def exchange(lst1, lst2):
    """In this problem, you will implement a function that takes two lists of numbers,
    and determines whether it is possible to perform an exchange of elements
    between them to make lst1 a list of only even numbers.
    There is no limit on the number of exchanged elements between lst1 and lst2.
    If it is possible to exchange elements between the lst1 and lst2 to make
    all the elements of lst1 to be even, return "YES".
    Otherwise, return "NO".
    For example:
    exchange([1, 2, 3, 4], [1, 2, 3, 4]) => "YES"
    exchange([1, 2, 3, 4], [1, 5, 3, 4]) => "NO"
    It is assumed that the input lists will be non-empty.
    """

    odd = 0
    even = 0
    for i in lst1:
        if i%2 == 1:
            odd += 1
    for i in lst2:
        if i%2 == 0:
            even += 1
    if even >= odd:
        return "YES"
    return "NO"
            


# Generated test cases:
import pytest


def exchange(lst1, lst2):
    odd = 0
    even = 0
    for i in lst1:
        if i%2 == 1:
            odd += 1
    for i in lst2:
        if i%2 == 0:
            even += 1
    if even >= odd:
        return "YES"
    return "NO"


class TestExchange:
    
    def test_example_yes(self):
        assert exchange([1, 2, 3, 4], [1, 2, 3, 4]) == "YES"
    
    def test_example_no(self):
        assert exchange([1, 2, 3, 4], [1, 5, 3, 4]) == "NO"
    
    def test_all_even_lst1(self):
        assert exchange([2, 4, 6, 8], [1, 3, 5, 7]) == "YES"
    
    def test_all_odd_lst1_enough_even_lst2(self):
        assert exchange([1, 3, 5], [2, 4, 6, 8]) == "YES"
    
    def test_all_odd_lst1_not_enough_even_lst2(self):
        assert exchange([1, 3, 5, 7], [2, 4, 1, 3]) == "NO"
    
    def test_single_element_odd_lst1_even_lst2(self):
        assert exchange([1], [2]) == "YES"
    
    def test_single_element_odd_lst1_odd_lst2(self):
        assert exchange([1], [3]) == "NO"
    
    def test_single_element_even_lst1(self):
        assert exchange([2], [1]) == "YES"
    
    def test_empty_lst2_all_even_lst1(self):
        assert exchange([2, 4], []) == "YES"
    
    def test_empty_lst2_has_odd_lst1(self):
        assert exchange([1, 2], []) == "NO"
    
    def test_all_odd_both_lists(self):
        assert exchange([1, 3, 5], [1, 3, 5]) == "NO"
    
    def test_all_even_both_lists(self):
        assert exchange([2, 4, 6], [2, 4, 6]) == "YES"
    
    def test_exact_match_odd_to_even(self):
        assert exchange([1, 3], [2, 4]) == "YES"
    
    def test_more_even_than_odd_needed(self):
        assert exchange([1, 3, 5], [2, 4, 6, 8, 10]) == "YES"
    
    def test_one_less_even_than_odd(self):
        assert exchange([1, 3, 5], [2, 4]) == "NO"
    
    def test_large_numbers(self):
        assert exchange([1000001, 1000003], [1000000, 1000002]) == "YES"
    
    def test_negative_odd_numbers(self):
        assert exchange([-1, -3, 2], [-2, -4]) == "YES"
    
    def test_negative_even_numbers(self):
        assert exchange([1, 3], [-2, -4]) == "YES"
    
    def test_zero_is_even(self):
        assert exchange([1, 3], [0, 2]) == "YES"
    
    def test_mixed_positive_negative(self):
        assert exchange([-1, 1, 3], [-2, 2, 4]) == "YES"
    
    def test_single_odd_single_even(self):
        assert exchange([1], [2]) == "YES"
    
    def test_multiple_odds_insufficient_evens(self):
        assert exchange([1, 3, 5, 7, 9], [2, 4]) == "NO"
    
    def test_zero_odd_numbers_in_lst1(self):
        assert exchange([2, 4, 6], [1, 3, 5]) == "YES"
    
    @pytest.mark.parametrize("lst1,lst2,expected", [
        ([1, 2, 3, 4], [1, 2, 3, 4], "YES"),
        ([1, 2, 3, 4], [1, 5, 3, 4], "NO"),
        ([1], [2], "YES"),
        ([1], [1], "NO"),
        ([2], [1], "YES"),
        ([1, 3, 5], [2, 4, 6], "YES"),
        ([1, 3, 5, 7], [2, 4], "NO"),
    ])
    def test_parametrized(self, lst1, lst2, expected):
        assert exchange(lst1, lst2) == expected
