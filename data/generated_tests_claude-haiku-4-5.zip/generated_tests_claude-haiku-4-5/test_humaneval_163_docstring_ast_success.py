# Test cases for HumanEval/163
# Generated using Claude API


def generate_integers(a, b):
    """
    Given two positive integers a and b, return the even digits between a
    and b, in ascending order.

    For example:
    generate_integers(2, 8) => [2, 4, 6, 8]
    generate_integers(8, 2) => [2, 4, 6, 8]
    generate_integers(10, 14) => []
    """

    lower = max(2, min(a, b))
    upper = min(8, max(a, b))

    return [i for i in range(lower, upper+1) if i % 2 == 0]


# Generated test cases:
import pytest


def generate_integers(a, b):
    lower = max(2, min(a, b))
    upper = min(8, max(a, b))
    return [i for i in range(lower, upper+1) if i % 2 == 0]


class TestGenerateIntegers:
    
    @pytest.mark.parametrize("a,b,expected", [
        (2, 8, [2, 4, 6, 8]),
        (8, 2, [2, 4, 6, 8]),
        (10, 14, []),
        (1, 3, [2]),
        (3, 5, [4]),
        (5, 7, [6]),
        (7, 9, [8]),
        (2, 2, [2]),
        (4, 4, [4]),
        (6, 6, [6]),
        (8, 8, [8]),
        (1, 1, []),
        (9, 9, []),
        (0, 0, []),
        (100, 200, []),
        (2, 3, [2]),
        (3, 4, [4]),
        (4, 5, [4]),
        (5, 6, [6]),
        (6, 7, [6]),
        (7, 8, [8]),
        (1, 8, [2, 4, 6, 8]),
        (2, 9, [2, 4, 6, 8]),
        (0, 10, [2, 4, 6, 8]),
        (1, 100, [2, 4, 6, 8]),
    ])
    def test_generate_integers_various_inputs(self, a, b, expected):
        assert generate_integers(a, b) == expected
    
    def test_generate_integers_basic_ascending(self):
        result = generate_integers(2, 8)
        assert result == [2, 4, 6, 8]
    
    def test_generate_integers_basic_descending(self):
        result = generate_integers(8, 2)
        assert result == [2, 4, 6, 8]
    
    def test_generate_integers_no_even_digits(self):
        result = generate_integers(10, 14)
        assert result == []
    
    def test_generate_integers_single_even_digit(self):
        result = generate_integers(2, 2)
        assert result == [2]
    
    def test_generate_integers_all_even_digits(self):
        result = generate_integers(2, 8)
        assert len(result) == 4
        assert all(x % 2 == 0 for x in result)
    
    def test_generate_integers_ascending_order(self):
        result = generate_integers(8, 2)
        assert result == sorted(result)
    
    def test_generate_integers_below_range(self):
        result = generate_integers(0, 1)
        assert result == []
    
    def test_generate_integers_above_range(self):
        result = generate_integers(9, 15)
        assert result == []
    
    def test_generate_integers_large_numbers(self):
        result = generate_integers(1000, 2000)
        assert result == []
    
    def test_generate_integers_negative_numbers(self):
        result = generate_integers(-5, 5)
        assert result == [2, 4]
    
    def test_generate_integers_single_digit_odd(self):
        result = generate_integers(3, 3)
        assert result == []
    
    def test_generate_integers_boundary_2(self):
        result = generate_integers(2, 2)
        assert result == [2]
    
    def test_generate_integers_boundary_8(self):
        result = generate_integers(8, 8)
        assert result == [8]
    
    def test_generate_integers_between_2_and_8(self):
        result = generate_integers(3, 7)
        assert result == [4, 6]
    
    def test_generate_integers_result_is_list(self):
        result = generate_integers(2, 8)
        assert isinstance(result, list)
    
    def test_generate_integers_result_contains_only_even(self):
        result = generate_integers(2, 8)
        for num in result:
            assert num % 2 == 0
    
    def test_generate_integers_result_in_range(self):
        result = generate_integers(2, 8)
        for num in result:
            assert 2 <= num <= 8
    
    def test_generate_integers_empty_result_properties(self):
        result = generate_integers(10, 14)
        assert result == []
        assert len(result) == 0
    
    def test_generate_integers_reversed_order_same_result(self):
        result1 = generate_integers(2, 8)
        result2 = generate_integers(8, 2)
        assert result1 == result2