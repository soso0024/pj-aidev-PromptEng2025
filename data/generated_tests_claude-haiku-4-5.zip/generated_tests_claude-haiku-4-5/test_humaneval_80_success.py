# Test cases for HumanEval/80
# Generated using Claude API


def is_happy(s):
    """You are given a string s.
    Your task is to check if the string is happy or not.
    A string is happy if its length is at least 3 and every 3 consecutive letters are distinct
    For example:
    is_happy(a) => False
    is_happy(aa) => False
    is_happy(abcd) => True
    is_happy(aabb) => False
    is_happy(adb) => True
    is_happy(xyy) => False
    """

    if len(s) < 3:
      return False

    for i in range(len(s) - 2):
      
      if s[i] == s[i+1] or s[i+1] == s[i+2] or s[i] == s[i+2]:
        return False
    return True


# Generated test cases:
import pytest


def is_happy(s):
    if len(s) < 3:
      return False

    for i in range(len(s) - 2):
      
      if s[i] == s[i+1] or s[i+1] == s[i+2] or s[i] == s[i+2]:
        return False
    return True


class TestIsHappy:
    
    @pytest.mark.parametrize("input_str,expected", [
        ("abc", True),
        ("abcd", True),
        ("abcde", True),
        ("abcdef", True),
    ])
    def test_happy_strings(self, input_str, expected):
        assert is_happy(input_str) == expected
    
    @pytest.mark.parametrize("input_str,expected", [
        ("aa", False),
        ("ab", False),
        ("a", False),
        ("", False),
    ])
    def test_strings_less_than_three(self, input_str, expected):
        assert is_happy(input_str) == expected
    
    @pytest.mark.parametrize("input_str,expected", [
        ("aab", False),
        ("aba", False),
        ("baa", False),
        ("aaa", False),
    ])
    def test_three_char_with_duplicates(self, input_str, expected):
        assert is_happy(input_str) == expected
    
    @pytest.mark.parametrize("input_str,expected", [
        ("abab", False),
        ("abac", False),
    ])
    def test_longer_strings_with_duplicates(self, input_str, expected):
        assert is_happy(input_str) == expected
    
    @pytest.mark.parametrize("input_str,expected", [
        ("abcdefg", True),
        ("abcdefgh", True),
        ("abcdefghij", True),
    ])
    def test_long_happy_strings(self, input_str, expected):
        assert is_happy(input_str) == True
    
    @pytest.mark.parametrize("input_str,expected", [
        ("aabbcc", False),
        ("abbacd", False),
        ("abccde", False),
    ])
    def test_consecutive_duplicates(self, input_str, expected):
        assert is_happy(input_str) == expected
    
    @pytest.mark.parametrize("input_str,expected", [
        ("xyz", True),
        ("xyzabc", True),
        ("abcxyz", True),
    ])
    def test_different_characters(self, input_str, expected):
        assert is_happy(input_str) == True
    
    @pytest.mark.parametrize("input_str,expected", [
        ("123", True),
        ("1234", True),
        ("121", False),
        ("112", False),
    ])
    def test_numeric_strings(self, input_str, expected):
        assert is_happy(input_str) == expected
    
    @pytest.mark.parametrize("input_str,expected", [
        ("!@#", True),
        ("!@!#", False),
        ("!@#$", True),
    ])
    def test_special_characters(self, input_str, expected):
        assert is_happy(input_str) == expected
    
    def test_exactly_three_chars_happy(self):
        assert is_happy("abc") == True
    
    def test_exactly_three_chars_unhappy_first_two_same(self):
        assert is_happy("aac") == False
    
    def test_exactly_three_chars_unhappy_last_two_same(self):
        assert is_happy("abb") == False
    
    def test_exactly_three_chars_unhappy_first_and_last_same(self):
        assert is_happy("aba") == False
    
    def test_four_chars_all_different(self):
        assert is_happy("abcd") == True
    
    def test_four_chars_duplicate_at_position_zero_and_two(self):
        assert is_happy("abac") == False
    
    def test_four_chars_duplicate_at_position_one_and_three(self):
        assert is_happy("abab") == False
    
    def test_case_sensitive(self):
        assert is_happy("AbC") == True
        assert is_happy("AAc") == False