# Test cases for HumanEval/110
# Generated using Claude API


def exchange(lst1, lst2):
    """In this problem, you will implement a function that takes two lists of numbers,
    and determines whether it is possible to perform an exchange of elements
    between them to make lst1 a list of only even numbers.
    There is no limit on the number of exchanged elements between lst1 and lst2.
    If it is possible to exchange elements between the lst1 and lst2 to make
    all the elements of lst1 to be even, return "YES".
    Otherwise, return "NO".
    For example:
    exchange([1, 2, 3, 4], [1, 2, 3, 4]) => "YES"
    exchange([1, 2, 3, 4], [1, 5, 3, 4]) => "NO"
    It is assumed that the input lists will be non-empty.
    """

    odd = 0
    even = 0
    for i in lst1:
        if i%2 == 1:
            odd += 1
    for i in lst2:
        if i%2 == 0:
            even += 1
    if even >= odd:
        return "YES"
    return "NO"
            


# Generated test cases:
import pytest


class TestExchange:
    
    def test_empty_lists(self):
        from test_humaneval_110_ast import exchange
        assert exchange([], []) == "YES"
    
    def test_empty_lst1(self):
        assert exchange([], [2, 4, 6]) == "YES"
    
    def test_empty_lst2(self):
        assert exchange([1, 3, 5], []) == "NO"
    
    def test_no_odd_in_lst1(self):
        assert exchange([2, 4, 6], [1, 3, 5]) == "YES"
    
    def test_no_even_in_lst2(self):
        assert exchange([1, 3, 5], [1, 3, 5]) == "NO"
    
    def test_equal_odd_and_even(self):
        assert exchange([1, 3], [2, 4]) == "YES"
    
    def test_more_even_than_odd(self):
        assert exchange([1], [2, 4, 6]) == "YES"
    
    def test_more_odd_than_even(self):
        assert exchange([1, 3, 5], [2]) == "NO"
    
    def test_single_odd_single_even(self):
        assert exchange([1], [2]) == "YES"
    
    def test_single_odd_no_even(self):
        assert exchange([1], [1]) == "NO"
    
    def test_multiple_odds_multiple_evens_equal(self):
        assert exchange([1, 3, 5, 7], [2, 4, 6, 8]) == "YES"
    
    def test_multiple_odds_multiple_evens_more_even(self):
        assert exchange([1, 3], [2, 4, 6, 8]) == "YES"
    
    def test_multiple_odds_multiple_evens_less_even(self):
        assert exchange([1, 3, 5, 7], [2, 4]) == "NO"
    
    def test_negative_odd_numbers(self):
        assert exchange([-1, -3], [2, 4]) == "YES"
    
    def test_negative_even_numbers(self):
        assert exchange([1, 3], [-2, -4]) == "YES"
    
    def test_mixed_positive_negative_odd(self):
        assert exchange([1, -1, 3, -3], [2, 4]) == "NO"
    
    def test_mixed_positive_negative_even(self):
        assert exchange([1, 3], [2, -2, 4, -4]) == "YES"
    
    def test_zero_in_lst1(self):
        assert exchange([0, 1, 3], [2, 4]) == "YES"
    
    def test_zero_in_lst2(self):
        assert exchange([1, 3], [0, 2, 4]) == "YES"
    
    def test_zero_in_both(self):
        assert exchange([0, 1], [0, 2]) == "YES"
    
    def test_large_numbers(self):
        assert exchange([1000001, 1000003], [1000000, 1000002]) == "YES"
    
    def test_all_same_odd(self):
        assert exchange([1, 1, 1], [2, 2]) == "NO"
    
    def test_all_same_even(self):
        assert exchange([1, 1], [2, 2, 2]) == "YES"
    
    def test_lst1_all_even_lst2_all_odd(self):
        assert exchange([2, 4, 6], [1, 3, 5]) == "YES"
    
    def test_lst1_all_odd_lst2_all_even(self):
        assert exchange([1, 3, 5], [2, 4, 6]) == "YES"
    
    def test_lst1_all_odd_lst2_all_odd(self):
        assert exchange([1, 3, 5], [1, 3, 5]) == "NO"
    
    def test_lst1_all_even_lst2_all_even(self):
        assert exchange([2, 4, 6], [2, 4, 6]) == "YES"
    
    def test_one_element_each_odd_even(self):
        assert exchange([1], [2]) == "YES"
    
    def test_one_element_each_odd_odd(self):
        assert exchange([1], [1]) == "NO"
    
    def test_one_element_each_even_even(self):
        assert exchange([2], [2]) == "YES"
    
    def test_one_element_each_even_odd(self):
        assert exchange([2], [1]) == "YES"


@pytest.mark.parametrize("lst1,lst2,expected", [
    ([], [], "YES"),
    ([1], [2], "YES"),
    ([1, 3], [2, 4], "YES"),
    ([1, 3, 5], [2], "NO"),
    ([2, 4], [1, 3], "YES"),
    ([1, 1, 1], [2, 2], "NO"),
    ([-1, -3], [2, 4], "YES"),
    ([0, 1], [0, 2], "YES"),
])
def test_exchange_parametrized(lst1, lst2, expected):
    assert exchange(lst1, lst2) == expected