# Test cases for HumanEval/10
# Generated using Claude API



def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """ Find the shortest palindrome that begins with a supplied string.
    Algorithm idea is simple:
    - Find the longest postfix of supplied string that is a palindrome.
    - Append to the end of the string reverse of a string prefix that comes before the palindromic suffix.
    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    """

    if not string:
        return ''

    beginning_of_suffix = 0

    while not is_palindrome(string[beginning_of_suffix:]):
        beginning_of_suffix += 1

    return string + string[:beginning_of_suffix][::-1]


# Generated test cases:
import pytest


def is_palindrome(string: str) -> bool:
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    if not string:
        return ''

    beginning_of_suffix = 0

    while not is_palindrome(string[beginning_of_suffix:]):
        beginning_of_suffix += 1

    return string + string[:beginning_of_suffix][::-1]


class TestMakePalindrome:
    
    def test_empty_string(self):
        assert make_palindrome('') == ''
    
    def test_single_character(self):
        assert make_palindrome('a') == 'a'
    
    def test_already_palindrome(self):
        assert make_palindrome('aba') == 'aba'
    
    def test_already_palindrome_even_length(self):
        assert make_palindrome('abba') == 'abba'
    
    def test_single_character_repeated(self):
        assert make_palindrome('aaa') == 'aaa'
    
    def test_two_same_characters(self):
        assert make_palindrome('aa') == 'aa'
    
    def test_two_different_characters(self):
        result = make_palindrome('ab')
        assert is_palindrome(result)
        assert result.startswith('ab')
    
    def test_simple_non_palindrome(self):
        result = make_palindrome('abc')
        assert is_palindrome(result)
        assert result.startswith('abc')
    
    def test_non_palindrome_four_chars(self):
        result = make_palindrome('abcd')
        assert is_palindrome(result)
        assert result.startswith('abcd')
    
    def test_result_is_palindrome_simple(self):
        result = make_palindrome('race')
        assert is_palindrome(result)
    
    def test_result_is_palindrome_complex(self):
        result = make_palindrome('hello')
        assert is_palindrome(result)
    
    def test_result_starts_with_original(self):
        original = 'test'
        result = make_palindrome(original)
        assert result.startswith(original)
    
    def test_result_starts_with_original_empty(self):
        original = ''
        result = make_palindrome(original)
        assert result.startswith(original)
    
    def test_result_starts_with_original_palindrome(self):
        original = 'racecar'
        result = make_palindrome(original)
        assert result.startswith(original)
    
    @pytest.mark.parametrize("input_str,expected", [
        ('a', 'a'),
        ('aa', 'aa'),
        ('aba', 'aba'),
        ('abba', 'abba'),
        ('racecar', 'racecar'),
    ])
    def test_palindromes_unchanged(self, input_str, expected):
        assert make_palindrome(input_str) == expected
    
    @pytest.mark.parametrize("input_str", [
        'ab',
        'abc',
        'abcd',
        'race',
        'hello',
        'world',
        'python',
    ])
    def test_result_is_always_palindrome(self, input_str):
        result = make_palindrome(input_str)
        assert is_palindrome(result)
    
    def test_minimal_addition_ab(self):
        result = make_palindrome('ab')
        assert result == 'aba'
    
    def test_minimal_addition_abc(self):
        result = make_palindrome('abc')
        assert result == 'abcba'
    
    def test_minimal_addition_abcd(self):
        result = make_palindrome('abcd')
        assert result == 'abcdcba'
    
    def test_long_string(self):
        result = make_palindrome('abcdefghij')
        assert is_palindrome(result)
        assert result.startswith('abcdefghij')
    
    def test_repeated_characters(self):
        result = make_palindrome('aaab')
        assert is_palindrome(result)
    
    def test_numbers_as_string(self):
        result = make_palindrome('12345')
        assert is_palindrome(result)
        assert result.startswith('12345')
    
    def test_special_characters(self):
        result = make_palindrome('a!b@c')
        assert is_palindrome(result)
        assert result.startswith('a!b@c')
    
    def test_spaces_in_string(self):
        result = make_palindrome('a b c')
        assert is_palindrome(result)
        assert result.startswith('a b c')
    
    def test_mixed_case(self):
        result = make_palindrome('AbC')
        assert is_palindrome(result)
        assert result.startswith('AbC')
    
    def test_unicode_characters(self):
        result = make_palindrome('café')
        assert is_palindrome(result)
        assert result.startswith('café')
    
    def test_result_length_reasonable(self):
        original = 'test'
        result = make_palindrome(original)
        assert len(result) <= 2 * len(original)
    
    def test_result_length_reasonable_long(self):
        original = 'abcdefghijklmnop'
        result = make_palindrome(original)
        assert len(result) <= 2 * len(original)
