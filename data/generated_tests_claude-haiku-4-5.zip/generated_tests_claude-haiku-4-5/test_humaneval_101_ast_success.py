# Test cases for HumanEval/101
# Generated using Claude API


def words_string(s):
    """
    You will be given a string of words separated by commas or spaces. Your task is
    to split the string into words and return an array of the words.
    
    For example:
    words_string("Hi, my name is John") == ["Hi", "my", "name", "is", "John"]
    words_string("One, two, three, four, five, six") == ["One", "two", "three", "four", "five", "six"]
    """

    if not s:
        return []

    s_list = []

    for letter in s:
        if letter == ',':
            s_list.append(' ')
        else:
            s_list.append(letter)

    s_list = "".join(s_list)
    return s_list.split()


# Generated test cases:
import pytest


def words_string(s):
    if not s:
        return []

    s_list = []

    for letter in s:
        if letter == ',':
            s_list.append(' ')
        else:
            s_list.append(letter)

    s_list = "".join(s_list)
    return s_list.split()


class TestWordsString:
    
    def test_empty_string(self):
        assert words_string("") == []
    
    def test_none_input(self):
        assert words_string(None) == []
    
    def test_single_word(self):
        assert words_string("hello") == ["hello"]
    
    def test_words_with_commas(self):
        assert words_string("hello,world") == ["hello", "world"]
    
    def test_multiple_commas(self):
        assert words_string("a,b,c,d") == ["a", "b", "c", "d"]
    
    def test_comma_separated_words(self):
        assert words_string("This,is,a,test") == ["This", "is", "a", "test"]
    
    def test_comma_at_start(self):
        assert words_string(",hello") == ["hello"]
    
    def test_comma_at_end(self):
        assert words_string("hello,") == ["hello"]
    
    def test_multiple_consecutive_commas(self):
        assert words_string("hello,,world") == ["hello", "world"]
    
    def test_only_commas(self):
        assert words_string(",,,") == []
    
    def test_words_with_spaces_and_commas(self):
        assert words_string("hello, world") == ["hello", "world"]
    
    def test_single_character(self):
        assert words_string("a") == ["a"]
    
    def test_single_comma(self):
        assert words_string(",") == []
    
    def test_complex_sentence_with_commas(self):
        assert words_string("Hello,world,how,are,you") == ["Hello", "world", "how", "are", "you"]
    
    def test_words_with_numbers(self):
        assert words_string("123,456,789") == ["123", "456", "789"]
    
    def test_mixed_alphanumeric(self):
        assert words_string("abc123,def456,ghi789") == ["abc123", "def456", "ghi789"]
    
    def test_special_characters_with_commas(self):
        assert words_string("hello!,world?") == ["hello!", "world?"]
    
    def test_spaces_between_words(self):
        assert words_string("hello world") == ["hello", "world"]
    
    def test_tabs_and_commas(self):
        assert words_string("hello\t,world") == ["hello", "world"]
    
    def test_newlines_and_commas(self):
        assert words_string("hello\n,world") == ["hello", "world"]
    
    def test_long_string_with_many_commas(self):
        result = words_string("a,b,c,d,e,f,g,h,i,j")
        assert result == ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j"]
    
    def test_unicode_characters(self):
        assert words_string("café,naïve") == ["café", "naïve"]
    
    def test_leading_trailing_spaces(self):
        assert words_string("  hello,world  ") == ["hello", "world"]
    
    def test_multiple_spaces_between_words(self):
        assert words_string("hello    world") == ["hello", "world"]


@pytest.mark.parametrize("input_str,expected", [
    ("", []),
    ("hello", ["hello"]),
    ("hello,world", ["hello", "world"]),
    ("a,b,c", ["a", "b", "c"]),
    (",hello", ["hello"]),
    ("hello,", ["hello"]),
    ("hello,,world", ["hello", "world"]),
    (",,,", []),
    ("hello, world", ["hello", "world"]),
    ("a", ["a"]),
    (",", []),
])
def test_words_string_parametrized(input_str, expected):
    assert words_string(input_str) == expected
