# Test cases for HumanEval/160
# Generated using Claude API


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and 
    the second list is a list of integers. Use the two given lists to build the algebric 
    expression and return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + ) 
    Subtraction ( - ) 
    Multiplication ( * ) 
    Floor division ( // ) 
    Exponentiation ( ** ) 

    Example:
    operator['+', '*', '-']
    array = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9

    Note:
        The length of operator list is equal to the length of operand list minus one.
        Operand is a list of of non-negative integers.
        Operator list has at least one operator, and operand list has at least two operands.

    """

    expression = str(operand[0])
    for oprt, oprn in zip(operator, operand[1:]):
        expression+= oprt + str(oprn)
    return eval(expression)


# Generated test cases:
import pytest


@pytest.mark.parametrize("operator,operand,expected", [
    (['+'], [1, 2], 3),
    (['-'], [5, 3], 2),
    (['*'], [4, 3], 12),
    (['//', ], [10, 3], 3),
    (['**'], [2, 3], 8),
    (['+', '*', '-'], [2, 3, 4, 5], 9),
    (['+', '+'], [1, 2, 3], 6),
    (['*', '*'], [2, 3, 4], 24),
    (['-', '-'], [10, 3, 2], 5),
    (['+', '-', '*'], [1, 2, 3, 4], -9),
    (['**', '+'], [2, 3, 4], 12),
    (['//', '+'], [20, 3, 5], 11),
    (['+', '*', '//', '-', '**'], [1, 2, 3, 4, 5, 2], -23),
    (['+'], [0, 0], 0),
    (['*'], [0, 5], 0),
    (['*'], [5, 0], 0),
    (['+'], [100, 200], 300),
    (['**'], [10, 2], 100),
    (['-'], [0, 1], -1),
    (['//', ], [100, 10], 10),
    (['+', '+', '+'], [1, 1, 1, 1], 4),
    (['*', '+', '*'], [2, 3, 4, 5], 26),
    (['-', '*', '+'], [10, 2, 3, 4], 8),
    (['**', '**'], [2, 2, 2], 16),
    (['+', '-'], [5, 3, 2], 6),
])
def test_do_algebra(operator, operand, expected):
    def do_algebra(operator, operand):
        expression = str(operand[0])
        for oprt, oprn in zip(operator, operand[1:]):
            expression += oprt + str(oprn)
        return eval(expression)
    
    assert do_algebra(operator, operand) == expected


def test_do_algebra_single_addition():
    def do_algebra(operator, operand):
        expression = str(operand[0])
        for oprt, oprn in zip(operator, operand[1:]):
            expression += oprt + str(oprn)
        return eval(expression)
    
    assert do_algebra(['+'], [5, 3]) == 8


def test_do_algebra_single_subtraction():
    def do_algebra(operator, operand):
        expression = str(operand[0])
        for oprt, oprn in zip(operator, operand[1:]):
            expression += oprt + str(oprn)
        return eval(expression)
    
    assert do_algebra(['-'], [10, 4]) == 6


def test_do_algebra_single_multiplication():
    def do_algebra(operator, operand):
        expression = str(operand[0])
        for oprt, oprn in zip(operator, operand[1:]):
            expression += oprt + str(oprn)
        return eval(expression)
    
    assert do_algebra(['*'], [6, 7]) == 42


def test_do_algebra_single_floor_division():
    def do_algebra(operator, operand):
        expression = str(operand[0])
        for oprt, oprn in zip(operator, operand[1:]):
            expression += oprt + str(oprn)
        return eval(expression)
    
    assert do_algebra(['//'], [15, 4]) == 3


def test_do_algebra_single_exponentiation():
    def do_algebra(operator, operand):
        expression = str(operand[0])
        for oprt, oprn in zip(operator, operand[1:]):
            expression += oprt + str(oprn)
        return eval(expression)
    
    assert do_algebra(['**'], [3, 4]) == 81


def test_do_algebra_complex_expression():
    def do_algebra(operator, operand):
        expression = str(operand[0])
        for oprt, oprn in zip(operator, operand[1:]):
            expression += oprt + str(oprn)
        return eval(expression)
    
    assert do_algebra(['+', '*', '-'], [2, 3, 4, 5]) == 9


def test_do_algebra_order_of_operations():
    def do_algebra(operator, operand):
        expression = str(operand[0])
        for oprt, oprn in zip(operator, operand[1:]):
            expression += oprt + str(oprn)
        return eval(expression)
    
    assert do_algebra(['+', '*'], [1, 2, 3]) == 7


def test_do_algebra_with_zeros():
    def do_algebra(operator, operand):
        expression = str(operand[0])
        for oprt, oprn in zip(operator, operand[1:]):
            expression += oprt + str(oprn)
        return eval(expression)
    
    assert do_algebra(['+', '*'], [0, 5, 3]) == 15


def test_do_algebra_large_numbers():
    def do_algebra(operator, operand):
        expression = str(operand[0])
        for oprt, oprn in zip(operator, operand[1:]):
            expression += oprt + str(oprn)
        return eval(expression)
    
    assert do_algebra(['*', '+'], [1000, 2000, 500]) == 2000500


def test_do_algebra_exponentiation_precedence():
    def do_algebra(operator, operand):
        expression = str(operand[0])
        for oprt, oprn in zip(operator, operand[1:]):
            expression += oprt + str(oprn)
        return eval(expression)
    
    assert do_algebra(['**', '*'], [2, 3, 4]) == 32


def test_do_algebra_division_and_subtraction():
    def do_algebra(operator, operand):
        expression = str(operand[0])
        for oprt, oprn in zip(operator, operand[1:]):
            expression += oprt + str(oprn)
        return eval(expression)
    
    assert do_algebra(['//', '-'], [20, 3, 2]) == 4


def test_do_algebra_multiple_operations():
    def do_algebra(operator, operand):
        expression = str(operand[0])
        for oprt, oprn in zip(operator, operand[1:]):
            expression += oprt + str(oprn)
        return eval(expression)
    
    assert do_algebra(['+', '-', '*', '//'], [1, 2, 3, 4, 5]) == 1


def test_do_algebra_all_additions():
    def do_algebra(operator, operand):
        expression = str(operand[0])
        for oprt, oprn in zip(operator, operand[1:]):
            expression += oprt + str(oprn)
        return eval(expression)
    
    assert do_algebra(['+', '+', '+', '+'], [1, 1, 1, 1, 1]) == 5


def test_do_algebra_all_multiplications():
    def do_algebra(operator, operand):
        expression = str(operand[0])
        for oprt, oprn in zip(operator, operand[1:]):
            expression += oprt + str(oprn)
        return eval(expression)
    
    assert do_algebra(['*', '*', '*'], [2, 2, 2, 2]) == 16


def test_do_algebra_mixed_operations_complex():
    def do_algebra(operator, operand):
        expression = str(operand[0])
        for oprt, oprn in zip(operator, operand[1:]):
            expression += oprt + str(oprn)
        return eval(expression)
    
    assert do_algebra(['+', '*', '-', '//'], [10, 5, 2, 3, 2]) == 19