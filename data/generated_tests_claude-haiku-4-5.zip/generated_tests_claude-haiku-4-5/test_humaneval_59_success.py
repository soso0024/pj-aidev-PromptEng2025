# Test cases for HumanEval/59
# Generated using Claude API



def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """

    def is_prime(k):
        if k < 2:
            return False
        for i in range(2, k - 1):
            if k % i == 0:
                return False
        return True
    largest = 1
    for j in range(2, n + 1):
        if n % j == 0 and is_prime(j):
            largest = max(largest, j)
    return largest


# Generated test cases:
import pytest


class TestLargestPrimeFactor:
    
    @pytest.mark.parametrize("n,expected", [
        (2, 2),
        (3, 3),
        (4, 2),
        (5, 5),
        (6, 3),
        (7, 7),
        (8, 2),
        (9, 3),
        (10, 5),
        (12, 3),
        (15, 5),
        (20, 5),
        (24, 3),
        (25, 5),
        (30, 5),
        (100, 5),
        (97, 97),
        (98, 7),
        (99, 11),
        (1000, 5),
    ])
    def test_largest_prime_factor_normal_cases(self, n, expected):
        from test_humaneval_59 import largest_prime_factor
        assert largest_prime_factor(n) == expected
    
    def test_largest_prime_factor_two(self):
        assert largest_prime_factor(2) == 2
    
    def test_largest_prime_factor_prime_number(self):
        assert largest_prime_factor(13) == 13
    
    def test_largest_prime_factor_power_of_two(self):
        assert largest_prime_factor(16) == 2
    
    def test_largest_prime_factor_power_of_three(self):
        assert largest_prime_factor(27) == 3
    
    def test_largest_prime_factor_product_of_two_primes(self):
        assert largest_prime_factor(35) == 7
    
    def test_largest_prime_factor_product_of_three_primes(self):
        assert largest_prime_factor(210) == 7
    
    def test_largest_prime_factor_large_prime(self):
        assert largest_prime_factor(97) == 97
    
    def test_largest_prime_factor_large_composite(self):
        assert largest_prime_factor(1000) == 5
    
    def test_largest_prime_factor_two_times_prime(self):
        assert largest_prime_factor(14) == 7
    
    def test_largest_prime_factor_three_times_prime(self):
        assert largest_prime_factor(21) == 7
    
    def test_largest_prime_factor_multiple_prime_factors(self):
        assert largest_prime_factor(60) == 5
    
    def test_largest_prime_factor_consecutive_primes(self):
        assert largest_prime_factor(2 * 3 * 5 * 7) == 7
    
    def test_largest_prime_factor_large_number_with_small_prime(self):
        assert largest_prime_factor(128) == 2
    
    def test_largest_prime_factor_semiprime(self):
        assert largest_prime_factor(143) == 13
    
    def test_largest_prime_factor_returns_integer(self):
        result = largest_prime_factor(10)
        assert isinstance(result, int)
    
    def test_largest_prime_factor_four(self):
        assert largest_prime_factor(4) == 2
    
    def test_largest_prime_factor_eleven(self):
        assert largest_prime_factor(11) == 11
    
    def test_largest_prime_factor_fifty(self):
        assert largest_prime_factor(50) == 5
    
    def test_largest_prime_factor_ninety_nine(self):
        assert largest_prime_factor(99) == 11