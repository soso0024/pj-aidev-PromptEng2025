# Test cases for HumanEval/95
# Generated using Claude API


def check_dict_case(dict):
    """
    Given a dictionary, return True if all keys are strings in lower 
    case or all keys are strings in upper case, else return False.
    The function should return False is the given dictionary is empty.
    Examples:
    check_dict_case({"a":"apple", "b":"banana"}) should return True.
    check_dict_case({"a":"apple", "A":"banana", "B":"banana"}) should return False.
    check_dict_case({"a":"apple", 8:"banana", "a":"apple"}) should return False.
    check_dict_case({"Name":"John", "Age":"36", "City":"Houston"}) should return False.
    check_dict_case({"STATE":"NC", "ZIP":"12345" }) should return True.
    """

    if len(dict.keys()) == 0:
        return False
    else:
        state = "start"
        for key in dict.keys():

            if isinstance(key, str) == False:
                state = "mixed"
                break
            if state == "start":
                if key.isupper():
                    state = "upper"
                elif key.islower():
                    state = "lower"
                else:
                    break
            elif (state == "upper" and not key.isupper()) or (state == "lower" and not key.islower()):
                    state = "mixed"
                    break
            else:
                break
        return state == "upper" or state == "lower" 


# Generated test cases:
import pytest


def check_dict_case(dict):
    if len(dict.keys()) == 0:
        return False
    else:
        state = "start"
        for key in dict.keys():

            if isinstance(key, str) == False:
                state = "mixed"
                break
            if state == "start":
                if key.isupper():
                    state = "upper"
                elif key.islower():
                    state = "lower"
                else:
                    break
            elif (state == "upper" and not key.isupper()) or (state == "lower" and not key.islower()):
                    state = "mixed"
                    break
            else:
                break
        return state == "upper" or state == "lower"


class TestCheckDictCase:
    
    def test_empty_dict(self):
        assert check_dict_case({}) == False
    
    def test_all_lowercase_keys(self):
        assert check_dict_case({"a": "apple", "b": "banana"}) == True
    
    def test_all_uppercase_keys(self):
        assert check_dict_case({"STATE": "NC", "ZIP": "12345"}) == True
    
    def test_mixed_case_keys(self):
        assert check_dict_case({"a": "apple", "A": "banana", "B": "banana"}) == False
    
    def test_non_string_key(self):
        assert check_dict_case({"a": "apple", 8: "banana", "a": "apple"}) == False
    
    def test_mixed_case_strings(self):
        assert check_dict_case({"Name": "John", "Age": "36", "City": "Houston"}) == False
    
    def test_single_lowercase_key(self):
        assert check_dict_case({"x": "value"}) == True
    
    def test_single_uppercase_key(self):
        assert check_dict_case({"X": "value"}) == True
    
    def test_single_mixed_case_key(self):
        assert check_dict_case({"Xy": "value"}) == False
    
    def test_multiple_lowercase_keys(self):
        assert check_dict_case({"apple": "1", "banana": "2", "cherry": "3"}) == True
    
    def test_multiple_uppercase_keys(self):
        assert check_dict_case({"APPLE": "1", "BANANA": "2", "CHERRY": "3"}) == True
    
    def test_numeric_key(self):
        assert check_dict_case({1: "value", 2: "value2"}) == False
    
    def test_mixed_numeric_and_string_keys(self):
        assert check_dict_case({"a": "value", 1: "value2"}) == False
    
    def test_keys_with_numbers_lowercase(self):
        assert check_dict_case({"a1": "value", "b2": "value2"}) == True
    
    def test_keys_with_numbers_uppercase(self):
        assert check_dict_case({"A1": "value", "B2": "value2"}) == True
    
    def test_keys_with_special_characters_lowercase(self):
        assert check_dict_case({"a_b": "value", "c_d": "value2"}) == True
    
    def test_keys_with_special_characters_uppercase(self):
        assert check_dict_case({"A_B": "value", "C_D": "value2"}) == True
    
    def test_keys_with_special_characters_mixed(self):
        assert check_dict_case({"A_b": "value", "C_d": "value2"}) == False
    
    def test_single_character_lowercase(self):
        assert check_dict_case({"a": "1", "b": "2", "c": "3"}) == True
    
    def test_single_character_uppercase(self):
        assert check_dict_case({"A": "1", "B": "2", "C": "3"}) == True
    
    def test_none_key(self):
        assert check_dict_case({None: "value"}) == False
    
    def test_float_key(self):
        assert check_dict_case({1.5: "value"}) == False
    
    def test_boolean_key(self):
        assert check_dict_case({True: "value"}) == False
    
    def test_all_lowercase_with_numbers_and_underscores(self):
        assert check_dict_case({"key_1": "value", "key_2": "value2"}) == True
    
    def test_all_uppercase_with_numbers_and_underscores(self):
        assert check_dict_case({"KEY_1": "value", "KEY_2": "value2"}) == True
    
    def test_lowercase_then_uppercase_key(self):
        assert check_dict_case({"a": "value", "B": "value2"}) == False
    
    def test_uppercase_then_lowercase_key(self):
        assert check_dict_case({"A": "value", "b": "value2"}) == False
    
    def test_keys_with_spaces_lowercase(self):
        assert check_dict_case({"hello world": "value", "foo bar": "value2"}) == True
    
    def test_keys_with_spaces_uppercase(self):
        assert check_dict_case({"HELLO WORLD": "value", "FOO BAR": "value2"}) == True
    
    def test_empty_string_key(self):
        assert check_dict_case({"": "value"}) == False
    
    def test_only_numbers_in_key_string(self):
        assert check_dict_case({"123": "value", "456": "value2"}) == False
    
    def test_mixed_with_only_numbers_key(self):
        assert check_dict_case({"a": "value", "123": "value2"}) == False
