# Test cases for HumanEval/85
# Generated using Claude API


def add(lst):
    """Given a non-empty list of integers lst. add the even elements that are at odd indices..


    Examples:
        add([4, 2, 6, 7]) ==> 2 
    """

    return sum([lst[i] for i in range(1, len(lst), 2) if lst[i]%2 == 0])


# Generated test cases:
import pytest


def add(lst):
    """Given a non-empty list of integers lst. add the even elements that are at odd indices..


    Examples:
        add([4, 2, 6, 7]) ==> 2 
    """
    return sum([lst[i] for i in range(1, len(lst), 2) if lst[i]%2 == 0])


class TestAdd:
    
    def test_example_case(self):
        assert add([4, 2, 6, 7]) == 2
    
    def test_single_element(self):
        assert add([5]) == 0
    
    def test_two_elements_even_at_odd_index(self):
        assert add([1, 2]) == 2
    
    def test_two_elements_odd_at_odd_index(self):
        assert add([1, 3]) == 0
    
    def test_all_even_at_odd_indices(self):
        assert add([1, 2, 3, 4, 5, 6]) == 12
    
    def test_all_odd_at_odd_indices(self):
        assert add([1, 3, 5, 7, 9, 11]) == 0
    
    def test_mixed_values(self):
        assert add([10, 5, 20, 3, 40, 7]) == 0
    
    def test_negative_even_at_odd_indices(self):
        assert add([1, -2, 3, -4, 5, -6]) == -12
    
    def test_zero_at_odd_indices(self):
        assert add([1, 0, 3, 0, 5, 0]) == 0
    
    def test_large_numbers(self):
        assert add([1000, 2000, 3000, 4000]) == 6000
    
    def test_three_elements(self):
        assert add([1, 2, 3]) == 2
    
    def test_four_elements_no_even_at_odd(self):
        assert add([2, 1, 4, 3]) == 0
    
    def test_five_elements(self):
        assert add([1, 2, 3, 4, 5]) == 6
    
    def test_alternating_pattern(self):
        assert add([0, 1, 0, 1, 0, 1]) == 0
    
    def test_only_odd_indices_matter(self):
        assert add([100, 2, 200, 4, 300, 6]) == 12
    
    def test_negative_numbers_mixed(self):
        assert add([-5, -2, -3, -4]) == -6
    
    def test_long_list(self):
        assert add([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == 30
    
    def test_single_even_at_odd_index(self):
        assert add([1, 2, 3]) == 2
    
    def test_multiple_odd_indices_with_evens(self):
        assert add([7, 8, 9, 10, 11, 12, 13, 14]) == 44
    
    def test_zero_values(self):
        assert add([0, 0, 0, 0]) == 0


@pytest.mark.parametrize("input_list,expected", [
    ([4, 2, 6, 7], 2),
    ([1, 2], 2),
    ([1, 3], 0),
    ([5], 0),
    ([1, 2, 3, 4, 5, 6], 12),
    ([1, 3, 5, 7, 9, 11], 0),
    ([10, 5, 20, 3, 40, 7], 0),
    ([1, -2, 3, -4, 5, -6], -12),
    ([1, 0, 3, 0, 5, 0], 0),
    ([1000, 2000, 3000, 4000], 6000),
    ([1, 2, 3], 2),
    ([2, 1, 4, 3], 0),
    ([1, 2, 3, 4, 5], 6),
    ([0, 1, 0, 1, 0, 1], 0),
    ([100, 2, 200, 4, 300, 6], 12),
    ([-5, -2, -3, -4], -6),
    ([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 30),
    ([7, 8, 9, 10, 11, 12, 13, 14], 44),
    ([0, 0, 0, 0], 0),
])
def test_add_parametrized(input_list, expected):
    assert add(input_list) == expected