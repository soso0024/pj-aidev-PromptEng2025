# Test cases for HumanEval/75
# Generated using Claude API


def is_multiply_prime(a):
    """Write a function that returns true if the given number is the multiplication of 3 prime numbers
    and false otherwise.
    Knowing that (a) is less then 100. 
    Example:
    is_multiply_prime(30) == True
    30 = 2 * 3 * 5
    """

    def is_prime(n):
        for j in range(2,n):
            if n%j == 0:
                return False
        return True

    for i in range(2,101):
        if not is_prime(i): continue
        for j in range(2,101):
            if not is_prime(j): continue
            for k in range(2,101):
                if not is_prime(k): continue
                if i*j*k == a: return True
    return False


# Generated test cases:
import pytest


def is_multiply_prime(a):
    def is_prime(n):
        if n < 2:
            return False
        for j in range(2, int(n**0.5) + 1):
            if n % j == 0:
                return False
        return True

    for i in range(2, 101):
        if not is_prime(i):
            continue
        for j in range(2, 101):
            if not is_prime(j):
                continue
            for k in range(2, 101):
                if not is_prime(k):
                    continue
                if i * j * k == a:
                    return True
    return False


class TestIsMultiplyPrime:
    
    @pytest.mark.parametrize("number,expected", [
        (30, True),
        (2, False),
        (3, False),
        (5, False),
        (8, True),
        (27, True),
        (125, True),
        (1, False),
        (0, False),
        (6, False),
        (10, False),
        (15, False),
        (20, True),
        (24, False),
        (60, False),
        (66, True),
        (70, True),
        (78, True),
        (84, False),
        (90, False),
        (99, True),
    ])
    def test_is_multiply_prime(self, number, expected):
        assert is_multiply_prime(number) == expected
    
    def test_multiply_prime_30(self):
        assert is_multiply_prime(30) == True
    
    def test_multiply_prime_8(self):
        assert is_multiply_prime(8) == True
    
    def test_multiply_prime_27(self):
        assert is_multiply_prime(27) == True
    
    def test_multiply_prime_125(self):
        assert is_multiply_prime(125) == True
    
    def test_not_multiply_prime_2(self):
        assert is_multiply_prime(2) == False
    
    def test_not_multiply_prime_3(self):
        assert is_multiply_prime(3) == False
    
    def test_not_multiply_prime_5(self):
        assert is_multiply_prime(5) == False
    
    def test_not_multiply_prime_1(self):
        assert is_multiply_prime(1) == False
    
    def test_not_multiply_prime_0(self):
        assert is_multiply_prime(0) == False
    
    def test_not_multiply_prime_6(self):
        assert is_multiply_prime(6) == False
    
    def test_not_multiply_prime_10(self):
        assert is_multiply_prime(10) == False
    
    def test_not_multiply_prime_15(self):
        assert is_multiply_prime(15) == False
    
    def test_multiply_prime_60(self):
        assert is_multiply_prime(60) == False
    
    def test_multiply_prime_66(self):
        assert is_multiply_prime(66) == True
    
    def test_multiply_prime_78(self):
        assert is_multiply_prime(78) == True
    
    def test_multiply_prime_90(self):
        assert is_multiply_prime(90) == False
    
    def test_not_multiply_prime_70(self):
        assert is_multiply_prime(70) == True
    
    def test_not_multiply_prime_99(self):
        assert is_multiply_prime(99) == True
    
    def test_multiply_prime_2_2_2(self):
        assert is_multiply_prime(8) == True
    
    def test_multiply_prime_3_3_3(self):
        assert is_multiply_prime(27) == True
    
    def test_multiply_prime_5_5_5(self):
        assert is_multiply_prime(125) == True
    
    def test_multiply_prime_2_3_5(self):
        assert is_multiply_prime(30) == True
    
    def test_multiply_prime_2_2_3(self):
        assert is_multiply_prime(12) == True
    
    def test_multiply_prime_2_2_5(self):
        assert is_multiply_prime(20) == True