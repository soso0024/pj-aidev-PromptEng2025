# Test cases for HumanEval/49
# Generated using Claude API



def modp(n: int, p: int):
    """Return 2^n modulo p (be aware of numerics).
    >>> modp(3, 5)
    3
    >>> modp(1101, 101)
    2
    >>> modp(0, 101)
    1
    >>> modp(3, 11)
    8
    >>> modp(100, 101)
    1
    """

    ret = 1
    for i in range(n):
        ret = (2 * ret) % p
    return ret


# Generated test cases:
import pytest


def modp(n: int, p: int):
    """Return 2^n modulo p (be aware of numerics)."""
    ret = 1
    for i in range(n):
        ret = (2 * ret) % p
    return ret


class TestModp:
    """Test cases for modp function."""

    @pytest.mark.parametrize("n,p,expected", [
        (3, 5, 3),
        (1101, 101, 2),
        (0, 101, 1),
        (3, 11, 8),
        (100, 101, 1),
    ])
    def test_docstring_examples(self, n, p, expected):
        """Test examples from docstring."""
        assert modp(n, p) == expected

    @pytest.mark.parametrize("n,p,expected", [
        (1, 2, 0),
        (1, 3, 2),
        (1, 5, 2),
        (1, 7, 2),
        (2, 3, 1),
        (2, 5, 4),
        (2, 7, 4),
        (4, 5, 1),
        (5, 7, 4),
        (6, 7, 1),
    ])
    def test_small_values(self, n, p, expected):
        """Test with small values of n and p."""
        assert modp(n, p) == expected

    @pytest.mark.parametrize("n,p,expected", [
        (0, 2, 1),
        (0, 3, 1),
        (0, 5, 1),
        (0, 7, 1),
        (0, 100, 1),
        (0, 1000, 1),
    ])
    def test_n_equals_zero(self, n, p, expected):
        """Test when n is 0 (2^0 = 1)."""
        assert modp(n, p) == expected

    @pytest.mark.parametrize("n,p,expected", [
        (10, 2, 0),
        (10, 3, 1),
        (10, 5, 4),
        (10, 7, 2),
        (10, 11, 1),
        (10, 13, 10),
    ])
    def test_n_equals_ten(self, n, p, expected):
        """Test when n is 10."""
        assert modp(n, p) == expected

    @pytest.mark.parametrize("n,p,expected", [
        (1, 1, 0),
        (2, 1, 0),
        (5, 1, 0),
        (100, 1, 0),
    ])
    def test_p_equals_one(self, n, p, expected):
        """Test when p is 1 (everything mod 1 is 0)."""
        assert modp(n, p) == expected

    @pytest.mark.parametrize("n,p,expected", [
        (1, 2, 0),
        (2, 2, 0),
        (3, 2, 0),
        (10, 2, 0),
    ])
    def test_p_equals_two(self, n, p, expected):
        """Test when p is 2."""
        assert modp(n, p) == expected

    @pytest.mark.parametrize("n,p,expected", [
        (7, 13, 11),
        (15, 17, 9),
        (20, 23, 6),
        (50, 53, 40),
    ])
    def test_larger_values(self, n, p, expected):
        """Test with larger values."""
        assert modp(n, p) == expected

    @pytest.mark.parametrize("n,p,expected", [
        (1000, 1009, 942),
        (500, 503, 126),
        (200, 211, 34),
    ])
    def test_very_large_n(self, n, p, expected):
        """Test with very large n values."""
        assert modp(n, p) == expected

    def test_result_always_less_than_p(self):
        """Test that result is always less than p."""
        for n in range(0, 50):
            for p in range(2, 20):
                result = modp(n, p)
                assert 0 <= result < p

    def test_result_is_power_of_two_mod_p(self):
        """Test that result equals 2^n mod p."""
        for n in range(0, 30):
            for p in range(2, 30):
                result = modp(n, p)
                expected = pow(2, n, p)
                assert result == expected

    @pytest.mark.parametrize("n,p", [
        (0, 2),
        (1, 3),
        (5, 7),
        (10, 11),
        (100, 101),
    ])
    def test_return_type_is_int(self, n, p):
        """Test that return type is always int."""
        result = modp(n, p)
        assert isinstance(result, int)

    @pytest.mark.parametrize("n,p,expected", [
        (1, 4, 2),
        (2, 4, 0),
        (3, 4, 0),
        (4, 4, 0),
    ])
    def test_composite_moduli(self, n, p, expected):
        """Test with composite moduli."""
        assert modp(n, p) == expected

    @pytest.mark.parametrize("n,p,expected", [
        (1, 97, 2),
        (2, 97, 4),
        (3, 97, 8),
        (10, 97, 54),
    ])
    def test_prime_moduli(self, n, p, expected):
        """Test with prime moduli."""
        assert modp(n, p) == expected