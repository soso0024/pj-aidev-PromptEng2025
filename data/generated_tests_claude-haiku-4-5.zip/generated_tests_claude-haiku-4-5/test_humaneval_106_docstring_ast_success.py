# Test cases for HumanEval/106
# Generated using Claude API


def f(n):
    """ Implement the function f that takes n as a parameter,
    and returns a list of size n, such that the value of the element at index i is the factorial of i if i is even
    or the sum of numbers from 1 to i otherwise.
    i starts from 1.
    the factorial of i is the multiplication of the numbers from 1 to i (1 * 2 * ... * i).
    Example:
    f(5) == [1, 2, 6, 24, 15]
    """

    ret = []
    for i in range(1,n+1):
        if i%2 == 0:
            x = 1
            for j in range(1,i+1): x *= j
            ret += [x]
        else:
            x = 0
            for j in range(1,i+1): x += j
            ret += [x]
    return ret


# Generated test cases:
import pytest


class TestFunctionF:
    
    def f(self, n):
        ret = []
        for i in range(1, n+1):
            if i % 2 == 0:
                x = 1
                for j in range(1, i+1):
                    x *= j
                ret += [x]
            else:
                x = 0
                for j in range(1, i+1):
                    x += j
                ret += [x]
        return ret
    
    def test_example_case(self):
        assert self.f(5) == [1, 2, 6, 24, 15]
    
    def test_n_equals_1(self):
        assert self.f(1) == [1]
    
    def test_n_equals_2(self):
        assert self.f(2) == [1, 2]
    
    def test_n_equals_3(self):
        assert self.f(3) == [1, 2, 6]
    
    def test_n_equals_4(self):
        assert self.f(4) == [1, 2, 6, 24]
    
    def test_n_equals_6(self):
        assert self.f(6) == [1, 2, 6, 24, 15, 720]
    
    def test_n_equals_0(self):
        assert self.f(0) == []
    
    def test_n_equals_10(self):
        result = self.f(10)
        assert len(result) == 10
        assert result[0] == 1
        assert result[1] == 2
        assert result[2] == 6
        assert result[3] == 24
        assert result[4] == 15
        assert result[5] == 720
        assert result[6] == 28
        assert result[7] == 40320
        assert result[8] == 45
        assert result[9] == 3628800
    
    def test_odd_indices_are_sums(self):
        result = self.f(7)
        assert result[0] == 1
        assert result[2] == 6
        assert result[4] == 15
        assert result[6] == 28
    
    def test_even_indices_are_factorials(self):
        result = self.f(8)
        assert result[1] == 2
        assert result[3] == 24
        assert result[5] == 720
        assert result[7] == 40320
    
    def test_return_type_is_list(self):
        result = self.f(5)
        assert isinstance(result, list)
    
    def test_return_length_matches_n(self):
        for n in range(0, 11):
            assert len(self.f(n)) == n
    
    def test_all_elements_are_integers(self):
        result = self.f(10)
        for element in result:
            assert isinstance(element, int)
    
    def test_all_elements_are_positive(self):
        result = self.f(10)
        for element in result:
            assert element > 0
    
    def test_large_n(self):
        result = self.f(15)
        assert len(result) == 15
        assert result[0] == 1
        assert result[1] == 2
        assert result[3] == 24
        assert result[5] == 720
    
    @pytest.mark.parametrize("n,expected", [
        (1, [1]),
        (2, [1, 2]),
        (3, [1, 2, 6]),
        (4, [1, 2, 6, 24]),
        (5, [1, 2, 6, 24, 15]),
    ])
    def test_parametrized_cases(self, n, expected):
        assert self.f(n) == expected
    
    def test_sum_calculation_for_odd_positions(self):
        result = self.f(9)
        assert result[0] == 1
        assert result[2] == 6
        assert result[4] == 15
        assert result[6] == 28
        assert result[8] == 45
    
    def test_factorial_calculation_for_even_positions(self):
        result = self.f(9)
        assert result[1] == 2
        assert result[3] == 24
        assert result[5] == 720
        assert result[7] == 40320
    
    def test_consistency_across_multiple_calls(self):
        result1 = self.f(5)
        result2 = self.f(5)
        assert result1 == result2
    
    def test_n_equals_12(self):
        result = self.f(12)
        assert len(result) == 12
        assert result[11] == 479001600