# Test cases for HumanEval/24
# Generated using Claude API



def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    >>> largest_divisor(15)
    5
    """

    for i in reversed(range(n)):
        if n % i == 0:
            return i


# Generated test cases:
import pytest


def largest_divisor(n: int) -> int:
    for i in reversed(range(n)):
        if n % i == 0:
            return i


class TestLargestDivisor:
    
    @pytest.mark.parametrize("n,expected", [
        (2, 1),
        (3, 1),
        (4, 2),
        (5, 1),
        (6, 3),
        (10, 5),
        (12, 6),
        (15, 5),
        (20, 10),
        (100, 50),
        (97, 1),
        (1000, 500),
    ])
    def test_largest_divisor_normal_cases(self, n, expected):
        assert largest_divisor(n) == expected
    
    def test_largest_divisor_prime_number(self):
        assert largest_divisor(7) == 1
        assert largest_divisor(11) == 1
        assert largest_divisor(13) == 1
    
    def test_largest_divisor_power_of_two(self):
        assert largest_divisor(8) == 4
        assert largest_divisor(16) == 8
        assert largest_divisor(32) == 16
    
    def test_largest_divisor_composite_numbers(self):
        assert largest_divisor(9) == 3
        assert largest_divisor(25) == 5
        assert largest_divisor(49) == 7
    
    def test_largest_divisor_even_numbers(self):
        assert largest_divisor(2) == 1
        assert largest_divisor(4) == 2
        assert largest_divisor(6) == 3
        assert largest_divisor(8) == 4
    
    def test_largest_divisor_odd_numbers(self):
        assert largest_divisor(3) == 1
        assert largest_divisor(5) == 1
        assert largest_divisor(9) == 3
        assert largest_divisor(15) == 5
    
    def test_largest_divisor_large_numbers(self):
        assert largest_divisor(1000000) == 500000
        assert largest_divisor(999999) == 333333
    
    def test_largest_divisor_consecutive_numbers(self):
        for n in range(2, 20):
            result = largest_divisor(n)
            assert result < n
            assert n % result == 0
    
    def test_largest_divisor_always_less_than_n(self):
        for n in range(2, 100):
            result = largest_divisor(n)
            assert result < n
    
    def test_largest_divisor_always_divides_n(self):
        for n in range(2, 100):
            result = largest_divisor(n)
            assert n % result == 0
    
    def test_largest_divisor_specific_cases(self):
        assert largest_divisor(24) == 12
        assert largest_divisor(36) == 18
        assert largest_divisor(50) == 25
        assert largest_divisor(60) == 30
