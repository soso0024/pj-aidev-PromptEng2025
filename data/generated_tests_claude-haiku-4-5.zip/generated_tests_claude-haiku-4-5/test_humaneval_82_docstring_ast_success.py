# Test cases for HumanEval/82
# Generated using Claude API


def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise
    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """

    l = len(string)
    if l == 0 or l == 1:
        return False
    for i in range(2, l):
        if l % i == 0:
            return False
    return True


# Generated test cases:
import pytest


def prime_length(string):
    l = len(string)
    if l == 0 or l == 1:
        return False
    for i in range(2, l):
        if l % i == 0:
            return False
    return True


class TestPrimeLength:
    
    @pytest.mark.parametrize("input_string,expected", [
        ("Hello", True),
        ("abcdcba", True),
        ("kittens", True),
        ("orange", False),
    ])
    def test_docstring_examples(self, input_string, expected):
        assert prime_length(input_string) == expected
    
    def test_empty_string(self):
        assert prime_length("") == False
    
    def test_single_character(self):
        assert prime_length("a") == False
    
    def test_two_characters_prime(self):
        assert prime_length("ab") == True
    
    def test_three_characters_prime(self):
        assert prime_length("abc") == True
    
    def test_four_characters_not_prime(self):
        assert prime_length("abcd") == False
    
    def test_five_characters_prime(self):
        assert prime_length("abcde") == True
    
    def test_six_characters_not_prime(self):
        assert prime_length("abcdef") == False
    
    def test_seven_characters_prime(self):
        assert prime_length("abcdefg") == True
    
    def test_eight_characters_not_prime(self):
        assert prime_length("abcdefgh") == False
    
    def test_nine_characters_not_prime(self):
        assert prime_length("abcdefghi") == False
    
    def test_ten_characters_not_prime(self):
        assert prime_length("abcdefghij") == False
    
    def test_eleven_characters_prime(self):
        assert prime_length("abcdefghijk") == True
    
    def test_thirteen_characters_prime(self):
        assert prime_length("abcdefghijklm") == True
    
    def test_fifteen_characters_not_prime(self):
        assert prime_length("abcdefghijklmno") == False
    
    def test_seventeen_characters_prime(self):
        assert prime_length("abcdefghijklmnopq") == True
    
    def test_twenty_characters_not_prime(self):
        assert prime_length("abcdefghijklmnopqrst") == False
    
    def test_special_characters_prime_length(self):
        assert prime_length("!@#$%") == True
    
    def test_special_characters_not_prime_length(self):
        assert prime_length("!@#$") == False
    
    def test_numbers_as_string_prime_length(self):
        assert prime_length("12345") == True
    
    def test_numbers_as_string_not_prime_length(self):
        assert prime_length("1234") == False
    
    def test_mixed_characters_prime_length(self):
        assert prime_length("Hello123!") == False
    
    def test_mixed_characters_not_prime_length(self):
        assert prime_length("Test@123") == False
    
    def test_spaces_prime_length(self):
        assert prime_length("a b c d e") == False
    
    def test_spaces_not_prime_length(self):
        assert prime_length("a b c d") == True
    
    def test_unicode_characters_prime_length(self):
        assert prime_length("café") == False
    
    def test_unicode_characters_not_prime_length(self):
        assert prime_length("naïve") == True
    
    def test_repeated_characters_prime_length(self):
        assert prime_length("aaaaa") == True
    
    def test_repeated_characters_not_prime_length(self):
        assert prime_length("aaaa") == False
    
    def test_newline_characters_prime_length(self):
        assert prime_length("a\nb\nc") == True
    
    def test_tab_characters_prime_length(self):
        assert prime_length("a\tb\tc\td\te") == False
    
    def test_large_prime_length(self):
        assert prime_length("a" * 97) == True
    
    def test_large_non_prime_length(self):
        assert prime_length("a" * 100) == False