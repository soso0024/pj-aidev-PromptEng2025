# Test cases for HumanEval/97
# Generated using Claude API


def multiply(a, b):
    """Complete the function that takes two integers and returns 
    the product of their unit digits.
    Assume the input is always valid.
    Examples:
    multiply(148, 412) should return 16.
    multiply(19, 28) should return 72.
    multiply(2020, 1851) should return 0.
    multiply(14,-15) should return 20.
    """

    return abs(a % 10) * abs(b % 10)


# Generated test cases:
import pytest


def multiply(a, b):
    return abs(a % 10) * abs(b % 10)


@pytest.mark.parametrize("a,b,expected", [
    (148, 412, 16),
    (19, 28, 72),
    (2020, 1851, 0),
    (14, -15, 20),
])
def test_multiply_examples(a, b, expected):
    assert multiply(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    (0, 0, 0),
    (0, 5, 0),
    (5, 0, 0),
    (10, 10, 0),
])
def test_multiply_with_zeros(a, b, expected):
    assert multiply(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    (1, 1, 1),
    (2, 3, 6),
    (5, 7, 35),
    (9, 9, 81),
])
def test_multiply_single_digits(a, b, expected):
    assert multiply(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    (-1, -1, 1),
    (-2, -3, 6),
    (-5, -7, 35),
    (-9, -9, 81),
])
def test_multiply_negative_single_digits(a, b, expected):
    assert multiply(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    (-148, 412, 32),
    (-19, -28, 72),
    (-2020, -1851, 0),
    (-14, 15, 20),
])
def test_multiply_negative_numbers(a, b, expected):
    assert multiply(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    (11, 22, 2),
    (23, 34, 12),
    (45, 56, 30),
    (67, 78, 56),
    (89, 90, 0),
])
def test_multiply_two_digit_numbers(a, b, expected):
    assert multiply(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    (100, 200, 0),
    (123, 456, 18),
    (999, 888, 72),
    (1234, 5678, 32),
])
def test_multiply_large_numbers(a, b, expected):
    assert multiply(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    (10, 20, 0),
    (20, 30, 0),
    (100, 1000, 0),
])
def test_multiply_multiples_of_ten(a, b, expected):
    assert multiply(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    (1, 2, 2),
    (2, 1, 2),
    (3, 4, 12),
    (4, 3, 12),
])
def test_multiply_commutative(a, b, expected):
    assert multiply(a, b) == multiply(b, a)


def test_multiply_returns_integer():
    result = multiply(5, 7)
    assert isinstance(result, int)


def test_multiply_result_non_negative():
    assert multiply(-5, -7) >= 0
    assert multiply(5, 7) >= 0
    assert multiply(-5, 7) >= 0
    assert multiply(5, -7) >= 0