# Test cases for HumanEval/150
# Generated using Claude API


def x_or_y(n, x, y):
    """A simple program which should return the value of x if n is 
    a prime number and should return the value of y otherwise.

    Examples:
    for x_or_y(7, 34, 12) == 34
    for x_or_y(15, 8, 5) == 5
    
    """

    if n == 1:
        return y
    for i in range(2, n):
        if n % i == 0:
            return y
            break
    else:
        return x


# Generated test cases:
import pytest


def x_or_y(n, x, y):
    if n == 1:
        return y
    for i in range(2, n):
        if n % i == 0:
            return y
            break
    else:
        return x


class TestXOrY:
    
    @pytest.mark.parametrize("n,x,y,expected", [
        (7, 34, 12, 34),
        (15, 8, 5, 5),
        (2, 100, 50, 100),
        (3, 10, 20, 10),
        (5, 99, 1, 99),
        (11, 77, 33, 77),
        (13, 42, 24, 42),
    ])
    def test_prime_numbers(self, n, x, y, expected):
        assert x_or_y(n, x, y) == expected
    
    @pytest.mark.parametrize("n,x,y,expected", [
        (1, 100, 50, 50),
        (4, 10, 20, 20),
        (6, 5, 15, 15),
        (8, 99, 1, 1),
        (9, 77, 33, 33),
        (10, 42, 24, 24),
        (12, 100, 200, 200),
        (14, 5, 10, 10),
        (16, 8, 16, 16),
        (18, 3, 9, 9),
        (20, 7, 14, 14),
    ])
    def test_non_prime_numbers(self, n, x, y, expected):
        assert x_or_y(n, x, y) == expected
    
    def test_two_is_prime(self):
        assert x_or_y(2, 100, 50) == 100
    
    def test_one_returns_y(self):
        assert x_or_y(1, 999, 111) == 111
    
    def test_large_prime(self):
        assert x_or_y(97, 1, 0) == 1
    
    def test_large_non_prime(self):
        assert x_or_y(100, 1, 0) == 0
    
    def test_negative_x_y_values(self):
        assert x_or_y(7, -34, -12) == -34
        assert x_or_y(15, -8, -5) == -5
    
    def test_zero_x_y_values(self):
        assert x_or_y(7, 0, 5) == 0
        assert x_or_y(15, 10, 0) == 0
    
    def test_same_x_y_values(self):
        assert x_or_y(7, 42, 42) == 42
        assert x_or_y(15, 42, 42) == 42
    
    def test_large_composite_number(self):
        assert x_or_y(1000, 1, 0) == 0
    
    def test_prime_with_large_values(self):
        assert x_or_y(23, 1000000, 1) == 1000000
    
    def test_composite_with_large_values(self):
        assert x_or_y(24, 1000000, 1) == 1
    
    @pytest.mark.parametrize("n,x,y", [
        (2, 5, 10),
        (3, 15, 20),
        (5, 100, 200),
        (7, 7, 7),
        (11, 0, 0),
        (13, -1, -2),
    ])
    def test_all_primes_return_x(self, n, x, y):
        assert x_or_y(n, x, y) == x
    
    @pytest.mark.parametrize("n,x,y", [
        (1, 5, 10),
        (4, 15, 20),
        (6, 100, 200),
        (8, 7, 7),
        (9, 0, 0),
        (10, -1, -2),
    ])
    def test_all_non_primes_return_y(self, n, x, y):
        assert x_or_y(n, x, y) == y
