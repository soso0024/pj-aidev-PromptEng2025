# Test cases for HumanEval/128
# Generated using Claude API


def prod_signs(arr):
    """
    You are given an array arr of integers and you need to return
    sum of magnitudes of integers multiplied by product of all signs
    of each number in the array, represented by 1, -1 or 0.
    Note: return None for empty arr.

    Example:
    >>> prod_signs([1, 2, 2, -4]) == -9
    >>> prod_signs([0, 1]) == 0
    >>> prod_signs([]) == None
    """

    if not arr: return None
    prod = 0 if 0 in arr else (-1) ** len(list(filter(lambda x: x < 0, arr)))
    return prod * sum([abs(i) for i in arr])


# Generated test cases:
import pytest


def prod_signs(arr):
    if not arr: return None
    prod = 0 if 0 in arr else (-1) ** len(list(filter(lambda x: x < 0, arr)))
    return prod * sum([abs(i) for i in arr])


class TestProdSigns:
    
    def test_empty_array(self):
        assert prod_signs([]) is None
    
    def test_single_positive_number(self):
        assert prod_signs([1]) == 1
    
    def test_single_negative_number(self):
        assert prod_signs([-1]) == -1
    
    def test_single_zero(self):
        assert prod_signs([0]) == 0
    
    def test_all_positive_numbers(self):
        assert prod_signs([1, 2, 3]) == 6
    
    def test_all_negative_numbers_even_count(self):
        assert prod_signs([-1, -2, -3, -4]) == 10
    
    def test_all_negative_numbers_odd_count(self):
        assert prod_signs([-1, -2, -3]) == -6
    
    def test_mixed_positive_and_negative_even_negatives(self):
        assert prod_signs([1, -2, 3, -4]) == 10
    
    def test_mixed_positive_and_negative_odd_negatives(self):
        assert prod_signs([1, -2, 3, -4, -5]) == -15
    
    def test_array_with_zero_and_positives(self):
        assert prod_signs([0, 1, 2, 3]) == 0
    
    def test_array_with_zero_and_negatives(self):
        assert prod_signs([0, -1, -2, -3]) == 0
    
    def test_array_with_zero_and_mixed(self):
        assert prod_signs([0, 1, -2, 3, -4]) == 0
    
    def test_array_with_multiple_zeros(self):
        assert prod_signs([0, 0, 1, 2]) == 0
    
    def test_large_positive_numbers(self):
        assert prod_signs([100, 200, 300]) == 600
    
    def test_large_negative_numbers_even_count(self):
        assert prod_signs([-100, -200]) == 300
    
    def test_large_negative_numbers_odd_count(self):
        assert prod_signs([-100, -200, -300]) == -600
    
    def test_mixed_large_numbers(self):
        assert prod_signs([100, -200, 300, -400]) == 1000
    
    def test_two_positive_numbers(self):
        assert prod_signs([5, 10]) == 15
    
    def test_two_negative_numbers(self):
        assert prod_signs([-5, -10]) == 15
    
    def test_two_mixed_numbers(self):
        assert prod_signs([5, -10]) == -15
    
    def test_one_positive_one_zero(self):
        assert prod_signs([5, 0]) == 0
    
    def test_one_negative_one_zero(self):
        assert prod_signs([-5, 0]) == 0
    
    def test_fractional_like_integers(self):
        assert prod_signs([1, 2, 3, 4, 5]) == 15
    
    def test_negative_one_repeated(self):
        assert prod_signs([-1, -1, -1, -1]) == 4
    
    def test_negative_one_repeated_odd(self):
        assert prod_signs([-1, -1, -1]) == -3
    
    @pytest.mark.parametrize("arr,expected", [
        ([1, 2, 3, 4, 5], 15),
        ([-1, -2, -3, -4], 10),
        ([-1, -2, -3], -6),
        ([0, 1, 2], 0),
        ([10], 10),
        ([-10], -10),
    ])
    def test_parametrized_cases(self, arr, expected):
        assert prod_signs(arr) == expected
