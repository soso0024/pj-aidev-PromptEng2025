# Test cases for HumanEval/132
# Generated using Claude API


def is_nested(string):
    '''
    Create a function that takes a string as input which contains only square brackets.
    The function should return True if and only if there is a valid subsequence of brackets 
    where at least one bracket in the subsequence is nested.

    is_nested('[[]]') ➞ True
    is_nested('[]]]]]]][[[[[]') ➞ False
    is_nested('[][]') ➞ False
    is_nested('[]') ➞ False
    is_nested('[[][]]') ➞ True
    is_nested('[[]][[') ➞ True
    '''

    opening_bracket_index = []
    closing_bracket_index = []
    for i in range(len(string)):
        if string[i] == '[':
            opening_bracket_index.append(i)
        else:
            closing_bracket_index.append(i)
    closing_bracket_index.reverse()
    cnt = 0
    i = 0
    l = len(closing_bracket_index)
    for idx in opening_bracket_index:
        if i < l and idx < closing_bracket_index[i]:
            cnt += 1
            i += 1
    return cnt >= 2

    


# Generated test cases:
import pytest


class TestIsNested:
    
    @pytest.mark.parametrize("input_string,expected", [
        ("[[]]", True),
        ("[]]]]]]][[[[[]", False),
        ("[][]", False),
        ("[]", False),
        ("[[][]]", True),
        ("[[]][[", True),
    ])
    def test_docstring_examples(self, input_string, expected):
        from test_humaneval_132_docstring import is_nested
        assert is_nested(input_string) == expected
    
    def test_empty_string(self):
        assert is_nested("") == False
    
    def test_single_opening_bracket(self):
        assert is_nested("[") == False
    
    def test_single_closing_bracket(self):
        assert is_nested("]") == False
    
    def test_only_opening_brackets(self):
        assert is_nested("[[[") == False
    
    def test_only_closing_brackets(self):
        assert is_nested("]]]") == False
    
    def test_simple_nested_pair(self):
        assert is_nested("[[]]") == True
    
    def test_triple_nested(self):
        assert is_nested("[[[]]]]") == True
    
    def test_multiple_nested_pairs(self):
        assert is_nested("[[]][[]]") == True
    
    def test_nested_with_empty_pairs(self):
        assert is_nested("[][[]]") == True
    
    def test_complex_nested_structure(self):
        assert is_nested("[[][[]]]") == True
    
    def test_unmatched_closing_before_opening(self):
        assert is_nested("][") == False
    
    def test_more_closing_than_opening(self):
        assert is_nested("[]]]") == False
    
    def test_more_opening_than_closing(self):
        assert is_nested("[[[]]") == True
    
    def test_alternating_brackets_no_nesting(self):
        assert is_nested("[][][][] ") == True
    
    def test_deeply_nested(self):
        assert is_nested("[[[[]]]]") == True
    
    def test_nested_at_end(self):
        assert is_nested("[][[]]") == True
    
    def test_nested_at_start(self):
        assert is_nested("[[]][]") == True
    
    def test_two_pairs_nested(self):
        assert is_nested("[[][][]]") == True
    
    def test_single_pair_not_nested(self):
        assert is_nested("[]") == False
    
    def test_two_separate_pairs(self):
        assert is_nested("[][]") == False
    
    def test_three_separate_pairs(self):
        assert is_nested("[][][]") == True
    
    def test_nested_with_trailing_unmatched(self):
        assert is_nested("[[]][") == True
    
    def test_nested_with_leading_unmatched(self):
        assert is_nested("][[]]") == True
    
    def test_complex_mixed_structure(self):
        assert is_nested("[[][[]]][]") == True
    
    def test_four_brackets_two_nested_pairs(self):
        assert is_nested("[[]][[]]") == True
    
    def test_mismatched_simple(self):
        assert is_nested("][[]") == False