# Test cases for HumanEval/141
# Generated using Claude API


def file_name_check(file_name):
    """Create a function which takes a string representing a file's name, and returns
    'Yes' if the the file's name is valid, and returns 'No' otherwise.
    A file's name is considered to be valid if and only if all the following conditions 
    are met:
    - There should not be more than three digits ('0'-'9') in the file's name.
    - The file's name contains exactly one dot '.'
    - The substring before the dot should not be empty, and it starts with a letter from 
    the latin alphapet ('a'-'z' and 'A'-'Z').
    - The substring after the dot should be one of these: ['txt', 'exe', 'dll']
    Examples:
    file_name_check("example.txt") # => 'Yes'
    file_name_check("1example.dll") # => 'No' (the name should start with a latin alphapet letter)
    """

    suf = ['txt', 'exe', 'dll']
    lst = file_name.split(sep='.')
    if len(lst) != 2:
        return 'No'
    if not lst[1] in suf:
        return 'No'
    if len(lst[0]) == 0:
        return 'No'
    if not lst[0][0].isalpha():
        return 'No'
    t = len([x for x in lst[0] if x.isdigit()])
    if t > 3:
        return 'No'
    return 'Yes'


# Generated test cases:
import pytest


def file_name_check(file_name):
    suf = ['txt', 'exe', 'dll']
    lst = file_name.split(sep='.')
    if len(lst) != 2:
        return 'No'
    if not lst[1] in suf:
        return 'No'
    if len(lst[0]) == 0:
        return 'No'
    if not lst[0][0].isalpha():
        return 'No'
    t = len([x for x in lst[0] if x.isdigit()])
    if t > 3:
        return 'No'
    return 'Yes'


class TestFileNameCheck:
    
    @pytest.mark.parametrize("file_name,expected", [
        ("example.txt", "Yes"),
        ("test.exe", "Yes"),
        ("document.dll", "Yes"),
        ("a.txt", "Yes"),
        ("Z.exe", "Yes"),
        ("file123.txt", "Yes"),
        ("test12.dll", "Yes"),
        ("a1b2c3.exe", "Yes"),
    ])
    def test_valid_file_names(self, file_name, expected):
        assert file_name_check(file_name) == expected
    
    @pytest.mark.parametrize("file_name,expected", [
        ("1example.dll", "No"),
        ("9test.txt", "No"),
        (".txt", "No"),
        ("example.", "No"),
        ("example", "No"),
        ("example.txt.exe", "No"),
        ("example.doc", "No"),
        ("example.pdf", "No"),
        ("example.TXT", "No"),
        ("example.EXE", "No"),
        ("example.DLL", "No"),
        ("example1234.txt", "No"),
        ("test12345.exe", "No"),
        ("a1b2c3d4.dll", "No"),
        ("_example.txt", "No"),
        ("-test.exe", "No"),
        ("@file.dll", "No"),
        ("example..txt", "No"),
        ("example.txt.", "No"),
        (".example.txt", "No"),
    ])
    def test_invalid_file_names(self, file_name, expected):
        assert file_name_check(file_name) == expected
    
    def test_valid_single_letter_start(self):
        assert file_name_check("a.txt") == "Yes"
        assert file_name_check("Z.exe") == "Yes"
    
    def test_valid_with_exactly_three_digits(self):
        assert file_name_check("file123.txt") == "Yes"
        assert file_name_check("a1b2c3.exe") == "Yes"
    
    def test_invalid_with_more_than_three_digits(self):
        assert file_name_check("file1234.txt") == "No"
        assert file_name_check("a1b2c3d4.exe") == "No"
        assert file_name_check("test12345.dll") == "No"
    
    def test_invalid_no_dot(self):
        assert file_name_check("exampletxt") == "No"
        assert file_name_check("testexe") == "No"
    
    def test_invalid_multiple_dots(self):
        assert file_name_check("example.txt.exe") == "No"
        assert file_name_check("test.file.dll") == "No"
        assert file_name_check("a.b.c.txt") == "No"
    
    def test_invalid_empty_name_before_dot(self):
        assert file_name_check(".txt") == "No"
        assert file_name_check(".exe") == "No"
        assert file_name_check(".dll") == "No"
    
    def test_invalid_wrong_extension(self):
        assert file_name_check("example.doc") == "No"
        assert file_name_check("test.pdf") == "No"
        assert file_name_check("file.jpg") == "No"
        assert file_name_check("document.docx") == "No"
    
    def test_invalid_starts_with_digit(self):
        assert file_name_check("1example.txt") == "No"
        assert file_name_check("9test.exe") == "No"
        assert file_name_check("0file.dll") == "No"
    
    def test_invalid_starts_with_special_char(self):
        assert file_name_check("_example.txt") == "No"
        assert file_name_check("-test.exe") == "No"
        assert file_name_check("@file.dll") == "No"
        assert file_name_check("#document.txt") == "No"
    
    def test_valid_lowercase_letters(self):
        assert file_name_check("abcdefg.txt") == "Yes"
        assert file_name_check("xyz.exe") == "Yes"
    
    def test_valid_uppercase_letters(self):
        assert file_name_check("ABCDEFG.txt") == "Yes"
        assert file_name_check("XYZ.exe") == "Yes"
    
    def test_valid_mixed_case_letters(self):
        assert file_name_check("AbCdEfG.txt") == "Yes"
        assert file_name_check("XyZ.exe") == "Yes"
    
    def test_valid_letters_and_digits_mixed(self):
        assert file_name_check("file1.txt") == "Yes"
        assert file_name_check("test2name3.exe") == "Yes"
        assert file_name_check("a1b2c3.dll") == "Yes"
    
    def test_edge_case_single_letter_with_extension(self):
        assert file_name_check("a.txt") == "Yes"
        assert file_name_check("b.exe") == "Yes"
        assert file_name_check("c.dll") == "Yes"
    
    def test_edge_case_long_name_with_valid_digits(self):
        assert file_name_check("verylongfilenamewithnumbers123.txt") == "Yes"
    
    def test_edge_case_long_name_with_invalid_digits(self):
        assert file_name_check("verylongfilenamewithnumbers1234.txt") == "No"
