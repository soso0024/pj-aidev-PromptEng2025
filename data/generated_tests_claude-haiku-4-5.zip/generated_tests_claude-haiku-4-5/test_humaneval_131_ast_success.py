# Test cases for HumanEval/131
# Generated using Claude API


def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.
    For example:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """

    product = 1
    odd_count = 0
    for digit in str(n):
        int_digit = int(digit)
        if int_digit%2 == 1:
            product= product*int_digit
            odd_count+=1
    if odd_count ==0:
        return 0
    else:
        return product


# Generated test cases:
import pytest


def digits(n):
    product = 1
    odd_count = 0
    for digit in str(n):
        int_digit = int(digit)
        if int_digit%2 == 1:
            product= product*int_digit
            odd_count+=1
    if odd_count ==0:
        return 0
    else:
        return product


class TestDigits:
    
    def test_single_odd_digit(self):
        assert digits(5) == 5
    
    def test_single_even_digit(self):
        assert digits(4) == 0
    
    def test_multiple_odd_digits(self):
        assert digits(135) == 15
    
    def test_multiple_even_digits(self):
        assert digits(246) == 0
    
    def test_mixed_odd_and_even(self):
        assert digits(1234) == 3
    
    def test_all_odd_digits(self):
        assert digits(13579) == 945
    
    def test_zero(self):
        assert digits(0) == 0
    
    def test_one(self):
        assert digits(1) == 1
    
    def test_two_digit_odd_numbers(self):
        assert digits(11) == 1
    
    def test_two_digit_mixed(self):
        assert digits(12) == 1
    
    def test_large_number_with_odds(self):
        assert digits(123456789) == 945
    
    def test_number_with_leading_even(self):
        assert digits(2135) == 15
    
    def test_number_with_trailing_even(self):
        assert digits(1352) == 15
    
    def test_single_digit_one(self):
        assert digits(1) == 1
    
    def test_single_digit_three(self):
        assert digits(3) == 3
    
    def test_single_digit_seven(self):
        assert digits(7) == 7
    
    def test_single_digit_nine(self):
        assert digits(9) == 9
    
    def test_two_odd_digits_same(self):
        assert digits(33) == 9
    
    def test_two_odd_digits_different(self):
        assert digits(35) == 15
    
    def test_number_with_only_zeros_and_evens(self):
        assert digits(2468) == 0
    
    def test_number_with_one_odd_among_evens(self):
        assert digits(24682) == 0
    
    def test_number_with_one_odd_at_start(self):
        assert digits(12468) == 1
    
    def test_number_with_one_odd_at_end(self):
        assert digits(24681) == 1
    
    def test_product_of_three_odds(self):
        assert digits(135) == 15
    
    def test_product_of_four_odds(self):
        assert digits(1357) == 105
    
    def test_product_with_nine(self):
        assert digits(19) == 9
    
    def test_product_with_multiple_nines(self):
        assert digits(99) == 81
    
    def test_alternating_odd_even(self):
        assert digits(10101) == 1
    
    def test_large_odd_product(self):
        assert digits(579) == 315


@pytest.mark.parametrize("input_val,expected", [
    (5, 5),
    (4, 0),
    (135, 15),
    (246, 0),
    (1234, 3),
    (13579, 945),
    (0, 0),
    (1, 1),
    (11, 1),
    (12, 1),
    (123456789, 945),
    (2135, 15),
    (1352, 15),
    (3, 3),
    (7, 7),
    (9, 9),
    (33, 9),
    (35, 15),
    (2468, 0),
    (24682, 0),
    (12468, 1),
    (24681, 1),
    (1357, 105),
    (19, 9),
    (99, 81),
    (10101, 1),
    (579, 315),
])
def test_digits_parametrized(input_val, expected):
    assert digits(input_val) == expected
