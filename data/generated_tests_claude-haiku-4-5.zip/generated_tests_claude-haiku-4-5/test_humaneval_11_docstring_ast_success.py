# Test cases for HumanEval/11
# Generated using Claude API

from typing import List


def string_xor(a: str, b: str) -> str:
    """ Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.
    >>> string_xor('010', '110')
    '100'
    """

    def xor(i, j):
        if i == j:
            return '0'
        else:
            return '1'

    return ''.join(xor(x, y) for x, y in zip(a, b))


# Generated test cases:
import pytest


def string_xor(a: str, b: str) -> str:
    def xor(i, j):
        if i == j:
            return '0'
        else:
            return '1'

    return ''.join(xor(x, y) for x, y in zip(a, b))


class TestStringXor:
    
    @pytest.mark.parametrize("a,b,expected", [
        ('010', '110', '100'),
        ('0', '0', '0'),
        ('1', '1', '0'),
        ('0', '1', '1'),
        ('1', '0', '1'),
        ('00', '00', '00'),
        ('11', '11', '00'),
        ('01', '10', '11'),
        ('10', '01', '11'),
        ('0101', '1010', '1111'),
        ('1111', '0000', '1111'),
        ('1010', '1010', '0000'),
        ('000', '111', '111'),
        ('111', '000', '111'),
        ('10101010', '01010101', '11111111'),
        ('1', '1', '0'),
        ('0000000', '0000000', '0000000'),
        ('1111111', '1111111', '0000000'),
        ('10', '10', '00'),
        ('01', '01', '00'),
    ])
    def test_string_xor_basic(self, a, b, expected):
        assert string_xor(a, b) == expected
    
    def test_string_xor_single_bit_same(self):
        assert string_xor('0', '0') == '0'
        assert string_xor('1', '1') == '0'
    
    def test_string_xor_single_bit_different(self):
        assert string_xor('0', '1') == '1'
        assert string_xor('1', '0') == '1'
    
    def test_string_xor_all_zeros(self):
        assert string_xor('0000', '0000') == '0000'
    
    def test_string_xor_all_ones(self):
        assert string_xor('1111', '1111') == '0000'
    
    def test_string_xor_alternating_pattern(self):
        assert string_xor('0101', '1010') == '1111'
        assert string_xor('1010', '0101') == '1111'
    
    def test_string_xor_long_strings(self):
        a = '1' * 100
        b = '1' * 100
        assert string_xor(a, b) == '0' * 100
    
    def test_string_xor_long_strings_different(self):
        a = '1' * 50 + '0' * 50
        b = '0' * 50 + '1' * 50
        assert string_xor(a, b) == '1' * 100
    
    def test_string_xor_docstring_example(self):
        assert string_xor('010', '110') == '100'
    
    def test_string_xor_commutative(self):
        a = '10110'
        b = '01101'
        assert string_xor(a, b) == string_xor(b, a)
    
    def test_string_xor_self_xor_is_zero(self):
        test_strings = ['0', '1', '01', '10', '0101', '1010', '11110000']
        for s in test_strings:
            assert string_xor(s, s) == '0' * len(s)
    
    def test_string_xor_xor_with_zeros(self):
        test_strings = ['0', '1', '01', '10', '0101', '1010', '11110000']
        for s in test_strings:
            assert string_xor(s, '0' * len(s)) == s
    
    def test_string_xor_xor_with_ones(self):
        assert string_xor('0', '1') == '1'
        assert string_xor('1', '1') == '0'
        assert string_xor('01', '11') == '10'
        assert string_xor('10', '11') == '01'
        assert string_xor('0101', '1111') == '1010'
    
    def test_string_xor_two_character_strings(self):
        assert string_xor('00', '00') == '00'
        assert string_xor('01', '01') == '00'
        assert string_xor('10', '10') == '00'
        assert string_xor('11', '11') == '00'
        assert string_xor('00', '11') == '11'
        assert string_xor('01', '10') == '11'
    
    def test_string_xor_three_character_strings(self):
        assert string_xor('000', '000') == '000'
        assert string_xor('111', '111') == '000'
        assert string_xor('010', '110') == '100'
        assert string_xor('101', '011') == '110'
    
    def test_string_xor_mixed_patterns(self):
        assert string_xor('1001', '0110') == '1111'
        assert string_xor('1100', '0011') == '1111'
        assert string_xor('1010', '1100') == '0110'
