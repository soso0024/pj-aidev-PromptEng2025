# Test cases for HumanEval/112
# Generated using Claude API


def reverse_delete(s,c):
    """Task
    We are given two strings s and c, you have to deleted all the characters in s that are equal to any character in c
    then check if the result string is palindrome.
    A string is called palindrome if it reads the same backward as forward.
    You should return a tuple containing the result string and True/False for the check.
    Example
    For s = "abcde", c = "ae", the result should be ('bcd',False)
    For s = "abcdef", c = "b"  the result should be ('acdef',False)
    For s = "abcdedcba", c = "ab", the result should be ('cdedc',True)
    """

    s = ''.join([char for char in s if char not in c])
    return (s,s[::-1] == s)


# Generated test cases:
import pytest


def reverse_delete(s, c):
    s = ''.join([char for char in s if char not in c])
    return (s, s[::-1] == s)


class TestReverseDelete:
    
    @pytest.mark.parametrize("s,c,expected_string,expected_palindrome", [
        ("abcde", "ae", "bcd", False),
        ("abcdef", "b", "acdef", False),
        ("abcdedcba", "ab", "cdedc", True),
    ])
    def test_examples_from_docstring(self, s, c, expected_string, expected_palindrome):
        result_string, is_palindrome = reverse_delete(s, c)
        assert result_string == expected_string
        assert is_palindrome == expected_palindrome
    
    def test_empty_string(self):
        result_string, is_palindrome = reverse_delete("", "a")
        assert result_string == ""
        assert is_palindrome == True
    
    def test_empty_delete_chars(self):
        result_string, is_palindrome = reverse_delete("abc", "")
        assert result_string == "abc"
        assert is_palindrome == False
    
    def test_both_empty(self):
        result_string, is_palindrome = reverse_delete("", "")
        assert result_string == ""
        assert is_palindrome == True
    
    def test_delete_all_chars(self):
        result_string, is_palindrome = reverse_delete("aaa", "a")
        assert result_string == ""
        assert is_palindrome == True
    
    def test_single_char_palindrome(self):
        result_string, is_palindrome = reverse_delete("a", "b")
        assert result_string == "a"
        assert is_palindrome == True
    
    def test_single_char_deleted(self):
        result_string, is_palindrome = reverse_delete("a", "a")
        assert result_string == ""
        assert is_palindrome == True
    
    def test_palindrome_no_deletion(self):
        result_string, is_palindrome = reverse_delete("racecar", "")
        assert result_string == "racecar"
        assert is_palindrome == True
    
    def test_palindrome_with_deletion(self):
        result_string, is_palindrome = reverse_delete("aabbaa", "b")
        assert result_string == "aaaa"
        assert is_palindrome == True
    
    def test_non_palindrome_no_deletion(self):
        result_string, is_palindrome = reverse_delete("hello", "")
        assert result_string == "hello"
        assert is_palindrome == False
    
    def test_non_palindrome_with_deletion(self):
        result_string, is_palindrome = reverse_delete("hello", "h")
        assert result_string == "ello"
        assert is_palindrome == False
    
    def test_multiple_chars_to_delete(self):
        result_string, is_palindrome = reverse_delete("programming", "grm")
        assert result_string == "poain"
        assert is_palindrome == False
    
    def test_delete_chars_not_in_string(self):
        result_string, is_palindrome = reverse_delete("abc", "xyz")
        assert result_string == "abc"
        assert is_palindrome == False
    
    def test_case_sensitive(self):
        result_string, is_palindrome = reverse_delete("AaBbCc", "a")
        assert result_string == "ABbCc"
        assert is_palindrome == False
    
    def test_special_chars_in_string(self):
        result_string, is_palindrome = reverse_delete("a!b!a", "!")
        assert result_string == "aba"
        assert is_palindrome == True
    
    def test_special_chars_to_delete(self):
        result_string, is_palindrome = reverse_delete("a!b@c", "!@")
        assert result_string == "abc"
        assert is_palindrome == False
    
    def test_spaces_in_string(self):
        result_string, is_palindrome = reverse_delete("a b a", " ")
        assert result_string == "aba"
        assert is_palindrome == True
    
    def test_numbers_in_string(self):
        result_string, is_palindrome = reverse_delete("12321", "1")
        assert result_string == "232"
        assert is_palindrome == True
    
    def test_long_palindrome_after_deletion(self):
        result_string, is_palindrome = reverse_delete("aXbXcXbXa", "X")
        assert result_string == "abcba"
        assert is_palindrome == True
    
    def test_repeated_delete_chars(self):
        result_string, is_palindrome = reverse_delete("aabbcc", "aabbcc")
        assert result_string == ""
        assert is_palindrome == True
    
    def test_two_char_palindrome(self):
        result_string, is_palindrome = reverse_delete("aa", "")
        assert result_string == "aa"
        assert is_palindrome == True
    
    def test_two_char_non_palindrome(self):
        result_string, is_palindrome = reverse_delete("ab", "")
        assert result_string == "ab"
        assert is_palindrome == False