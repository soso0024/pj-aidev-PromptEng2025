# Test cases for HumanEval/15
# Generated using Claude API



def string_sequence(n: int) -> str:
    """ Return a string containing space-delimited numbers starting from 0 upto n inclusive.
    >>> string_sequence(0)
    '0'
    >>> string_sequence(5)
    '0 1 2 3 4 5'
    """

    return ' '.join([str(x) for x in range(n + 1)])


# Generated test cases:
import pytest


def string_sequence(n: int) -> str:
    return ' '.join([str(x) for x in range(n + 1)])


class TestStringSequence:
    
    def test_zero(self):
        assert string_sequence(0) == '0'
    
    def test_five(self):
        assert string_sequence(5) == '0 1 2 3 4 5'
    
    def test_one(self):
        assert string_sequence(1) == '0 1'
    
    def test_ten(self):
        assert string_sequence(10) == '0 1 2 3 4 5 6 7 8 9 10'
    
    def test_large_number(self):
        result = string_sequence(100)
        assert result.startswith('0 1 2 3')
        assert result.endswith('98 99 100')
        assert len(result.split()) == 101
    
    def test_two(self):
        assert string_sequence(2) == '0 1 2'
    
    def test_three(self):
        assert string_sequence(3) == '0 1 2 3'
    
    def test_return_type_is_string(self):
        result = string_sequence(5)
        assert isinstance(result, str)
    
    def test_contains_spaces(self):
        result = string_sequence(5)
        assert ' ' in result
    
    def test_no_trailing_space(self):
        result = string_sequence(5)
        assert not result.endswith(' ')
    
    def test_no_leading_space(self):
        result = string_sequence(5)
        assert not result.startswith(' ')
    
    def test_split_count(self):
        result = string_sequence(5)
        assert len(result.split()) == 6
    
    def test_split_count_zero(self):
        result = string_sequence(0)
        assert len(result.split()) == 1
    
    def test_all_numbers_present(self):
        result = string_sequence(5)
        numbers = result.split()
        assert numbers == ['0', '1', '2', '3', '4', '5']
    
    def test_sequence_order(self):
        result = string_sequence(10)
        numbers = [int(x) for x in result.split()]
        assert numbers == list(range(11))
    
    @pytest.mark.parametrize("n,expected", [
        (0, '0'),
        (1, '0 1'),
        (2, '0 1 2'),
        (3, '0 1 2 3'),
        (5, '0 1 2 3 4 5'),
        (10, '0 1 2 3 4 5 6 7 8 9 10'),
    ])
    def test_parametrized_cases(self, n, expected):
        assert string_sequence(n) == expected
    
    def test_consecutive_numbers(self):
        result = string_sequence(20)
        numbers = [int(x) for x in result.split()]
        for i in range(len(numbers) - 1):
            assert numbers[i + 1] - numbers[i] == 1
    
    def test_starts_with_zero(self):
        result = string_sequence(5)
        assert result.startswith('0')
    
    def test_ends_with_n(self):
        n = 7
        result = string_sequence(n)
        assert result.endswith(str(n))
