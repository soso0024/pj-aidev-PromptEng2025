# Test cases for HumanEval/104
# Generated using Claude API


def unique_digits(x):
    """Given a list of positive integers x. return a sorted list of all 
    elements that hasn't any even digit.

    Note: Returned list should be sorted in increasing order.
    
    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """

    odd_digit_elements = []
    for i in x:
        if all (int(c) % 2 == 1 for c in str(i)):
            odd_digit_elements.append(i)
    return sorted(odd_digit_elements)


# Generated test cases:
import pytest


def unique_digits(x):
    """Given a list of positive integers x. return a sorted list of all 
    elements that hasn't any even digit.

    Note: Returned list should be sorted in increasing order.
    
    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """

    odd_digit_elements = []
    for i in x:
        if all (int(c) % 2 == 1 for c in str(i)):
            odd_digit_elements.append(i)
    return sorted(odd_digit_elements)


class TestUniqueDigits:
    
    def test_example_1(self):
        assert unique_digits([15, 33, 1422, 1]) == [1, 15, 33]
    
    def test_example_2(self):
        assert unique_digits([152, 323, 1422, 10]) == []
    
    def test_empty_list(self):
        assert unique_digits([]) == []
    
    def test_single_odd_digit(self):
        assert unique_digits([1]) == [1]
    
    def test_single_even_digit(self):
        assert unique_digits([2]) == []
    
    def test_all_odd_digits(self):
        assert unique_digits([1, 3, 5, 7, 9]) == [1, 3, 5, 7, 9]
    
    def test_all_even_digits(self):
        assert unique_digits([2, 4, 6, 8]) == []
    
    def test_mixed_single_digits(self):
        assert unique_digits([1, 2, 3, 4, 5]) == [1, 3, 5]
    
    def test_multi_digit_all_odd(self):
        assert unique_digits([11, 33, 55, 77, 99]) == [11, 33, 55, 77, 99]
    
    def test_multi_digit_all_even(self):
        assert unique_digits([22, 44, 66, 88]) == []
    
    def test_multi_digit_mixed(self):
        assert unique_digits([135, 246, 357, 468]) == [135, 357]
    
    def test_unsorted_input(self):
        assert unique_digits([99, 11, 55, 33]) == [11, 33, 55, 99]
    
    def test_duplicates_in_input(self):
        assert unique_digits([11, 11, 33, 33]) == [11, 11, 33, 33]
    
    def test_large_numbers_all_odd(self):
        assert unique_digits([111, 333, 555]) == [111, 333, 555]
    
    def test_large_numbers_with_even(self):
        assert unique_digits([1111, 1112, 1113]) == [1111, 1113]
    
    def test_single_digit_nine(self):
        assert unique_digits([9]) == [9]
    
    def test_single_digit_zero(self):
        assert unique_digits([0]) == []
    
    def test_number_with_zero(self):
        assert unique_digits([101, 103, 105]) == []
    
    def test_number_with_one_even_digit(self):
        assert unique_digits([111, 112, 113]) == [111, 113]
    
    def test_sorted_output_order(self):
        result = unique_digits([99, 1, 33, 5, 77])
        assert result == [1, 5, 33, 77, 99]
    
    def test_very_large_odd_number(self):
        assert unique_digits([13579, 24680]) == [13579]
    
    def test_all_nines(self):
        assert unique_digits([9, 99, 999, 9999]) == [9, 99, 999, 9999]
    
    def test_alternating_odd_even(self):
        assert unique_digits([13, 25, 37, 49]) == [13, 37]
    
    def test_number_with_multiple_same_digits(self):
        assert unique_digits([111, 333, 555, 222, 444]) == [111, 333, 555]
    
    def test_mixed_order_result_sorted(self):
        result = unique_digits([531, 135, 315, 153])
        assert result == sorted(result)
    
    def test_single_element_odd(self):
        assert unique_digits([7]) == [7]
    
    def test_single_element_even(self):
        assert unique_digits([8]) == []
    
    def test_large_list_mostly_even(self):
        assert unique_digits([2, 4, 6, 8, 10, 12, 14, 1, 3, 5]) == [1, 3, 5]
    
    def test_large_list_mostly_odd(self):
        assert unique_digits([1, 3, 5, 7, 9, 11, 13, 15, 2, 4]) == [1, 3, 5, 7, 9, 11, 13, 15]