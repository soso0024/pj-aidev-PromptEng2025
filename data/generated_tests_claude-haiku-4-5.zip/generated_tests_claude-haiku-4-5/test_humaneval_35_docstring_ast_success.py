# Test cases for HumanEval/35
# Generated using Claude API



def max_element(l: list):
    """Return maximum element in the list.
    >>> max_element([1, 2, 3])
    3
    >>> max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    123
    """

    m = l[0]
    for e in l:
        if e > m:
            m = e
    return m


# Generated test cases:
import pytest


def max_element(l: list):
    """Return maximum element in the list."""
    m = l[0]
    for e in l:
        if e > m:
            m = e
    return m


class TestMaxElement:
    def test_basic_positive_numbers(self):
        assert max_element([1, 2, 3]) == 3

    def test_mixed_numbers(self):
        assert max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10]) == 123

    def test_single_element(self):
        assert max_element([42]) == 42

    def test_two_elements(self):
        assert max_element([10, 20]) == 20

    def test_two_elements_reversed(self):
        assert max_element([20, 10]) == 20

    def test_all_negative_numbers(self):
        assert max_element([-5, -2, -10, -1]) == -1

    def test_all_same_numbers(self):
        assert max_element([5, 5, 5, 5]) == 5

    def test_max_at_beginning(self):
        assert max_element([100, 50, 25, 10]) == 100

    def test_max_at_end(self):
        assert max_element([10, 25, 50, 100]) == 100

    def test_max_in_middle(self):
        assert max_element([10, 50, 25, 100, 75]) == 100

    def test_with_zero(self):
        assert max_element([0, -5, -10]) == 0

    def test_large_numbers(self):
        assert max_element([1000000, 999999, 1000001]) == 1000001

    def test_floats(self):
        assert max_element([1.5, 2.7, 0.3]) == 2.7

    def test_mixed_int_float(self):
        assert max_element([1, 2.5, 3, 1.5]) == 3

    def test_negative_and_positive(self):
        assert max_element([-100, -50, 0, 50, 100]) == 100

    @pytest.mark.parametrize("input_list,expected", [
        ([1, 2, 3], 3),
        ([3, 2, 1], 3),
        ([5], 5),
        ([-1, -2, -3], -1),
        ([0, 0, 0], 0),
        ([100, 1, 50], 100),
    ])
    def test_parametrized_cases(self, input_list, expected):
        assert max_element(input_list) == expected

    def test_return_type_is_element(self):
        result = max_element([1, 2, 3])
        assert isinstance(result, int)

    def test_return_type_float(self):
        result = max_element([1.5, 2.5, 3.5])
        assert isinstance(result, float)

    def test_list_not_modified(self):
        original = [3, 1, 2]
        original_copy = original.copy()
        max_element(original)
        assert original == original_copy

    def test_very_long_list(self):
        long_list = list(range(1000))
        assert max_element(long_list) == 999

    def test_very_long_list_reversed(self):
        long_list = list(range(1000, 0, -1))
        assert max_element(long_list) == 1000
