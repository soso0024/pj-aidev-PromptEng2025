# Test cases for HumanEval/54
# Generated using Claude API



def same_chars(s0: str, s1: str):
    """
    Check if two words have the same characters.
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddeddabc')
    True
    >>> same_chars('abcd', 'dddddddabc')
    True
    >>> same_chars('dddddddabc', 'abcd')
    True
    >>> same_chars('eabcd', 'dddddddabc')
    False
    >>> same_chars('abcd', 'dddddddabce')
    False
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddddabc')
    False
    """

    return set(s0) == set(s1)


# Generated test cases:
import pytest


def same_chars(s0: str, s1: str):
    return set(s0) == set(s1)


class TestSameChars:
    
    @pytest.mark.parametrize("s0,s1,expected", [
        ('eabcdzzzz', 'dddzzzzzzzddeddabc', True),
        ('abcd', 'dddddddabc', True),
        ('dddddddabc', 'abcd', True),
        ('eabcd', 'dddddddabc', False),
        ('abcd', 'dddddddabce', False),
        ('eabcdzzzz', 'dddzzzzzzzddddabc', False),
    ])
    def test_docstring_examples(self, s0, s1, expected):
        assert same_chars(s0, s1) == expected
    
    def test_empty_strings(self):
        assert same_chars('', '') == True
    
    def test_one_empty_string(self):
        assert same_chars('', 'a') == False
        assert same_chars('a', '') == False
    
    def test_single_character_same(self):
        assert same_chars('a', 'a') == True
    
    def test_single_character_different(self):
        assert same_chars('a', 'b') == False
    
    def test_single_character_repeated(self):
        assert same_chars('a', 'aaaa') == True
        assert same_chars('aaaa', 'a') == True
    
    def test_identical_strings(self):
        assert same_chars('abc', 'abc') == True
        assert same_chars('hello', 'hello') == True
    
    def test_different_order_same_chars(self):
        assert same_chars('abc', 'cba') == True
        assert same_chars('abcdef', 'fedcba') == True
    
    def test_different_order_different_chars(self):
        assert same_chars('abc', 'abd') == False
        assert same_chars('xyz', 'xya') == False
    
    def test_repeated_characters(self):
        assert same_chars('aaa', 'aaa') == True
        assert same_chars('aaa', 'aaaa') == True
        assert same_chars('aaabbb', 'bbbaaaa') == True
    
    def test_subset_characters(self):
        assert same_chars('ab', 'abc') == False
        assert same_chars('abc', 'ab') == False
    
    def test_superset_characters(self):
        assert same_chars('abcd', 'abc') == False
        assert same_chars('abc', 'abcd') == False
    
    def test_case_sensitive(self):
        assert same_chars('A', 'a') == False
        assert same_chars('ABC', 'abc') == False
    
    def test_special_characters(self):
        assert same_chars('!@#', '#@!') == True
        assert same_chars('!@#', '!@#$') == False
    
    def test_numbers_as_strings(self):
        assert same_chars('123', '321') == True
        assert same_chars('123', '1234') == False
    
    def test_whitespace(self):
        assert same_chars(' ', ' ') == True
        assert same_chars('a b', 'b a') == True
        assert same_chars('a b', 'ab') == False
    
    def test_long_strings(self):
        s0 = 'abcdefghijklmnopqrstuvwxyz'
        s1 = 'zyxwvutsrqponmlkjihgfedcba'
        assert same_chars(s0, s1) == True
    
    def test_long_strings_with_repetition(self):
        s0 = 'a' * 1000 + 'b' * 1000
        s1 = 'b' * 500 + 'a' * 500
        assert same_chars(s0, s1) == True
    
    def test_unicode_characters(self):
        assert same_chars('café', 'éfac') == True
        assert same_chars('café', 'cafe') == False
    
    def test_mixed_content(self):
        assert same_chars('a1!', '!1a') == True
        assert same_chars('a1!', '!1ab') == False
