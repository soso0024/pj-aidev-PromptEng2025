# Test cases for HumanEval/53
# Generated using Claude API



def add(x: int, y: int):
    """Add two numbers x and y
    >>> add(2, 3)
    5
    >>> add(5, 7)
    12
    """

    return x + y


# Generated test cases:
import pytest


def add(x: int, y: int):
    """Add two numbers x and y
    >>> add(2, 3)
    5
    >>> add(5, 7)
    12
    """
    return x + y


class TestAdd:
    """Test cases for the add function"""

    @pytest.mark.parametrize("x,y,expected", [
        (2, 3, 5),
        (5, 7, 12),
        (0, 0, 0),
        (1, 0, 1),
        (0, 1, 1),
        (-1, 1, 0),
        (-5, -3, -8),
        (-10, 5, -5),
        (10, -5, 5),
        (100, 200, 300),
        (-100, -200, -300),
    ])
    def test_add_basic(self, x, y, expected):
        """Test basic addition cases"""
        assert add(x, y) == expected

    def test_add_positive_numbers(self):
        """Test addition of positive numbers"""
        assert add(1, 2) == 3
        assert add(10, 20) == 30

    def test_add_negative_numbers(self):
        """Test addition of negative numbers"""
        assert add(-1, -2) == -3
        assert add(-10, -20) == -30

    def test_add_mixed_signs(self):
        """Test addition with mixed positive and negative numbers"""
        assert add(5, -3) == 2
        assert add(-5, 3) == -2

    def test_add_zero(self):
        """Test addition with zero"""
        assert add(0, 5) == 5
        assert add(5, 0) == 5
        assert add(0, 0) == 0

    def test_add_large_numbers(self):
        """Test addition with large numbers"""
        assert add(1000000, 2000000) == 3000000
        assert add(999999999, 1) == 1000000000

    def test_add_commutative(self):
        """Test that addition is commutative"""
        assert add(3, 5) == add(5, 3)
        assert add(-10, 20) == add(20, -10)

    def test_add_associative(self):
        """Test that addition is associative"""
        x, y, z = 2, 3, 4
        assert add(add(x, y), z) == add(x, add(y, z))

    def test_add_identity(self):
        """Test that zero is the additive identity"""
        assert add(42, 0) == 42
        assert add(0, 42) == 42
        assert add(-42, 0) == -42

    def test_add_inverse(self):
        """Test additive inverse property"""
        assert add(5, -5) == 0
        assert add(-10, 10) == 0

    def test_add_return_type(self):
        """Test that the return type is int"""
        result = add(2, 3)
        assert isinstance(result, int)

    def test_add_docstring_examples(self):
        """Test examples from docstring"""
        assert add(2, 3) == 5
        assert add(5, 7) == 12
