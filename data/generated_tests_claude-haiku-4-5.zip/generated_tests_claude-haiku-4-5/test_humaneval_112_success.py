# Test cases for HumanEval/112
# Generated using Claude API


def reverse_delete(s,c):
    """Task
    We are given two strings s and c, you have to deleted all the characters in s that are equal to any character in c
    then check if the result string is palindrome.
    A string is called palindrome if it reads the same backward as forward.
    You should return a tuple containing the result string and True/False for the check.
    Example
    For s = "abcde", c = "ae", the result should be ('bcd',False)
    For s = "abcdef", c = "b"  the result should be ('acdef',False)
    For s = "abcdedcba", c = "ab", the result should be ('cdedc',True)
    """

    s = ''.join([char for char in s if char not in c])
    return (s,s[::-1] == s)


# Generated test cases:
import pytest


def reverse_delete(s, c):
    s = ''.join([char for char in s if char not in c])
    return (s, s[::-1] == s)


class TestReverseDelete:
    
    def test_empty_string(self):
        result = reverse_delete("", "")
        assert result == ("", True)
    
    def test_empty_chars_to_delete(self):
        result = reverse_delete("abc", "")
        assert result == ("abc", False)
    
    def test_empty_chars_to_delete_palindrome(self):
        result = reverse_delete("aba", "")
        assert result == ("aba", True)
    
    def test_delete_all_chars(self):
        result = reverse_delete("abc", "abc")
        assert result == ("", True)
    
    def test_delete_all_chars_empty_result(self):
        result = reverse_delete("aaa", "a")
        assert result == ("", True)
    
    def test_simple_palindrome(self):
        result = reverse_delete("racecar", "")
        assert result == ("racecar", True)
    
    def test_simple_non_palindrome(self):
        result = reverse_delete("hello", "")
        assert result == ("hello", False)
    
    def test_delete_middle_char(self):
        result = reverse_delete("abcba", "c")
        assert result == ("abba", True)
    
    def test_delete_multiple_chars(self):
        result = reverse_delete("abcdef", "bd")
        assert result == ("acef", False)
    
    def test_delete_creates_palindrome(self):
        result = reverse_delete("abcd", "bd")
        assert result == ("ac", False)
    
    def test_single_char_string(self):
        result = reverse_delete("a", "")
        assert result == ("a", True)
    
    def test_single_char_deleted(self):
        result = reverse_delete("a", "a")
        assert result == ("", True)
    
    def test_two_char_palindrome(self):
        result = reverse_delete("aa", "")
        assert result == ("aa", True)
    
    def test_two_char_non_palindrome(self):
        result = reverse_delete("ab", "")
        assert result == ("ab", False)
    
    def test_delete_one_from_two_chars(self):
        result = reverse_delete("ab", "b")
        assert result == ("a", True)
    
    def test_case_sensitive_deletion(self):
        result = reverse_delete("AaBbCc", "a")
        assert result == ("ABbCc", False)
    
    def test_case_sensitive_deletion_uppercase(self):
        result = reverse_delete("AaBbCc", "A")
        assert result == ("aBbCc", False)
    
    def test_repeated_chars_in_delete_string(self):
        result = reverse_delete("aabbcc", "aaa")
        assert result == ("bbcc", False)
    
    def test_special_characters(self):
        result = reverse_delete("a!b!a", "!")
        assert result == ("aba", True)
    
    def test_numbers_as_chars(self):
        result = reverse_delete("12321", "")
        assert result == ("12321", True)
    
    def test_delete_numbers(self):
        result = reverse_delete("1a2b1", "2")
        assert result == ("1ab1", False)
    
    def test_spaces_in_string(self):
        result = reverse_delete("a b a", " ")
        assert result == ("aba", True)
    
    def test_delete_spaces(self):
        result = reverse_delete("a b c", " ")
        assert result == ("abc", False)
    
    def test_long_palindrome(self):
        result = reverse_delete("abcdefedcba", "")
        assert result == ("abcdefedcba", True)
    
    def test_long_string_delete_middle(self):
        result = reverse_delete("abcdefedcba", "def")
        assert result == ("abccba", True)
    
    def test_all_same_chars(self):
        result = reverse_delete("aaaa", "")
        assert result == ("aaaa", True)
    
    def test_alternating_pattern(self):
        result = reverse_delete("ababab", "")
        assert result == ("ababab", False)
    
    def test_alternating_pattern_palindrome(self):
        result = reverse_delete("ababa", "")
        assert result == ("ababa", True)
    
    def test_delete_alternating_chars(self):
        result = reverse_delete("abcabc", "b")
        assert result == ("acac", False)
    
    def test_unicode_characters(self):
        result = reverse_delete("café", "")
        assert result == ("café", False)
    
    def test_delete_unicode_character(self):
        result = reverse_delete("caféac", "é")
        assert result == ("cafac", True)


@pytest.mark.parametrize("s,c,expected", [
    ("", "", ("", True)),
    ("a", "", ("a", True)),
    ("ab", "", ("ab", False)),
    ("aba", "", ("aba", True)),
    ("abc", "abc", ("", True)),
    ("abcba", "c", ("abba", True)),
    ("abcd", "bd", ("ac", False)),
    ("hello", "lo", ("he", False)),
    ("racecar", "", ("racecar", True)),
    ("12321", "", ("12321", True)),
    ("a!b!a", "!", ("aba", True)),
    ("aabbcc", "abc", ("", True)),
])
def test_reverse_delete_parametrized(s, c, expected):
    result = reverse_delete(s, c)
    assert result == expected