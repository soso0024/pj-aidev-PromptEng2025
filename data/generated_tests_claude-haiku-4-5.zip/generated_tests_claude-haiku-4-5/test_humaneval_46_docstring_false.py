# Test cases for HumanEval/46
# Generated using Claude API



def fib4(n: int):
    """The Fib4 number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fib4(0) -> 0
    fib4(1) -> 0
    fib4(2) -> 2
    fib4(3) -> 0
    fib4(n) -> fib4(n-1) + fib4(n-2) + fib4(n-3) + fib4(n-4).
    Please write a function to efficiently compute the n-th element of the fib4 number sequence.  Do not use recursion.
    >>> fib4(5)
    4
    >>> fib4(6)
    8
    >>> fib4(7)
    14
    """

    results = [0, 0, 2, 0]
    if n < 4:
        return results[n]

    for _ in range(4, n + 1):
        results.append(results[-1] + results[-2] + results[-3] + results[-4])
        results.pop(0)

    return results[-1]


# Generated test cases:
import pytest


class TestFib4:
    
    @pytest.mark.parametrize("n,expected", [
        (0, 0),
        (1, 0),
        (2, 2),
        (3, 0),
        (4, 2),
        (5, 4),
        (6, 8),
        (7, 14),
        (8, 28),
        (9, 54),
        (10, 104),
    ])
    def test_fib4_basic_cases(self, n, expected):
        from test_humaneval_46_docstring import fib4
        assert fib4(n) == expected
    
    def test_fib4_base_case_0(self):
        assert fib4(0) == 0
    
    def test_fib4_base_case_1(self):
        assert fib4(1) == 0
    
    def test_fib4_base_case_2(self):
        assert fib4(2) == 2
    
    def test_fib4_base_case_3(self):
        assert fib4(3) == 0
    
    def test_fib4_first_computed_value(self):
        assert fib4(4) == 2
    
    def test_fib4_docstring_example_5(self):
        assert fib4(5) == 4
    
    def test_fib4_docstring_example_6(self):
        assert fib4(6) == 8
    
    def test_fib4_docstring_example_7(self):
        assert fib4(7) == 14
    
    def test_fib4_larger_values(self):
        assert fib4(11) == 200
        assert fib4(12) == 386
        assert fib4(13) == 742
    
    def test_fib4_sequence_growth(self):
        prev = fib4(5)
        for i in range(6, 15):
            curr = fib4(i)
            assert curr > prev
            prev = curr
    
    def test_fib4_returns_integer(self):
        result = fib4(5)
        assert isinstance(result, int)
    
    def test_fib4_returns_non_negative(self):
        for i in range(20):
            assert fib4(i) >= 0
    
    def test_fib4_medium_value(self):
        assert fib4(15) == 2768
    
    def test_fib4_consistency(self):
        assert fib4(5) == fib4(5)
        assert fib4(10) == fib4(10)