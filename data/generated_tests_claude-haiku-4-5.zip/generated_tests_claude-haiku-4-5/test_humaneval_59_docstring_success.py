# Test cases for HumanEval/59
# Generated using Claude API



def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """

    def is_prime(k):
        if k < 2:
            return False
        for i in range(2, k - 1):
            if k % i == 0:
                return False
        return True
    largest = 1
    for j in range(2, n + 1):
        if n % j == 0 and is_prime(j):
            largest = max(largest, j)
    return largest


# Generated test cases:
import pytest


def largest_prime_factor(n: int):
    def is_prime(k):
        if k < 2:
            return False
        for i in range(2, int(k**0.5) + 1):
            if k % i == 0:
                return False
        return True
    largest = 1
    j = 2
    while j * j <= n:
        while n % j == 0:
            largest = j
            n //= j
        j += 1
    if n > 1:
        largest = n
    return largest


@pytest.mark.parametrize("n,expected", [
    (13195, 29),
    (2048, 2),
    (4, 2),
    (6, 3),
    (8, 2),
    (9, 3),
    (10, 5),
    (12, 3),
    (15, 5),
    (20, 5),
    (21, 7),
    (24, 3),
    (25, 5),
    (30, 5),
    (100, 5),
    (1000, 5),
    (97 * 2, 97),
    (11 * 13, 13),
    (7 * 11 * 13, 13),
    (2 * 3 * 5 * 7, 7),
    (2 * 2 * 2 * 2 * 2, 2),
    (3 * 3 * 3 * 3, 3),
    (5 * 5 * 5, 5),
])
def test_largest_prime_factor(n, expected):
    assert largest_prime_factor(n) == expected


def test_largest_prime_factor_small_composite():
    assert largest_prime_factor(4) == 2


def test_largest_prime_factor_two_prime_factors():
    assert largest_prime_factor(6) == 3


def test_largest_prime_factor_multiple_same_prime():
    assert largest_prime_factor(32) == 2


def test_largest_prime_factor_large_number():
    assert largest_prime_factor(600851475143) == 6857


def test_largest_prime_factor_product_of_two_large_primes():
    assert largest_prime_factor(97 * 101) == 101


def test_largest_prime_factor_power_of_two():
    assert largest_prime_factor(256) == 2


def test_largest_prime_factor_power_of_three():
    assert largest_prime_factor(243) == 3


def test_largest_prime_factor_mixed_primes():
    result = largest_prime_factor(2 * 3 * 5 * 7 * 11)
    assert result == 11


def test_largest_prime_factor_docstring_example_1():
    assert largest_prime_factor(13195) == 29


def test_largest_prime_factor_docstring_example_2():
    assert largest_prime_factor(2048) == 2