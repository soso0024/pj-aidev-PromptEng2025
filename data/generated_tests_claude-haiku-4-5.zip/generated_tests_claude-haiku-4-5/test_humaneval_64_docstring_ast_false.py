# Test cases for HumanEval/64
# Generated using Claude API


FIX = """
Add more test cases.
"""

def vowels_count(s):
    """Write a function vowels_count which takes a string representing
    a word as input and returns the number of vowels in the string.
    Vowels in this case are 'a', 'e', 'i', 'o', 'u'. Here, 'y' is also a
    vowel, but only when it is at the end of the given word.

    Example:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    """

    vowels = "aeiouAEIOU"
    n_vowels = sum(c in vowels for c in s)
    if s[-1] == 'y' or s[-1] == 'Y':
        n_vowels += 1
    return n_vowels


# Generated test cases:
import pytest


def vowels_count(s):
    vowels = "aeiouAEIOU"
    n_vowels = sum(c in vowels for c in s)
    if s[-1] == 'y' or s[-1] == 'Y':
        n_vowels += 1
    return n_vowels


class TestVowelsCount:
    
    @pytest.mark.parametrize("input_str,expected", [
        ("abcde", 2),
        ("ACEDY", 3),
        ("hello", 2),
        ("world", 1),
        ("aeiou", 5),
        ("AEIOU", 5),
        ("bcdfg", 0),
        ("y", 1),
        ("Y", 1),
        ("happy", 1),
        ("HAPPY", 1),
        ("sky", 1),
        ("SKY", 1),
        ("rhythm", 0),
        ("RHYTHM", 0),
        ("a", 1),
        ("b", 0),
        ("ay", 2),
        ("AY", 2),
        ("by", 1),
        ("BY", 1),
        ("aeiouY", 6),
        ("xyz", 0),
        ("XYZ", 0),
        ("programming", 3),
        ("PROGRAMMING", 3),
        ("beautiful", 5),
        ("BEAUTIFUL", 5),
        ("queue", 4),
        ("QUEUE", 4),
        ("education", 5),
        ("EDUCATION", 5),
        ("python", 1),
        ("PYTHON", 1),
        ("try", 1),
        ("TRY", 1),
        ("cry", 1),
        ("CRY", 1),
        ("fly", 1),
        ("FLY", 1),
        ("day", 2),
        ("DAY", 2),
        ("way", 2),
        ("WAY", 2),
        ("say", 2),
        ("SAY", 2),
        ("play", 2),
        ("PLAY", 2),
        ("stay", 2),
        ("STAY", 2),
        ("boy", 2),
        ("BOY", 2),
        ("joy", 2),
        ("JOY", 2),
        ("toy", 2),
        ("TOY", 2),
        ("key", 2),
        ("KEY", 2),
        ("money", 3),
        ("MONEY", 3),
        ("honey", 3),
        ("HONEY", 3),
        ("lady", 2),
        ("LADY", 2),
        ("baby", 2),
        ("BABY", 2),
        ("city", 2),
        ("CITY", 2),
        ("party", 2),
        ("PARTY", 2),
        ("story", 2),
        ("STORY", 2),
        ("history", 3),
        ("HISTORY", 3),
        ("mystery", 2),
        ("MYSTERY", 2),
        ("energy", 3),
        ("ENERGY", 3),
        ("family", 3),
        ("FAMILY", 3),
        ("quality", 4),
        ("QUALITY", 4),
        ("beauty", 4),
        ("BEAUTY", 4),
        ("duty", 2),
        ("DUTY", 2),
        ("study", 2),
        ("STUDY", 2),
        ("supply", 2),
        ("SUPPLY", 2),
        ("reply", 2),
        ("REPLY", 2),
        ("apply", 2),
        ("APPLY", 2),
        ("multiply", 3),
        ("MULTIPLY", 3),
        ("simplify", 3),
        ("SIMPLIFY", 3),
        ("modify", 3),
        ("MODIFY", 3),
        ("notify", 3),
        ("NOTIFY", 3),
        ("justify", 3),
        ("JUSTIFY", 3),
        ("satisfy", 3),
        ("SATISFY", 3),
        ("identify", 4),
        ("IDENTIFY", 4),
        ("classify", 3),
        ("CLASSIFY", 3),
        ("amplify", 3),
        ("AMPLIFY", 3),
        ("clarify", 3),
        ("CLARIFY", 3),
        ("verify", 3),
        ("VERIFY", 3),
        ("terrify", 3),
        ("TERRIFY", 3),
        ("testify", 3),
        ("TESTIFY", 3),
        ("certify", 3),
        ("CERTIFY", 3),
        ("purify", 3),
        ("PURIFY", 3),
        ("ratify", 3),
        ("RATIFY", 3),
        ("unify", 3),
        ("UNIFY", 3),
        ("defy", 2),
        ("DEFY", 2),
        ("rely", 2),
        ("RELY", 2),
        ("deny", 2),
        ("DENY", 2),
        ("comply", 2),
        ("COMPLY", 2),
        ("imply", 2),
        ("IMPLY", 2),
        ("employ", 3),
        ("EMPLOY", 3),
        ("deploy", 3),
        ("DEPLOY", 3),
        ("destroy", 3),
        ("DESTROY", 3),
        ("enjoy", 3),
        ("ENJOY", 3),
        ("annoy", 3),
        ("ANNOY", 3),
        ("alloy", 3),
        ("ALLOY", 3),
        ("decoy", 3),
        ("DECOY", 3),
        ("convoy", 3),
        ("CONVOY", 3),
        ("envoy", 3),
        ("ENVOY", 3),
        ("ploy", 2),
        ("PLOY", 2),
        ("cloy", 2),
        ("CLOY", 2),
        ("ahoy", 3),
        ("AHOY", 3),
        ("buoy", 3),
        ("BUOY", 3),
        ("savoy", 3),
        ("SAVOY", 3),
    ])
    def test_vowels_count_parametrized(self, input_str, expected):
        assert vowels_count(input_str) == expected
    
    def test_vowels_count_basic_example(self):
        assert vowels_count("abcde") == 2
    
    def test_vowels_count_uppercase_example(self):
        assert vowels_count("ACEDY") == 3
    
    def test_vowels_count_single_vowel(self):
        assert vowels_count("a") == 1