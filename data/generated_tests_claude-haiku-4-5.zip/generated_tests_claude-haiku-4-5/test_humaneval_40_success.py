# Test cases for HumanEval/40
# Generated using Claude API



def triples_sum_to_zero(l: list):
    """
    triples_sum_to_zero takes a list of integers as an input.
    it returns True if there are three distinct elements in the list that
    sum to zero, and False otherwise.

    >>> triples_sum_to_zero([1, 3, 5, 0])
    False
    >>> triples_sum_to_zero([1, 3, -2, 1])
    True
    >>> triples_sum_to_zero([1, 2, 3, 7])
    False
    >>> triples_sum_to_zero([2, 4, -5, 3, 9, 7])
    True
    >>> triples_sum_to_zero([1])
    False
    """

    for i in range(len(l)):
        for j in range(i + 1, len(l)):
            for k in range(j + 1, len(l)):
                if l[i] + l[j] + l[k] == 0:
                    return True
    return False


# Generated test cases:
import pytest


def triples_sum_to_zero(l: list):
    for i in range(len(l)):
        for j in range(i + 1, len(l)):
            for k in range(j + 1, len(l)):
                if l[i] + l[j] + l[k] == 0:
                    return True
    return False


class TestTriplesSumToZero:
    
    @pytest.mark.parametrize("input_list,expected", [
        ([0, 0, 0], True),
        ([1, -1, 0], True),
        ([1, 2, -3], True),
        ([-1, -2, 3], True),
        ([1, 2, 3], False),
        ([-1, -2, -3], False),
        ([1, 2, 3, -5], True),
        ([1, 2, 3, -6], False),
        ([5, -5, 0], True),
        ([1, 1, -2], True),
        ([2, 2, -4], True),
        ([-1, 0, 1], True),
        ([10, 20, 30], False),
        ([-10, -20, -30], False),
        ([1, 2, 3, 4, 5, -9], True),
        ([1, 2, 3, 4, 5, -10], False),
    ])
    def test_triples_sum_to_zero_parametrized(self, input_list, expected):
        assert triples_sum_to_zero(input_list) == expected
    
    def test_empty_list(self):
        assert triples_sum_to_zero([]) == False
    
    def test_single_element(self):
        assert triples_sum_to_zero([0]) == False
    
    def test_two_elements(self):
        assert triples_sum_to_zero([1, -1]) == False
    
    def test_three_elements_sum_zero(self):
        assert triples_sum_to_zero([1, 2, -3]) == True
    
    def test_three_elements_no_sum_zero(self):
        assert triples_sum_to_zero([1, 2, 3]) == False
    
    def test_all_zeros(self):
        assert triples_sum_to_zero([0, 0, 0, 0]) == True
    
    def test_large_positive_numbers(self):
        assert triples_sum_to_zero([100, 200, 300]) == False
    
    def test_large_negative_numbers(self):
        assert triples_sum_to_zero([-100, -200, -300]) == False
    
    def test_mixed_large_numbers(self):
        assert triples_sum_to_zero([100, 200, -300]) == True
    
    def test_multiple_valid_triples(self):
        assert triples_sum_to_zero([1, -1, 0, 2, -2]) == True
    
    def test_first_triple_valid(self):
        assert triples_sum_to_zero([1, 2, -3, 100, 200, 300]) == True
    
    def test_last_triple_valid(self):
        assert triples_sum_to_zero([100, 200, 300, 1, 2, -3]) == True
    
    def test_middle_triple_valid(self):
        assert triples_sum_to_zero([100, 1, 2, -3, 200]) == True
    
    def test_negative_zero_positive(self):
        assert triples_sum_to_zero([-5, 0, 5]) == True
    
    def test_duplicates_no_sum(self):
        assert triples_sum_to_zero([1, 1, 1, 1]) == False
    
    def test_duplicates_with_sum(self):
        assert triples_sum_to_zero([1, 1, -2]) == True
    
    def test_fractional_like_integers(self):
        assert triples_sum_to_zero([3, 4, -7]) == True
    
    def test_very_small_numbers(self):
        assert triples_sum_to_zero([1, 2, -3]) == True
    
    def test_alternating_signs(self):
        assert triples_sum_to_zero([1, -2, 3, -4, 5]) == True
    
    def test_alternating_signs_with_zero(self):
        assert triples_sum_to_zero([1, -1, 0, 2, -2]) == True