# Test cases for HumanEval/13
# Generated using Claude API



def greatest_common_divisor(a: int, b: int) -> int:
    """ Return a greatest common divisor of two integers a and b
    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """

    while b:
        a, b = b, a % b
    return a


# Generated test cases:
import pytest


class TestGreatestCommonDivisor:
    
    @pytest.mark.parametrize("a,b,expected", [
        (12, 8, 4),
        (48, 18, 6),
        (100, 50, 50),
        (17, 19, 1),
        (0, 5, 5),
        (5, 0, 5),
        (0, 0, 0),
        (1, 1, 1),
        (1, 100, 1),
        (100, 1, 1),
    ])
    def test_gcd_basic_cases(self, a, b, expected):
        from test_humaneval_13 import greatest_common_divisor
        assert greatest_common_divisor(a, b) == expected
    
    @pytest.mark.parametrize("a,b,expected", [
        (-12, 8, 4),
        (12, -8, 4),
        (-12, -8, 4),
        (-48, 18, 6),
        (-100, -50, 50),
    ])
    def test_gcd_negative_numbers(self, a, b, expected):
        assert abs(greatest_common_divisor(a, b)) == expected
    
    @pytest.mark.parametrize("a,b,expected", [
        (2, 3, 1),
        (7, 11, 1),
        (13, 17, 1),
        (1, 999, 1),
    ])
    def test_gcd_coprime_numbers(self, a, b, expected):
        assert greatest_common_divisor(a, b) == expected
    
    @pytest.mark.parametrize("a,b,expected", [
        (10, 10, 10),
        (5, 5, 5),
        (1, 1, 1),
        (100, 100, 100),
    ])
    def test_gcd_equal_numbers(self, a, b, expected):
        assert greatest_common_divisor(a, b) == expected
    
    @pytest.mark.parametrize("a,b,expected", [
        (12, 4, 4),
        (100, 10, 10),
        (50, 25, 25),
        (1000, 100, 100),
    ])
    def test_gcd_divisible_numbers(self, a, b, expected):
        assert greatest_common_divisor(a, b) == expected
    
    @pytest.mark.parametrize("a,b,expected", [
        (4, 12, 4),
        (10, 100, 10),
        (25, 50, 25),
        (100, 1000, 100),
    ])
    def test_gcd_reversed_divisible_numbers(self, a, b, expected):
        assert greatest_common_divisor(a, b) == expected
    
    @pytest.mark.parametrize("a,b,expected", [
        (1071, 462, 21),
        (270, 192, 6),
        (1234, 5678, 2),
        (9999, 3333, 3333),
    ])
    def test_gcd_large_numbers(self, a, b, expected):
        assert greatest_common_divisor(a, b) == expected
    
    def test_gcd_commutative(self):
        assert greatest_common_divisor(12, 8) == greatest_common_divisor(8, 12)
        assert greatest_common_divisor(100, 50) == greatest_common_divisor(50, 100)
        assert greatest_common_divisor(17, 19) == greatest_common_divisor(19, 17)
    
    def test_gcd_with_zero_first_argument(self):
        assert greatest_common_divisor(0, 5) == 5
        assert greatest_common_divisor(0, 100) == 100
    
    def test_gcd_with_zero_second_argument(self):
        assert greatest_common_divisor(5, 0) == 5
        assert greatest_common_divisor(100, 0) == 100
    
    def test_gcd_both_zero(self):
        assert greatest_common_divisor(0, 0) == 0
    
    def test_gcd_with_one(self):
        assert greatest_common_divisor(1, 5) == 1
        assert greatest_common_divisor(100, 1) == 1
        assert greatest_common_divisor(1, 1) == 1