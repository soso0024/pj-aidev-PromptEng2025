# Test cases for HumanEval/124
# Generated using Claude API


def valid_date(date):
    """You have to write a function which validates a given date string and
    returns True if the date is valid otherwise False.
    The date is valid if all of the following rules are satisfied:
    1. The date string is not empty.
    2. The number of days is not less than 1 or higher than 31 days for months 1,3,5,7,8,10,12. And the number of days is not less than 1 or higher than 30 days for months 4,6,9,11. And, the number of days is not less than 1 or higher than 29 for the month 2.
    3. The months should not be less than 1 or higher than 12.
    4. The date should be in the format: mm-dd-yyyy

    for example: 
    valid_date('03-11-2000') => True

    valid_date('15-01-2012') => False

    valid_date('04-0-2040') => False

    valid_date('06-04-2020') => True

    valid_date('06/04/2020') => False
    """

    try:
        date = date.strip()
        month, day, year = date.split('-')
        month, day, year = int(month), int(day), int(year)
        if month < 1 or month > 12:
            return False
        if month in [1,3,5,7,8,10,12] and day < 1 or day > 31:
            return False
        if month in [4,6,9,11] and day < 1 or day > 30:
            return False
        if month == 2 and day < 1 or day > 29:
            return False
    except:
        return False

    return True


# Generated test cases:
import pytest


class TestValidDate:
    
    @pytest.mark.parametrize("date_input,expected", [
        ("1-1-2020", True),
        ("12-31-2020", False),
        ("2-29-2020", True),
        ("4-30-2020", False),
        ("6-30-2020", False),
        ("9-30-2020", False),
        ("11-30-2020", False),
        ("1-31-2020", False),
        ("3-31-2020", False),
        ("5-31-2020", False),
        ("7-31-2020", False),
        ("8-31-2020", False),
        ("10-31-2020", False),
    ])
    def test_valid_dates(self, date_input, expected):
        from test_humaneval_124_ast import valid_date
        assert valid_date(date_input) == expected
    
    @pytest.mark.parametrize("date_input,expected", [
        ("0-1-2020", False),
        ("13-1-2020", False),
        ("-1-1-2020", False),
        ("1-0-2020", False),
        ("1-32-2020", False),
        ("4-31-2020", False),
        ("6-31-2020", False),
        ("9-31-2020", False),
        ("11-31-2020", False),
        ("2-30-2020", False),
        ("2-31-2020", False),
    ])
    def test_invalid_dates(self, date_input, expected):
        assert valid_date(date_input) == expected
    
    @pytest.mark.parametrize("date_input,expected", [
        ("1-1-2020 ", True),
        (" 1-1-2020", True),
        ("  1-1-2020  ", True),
        ("\t1-1-2020", True),
        ("1-1-2020\n", True),
    ])
    def test_dates_with_whitespace(self, date_input, expected):
        assert valid_date(date_input) == expected
    
    @pytest.mark.parametrize("date_input,expected", [
        ("1/1/2020", False),
        ("1.1.2020", False),
        ("1 1 2020", False),
        ("1-1", False),
        ("1-1-2020-extra", False),
        ("", False),
        ("   ", False),
    ])
    def test_invalid_format(self, date_input, expected):
        assert valid_date(date_input) == expected
    
    @pytest.mark.parametrize("date_input,expected", [
        ("a-1-2020", False),
        ("1-b-2020", False),
        ("1-1-c", False),
        ("abc-def-ghi", False),
        ("1.5-1-2020", False),
    ])
    def test_non_numeric_values(self, date_input, expected):
        assert valid_date(date_input) == expected
    
    @pytest.mark.parametrize("date_input,expected", [
        ("1-1-1", True),
        ("1-1-9999", True),
        ("12-31-1", False),
        ("12-31-9999", False),
    ])
    def test_various_years(self, date_input, expected):
        assert valid_date(date_input) == expected
    
    @pytest.mark.parametrize("date_input,expected", [
        ("2-28-2020", True),
        ("2-29-2020", True),
        ("2-1-2020", True),
    ])
    def test_february_dates(self, date_input, expected):
        assert valid_date(date_input) == expected
    
    def test_none_input(self):
        assert valid_date(None) == False
    
    def test_empty_string(self):
        assert valid_date("") == False
    
    def test_only_whitespace(self):
        assert valid_date("   ") == False
    
    def test_single_digit_month_day_year(self):
        assert valid_date("1-1-1") == True
    
    def test_leading_zeros(self):
        assert valid_date("01-01-2020") == True
    
    def test_month_boundary_values(self):
        assert valid_date("1-15-2020") == True
        assert valid_date("12-15-2020") == True
    
    def test_day_boundary_values_31_day_months(self):
        assert valid_date("1-31-2020") == False
        assert valid_date("1-32-2020") == False
    
    def test_day_boundary_values_30_day_months(self):
        assert valid_date("4-30-2020") == False
        assert valid_date("4-31-2020") == False
    
    def test_february_boundary(self):
        assert valid_date("2-29-2020") == True
        assert valid_date("2-30-2020") == False