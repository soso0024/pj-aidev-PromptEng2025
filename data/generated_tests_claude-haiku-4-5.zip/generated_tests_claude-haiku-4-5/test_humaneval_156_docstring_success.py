# Test cases for HumanEval/156
# Generated using Claude API


def int_to_mini_roman(number):
    """
    Given a positive integer, obtain its roman numeral equivalent as a string,
    and return it in lowercase.
    Restrictions: 1 <= num <= 1000

    Examples:
    >>> int_to_mini_roman(19) == 'xix'
    >>> int_to_mini_roman(152) == 'clii'
    >>> int_to_mini_roman(426) == 'cdxxvi'
    """

    num = [1, 4, 5, 9, 10, 40, 50, 90,  
           100, 400, 500, 900, 1000] 
    sym = ["I", "IV", "V", "IX", "X", "XL",  
           "L", "XC", "C", "CD", "D", "CM", "M"] 
    i = 12
    res = ''
    while number: 
        div = number // num[i] 
        number %= num[i] 
        while div: 
            res += sym[i] 
            div -= 1
        i -= 1
    return res.lower()


# Generated test cases:
import pytest


def int_to_mini_roman(number):
    num = [1, 4, 5, 9, 10, 40, 50, 90,  
           100, 400, 500, 900, 1000] 
    sym = ["I", "IV", "V", "IX", "X", "XL",  
           "L", "XC", "C", "CD", "D", "CM", "M"] 
    i = 12
    res = ''
    while number: 
        div = number // num[i] 
        number %= num[i] 
        while div: 
            res += sym[i] 
            div -= 1
        i -= 1
    return res.lower()


class TestIntToMiniRoman:
    
    @pytest.mark.parametrize("number,expected", [
        (1, "i"),
        (2, "ii"),
        (3, "iii"),
        (4, "iv"),
        (5, "v"),
        (6, "vi"),
        (7, "vii"),
        (8, "viii"),
        (9, "ix"),
        (10, "x"),
        (19, "xix"),
        (27, "xxvii"),
        (48, "xlviii"),
        (59, "lix"),
        (93, "xciii"),
        (141, "cxli"),
        (163, "clxiii"),
        (152, "clii"),
        (426, "cdxxvi"),
        (500, "d"),
        (944, "cmxliv"),
        (1000, "m"),
        (999, "cmxcix"),
        (444, "cdxliv"),
        (888, "dccclxxxviii"),
    ])
    def test_int_to_mini_roman_valid_numbers(self, number, expected):
        assert int_to_mini_roman(number) == expected
    
    def test_int_to_mini_roman_one(self):
        assert int_to_mini_roman(1) == "i"
    
    def test_int_to_mini_roman_max_value(self):
        assert int_to_mini_roman(1000) == "m"
    
    def test_int_to_mini_roman_returns_lowercase(self):
        result = int_to_mini_roman(49)
        assert result == result.lower()
    
    def test_int_to_mini_roman_returns_string(self):
        result = int_to_mini_roman(100)
        assert isinstance(result, str)
    
    def test_int_to_mini_roman_subtractive_notation(self):
        assert int_to_mini_roman(4) == "iv"
        assert int_to_mini_roman(9) == "ix"
        assert int_to_mini_roman(40) == "xl"
        assert int_to_mini_roman(90) == "xc"
        assert int_to_mini_roman(400) == "cd"
        assert int_to_mini_roman(900) == "cm"
    
    def test_int_to_mini_roman_additive_notation(self):
        assert int_to_mini_roman(3) == "iii"
        assert int_to_mini_roman(8) == "viii"
        assert int_to_mini_roman(30) == "xxx"
        assert int_to_mini_roman(80) == "lxxx"
        assert int_to_mini_roman(300) == "ccc"
        assert int_to_mini_roman(800) == "dccc"
    
    def test_int_to_mini_roman_complex_numbers(self):
        assert int_to_mini_roman(1994) == "mcmxciv"
        assert int_to_mini_roman(58) == "lviii"
        assert int_to_mini_roman(1984) == "mcmlxxxiv"
    
    def test_int_to_mini_roman_powers_of_ten(self):
        assert int_to_mini_roman(10) == "x"
        assert int_to_mini_roman(100) == "c"
        assert int_to_mini_roman(1000) == "m"
    
    def test_int_to_mini_roman_powers_of_five(self):
        assert int_to_mini_roman(5) == "v"
        assert int_to_mini_roman(50) == "l"
        assert int_to_mini_roman(500) == "d"
