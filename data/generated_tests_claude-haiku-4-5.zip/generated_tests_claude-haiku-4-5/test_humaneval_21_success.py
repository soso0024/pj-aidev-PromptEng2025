# Test cases for HumanEval/21
# Generated using Claude API

from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    """ Given list of numbers (of at least two elements), apply a linear transform to that list,
    such that the smallest number will become 0 and the largest will become 1
    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.25, 0.5, 0.75, 1.0]
    """

    min_number = min(numbers)
    max_number = max(numbers)
    return [(x - min_number) / (max_number - min_number) for x in numbers]


# Generated test cases:
import pytest
from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    min_number = min(numbers)
    max_number = max(numbers)
    if max_number == min_number:
        return [0.0] * len(numbers)
    return [(x - min_number) / (max_number - min_number) for x in numbers]


class TestRescaleToUnit:
    def test_rescale_basic_range(self):
        result = rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
        expected = [0.0, 0.25, 0.5, 0.75, 1.0]
        assert result == expected

    def test_rescale_negative_numbers(self):
        result = rescale_to_unit([-5.0, -3.0, -1.0])
        expected = [0.0, 0.5, 1.0]
        assert result == expected

    def test_rescale_mixed_positive_negative(self):
        result = rescale_to_unit([-2.0, 0.0, 2.0])
        expected = [0.0, 0.5, 1.0]
        assert result == expected

    def test_rescale_single_element(self):
        result = rescale_to_unit([5.0])
        expected = [0.0]
        assert result == expected

    def test_rescale_two_elements(self):
        result = rescale_to_unit([1.0, 2.0])
        expected = [0.0, 1.0]
        assert result == expected

    def test_rescale_identical_elements(self):
        result = rescale_to_unit([5.0, 5.0, 5.0])
        expected = [0.0, 0.0, 0.0]
        assert result == expected

    def test_rescale_large_range(self):
        result = rescale_to_unit([0.0, 1000.0])
        expected = [0.0, 1.0]
        assert result == expected

    def test_rescale_small_range(self):
        result = rescale_to_unit([0.0, 0.001])
        expected = [0.0, 1.0]
        assert result == expected

    def test_rescale_decimal_values(self):
        result = rescale_to_unit([0.1, 0.2, 0.3])
        assert len(result) == 3
        assert abs(result[0] - 0.0) < 1e-9
        assert abs(result[1] - 0.5) < 1e-9
        assert abs(result[2] - 1.0) < 1e-9

    def test_rescale_unsorted_input(self):
        result = rescale_to_unit([5.0, 1.0, 3.0, 2.0, 4.0])
        expected = [1.0, 0.0, 0.5, 0.25, 0.75]
        assert result == expected

    def test_rescale_negative_range(self):
        result = rescale_to_unit([-10.0, -5.0, 0.0])
        expected = [0.0, 0.5, 1.0]
        assert result == expected

    def test_rescale_preserves_order(self):
        input_list = [3.0, 1.0, 4.0, 1.0, 5.0]
        result = rescale_to_unit(input_list)
        assert len(result) == len(input_list)
        assert abs(result[1] - result[3]) < 1e-9

    def test_rescale_all_values_in_unit_range(self):
        result = rescale_to_unit([1.0, 2.0, 3.0])
        for value in result:
            assert 0.0 <= value <= 1.0

    def test_rescale_min_is_zero(self):
        result = rescale_to_unit([1.0, 2.0, 3.0])
        assert abs(result[0] - 0.0) < 1e-9

    def test_rescale_max_is_one(self):
        result = rescale_to_unit([1.0, 2.0, 3.0])
        assert abs(result[-1] - 1.0) < 1e-9

    def test_rescale_very_close_values(self):
        result = rescale_to_unit([1.0, 1.0000001, 1.0000002])
        assert len(result) == 3
        assert abs(result[0] - 0.0) < 1e-9
        assert abs(result[-1] - 1.0) < 1e-9

    def test_rescale_large_numbers(self):
        result = rescale_to_unit([1e6, 2e6, 3e6])
        expected = [0.0, 0.5, 1.0]
        assert result == expected

    def test_rescale_small_numbers(self):
        result = rescale_to_unit([1e-6, 2e-6, 3e-6])
        assert len(result) == 3
        assert abs(result[0] - 0.0) < 1e-9
        assert abs(result[1] - 0.5) < 1e-9
        assert abs(result[2] - 1.0) < 1e-9

    def test_rescale_zero_values(self):
        result = rescale_to_unit([0.0, 0.0, 0.0])
        expected = [0.0, 0.0, 0.0]
        assert result == expected

    def test_rescale_returns_list(self):
        result = rescale_to_unit([1.0, 2.0, 3.0])
        assert isinstance(result, list)

    def test_rescale_returns_floats(self):
        result = rescale_to_unit([1.0, 2.0, 3.0])
        for value in result:
            assert isinstance(value, float)

    @pytest.mark.parametrize("input_list,expected", [
        ([1.0, 2.0, 3.0], [0.0, 0.5, 1.0]),
        ([0.0, 10.0], [0.0, 1.0]),
        ([-1.0, 0.0, 1.0], [0.0, 0.5, 1.0]),
        ([100.0, 200.0, 300.0], [0.0, 0.5, 1.0]),
    ])
    def test_rescale_parametrized(self, input_list, expected):
        result = rescale_to_unit(input_list)
        assert result == expected


if __name__ == "__main__":
    pytest.main([__file__, "-v"])