# Test cases for HumanEval/61
# Generated using Claude API



def correct_bracketing(brackets: str):
    """ brackets is a string of "(" and ")".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """

    depth = 0
    for b in brackets:
        if b == "(":
            depth += 1
        else:
            depth -= 1
        if depth < 0:
            return False
    return depth == 0


# Generated test cases:
import pytest


def correct_bracketing(brackets: str):
    depth = 0
    for b in brackets:
        if b == "(":
            depth += 1
        else:
            depth -= 1
        if depth < 0:
            return False
    return depth == 0


class TestCorrectBracketing:
    
    @pytest.mark.parametrize("brackets,expected", [
        ("()", True),
        ("(()())", True),
        ("()()", True),
        ("((()))", True),
        ("()()()", True),
        ("(()(()))", True),
    ])
    def test_correct_bracketing_valid(self, brackets, expected):
        assert correct_bracketing(brackets) == expected
    
    @pytest.mark.parametrize("brackets,expected", [
        ("(", False),
        (")", False),
        ("(()", False),
        ("())", False),
        (")(()", False),
        (")(", False),
        (")))((", False),
        ("(()())", True),
    ])
    def test_correct_bracketing_invalid(self, brackets, expected):
        assert correct_bracketing(brackets) == expected
    
    def test_empty_string(self):
        assert correct_bracketing("") == True
    
    def test_single_opening_bracket(self):
        assert correct_bracketing("(") == False
    
    def test_single_closing_bracket(self):
        assert correct_bracketing(")") == False
    
    def test_multiple_opening_brackets(self):
        assert correct_bracketing("(((") == False
    
    def test_multiple_closing_brackets(self):
        assert correct_bracketing(")))") == False
    
    def test_closing_before_opening(self):
        assert correct_bracketing(")(") == False
    
    def test_multiple_closing_before_opening(self):
        assert correct_bracketing("))(") == False
    
    def test_nested_brackets(self):
        assert correct_bracketing("((()))") == True
    
    def test_alternating_brackets(self):
        assert correct_bracketing("()()()") == True
    
    def test_complex_valid_pattern(self):
        assert correct_bracketing("(())(())") == True
    
    def test_complex_invalid_pattern_extra_closing(self):
        assert correct_bracketing("(())(()))") == False
    
    def test_complex_invalid_pattern_extra_opening(self):
        assert correct_bracketing("((())((())") == False
    
    def test_closing_bracket_at_start(self):
        assert correct_bracketing(")()") == False
    
    def test_long_valid_sequence(self):
        assert correct_bracketing("()" * 50) == True
    
    def test_long_invalid_sequence_extra_closing(self):
        assert correct_bracketing("()" * 50 + ")") == False
    
    def test_long_invalid_sequence_extra_opening(self):
        assert correct_bracketing("(" + "()" * 50) == False
    
    def test_deeply_nested_valid(self):
        assert correct_bracketing("(" * 10 + ")" * 10) == True
    
    def test_deeply_nested_invalid(self):
        assert correct_bracketing("(" * 10 + ")" * 9) == False
