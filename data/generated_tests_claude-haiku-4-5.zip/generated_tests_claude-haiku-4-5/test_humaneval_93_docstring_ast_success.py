# Test cases for HumanEval/93
# Generated using Claude API


def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """

    vowels = "aeiouAEIOU"
    vowels_replace = dict([(i, chr(ord(i) + 2)) for i in vowels])
    message = message.swapcase()
    return ''.join([vowels_replace[i] if i in vowels else i for i in message])


# Generated test cases:
import pytest


class TestEncode:
    
    @pytest.mark.parametrize("input_msg,expected", [
        ("test", "TGST"),
        ("This is a message", "tHKS KS C MGSSCGG"),
    ])
    def test_docstring_examples(self, input_msg, expected):
        from test_humaneval_93_docstring_ast import encode
        assert encode(input_msg) == expected
    
    def test_empty_string(self):
        assert encode("") == ""
    
    def test_single_lowercase_vowel_a(self):
        assert encode("a") == "C"
    
    def test_single_lowercase_vowel_e(self):
        assert encode("e") == "G"
    
    def test_single_lowercase_vowel_i(self):
        assert encode("i") == "K"
    
    def test_single_lowercase_vowel_o(self):
        assert encode("o") == "Q"
    
    def test_single_lowercase_vowel_u(self):
        assert encode("u") == "W"
    
    def test_single_uppercase_vowel_a(self):
        assert encode("A") == "c"
    
    def test_single_uppercase_vowel_e(self):
        assert encode("E") == "g"
    
    def test_single_uppercase_vowel_i(self):
        assert encode("I") == "k"
    
    def test_single_uppercase_vowel_o(self):
        assert encode("O") == "q"
    
    def test_single_uppercase_vowel_u(self):
        assert encode("U") == "w"
    
    def test_single_consonant_lowercase(self):
        assert encode("b") == "B"
    
    def test_single_consonant_uppercase(self):
        assert encode("B") == "b"
    
    def test_all_lowercase_vowels(self):
        assert encode("aeiou") == "CGKQW"
    
    def test_all_uppercase_vowels(self):
        assert encode("AEIOU") == "cgkqw"
    
    def test_all_lowercase_consonants(self):
        assert encode("bcdfg") == "BCDFG"
    
    def test_all_uppercase_consonants(self):
        assert encode("BCDFG") == "bcdfg"
    
    def test_mixed_case_no_vowels(self):
        assert encode("BcDfG") == "bCdFg"
    
    def test_spaces_preserved(self):
        assert encode("hello world") == "HGLLQ WQRLD"
    
    def test_multiple_spaces(self):
        assert encode("a  b") == "C  B"
    
    def test_long_message(self):
        result = encode("The quick brown fox jumps over the lazy dog")
        assert result == "tHG QWKCK BRQWN FQX JWMPS QVGR THG LCZY DQG"
    
    def test_repeated_vowels(self):
        assert encode("aaa") == "CCC"
    
    def test_repeated_consonants(self):
        assert encode("bbb") == "BBB"
    
    def test_alternating_vowels_consonants(self):
        assert encode("aba") == "CBC"
    
    def test_case_swap_only_consonants(self):
        assert encode("xyz") == "XYZ"
    
    def test_case_swap_only_consonants_uppercase(self):
        assert encode("XYZ") == "xyz"
    
    def test_vowel_at_start(self):
        assert encode("apple") == "CPPLG"
    
    def test_vowel_at_end(self):
        assert encode("tree") == "TRGG"
    
    def test_vowel_in_middle(self):
        assert encode("cat") == "CCT"
    
    def test_consecutive_vowels(self):
        assert encode("eat") == "GCT"
    
    def test_all_same_vowel(self):
        assert encode("eeee") == "GGGG"
    
    def test_mixed_case_with_vowels(self):
        assert encode("HeLLo") == "hGllQ"
    
    def test_sentence_with_punctuation_spaces(self):
        result = encode("hello world")
        assert result == "HGLLQ WQRLD"
    
    def test_single_letter_words(self):
        assert encode("I a e") == "k C G"
    
    def test_uppercase_sentence(self):
        assert encode("HELLO") == "hgllq"
    
    def test_lowercase_sentence(self):
        assert encode("hello") == "HGLLQ"
    
    def test_vowel_replacement_mapping(self):
        mapping = {
            'a': 'C', 'e': 'G', 'i': 'K', 'o': 'Q', 'u': 'W',
            'A': 'c', 'E': 'g', 'I': 'k', 'O': 'q', 'U': 'w'
        }
        for vowel, replacement in mapping.items():
            assert encode(vowel) == replacement
    
    def test_no_vowels_in_message(self):
        assert encode("xyz") == "XYZ"
    
    def test_only_vowels(self):
        assert encode("aeiouAEIOU") == "CGKQWcgkqw"
    
    def test_word_with_all_vowels_and_consonants(self):
        assert encode("beautiful") == "BGCWTKFWL"
    
    def test_repeated_pattern(self):
        assert encode("abab") == "CBCB"