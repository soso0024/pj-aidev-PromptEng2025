# Test cases for HumanEval/163
# Generated using Claude API


def generate_integers(a, b):
    """
    Given two positive integers a and b, return the even digits between a
    and b, in ascending order.

    For example:
    generate_integers(2, 8) => [2, 4, 6, 8]
    generate_integers(8, 2) => [2, 4, 6, 8]
    generate_integers(10, 14) => []
    """

    lower = max(2, min(a, b))
    upper = min(8, max(a, b))

    return [i for i in range(lower, upper+1) if i % 2 == 0]


# Generated test cases:
import pytest


def generate_integers(a, b):
    lower = max(2, min(a, b))
    upper = min(8, max(a, b))

    return [i for i in range(lower, upper+1) if i % 2 == 0]


class TestGenerateIntegers:
    
    def test_normal_case_ascending(self):
        result = generate_integers(2, 8)
        assert result == [2, 4, 6, 8]
    
    def test_normal_case_descending(self):
        result = generate_integers(8, 2)
        assert result == [2, 4, 6, 8]
    
    def test_single_even_number(self):
        result = generate_integers(4, 4)
        assert result == [4]
    
    def test_single_odd_number(self):
        result = generate_integers(5, 5)
        assert result == []
    
    def test_range_below_minimum(self):
        result = generate_integers(0, 1)
        assert result == []
    
    def test_range_above_maximum(self):
        result = generate_integers(9, 10)
        assert result == []
    
    def test_range_partially_below_minimum(self):
        result = generate_integers(1, 5)
        assert result == [2, 4]
    
    def test_range_partially_above_maximum(self):
        result = generate_integers(5, 10)
        assert result == [6, 8]
    
    def test_negative_numbers(self):
        result = generate_integers(-5, 3)
        assert result == [2]
    
    def test_both_negative(self):
        result = generate_integers(-10, -5)
        assert result == []
    
    def test_negative_to_positive(self):
        result = generate_integers(-2, 6)
        assert result == [2, 4, 6]
    
    def test_odd_range_within_bounds(self):
        result = generate_integers(3, 7)
        assert result == [4, 6]
    
    def test_minimum_boundary(self):
        result = generate_integers(2, 2)
        assert result == [2]
    
    def test_maximum_boundary(self):
        result = generate_integers(8, 8)
        assert result == [8]
    
    def test_full_range(self):
        result = generate_integers(2, 8)
        assert result == [2, 4, 6, 8]
    
    def test_large_negative_to_small_positive(self):
        result = generate_integers(-100, 5)
        assert result == [2, 4]
    
    def test_large_positive_numbers(self):
        result = generate_integers(100, 200)
        assert result == []
    
    def test_zero_and_positive(self):
        result = generate_integers(0, 8)
        assert result == [2, 4, 6, 8]
    
    def test_zero_and_negative(self):
        result = generate_integers(-8, 0)
        assert result == []
    
    def test_reversed_order_with_odds(self):
        result = generate_integers(7, 3)
        assert result == [4, 6]
    
    def test_single_value_at_lower_bound(self):
        result = generate_integers(2, 1)
        assert result == [2]
    
    def test_single_value_at_upper_bound(self):
        result = generate_integers(9, 8)
        assert result == [8]
    
    def test_all_odd_numbers_in_range(self):
        result = generate_integers(3, 5)
        assert result == [4]
    
    def test_consecutive_even_numbers(self):
        result = generate_integers(2, 4)
        assert result == [2, 4]
    
    def test_large_range_clamped(self):
        result = generate_integers(-1000, 1000)
        assert result == [2, 4, 6, 8]


@pytest.mark.parametrize("a,b,expected", [
    (2, 8, [2, 4, 6, 8]),
    (8, 2, [2, 4, 6, 8]),
    (4, 4, [4]),
    (5, 5, []),
    (0, 1, []),
    (9, 10, []),
    (1, 5, [2, 4]),
    (5, 10, [6, 8]),
    (-5, 3, [2]),
    (-10, -5, []),
    (-2, 6, [2, 4, 6]),
    (3, 7, [4, 6]),
    (2, 2, [2]),
    (8, 8, [8]),
    (-100, 5, [2, 4]),
    (100, 200, []),
    (0, 8, [2, 4, 6, 8]),
    (-8, 0, []),
    (7, 3, [4, 6]),
    (2, 1, [2]),
    (9, 8, [8]),
    (3, 5, [4]),
    (2, 4, [2, 4]),
    (-1000, 1000, [2, 4, 6, 8]),
])
def test_generate_integers_parametrized(a, b, expected):
    assert generate_integers(a, b) == expected


def test_return_type_is_list():
    result = generate_integers(2, 8)
    assert isinstance(result, list)


def test_all_elements_are_even():
    result = generate_integers(2, 8)
    for num in result:
        assert num % 2 == 0


def test_all_elements_in_valid_range():
    result = generate_integers(2, 8)
    for num in result:
        assert 2 <= num <= 8


def test_result_is_sorted():
    result = generate_integers(8, 2)
    assert result == sorted(result)