# Test cases for HumanEval/85
# Generated using Claude API


def add(lst):
    """Given a non-empty list of integers lst. add the even elements that are at odd indices..


    Examples:
        add([4, 2, 6, 7]) ==> 2 
    """

    return sum([lst[i] for i in range(1, len(lst), 2) if lst[i]%2 == 0])


# Generated test cases:
import pytest


def add(lst):
    return sum([lst[i] for i in range(1, len(lst), 2) if lst[i]%2 == 0])


class TestAdd:
    def test_empty_list(self):
        assert add([]) == 0

    def test_single_element(self):
        assert add([1]) == 0

    def test_two_elements_even_at_index_1(self):
        assert add([1, 2]) == 2

    def test_two_elements_odd_at_index_1(self):
        assert add([1, 3]) == 0

    def test_multiple_elements_all_even_at_odd_indices(self):
        assert add([1, 2, 3, 4, 5, 6]) == 12

    def test_multiple_elements_all_odd_at_odd_indices(self):
        assert add([1, 3, 5, 7, 9, 11]) == 0

    def test_mixed_even_odd_at_odd_indices(self):
        assert add([0, 2, 1, 4, 3, 6, 5, 8]) == 20

    def test_only_odd_indices_matter(self):
        assert add([100, 2, 200, 4, 300, 6]) == 12

    def test_negative_even_numbers_at_odd_indices(self):
        assert add([1, -2, 3, -4, 5, -6]) == -12

    def test_negative_odd_numbers_at_odd_indices(self):
        assert add([1, -1, 3, -3, 5, -5]) == 0

    def test_zero_at_odd_indices(self):
        assert add([1, 0, 3, 0, 5, 0]) == 0

    def test_large_even_numbers(self):
        assert add([1, 1000, 3, 2000, 5, 3000]) == 6000

    def test_three_elements(self):
        assert add([10, 5, 20]) == 0

    def test_three_elements_even_at_index_1(self):
        assert add([10, 4, 20]) == 4

    def test_four_elements(self):
        assert add([1, 2, 3, 4]) == 6

    def test_five_elements(self):
        assert add([1, 2, 3, 4, 5]) == 6

    def test_alternating_pattern(self):
        assert add([0, 1, 0, 2, 0, 3, 0, 4]) == 6

    def test_all_zeros(self):
        assert add([0, 0, 0, 0]) == 0

    def test_single_even_at_odd_index(self):
        assert add([999, 2]) == 2

    def test_multiple_same_even_values(self):
        assert add([1, 2, 3, 2, 5, 2]) == 6

    def test_large_list(self):
        lst = list(range(100))
        result = add(lst)
        expected = sum([lst[i] for i in range(1, len(lst), 2) if lst[i] % 2 == 0])
        assert result == expected

    def test_negative_and_positive_mix(self):
        assert add([-1, 2, -3, -4, -5, 6]) == 4

    def test_index_1_only(self):
        assert add([100, 50]) == 50

    def test_index_1_and_3(self):
        assert add([0, 10, 0, 20]) == 30

    def test_index_1_3_5(self):
        assert add([0, 2, 0, 4, 0, 6]) == 12

    def test_odd_length_list(self):
        assert add([1, 2, 3, 4, 5]) == 6

    def test_even_length_list(self):
        assert add([1, 2, 3, 4]) == 6