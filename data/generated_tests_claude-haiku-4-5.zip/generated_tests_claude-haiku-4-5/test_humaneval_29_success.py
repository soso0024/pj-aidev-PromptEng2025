# Test cases for HumanEval/29
# Generated using Claude API

from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    """ Filter an input list of strings only for ones that start with a given prefix.
    >>> filter_by_prefix([], 'a')
    []
    >>> filter_by_prefix(['abc', 'bcd', 'cde', 'array'], 'a')
    ['abc', 'array']
    """

    return [x for x in strings if x.startswith(prefix)]


# Generated test cases:
import pytest
from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    return [x for x in strings if x.startswith(prefix)]


class TestFilterByPrefix:
    
    def test_empty_list(self):
        result = filter_by_prefix([], "test")
        assert result == []
    
    def test_empty_prefix(self):
        result = filter_by_prefix(["hello", "world"], "")
        assert result == ["hello", "world"]
    
    def test_no_matches(self):
        result = filter_by_prefix(["hello", "world"], "xyz")
        assert result == []
    
    def test_single_match(self):
        result = filter_by_prefix(["hello", "world"], "hel")
        assert result == ["hello"]
    
    def test_multiple_matches(self):
        result = filter_by_prefix(["hello", "help", "world", "helpful"], "hel")
        assert result == ["hello", "help", "helpful"]
    
    def test_exact_match(self):
        result = filter_by_prefix(["hello", "world"], "hello")
        assert result == ["hello"]
    
    def test_case_sensitive(self):
        result = filter_by_prefix(["Hello", "hello", "HELLO"], "hello")
        assert result == ["hello"]
    
    def test_single_character_prefix(self):
        result = filter_by_prefix(["apple", "apricot", "banana"], "a")
        assert result == ["apple", "apricot"]
    
    def test_prefix_longer_than_strings(self):
        result = filter_by_prefix(["hi", "bye"], "hello")
        assert result == []
    
    def test_all_strings_match(self):
        result = filter_by_prefix(["test1", "test2", "test3"], "test")
        assert result == ["test1", "test2", "test3"]
    
    def test_special_characters_in_prefix(self):
        result = filter_by_prefix(["@user", "@admin", "user"], "@")
        assert result == ["@user", "@admin"]
    
    def test_special_characters_in_strings(self):
        result = filter_by_prefix(["hello-world", "hello_world", "hello world"], "hello-")
        assert result == ["hello-world"]
    
    def test_numbers_in_prefix(self):
        result = filter_by_prefix(["123abc", "123def", "456abc"], "123")
        assert result == ["123abc", "123def"]
    
    def test_whitespace_in_prefix(self):
        result = filter_by_prefix(["hello world", "hello there", "goodbye"], "hello ")
        assert result == ["hello world", "hello there"]
    
    def test_unicode_characters(self):
        result = filter_by_prefix(["café", "car", "cat"], "ca")
        assert result == ["café", "car", "cat"]
    
    def test_unicode_prefix(self):
        result = filter_by_prefix(["café", "cafeteria", "car"], "café")
        assert result == ["café"]
    
    def test_duplicate_strings(self):
        result = filter_by_prefix(["hello", "hello", "world"], "hel")
        assert result == ["hello", "hello"]
    
    def test_empty_string_in_list(self):
        result = filter_by_prefix(["", "hello", "world"], "")
        assert result == ["", "hello", "world"]
    
    def test_empty_string_in_list_with_prefix(self):
        result = filter_by_prefix(["", "hello", "world"], "hel")
        assert result == ["hello"]
    
    def test_prefix_is_empty_string_with_empty_list(self):
        result = filter_by_prefix([], "")
        assert result == []


@pytest.mark.parametrize("strings,prefix,expected", [
    (["hello", "world"], "hel", ["hello"]),
    (["apple", "apricot", "banana"], "ap", ["apple", "apricot"]),
    (["test"], "test", ["test"]),
    (["a", "ab", "abc"], "ab", ["ab", "abc"]),
    (["xyz", "xya", "xyb"], "xy", ["xyz", "xya", "xyb"]),
    (["hello", "HELLO"], "HEL", ["HELLO"]),
    (["123", "124", "125"], "12", ["123", "124", "125"]),
])
def test_filter_by_prefix_parametrized(strings, prefix, expected):
    assert filter_by_prefix(strings, prefix) == expected


@pytest.mark.parametrize("strings,prefix,expected", [
    ([], "", []),
    ([], "any", []),
    ([""], "", [""]),
    (["hello"], "", ["hello"]),
])
def test_filter_by_prefix_edge_cases_parametrized(strings, prefix, expected):
    assert filter_by_prefix(strings, prefix) == expected