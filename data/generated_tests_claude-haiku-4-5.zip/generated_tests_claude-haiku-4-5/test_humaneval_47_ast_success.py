# Test cases for HumanEval/47
# Generated using Claude API



def median(l: list):
    """Return median of elements in the list l.
    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """

    l = sorted(l)
    if len(l) % 2 == 1:
        return l[len(l) // 2]
    else:
        return (l[len(l) // 2 - 1] + l[len(l) // 2]) / 2.0


# Generated test cases:
import pytest


def median(l: list):
    l = sorted(l)
    if len(l) % 2 == 1:
        return l[len(l) // 2]
    else:
        return (l[len(l) // 2 - 1] + l[len(l) // 2]) / 2.0


class TestMedian:
    def test_single_element(self):
        assert median([5]) == 5

    def test_two_elements(self):
        assert median([1, 2]) == 1.5

    def test_three_elements(self):
        assert median([1, 2, 3]) == 2

    def test_odd_length_list(self):
        assert median([3, 1, 4, 1, 5]) == 3

    def test_even_length_list(self):
        assert median([1, 2, 3, 4]) == 2.5

    def test_unsorted_list(self):
        assert median([5, 2, 8, 1, 9]) == 5

    def test_negative_numbers(self):
        assert median([-5, -2, -8, -1]) == -3.5

    def test_mixed_positive_negative(self):
        assert median([-2, -1, 0, 1, 2]) == 0

    def test_duplicates(self):
        assert median([1, 1, 1, 1]) == 1.0

    def test_duplicates_odd(self):
        assert median([1, 2, 2, 2, 3]) == 2

    def test_large_numbers(self):
        assert median([1000000, 2000000, 3000000]) == 2000000

    def test_floats(self):
        assert median([1.5, 2.5, 3.5]) == 2.5

    def test_floats_even(self):
        assert median([1.0, 2.0, 3.0, 4.0]) == 2.5

    def test_negative_floats(self):
        assert median([-1.5, -0.5, 0.5, 1.5]) == 0.0

    def test_zero_in_list(self):
        assert median([0, 0, 0]) == 0

    def test_mixed_zeros(self):
        assert median([-1, 0, 1]) == 0

    def test_five_elements(self):
        assert median([5, 1, 3, 2, 4]) == 3

    def test_six_elements(self):
        assert median([6, 1, 5, 2, 4, 3]) == 3.5

    def test_already_sorted(self):
        assert median([1, 2, 3, 4, 5]) == 3

    def test_reverse_sorted(self):
        assert median([5, 4, 3, 2, 1]) == 3

    def test_all_same_elements(self):
        assert median([7, 7, 7, 7, 7]) == 7

    def test_two_same_elements(self):
        assert median([5, 5]) == 5.0

    def test_large_list_odd(self):
        assert median(list(range(1, 100, 2))) == 50

    def test_large_list_even(self):
        assert median(list(range(1, 101))) == 50.5

    def test_negative_to_positive_range(self):
        assert median([-5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5]) == 0

    def test_decimal_precision(self):
        result = median([0.1, 0.2, 0.3, 0.4])
        assert abs(result - 0.25) < 1e-10

    def test_very_small_numbers(self):
        assert median([0.001, 0.002, 0.003]) == 0.002

    def test_very_large_numbers(self):
        assert median([1e10, 2e10, 3e10]) == 2e10

    def test_mixed_int_float(self):
        assert median([1, 2.5, 3]) == 2.5

    def test_seven_elements(self):
        assert median([7, 3, 1, 5, 2, 6, 4]) == 4

    def test_eight_elements(self):
        assert median([8, 4, 2, 6, 1, 7, 3, 5]) == 4.5
