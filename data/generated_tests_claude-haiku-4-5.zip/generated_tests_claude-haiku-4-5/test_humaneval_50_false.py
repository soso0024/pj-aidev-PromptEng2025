# Test cases for HumanEval/50
# Generated using Claude API



def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


def decode_shift(s: str):
    """
    takes as input string encoded with encode_shift function. Returns decoded string.
    """

    return "".join([chr(((ord(ch) - 5 - ord("a")) % 26) + ord("a")) for ch in s])


# Generated test cases:
import pytest


def decode_shift(s: str):
    return "".join([chr(((ord(ch) - 5 - ord("a")) % 26) + ord("a")) for ch in s])


class TestDecodeShift:
    
    def test_empty_string(self):
        assert decode_shift("") == ""
    
    def test_single_character_a(self):
        assert decode_shift("a") == "v"
    
    def test_single_character_b(self):
        assert decode_shift("b") == "w"
    
    def test_single_character_z(self):
        assert decode_shift("z") == "u"
    
    def test_simple_word(self):
        assert decode_shift("bcd") == "wxy"
    
    def test_wrap_around_beginning(self):
        assert decode_shift("abc") == "vwx"
    
    def test_all_alphabet(self):
        result = decode_shift("abcdefghijklmnopqrstuvwxyz")
        assert len(result) == 26
        assert all(c.isalpha() and c.islower() for c in result)
    
    def test_repeated_characters(self):
        assert decode_shift("aaa") == "vvv"
    
    def test_repeated_characters_z(self):
        assert decode_shift("zzz") == "uuu"
    
    def test_long_string(self):
        input_str = "abcdefghijklmnopqrstuvwxyz" * 10
        result = decode_shift(input_str)
        assert len(result) == 260
    
    def test_decode_shift_consistency(self):
        original = "hello"
        decoded = decode_shift(original)
        assert isinstance(decoded, str)
        assert len(decoded) == len(original)
    
    def test_decode_shift_with_e(self):
        assert decode_shift("e") == "z"
    
    def test_decode_shift_with_f(self):
        assert decode_shift("f") == "a"
    
    def test_decode_shift_with_g(self):
        assert decode_shift("g") == "b"
    
    @pytest.mark.parametrize("input_str,expected", [
        ("a", "v"),
        ("b", "w"),
        ("c", "x"),
        ("d", "y"),
        ("e", "z"),
        ("f", "a"),
        ("z", "u"),
    ])
    def test_individual_characters(self, input_str, expected):
        assert decode_shift(input_str) == expected
    
    @pytest.mark.parametrize("input_str", [
        "a",
        "ab",
        "abc",
        "abcdefghijklmnopqrstuvwxyz",
        "zzz",
        "aaa",
    ])
    def test_output_is_lowercase(self, input_str):
        result = decode_shift(input_str)
        assert result.islower()
    
    @pytest.mark.parametrize("input_str", [
        "a",
        "ab",
        "abc",
        "abcdefghijklmnopqrstuvwxyz",
    ])
    def test_output_length_matches_input(self, input_str):
        result = decode_shift(input_str)
        assert len(result) == len(input_str)
    
    def test_decode_shift_reversible_property(self):
        test_strings = ["a", "z", "abc", "xyz", "hello"]
        for s in test_strings:
            decoded_once = decode_shift(s)
            decoded_twice = decode_shift(decoded_once)
            decoded_thrice = decode_shift(decoded_twice)
            decoded_four = decode_shift(decoded_thrice)
            decoded_five = decode_shift(decoded_four)
            assert decoded_five == s
    
    def test_decode_shift_modulo_behavior(self):
        result_a = decode_shift("a")
        result_f = decode_shift("f")
        assert result_a != result_f
        assert result_f == "a"
    
    def test_decode_shift_wrap_around(self):
        result = decode_shift("abcde")
        assert all(c in "abcdefghijklmnopqrstuvwxyz" for c in result)
    
    def test_decode_shift_no_special_characters(self):
        result = decode_shift("abcxyz")
        assert result.isalpha()
        assert result.islower()