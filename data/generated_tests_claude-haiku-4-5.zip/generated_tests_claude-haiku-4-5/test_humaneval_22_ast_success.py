# Test cases for HumanEval/22
# Generated using Claude API

from typing import List, Any


def filter_integers(values: List[Any]) -> List[int]:
    """ Filter given list of any python values only for integers
    >>> filter_integers(['a', 3.14, 5])
    [5]
    >>> filter_integers([1, 2, 3, 'abc', {}, []])
    [1, 2, 3]
    """

    return [x for x in values if isinstance(x, int)]


# Generated test cases:
import pytest
from typing import List, Any


def filter_integers(values: List[Any]) -> List[int]:
    return [x for x in values if isinstance(x, int)]


class TestFilterIntegers:
    def test_empty_list(self):
        assert filter_integers([]) == []

    def test_only_integers(self):
        assert filter_integers([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

    def test_only_strings(self):
        assert filter_integers(["a", "b", "c"]) == []

    def test_only_floats(self):
        assert filter_integers([1.5, 2.7, 3.14]) == []

    def test_mixed_types(self):
        assert filter_integers([1, "hello", 2, 3.14, 4, None, 5]) == [1, 2, 4, 5]

    def test_negative_integers(self):
        assert filter_integers([-1, -2, -3]) == [-1, -2, -3]

    def test_zero(self):
        assert filter_integers([0, 1, 2]) == [0, 1, 2]

    def test_mixed_positive_negative(self):
        assert filter_integers([-5, 0, 5, -10, 10]) == [-5, 0, 5, -10, 10]

    def test_with_booleans(self):
        assert filter_integers([True, False, 1, 2]) == [True, False, 1, 2]

    def test_with_none(self):
        assert filter_integers([1, None, 2, None, 3]) == [1, 2, 3]

    def test_with_lists(self):
        assert filter_integers([1, [2, 3], 4]) == [1, 4]

    def test_with_dicts(self):
        assert filter_integers([1, {"key": "value"}, 2]) == [1, 2]

    def test_with_tuples(self):
        assert filter_integers([1, (2, 3), 4]) == [1, 4]

    def test_large_integers(self):
        assert filter_integers([1000000, 2000000, 3000000]) == [1000000, 2000000, 3000000]

    def test_very_large_integers(self):
        assert filter_integers([10**100, 10**200]) == [10**100, 10**200]

    def test_single_integer(self):
        assert filter_integers([42]) == [42]

    def test_single_non_integer(self):
        assert filter_integers(["string"]) == []

    def test_complex_mixed_types(self):
        assert filter_integers([1, 2.5, "three", 4, None, [], {}, (1, 2), 5]) == [1, 4, 5]

    def test_preserves_order(self):
        assert filter_integers([5, 1, 3, 2, 4]) == [5, 1, 3, 2, 4]

    def test_with_float_that_looks_like_int(self):
        assert filter_integers([1.0, 2.0, 3]) == [3]

    def test_with_complex_numbers(self):
        assert filter_integers([1, 2+3j, 4]) == [1, 4]

    def test_with_custom_objects(self):
        class CustomObj:
            pass
        assert filter_integers([1, CustomObj(), 2]) == [1, 2]

    @pytest.mark.parametrize("input_list,expected", [
        ([1, 2, 3], [1, 2, 3]),
        ([], []),
        ([1], [1]),
        (["a", "b"], []),
        ([1, "a", 2, "b", 3], [1, 2, 3]),
        ([-1, -2, -3], [-1, -2, -3]),
        ([0], [0]),
        ([1, 1.5, 2], [1, 2]),
    ])
    def test_parametrized_cases(self, input_list, expected):
        assert filter_integers(input_list) == expected

    def test_return_type_is_list(self):
        result = filter_integers([1, 2, 3])
        assert isinstance(result, list)

    def test_return_type_with_empty_list(self):
        result = filter_integers([])
        assert isinstance(result, list)

    def test_does_not_modify_original(self):
        original = [1, "a", 2]
        filter_integers(original)
        assert original == [1, "a", 2]

    def test_with_infinity(self):
        assert filter_integers([float('inf'), 1, 2]) == [1, 2]

    def test_with_nan(self):
        assert filter_integers([float('nan'), 1, 2]) == [1, 2]
