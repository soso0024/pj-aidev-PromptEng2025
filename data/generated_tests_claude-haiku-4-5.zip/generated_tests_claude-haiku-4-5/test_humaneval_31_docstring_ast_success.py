# Test cases for HumanEval/31
# Generated using Claude API



def is_prime(n):
    """Return true if a given number is prime, and false otherwise.
    >>> is_prime(6)
    False
    >>> is_prime(101)
    True
    >>> is_prime(11)
    True
    >>> is_prime(13441)
    True
    >>> is_prime(61)
    True
    >>> is_prime(4)
    False
    >>> is_prime(1)
    False
    """

    if n < 2:
        return False
    for k in range(2, n - 1):
        if n % k == 0:
            return False
    return True


# Generated test cases:
import pytest


def is_prime(n):
    if n < 2:
        return False
    for k in range(2, n - 1):
        if n % k == 0:
            return False
    return True


class TestIsPrime:
    
    @pytest.mark.parametrize("n,expected", [
        (1, False),
        (0, False),
        (-1, False),
        (-10, False),
        (2, True),
        (3, True),
        (4, False),
        (5, True),
        (6, False),
        (7, True),
        (8, False),
        (9, False),
        (10, False),
        (11, True),
        (13, True),
        (15, False),
        (17, True),
        (19, True),
        (20, False),
        (21, False),
        (23, True),
        (25, False),
        (29, True),
        (31, True),
        (37, True),
        (41, True),
        (43, True),
        (47, True),
        (49, False),
        (61, True),
        (101, True),
        (121, False),
        (13441, True),
    ])
    def test_is_prime_various_numbers(self, n, expected):
        assert is_prime(n) == expected
    
    def test_is_prime_small_primes(self):
        small_primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
        for prime in small_primes:
            assert is_prime(prime) is True
    
    def test_is_prime_small_composites(self):
        small_composites = [4, 6, 8, 9, 10, 12, 14, 15, 16, 18, 20, 21, 22, 24, 25, 26, 27, 28]
        for composite in small_composites:
            assert is_prime(composite) is False
    
    def test_is_prime_edge_cases(self):
        assert is_prime(1) is False
        assert is_prime(0) is False
        assert is_prime(-5) is False
        assert is_prime(-100) is False
    
    def test_is_prime_two(self):
        assert is_prime(2) is True
    
    def test_is_prime_large_prime(self):
        assert is_prime(97) is True
        assert is_prime(199) is True
    
    def test_is_prime_large_composite(self):
        assert is_prime(100) is False
        assert is_prime(200) is False
        assert is_prime(1000) is False
    
    def test_is_prime_perfect_squares(self):
        assert is_prime(4) is False
        assert is_prime(9) is False
        assert is_prime(16) is False
        assert is_prime(25) is False
        assert is_prime(36) is False
        assert is_prime(49) is False
        assert is_prime(64) is False
        assert is_prime(81) is False
        assert is_prime(100) is False
    
    def test_is_prime_twin_primes(self):
        assert is_prime(3) is True
        assert is_prime(5) is True
        assert is_prime(11) is True
        assert is_prime(13) is True
        assert is_prime(17) is True
        assert is_prime(19) is True
        assert is_prime(29) is True
        assert is_prime(31) is True
    
    def test_is_prime_return_type(self):
        result = is_prime(5)
        assert isinstance(result, bool)
        result = is_prime(4)
        assert isinstance(result, bool)
