# Test cases for HumanEval/53
# Generated using Claude API



def add(x: int, y: int):
    """Add two numbers x and y
    >>> add(2, 3)
    5
    >>> add(5, 7)
    12
    """

    return x + y


# Generated test cases:
import pytest


def add(x: int, y: int):
    return x + y


class TestAdd:
    def test_add_positive_integers(self):
        assert add(2, 3) == 5

    def test_add_negative_integers(self):
        assert add(-2, -3) == -5

    def test_add_mixed_signs(self):
        assert add(5, -3) == 2
        assert add(-5, 3) == -2

    def test_add_zero(self):
        assert add(0, 0) == 0
        assert add(5, 0) == 5
        assert add(0, 5) == 5

    def test_add_large_numbers(self):
        assert add(1000000, 2000000) == 3000000

    def test_add_commutative(self):
        assert add(3, 5) == add(5, 3)

    def test_add_associative(self):
        assert add(add(1, 2), 3) == add(1, add(2, 3))

    @pytest.mark.parametrize("x,y,expected", [
        (0, 0, 0),
        (1, 1, 2),
        (10, 20, 30),
        (-5, -10, -15),
        (100, -50, 50),
        (-100, 50, -50),
        (999, 1, 1000),
        (-999, -1, -1000),
    ])
    def test_add_parametrized(self, x, y, expected):
        assert add(x, y) == expected

    def test_add_identity_element(self):
        for i in range(-100, 101):
            assert add(i, 0) == i

    def test_add_inverse(self):
        assert add(5, -5) == 0
        assert add(-10, 10) == 0

    def test_add_type_annotations(self):
        result = add(1, 2)
        assert isinstance(result, int)

    def test_add_single_digit(self):
        assert add(1, 2) == 3
        assert add(9, 9) == 18

    def test_add_boundary_values(self):
        assert add(2147483647, 0) == 2147483647
        assert add(-2147483648, 0) == -2147483648

    def test_add_sequential_operations(self):
        result = add(1, 2)
        result = add(result, 3)
        result = add(result, 4)
        assert result == 10
