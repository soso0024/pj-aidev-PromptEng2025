# Test cases for HumanEval/69
# Generated using Claude API


def search(lst):
    '''
    You are given a non-empty list of positive integers. Return the greatest integer that is greater than 
    zero, and has a frequency greater than or equal to the value of the integer itself. 
    The frequency of an integer is the number of times it appears in the list.
    If no such a value exist, return -1.
    Examples:
        search([4, 1, 2, 2, 3, 1]) == 2
        search([1, 2, 2, 3, 3, 3, 4, 4, 4]) == 3
        search([5, 5, 4, 4, 4]) == -1
    '''

    frq = [0] * (max(lst) + 1)
    for i in lst:
        frq[i] += 1;

    ans = -1
    for i in range(1, len(frq)):
        if frq[i] >= i:
            ans = i
    
    return ans


# Generated test cases:
import pytest


def search(lst):
    '''
    You are given a non-empty list of positive integers. Return the greatest integer that is greater than 
    zero, and has a frequency greater than or equal to the value of the integer itself. 
    The frequency of an integer is the number of times it appears in the list.
    If no such a value exist, return -1.
    Examples:
        search([4, 1, 2, 2, 3, 1]) == 2
        search([1, 2, 2, 3, 3, 3, 4, 4, 4]) == 3
        search([5, 5, 4, 4, 4]) == -1
    '''

    frq = [0] * (max(lst) + 1)
    for i in lst:
        frq[i] += 1

    ans = -1
    for i in range(1, len(frq)):
        if frq[i] >= i:
            ans = i
    
    return ans


class TestSearch:
    
    def test_example_1(self):
        assert search([4, 1, 2, 2, 3, 1]) == 2
    
    def test_example_2(self):
        assert search([1, 2, 2, 3, 3, 3, 4, 4, 4]) == 3
    
    def test_example_3(self):
        assert search([5, 5, 4, 4, 4]) == -1
    
    def test_single_element_one(self):
        assert search([1]) == 1
    
    def test_single_element_greater_than_one(self):
        assert search([5]) == -1
    
    def test_all_ones(self):
        assert search([1, 1, 1, 1]) == 1
    
    def test_all_twos(self):
        assert search([2, 2]) == 2
    
    def test_all_threes(self):
        assert search([3, 3, 3]) == 3
    
    def test_no_valid_value(self):
        assert search([10, 10]) == -1
    
    def test_multiple_valid_values_return_greatest(self):
        assert search([1, 2, 2, 3, 3, 3]) == 3
    
    def test_frequency_equals_value(self):
        assert search([2, 2, 3, 3, 3]) == 3
    
    def test_frequency_greater_than_value(self):
        assert search([1, 1, 1, 1, 1]) == 1
    
    def test_mixed_frequencies(self):
        assert search([1, 2, 2, 3, 3, 3, 4, 4, 4, 4]) == 4
    
    def test_large_numbers_low_frequency(self):
        assert search([100, 100]) == -1
    
    def test_large_numbers_high_frequency(self):
        result = search([5] * 10)
        assert result == 5
    
    def test_zero_not_considered(self):
        assert search([1, 1, 2, 2]) == 2
    
    def test_ascending_sequence(self):
        assert search([1, 2, 3, 4, 5]) == 1
    
    def test_descending_sequence(self):
        assert search([5, 4, 3, 2, 1]) == 1
    
    def test_repeated_pattern(self):
        assert search([1, 1, 2, 2, 3, 3, 3]) == 3
    
    def test_two_valid_candidates(self):
        assert search([2, 2, 3, 3, 3]) == 3
    
    def test_frequency_just_below_value(self):
        assert search([5, 5, 5, 5]) == -1
    
    def test_many_ones_and_twos(self):
        assert search([1, 1, 1, 2, 2]) == 2
    
    def test_large_list_with_valid_answer(self):
        assert search([1] * 100 + [2] * 50) == 2
    
    def test_single_large_number_repeated(self):
        assert search([7, 7, 7, 7, 7, 7, 7]) == 7
    
    def test_mixed_with_high_frequency_small_number(self):
        assert search([1, 1, 1, 1, 1, 10]) == 1
    
    def test_boundary_case_frequency_equals_max_value(self):
        assert search([3, 3, 3, 5, 5]) == 3
    
    def test_all_different_numbers(self):
        assert search([1, 2, 3, 4, 5, 6]) == 1
    
    def test_two_elements_both_valid(self):
        assert search([2, 2, 3, 3, 3]) == 3
    
    def test_frequency_much_greater_than_value(self):
        assert search([1] * 1000) == 1
    
    def test_complex_mixed_case(self):
        assert search([1, 1, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 4]) == 4