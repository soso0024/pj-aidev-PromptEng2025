# Test cases for HumanEval/128
# Generated using Claude API


def prod_signs(arr):
    """
    You are given an array arr of integers and you need to return
    sum of magnitudes of integers multiplied by product of all signs
    of each number in the array, represented by 1, -1 or 0.
    Note: return None for empty arr.

    Example:
    >>> prod_signs([1, 2, 2, -4]) == -9
    >>> prod_signs([0, 1]) == 0
    >>> prod_signs([]) == None
    """

    if not arr: return None
    prod = 0 if 0 in arr else (-1) ** len(list(filter(lambda x: x < 0, arr)))
    return prod * sum([abs(i) for i in arr])


# Generated test cases:
import pytest


def prod_signs(arr):
    if not arr: return None
    prod = 0 if 0 in arr else (-1) ** len(list(filter(lambda x: x < 0, arr)))
    return prod * sum([abs(i) for i in arr])


class TestProdSigns:
    
    def test_empty_array(self):
        assert prod_signs([]) is None
    
    def test_single_positive(self):
        assert prod_signs([5]) == 5
    
    def test_single_negative(self):
        assert prod_signs([-5]) == -5
    
    def test_single_zero(self):
        assert prod_signs([0]) == 0
    
    def test_all_positive(self):
        assert prod_signs([1, 2, 3]) == 6
    
    def test_all_negative(self):
        assert prod_signs([-1, -2, -3]) == -6
    
    def test_even_negatives(self):
        assert prod_signs([1, 2, 2, -4]) == -9
    
    def test_odd_negatives(self):
        assert prod_signs([-1, 2, 3]) == -6
    
    def test_with_zero_in_middle(self):
        assert prod_signs([0, 1]) == 0
    
    def test_with_zero_at_start(self):
        assert prod_signs([0, -5, 10]) == 0
    
    def test_with_zero_at_end(self):
        assert prod_signs([5, 10, 0]) == 0
    
    def test_multiple_zeros(self):
        assert prod_signs([0, 0, 0]) == 0
    
    def test_mixed_with_zero(self):
        assert prod_signs([-1, -2, 0, 3]) == 0
    
    def test_large_positive_numbers(self):
        assert prod_signs([100, 200, 300]) == 600
    
    def test_large_negative_numbers(self):
        assert prod_signs([-100, -200]) == 300
    
    def test_two_negatives(self):
        assert prod_signs([-1, -1]) == 2
    
    def test_three_negatives(self):
        assert prod_signs([-1, -1, -1]) == -3
    
    def test_four_negatives(self):
        assert prod_signs([-1, -1, -1, -1]) == 4
    
    def test_mixed_magnitudes(self):
        assert prod_signs([1, -2, 3, -4, 5]) == 15
    
    def test_single_one(self):
        assert prod_signs([1]) == 1
    
    def test_single_negative_one(self):
        assert prod_signs([-1]) == -1
    
    @pytest.mark.parametrize("arr,expected", [
        ([1, 2, 2, -4], -9),
        ([0, 1], 0),
        ([], None),
        ([5], 5),
        ([-5], -5),
        ([1, 1, 1], 3),
        ([-1, -1, 1], 3),
        ([10, -10], -20),
    ])
    def test_parametrized_cases(self, arr, expected):
        assert prod_signs(arr) == expected