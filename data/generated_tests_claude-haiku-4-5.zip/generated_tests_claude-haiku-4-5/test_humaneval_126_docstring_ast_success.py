# Test cases for HumanEval/126
# Generated using Claude API


def is_sorted(lst):
    '''
    Given a list of numbers, return whether or not they are sorted
    in ascending order. If list has more than 1 duplicate of the same
    number, return False. Assume no negative numbers and only integers.

    Examples
    is_sorted([5]) ➞ True
    is_sorted([1, 2, 3, 4, 5]) ➞ True
    is_sorted([1, 3, 2, 4, 5]) ➞ False
    is_sorted([1, 2, 3, 4, 5, 6]) ➞ True
    is_sorted([1, 2, 3, 4, 5, 6, 7]) ➞ True
    is_sorted([1, 3, 2, 4, 5, 6, 7]) ➞ False
    is_sorted([1, 2, 2, 3, 3, 4]) ➞ True
    is_sorted([1, 2, 2, 2, 3, 4]) ➞ False
    '''

    count_digit = dict([(i, 0) for i in lst])
    for i in lst:
        count_digit[i]+=1 
    if any(count_digit[i] > 2 for i in lst):
        return False
    if all(lst[i-1] <= lst[i] for i in range(1, len(lst))):
        return True
    else:
        return False
    
    


# Generated test cases:
import pytest


def is_sorted(lst):
    count_digit = dict([(i, 0) for i in lst])
    for i in lst:
        count_digit[i]+=1 
    if any(count_digit[i] > 2 for i in lst):
        return False
    if all(lst[i-1] <= lst[i] for i in range(1, len(lst))):
        return True
    else:
        return False


class TestIsSorted:
    
    def test_single_element(self):
        assert is_sorted([5]) == True
    
    def test_sorted_ascending(self):
        assert is_sorted([1, 2, 3, 4, 5]) == True
    
    def test_unsorted_middle(self):
        assert is_sorted([1, 3, 2, 4, 5]) == False
    
    def test_sorted_longer(self):
        assert is_sorted([1, 2, 3, 4, 5, 6]) == True
    
    def test_sorted_even_longer(self):
        assert is_sorted([1, 2, 3, 4, 5, 6, 7]) == True
    
    def test_unsorted_middle_longer(self):
        assert is_sorted([1, 3, 2, 4, 5, 6, 7]) == False
    
    def test_duplicates_allowed_once(self):
        assert is_sorted([1, 2, 2, 3, 3, 4]) == True
    
    def test_duplicates_more_than_twice(self):
        assert is_sorted([1, 2, 2, 2, 3, 4]) == False
    
    def test_empty_list(self):
        assert is_sorted([]) == True
    
    def test_two_elements_sorted(self):
        assert is_sorted([1, 2]) == True
    
    def test_two_elements_unsorted(self):
        assert is_sorted([2, 1]) == False
    
    def test_two_identical_elements(self):
        assert is_sorted([5, 5]) == True
    
    def test_three_identical_elements(self):
        assert is_sorted([5, 5, 5]) == False
    
    def test_all_same_number_twice(self):
        assert is_sorted([7, 7]) == True
    
    def test_all_same_number_three_times(self):
        assert is_sorted([7, 7, 7]) == False
    
    def test_duplicates_at_start(self):
        assert is_sorted([1, 1, 2, 3, 4]) == True
    
    def test_duplicates_at_end(self):
        assert is_sorted([1, 2, 3, 4, 4]) == True
    
    def test_multiple_pairs_of_duplicates(self):
        assert is_sorted([1, 1, 2, 2, 3, 3]) == True
    
    def test_triple_in_middle(self):
        assert is_sorted([1, 2, 2, 2, 3]) == False
    
    def test_zero_in_list(self):
        assert is_sorted([0, 1, 2, 3]) == True
    
    def test_large_numbers(self):
        assert is_sorted([100, 200, 300, 400]) == True
    
    def test_large_numbers_unsorted(self):
        assert is_sorted([100, 300, 200, 400]) == False
    
    def test_descending_order(self):
        assert is_sorted([5, 4, 3, 2, 1]) == False
    
    def test_mostly_sorted_with_one_violation(self):
        assert is_sorted([1, 2, 3, 5, 4, 6]) == False
    
    def test_duplicate_at_boundary(self):
        assert is_sorted([1, 2, 3, 3, 4, 5]) == True
    
    def test_four_duplicates(self):
        assert is_sorted([1, 2, 2, 2, 2, 3]) == False
    
    def test_sorted_with_zero_and_duplicates(self):
        assert is_sorted([0, 0, 1, 1, 2, 2]) == True
    
    def test_single_duplicate_violation(self):
        assert is_sorted([1, 1, 1, 2, 3]) == False
    
    @pytest.mark.parametrize("lst,expected", [
        ([1], True),
        ([1, 2], True),
        ([2, 1], False),
        ([1, 1], True),
        ([1, 1, 1], False),
        ([1, 2, 3], True),
        ([3, 2, 1], False),
        ([1, 2, 2, 3], True),
        ([1, 2, 2, 2, 3], False),
        ([0, 1, 2], True),
        ([1, 1, 2, 2, 3, 3], True),
        ([1, 1, 1, 2, 2, 3], False),
    ])
    def test_parametrized_cases(self, lst, expected):
        assert is_sorted(lst) == expected
