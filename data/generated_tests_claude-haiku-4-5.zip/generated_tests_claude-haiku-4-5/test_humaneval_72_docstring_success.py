# Test cases for HumanEval/72
# Generated using Claude API


def will_it_fly(q,w):
    '''
    Write a function that returns True if the object q will fly, and False otherwise.
    The object q will fly if it's balanced (it is a palindromic list) and the sum of its elements is less than or equal the maximum possible weight w.

    Example:
    will_it_fly([1, 2], 5) ➞ False 
    # 1+2 is less than the maximum possible weight, but it's unbalanced.

    will_it_fly([3, 2, 3], 1) ➞ False
    # it's balanced, but 3+2+3 is more than the maximum possible weight.

    will_it_fly([3, 2, 3], 9) ➞ True
    # 3+2+3 is less than the maximum possible weight, and it's balanced.

    will_it_fly([3], 5) ➞ True
    # 3 is less than the maximum possible weight, and it's balanced.
    '''

    if sum(q) > w:
        return False

    i, j = 0, len(q)-1
    while i<j:
        if q[i] != q[j]:
            return False
        i+=1
        j-=1
    return True


# Generated test cases:
import pytest


def will_it_fly(q, w):
    if sum(q) > w:
        return False

    i, j = 0, len(q)-1
    while i<j:
        if q[i] != q[j]:
            return False
        i+=1
        j-=1
    return True


@pytest.mark.parametrize("q,w,expected", [
    ([1, 2], 5, False),
    ([3, 2, 3], 1, False),
    ([3, 2, 3], 9, True),
    ([3], 5, True),
    ([], 10, True),
    ([1], 1, True),
    ([1], 0, False),
    ([1, 1], 2, True),
    ([1, 1], 1, False),
    ([1, 2, 1], 4, True),
    ([1, 2, 1], 3, False),
    ([1, 2, 2, 1], 6, True),
    ([1, 2, 2, 1], 5, False),
    ([5, 5], 10, True),
    ([5, 5], 9, False),
    ([1, 2, 3, 2, 1], 9, True),
    ([1, 2, 3, 2, 1], 8, False),
    ([2, 1, 1, 2], 6, True),
    ([2, 1, 1, 2], 5, False),
    ([0, 0], 0, True),
    ([0], 0, True),
    ([1, 0, 1], 2, True),
    ([1, 0, 1], 1, False),
    ([10, 10], 20, True),
    ([10, 10], 19, False),
    ([1, 1, 1, 1, 1], 5, True),
    ([1, 1, 1, 1, 1], 4, False),
    ([2, 3, 2], 7, True),
    ([2, 3, 2], 6, False),
    ([100], 100, True),
    ([100], 99, False),
    ([1, 2, 3, 4, 3, 2, 1], 16, True),
    ([1, 2, 3, 4, 3, 2, 1], 15, False),
    ([5, 4, 5], 14, True),
    ([5, 4, 5], 13, False),
    ([1, 1, 1], 3, True),
    ([1, 1, 1], 2, False),
])
def test_will_it_fly(q, w, expected):
    assert will_it_fly(q, w) == expected


def test_will_it_fly_unbalanced_list():
    assert will_it_fly([1, 2, 3], 10) == False


def test_will_it_fly_balanced_but_too_heavy():
    assert will_it_fly([5, 5], 9) == False


def test_will_it_fly_balanced_and_light():
    assert will_it_fly([2, 2], 10) == True


def test_will_it_fly_single_element():
    assert will_it_fly([7], 7) == True
    assert will_it_fly([7], 6) == False


def test_will_it_fly_empty_list():
    assert will_it_fly([], 0) == True
    assert will_it_fly([], 100) == True


def test_will_it_fly_large_palindrome():
    large_list = [1] * 100
    assert will_it_fly(large_list, 100) == True
    assert will_it_fly(large_list, 99) == False


def test_will_it_fly_negative_weight():
    assert will_it_fly([1, 1], -1) == False


def test_will_it_fly_zero_weight():
    assert will_it_fly([0], 0) == True
    assert will_it_fly([1], 0) == False
