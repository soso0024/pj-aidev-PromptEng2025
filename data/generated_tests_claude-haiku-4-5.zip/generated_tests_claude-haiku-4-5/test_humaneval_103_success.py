# Test cases for HumanEval/103
# Generated using Claude API


def rounded_avg(n, m):
    """You are given two positive integers n and m, and your task is to compute the
    average of the integers from n through m (including n and m). 
    Round the answer to the nearest integer and convert that to binary.
    If n is greater than m, return -1.
    Example:
    rounded_avg(1, 5) => "0b11"
    rounded_avg(7, 5) => -1
    rounded_avg(10, 20) => "0b1111"
    rounded_avg(20, 33) => "0b11010"
    """

    if m < n:
        return -1
    summation = 0
    for i in range(n, m+1):
        summation += i
    return bin(round(summation/(m - n + 1)))


# Generated test cases:
import pytest


def rounded_avg(n, m):
    if m < n:
        return -1
    summation = 0
    for i in range(n, m+1):
        summation += i
    return bin(round(summation/(m - n + 1)))


class TestRoundedAvg:
    
    def test_single_number(self):
        result = rounded_avg(1, 1)
        assert result == bin(1)
    
    def test_two_consecutive_numbers(self):
        result = rounded_avg(1, 2)
        assert result == bin(2)
    
    def test_range_with_even_average(self):
        result = rounded_avg(2, 4)
        assert result == bin(3)
    
    def test_range_with_rounding_down(self):
        result = rounded_avg(1, 3)
        assert result == bin(2)
    
    def test_range_with_rounding_up(self):
        result = rounded_avg(1, 4)
        assert result == bin(2)
    
    def test_m_less_than_n(self):
        result = rounded_avg(5, 3)
        assert result == -1
    
    def test_m_equals_n_minus_one(self):
        result = rounded_avg(10, 9)
        assert result == -1
    
    def test_large_range(self):
        result = rounded_avg(1, 100)
        expected = bin(round(sum(range(1, 101)) / 100))
        assert result == expected
    
    def test_negative_numbers(self):
        result = rounded_avg(-5, -1)
        expected = bin(round(sum(range(-5, 0)) / 5))
        assert result == expected
    
    def test_negative_to_positive_range(self):
        result = rounded_avg(-2, 2)
        expected = bin(round(sum(range(-2, 3)) / 5))
        assert result == expected
    
    def test_zero_in_range(self):
        result = rounded_avg(0, 0)
        assert result == bin(0)
    
    def test_zero_to_positive(self):
        result = rounded_avg(0, 5)
        expected = bin(round(sum(range(0, 6)) / 6))
        assert result == expected
    
    def test_large_numbers(self):
        result = rounded_avg(1000, 1010)
        expected = bin(round(sum(range(1000, 1011)) / 11))
        assert result == expected
    
    def test_returns_binary_string(self):
        result = rounded_avg(1, 5)
        assert isinstance(result, str)
        assert result.startswith('0b')
    
    @pytest.mark.parametrize("n,m,expected_decimal", [
        (1, 1, 1),
        (1, 2, 2),
        (2, 4, 3),
        (1, 5, 3),
        (0, 10, 5),
    ])
    def test_parametrized_cases(self, n, m, expected_decimal):
        result = rounded_avg(n, m)
        assert result == bin(expected_decimal)
    
    @pytest.mark.parametrize("n,m", [
        (10, 5),
        (100, 50),
        (0, -1),
        (5, 4),
    ])
    def test_parametrized_invalid_ranges(self, n, m):
        result = rounded_avg(n, m)
        assert result == -1