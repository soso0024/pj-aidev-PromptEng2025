# Test cases for HumanEval/81
# Generated using Claude API


def numerical_letter_grade(grades):
    """It is the last week of the semester and the teacher has to give the grades
    to students. The teacher has been making her own algorithm for grading.
    The only problem is, she has lost the code she used for grading.
    She has given you a list of GPAs for some students and you have to write 
    a function that can output a list of letter grades using the following table:
             GPA       |    Letter grade
              4.0                A+
            > 3.7                A 
            > 3.3                A- 
            > 3.0                B+
            > 2.7                B 
            > 2.3                B-
            > 2.0                C+
            > 1.7                C
            > 1.3                C-
            > 1.0                D+ 
            > 0.7                D 
            > 0.0                D-
              0.0                E
    

    Example:
    grade_equation([4.0, 3, 1.7, 2, 3.5]) ==> ['A+', 'B', 'C-', 'C', 'A-']
    """


   
    letter_grade = []
    for gpa in grades:
        if gpa == 4.0:
            letter_grade.append("A+")
        elif gpa > 3.7:
            letter_grade.append("A")
        elif gpa > 3.3:
            letter_grade.append("A-")
        elif gpa > 3.0:
            letter_grade.append("B+")
        elif gpa > 2.7:
            letter_grade.append("B")
        elif gpa > 2.3:
            letter_grade.append("B-")
        elif gpa > 2.0:
            letter_grade.append("C+")
        elif gpa > 1.7:
            letter_grade.append("C")
        elif gpa > 1.3:
            letter_grade.append("C-")
        elif gpa > 1.0:
            letter_grade.append("D+")
        elif gpa > 0.7:
            letter_grade.append("D")
        elif gpa > 0.0:
            letter_grade.append("D-")
        else:
            letter_grade.append("E")
    return letter_grade


# Generated test cases:
import pytest


class TestNumericalLetterGrade:
    
    def test_example_case(self):
        from solution import numerical_letter_grade
        result = numerical_letter_grade([4.0, 3, 1.7, 2, 3.5])
        assert result == ['A+', 'B', 'C', 'C+', 'A-']
    
    def test_perfect_score(self):
        result = numerical_letter_grade([4.0])
        assert result == ['A+']
    
    def test_all_a_grades(self):
        result = numerical_letter_grade([4.0, 3.9, 3.8, 3.7, 3.6, 3.5, 3.4, 3.3])
        assert result == ['A+', 'A', 'A', 'A', 'A-', 'A-', 'A-', 'B+']
    
    def test_all_b_grades(self):
        result = numerical_letter_grade([3.2, 3.1, 3.0, 2.9, 2.8, 2.7, 2.6, 2.5, 2.4, 2.3])
        assert result == ['B+', 'B+', 'B', 'B', 'B', 'B-', 'B-', 'B-', 'B-', 'C+']
    
    def test_all_c_grades(self):
        result = numerical_letter_grade([2.2, 2.1, 2.0, 1.9, 1.8, 1.7, 1.6, 1.5, 1.4, 1.3])
        assert result == ['C+', 'C+', 'C', 'C', 'C', 'C-', 'C-', 'C-', 'C-', 'D+']
    
    def test_all_d_grades(self):
        result = numerical_letter_grade([1.2, 1.1, 1.0, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.1])
        assert result == ['D+', 'D+', 'D', 'D', 'D', 'D-', 'D-', 'D-', 'D-', 'D-']
    
    def test_zero_gpa(self):
        result = numerical_letter_grade([0.0])
        assert result == ['E']
    
    def test_boundary_values(self):
        result = numerical_letter_grade([4.0, 3.7, 3.3, 3.0, 2.7, 2.3, 2.0, 1.7, 1.3, 1.0, 0.7, 0.0])
        assert result == ['A+', 'A-', 'B+', 'B', 'B-', 'C+', 'C', 'C-', 'D+', 'D', 'D-', 'E']
    
    def test_just_above_boundaries(self):
        result = numerical_letter_grade([3.71, 3.31, 3.01, 2.71, 2.31, 2.01, 1.71, 1.31, 1.01, 0.71, 0.01])
        assert result == ['A', 'A-', 'B+', 'B', 'B-', 'C+', 'C', 'C-', 'D+', 'D', 'D-']
    
    def test_just_below_boundaries(self):
        result = numerical_letter_grade([3.69, 3.29, 2.99, 2.69, 2.29, 1.99, 1.69, 1.29, 0.99, 0.69])
        assert result == ['A', 'A-', 'B+', 'B', 'B-', 'C+', 'C', 'C-', 'D+', 'D']
    
    def test_empty_list(self):
        result = numerical_letter_grade([])
        assert result == []
    
    def test_single_grade_a_plus(self):
        result = numerical_letter_grade([4.0])
        assert result == ['A+']
    
    def test_single_grade_a(self):
        result = numerical_letter_grade([3.8])
        assert result == ['A']
    
    def test_single_grade_e(self):
        result = numerical_letter_grade([0.0])
        assert result == ['E']
    
    def test_multiple_same_grades(self):
        result = numerical_letter_grade([3.5, 3.5, 3.5])
        assert result == ['A-', 'A-', 'A-']
    
    def test_descending_order(self):
        result = numerical_letter_grade([4.0, 3.5, 3.0, 2.5, 2.0, 1.5, 1.0, 0.5, 0.0])
        assert result == ['A+', 'A-', 'B', 'B-', 'C', 'C-', 'D', 'D-', 'E']
    
    def test_ascending_order(self):
        result = numerical_letter_grade([0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0])
        assert result == ['E', 'D-', 'D', 'C-', 'C', 'B-', 'B', 'A-', 'A+']
    
    def test_very_small_positive_value(self):
        result = numerical_letter_grade([0.001])
        assert result == ['D-']
    
    def test_large_list(self):
        grades = [4.0] * 100
        result = numerical_letter_grade(grades)
        assert result == ['A+'] * 100
    
    def test_mixed_grades_large_list(self):
        grades = [4.0, 3.5, 2.5, 1.5, 0.5] * 20
        result = numerical_letter_grade(grades)
        expected = ['A+', 'A-', 'B-', 'C-', 'D-'] * 20
        assert result == expected
    
    @pytest.mark.parametrize("gpa,expected", [
        (4.0, 'A+'),
        (3.9, 'A'),
        (3.8, 'A'),
        (3.7, 'A-'),
        (3.6, 'A-'),
        (3.5, 'A-'),
        (3.4, 'A-'),
        (3.3, 'B+'),
        (3.2, 'B+'),
        (3.1, 'B+'),
        (3.0, 'B'),
        (2.9, 'B'),
        (2.8, 'B'),
        (2.7, 'B-'),
        (2.6, 'B-'),
        (2.5, 'B-'),
        (2.4, 'B-'),
        (2.3, 'C+'),
        (2.2, 'C+'),
        (2.1, 'C+'),
        (2.0, 'C'),
        (1.9, 'C'),
        (1.8, 'C'),
        (1.7, 'C-'),
        (1.6, 'C-'),
        (1.5, 'C-'),
        (1.4, 'C-'),
        (1.3, 'D+'),
        (1.2, 'D+'),
        (1.1, 'D+'),
        (1.0, 'D'),
        (0.9, 'D'),
        (0.8, 'D'),
        (0.7, 'D-'),
        (0.6, 'D-'),
        (0.5, 'D-'),
        (0.4, 'D-'),
        (0.1, 'D-'),
        (0.0, 'E'),
    ])
    def test_parametrized_grades(self, gpa, expected):
        result = numerical_letter_grade([gpa])
        assert result == [expected]