# Test cases for HumanEval/153
# Generated using Claude API


def Strongest_Extension(class_name, extensions):
    """You will be given the name of a class (a string) and a list of extensions.
    The extensions are to be used to load additional classes to the class. The
    strength of the extension is as follows: Let CAP be the number of the uppercase
    letters in the extension's name, and let SM be the number of lowercase letters 
    in the extension's name, the strength is given by the fraction CAP - SM. 
    You should find the strongest extension and return a string in this 
    format: ClassName.StrongestExtensionName.
    If there are two or more extensions with the same strength, you should
    choose the one that comes first in the list.
    For example, if you are given "Slices" as the class and a list of the
    extensions: ['SErviNGSliCes', 'Cheese', 'StuFfed'] then you should
    return 'Slices.SErviNGSliCes' since 'SErviNGSliCes' is the strongest extension 
    (its strength is -1).
    Example:
    for Strongest_Extension('my_class', ['AA', 'Be', 'CC']) == 'my_class.AA'
    """

    strong = extensions[0]
    my_val = len([x for x in extensions[0] if x.isalpha() and x.isupper()]) - len([x for x in extensions[0] if x.isalpha() and x.islower()])
    for s in extensions:
        val = len([x for x in s if x.isalpha() and x.isupper()]) - len([x for x in s if x.isalpha() and x.islower()])
        if val > my_val:
            strong = s
            my_val = val

    ans = class_name + "." + strong
    return ans



# Generated test cases:
import pytest


def Strongest_Extension(class_name, extensions):
    """You will be given the name of a class (a string) and a list of extensions.
    The extensions are to be used to load additional classes to the class. The
    strength of the extension is as follows: Let CAP be the number of the uppercase
    letters in the extension's name, and let SM be the number of lowercase letters 
    in the extension's name, the strength is given by the fraction CAP - SM. 
    You should find the strongest extension and return a string in this 
    format: ClassName.StrongestExtensionName.
    If there are two or more extensions with the same strength, you should
    choose the one that comes first in the list.
    For example, if you are given "Slices" as the class and a list of the
    extensions: ['SErviNGSliCes', 'Cheese', 'StuFfed'] then you should
    return 'Slices.SErviNGSliCes' since 'SErviNGSliCes' is the strongest extension 
    (its strength is -1).
    Example:
    for Strongest_Extension('my_class', ['AA', 'Be', 'CC']) == 'my_class.AA'
    """

    strong = extensions[0]
    my_val = len([x for x in extensions[0] if x.isalpha() and x.isupper()]) - len([x for x in extensions[0] if x.isalpha() and x.islower()])
    for s in extensions:
        val = len([x for x in s if x.isalpha() and x.isupper()]) - len([x for x in s if x.isalpha() and x.islower()])
        if val > my_val:
            strong = s
            my_val = val

    ans = class_name + "." + strong
    return ans


class TestStrongestExtension:
    
    def test_basic_example(self):
        result = Strongest_Extension('my_class', ['AA', 'Be', 'CC'])
        assert result == 'my_class.AA'
    
    def test_docstring_example(self):
        result = Strongest_Extension('Slices', ['SErviNGSliCes', 'Cheese', 'StuFfed'])
        assert result == 'Slices.SErviNGSliCes'
    
    def test_single_extension(self):
        result = Strongest_Extension('MyClass', ['Extension'])
        assert result == 'MyClass.Extension'
    
    def test_all_uppercase(self):
        result = Strongest_Extension('Test', ['ABC', 'DEF', 'GHI'])
        assert result == 'Test.ABC'
    
    def test_all_lowercase(self):
        result = Strongest_Extension('Test', ['abc', 'def', 'ghi'])
        assert result == 'Test.abc'
    
    def test_mixed_case_single(self):
        result = Strongest_Extension('Class', ['AaBbCc'])
        assert result == 'Class.AaBbCc'
    
    def test_first_strongest(self):
        result = Strongest_Extension('MyClass', ['AAA', 'aaa', 'Aa'])
        assert result == 'MyClass.AAA'
    
    def test_last_strongest(self):
        result = Strongest_Extension('MyClass', ['aaa', 'Aa', 'AAA'])
        assert result == 'MyClass.AAA'
    
    def test_middle_strongest(self):
        result = Strongest_Extension('MyClass', ['aaa', 'AAA', 'Aa'])
        assert result == 'MyClass.AAA'
    
    def test_tie_returns_first(self):
        result = Strongest_Extension('MyClass', ['AA', 'BB', 'CC'])
        assert result == 'MyClass.AA'
    
    def test_tie_returns_first_complex(self):
        result = Strongest_Extension('MyClass', ['AaBb', 'CcDd', 'EeFf'])
        assert result == 'MyClass.AaBb'
    
    def test_negative_strength(self):
        result = Strongest_Extension('MyClass', ['aabbcc', 'AABBCC', 'AaBbCc'])
        assert result == 'MyClass.AABBCC'
    
    def test_with_numbers_and_special_chars(self):
        result = Strongest_Extension('MyClass', ['A1b2C3', 'a1B2c3', 'ABC123'])
        assert result == 'MyClass.ABC123'
    
    def test_empty_string_extension(self):
        result = Strongest_Extension('MyClass', ['', 'A', 'a'])
        assert result == 'MyClass.A'
    
    def test_strength_calculation_accuracy(self):
        result = Strongest_Extension('Test', ['Aa', 'AA', 'aa'])
        assert result == 'Test.AA'
    
    def test_class_name_with_underscore(self):
        result = Strongest_Extension('my_class_name', ['ABC', 'def'])
        assert result == 'my_class_name.ABC'
    
    def test_class_name_with_numbers(self):
        result = Strongest_Extension('Class123', ['ABC', 'def'])
        assert result == 'Class123.ABC'
    
    def test_extension_with_spaces(self):
        result = Strongest_Extension('MyClass', ['A B', 'ab', 'AB'])
        assert result == 'MyClass.A B'
    
    def test_long_extension_names(self):
        result = Strongest_Extension('MyClass', ['aaaaaBBBBB', 'AAAAABBBBB', 'AaAaAaBbBbBb'])
        assert result == 'MyClass.AAAAABBBBB'
    
    def test_two_extensions_different_strength(self):
        result = Strongest_Extension('MyClass', ['Abc', 'ABC'])
        assert result == 'MyClass.ABC'
    
    def test_strength_zero(self):
        result = Strongest_Extension('MyClass', ['AaBb', 'CcDd', 'a'])
        assert result == 'MyClass.AaBb'
    
    def test_multiple_same_strength_first_wins(self):
        result = Strongest_Extension('MyClass', ['AB', 'CD', 'EF', 'ab'])
        assert result == 'MyClass.AB'
    
    def test_decreasing_strength(self):
        result = Strongest_Extension('MyClass', ['AAA', 'AAa', 'Aaa', 'aaa'])
        assert result == 'MyClass.AAA'
    
    def test_increasing_strength(self):
        result = Strongest_Extension('MyClass', ['aaa', 'Aaa', 'AAa', 'AAA'])
        assert result == 'MyClass.AAA'
    
    def test_single_character_extensions(self):
        result = Strongest_Extension('MyClass', ['a', 'B', 'c', 'D'])
        assert result == 'MyClass.B'
    
    def test_very_long_class_name(self):
        result = Strongest_Extension('VeryLongClassNameWithManyCharacters', ['ABC', 'def'])
        assert result == 'VeryLongClassNameWithManyCharacters.ABC'
    
    def test_special_characters_ignored(self):
        result = Strongest_Extension('MyClass', ['A!@#b', 'a$%^B', 'AB'])
        assert result == 'MyClass.AB'
    
    def test_unicode_letters(self):
        result = Strongest_Extension('MyClass', ['ABC', 'def', 'Ghi'])
        assert result == 'MyClass.ABC'

    @pytest.mark.parametrize("class_name,extensions,expected", [
        ('Test', ['AA', 'bb'], 'Test.AA'),
        ('Class', ['a', 'B'], 'Class.B'),
        ('MyClass', ['ABC', 'abc', 'Abc'], 'MyClass.ABC'),
        ('X', ['X', 'x'], 'X.X'),
        ('Simple', ['UPPER', 'lower', 'MiXeD'], 'Simple.UPPER'),
    ])
    def test_parametrized_cases(self, class_name, extensions, expected):
        assert Strongest_Extension(class_name, extensions) == expected