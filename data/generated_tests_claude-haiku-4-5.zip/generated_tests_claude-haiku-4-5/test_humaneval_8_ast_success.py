# Test cases for HumanEval/8
# Generated using Claude API

from typing import List, Tuple


def sum_product(numbers: List[int]) -> Tuple[int, int]:
    """ For a given list of integers, return a tuple consisting of a sum and a product of all the integers in a list.
    Empty sum should be equal to 0 and empty product should be equal to 1.
    >>> sum_product([])
    (0, 1)
    >>> sum_product([1, 2, 3, 4])
    (10, 24)
    """

    sum_value = 0
    prod_value = 1

    for n in numbers:
        sum_value += n
        prod_value *= n
    return sum_value, prod_value


# Generated test cases:
import pytest
from typing import List, Tuple


def sum_product(numbers: List[int]) -> Tuple[int, int]:
    sum_value = 0
    prod_value = 1

    for n in numbers:
        sum_value += n
        prod_value *= n
    return sum_value, prod_value


class TestSumProduct:
    def test_empty_list(self):
        result = sum_product([])
        assert result == (0, 1)

    def test_single_element(self):
        result = sum_product([5])
        assert result == (5, 5)

    def test_two_elements(self):
        result = sum_product([2, 3])
        assert result == (5, 6)

    def test_multiple_positive_numbers(self):
        result = sum_product([1, 2, 3, 4])
        assert result == (10, 24)

    def test_with_zero(self):
        result = sum_product([1, 0, 3])
        assert result == (4, 0)

    def test_with_negative_numbers(self):
        result = sum_product([-1, -2, -3])
        assert result == (-6, -6)

    def test_mixed_positive_negative(self):
        result = sum_product([1, -2, 3])
        assert result == (2, -6)

    def test_large_numbers(self):
        result = sum_product([100, 200, 300])
        assert result == (600, 6000000)

    def test_single_zero(self):
        result = sum_product([0])
        assert result == (0, 0)

    def test_multiple_zeros(self):
        result = sum_product([0, 0, 0])
        assert result == (0, 0)

    def test_negative_and_zero(self):
        result = sum_product([-5, 0, 3])
        assert result == (-2, 0)

    def test_all_ones(self):
        result = sum_product([1, 1, 1, 1])
        assert result == (4, 1)

    def test_all_negative_ones(self):
        result = sum_product([-1, -1, -1])
        assert result == (-3, -1)

    def test_large_list(self):
        numbers = list(range(1, 11))
        result = sum_product(numbers)
        assert result == (55, 3628800)

    def test_negative_product_odd_negatives(self):
        result = sum_product([-1, 2, -3, 4])
        assert result == (2, 24)

    def test_negative_product_even_negatives(self):
        result = sum_product([-1, -2, 3, 4])
        assert result == (4, 24)


@pytest.mark.parametrize("numbers,expected", [
    ([], (0, 1)),
    ([5], (5, 5)),
    ([2, 3], (5, 6)),
    ([1, 2, 3, 4], (10, 24)),
    ([0], (0, 0)),
    ([1, 0, 3], (4, 0)),
    ([-1, -2, -3], (-6, -6)),
    ([1, -2, 3], (2, -6)),
    ([100, 200, 300], (600, 6000000)),
    ([1, 1, 1, 1], (4, 1)),
    ([-1, -1, -1], (-3, -1)),
    ([10, 20, 30], (60, 6000)),
    ([-5, 0, 3], (-2, 0)),
    ([2, 2, 2, 2], (8, 16)),
])
def test_sum_product_parametrized(numbers, expected):
    assert sum_product(numbers) == expected


def test_return_type():
    result = sum_product([1, 2, 3])
    assert isinstance(result, tuple)
    assert len(result) == 2
    assert isinstance(result[0], int)
    assert isinstance(result[1], int)


def test_immutability():
    original = [1, 2, 3]
    original_copy = original.copy()
    sum_product(original)
    assert original == original_copy
