# Test cases for HumanEval/48
# Generated using Claude API



def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """

    for i in range(len(text)):
        if text[i] != text[len(text) - 1 - i]:
            return False
    return True


# Generated test cases:
import pytest


def is_palindrome(text: str):
    for i in range(len(text)):
        if text[i] != text[len(text) - 1 - i]:
            return False
    return True


class TestIsPalindrome:
    
    @pytest.mark.parametrize("text,expected", [
        ("", True),
        ("a", True),
        ("aa", True),
        ("aba", True),
        ("aaaaa", True),
        ("racecar", True),
        ("madam", True),
        ("noon", True),
        ("level", True),
        ("12321", True),
        ("abcba", True),
    ])
    def test_valid_palindromes(self, text, expected):
        assert is_palindrome(text) == expected
    
    @pytest.mark.parametrize("text,expected", [
        ("zbcd", False),
        ("ab", False),
        ("abc", False),
        ("abcd", False),
        ("hello", False),
        ("world", False),
        ("python", False),
        ("test", False),
        ("12345", False),
        ("abcdef", False),
    ])
    def test_invalid_palindromes(self, text, expected):
        assert is_palindrome(text) == expected
    
    def test_empty_string(self):
        assert is_palindrome("") is True
    
    def test_single_character(self):
        assert is_palindrome("a") is True
    
    def test_two_same_characters(self):
        assert is_palindrome("aa") is True
    
    def test_two_different_characters(self):
        assert is_palindrome("ab") is False
    
    def test_odd_length_palindrome(self):
        assert is_palindrome("racecar") is True
    
    def test_even_length_palindrome(self):
        assert is_palindrome("abba") is True
    
    def test_odd_length_non_palindrome(self):
        assert is_palindrome("abcde") is False
    
    def test_even_length_non_palindrome(self):
        assert is_palindrome("abcd") is False
    
    def test_numeric_palindrome(self):
        assert is_palindrome("12321") is True
    
    def test_numeric_non_palindrome(self):
        assert is_palindrome("12345") is False
    
    def test_special_characters_palindrome(self):
        assert is_palindrome("!@!") is True
    
    def test_special_characters_non_palindrome(self):
        assert is_palindrome("!@#") is False
    
    def test_spaces_palindrome(self):
        assert is_palindrome("a b a") is True
    
    def test_spaces_non_palindrome(self):
        assert is_palindrome("a b c") is False
    
    def test_mixed_case_not_palindrome(self):
        assert is_palindrome("Aba") is False
    
    def test_long_palindrome(self):
        assert is_palindrome("abcdefghijihgfedcba") is True
    
    def test_long_non_palindrome(self):
        assert is_palindrome("abcdefghijklmnopqrst") is False
