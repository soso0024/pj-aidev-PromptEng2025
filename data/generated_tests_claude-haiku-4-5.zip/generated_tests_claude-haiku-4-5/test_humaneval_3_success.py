# Test cases for HumanEval/3
# Generated using Claude API

from typing import List


def below_zero(operations: List[int]) -> bool:
    """ You're given a list of deposit and withdrawal operations on a bank account that starts with
    zero balance. Your task is to detect if at any point the balance of account fallls below zero, and
    at that point function should return True. Otherwise it should return False.
    >>> below_zero([1, 2, 3])
    False
    >>> below_zero([1, 2, -4, 5])
    True
    """

    balance = 0

    for op in operations:
        balance += op
        if balance < 0:
            return True

    return False


# Generated test cases:
import pytest
from typing import List


def below_zero(operations: List[int]) -> bool:
    balance = 0

    for op in operations:
        balance += op
        if balance < 0:
            return True

    return False


class TestBelowZero:
    def test_empty_list(self):
        assert below_zero([]) is False

    def test_single_positive_operation(self):
        assert below_zero([1]) is False

    def test_single_negative_operation(self):
        assert below_zero([-1]) is True

    def test_single_zero_operation(self):
        assert below_zero([0]) is False

    def test_all_positive_operations(self):
        assert below_zero([1, 2, 3, 4, 5]) is False

    def test_all_negative_operations(self):
        assert below_zero([-1, -2, -3]) is True

    def test_negative_at_end(self):
        assert below_zero([5, 3, -10]) is True

    def test_negative_in_middle(self):
        assert below_zero([5, -10, 3]) is True

    def test_negative_at_start(self):
        assert below_zero([-5, 10, 3]) is True

    def test_balance_reaches_zero_then_negative(self):
        assert below_zero([5, -5, -1]) is True

    def test_balance_stays_at_zero(self):
        assert below_zero([5, -5, 0]) is False

    def test_large_positive_then_large_negative(self):
        assert below_zero([1000, -2000]) is True

    def test_multiple_operations_never_below_zero(self):
        assert below_zero([10, 5, 3, 2, 1]) is False

    def test_multiple_operations_goes_below_zero_once(self):
        assert below_zero([10, 5, -20, 3]) is True

    def test_zero_operations(self):
        assert below_zero([0, 0, 0, 0]) is False

    def test_mixed_operations_stays_positive(self):
        assert below_zero([5, -2, 3, -1, 4]) is False

    def test_mixed_operations_goes_negative(self):
        assert below_zero([5, -2, 3, -10, 4]) is True

    def test_large_list_no_negative_balance(self):
        assert below_zero([1] * 100) is False

    def test_large_list_with_negative_balance(self):
        operations = [1] * 50 + [-100]
        assert below_zero(operations) is True

    def test_negative_balance_at_first_operation(self):
        assert below_zero([-1, 100, 200]) is True

    def test_balance_exactly_zero_never_below(self):
        assert below_zero([10, -10, 5, -5]) is False

    def test_very_large_negative_number(self):
        assert below_zero([1, -999999]) is True

    def test_very_large_positive_then_negative(self):
        assert below_zero([999999, -1000000]) is True


@pytest.mark.parametrize("operations,expected", [
    ([], False),
    ([1], False),
    ([-1], True),
    ([0], False),
    ([1, 2, 3], False),
    ([-1, -2, -3], True),
    ([5, -10], True),
    ([10, -5], False),
    ([0, 0, 0], False),
    ([1, 1, 1, -5], True),
    ([100, -50, -60], True),
    ([50, 50, 50], False),
])
def test_below_zero_parametrized(operations, expected):
    assert below_zero(operations) is expected
