# Test cases for HumanEval/140
# Generated using Claude API


def fix_spaces(text):
    """
    Given a string text, replace all spaces in it with underscores, 
    and if a string has more than 2 consecutive spaces, 
    then replace all consecutive spaces with - 
    
    fix_spaces("Example") == "Example"
    fix_spaces("Example 1") == "Example_1"
    fix_spaces(" Example 2") == "_Example_2"
    fix_spaces(" Example   3") == "_Example-3"
    """

    new_text = ""
    i = 0
    start, end = 0, 0
    while i < len(text):
        if text[i] == " ":
            end += 1
        else:
            if end - start > 2:
                new_text += "-"+text[i]
            elif end - start > 0:
                new_text += "_"*(end - start)+text[i]
            else:
                new_text += text[i]
            start, end = i+1, i+1
        i+=1
    if end - start > 2:
        new_text += "-"
    elif end - start > 0:
        new_text += "_"
    return new_text


# Generated test cases:
import pytest


class TestFixSpaces:
    
    def test_empty_string(self):
        from test_humaneval_140_ast import fix_spaces
        assert fix_spaces("") == ""
    
    def test_no_spaces(self):
        assert fix_spaces("abc") == "abc"
    
    def test_single_space(self):
        assert fix_spaces("a b") == "a_b"
    
    def test_two_spaces(self):
        assert fix_spaces("a  b") == "a__b"
    
    def test_three_spaces(self):
        assert fix_spaces("a   b") == "a-b"
    
    def test_four_spaces(self):
        assert fix_spaces("a    b") == "a-b"
    
    def test_multiple_space_groups_single(self):
        assert fix_spaces("a b c") == "a_b_c"
    
    def test_multiple_space_groups_double(self):
        assert fix_spaces("a  b  c") == "a__b__c"
    
    def test_multiple_space_groups_triple(self):
        assert fix_spaces("a   b   c") == "a-b-c"
    
    def test_mixed_space_groups(self):
        assert fix_spaces("a b  c   d") == "a_b__c-d"
    
    def test_leading_single_space(self):
        assert fix_spaces(" a") == "_a"
    
    def test_leading_double_space(self):
        assert fix_spaces("  a") == "__a"
    
    def test_leading_triple_space(self):
        assert fix_spaces("   a") == "-a"
    
    def test_trailing_single_space(self):
        assert fix_spaces("a ") == "a_"
    
    def test_trailing_double_space(self):
        assert fix_spaces("a  ") == "a_"
    
    def test_trailing_triple_space(self):
        assert fix_spaces("a   ") == "a-"
    
    def test_only_single_space(self):
        assert fix_spaces(" ") == "_"
    
    def test_only_double_space(self):
        assert fix_spaces("  ") == "_"
    
    def test_only_triple_space(self):
        assert fix_spaces("   ") == "-"
    
    def test_only_four_spaces(self):
        assert fix_spaces("    ") == "-"
    
    def test_single_character(self):
        assert fix_spaces("a") == "a"
    
    def test_complex_string_1(self):
        assert fix_spaces("fix  spaces") == "fix__spaces"
    
    def test_complex_string_2(self):
        assert fix_spaces("fix   spaces") == "fix-spaces"
    
    def test_complex_string_3(self):
        assert fix_spaces("fix    spaces") == "fix-spaces"
    
    def test_consecutive_single_spaces(self):
        assert fix_spaces("a b c d e") == "a_b_c_d_e"
    
    def test_consecutive_double_spaces(self):
        assert fix_spaces("a  b  c  d") == "a__b__c__d"
    
    def test_consecutive_triple_spaces(self):
        assert fix_spaces("a   b   c   d") == "a-b-c-d"
    
    def test_alternating_spaces(self):
        assert fix_spaces("a b  c   d") == "a_b__c-d"
    
    def test_long_string_with_many_spaces(self):
        assert fix_spaces("hello     world") == "hello-world"
    
    def test_numbers_with_spaces(self):
        assert fix_spaces("1 2 3") == "1_2_3"
    
    def test_special_characters_with_spaces(self):
        assert fix_spaces("! @ #") == "!_@_#"
    
    def test_mixed_content(self):
        assert fix_spaces("a1 b2  c3   d4") == "a1_b2__c3-d4"
    
    def test_five_spaces(self):
        assert fix_spaces("a     b") == "a-b"
    
    def test_ten_spaces(self):
        assert fix_spaces("a          b") == "a-b"
    
    def test_space_at_beginning_and_end(self):
        assert fix_spaces(" a ") == "_a_"
    
    def test_space_at_beginning_and_end_double(self):
        assert fix_spaces("  a  ") == "__a_"
    
    def test_space_at_beginning_and_end_triple(self):
        assert fix_spaces("   a   ") == "-a-"
    
    def test_only_spaces_five(self):
        assert fix_spaces("     ") == "-"
    
    def test_word_with_internal_spaces(self):
        assert fix_spaces("a b c d") == "a_b_c_d"
    
    def test_repeated_pattern(self):
        assert fix_spaces("x y x y") == "x_y_x_y"
    
    @pytest.mark.parametrize("input_text,expected", [
        ("", ""),
        ("a", "a"),
        ("a b", "a_b"),
        ("a  b", "a__b"),
        ("a   b", "a-b"),
        ("a    b", "a-b"),
        ("a b c", "a_b_c"),
        ("a  b  c", "a__b__c"),
        ("a   b   c", "a-b-c"),
        (" a", "_a"),
        ("a ", "a_"),
        ("  a", "__a"),
        ("a  ", "a_"),
        ("   a", "-a"),
        ("a   ", "a-"),
        (" ", "_"),
        ("  ", "_"),
        ("   ", "-"),
        ("    ", "-"),
    ])
    def test_parametrized_cases(self, input_text, expected):
        assert fix_spaces(input_text) == expected