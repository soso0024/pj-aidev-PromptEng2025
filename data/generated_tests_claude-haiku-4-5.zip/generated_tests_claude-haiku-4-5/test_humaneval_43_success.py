# Test cases for HumanEval/43
# Generated using Claude API



def pairs_sum_to_zero(l):
    """
    pairs_sum_to_zero takes a list of integers as an input.
    it returns True if there are two distinct elements in the list that
    sum to zero, and False otherwise.
    >>> pairs_sum_to_zero([1, 3, 5, 0])
    False
    >>> pairs_sum_to_zero([1, 3, -2, 1])
    False
    >>> pairs_sum_to_zero([1, 2, 3, 7])
    False
    >>> pairs_sum_to_zero([2, 4, -5, 3, 5, 7])
    True
    >>> pairs_sum_to_zero([1])
    False
    """

    for i, l1 in enumerate(l):
        for j in range(i + 1, len(l)):
            if l1 + l[j] == 0:
                return True
    return False


# Generated test cases:
import pytest


def pairs_sum_to_zero(l):
    for i, l1 in enumerate(l):
        for j in range(i + 1, len(l)):
            if l1 + l[j] == 0:
                return True
    return False


class TestPairsSumToZero:
    
    @pytest.mark.parametrize("input_list,expected", [
        ([1, -1], True),
        ([1, 2, 3, -1], True),
        ([1, 2, 3, 4], False),
        ([-1, -2, -3], False),
        ([0, 0], True),
        ([5, -5, 10], True),
        ([-10, 5, 10, -5], True),
        ([1, 2, 3], False),
        ([-1, -2, -3, -4], False),
        ([100, -100], True),
    ])
    def test_pairs_sum_to_zero_parametrized(self, input_list, expected):
        assert pairs_sum_to_zero(input_list) == expected
    
    def test_empty_list(self):
        assert pairs_sum_to_zero([]) == False
    
    def test_single_element(self):
        assert pairs_sum_to_zero([1]) == False
    
    def test_two_elements_sum_to_zero(self):
        assert pairs_sum_to_zero([5, -5]) == True
    
    def test_two_elements_not_sum_to_zero(self):
        assert pairs_sum_to_zero([5, 3]) == False
    
    def test_multiple_pairs_sum_to_zero(self):
        assert pairs_sum_to_zero([1, -1, 2, -2, 3]) == True
    
    def test_zero_with_zero(self):
        assert pairs_sum_to_zero([0, 0]) == True
    
    def test_single_zero(self):
        assert pairs_sum_to_zero([0]) == False
    
    def test_zero_with_other_numbers(self):
        assert pairs_sum_to_zero([0, 1, 2]) == False
    
    def test_large_numbers(self):
        assert pairs_sum_to_zero([1000000, -1000000]) == True
    
    def test_large_numbers_no_pair(self):
        assert pairs_sum_to_zero([1000000, 999999]) == False
    
    def test_negative_numbers_only(self):
        assert pairs_sum_to_zero([-1, -2, -3, -4, -5]) == False
    
    def test_positive_numbers_only(self):
        assert pairs_sum_to_zero([1, 2, 3, 4, 5]) == False
    
    def test_pair_at_beginning(self):
        assert pairs_sum_to_zero([5, -5, 1, 2, 3]) == True
    
    def test_pair_at_end(self):
        assert pairs_sum_to_zero([1, 2, 3, 5, -5]) == True
    
    def test_pair_in_middle(self):
        assert pairs_sum_to_zero([1, 2, 5, -5, 3]) == True
    
    def test_multiple_zeros(self):
        assert pairs_sum_to_zero([0, 0, 0]) == True
    
    def test_fractional_like_integers(self):
        assert pairs_sum_to_zero([1, 2, 3, -2]) == True
    
    def test_no_pair_with_similar_numbers(self):
        assert pairs_sum_to_zero([1, 2, 3, 4, 5, 6]) == False
    
    def test_mixed_with_duplicates(self):
        assert pairs_sum_to_zero([1, 1, -1, 2]) == True
    
    def test_long_list_with_pair_at_end(self):
        assert pairs_sum_to_zero([1, 2, 3, 4, 5, 6, 7, 8, 9, -9]) == True
    
    def test_long_list_no_pair(self):
        assert pairs_sum_to_zero([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == False
