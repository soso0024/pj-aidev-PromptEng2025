# Test cases for HumanEval/98
# Generated using Claude API


def count_upper(s):
    """
    Given a string s, count the number of uppercase vowels in even indices.
    
    For example:
    count_upper('aBCdEf') returns 1
    count_upper('abcdefg') returns 0
    count_upper('dBBE') returns 0
    """

    count = 0
    for i in range(0,len(s),2):
        if s[i] in "AEIOU":
            count += 1
    return count


# Generated test cases:
import pytest


def count_upper(s):
    count = 0
    for i in range(0, len(s), 2):
        if s[i] in "AEIOU":
            count += 1
    return count


@pytest.mark.parametrize("input_str,expected", [
    ('aBCdEf', 1),
    ('abcdefg', 0),
    ('dBBE', 0),
    ('AEIOU', 3),
    ('aeiou', 0),
    ('A', 1),
    ('a', 0),
    ('', 0),
    ('AB', 1),
    ('Ba', 0),
    ('AaBbCcDdEe', 2),
    ('ABCDEFGHIJ', 3),
    ('abcdefghij', 0),
    ('AEIOUaeiou', 3),
    ('aEIOUAeiou', 2),
    ('E', 1),
    ('I', 1),
    ('O', 1),
    ('U', 1),
    ('e', 0),
    ('i', 0),
    ('o', 0),
    ('u', 0),
    ('AaAaAa', 3),
    ('aAaAaA', 0),
    ('AEIOUBCDFG', 3),
    ('bcdfgAEIOU', 2),
    ('A B C D E', 2),
    ('123A456E789', 0),
    ('!@#$%^&*()', 0),
    ('AEIOUaeiouAEIOUaeiou', 6),
])
def test_count_upper(input_str, expected):
    assert count_upper(input_str) == expected


def test_count_upper_single_uppercase_vowel():
    assert count_upper('A') == 1
    assert count_upper('E') == 1
    assert count_upper('I') == 1
    assert count_upper('O') == 1
    assert count_upper('U') == 1


def test_count_upper_single_lowercase_vowel():
    assert count_upper('a') == 0
    assert count_upper('e') == 0
    assert count_upper('i') == 0
    assert count_upper('o') == 0
    assert count_upper('u') == 0


def test_count_upper_single_consonant():
    assert count_upper('B') == 0
    assert count_upper('C') == 0
    assert count_upper('Z') == 0


def test_count_upper_empty_string():
    assert count_upper('') == 0


def test_count_upper_only_even_indices_matter():
    assert count_upper('AEIOU') == 3
    assert count_upper('aAEIOUa') == 2
    assert count_upper('xAxExIxOxU') == 0


def test_count_upper_mixed_case():
    assert count_upper('AaBbCcDdEe') == 2
    assert count_upper('aAbBcCdDeE') == 0


def test_count_upper_special_characters():
    assert count_upper('!@#$%') == 0
    assert count_upper('A!B@C#D$E%') == 2


def test_count_upper_numbers():
    assert count_upper('123456') == 0
    assert count_upper('A1B2C3') == 1


def test_count_upper_spaces():
    assert count_upper('A B C D E') == 2
    assert count_upper(' A B C D') == 0


def test_count_upper_long_string():
    long_str = 'A' * 100
    assert count_upper(long_str) == 50
    
    long_str_mixed = 'Aa' * 50
    assert count_upper(long_str_mixed) == 50


def test_count_upper_all_uppercase_vowels():
    assert count_upper('AEIOUAEIOU') == 5


def test_count_upper_all_lowercase_vowels():
    assert count_upper('aeiouaeiou') == 0


def test_count_upper_consonants_only():
    assert count_upper('BCDFGHJKLMNPQRSTVWXYZ') == 0
    assert count_upper('bcdfghjklmnpqrstvwxyz') == 0