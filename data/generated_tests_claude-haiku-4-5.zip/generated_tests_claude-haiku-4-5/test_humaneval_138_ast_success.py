# Test cases for HumanEval/138
# Generated using Claude API


def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """

    return n%2 == 0 and n >= 8


# Generated test cases:
import pytest


def is_equal_to_sum_even(n):
    return n%2 == 0 and n >= 8


class TestIsEqualToSumEven:
    
    @pytest.mark.parametrize("n,expected", [
        (8, True),
        (10, True),
        (100, True),
        (1000, True),
        (2, False),
        (4, False),
        (6, False),
        (0, False),
        (-8, False),
        (-10, False),
        (9, False),
        (11, False),
        (7, False),
        (1, False),
        (3, False),
        (5, False),
    ])
    def test_is_equal_to_sum_even(self, n, expected):
        assert is_equal_to_sum_even(n) == expected
    
    def test_boundary_value_8(self):
        assert is_equal_to_sum_even(8) is True
    
    def test_boundary_value_7(self):
        assert is_equal_to_sum_even(7) is False
    
    def test_boundary_value_6(self):
        assert is_equal_to_sum_even(6) is False
    
    def test_even_numbers_below_8(self):
        assert is_equal_to_sum_even(0) is False
        assert is_equal_to_sum_even(2) is False
        assert is_equal_to_sum_even(4) is False
        assert is_equal_to_sum_even(6) is False
    
    def test_odd_numbers_above_8(self):
        assert is_equal_to_sum_even(9) is False
        assert is_equal_to_sum_even(11) is False
        assert is_equal_to_sum_even(13) is False
        assert is_equal_to_sum_even(99) is False
    
    def test_even_numbers_above_8(self):
        assert is_equal_to_sum_even(10) is True
        assert is_equal_to_sum_even(12) is True
        assert is_equal_to_sum_even(20) is True
        assert is_equal_to_sum_even(50) is True
        assert is_equal_to_sum_even(1000) is True
    
    def test_negative_even_numbers(self):
        assert is_equal_to_sum_even(-2) is False
        assert is_equal_to_sum_even(-4) is False
        assert is_equal_to_sum_even(-8) is False
        assert is_equal_to_sum_even(-10) is False
    
    def test_negative_odd_numbers(self):
        assert is_equal_to_sum_even(-1) is False
        assert is_equal_to_sum_even(-3) is False
        assert is_equal_to_sum_even(-9) is False
    
    def test_large_even_numbers(self):
        assert is_equal_to_sum_even(10000) is True
        assert is_equal_to_sum_even(999998) is True
    
    def test_large_odd_numbers(self):
        assert is_equal_to_sum_even(9999) is False
        assert is_equal_to_sum_even(999999) is False
