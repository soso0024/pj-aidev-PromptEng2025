# Test cases for HumanEval/65
# Generated using Claude API


def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.
    >>> circular_shift(12, 1)
    "21"
    >>> circular_shift(12, 2)
    "12"
    """

    s = str(x)
    if shift > len(s):
        return s[::-1]
    else:
        return s[len(s) - shift:] + s[:len(s) - shift]


# Generated test cases:
import pytest


def circular_shift(x, shift):
    s = str(x)
    if shift > len(s):
        return s[::-1]
    else:
        return s[len(s) - shift:] + s[:len(s) - shift]


class TestCircularShift:
    
    @pytest.mark.parametrize("x,shift,expected", [
        (12, 1, "21"),
        (12, 2, "12"),
        (123, 1, "312"),
        (123, 2, "231"),
        (123, 3, "123"),
        (1234, 1, "4123"),
        (1234, 2, "3412"),
        (1234, 3, "2341"),
        (1234, 4, "1234"),
    ])
    def test_circular_shift_normal_cases(self, x, shift, expected):
        assert circular_shift(x, shift) == expected
    
    @pytest.mark.parametrize("x,shift,expected", [
        (12, 3, "21"),
        (123, 4, "321"),
        (123, 5, "321"),
        (1234, 5, "4321"),
        (1234, 10, "4321"),
        (5, 2, "5"),
    ])
    def test_circular_shift_greater_than_length(self, x, shift, expected):
        assert circular_shift(x, shift) == expected
    
    @pytest.mark.parametrize("x,shift,expected", [
        (0, 1, "0"),
        (0, 5, "0"),
        (5, 0, "5"),
        (5, 1, "5"),
        (9, 1, "9"),
    ])
    def test_circular_shift_single_digit(self, x, shift, expected):
        assert circular_shift(x, shift) == expected
    
    @pytest.mark.parametrize("x,shift,expected", [
        (100, 1, "010"),
        (100, 2, "001"),
        (100, 3, "100"),
        (1000, 1, "0100"),
        (1001, 1, "1100"),
        (1001, 2, "0110"),
    ])
    def test_circular_shift_with_zeros(self, x, shift, expected):
        assert circular_shift(x, shift) == expected
    
    @pytest.mark.parametrize("x,shift,expected", [
        (9876543210, 1, "0987654321"),
        (9876543210, 5, "4321098765"),
    ])
    def test_circular_shift_large_numbers(self, x, shift, expected):
        assert circular_shift(x, shift) == expected
    
    def test_circular_shift_zero_shift(self):
        assert circular_shift(12345, 0) == "12345"
    
    def test_circular_shift_return_type_is_string(self):
        result = circular_shift(123, 1)
        assert isinstance(result, str)
    
    @pytest.mark.parametrize("x,shift", [
        (12, 1),
        (999, 2),
        (1, 1),
        (54321, 3),
    ])
    def test_circular_shift_returns_same_length_string(self, x, shift):
        result = circular_shift(x, shift)
        assert len(result) == len(str(x))