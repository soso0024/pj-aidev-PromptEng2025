# Test cases for HumanEval/39
# Generated using Claude API



def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """

    import math

    def is_prime(p):
        if p < 2:
            return False
        for k in range(2, min(int(math.sqrt(p)) + 1, p - 1)):
            if p % k == 0:
                return False
        return True
    f = [0, 1]
    while True:
        f.append(f[-1] + f[-2])
        if is_prime(f[-1]):
            n -= 1
        if n == 0:
            return f[-1]


# Generated test cases:
import pytest


def prime_fib(n: int):
    import math

    def is_prime(p):
        if p < 2:
            return False
        for k in range(2, min(int(math.sqrt(p)) + 1, p - 1)):
            if p % k == 0:
                return False
        return True
    f = [0, 1]
    while True:
        f.append(f[-1] + f[-2])
        if is_prime(f[-1]):
            n -= 1
        if n == 0:
            return f[-1]


class TestPrimeFib:
    
    @pytest.mark.parametrize("n,expected", [
        (1, 2),
        (2, 3),
        (3, 5),
        (4, 13),
        (5, 89),
    ])
    def test_prime_fib_basic_cases(self, n, expected):
        assert prime_fib(n) == expected
    
    def test_prime_fib_first_prime_fib(self):
        assert prime_fib(1) == 2
    
    def test_prime_fib_second_prime_fib(self):
        assert prime_fib(2) == 3
    
    def test_prime_fib_third_prime_fib(self):
        assert prime_fib(3) == 5
    
    def test_prime_fib_fourth_prime_fib(self):
        assert prime_fib(4) == 13
    
    def test_prime_fib_fifth_prime_fib(self):
        assert prime_fib(5) == 89
    
    def test_prime_fib_sixth_prime_fib(self):
        assert prime_fib(6) == 233
    
    def test_prime_fib_seventh_prime_fib(self):
        assert prime_fib(7) == 1597
    
    def test_prime_fib_eighth_prime_fib(self):
        assert prime_fib(8) == 28657
    
    def test_prime_fib_ninth_prime_fib(self):
        assert prime_fib(9) == 514229
    
    def test_prime_fib_tenth_prime_fib(self):
        assert prime_fib(10) == 433494437
    
    def test_prime_fib_returns_prime_number(self):
        result = prime_fib(1)
        assert result == 2
        assert result > 1
    
    def test_prime_fib_returns_fibonacci_number(self):
        result = prime_fib(3)
        assert result == 5
        fib_sequence = [0, 1]
        while fib_sequence[-1] < result:
            fib_sequence.append(fib_sequence[-1] + fib_sequence[-2])
        assert result in fib_sequence
    
    def test_prime_fib_sequence_is_increasing(self):
        results = [prime_fib(i) for i in range(1, 6)]
        assert results == sorted(results)
        assert all(results[i] < results[i+1] for i in range(len(results)-1))
    
    def test_prime_fib_large_n(self):
        result = prime_fib(11)
        assert isinstance(result, int)
        assert result > 0
    
    def test_prime_fib_consistency(self):
        assert prime_fib(1) == 2
        assert prime_fib(1) == 2
    
    def test_prime_fib_all_results_are_positive(self):
        for i in range(1, 8):
            assert prime_fib(i) > 0
    
    def test_prime_fib_all_results_are_integers(self):
        for i in range(1, 8):
            assert isinstance(prime_fib(i), int)
