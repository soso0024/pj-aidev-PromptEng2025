# Test cases for HumanEval/122
# Generated using Claude API


def add_elements(arr, k):
    """
    Given a non-empty array of integers arr and an integer k, return
    the sum of the elements with at most two digits from the first k elements of arr.

    Example:

        Input: arr = [111,21,3,4000,5,6,7,8,9], k = 4
        Output: 24 # sum of 21 + 3

    Constraints:
        1. 1 <= len(arr) <= 100
        2. 1 <= k <= len(arr)
    """

    return sum(elem for elem in arr[:k] if len(str(elem)) <= 2)


# Generated test cases:
import pytest


def add_elements(arr, k):
    return sum(elem for elem in arr[:k] if len(str(elem)) <= 2)


class TestAddElements:
    
    def test_empty_array(self):
        assert add_elements([], 0) == 0
    
    def test_k_zero(self):
        assert add_elements([1, 2, 3, 4, 5], 0) == 0
    
    def test_k_greater_than_array_length(self):
        assert add_elements([1, 2, 3], 10) == 6
    
    def test_single_digit_numbers(self):
        assert add_elements([1, 2, 3, 4, 5], 3) == 6
    
    def test_two_digit_numbers(self):
        assert add_elements([10, 20, 30], 3) == 60
    
    def test_mixed_single_and_two_digit(self):
        assert add_elements([1, 10, 2, 20, 3], 5) == 36
    
    def test_three_digit_numbers_excluded(self):
        assert add_elements([1, 100, 2, 200, 3], 5) == 6
    
    def test_negative_single_digit(self):
        assert add_elements([-1, -2, -3], 3) == -6
    
    def test_negative_two_digit(self):
        assert add_elements([-10, -20, -30], 3) == -60
    
    def test_mixed_positive_negative(self):
        assert add_elements([5, -10, 3, -20, 7], 5) == -15
    
    def test_zero_in_array(self):
        assert add_elements([0, 1, 2, 3], 4) == 6
    
    def test_k_equals_one(self):
        assert add_elements([5, 100, 200], 1) == 5
    
    def test_k_equals_array_length(self):
        assert add_elements([1, 2, 3, 4], 4) == 10
    
    def test_all_three_digit_numbers(self):
        assert add_elements([100, 200, 300], 3) == 0
    
    def test_mixed_with_three_digit_at_start(self):
        assert add_elements([100, 1, 2, 3], 4) == 6
    
    def test_mixed_with_three_digit_in_middle(self):
        assert add_elements([1, 100, 2, 3], 4) == 6
    
    def test_large_k_with_mixed_numbers(self):
        assert add_elements([1, 2, 100, 200, 3, 4], 10) == 10
    
    def test_negative_three_digit(self):
        assert add_elements([-100, -1, -2], 3) == -3
    
    def test_boundary_99(self):
        assert add_elements([99, 100, 101], 3) == 99
    
    def test_boundary_negative_99(self):
        assert add_elements([-99, -100, -101], 3) == -99
    
    @pytest.mark.parametrize("arr,k,expected", [
        ([1, 2, 3], 2, 3),
        ([10, 20, 30], 2, 30),
        ([5, 100, 10], 3, 15),
        ([-5, -10, 5], 3, -10),
        ([0, 0, 0], 3, 0),
        ([99, 99, 99], 3, 297),
        ([1], 1, 1),
        ([100], 1, 0),
    ])
    def test_parametrized_cases(self, arr, k, expected):
        assert add_elements(arr, k) == expected