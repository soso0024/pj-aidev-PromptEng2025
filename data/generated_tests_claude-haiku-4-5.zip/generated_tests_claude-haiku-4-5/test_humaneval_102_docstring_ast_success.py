# Test cases for HumanEval/102
# Generated using Claude API


def choose_num(x, y):
    """This function takes two positive numbers x and y and returns the
    biggest even integer number that is in the range [x, y] inclusive. If 
    there's no such number, then the function should return -1.

    For example:
    choose_num(12, 15) = 14
    choose_num(13, 12) = -1
    """

    if x > y:
        return -1
    if y % 2 == 0:
        return y
    if x == y:
        return -1
    return y - 1


# Generated test cases:
import pytest


def choose_num(x, y):
    if x > y:
        return -1
    if y % 2 == 0:
        return y
    if x == y:
        return -1
    return y - 1


class TestChooseNum:
    
    def test_basic_example_1(self):
        assert choose_num(12, 15) == 14
    
    def test_basic_example_2(self):
        assert choose_num(13, 12) == -1
    
    def test_x_greater_than_y(self):
        assert choose_num(20, 10) == -1
    
    def test_x_equals_y_both_even(self):
        assert choose_num(4, 4) == 4
    
    def test_x_equals_y_both_odd(self):
        assert choose_num(5, 5) == -1
    
    def test_y_is_even(self):
        assert choose_num(1, 10) == 10
    
    def test_y_is_odd_x_is_even(self):
        assert choose_num(2, 9) == 8
    
    def test_y_is_odd_x_is_odd(self):
        assert choose_num(3, 9) == 8
    
    def test_both_even_consecutive(self):
        assert choose_num(2, 4) == 4
    
    def test_both_odd_consecutive(self):
        assert choose_num(1, 3) == 2
    
    def test_large_range_even_end(self):
        assert choose_num(1, 100) == 100
    
    def test_large_range_odd_end(self):
        assert choose_num(1, 99) == 98
    
    def test_single_even_number(self):
        assert choose_num(8, 8) == 8
    
    def test_single_odd_number(self):
        assert choose_num(7, 7) == -1
    
    def test_two_consecutive_even(self):
        assert choose_num(6, 8) == 8
    
    def test_two_consecutive_odd(self):
        assert choose_num(5, 7) == 6
    
    def test_range_with_multiple_evens(self):
        assert choose_num(10, 20) == 20
    
    def test_range_with_multiple_odds_ending_odd(self):
        assert choose_num(11, 21) == 20
    
    def test_zero_in_range(self):
        assert choose_num(0, 5) == 4
    
    def test_zero_as_both_bounds(self):
        assert choose_num(0, 0) == 0
    
    def test_negative_to_positive(self):
        assert choose_num(-5, 5) == 4
    
    def test_both_negative_even_end(self):
        assert choose_num(-10, -2) == -2
    
    def test_both_negative_odd_end(self):
        assert choose_num(-9, -3) == -4
    
    def test_negative_equal_odd(self):
        assert choose_num(-5, -5) == -1
    
    def test_negative_equal_even(self):
        assert choose_num(-4, -4) == -4


@pytest.mark.parametrize("x,y,expected", [
    (12, 15, 14),
    (13, 12, -1),
    (20, 10, -1),
    (4, 4, 4),
    (5, 5, -1),
    (1, 10, 10),
    (2, 9, 8),
    (3, 9, 8),
    (2, 4, 4),
    (1, 3, 2),
    (1, 100, 100),
    (1, 99, 98),
    (8, 8, 8),
    (7, 7, -1),
    (6, 8, 8),
    (5, 7, 6),
    (10, 20, 20),
    (11, 21, 20),
    (0, 5, 4),
    (0, 0, 0),
    (-5, 5, 4),
    (-10, -2, -2),
    (-9, -3, -4),
    (-5, -5, -1),
    (-4, -4, -4),
    (100, 100, 100),
    (101, 101, -1),
    (50, 51, 50),
    (49, 50, 50),
])
def test_choose_num_parametrized(x, y, expected):
    assert choose_num(x, y) == expected
