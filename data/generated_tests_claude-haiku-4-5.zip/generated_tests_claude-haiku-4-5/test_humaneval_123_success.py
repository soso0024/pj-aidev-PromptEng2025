# Test cases for HumanEval/123
# Generated using Claude API


def get_odd_collatz(n):
    """
    Given a positive integer n, return a sorted list that has the odd numbers in collatz sequence.

    The Collatz conjecture is a conjecture in mathematics that concerns a sequence defined
    as follows: start with any positive integer n. Then each term is obtained from the 
    previous term as follows: if the previous term is even, the next term is one half of 
    the previous term. If the previous term is odd, the next term is 3 times the previous
    term plus 1. The conjecture is that no matter what value of n, the sequence will always reach 1.

    Note: 
        1. Collatz(1) is [1].
        2. returned list sorted in increasing order.

    For example:
    get_odd_collatz(5) returns [1, 5] # The collatz sequence for 5 is [5, 16, 8, 4, 2, 1], so the odd numbers are only 1, and 5.
    """

    if n%2==0:
        odd_collatz = [] 
    else:
        odd_collatz = [n]
    while n > 1:
        if n % 2 == 0:
            n = n/2
        else:
            n = n*3 + 1
            
        if n%2 == 1:
            odd_collatz.append(int(n))

    return sorted(odd_collatz)


# Generated test cases:
import pytest


class TestGetOddCollatz:
    
    def test_odd_number_basic(self):
        from test_humaneval_123 import get_odd_collatz
        result = get_odd_collatz(1)
        assert result == [1]
    
    def test_even_number_basic(self):
        result = get_odd_collatz(2)
        assert result == [1]
    
    def test_odd_number_5(self):
        result = get_odd_collatz(5)
        assert result == [1, 5]
    
    def test_even_number_4(self):
        result = get_odd_collatz(4)
        assert result == [1]
    
    def test_odd_number_3(self):
        result = get_odd_collatz(3)
        assert result == [1, 3, 5]
    
    def test_even_number_6(self):
        result = get_odd_collatz(6)
        assert result == [1, 3, 5]
    
    def test_odd_number_7(self):
        result = get_odd_collatz(7)
        assert result == [1, 5, 7, 11, 13, 17]
    
    def test_even_number_8(self):
        result = get_odd_collatz(8)
        assert result == [1]
    
    def test_odd_number_9(self):
        result = get_odd_collatz(9)
        assert result == [1, 5, 7, 9, 11, 13, 17]
    
    def test_even_number_10(self):
        result = get_odd_collatz(10)
        assert result == [1, 5]
    
    def test_result_is_sorted(self):
        result = get_odd_collatz(5)
        assert result == sorted(result)
    
    def test_result_contains_only_odd_numbers(self):
        result = get_odd_collatz(10)
        for num in result:
            assert num % 2 == 1
    
    def test_result_is_list(self):
        result = get_odd_collatz(5)
        assert isinstance(result, list)
    
    def test_result_contains_integers(self):
        result = get_odd_collatz(5)
        for num in result:
            assert isinstance(num, int)
    
    def test_large_odd_number(self):
        result = get_odd_collatz(27)
        assert isinstance(result, list)
        assert all(num % 2 == 1 for num in result)
        assert result == sorted(result)
    
    def test_large_even_number(self):
        result = get_odd_collatz(100)
        assert isinstance(result, list)
        assert all(num % 2 == 1 for num in result)
        assert result == sorted(result)
    
    def test_one_is_included(self):
        result = get_odd_collatz(5)
        assert 1 in result
    
    def test_starting_odd_is_included(self):
        result = get_odd_collatz(5)
        assert 5 in result
    
    def test_starting_even_not_included(self):
        result = get_odd_collatz(4)
        assert 4 not in result
    
    def test_no_duplicates(self):
        result = get_odd_collatz(10)
        assert len(result) == len(set(result))
    
    @pytest.mark.parametrize("n,expected_contains", [
        (1, [1]),
        (2, [1]),
        (3, [1, 3]),
        (4, [1]),
        (5, [1, 5]),
    ])
    def test_parametrized_basic(self, n, expected_contains):
        result = get_odd_collatz(n)
        for num in expected_contains:
            assert num in result