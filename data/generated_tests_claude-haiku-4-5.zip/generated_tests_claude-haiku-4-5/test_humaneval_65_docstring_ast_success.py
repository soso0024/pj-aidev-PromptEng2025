# Test cases for HumanEval/65
# Generated using Claude API


def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.
    >>> circular_shift(12, 1)
    "21"
    >>> circular_shift(12, 2)
    "12"
    """

    s = str(x)
    if shift > len(s):
        return s[::-1]
    else:
        return s[len(s) - shift:] + s[:len(s) - shift]


# Generated test cases:
import pytest


class TestCircularShift:
    
    def circular_shift(self, x, shift):
        s = str(x)
        if shift > len(s):
            return s[::-1]
        else:
            return s[len(s) - shift:] + s[:len(s) - shift]
    
    def test_basic_shift_right_by_one(self):
        assert self.circular_shift(12, 1) == "21"
    
    def test_basic_shift_right_by_two(self):
        assert self.circular_shift(12, 2) == "12"
    
    def test_shift_zero(self):
        assert self.circular_shift(12, 0) == "12"
    
    def test_shift_greater_than_length(self):
        assert self.circular_shift(12, 3) == "21"
    
    def test_shift_greater_than_length_three_digits(self):
        assert self.circular_shift(123, 5) == "321"
    
    def test_single_digit(self):
        assert self.circular_shift(5, 1) == "5"
    
    def test_single_digit_shift_greater(self):
        assert self.circular_shift(5, 2) == "5"
    
    def test_three_digit_shift_one(self):
        assert self.circular_shift(123, 1) == "312"
    
    def test_three_digit_shift_two(self):
        assert self.circular_shift(123, 2) == "231"
    
    def test_three_digit_shift_three(self):
        assert self.circular_shift(123, 3) == "123"
    
    def test_four_digit_shift_one(self):
        assert self.circular_shift(1234, 1) == "4123"
    
    def test_four_digit_shift_two(self):
        assert self.circular_shift(1234, 2) == "3412"
    
    def test_four_digit_shift_three(self):
        assert self.circular_shift(1234, 3) == "2341"
    
    def test_four_digit_shift_four(self):
        assert self.circular_shift(1234, 4) == "1234"
    
    def test_four_digit_shift_greater_than_length(self):
        assert self.circular_shift(1234, 5) == "4321"
    
    def test_number_with_zeros(self):
        assert self.circular_shift(102, 1) == "210"
    
    def test_number_with_zeros_shift_two(self):
        assert self.circular_shift(102, 2) == "021"
    
    def test_large_number(self):
        assert self.circular_shift(123456789, 1) == "912345678"
    
    def test_large_number_shift_multiple(self):
        assert self.circular_shift(123456789, 3) == "789123456"
    
    def test_large_number_shift_greater_than_length(self):
        assert self.circular_shift(123456789, 10) == "987654321"
    
    def test_zero(self):
        assert self.circular_shift(0, 1) == "0"
    
    def test_zero_shift_greater(self):
        assert self.circular_shift(0, 5) == "0"
    
    @pytest.mark.parametrize("x,shift,expected", [
        (12, 1, "21"),
        (12, 2, "12"),
        (123, 1, "312"),
        (123, 2, "231"),
        (1234, 1, "4123"),
        (100, 1, "010"),
        (999, 1, "999"),
        (10, 1, "01"),
        (10, 2, "10"),
        (10, 3, "01"),
    ])
    def test_parametrized_cases(self, x, shift, expected):
        assert self.circular_shift(x, shift) == expected
    
    def test_return_type_is_string(self):
        result = self.circular_shift(12, 1)
        assert isinstance(result, str)
    
    def test_return_type_is_string_with_shift_greater(self):
        result = self.circular_shift(12, 5)
        assert isinstance(result, str)
    
    def test_leading_zeros_preserved(self):
        result = self.circular_shift(102, 1)
        assert result == "210"
        assert len(result) == 3
    
    def test_all_same_digits(self):
        assert self.circular_shift(1111, 1) == "1111"
    
    def test_all_same_digits_shift_greater(self):
        assert self.circular_shift(1111, 5) == "1111"