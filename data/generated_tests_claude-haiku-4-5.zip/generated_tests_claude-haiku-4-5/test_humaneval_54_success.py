# Test cases for HumanEval/54
# Generated using Claude API



def same_chars(s0: str, s1: str):
    """
    Check if two words have the same characters.
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddeddabc')
    True
    >>> same_chars('abcd', 'dddddddabc')
    True
    >>> same_chars('dddddddabc', 'abcd')
    True
    >>> same_chars('eabcd', 'dddddddabc')
    False
    >>> same_chars('abcd', 'dddddddabce')
    False
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddddabc')
    False
    """

    return set(s0) == set(s1)


# Generated test cases:
import pytest


def same_chars(s0: str, s1: str):
    return set(s0) == set(s1)


class TestSameChars:
    def test_identical_strings(self):
        assert same_chars("abc", "abc") is True

    def test_same_chars_different_order(self):
        assert same_chars("abc", "bca") is True

    def test_same_chars_different_frequency(self):
        assert same_chars("aaa", "a") is True

    def test_different_chars(self):
        assert same_chars("abc", "def") is False

    def test_empty_strings(self):
        assert same_chars("", "") is True

    def test_one_empty_string(self):
        assert same_chars("", "abc") is False

    def test_other_empty_string(self):
        assert same_chars("abc", "") is False

    def test_single_char_same(self):
        assert same_chars("a", "a") is True

    def test_single_char_different(self):
        assert same_chars("a", "b") is False

    def test_repeated_chars_same(self):
        assert same_chars("aaaa", "aaaa") is True

    def test_repeated_chars_different_count(self):
        assert same_chars("aaaa", "aa") is True

    def test_case_sensitive(self):
        assert same_chars("Abc", "abc") is False

    def test_case_sensitive_same_case(self):
        assert same_chars("ABC", "ABC") is True

    def test_special_characters(self):
        assert same_chars("!@#", "#@!") is True

    def test_special_characters_different(self):
        assert same_chars("!@#", "!@$") is False

    def test_numbers_as_strings(self):
        assert same_chars("123", "321") is True

    def test_numbers_different(self):
        assert same_chars("123", "456") is False

    def test_mixed_alphanumeric(self):
        assert same_chars("a1b2", "2b1a") is True

    def test_spaces_included(self):
        assert same_chars("a b c", "c b a") is True

    def test_spaces_different(self):
        assert same_chars("abc", "a b c") is False

    def test_long_strings_same(self):
        assert same_chars("abcdefghijklmnopqrstuvwxyz", "zyxwvutsrqponmlkjihgfedcba") is True

    def test_long_strings_different(self):
        assert same_chars("abcdefghijklmnopqrstuvwxyz", "abcdefghijklmnopqrstuvwxy") is False

    def test_unicode_characters(self):
        assert same_chars("café", "éfac") is True

    def test_unicode_different(self):
        assert same_chars("café", "cafe") is False

    def test_newline_characters(self):
        assert same_chars("a\nb", "b\na") is True

    def test_tab_characters(self):
        assert same_chars("a\tb", "b\ta") is True

    def test_whitespace_different(self):
        assert same_chars("a b", "a\tb") is False


@pytest.mark.parametrize("s0,s1,expected", [
    ("abc", "abc", True),
    ("abc", "bca", True),
    ("aaa", "a", True),
    ("abc", "def", False),
    ("", "", True),
    ("", "abc", False),
    ("abc", "", False),
    ("a", "a", True),
    ("a", "b", False),
    ("hello", "olleh", True),
    ("hello", "world", False),
    ("123", "321", True),
    ("!@#$", "$#@!", True),
    ("AaBbCc", "abcABC", True),
    ("test", "testing", False),
])
def test_same_chars_parametrized(s0, s1, expected):
    assert same_chars(s0, s1) is expected
