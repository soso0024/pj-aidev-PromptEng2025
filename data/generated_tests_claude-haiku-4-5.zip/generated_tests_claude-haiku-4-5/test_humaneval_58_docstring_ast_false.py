# Test cases for HumanEval/58
# Generated using Claude API



def common(l1: list, l2: list):
    """Return sorted unique common elements for two lists.
    >>> common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121])
    [1, 5, 653]
    >>> common([5, 3, 2, 8], [3, 2])
    [2, 3]

    """

    ret = set()
    for e1 in l1:
        for e2 in l2:
            if e1 == e2:
                ret.add(e1)
    return sorted(list(ret))


# Generated test cases:
import pytest


def common(l1: list, l2: list):
    ret = set()
    for e1 in l1:
        for e2 in l2:
            if e1 == e2:
                ret.add(e1)
    return sorted(list(ret))


class TestCommon:
    def test_example_1(self):
        result = common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121])
        assert result == [1, 5, 653]

    def test_example_2(self):
        result = common([5, 3, 2, 8], [3, 2])
        assert result == [2, 3]

    def test_empty_first_list(self):
        result = common([], [1, 2, 3])
        assert result == []

    def test_empty_second_list(self):
        result = common([1, 2, 3], [])
        assert result == []

    def test_both_empty_lists(self):
        result = common([], [])
        assert result == []

    def test_no_common_elements(self):
        result = common([1, 2, 3], [4, 5, 6])
        assert result == []

    def test_all_common_elements(self):
        result = common([1, 2, 3], [1, 2, 3])
        assert result == [1, 2, 3]

    def test_single_element_common(self):
        result = common([5], [5])
        assert result == [5]

    def test_single_element_no_common(self):
        result = common([5], [3])
        assert result == []

    def test_duplicates_in_first_list(self):
        result = common([1, 1, 1, 2], [1, 2, 3])
        assert result == [1, 2]

    def test_duplicates_in_second_list(self):
        result = common([1, 2, 3], [1, 1, 1, 2])
        assert result == [1, 2]

    def test_duplicates_in_both_lists(self):
        result = common([1, 1, 2, 2], [1, 1, 2, 2])
        assert result == [1, 2]

    def test_negative_numbers(self):
        result = common([-1, -2, 3], [-1, 4, -2])
        assert result == [-2, -1]

    def test_mixed_positive_negative(self):
        result = common([-5, 0, 5], [-5, 0, 5, 10])
        assert result == [-5, 0, 5]

    def test_zero_in_common(self):
        result = common([0, 1, 2], [0, 3, 4])
        assert result == [0]

    def test_large_numbers(self):
        result = common([1000000, 2000000], [2000000, 3000000])
        assert result == [2000000]

    def test_strings_in_list(self):
        result = common(['a', 'b', 'c'], ['b', 'c', 'd'])
        assert result == ['b', 'c']

    def test_mixed_types(self):
        result = common([1, '1', 2], ['1', 2, 3])
        assert result == ['1', 2]

    def test_floats(self):
        result = common([1.5, 2.5, 3.5], [2.5, 3.5, 4.5])
        assert result == [2.5, 3.5]

    def test_result_is_sorted(self):
        result = common([5, 1, 3], [3, 5, 1])
        assert result == [1, 3, 5]
        assert result == sorted(result)

    def test_unsorted_input_lists(self):
        result = common([9, 2, 7, 1], [7, 3, 9, 5])
        assert result == [7, 9]

    def test_single_element_lists(self):
        result = common([42], [42])
        assert result == [42]

    def test_long_lists(self):
        l1 = list(range(100))
        l2 = list(range(50, 150))
        result = common(l1, l2)
        assert result == list(range(50, 100))

    def test_boolean_values(self):
        result = common([True, False, 1], [True, 0])
        assert True in result or 1 in result

    def test_none_values(self):
        result = common([None, 1, 2], [None, 3])
        assert result == [None]

    def test_repeated_common_elements(self):
        result = common([1, 1, 1, 1], [1, 1, 1])
        assert result == [1]

    def test_order_independence(self):
        result1 = common([1, 2, 3], [3, 2, 1])
        result2 = common([3, 2, 1], [1, 2, 3])
        assert result1 == result2 == [1, 2, 3]