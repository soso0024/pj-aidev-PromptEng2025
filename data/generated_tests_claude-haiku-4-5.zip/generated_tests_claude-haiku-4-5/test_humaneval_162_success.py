# Test cases for HumanEval/162
# Generated using Claude API


def string_to_md5(text):
    """
    Given a string 'text', return its md5 hash equivalent string.
    If 'text' is an empty string, return None.

    >>> string_to_md5('Hello world') == '3e25960a79dbc69b674cd4ec67a72c62'
    """

    import hashlib
    return hashlib.md5(text.encode('ascii')).hexdigest() if text else None


# Generated test cases:
import pytest
import hashlib


def string_to_md5(text):
    return hashlib.md5(text.encode('ascii')).hexdigest() if text else None


class TestStringToMd5:
    
    def test_empty_string_returns_none(self):
        assert string_to_md5("") is None
    
    def test_none_input_returns_none(self):
        assert string_to_md5(None) is None
    
    def test_single_character(self):
        result = string_to_md5("a")
        expected = hashlib.md5("a".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_simple_word(self):
        result = string_to_md5("hello")
        expected = hashlib.md5("hello".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_sentence_with_spaces(self):
        result = string_to_md5("hello world")
        expected = hashlib.md5("hello world".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_numbers_as_string(self):
        result = string_to_md5("12345")
        expected = hashlib.md5("12345".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_special_characters(self):
        result = string_to_md5("!@#$%^&*()")
        expected = hashlib.md5("!@#$%^&*()".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_mixed_case(self):
        result = string_to_md5("HeLLo WoRLd")
        expected = hashlib.md5("HeLLo WoRLd".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_long_string(self):
        long_text = "a" * 1000
        result = string_to_md5(long_text)
        expected = hashlib.md5(long_text.encode('ascii')).hexdigest()
        assert result == expected
    
    def test_md5_format_is_hexdigest(self):
        result = string_to_md5("test")
        assert isinstance(result, str)
        assert len(result) == 32
        assert all(c in "0123456789abcdef" for c in result)
    
    def test_whitespace_only_string(self):
        result = string_to_md5("   ")
        expected = hashlib.md5("   ".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_newline_character(self):
        result = string_to_md5("hello\nworld")
        expected = hashlib.md5("hello\nworld".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_tab_character(self):
        result = string_to_md5("hello\tworld")
        expected = hashlib.md5("hello\tworld".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_same_input_produces_same_output(self):
        text = "consistent"
        result1 = string_to_md5(text)
        result2 = string_to_md5(text)
        assert result1 == result2
    
    def test_different_inputs_produce_different_outputs(self):
        result1 = string_to_md5("test1")
        result2 = string_to_md5("test2")
        assert result1 != result2
    
    @pytest.mark.parametrize("input_text,expected_not_none", [
        ("a", True),
        ("test", True),
        ("123", True),
        ("", False),
    ])
    def test_parametrized_none_check(self, input_text, expected_not_none):
        result = string_to_md5(input_text)
        if expected_not_none:
            assert result is not None
        else:
            assert result is None
    
    @pytest.mark.parametrize("input_text", [
        "hello",
        "world",
        "test123",
        "!@#$",
        "   ",
    ])
    def test_parametrized_valid_md5_format(self, input_text):
        result = string_to_md5(input_text)
        assert isinstance(result, str)
        assert len(result) == 32
        assert all(c in "0123456789abcdef" for c in result)
    
    def test_ascii_printable_characters(self):
        ascii_chars = "".join(chr(i) for i in range(32, 127))
        result = string_to_md5(ascii_chars)
        expected = hashlib.md5(ascii_chars.encode('ascii')).hexdigest()
        assert result == expected
    
    def test_zero_string(self):
        result = string_to_md5("0")
        expected = hashlib.md5("0".encode('ascii')).hexdigest()
        assert result == expected
