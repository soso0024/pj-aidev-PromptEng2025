# Test cases for HumanEval/152
# Generated using Claude API


def compare(game,guess):
    """I think we all remember that feeling when the result of some long-awaited
    event is finally known. The feelings and thoughts you have at that moment are
    definitely worth noting down and comparing.
    Your task is to determine if a person correctly guessed the results of a number of matches.
    You are given two arrays of scores and guesses of equal length, where each index shows a match. 
    Return an array of the same length denoting how far off each guess was. If they have guessed correctly,
    the value is 0, and if not, the value is the absolute difference between the guess and the score.
    
    
    example:

    compare([1,2,3,4,5,1],[1,2,3,4,2,-2]) -> [0,0,0,0,3,3]
    compare([0,5,0,0,0,4],[4,1,1,0,0,-2]) -> [4,4,1,0,0,6]
    """

    return [abs(x-y) for x,y in zip(game,guess)]


# Generated test cases:
import pytest


def compare(game, guess):
    return [abs(x - y) for x, y in zip(game, guess)]


class TestCompare:
    def test_identical_sequences(self):
        assert compare([1, 2, 3], [1, 2, 3]) == [0, 0, 0]

    def test_completely_different_sequences(self):
        assert compare([1, 2, 3], [4, 5, 6]) == [3, 3, 3]

    def test_single_element(self):
        assert compare([5], [2]) == [3]

    def test_empty_sequences(self):
        assert compare([], []) == []

    def test_negative_numbers(self):
        assert compare([-1, -2, -3], [-4, -5, -6]) == [3, 3, 3]

    def test_mixed_positive_negative(self):
        assert compare([1, -2, 3], [-1, 2, -3]) == [2, 4, 6]

    def test_zero_differences(self):
        assert compare([0, 0, 0], [0, 0, 0]) == [0, 0, 0]

    def test_large_numbers(self):
        assert compare([1000, 2000], [500, 1500]) == [500, 500]

    def test_floats(self):
        result = compare([1.5, 2.5], [1.0, 3.0])
        assert result == [0.5, 0.5]

    def test_two_elements(self):
        assert compare([10, 20], [5, 15]) == [5, 5]

    def test_longer_sequence(self):
        assert compare([1, 2, 3, 4, 5], [2, 3, 4, 5, 6]) == [1, 1, 1, 1, 1]

    def test_all_zeros(self):
        assert compare([0, 0, 0], [0, 0, 0]) == [0, 0, 0]

    def test_negative_to_positive(self):
        assert compare([-5], [5]) == [10]

    def test_positive_to_negative(self):
        assert compare([5], [-5]) == [10]

    @pytest.mark.parametrize("game,guess,expected", [
        ([1, 2, 3], [1, 2, 3], [0, 0, 0]),
        ([0], [0], [0]),
        ([1], [2], [1]),
        ([10, 20, 30], [5, 15, 25], [5, 5, 5]),
        ([-1, -2], [-3, -4], [2, 2]),
        ([100], [50], [50]),
    ])
    def test_parametrized_cases(self, game, guess, expected):
        assert compare(game, guess) == expected

    def test_return_type_is_list(self):
        result = compare([1, 2], [1, 2])
        assert isinstance(result, list)

    def test_result_length_matches_input_length(self):
        game = [1, 2, 3, 4]
        guess = [5, 6, 7, 8]
        result = compare(game, guess)
        assert len(result) == len(game)

    def test_all_results_non_negative(self):
        result = compare([1, 2, 3], [10, 20, 30])
        assert all(x >= 0 for x in result)

    def test_fractional_differences(self):
        result = compare([1.1, 2.2], [1.0, 2.0])
        assert len(result) == 2
        assert abs(result[0] - 0.1) < 1e-9
        assert abs(result[1] - 0.2) < 1e-9

    def test_very_large_difference(self):
        assert compare([0], [1000000]) == [1000000]

    def test_single_zero_difference(self):
        assert compare([5, 10, 15], [5, 10, 15]) == [0, 0, 0]
