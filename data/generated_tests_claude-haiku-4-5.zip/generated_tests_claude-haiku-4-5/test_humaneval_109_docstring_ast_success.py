# Test cases for HumanEval/109
# Generated using Claude API


def move_one_ball(arr):
    """We have an array 'arr' of N integers arr[1], arr[2], ..., arr[N].The
    numbers in the array will be randomly ordered. Your task is to determine if
    it is possible to get an array sorted in non-decreasing order by performing 
    the following operation on the given array:
        You are allowed to perform right shift operation any number of times.
    
    One right shift operation means shifting all elements of the array by one
    position in the right direction. The last element of the array will be moved to
    the starting position in the array i.e. 0th index. 

    If it is possible to obtain the sorted array by performing the above operation
    then return True else return False.
    If the given array is empty then return True.

    Note: The given list is guaranteed to have unique elements.

    For Example:
    
    move_one_ball([3, 4, 5, 1, 2])==>True
    Explanation: By performin 2 right shift operations, non-decreasing order can
                 be achieved for the given array.
    move_one_ball([3, 5, 4, 1, 2])==>False
    Explanation:It is not possible to get non-decreasing order for the given
                array by performing any number of right shift operations.
                
    """

    if len(arr)==0:
      return True
    sorted_array=sorted(arr)
    my_arr=[]
    
    min_value=min(arr)
    min_index=arr.index(min_value)
    my_arr=arr[min_index:]+arr[0:min_index]
    for i in range(len(arr)):
      if my_arr[i]!=sorted_array[i]:
        return False
    return True


# Generated test cases:
import pytest


class TestMoveOneBall:
    
    def move_one_ball(self, arr):
        if len(arr)==0:
            return True
        sorted_array=sorted(arr)
        my_arr=[]
        
        min_value=min(arr)
        min_index=arr.index(min_value)
        my_arr=arr[min_index:]+arr[0:min_index]
        for i in range(len(arr)):
            if my_arr[i]!=sorted_array[i]:
                return False
        return True
    
    def test_empty_array(self):
        assert self.move_one_ball([]) == True
    
    def test_single_element(self):
        assert self.move_one_ball([1]) == True
    
    def test_already_sorted(self):
        assert self.move_one_ball([1, 2, 3, 4, 5]) == True
    
    def test_one_right_shift_needed(self):
        assert self.move_one_ball([5, 1, 2, 3, 4]) == True
    
    def test_two_right_shifts_needed(self):
        assert self.move_one_ball([3, 4, 5, 1, 2]) == True
    
    def test_multiple_right_shifts_needed(self):
        assert self.move_one_ball([4, 5, 1, 2, 3]) == True
    
    def test_not_sortable_by_rotation(self):
        assert self.move_one_ball([3, 5, 4, 1, 2]) == False
    
    def test_not_sortable_simple(self):
        assert self.move_one_ball([2, 1]) == True
    
    def test_two_elements_sorted(self):
        assert self.move_one_ball([1, 2]) == True
    
    def test_two_elements_need_rotation(self):
        assert self.move_one_ball([2, 1]) == True
    
    def test_three_elements_sorted(self):
        assert self.move_one_ball([1, 2, 3]) == True
    
    def test_three_elements_rotated_once(self):
        assert self.move_one_ball([3, 1, 2]) == True
    
    def test_three_elements_rotated_twice(self):
        assert self.move_one_ball([2, 3, 1]) == True
    
    def test_three_elements_not_sortable(self):
        assert self.move_one_ball([2, 1, 3]) == False
    
    def test_large_array_sorted(self):
        assert self.move_one_ball([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == True
    
    def test_large_array_rotated(self):
        assert self.move_one_ball([8, 9, 10, 1, 2, 3, 4, 5, 6, 7]) == True
    
    def test_large_array_not_sortable(self):
        assert self.move_one_ball([1, 3, 2, 4, 5, 6, 7, 8, 9, 10]) == False
    
    def test_negative_numbers_sorted(self):
        assert self.move_one_ball([-5, -3, -1, 0, 2]) == True
    
    def test_negative_numbers_rotated(self):
        assert self.move_one_ball([0, 2, -5, -3, -1]) == True
    
    def test_negative_numbers_not_sortable(self):
        assert self.move_one_ball([-1, -5, -3, 0, 2]) == False
    
    def test_mixed_positive_negative_sorted(self):
        assert self.move_one_ball([-10, -5, 0, 5, 10]) == True
    
    def test_mixed_positive_negative_rotated(self):
        assert self.move_one_ball([5, 10, -10, -5, 0]) == True
    
    def test_all_same_would_fail_but_unique_guaranteed(self):
        assert self.move_one_ball([5, 1, 2, 3, 4]) == True
    
    def test_descending_order_not_sortable(self):
        assert self.move_one_ball([5, 4, 3, 2, 1]) == False
    
    def test_min_at_start(self):
        assert self.move_one_ball([1, 2, 3, 4, 5]) == True
    
    def test_min_at_end(self):
        assert self.move_one_ball([2, 3, 4, 5, 1]) == True
    
    def test_min_in_middle_rotatable(self):
        assert self.move_one_ball([4, 5, 1, 2, 3]) == True
    
    def test_min_in_middle_not_rotatable(self):
        assert self.move_one_ball([3, 1, 2, 4, 5]) == False
    
    @pytest.mark.parametrize("arr,expected", [
        ([3, 4, 5, 1, 2], True),
        ([3, 5, 4, 1, 2], False),
        ([1, 2, 3], True),
        ([3, 1, 2], True),
        ([2, 1, 3], False),
        ([], True),
        ([1], True),
        ([5, 1, 2, 3, 4], True),
        ([1, 2, 3, 4, 5], True),
        ([5, 4, 3, 2, 1], False),
    ])
    def test_parametrized_cases(self, arr, expected):
        assert self.move_one_ball(arr) == expected