# Test cases for HumanEval/41
# Generated using Claude API



def car_race_collision(n: int):
    """
    Imagine a road that's a perfectly straight infinitely long line.
    n cars are driving left to right;  simultaneously, a different set of n cars
    are driving right to left.   The two sets of cars start out being very far from
    each other.  All cars move in the same speed.  Two cars are said to collide
    when a car that's moving left to right hits a car that's moving right to left.
    However, the cars are infinitely sturdy and strong; as a result, they continue moving
    in their trajectory as if they did not collide.

    This function outputs the number of such collisions.
    """

    return n**2


# Generated test cases:
import pytest


def car_race_collision(n: int):
    return n**2


class TestCarRaceCollision:
    
    def test_zero_cars(self):
        assert car_race_collision(0) == 0
    
    def test_one_car(self):
        assert car_race_collision(1) == 1
    
    def test_two_cars(self):
        assert car_race_collision(2) == 4
    
    def test_three_cars(self):
        assert car_race_collision(3) == 9
    
    def test_five_cars(self):
        assert car_race_collision(5) == 25
    
    def test_ten_cars(self):
        assert car_race_collision(10) == 100
    
    def test_large_number(self):
        assert car_race_collision(100) == 10000
    
    def test_very_large_number(self):
        assert car_race_collision(1000) == 1000000
    
    @pytest.mark.parametrize("n,expected", [
        (0, 0),
        (1, 1),
        (2, 4),
        (3, 9),
        (4, 16),
        (5, 25),
        (6, 36),
        (7, 49),
        (8, 64),
        (9, 81),
        (10, 100),
        (15, 225),
        (20, 400),
        (50, 2500),
        (100, 10000),
    ])
    def test_parametrized_values(self, n, expected):
        assert car_race_collision(n) == expected
    
    def test_return_type_is_int(self):
        result = car_race_collision(5)
        assert isinstance(result, int)
    
    def test_return_type_for_zero(self):
        result = car_race_collision(0)
        assert isinstance(result, int)
    
    def test_result_is_non_negative(self):
        for n in range(0, 20):
            assert car_race_collision(n) >= 0
    
    def test_result_increases_with_n(self):
        for n in range(1, 10):
            assert car_race_collision(n) > car_race_collision(n - 1)
    
    def test_mathematical_property_n_squared(self):
        for n in range(0, 50):
            assert car_race_collision(n) == n * n
