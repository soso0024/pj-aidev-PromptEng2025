# Test cases for HumanEval/143
# Generated using Claude API


def words_in_sentence(sentence):
    """
    You are given a string representing a sentence,
    the sentence contains some words separated by a space,
    and you have to return a string that contains the words from the original sentence,
    whose lengths are prime numbers,
    the order of the words in the new string should be the same as the original one.

    Example 1:
        Input: sentence = "This is a test"
        Output: "is"

    Example 2:
        Input: sentence = "lets go for swimming"
        Output: "go for"

    Constraints:
        * 1 <= len(sentence) <= 100
        * sentence contains only letters
    """

    new_lst = []
    for word in sentence.split():
        flg = 0
        if len(word) == 1:
            flg = 1
        for i in range(2, len(word)):
            if len(word)%i == 0:
                flg = 1
        if flg == 0 or len(word) == 2:
            new_lst.append(word)
    return " ".join(new_lst)


# Generated test cases:
import pytest


class TestWordsInSentence:
    
    @pytest.mark.parametrize("sentence,expected", [
        ("This is a test", "is"),
        ("lets go for swimming", "go for"),
        ("a", ""),
        ("ab", "ab"),
        ("abc", "abc"),
        ("abcd", ""),
        ("abcde", "abcde"),
        ("abcdef", ""),
        ("I am learning Python", "am"),
        ("hello world", "hello world"),
        ("hi", "hi"),
        ("bye", "bye"),
        ("code", ""),
        ("python", ""),
        ("test", ""),
        ("a b c d e", ""),
        ("ab cd ef gh", "ab cd ef gh"),
        ("programming", "programming"),
        ("is it ok", "is it ok"),
        ("the quick brown fox", "the quick brown fox"),
    ])
    def test_words_in_sentence_basic(self, sentence, expected):
        from test_humaneval_143_docstring_ast import words_in_sentence
        assert words_in_sentence(sentence) == expected
    
    def test_single_word_length_one(self):
        assert words_in_sentence("a") == ""
    
    def test_single_word_length_two(self):
        assert words_in_sentence("ab") == "ab"
    
    def test_single_word_length_three(self):
        assert words_in_sentence("abc") == "abc"
    
    def test_single_word_length_four(self):
        assert words_in_sentence("abcd") == ""
    
    def test_single_word_length_five(self):
        assert words_in_sentence("abcde") == "abcde"
    
    def test_single_word_length_six(self):
        assert words_in_sentence("abcdef") == ""
    
    def test_single_word_length_seven(self):
        assert words_in_sentence("abcdefg") == "abcdefg"
    
    def test_multiple_prime_length_words(self):
        assert words_in_sentence("ab cd ef") == "ab cd ef"
    
    def test_multiple_composite_length_words(self):
        assert words_in_sentence("abcd efgh ijkl") == ""
    
    def test_mixed_prime_and_composite(self):
        assert words_in_sentence("ab abcd abc abcde") == "ab abc abcde"
    
    def test_example_one(self):
        assert words_in_sentence("This is a test") == "is"
    
    def test_example_two(self):
        assert words_in_sentence("lets go for swimming") == "go for"
    
    def test_all_single_letters(self):
        assert words_in_sentence("a b c d e") == ""
    
    def test_all_two_letter_words(self):
        assert words_in_sentence("ab cd ef gh ij") == "ab cd ef gh ij"
    
    def test_prime_lengths_only(self):
        result = words_in_sentence("ab abc abcde abcdefg")
        assert result == "ab abc abcde abcdefg"
    
    def test_composite_lengths_only(self):
        result = words_in_sentence("abcd abcdef abcdefgh")
        assert result == ""
    
    def test_alternating_prime_composite(self):
        result = words_in_sentence("ab abcd abc abcdef abcde")
        assert result == "ab abc abcde"
    
    def test_long_sentence(self):
        result = words_in_sentence("a ab abc abcd abcde abcdef abcdefg abcdefgh abcdefghi")
        assert result == "ab abc abcde abcdefg"
    
    def test_words_with_uppercase(self):
        result = words_in_sentence("Hello World Python")
        assert result == "Hello World"
    
    def test_words_with_mixed_case(self):
        result = words_in_sentence("ThIs Is A TeSt")
        assert result == "Is"
    
    def test_sentence_with_repeated_words(self):
        result = words_in_sentence("ab ab ab cd cd cd")
        assert result == "ab ab ab cd cd cd"
    
    def test_sentence_with_one_prime_word(self):
        result = words_in_sentence("abcd abcde abcdef")
        assert result == "abcde"
    
    def test_sentence_with_no_prime_words(self):
        result = words_in_sentence("abcd abcdef abcdefgh")
        assert result == ""
    
    def test_length_eleven_prime(self):
        result = words_in_sentence("abcdefghijk")
        assert result == "abcdefghijk"
    
    def test_length_thirteen_prime(self):
        result = words_in_sentence("abcdefghijklm")
        assert result == "abcdefghijklm"
    
    def test_length_nine_composite(self):
        result = words_in_sentence("abcdefghi")
        assert result == ""
    
    def test_length_ten_composite(self):
        result = words_in_sentence("abcdefghij")
        assert result == ""
    
    def test_length_twelve_composite(self):
        result = words_in_sentence("abcdefghijkl")
        assert result == ""