# Test cases for HumanEval/148
# Generated using Claude API


def bf(planet1, planet2):
    '''
    There are eight planets in our solar system: the closerst to the Sun 
    is Mercury, the next one is Venus, then Earth, Mars, Jupiter, Saturn, 
    Uranus, Neptune.
    Write a function that takes two planet names as strings planet1 and planet2. 
    The function should return a tuple containing all planets whose orbits are 
    located between the orbit of planet1 and the orbit of planet2, sorted by 
    the proximity to the sun. 
    The function should return an empty tuple if planet1 or planet2
    are not correct planet names. 
    Examples
    bf("Jupiter", "Neptune") ==> ("Saturn", "Uranus")
    bf("Earth", "Mercury") ==> ("Venus")
    bf("Mercury", "Uranus") ==> ("Venus", "Earth", "Mars", "Jupiter", "Saturn")
    '''

    planet_names = ("Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune")
    if planet1 not in planet_names or planet2 not in planet_names or planet1 == planet2:
        return ()
    planet1_index = planet_names.index(planet1)
    planet2_index = planet_names.index(planet2)
    if planet1_index < planet2_index:
        return (planet_names[planet1_index + 1: planet2_index])
    else:
        return (planet_names[planet2_index + 1 : planet1_index])


# Generated test cases:
import pytest


def bf(planet1, planet2):
    planet_names = ("Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune")
    if planet1 not in planet_names or planet2 not in planet_names or planet1 == planet2:
        return ()
    planet1_index = planet_names.index(planet1)
    planet2_index = planet_names.index(planet2)
    if planet1_index < planet2_index:
        return planet_names[planet1_index + 1: planet2_index]
    else:
        return planet_names[planet2_index + 1 : planet1_index]


class TestBf:
    
    def test_adjacent_planets_ascending(self):
        assert bf("Mercury", "Venus") == ()
    
    def test_adjacent_planets_descending(self):
        assert bf("Venus", "Mercury") == ()
    
    def test_two_planets_between_ascending(self):
        assert bf("Mercury", "Earth") == ("Venus",)
    
    def test_two_planets_between_descending(self):
        assert bf("Earth", "Mercury") == ("Venus",)
    
    def test_multiple_planets_between_ascending(self):
        assert bf("Mercury", "Mars") == ("Venus", "Earth")
    
    def test_multiple_planets_between_descending(self):
        assert bf("Mars", "Mercury") == ("Venus", "Earth")
    
    def test_many_planets_between_ascending(self):
        assert bf("Mercury", "Jupiter") == ("Venus", "Earth", "Mars")
    
    def test_many_planets_between_descending(self):
        assert bf("Jupiter", "Mercury") == ("Venus", "Earth", "Mars")
    
    def test_earth_to_saturn_ascending(self):
        assert bf("Earth", "Saturn") == ("Mars", "Jupiter")
    
    def test_saturn_to_earth_descending(self):
        assert bf("Saturn", "Earth") == ("Mars", "Jupiter")
    
    def test_uranus_to_neptune_adjacent(self):
        assert bf("Uranus", "Neptune") == ()
    
    def test_neptune_to_uranus_adjacent(self):
        assert bf("Neptune", "Uranus") == ()
    
    def test_mercury_to_neptune_all_planets(self):
        assert bf("Mercury", "Neptune") == ("Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus")
    
    def test_neptune_to_mercury_all_planets(self):
        assert bf("Neptune", "Mercury") == ("Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus")
    
    def test_same_planet_returns_empty(self):
        assert bf("Earth", "Earth") == ()
    
    def test_same_planet_mercury(self):
        assert bf("Mercury", "Mercury") == ()
    
    def test_same_planet_neptune(self):
        assert bf("Neptune", "Neptune") == ()
    
    def test_invalid_planet1(self):
        assert bf("Pluto", "Earth") == ()
    
    def test_invalid_planet2(self):
        assert bf("Earth", "Pluto") == ()
    
    def test_both_invalid_planets(self):
        assert bf("Pluto", "Xena") == ()
    
    def test_invalid_planet_lowercase(self):
        assert bf("earth", "Mars") == ()
    
    def test_invalid_planet_uppercase(self):
        assert bf("EARTH", "Mars") == ()
    
    def test_invalid_planet_misspelled(self):
        assert bf("Earh", "Mars") == ()
    
    def test_empty_string_planet1(self):
        assert bf("", "Earth") == ()
    
    def test_empty_string_planet2(self):
        assert bf("Earth", "") == ()
    
    def test_venus_to_mars(self):
        assert bf("Venus", "Mars") == ("Earth",)
    
    def test_mars_to_venus(self):
        assert bf("Mars", "Venus") == ("Earth",)
    
    def test_jupiter_to_neptune(self):
        assert bf("Jupiter", "Neptune") == ("Saturn", "Uranus")
    
    def test_neptune_to_jupiter(self):
        assert bf("Neptune", "Jupiter") == ("Saturn", "Uranus")
    
    def test_saturn_to_neptune(self):
        assert bf("Saturn", "Neptune") == ("Uranus",)
    
    def test_neptune_to_saturn(self):
        assert bf("Neptune", "Saturn") == ("Uranus",)
    
    @pytest.mark.parametrize("planet1,planet2,expected", [
        ("Mercury", "Venus", ()),
        ("Mercury", "Earth", ("Venus",)),
        ("Mercury", "Mars", ("Venus", "Earth")),
        ("Venus", "Mercury", ()),
        ("Earth", "Mercury", ("Venus",)),
        ("Mars", "Mercury", ("Venus", "Earth")),
    ])
    def test_parametrized_cases(self, planet1, planet2, expected):
        assert bf(planet1, planet2) == expected