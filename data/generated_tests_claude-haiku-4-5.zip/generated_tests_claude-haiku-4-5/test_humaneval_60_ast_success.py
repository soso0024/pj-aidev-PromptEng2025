# Test cases for HumanEval/60
# Generated using Claude API



def sum_to_n(n: int):
    """sum_to_n is a function that sums numbers from 1 to n.
    >>> sum_to_n(30)
    465
    >>> sum_to_n(100)
    5050
    >>> sum_to_n(5)
    15
    >>> sum_to_n(10)
    55
    >>> sum_to_n(1)
    1
    """

    return sum(range(n + 1))


# Generated test cases:
import pytest


def sum_to_n(n: int):
    return sum(range(n + 1))


class TestSumToN:
    def test_sum_to_zero(self):
        assert sum_to_n(0) == 0

    def test_sum_to_one(self):
        assert sum_to_n(1) == 1

    def test_sum_to_five(self):
        assert sum_to_n(5) == 15

    def test_sum_to_ten(self):
        assert sum_to_n(10) == 55

    def test_sum_to_hundred(self):
        assert sum_to_n(100) == 5050

    def test_sum_to_negative_one(self):
        assert sum_to_n(-1) == 0

    def test_sum_to_negative_five(self):
        assert sum_to_n(-5) == 0

    def test_sum_to_large_number(self):
        assert sum_to_n(1000) == 500500

    def test_sum_to_very_large_number(self):
        assert sum_to_n(10000) == 50005000

    @pytest.mark.parametrize("n,expected", [
        (0, 0),
        (1, 1),
        (2, 3),
        (3, 6),
        (4, 10),
        (5, 15),
        (6, 21),
        (7, 28),
        (8, 36),
        (9, 45),
        (10, 55),
    ])
    def test_sum_to_n_parametrized(self, n, expected):
        assert sum_to_n(n) == expected

    def test_sum_to_n_formula_verification(self):
        for n in range(20):
            expected = n * (n + 1) // 2
            assert sum_to_n(n) == expected

    def test_sum_to_n_returns_int(self):
        result = sum_to_n(5)
        assert isinstance(result, int)

    def test_sum_to_n_incremental(self):
        assert sum_to_n(0) == 0
        assert sum_to_n(1) == sum_to_n(0) + 1
        assert sum_to_n(2) == sum_to_n(1) + 2
        assert sum_to_n(3) == sum_to_n(2) + 3

    def test_sum_to_n_negative_input(self):
        assert sum_to_n(-10) == 0

    def test_sum_to_n_two(self):
        assert sum_to_n(2) == 3

    def test_sum_to_n_three(self):
        assert sum_to_n(3) == 6

    def test_sum_to_n_four(self):
        assert sum_to_n(4) == 10
