# Test cases for HumanEval/140
# Generated using Claude API


def fix_spaces(text):
    """
    Given a string text, replace all spaces in it with underscores, 
    and if a string has more than 2 consecutive spaces, 
    then replace all consecutive spaces with - 
    
    fix_spaces("Example") == "Example"
    fix_spaces("Example 1") == "Example_1"
    fix_spaces(" Example 2") == "_Example_2"
    fix_spaces(" Example   3") == "_Example-3"
    """

    new_text = ""
    i = 0
    start, end = 0, 0
    while i < len(text):
        if text[i] == " ":
            end += 1
        else:
            if end - start > 2:
                new_text += "-"+text[i]
            elif end - start > 0:
                new_text += "_"*(end - start)+text[i]
            else:
                new_text += text[i]
            start, end = i+1, i+1
        i+=1
    if end - start > 2:
        new_text += "-"
    elif end - start > 0:
        new_text += "_"
    return new_text


# Generated test cases:
import pytest


def fix_spaces(text):
    new_text = ""
    i = 0
    start, end = 0, 0
    while i < len(text):
        if text[i] == " ":
            end += 1
        else:
            if end - start > 2:
                new_text += "-"+text[i]
            elif end - start > 0:
                new_text += "_"*(end - start)+text[i]
            else:
                new_text += text[i]
            start, end = i+1, i+1
        i+=1
    if end - start > 2:
        new_text += "-"
    elif end - start > 0:
        new_text += "_"*(end - start)
    return new_text


@pytest.mark.parametrize("input_text,expected", [
    ("Example", "Example"),
    ("Example 1", "Example_1"),
    (" Example 2", "_Example_2"),
    (" Example   3", "_Example-3"),
    ("", ""),
    (" ", "_"),
    ("  ", "__"),
    ("   ", "-"),
    ("    ", "-"),
    ("a b c", "a_b_c"),
    ("a  b  c", "a__b__c"),
    ("a   b   c", "a-b-c"),
    ("  a  b  ", "__a__b__"),
    ("hello world", "hello_world"),
    ("hello  world", "hello__world"),
    ("hello   world", "hello-world"),
    ("hello    world", "hello-world"),
    ("a", "a"),
    (" a", "_a"),
    ("  a", "__a"),
    ("   a", "-a"),
    ("a ", "a_"),
    ("a  ", "a__"),
    ("a   ", "a-"),
    ("a    ", "a-"),
    ("  ", "__"),
    ("   ", "-"),
    ("    ", "-"),
    ("     ", "-"),
    ("a b c d e", "a_b_c_d_e"),
    ("a  b  c  d", "a__b__c__d"),
    ("a   b   c   d", "a-b-c-d"),
    ("multiple   spaces   here", "multiple-spaces-here"),
    ("one  two  three  four", "one__two__three__four"),
    ("start ", "start_"),
    ("start  ", "start__"),
    ("start   ", "start-"),
    (" end", "_end"),
    ("  end", "__end"),
    ("   end", "-end"),
    ("  middle  ", "__middle__"),
    ("   middle   ", "-middle-"),
    ("a b  c   d    e", "a_b__c-d-e"),
    ("test", "test"),
    ("t e s t", "t_e_s_t"),
    ("t  e  s  t", "t__e__s__t"),
    ("t   e   s   t", "t-e-s-t"),
])
def test_fix_spaces(input_text, expected):
    assert fix_spaces(input_text) == expected


def test_fix_spaces_no_spaces():
    assert fix_spaces("NoSpaces") == "NoSpaces"


def test_fix_spaces_single_space():
    assert fix_spaces("a b") == "a_b"


def test_fix_spaces_double_space():
    assert fix_spaces("a  b") == "a__b"


def test_fix_spaces_triple_space():
    assert fix_spaces("a   b") == "a-b"


def test_fix_spaces_many_spaces():
    assert fix_spaces("a          b") == "a-b"


def test_fix_spaces_leading_single_space():
    assert fix_spaces(" a") == "_a"


def test_fix_spaces_leading_double_space():
    assert fix_spaces("  a") == "__a"


def test_fix_spaces_trailing_single_space():
    assert fix_spaces("a ") == "a_"


def test_fix_spaces_trailing_double_space():
    assert fix_spaces("a  ") == "a__"


def test_fix_spaces_only_spaces():
    assert fix_spaces("   ") == "-"


def test_fix_spaces_complex_string():
    assert fix_spaces("  hello   world  test  ") == "__hello-world__test__"


def test_fix_spaces_numbers_and_special_chars():
    assert fix_spaces("123  456  789") == "123__456__789"


def test_fix_spaces_mixed_content():
    assert fix_spaces("a1  b2  c3") == "a1__b2__c3"