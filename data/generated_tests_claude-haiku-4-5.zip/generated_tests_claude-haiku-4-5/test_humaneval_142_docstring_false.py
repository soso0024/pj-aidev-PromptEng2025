# Test cases for HumanEval/142
# Generated using Claude API




def sum_squares(lst):
    """"
    This function will take a list of integers. For all entries in the list, the function shall square the integer entry if its index is a 
    multiple of 3 and will cube the integer entry if its index is a multiple of 4 and not a multiple of 3. The function will not 
    change the entries in the list whose indexes are not a multiple of 3 or 4. The function shall then return the sum of all entries. 
    
    Examples:
    For lst = [1,2,3] the output should be 6
    For lst = []  the output should be 0
    For lst = [-1,-5,2,-1,-5]  the output should be -126
    """

    result =[]
    for i in range(len(lst)):
        if i %3 == 0:
            result.append(lst[i]**2)
        elif i % 4 == 0 and i%3 != 0:
            result.append(lst[i]**3)
        else:
            result.append(lst[i])
    return sum(result)


# Generated test cases:
import pytest


def sum_squares(lst):
    result = []
    for i in range(len(lst)):
        if i % 3 == 0:
            result.append(lst[i]**2)
        elif i % 4 == 0 and i % 3 != 0:
            result.append(lst[i]**3)
        else:
            result.append(lst[i])
    return sum(result)


class TestSumSquares:
    
    def test_empty_list(self):
        assert sum_squares([]) == 0
    
    def test_single_element_at_index_0(self):
        assert sum_squares([5]) == 25
    
    def test_example_case_1(self):
        assert sum_squares([1, 2, 3]) == 6
    
    def test_example_case_2(self):
        assert sum_squares([-1, -5, 2, -1, -5]) == -126
    
    def test_index_0_multiple_of_3(self):
        assert sum_squares([2]) == 4
    
    def test_index_3_multiple_of_3_not_4(self):
        assert sum_squares([1, 2, 3, 4]) == 1 + 2 + 3 + 16
    
    def test_index_4_multiple_of_4_not_3(self):
        assert sum_squares([1, 2, 3, 4, 5]) == 1 + 2 + 3 + 4 + 125
    
    def test_index_12_multiple_of_both_3_and_4(self):
        result = sum_squares([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 2])
        expected = 1 + 2 + 3 + 4 + 5 + 36 + 7 + 512 + 81 + 10 + 11 + 144 + 4
        assert result == expected
    
    def test_negative_numbers(self):
        assert sum_squares([-2, -3, -4]) == 4 + (-3) + (-4)
    
    def test_negative_at_index_4(self):
        assert sum_squares([1, 2, 3, 4, -2]) == 1 + 2 + 3 + 4 + (-8)
    
    def test_zero_values(self):
        assert sum_squares([0, 0, 0, 0]) == 0
    
    def test_mixed_positive_negative(self):
        assert sum_squares([1, -2, 3, -4, 5]) == 1 + (-2) + 9 + (-4) + 125
    
    def test_large_list(self):
        lst = list(range(1, 13))
        result = sum_squares(lst)
        expected = 1 + 2 + 3 + 4 + 5 + 36 + 7 + 512 + 81 + 10 + 11 + 144
        assert result == expected
    
    def test_index_6_not_multiple_of_3_or_4(self):
        assert sum_squares([1, 2, 3, 4, 5, 6, 7]) == 1 + 2 + 3 + 4 + 5 + 6 + 343
    
    def test_index_8_multiple_of_4_not_3(self):
        lst = [1, 2, 3, 4, 5, 6, 7, 8, 2]
        result = sum_squares(lst)
        expected = 1 + 2 + 3 + 4 + 5 + 36 + 7 + 512 + 4
        assert result == expected
    
    @pytest.mark.parametrize("lst,expected", [
        ([1, 2, 3], 6),
        ([], 0),
        ([-1, -5, 2, -1, -5], -126),
        ([0], 0),
        ([2, 2, 2, 2, 2], 4 + 2 + 2 + 2 + 8),
        ([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1),
    ])
    def test_parametrized_cases(self, lst, expected):
        assert sum_squares(lst) == expected