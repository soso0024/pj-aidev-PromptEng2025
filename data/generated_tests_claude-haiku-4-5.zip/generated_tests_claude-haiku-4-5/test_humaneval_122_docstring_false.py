# Test cases for HumanEval/122
# Generated using Claude API


def add_elements(arr, k):
    """
    Given a non-empty array of integers arr and an integer k, return
    the sum of the elements with at most two digits from the first k elements of arr.

    Example:

        Input: arr = [111,21,3,4000,5,6,7,8,9], k = 4
        Output: 24 # sum of 21 + 3

    Constraints:
        1. 1 <= len(arr) <= 100
        2. 1 <= k <= len(arr)
    """

    return sum(elem for elem in arr[:k] if len(str(elem)) <= 2)


# Generated test cases:
import pytest


class TestAddElements:
    
    def test_example_case(self):
        arr = [111, 21, 3, 4000, 5, 6, 7, 8, 9]
        k = 4
        assert add_elements(arr, k) == 24
    
    def test_single_element_single_digit(self):
        arr = [5]
        k = 1
        assert add_elements(arr, k) == 5
    
    def test_single_element_two_digits(self):
        arr = [42]
        k = 1
        assert add_elements(arr, k) == 42
    
    def test_single_element_three_digits(self):
        arr = [123]
        k = 1
        assert add_elements(arr, k) == 0
    
    def test_all_single_digits(self):
        arr = [1, 2, 3, 4, 5]
        k = 5
        assert add_elements(arr, k) == 15
    
    def test_all_two_digits(self):
        arr = [10, 20, 30, 40, 50]
        k = 5
        assert add_elements(arr, k) == 150
    
    def test_all_three_digits(self):
        arr = [100, 200, 300, 400, 500]
        k = 5
        assert add_elements(arr, k) == 0
    
    def test_mixed_digits_k_less_than_length(self):
        arr = [1, 22, 333, 4444, 55555]
        k = 3
        assert add_elements(arr, k) == 23
    
    def test_k_equals_one(self):
        arr = [99, 100, 101]
        k = 1
        assert add_elements(arr, k) == 99
    
    def test_k_equals_length(self):
        arr = [5, 10, 15]
        k = 3
        assert add_elements(arr, k) == 30
    
    def test_negative_single_digit(self):
        arr = [-5, 10, 20]
        k = 3
        assert add_elements(arr, k) == 25
    
    def test_negative_two_digits(self):
        arr = [-50, 10, 20]
        k = 3
        assert add_elements(arr, k) == 30
    
    def test_negative_three_digits(self):
        arr = [-100, 10, 20]
        k = 3
        assert add_elements(arr, k) == 30
    
    def test_zero(self):
        arr = [0, 1, 2]
        k = 3
        assert add_elements(arr, k) == 3
    
    def test_large_numbers(self):
        arr = [1000000, 99, 50, 2000000]
        k = 4
        assert add_elements(arr, k) == 149
    
    def test_boundary_99(self):
        arr = [99, 100]
        k = 2
        assert add_elements(arr, k) == 99
    
    def test_boundary_9(self):
        arr = [9, 10]
        k = 2
        assert add_elements(arr, k) == 19
    
    def test_boundary_negative_99(self):
        arr = [-99, -100]
        k = 2
        assert add_elements(arr, k) == 0
    
    def test_boundary_negative_9(self):
        arr = [-9, -10]
        k = 2
        assert add_elements(arr, k) == -9
    
    def test_mixed_positive_negative(self):
        arr = [-5, 15, -25, 35, -45]
        k = 5
        assert add_elements(arr, k) == 45
    
    @pytest.mark.parametrize("arr,k,expected", [
        ([1, 2, 3], 1, 1),
        ([10, 20, 30], 1, 10),
        ([100, 200, 300], 1, 0),
        ([5, 50, 500], 2, 55),
        ([9, 99, 999], 3, 108),
        ([0], 1, 0),
        ([-1, -10, -100], 3, -11),
    ])
    def test_parametrized_cases(self, arr, k, expected):
        assert add_elements(arr, k) == expected


def add_elements(arr, k):
    return sum(elem for elem in arr[:k] if len(str(abs(elem))) <= 2)