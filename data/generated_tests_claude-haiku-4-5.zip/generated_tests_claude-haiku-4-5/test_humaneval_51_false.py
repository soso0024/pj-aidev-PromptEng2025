# Test cases for HumanEval/51
# Generated using Claude API



def remove_vowels(text):
    """
    remove_vowels is a function that takes string and returns string without vowels.
    >>> remove_vowels('')
    ''
    >>> remove_vowels("abcdef\nghijklm")
    'bcdf\nghjklm'
    >>> remove_vowels('abcdef')
    'bcdf'
    >>> remove_vowels('aaaaa')
    ''
    >>> remove_vowels('aaBAA')
    'B'
    >>> remove_vowels('zbcd')
    'zbcd'
    """

    return "".join([s for s in text if s.lower() not in ["a", "e", "i", "o", "u"]])


# Generated test cases:
import pytest


def remove_vowels(text):
    return "".join([s for s in text if s.lower() not in ["a", "e", "i", "o", "u"]])


class TestRemoveVowels:
    
    @pytest.mark.parametrize("input_text,expected", [
        ("hello", "hll"),
        ("world", "wrld"),
        ("aeiou", ""),
        ("AEIOU", ""),
        ("bcdfg", "bcdfg"),
        ("", ""),
        ("a", ""),
        ("b", "b"),
        ("Hello World", "Hll Wrld"),
        ("HELLO WORLD", "HLL WRLD"),
        ("The quick brown fox", "Th qck brwn fx"),
        ("Python", "Pythn"),
        ("aAbBcC", "bBcC"),
        ("123", "123"),
        ("!@#$%", "!@#$%"),
        ("a1e2i3o4u5", "12345"),
        ("AaEeIiOoUu", ""),
        ("programming", "prgrmmng"),
        ("vowels", "vwls"),
        ("VOWELS", "VWLS"),
        ("aEiOu", ""),
        ("xyz", "xyz"),
        ("   ", "   "),
        ("a e i o u", "    "),
        ("Aa Ee Ii Oo Uu", "    "),
    ])
    def test_remove_vowels_various_cases(self, input_text, expected):
        assert remove_vowels(input_text) == expected
    
    def test_remove_vowels_empty_string(self):
        assert remove_vowels("") == ""
    
    def test_remove_vowels_only_vowels(self):
        assert remove_vowels("aeiou") == ""
    
    def test_remove_vowels_only_consonants(self):
        assert remove_vowels("bcdfg") == "bcdfg"
    
    def test_remove_vowels_mixed_case_vowels(self):
        assert remove_vowels("AeIoU") == ""
    
    def test_remove_vowels_with_numbers(self):
        assert remove_vowels("a1b2c3") == "1b2c3"
    
    def test_remove_vowels_with_special_characters(self):
        assert remove_vowels("a!e@i#o$u%") == "!@#$%"
    
    def test_remove_vowels_with_spaces(self):
        assert remove_vowels("a e i o u") == "    "
    
    def test_remove_vowels_single_vowel(self):
        assert remove_vowels("a") == ""
    
    def test_remove_vowels_single_consonant(self):
        assert remove_vowels("b") == "b"
    
    def test_remove_vowels_uppercase_vowels(self):
        assert remove_vowels("AEIOU") == ""
    
    def test_remove_vowels_mixed_case(self):
        assert remove_vowels("HeLLo WoRLd") == "HLL WRLd"
    
    def test_remove_vowels_long_string(self):
        assert remove_vowels("The quick brown fox jumps over the lazy dog") == "Th qck brwn fx jmps vr th lzy dg"
    
    def test_remove_vowels_repeated_vowels(self):
        assert remove_vowels("aaa") == ""
    
    def test_remove_vowels_repeated_consonants(self):
        assert remove_vowels("bbb") == "bbb"
    
    def test_remove_vowels_alternating_vowels_consonants(self):
        assert remove_vowels("ababab") == "bbb"
    
    def test_remove_vowels_with_newlines(self):
        assert remove_vowels("hello\nworld") == "hll\nwrld"
    
    def test_remove_vowels_with_tabs(self):
        assert remove_vowels("hello\tworld") == "hll\twrld"
    
    def test_remove_vowels_unicode_vowels(self):
        assert remove_vowels("café") == "cf"
    
    def test_remove_vowels_only_spaces(self):
        assert remove_vowels("     ") == "     "