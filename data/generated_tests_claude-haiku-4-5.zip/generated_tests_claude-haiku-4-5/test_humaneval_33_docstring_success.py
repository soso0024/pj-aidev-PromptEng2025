# Test cases for HumanEval/33
# Generated using Claude API



def sort_third(l: list):
    """This function takes a list l and returns a list l' such that
    l' is identical to l in the indicies that are not divisible by three, while its values at the indicies that are divisible by three are equal
    to the values of the corresponding indicies of l, but sorted.
    >>> sort_third([1, 2, 3])
    [1, 2, 3]
    >>> sort_third([5, 6, 3, 4, 8, 9, 2])
    [2, 6, 3, 4, 8, 9, 5]
    """

    l = list(l)
    l[::3] = sorted(l[::3])
    return l


# Generated test cases:
import pytest


def sort_third(l: list):
    l = list(l)
    l[::3] = sorted(l[::3])
    return l


class TestSortThird:
    
    def test_empty_list(self):
        assert sort_third([]) == []
    
    def test_single_element(self):
        assert sort_third([1]) == [1]
    
    def test_two_elements(self):
        assert sort_third([2, 1]) == [2, 1]
    
    def test_three_elements(self):
        assert sort_third([1, 2, 3]) == [1, 2, 3]
    
    def test_example_case_1(self):
        assert sort_third([1, 2, 3]) == [1, 2, 3]
    
    def test_example_case_2(self):
        assert sort_third([5, 6, 3, 4, 8, 9, 2]) == [2, 6, 3, 4, 8, 9, 5]
    
    def test_seven_elements_unsorted_at_indices_divisible_by_three(self):
        assert sort_third([9, 1, 2, 8, 3, 4, 7]) == [7, 1, 2, 8, 3, 4, 9]
    
    def test_six_elements(self):
        assert sort_third([6, 1, 2, 5, 3, 4]) == [5, 1, 2, 6, 3, 4]
    
    def test_nine_elements(self):
        assert sort_third([9, 1, 2, 8, 3, 4, 7, 5, 6]) == [7, 1, 2, 8, 3, 4, 9, 5, 6]
    
    def test_negative_numbers(self):
        assert sort_third([-1, 2, 3, -4, 5, 6]) == [-4, 2, 3, -1, 5, 6]
    
    def test_mixed_positive_negative(self):
        assert sort_third([5, -1, 2, -3, 4, 6]) == [-3, -1, 2, 5, 4, 6]
    
    def test_all_same_elements(self):
        assert sort_third([1, 1, 1, 1, 1, 1]) == [1, 1, 1, 1, 1, 1]
    
    def test_already_sorted_at_divisible_indices(self):
        assert sort_third([1, 5, 6, 2, 7, 8, 3]) == [1, 5, 6, 2, 7, 8, 3]
    
    def test_reverse_sorted_at_divisible_indices(self):
        assert sort_third([9, 1, 2, 8, 3, 4, 7]) == [7, 1, 2, 8, 3, 4, 9]
    
    def test_large_list(self):
        input_list = list(range(30, 0, -1))
        result = sort_third(input_list)
        expected_third = sorted(input_list[::3])
        assert result[::3] == expected_third
        assert result[1::3] == input_list[1::3]
        assert result[2::3] == input_list[2::3]
    
    def test_zero_values(self):
        assert sort_third([0, 1, 2, 0, 3, 4]) == [0, 1, 2, 0, 3, 4]
    
    def test_float_values(self):
        assert sort_third([3.5, 1.2, 2.1, 1.5, 4.2, 5.1]) == [1.5, 1.2, 2.1, 3.5, 4.2, 5.1]
    
    def test_preserves_non_divisible_indices(self):
        input_list = [5, 100, 200, 4, 300, 400, 3]
        result = sort_third(input_list)
        assert result[1] == 100
        assert result[2] == 200
        assert result[4] == 300
        assert result[5] == 400
    
    def test_four_elements(self):
        assert sort_third([4, 1, 2, 3]) == [3, 1, 2, 4]
    
    def test_five_elements(self):
        assert sort_third([5, 1, 2, 4, 3]) == [4, 1, 2, 5, 3]
    
    def test_original_list_not_modified(self):
        original = [5, 6, 3, 4, 8, 9, 2]
        original_copy = original.copy()
        sort_third(original)
        assert original == original_copy
    
    def test_duplicate_values_at_divisible_indices(self):
        assert sort_third([5, 1, 2, 5, 3, 4]) == [5, 1, 2, 5, 3, 4]
    
    def test_string_elements(self):
        assert sort_third(['c', 'x', 'y', 'a', 'z', 'w']) == ['a', 'x', 'y', 'c', 'z', 'w']


@pytest.mark.parametrize("input_list,expected", [
    ([], []),
    ([1], [1]),
    ([1, 2, 3], [1, 2, 3]),
    ([5, 6, 3, 4, 8, 9, 2], [2, 6, 3, 4, 8, 9, 5]),
    ([9, 1, 2, 8, 3, 4, 7], [7, 1, 2, 8, 3, 4, 9]),
    ([6, 1, 2, 5, 3, 4], [5, 1, 2, 6, 3, 4]),
    ([-1, 2, 3, -4, 5, 6], [-4, 2, 3, -1, 5, 6]),
    ([1, 1, 1, 1, 1, 1], [1, 1, 1, 1, 1, 1]),
])
def test_sort_third_parametrized(input_list, expected):
    assert sort_third(input_list) == expected
