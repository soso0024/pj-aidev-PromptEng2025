# Test cases for HumanEval/87
# Generated using Claude API


def get_row(lst, x):
    """
    You are given a 2 dimensional data, as a nested lists,
    which is similar to matrix, however, unlike matrices,
    each row may contain a different number of columns.
    Given lst, and integer x, find integers x in the list,
    and return list of tuples, [(x1, y1), (x2, y2) ...] such that
    each tuple is a coordinate - (row, columns), starting with 0.
    Sort coordinates initially by rows in ascending order.
    Also, sort coordinates of the row by columns in descending order.
    
    Examples:
    get_row([
      [1,2,3,4,5,6],
      [1,2,3,4,1,6],
      [1,2,3,4,5,1]
    ], 1) == [(0, 0), (1, 4), (1, 0), (2, 5), (2, 0)]
    get_row([], 1) == []
    get_row([[], [1], [1, 2, 3]], 3) == [(2, 2)]
    """

    coords = [(i, j) for i in range(len(lst)) for j in range(len(lst[i])) if lst[i][j] == x]
    return sorted(sorted(coords, key=lambda x: x[1], reverse=True), key=lambda x: x[0])


# Generated test cases:
import pytest


def get_row(lst, x):
    coords = [(i, j) for i in range(len(lst)) for j in range(len(lst[i])) if lst[i][j] == x]
    return sorted(sorted(coords, key=lambda x: x[1], reverse=True), key=lambda x: x[0])


class TestGetRow:
    
    def test_example_1(self):
        result = get_row([
            [1, 2, 3, 4, 5, 6],
            [1, 2, 3, 4, 1, 6],
            [1, 2, 3, 4, 5, 1]
        ], 1)
        assert result == [(0, 0), (1, 4), (1, 0), (2, 5), (2, 0)]
    
    def test_example_2_empty_list(self):
        result = get_row([], 1)
        assert result == []
    
    def test_example_3_mixed_rows(self):
        result = get_row([[], [1], [1, 2, 3]], 3)
        assert result == [(2, 2)]
    
    def test_single_element_found(self):
        result = get_row([[5]], 5)
        assert result == [(0, 0)]
    
    def test_single_element_not_found(self):
        result = get_row([[5]], 3)
        assert result == []
    
    def test_element_not_in_list(self):
        result = get_row([[1, 2, 3], [4, 5, 6]], 7)
        assert result == []
    
    def test_single_row(self):
        result = get_row([[1, 2, 3, 2, 1]], 2)
        assert result == [(0, 3), (0, 1)]
    
    def test_single_column(self):
        result = get_row([[1], [2], [1], [3]], 1)
        assert result == [(0, 0), (2, 0)]
    
    def test_all_same_elements(self):
        result = get_row([[5, 5], [5, 5]], 5)
        assert result == [(0, 1), (0, 0), (1, 1), (1, 0)]
    
    def test_multiple_occurrences_same_row(self):
        result = get_row([[7, 7, 7]], 7)
        assert result == [(0, 2), (0, 1), (0, 0)]
    
    def test_multiple_rows_multiple_columns(self):
        result = get_row([[1, 2], [3, 1], [1, 1]], 1)
        assert result == [(0, 0), (1, 1), (2, 1), (2, 0)]
    
    def test_empty_rows_in_middle(self):
        result = get_row([[1, 2], [], [3, 1]], 1)
        assert result == [(0, 0), (2, 1)]
    
    def test_negative_numbers(self):
        result = get_row([[-1, -2], [-1, 3]], -1)
        assert result == [(0, 0), (1, 0)]
    
    def test_zero_value(self):
        result = get_row([[0, 1], [0, 0]], 0)
        assert result == [(0, 0), (1, 1), (1, 0)]
    
    def test_string_elements(self):
        result = get_row([['a', 'b'], ['a', 'c']], 'a')
        assert result == [(0, 0), (1, 0)]
    
    def test_large_grid(self):
        grid = [[i + j for j in range(5)] for i in range(5)]
        result = get_row(grid, 5)
        assert len(result) > 0
        assert all(isinstance(coord, tuple) and len(coord) == 2 for coord in result)
    
    def test_sorting_by_row_then_column(self):
        result = get_row([[2, 1], [1, 2], [2, 2]], 2)
        assert result[0][0] <= result[1][0]
        if result[0][0] == result[1][0]:
            assert result[0][1] >= result[1][1]
    
    def test_float_elements(self):
        result = get_row([[1.5, 2.5], [1.5, 3.5]], 1.5)
        assert result == [(0, 0), (1, 0)]
    
    def test_mixed_types_search_for_int(self):
        result = get_row([[1, '1'], [1, 2]], 1)
        assert result == [(0, 0), (1, 0)]
    
    def test_single_row_single_element(self):
        result = get_row([[42]], 42)
        assert result == [(0, 0)]
    
    def test_descending_column_order_within_row(self):
        result = get_row([[3, 3, 3]], 3)
        assert result == [(0, 2), (0, 1), (0, 0)]
    
    def test_multiple_rows_verify_row_order(self):
        result = get_row([[1], [1], [1]], 1)
        assert result == [(0, 0), (1, 0), (2, 0)]
        assert all(result[i][0] <= result[i+1][0] for i in range(len(result)-1))