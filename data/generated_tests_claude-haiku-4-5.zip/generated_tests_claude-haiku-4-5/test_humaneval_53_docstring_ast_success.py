# Test cases for HumanEval/53
# Generated using Claude API



def add(x: int, y: int):
    """Add two numbers x and y
    >>> add(2, 3)
    5
    >>> add(5, 7)
    12
    """

    return x + y


# Generated test cases:
import pytest


def add(x: int, y: int):
    """Add two numbers x and y
    >>> add(2, 3)
    5
    >>> add(5, 7)
    12
    """
    return x + y


class TestAdd:
    def test_add_positive_numbers(self):
        assert add(2, 3) == 5
        assert add(5, 7) == 12

    def test_add_negative_numbers(self):
        assert add(-2, -3) == -5
        assert add(-5, -7) == -12

    def test_add_mixed_signs(self):
        assert add(5, -3) == 2
        assert add(-5, 3) == -2
        assert add(10, -10) == 0

    def test_add_zero(self):
        assert add(0, 0) == 0
        assert add(5, 0) == 5
        assert add(0, 5) == 5
        assert add(-5, 0) == -5

    def test_add_large_numbers(self):
        assert add(1000000, 2000000) == 3000000
        assert add(999999999, 1) == 1000000000

    def test_add_commutative(self):
        assert add(3, 5) == add(5, 3)
        assert add(-2, 8) == add(8, -2)

    @pytest.mark.parametrize("x,y,expected", [
        (0, 0, 0),
        (1, 1, 2),
        (10, 20, 30),
        (-10, -20, -30),
        (100, -50, 50),
        (-100, 50, -50),
        (999, 1, 1000),
    ])
    def test_add_parametrized(self, x, y, expected):
        assert add(x, y) == expected

    def test_add_associative(self):
        x, y, z = 5, 3, 2
        assert add(add(x, y), z) == add(x, add(y, z))

    def test_add_identity(self):
        assert add(42, 0) == 42
        assert add(0, 42) == 42

    def test_add_inverse(self):
        assert add(5, -5) == 0
        assert add(-10, 10) == 0
