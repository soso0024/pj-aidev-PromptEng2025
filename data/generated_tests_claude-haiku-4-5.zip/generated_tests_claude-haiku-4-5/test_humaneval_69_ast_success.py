# Test cases for HumanEval/69
# Generated using Claude API


def search(lst):
    '''
    You are given a non-empty list of positive integers. Return the greatest integer that is greater than 
    zero, and has a frequency greater than or equal to the value of the integer itself. 
    The frequency of an integer is the number of times it appears in the list.
    If no such a value exist, return -1.
    Examples:
        search([4, 1, 2, 2, 3, 1]) == 2
        search([1, 2, 2, 3, 3, 3, 4, 4, 4]) == 3
        search([5, 5, 4, 4, 4]) == -1
    '''

    frq = [0] * (max(lst) + 1)
    for i in lst:
        frq[i] += 1;

    ans = -1
    for i in range(1, len(frq)):
        if frq[i] >= i:
            ans = i
    
    return ans


# Generated test cases:
import pytest


def search(lst):
    frq = [0] * (max(lst) + 1)
    for i in lst:
        frq[i] += 1

    ans = -1
    for i in range(1, len(frq)):
        if frq[i] >= i:
            ans = i
    
    return ans


@pytest.mark.parametrize("lst,expected", [
    ([1, 1, 3, 6, 6, 6, 6], 1),
    ([1, 2, 3, 4, 5], 1),
    ([0], -1),
    ([1], 1),
    ([2, 2], 2),
    ([1, 1, 1], 1),
    ([3, 3, 3], 3),
    ([1, 2, 2, 3, 3, 3], 3),
    ([5, 5, 5, 5, 5], 5),
    ([1, 1, 1, 1, 1, 1, 1, 1, 1, 1], 1),
    ([2, 2, 2, 2], 2),
    ([0, 0, 0], -1),
    ([1, 0], 1),
    ([0, 1, 1], 1),
    ([4, 4, 4, 4], 4),
    ([1, 1, 2, 2, 2], 2),
    ([10], -1),
    ([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 1),
    ([2, 2, 2, 2, 2], 2),
    ([3, 3, 3, 3], 3),
])
def test_search_various_cases(lst, expected):
    assert search(lst) == expected


def test_search_single_element_zero():
    assert search([0]) == -1


def test_search_single_element_one():
    assert search([1]) == 1


def test_search_all_zeros():
    assert search([0, 0, 0, 0]) == -1


def test_search_all_ones():
    assert search([1, 1, 1, 1]) == 1


def test_search_all_twos():
    assert search([2, 2]) == 2


def test_search_mixed_with_zero():
    assert search([0, 1, 1, 2, 2, 2]) == 2


def test_search_large_numbers():
    assert search([100, 100, 100, 100, 100, 100, 100, 100, 100, 100]) == -1


def test_search_ascending_sequence():
    assert search([1, 2, 3, 4, 5]) == 1


def test_search_descending_frequency():
    assert search([1, 1, 1, 2, 2, 3]) == 2


def test_search_returns_largest_valid_i():
    result = search([1, 1, 2, 2, 3, 3, 3, 4, 4, 4, 4])
    assert result == 4


def test_search_no_valid_i():
    assert search([10, 20, 30]) == -1


def test_search_boundary_case():
    assert search([1, 2, 2, 3, 3, 3, 4, 4, 4, 4]) == 4


def test_search_single_large_frequency():
    assert search([5, 5, 5, 5, 5, 5]) == 5


def test_search_mixed_frequencies():
    assert search([1, 1, 1, 2, 2, 3]) == 2


def test_search_two_elements_same():
    assert search([2, 2]) == 2


def test_search_two_elements_different():
    assert search([1, 2]) == 1


def test_search_three_ones():
    assert search([1, 1, 1]) == 1


def test_search_four_twos():
    assert search([2, 2, 2, 2]) == 2


def test_search_complex_case():
    assert search([1, 1, 2, 2, 2, 3, 3, 3, 3]) == 3