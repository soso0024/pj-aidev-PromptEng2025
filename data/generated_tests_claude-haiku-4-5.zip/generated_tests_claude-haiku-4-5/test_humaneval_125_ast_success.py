# Test cases for HumanEval/125
# Generated using Claude API


def split_words(txt):
    '''
    Given a string of words, return a list of words split on whitespace, if no whitespaces exists in the text you
    should split on commas ',' if no commas exists you should return the number of lower-case letters with odd order in the
    alphabet, ord('a') = 0, ord('b') = 1, ... ord('z') = 25
    Examples
    split_words("Hello world!") ➞ ["Hello", "world!"]
    split_words("Hello,world!") ➞ ["Hello", "world!"]
    split_words("abcdef") == 3 
    '''

    if " " in txt:
        return txt.split()
    elif "," in txt:
        return txt.replace(',',' ').split()
    else:
        return len([i for i in txt if i.islower() and ord(i)%2 == 0])


# Generated test cases:
import pytest


def split_words(txt):
    if " " in txt:
        return txt.split()
    elif "," in txt:
        return txt.replace(',',' ').split()
    else:
        return len([i for i in txt if i.islower() and ord(i)%2 == 0])


class TestSplitWords:
    
    def test_split_words_with_spaces(self):
        assert split_words("Hello World") == ["Hello", "World"]
    
    def test_split_words_with_multiple_spaces(self):
        assert split_words("one two three four") == ["one", "two", "three", "four"]
    
    def test_split_words_with_single_word_no_space(self):
        assert split_words("Hello") == 2
    
    def test_split_words_with_commas(self):
        assert split_words("Hello,World") == ["Hello", "World"]
    
    def test_split_words_with_multiple_commas(self):
        assert split_words("one,two,three,four") == ["one", "two", "three", "four"]
    
    def test_split_words_with_comma_and_spaces(self):
        assert split_words("Hello, World") == ["Hello,", "World"]
    
    def test_split_words_empty_string(self):
        assert split_words("") == 0
    
    def test_split_words_single_character_lowercase_even_ord(self):
        result = split_words("a")
        assert isinstance(result, int)
        assert result >= 0
    
    def test_split_words_single_character_lowercase_odd_ord(self):
        result = split_words("b")
        assert isinstance(result, int)
        assert result >= 0
    
    def test_split_words_single_character_uppercase(self):
        result = split_words("A")
        assert isinstance(result, int)
        assert result == 0
    
    def test_split_words_lowercase_letters_even_ord(self):
        result = split_words("abcd")
        assert isinstance(result, int)
        assert result >= 0
    
    def test_split_words_mixed_case(self):
        result = split_words("AaBbCc")
        assert isinstance(result, int)
        assert result >= 0
    
    def test_split_words_with_numbers(self):
        result = split_words("abc123")
        assert isinstance(result, int)
        assert result >= 0
    
    def test_split_words_with_special_characters(self):
        result = split_words("abc!@#")
        assert isinstance(result, int)
        assert result >= 0
    
    def test_split_words_space_takes_precedence(self):
        result = split_words("hello world,test")
        assert result == ["hello", "world,test"]
    
    def test_split_words_multiple_spaces_between_words(self):
        assert split_words("hello  world") == ["hello", "world"]
    
    def test_split_words_leading_space(self):
        result = split_words(" hello")
        assert "" in result or "hello" in result
    
    def test_split_words_trailing_space(self):
        result = split_words("hello ")
        assert "hello" in result
    
    def test_split_words_only_spaces(self):
        result = split_words("   ")
        assert result == []
    
    def test_split_words_only_commas(self):
        result = split_words(",,,")
        assert result == []
    
    def test_split_words_comma_with_spaces_around(self):
        assert split_words("a, b, c") == ["a,", "b,", "c"]
    
    def test_split_words_character_b_even_ord(self):
        result = split_words("b")
        assert result == 1
    
    def test_split_words_character_d_even_ord(self):
        result = split_words("d")
        assert result == 1
    
    def test_split_words_character_a_odd_ord(self):
        result = split_words("a")
        assert result == 0
    
    def test_split_words_character_c_odd_ord(self):
        result = split_words("c")
        assert result == 0
    
    def test_split_words_lowercase_even_ord_chars(self):
        result = split_words("bd")
        assert result == 2
    
    def test_split_words_lowercase_mixed_ord_chars(self):
        result = split_words("abcd")
        assert result == 2
    
    def test_split_words_uppercase_ignored(self):
        result = split_words("ABCD")
        assert result == 0
    
    def test_split_words_numbers_ignored(self):
        result = split_words("1234")
        assert result == 0
    
    def test_split_words_special_chars_ignored(self):
        result = split_words("!@#$%")
        assert result == 0
    
    def test_split_words_space_in_middle(self):
        assert split_words("a b") == ["a", "b"]
    
    def test_split_words_comma_in_middle(self):
        assert split_words("a,b") == ["a", "b"]


@pytest.mark.parametrize("input_str,expected", [
    ("hello world", ["hello", "world"]),
    ("one two three", ["one", "two", "three"]),
    ("a,b", ["a", "b"]),
    ("x,y,z", ["x", "y", "z"]),
    ("", 0),
])
def test_split_words_parametrized(input_str, expected):
    assert split_words(input_str) == expected