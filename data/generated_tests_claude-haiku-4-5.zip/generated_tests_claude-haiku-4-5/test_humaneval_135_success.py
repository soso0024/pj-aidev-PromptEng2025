# Test cases for HumanEval/135
# Generated using Claude API


def can_arrange(arr):
    """Create a function which returns the largest index of an element which
    is not greater than or equal to the element immediately preceding it. If
    no such element exists then return -1. The given array will not contain
    duplicate values.

    Examples:
    can_arrange([1,2,4,3,5]) = 3
    can_arrange([1,2,3]) = -1
    """

    ind=-1
    i=1
    while i<len(arr):
      if arr[i]<arr[i-1]:
        ind=i
      i+=1
    return ind


# Generated test cases:
import pytest


def can_arrange(arr):
    ind=-1
    i=1
    while i<len(arr):
      if arr[i]<arr[i-1]:
        ind=i
      i+=1
    return ind


class TestCanArrange:
    
    def test_empty_array(self):
        assert can_arrange([]) == -1
    
    def test_single_element(self):
        assert can_arrange([1]) == -1
    
    def test_two_elements_sorted(self):
        assert can_arrange([1, 2]) == -1
    
    def test_two_elements_unsorted(self):
        assert can_arrange([2, 1]) == 1
    
    def test_already_sorted_array(self):
        assert can_arrange([1, 2, 3, 4, 5]) == -1
    
    def test_reverse_sorted_array(self):
        assert can_arrange([5, 4, 3, 2, 1]) == 4
    
    def test_one_violation_at_end(self):
        assert can_arrange([1, 2, 3, 2]) == 3
    
    def test_one_violation_at_start(self):
        assert can_arrange([2, 1, 3, 4]) == 1
    
    def test_multiple_violations_returns_last(self):
        assert can_arrange([3, 1, 2, 4, 5]) == 1
    
    def test_multiple_violations_complex(self):
        assert can_arrange([1, 3, 2, 4, 5, 6]) == 2
    
    def test_all_same_elements(self):
        assert can_arrange([5, 5, 5, 5]) == -1
    
    def test_negative_numbers_sorted(self):
        assert can_arrange([-5, -3, -1, 0, 2]) == -1
    
    def test_negative_numbers_unsorted(self):
        assert can_arrange([-1, -5, 0, 2]) == 1
    
    def test_mixed_positive_negative_sorted(self):
        assert can_arrange([-10, -5, 0, 5, 10]) == -1
    
    def test_mixed_positive_negative_unsorted(self):
        assert can_arrange([-5, -10, 0, 5]) == 1
    
    def test_large_numbers(self):
        assert can_arrange([1000000, 2000000, 3000000]) == -1
    
    def test_large_numbers_unsorted(self):
        assert can_arrange([3000000, 1000000, 2000000]) == 1
    
    def test_zeros_in_array(self):
        assert can_arrange([0, 0, 0]) == -1
    
    def test_zeros_with_violation(self):
        assert can_arrange([1, 0, 2]) == 1
    
    def test_duplicate_elements_sorted(self):
        assert can_arrange([1, 1, 2, 2, 3, 3]) == -1
    
    def test_duplicate_elements_unsorted(self):
        assert can_arrange([1, 2, 2, 1, 3]) == 3
    
    def test_alternating_pattern(self):
        assert can_arrange([1, 3, 2, 4, 3, 5]) == 4
    
    def test_violation_in_middle(self):
        assert can_arrange([1, 2, 3, 2, 4, 5]) == 3
    
    def test_two_element_equal(self):
        assert can_arrange([5, 5]) == -1
    
    def test_descending_then_ascending(self):
        assert can_arrange([5, 4, 3, 4, 5]) == 2


@pytest.mark.parametrize("arr,expected", [
    ([], -1),
    ([1], -1),
    ([1, 2], -1),
    ([2, 1], 1),
    ([1, 2, 3, 4, 5], -1),
    ([5, 4, 3, 2, 1], 4),
    ([1, 2, 3, 2], 3),
    ([2, 1, 3, 4], 1),
    ([3, 1, 2, 4, 5], 1),
    ([1, 3, 2, 4, 5, 6], 2),
    ([5, 5, 5, 5], -1),
    ([-5, -3, -1, 0, 2], -1),
    ([-1, -5, 0, 2], 1),
    ([0, 0, 0], -1),
    ([1, 0, 2], 1),
])
def test_can_arrange_parametrized(arr, expected):
    assert can_arrange(arr) == expected