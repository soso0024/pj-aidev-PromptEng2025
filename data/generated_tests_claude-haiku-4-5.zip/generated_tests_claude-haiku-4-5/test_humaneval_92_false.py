# Test cases for HumanEval/92
# Generated using Claude API


def any_int(x, y, z):
    '''
    Create a function that takes 3 numbers.
    Returns true if one of the numbers is equal to the sum of the other two, and all numbers are integers.
    Returns false in any other cases.
    
    Examples
    any_int(5, 2, 7) ➞ True
    
    any_int(3, 2, 2) ➞ False

    any_int(3, -2, 1) ➞ True
    
    any_int(3.6, -2.2, 2) ➞ False
  

    
    '''

    
    if isinstance(x,int) and isinstance(y,int) and isinstance(z,int):
        if (x+y==z) or (x+z==y) or (y+z==x):
            return True
        return False
    return False


# Generated test cases:
import pytest


def any_int(x, y, z):
    
    if isinstance(x,int) and isinstance(y,int) and isinstance(z,int):
        if (x+y==z) or (x+z==y) or (y+z==x):
            return True
        return False
    return False


class TestAnyInt:
    
    @pytest.mark.parametrize("x,y,z,expected", [
        (1, 2, 3, True),
        (2, 1, 3, True),
        (3, 2, 1, True),
        (1, 1, 2, True),
        (0, 0, 0, True),
        (5, 5, 10, True),
        (-1, -2, -3, True),
        (-1, 2, 1, True),
        (1, -2, -1, True),
    ])
    def test_valid_integer_sums(self, x, y, z, expected):
        assert any_int(x, y, z) == expected
    
    @pytest.mark.parametrize("x,y,z,expected", [
        (1, 2, 4, False),
        (1, 1, 3, False),
        (5, 5, 11, False),
        (0, 0, 1, False),
        (-1, -1, -3, False),
        (10, 20, 25, False),
    ])
    def test_invalid_integer_sums(self, x, y, z, expected):
        assert any_int(x, y, z) == expected
    
    @pytest.mark.parametrize("x,y,z,expected", [
        (1.5, 2, 3, False),
        (1, 2.5, 3, False),
        (1, 2, 3.5, False),
        (1.5, 2.5, 4, False),
        (1.0, 2.0, 3.0, False),
    ])
    def test_float_inputs(self, x, y, z, expected):
        assert any_int(x, y, z) == expected
    
    @pytest.mark.parametrize("x,y,z,expected", [
        ("1", 2, 3, False),
        (1, "2", 3, False),
        (1, 2, "3", False),
        ("1", "2", "3", False),
    ])
    def test_string_inputs(self, x, y, z, expected):
        assert any_int(x, y, z) == expected
    
    @pytest.mark.parametrize("x,y,z,expected", [
        (None, 2, 3, False),
        (1, None, 3, False),
        (1, 2, None, False),
    ])
    def test_none_inputs(self, x, y, z, expected):
        assert any_int(x, y, z) == expected
    
    @pytest.mark.parametrize("x,y,z,expected", [
        ([1], 2, 3, False),
        (1, [2], 3, False),
        (1, 2, [3], False),
        ({1}, 2, 3, False),
    ])
    def test_collection_inputs(self, x, y, z, expected):
        assert any_int(x, y, z) == expected
    
    @pytest.mark.parametrize("x,y,z,expected", [
        (0, 0, 0, True),
        (0, 1, 1, True),
        (1, 0, 1, True),
        (0, -1, -1, True),
    ])
    def test_zero_values(self, x, y, z, expected):
        assert any_int(x, y, z) == expected
    
    @pytest.mark.parametrize("x,y,z,expected", [
        (-5, -3, -8, True),
        (-10, 5, -5, True),
        (100, 200, 300, True),
        (-100, -200, -300, True),
    ])
    def test_large_values(self, x, y, z, expected):
        assert any_int(x, y, z) == expected
    
    def test_boolean_inputs(self):
        assert any_int(True, True, True) == True
        assert any_int(True, False, True) == True
        assert any_int(False, False, False) == True
    
    def test_mixed_types(self):
        assert any_int(1, 2.0, 3) == False
        assert any_int(1, "2", 3) == False
        assert any_int(1, None, 3) == False