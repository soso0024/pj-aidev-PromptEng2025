# Test cases for HumanEval/79
# Generated using Claude API


def decimal_to_binary(decimal):
    """You will be given a number in decimal form and your task is to convert it to
    binary format. The function should return a string, with each character representing a binary
    number. Each character in the string will be '0' or '1'.

    There will be an extra couple of characters 'db' at the beginning and at the end of the string.
    The extra characters are there to help with the format.

    Examples:
    decimal_to_binary(15)   # returns "db1111db"
    decimal_to_binary(32)   # returns "db100000db"
    """

    return "db" + bin(decimal)[2:] + "db"


# Generated test cases:
import pytest


class TestDecimalToBinary:
    
    def test_zero(self):
        from test_humaneval_79 import decimal_to_binary
        assert decimal_to_binary(0) == "db0db"
    
    def test_one(self):
        assert decimal_to_binary(1) == "db1db"
    
    def test_two(self):
        assert decimal_to_binary(2) == "db10db"
    
    def test_small_positive_number(self):
        assert decimal_to_binary(5) == "db101db"
    
    def test_eight(self):
        assert decimal_to_binary(8) == "db1000db"
    
    def test_fifteen(self):
        assert decimal_to_binary(15) == "db1111db"
    
    def test_sixteen(self):
        assert decimal_to_binary(16) == "db10000db"
    
    def test_large_positive_number(self):
        assert decimal_to_binary(255) == "db11111111db"
    
    def test_very_large_number(self):
        assert decimal_to_binary(1024) == "db10000000000db"
    
    def test_negative_one(self):
        assert decimal_to_binary(-1) == "dbb1db"
    
    def test_negative_number(self):
        assert decimal_to_binary(-5) == "dbb101db"
    
    def test_negative_large_number(self):
        assert decimal_to_binary(-255) == "dbb11111111db"
    
    def test_output_format_has_prefix_suffix(self):
        result = decimal_to_binary(10)
        assert result.startswith("db")
        assert result.endswith("db")
    
    def test_output_contains_only_valid_binary_chars(self):
        result = decimal_to_binary(42)
        binary_part = result[2:-2]
        for char in binary_part:
            assert char in "01b-"
    
    @pytest.mark.parametrize("decimal,expected", [
        (0, "db0db"),
        (1, "db1db"),
        (2, "db10db"),
        (3, "db11db"),
        (4, "db100db"),
        (7, "db111db"),
        (10, "db1010db"),
        (100, "db1100100db"),
        (1000, "db1111101000db"),
    ])
    def test_parametrized_positive_numbers(self, decimal, expected):
        assert decimal_to_binary(decimal) == expected
    
    @pytest.mark.parametrize("decimal,expected", [
        (-1, "dbb1db"),
        (-2, "dbb10db"),
        (-5, "dbb101db"),
        (-10, "dbb1010db"),
    ])
    def test_parametrized_negative_numbers(self, decimal, expected):
        assert decimal_to_binary(decimal) == expected
    
    def test_power_of_two(self):
        assert decimal_to_binary(32) == "db100000db"
    
    def test_power_of_two_minus_one(self):
        assert decimal_to_binary(31) == "db11111db"
    
    def test_return_type_is_string(self):
        result = decimal_to_binary(5)
        assert isinstance(result, str)
    
    def test_binary_representation_correctness(self):
        for i in range(20):
            result = decimal_to_binary(i)
            binary_part = result[2:-2]
            assert int(binary_part, 2) == i