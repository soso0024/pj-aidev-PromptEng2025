# Test cases for HumanEval/23
# Generated using Claude API



def strlen(string: str) -> int:
    """ Return length of given string
    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """

    return len(string)


# Generated test cases:
import pytest


def strlen(string: str) -> int:
    return len(string)


class TestStrlen:
    def test_empty_string(self):
        assert strlen("") == 0

    def test_single_character(self):
        assert strlen("a") == 1

    def test_simple_word(self):
        assert strlen("hello") == 5

    def test_string_with_spaces(self):
        assert strlen("hello world") == 11

    def test_string_with_numbers(self):
        assert strlen("abc123") == 6

    def test_string_with_special_characters(self):
        assert strlen("!@#$%^&*()") == 10

    def test_string_with_newline(self):
        assert strlen("hello\nworld") == 11

    def test_string_with_tab(self):
        assert strlen("hello\tworld") == 11

    def test_string_with_unicode_characters(self):
        assert strlen("café") == 4

    def test_string_with_emoji(self):
        assert strlen("hello😀") == 6

    def test_long_string(self):
        long_str = "a" * 1000
        assert strlen(long_str) == 1000

    def test_string_with_multiple_spaces(self):
        assert strlen("   ") == 3

    def test_string_with_mixed_whitespace(self):
        assert strlen(" \t\n ") == 4

    def test_numeric_string(self):
        assert strlen("12345") == 5

    def test_string_with_quotes(self):
        assert strlen('he said "hello"') == 15

    def test_string_with_apostrophe(self):
        assert strlen("it's") == 4

    def test_string_with_backslash(self):
        assert strlen("path\\to\\file") == 12

    def test_string_with_null_character(self):
        assert strlen("hello\x00world") == 11

    def test_very_long_string(self):
        very_long = "x" * 10000
        assert strlen(very_long) == 10000

    def test_string_with_only_newlines(self):
        assert strlen("\n\n\n") == 3

    def test_string_with_mixed_case(self):
        assert strlen("HeLLo WoRLd") == 11

    def test_string_with_accented_characters(self):
        assert strlen("naïve") == 5

    def test_string_with_chinese_characters(self):
        assert strlen("你好") == 2

    def test_string_with_arabic_characters(self):
        assert strlen("مرحبا") == 5

    def test_string_with_cyrillic_characters(self):
        assert strlen("привет") == 6


@pytest.mark.parametrize("input_str,expected", [
    ("", 0),
    ("a", 1),
    ("hello", 5),
    ("hello world", 11),
    ("123", 3),
    ("!@#$", 4),
    ("   ", 3),
    ("a" * 100, 100),
    ("\n", 1),
    ("\t", 1),
])
def test_strlen_parametrized(input_str, expected):
    assert strlen(input_str) == expected


def test_strlen_returns_int():
    result = strlen("test")
    assert isinstance(result, int)


def test_strlen_consistency():
    test_string = "consistency test"
    assert strlen(test_string) == strlen(test_string)


def test_strlen_different_strings_different_lengths():
    assert strlen("a") != strlen("ab")
    assert strlen("test") != strlen("testing")