# Test cases for HumanEval/75
# Generated using Claude API


def is_multiply_prime(a):
    """Write a function that returns true if the given number is the multiplication of 3 prime numbers
    and false otherwise.
    Knowing that (a) is less then 100. 
    Example:
    is_multiply_prime(30) == True
    30 = 2 * 3 * 5
    """

    def is_prime(n):
        for j in range(2,n):
            if n%j == 0:
                return False
        return True

    for i in range(2,101):
        if not is_prime(i): continue
        for j in range(2,101):
            if not is_prime(j): continue
            for k in range(2,101):
                if not is_prime(k): continue
                if i*j*k == a: return True
    return False


# Generated test cases:
import pytest


class TestIsMultiplyPrime:
    
    def is_multiply_prime(self, a):
        def is_prime(n):
            if n < 2:
                return False
            for j in range(2, n):
                if n % j == 0:
                    return False
            return True

        for i in range(2, 101):
            if not is_prime(i):
                continue
            for j in range(2, 101):
                if not is_prime(j):
                    continue
                for k in range(2, 101):
                    if not is_prime(k):
                        continue
                    if i * j * k == a:
                        return True
        return False
    
    @pytest.mark.parametrize("number,expected", [
        (30, True),
        (2, False),
        (3, False),
        (5, False),
        (6, False),
        (8, True),
        (27, True),
        (30, True),
        (42, True),
        (66, True),
        (70, True),
        (78, True),
        (1, False),
        (4, False),
        (9, False),
        (25, False),
        (49, False),
    ])
    def test_is_multiply_prime(self, number, expected):
        assert self.is_multiply_prime(number) == expected
    
    def test_multiply_prime_30(self):
        assert self.is_multiply_prime(30) == True
    
    def test_multiply_prime_8(self):
        assert self.is_multiply_prime(8) == True
    
    def test_multiply_prime_27(self):
        assert self.is_multiply_prime(27) == True
    
    def test_not_multiply_prime_2(self):
        assert self.is_multiply_prime(2) == False
    
    def test_not_multiply_prime_3(self):
        assert self.is_multiply_prime(3) == False
    
    def test_not_multiply_prime_5(self):
        assert self.is_multiply_prime(5) == False
    
    def test_not_multiply_prime_1(self):
        assert self.is_multiply_prime(1) == False
    
    def test_not_multiply_prime_4(self):
        assert self.is_multiply_prime(4) == False
    
    def test_not_multiply_prime_6(self):
        assert self.is_multiply_prime(6) == False
    
    def test_multiply_prime_42(self):
        assert self.is_multiply_prime(42) == True
    
    def test_multiply_prime_66(self):
        assert self.is_multiply_prime(66) == True
    
    def test_multiply_prime_70(self):
        assert self.is_multiply_prime(70) == True
    
    def test_multiply_prime_78(self):
        assert self.is_multiply_prime(78) == True
    
    def test_not_multiply_prime_9(self):
        assert self.is_multiply_prime(9) == False
    
    def test_not_multiply_prime_25(self):
        assert self.is_multiply_prime(25) == False
    
    def test_not_multiply_prime_49(self):
        assert self.is_multiply_prime(49) == False
    
    def test_multiply_prime_105(self):
        assert self.is_multiply_prime(105) == True
    
    def test_multiply_prime_110(self):
        assert self.is_multiply_prime(110) == True
    
    def test_multiply_prime_130(self):
        assert self.is_multiply_prime(130) == True
    
    def test_multiply_prime_2_3_5(self):
        assert self.is_multiply_prime(2 * 3 * 5) == True
    
    def test_multiply_prime_2_2_2(self):
        assert self.is_multiply_prime(2 * 2 * 2) == True
    
    def test_multiply_prime_3_3_3(self):
        assert self.is_multiply_prime(3 * 3 * 3) == True
    
    def test_multiply_prime_2_3_7(self):
        assert self.is_multiply_prime(2 * 3 * 7) == True
    
    def test_multiply_prime_2_5_7(self):
        assert self.is_multiply_prime(2 * 5 * 7) == True
    
    def test_multiply_prime_3_5_7(self):
        assert self.is_multiply_prime(3 * 5 * 7) == True