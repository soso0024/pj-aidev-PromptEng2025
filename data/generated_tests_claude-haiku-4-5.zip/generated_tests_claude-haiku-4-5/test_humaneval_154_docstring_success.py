# Test cases for HumanEval/154
# Generated using Claude API


def cycpattern_check(a , b):
    """You are given 2 words. You need to return True if the second word or any of its rotations is a substring in the first word
    cycpattern_check("abcd","abd") => False
    cycpattern_check("hello","ell") => True
    cycpattern_check("whassup","psus") => False
    cycpattern_check("abab","baa") => True
    cycpattern_check("efef","eeff") => False
    cycpattern_check("himenss","simen") => True

    """

    l = len(b)
    pat = b + b
    for i in range(len(a) - l + 1):
        for j in range(l + 1):
            if a[i:i+l] == pat[j:j+l]:
                return True
    return False


# Generated test cases:
import pytest


def cycpattern_check(a , b):
    l = len(b)
    pat = b + b
    for i in range(len(a) - l + 1):
        for j in range(l + 1):
            if a[i:i+l] == pat[j:j+l]:
                return True
    return False


@pytest.mark.parametrize("a,b,expected", [
    ("abcd", "abd", False),
    ("hello", "ell", True),
    ("whassup", "psus", False),
    ("abab", "baa", True),
    ("efef", "eeff", False),
    ("himenss", "simen", True),
])
def test_cycpattern_check_basic(a, b, expected):
    assert cycpattern_check(a, b) == expected


def test_cycpattern_check_exact_match():
    assert cycpattern_check("abc", "abc") == True


def test_cycpattern_check_rotation_at_start():
    assert cycpattern_check("abcabc", "cab") == True


def test_cycpattern_check_rotation_at_end():
    assert cycpattern_check("xyzabc", "cab") == True


def test_cycpattern_check_single_char_pattern():
    assert cycpattern_check("hello", "l") == True


def test_cycpattern_check_single_char_pattern_not_found():
    assert cycpattern_check("hello", "x") == False


def test_cycpattern_check_pattern_longer_than_text():
    assert cycpattern_check("ab", "abcd") == False


def test_cycpattern_check_empty_pattern():
    assert cycpattern_check("hello", "") == True


def test_cycpattern_check_empty_text():
    assert cycpattern_check("", "a") == False


def test_cycpattern_check_both_empty():
    assert cycpattern_check("", "") == True


def test_cycpattern_check_same_length_match():
    assert cycpattern_check("abc", "bca") == True


def test_cycpattern_check_same_length_no_match():
    assert cycpattern_check("abc", "def") == False


def test_cycpattern_check_repeated_chars():
    assert cycpattern_check("aaaa", "aa") == True


def test_cycpattern_check_repeated_pattern():
    assert cycpattern_check("abcabcabc", "cab") == True


def test_cycpattern_check_no_rotation_match():
    assert cycpattern_check("abcdef", "xyz") == False


def test_cycpattern_check_pattern_at_beginning():
    assert cycpattern_check("abcdef", "abc") == True


def test_cycpattern_check_pattern_in_middle():
    assert cycpattern_check("abcdef", "cde") == True


def test_cycpattern_check_rotation_match_middle():
    assert cycpattern_check("abcdefgh", "fga") == False


def test_cycpattern_check_case_sensitive():
    assert cycpattern_check("Hello", "ell") == True


def test_cycpattern_check_case_sensitive_match():
    assert cycpattern_check("Hello", "ell") == True
    assert cycpattern_check("hello", "ell") == True


def test_cycpattern_check_special_chars():
    assert cycpattern_check("a@b#c", "@b#") == True


def test_cycpattern_check_numbers():
    assert cycpattern_check("12345", "234") == True


def test_cycpattern_check_numbers_rotation():
    assert cycpattern_check("12345", "512") == False


def test_cycpattern_check_long_text_short_pattern():
    assert cycpattern_check("a" * 1000 + "bcd", "dbc") == True


def test_cycpattern_check_whitespace():
    assert cycpattern_check("a b c", " b ") == True


def test_cycpattern_check_all_rotations():
    text = "abcabc"
    pattern = "cab"
    assert cycpattern_check(text, pattern) == True


def test_cycpattern_check_pattern_not_substring_or_rotation():
    assert cycpattern_check("abcdef", "xyz") == False