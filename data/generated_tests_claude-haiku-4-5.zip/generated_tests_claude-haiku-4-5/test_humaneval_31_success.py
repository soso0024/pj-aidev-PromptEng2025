# Test cases for HumanEval/31
# Generated using Claude API



def is_prime(n):
    """Return true if a given number is prime, and false otherwise.
    >>> is_prime(6)
    False
    >>> is_prime(101)
    True
    >>> is_prime(11)
    True
    >>> is_prime(13441)
    True
    >>> is_prime(61)
    True
    >>> is_prime(4)
    False
    >>> is_prime(1)
    False
    """

    if n < 2:
        return False
    for k in range(2, n - 1):
        if n % k == 0:
            return False
    return True


# Generated test cases:
import pytest


def is_prime(n):
    if n < 2:
        return False
    for k in range(2, n - 1):
        if n % k == 0:
            return False
    return True


class TestIsPrime:
    
    @pytest.mark.parametrize("n,expected", [
        (2, True),
        (3, True),
        (5, True),
        (7, True),
        (11, True),
        (13, True),
        (17, True),
        (19, True),
        (23, True),
        (29, True),
        (31, True),
        (37, True),
        (41, True),
        (43, True),
        (47, True),
    ])
    def test_prime_numbers(self, n, expected):
        assert is_prime(n) == expected
    
    @pytest.mark.parametrize("n,expected", [
        (0, False),
        (1, False),
        (-1, False),
        (-5, False),
        (-100, False),
    ])
    def test_numbers_less_than_two(self, n, expected):
        assert is_prime(n) == expected
    
    @pytest.mark.parametrize("n,expected", [
        (4, False),
        (6, False),
        (8, False),
        (9, False),
        (10, False),
        (12, False),
        (14, False),
        (15, False),
        (16, False),
        (18, False),
        (20, False),
        (21, False),
        (22, False),
        (24, False),
        (25, False),
        (26, False),
        (27, False),
        (28, False),
        (30, False),
        (100, False),
        (121, False),
        (144, False),
    ])
    def test_composite_numbers(self, n, expected):
        assert is_prime(n) == expected
    
    def test_two_is_prime(self):
        assert is_prime(2) == True
    
    def test_three_is_prime(self):
        assert is_prime(3) == True
    
    def test_four_is_not_prime(self):
        assert is_prime(4) == False
    
    def test_one_is_not_prime(self):
        assert is_prime(1) == False
    
    def test_zero_is_not_prime(self):
        assert is_prime(0) == False
    
    def test_negative_number_is_not_prime(self):
        assert is_prime(-7) == False
    
    def test_large_prime(self):
        assert is_prime(97) == True
    
    def test_large_composite(self):
        assert is_prime(100) == False
