# Test cases for HumanEval/23
# Generated using Claude API



def strlen(string: str) -> int:
    """ Return length of given string
    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """

    return len(string)


# Generated test cases:
import pytest


class TestStrlen:
    """Test cases for strlen function"""

    def test_empty_string(self):
        """Test with empty string"""
        from test_humaneval_23_docstring_ast import strlen
        assert strlen('') == 0

    def test_single_character(self):
        """Test with single character"""
        assert strlen('a') == 1

    def test_multiple_characters(self):
        """Test with multiple characters"""
        assert strlen('abc') == 3

    def test_long_string(self):
        """Test with long string"""
        assert strlen('abcdefghijklmnopqrstuvwxyz') == 26

    def test_string_with_spaces(self):
        """Test with string containing spaces"""
        assert strlen('hello world') == 11

    def test_string_with_numbers(self):
        """Test with string containing numbers"""
        assert strlen('abc123') == 6

    def test_string_with_special_characters(self):
        """Test with string containing special characters"""
        assert strlen('!@#$%^&*()') == 10

    def test_string_with_newline(self):
        """Test with string containing newline"""
        assert strlen('hello\nworld') == 11

    def test_string_with_tab(self):
        """Test with string containing tab"""
        assert strlen('hello\tworld') == 11

    def test_string_with_unicode(self):
        """Test with unicode characters"""
        assert strlen('café') == 4

    def test_string_with_emoji(self):
        """Test with emoji characters"""
        assert strlen('hello😀') == 6

    def test_repeated_characters(self):
        """Test with repeated characters"""
        assert strlen('aaaa') == 4

    def test_mixed_case_string(self):
        """Test with mixed case string"""
        assert strlen('HeLLo') == 5

    @pytest.mark.parametrize("input_str,expected", [
        ('', 0),
        ('a', 1),
        ('abc', 3),
        ('hello', 5),
        ('hello world', 11),
        ('123', 3),
        ('!@#', 3),
        ('   ', 3),
        ('a' * 100, 100),
        ('test\nstring', 11),
    ])
    def test_strlen_parametrized(self, input_str, expected):
        """Parametrized test for various string inputs"""
        assert strlen(input_str) == expected

    def test_return_type_is_int(self):
        """Test that return type is int"""
        result = strlen('test')
        assert isinstance(result, int)

    def test_return_type_for_empty_string(self):
        """Test that return type is int for empty string"""
        result = strlen('')
        assert isinstance(result, int)

    def test_very_long_string(self):
        """Test with very long string"""
        long_string = 'x' * 10000
        assert strlen(long_string) == 10000

    def test_string_with_all_whitespace(self):
        """Test with string containing only whitespace"""
        assert strlen('   \t\n') == 6