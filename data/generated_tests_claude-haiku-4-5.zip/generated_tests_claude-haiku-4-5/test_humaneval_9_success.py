# Test cases for HumanEval/9
# Generated using Claude API

from typing import List, Tuple


def rolling_max(numbers: List[int]) -> List[int]:
    """ From a given list of integers, generate a list of rolling maximum element found until given moment
    in the sequence.
    >>> rolling_max([1, 2, 3, 2, 3, 4, 2])
    [1, 2, 3, 3, 3, 4, 4]
    """

    running_max = None
    result = []

    for n in numbers:
        if running_max is None:
            running_max = n
        else:
            running_max = max(running_max, n)

        result.append(running_max)

    return result


# Generated test cases:
import pytest
from typing import List


def rolling_max(numbers: List[int]) -> List[int]:
    running_max = None
    result = []

    for n in numbers:
        if running_max is None:
            running_max = n
        else:
            running_max = max(running_max, n)

        result.append(running_max)

    return result


class TestRollingMax:
    def test_empty_list(self):
        assert rolling_max([]) == []

    def test_single_element(self):
        assert rolling_max([5]) == [5]

    def test_single_negative_element(self):
        assert rolling_max([-10]) == [-10]

    def test_ascending_sequence(self):
        assert rolling_max([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

    def test_descending_sequence(self):
        assert rolling_max([5, 4, 3, 2, 1]) == [5, 5, 5, 5, 5]

    def test_mixed_sequence(self):
        assert rolling_max([3, 1, 4, 1, 5, 9, 2, 6]) == [3, 3, 4, 4, 5, 9, 9, 9]

    def test_all_same_elements(self):
        assert rolling_max([7, 7, 7, 7]) == [7, 7, 7, 7]

    def test_negative_numbers(self):
        assert rolling_max([-5, -2, -8, -1]) == [-5, -2, -2, -1]

    def test_mixed_positive_negative(self):
        assert rolling_max([-3, 5, -1, 8, -10]) == [-3, 5, 5, 8, 8]

    def test_zeros(self):
        assert rolling_max([0, 0, 0]) == [0, 0, 0]

    def test_with_zero_and_negatives(self):
        assert rolling_max([-5, 0, -3, 2]) == [-5, 0, 0, 2]

    def test_large_numbers(self):
        assert rolling_max([1000000, 999999, 1000001]) == [1000000, 1000000, 1000001]

    def test_two_elements_ascending(self):
        assert rolling_max([1, 2]) == [1, 2]

    def test_two_elements_descending(self):
        assert rolling_max([2, 1]) == [2, 2]

    def test_two_elements_same(self):
        assert rolling_max([5, 5]) == [5, 5]

    def test_alternating_high_low(self):
        assert rolling_max([10, 1, 10, 1, 10]) == [10, 10, 10, 10, 10]

    def test_peak_in_middle(self):
        assert rolling_max([1, 2, 3, 2, 1]) == [1, 2, 3, 3, 3]

    def test_multiple_peaks(self):
        assert rolling_max([1, 5, 2, 8, 3, 9]) == [1, 5, 5, 8, 8, 9]

    @pytest.mark.parametrize("input_list,expected", [
        ([1], [1]),
        ([1, 2], [1, 2]),
        ([2, 1], [2, 2]),
        ([1, 1, 1], [1, 1, 1]),
        ([-1, -2, -3], [-1, -1, -1]),
        ([0], [0]),
        ([0, 1, 2], [0, 1, 2]),
    ])
    def test_parametrized_cases(self, input_list, expected):
        assert rolling_max(input_list) == expected

    def test_result_length_matches_input(self):
        input_list = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5]
        result = rolling_max(input_list)
        assert len(result) == len(input_list)

    def test_result_is_non_decreasing(self):
        input_list = [3, 1, 4, 1, 5, 9, 2, 6]
        result = rolling_max(input_list)
        for i in range(1, len(result)):
            assert result[i] >= result[i - 1]

    def test_first_element_equals_input_first(self):
        input_list = [5, 3, 8, 1]
        result = rolling_max(input_list)
        assert result[0] == input_list[0]

    def test_last_element_is_maximum(self):
        input_list = [3, 1, 4, 1, 5, 9, 2, 6]
        result = rolling_max(input_list)
        assert result[-1] == max(input_list)
