# Test cases for HumanEval/142
# Generated using Claude API




def sum_squares(lst):
    """"
    This function will take a list of integers. For all entries in the list, the function shall square the integer entry if its index is a 
    multiple of 3 and will cube the integer entry if its index is a multiple of 4 and not a multiple of 3. The function will not 
    change the entries in the list whose indexes are not a multiple of 3 or 4. The function shall then return the sum of all entries. 
    
    Examples:
    For lst = [1,2,3] the output should be 6
    For lst = []  the output should be 0
    For lst = [-1,-5,2,-1,-5]  the output should be -126
    """

    result =[]
    for i in range(len(lst)):
        if i %3 == 0:
            result.append(lst[i]**2)
        elif i % 4 == 0 and i%3 != 0:
            result.append(lst[i]**3)
        else:
            result.append(lst[i])
    return sum(result)


# Generated test cases:
import pytest


def sum_squares(lst):
    result =[]
    for i in range(len(lst)):
        if i %3 == 0:
            result.append(lst[i]**2)
        elif i % 4 == 0 and i%3 != 0:
            result.append(lst[i]**3)
        else:
            result.append(lst[i])
    return sum(result)


class TestSumSquares:
    
    def test_empty_list(self):
        assert sum_squares([]) == 0
    
    def test_single_element_at_index_0(self):
        assert sum_squares([5]) == 25
    
    def test_two_elements(self):
        assert sum_squares([2, 3]) == 7
    
    def test_three_elements(self):
        assert sum_squares([1, 2, 3]) == 6
    
    def test_four_elements(self):
        assert sum_squares([1, 2, 3, 4]) == 22
    
    def test_five_elements(self):
        assert sum_squares([1, 2, 3, 4, 5]) == 147
    
    def test_six_elements(self):
        assert sum_squares([1, 2, 3, 4, 5, 6]) == 153
    
    def test_seven_elements(self):
        assert sum_squares([1, 2, 3, 4, 5, 6, 7]) == 202
    
    def test_eight_elements(self):
        assert sum_squares([1, 2, 3, 4, 5, 6, 7, 8]) == 210
    
    def test_negative_numbers(self):
        assert sum_squares([-1, -2, -3]) == -4
    
    def test_zero_values(self):
        assert sum_squares([0, 0, 0]) == 0
    
    def test_mixed_positive_negative(self):
        assert sum_squares([2, -3, 4, -5]) == 30
    
    def test_large_numbers(self):
        assert sum_squares([10, 20, 30]) == 150
    
    def test_floats(self):
        result = sum_squares([1.5, 2.5, 3.5])
        assert abs(result - 8.25) < 0.0001
    
    def test_index_0_squared(self):
        assert sum_squares([3, 1, 1, 1, 1, 1]) == 14
    
    def test_index_3_cubed(self):
        assert sum_squares([1, 1, 1, 2, 1, 1]) == 9
    
    def test_index_4_cubed(self):
        assert sum_squares([1, 1, 1, 1, 2, 1]) == 13
    
    def test_index_6_squared(self):
        assert sum_squares([1, 1, 1, 1, 1, 1, 3]) == 15
    
    def test_index_8_cubed(self):
        assert sum_squares([1, 1, 1, 1, 1, 1, 1, 1, 2]) == 16
    
    def test_index_9_squared(self):
        assert sum_squares([1, 1, 1, 1, 1, 1, 1, 1, 1, 3]) == 18
    
    def test_all_indices_pattern(self):
        lst = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
        result = sum_squares(lst)
        expected = 4 + 3 + 4 + 125 + 6 + 7 + 512 + 9 + 1000 + 11 + 144 + 13
        assert result == 1478
    
    def test_single_negative_at_index_0(self):
        assert sum_squares([-5]) == 25
    
    def test_single_negative_at_index_1(self):
        assert sum_squares([1, -3]) == -2
    
    def test_long_list(self):
        lst = list(range(1, 21))
        result = sum_squares(lst)
        assert isinstance(result, (int, float))
    
    def test_all_ones(self):
        assert sum_squares([1, 1, 1, 1, 1, 1, 1, 1, 1]) == 9
    
    def test_alternating_pattern(self):
        assert sum_squares([1, -1, 1, -1, 1, -1]) == 2

    @pytest.mark.parametrize("lst,expected", [
        ([0], 0),
        ([1], 1),
        ([2], 4),
        ([1, 2], 3),
        ([2, 2], 6),
        ([1, 1, 1], 3),
        ([2, 2, 2], 8),
    ])
    def test_parametrized_basic(self, lst, expected):
        assert sum_squares(lst) == expected