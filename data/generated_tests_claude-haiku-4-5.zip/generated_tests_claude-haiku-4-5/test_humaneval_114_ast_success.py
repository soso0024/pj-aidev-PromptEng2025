# Test cases for HumanEval/114
# Generated using Claude API


def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """

    max_sum = 0
    s = 0
    for num in nums:
        s += -num
        if (s < 0):
            s = 0
        max_sum = max(s, max_sum)
    if max_sum == 0:
        max_sum = max(-i for i in nums)
    min_sum = -max_sum
    return min_sum


# Generated test cases:
import pytest


class TestMinSubArraySum:
    
    def test_single_positive_element(self):
        from test_humaneval_114_ast import minSubArraySum
        assert minSubArraySum([5]) == 5
    
    def test_single_negative_element(self):
        assert minSubArraySum([-5]) == -5
    
    def test_single_zero_element(self):
        assert minSubArraySum([0]) == 0
    
    def test_all_positive_numbers(self):
        assert minSubArraySum([1, 2, 3, 4]) == 1
    
    def test_all_negative_numbers(self):
        assert minSubArraySum([-1, -2, -3, -4]) == -10
    
    def test_mixed_positive_and_negative(self):
        assert minSubArraySum([5, -3, 5]) == -3
    
    def test_mixed_with_zeros(self):
        assert minSubArraySum([0, -1, 0, -2]) == -3
    
    def test_two_elements_positive(self):
        assert minSubArraySum([3, 7]) == 3
    
    def test_two_elements_negative(self):
        assert minSubArraySum([-3, -7]) == -10
    
    def test_two_elements_mixed(self):
        assert minSubArraySum([5, -2]) == -2
    
    def test_large_positive_numbers(self):
        assert minSubArraySum([100, 200, 300]) == 100
    
    def test_large_negative_numbers(self):
        assert minSubArraySum([-100, -200, -300]) == -600
    
    def test_alternating_signs(self):
        assert minSubArraySum([1, -1, 1, -1]) == -1
    
    def test_zero_in_middle(self):
        assert minSubArraySum([5, 0, 5]) == 0
    
    def test_multiple_zeros(self):
        assert minSubArraySum([0, 0, 0]) == 0
    
    def test_negative_then_positive(self):
        assert minSubArraySum([-5, 10, -3]) == -5
    
    def test_positive_then_negative(self):
        assert minSubArraySum([5, -10, 3]) == -10
    
    def test_subarray_in_middle(self):
        assert minSubArraySum([1, -5, -3, 1]) == -8
    
    def test_large_array(self):
        assert minSubArraySum([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == 1
    
    def test_array_with_one_large_negative(self):
        assert minSubArraySum([1, 2, -100, 3, 4]) == -100
    
    def test_array_with_one_large_positive(self):
        assert minSubArraySum([-1, -2, 100, -3, -4]) == -7
    
    def test_negative_zero_positive(self):
        assert minSubArraySum([-5, 0, 5]) == -5
    
    def test_complex_pattern(self):
        assert minSubArraySum([2, -1, 2, -1, 4, -5]) == -5
    
    def test_all_same_positive(self):
        assert minSubArraySum([3, 3, 3, 3]) == 3
    
    def test_all_same_negative(self):
        assert minSubArraySum([-3, -3, -3, -3]) == -12
    
    def test_single_large_negative_in_positives(self):
        assert minSubArraySum([1, 1, -50, 1, 1]) == -50
    
    def test_decreasing_sequence(self):
        assert minSubArraySum([10, 9, 8, 7, 6]) == 6
    
    def test_increasing_sequence(self):
        assert minSubArraySum([1, 2, 3, 4, 5]) == 1
    
    def test_valley_pattern(self):
        assert minSubArraySum([5, 1, -10, 1, 5]) == -10
    
    def test_peak_pattern(self):
        assert minSubArraySum([-5, -1, 10, -1, -5]) == -6
    
    def test_two_negatives_one_positive(self):
        assert minSubArraySum([-3, -4, 2]) == -7
    
    def test_fractional_like_behavior(self):
        assert minSubArraySum([1, 1, 1, -10, 1, 1, 1]) == -10
    
    def test_negative_at_start(self):
        assert minSubArraySum([-10, 1, 2, 3]) == -10
    
    def test_negative_at_end(self):
        assert minSubArraySum([1, 2, 3, -10]) == -10
    
    def test_multiple_subarrays_same_sum(self):
        assert minSubArraySum([-5, 1, -5, 1]) == -9