# Test cases for HumanEval/78
# Generated using Claude API


def hex_key(num):
    """You have been tasked to write a function that receives 
    a hexadecimal number as a string and counts the number of hexadecimal 
    digits that are primes (prime number, or a prime, is a natural number 
    greater than 1 that is not a product of two smaller natural numbers).
    Hexadecimal digits are 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, A, B, C, D, E, F.
    Prime numbers are 2, 3, 5, 7, 11, 13, 17,...
    So you have to determine a number of the following digits: 2, 3, 5, 7, 
    B (=decimal 11), D (=decimal 13).
    Note: you may assume the input is always correct or empty string, 
    and symbols A,B,C,D,E,F are always uppercase.
    Examples:
    For num = "AB" the output should be 1.
    For num = "1077E" the output should be 2.
    For num = "ABED1A33" the output should be 4.
    For num = "123456789ABCDEF0" the output should be 6.
    For num = "2020" the output should be 2.
    """

    primes = ('2', '3', '5', '7', 'B', 'D')
    total = 0
    for i in range(0, len(num)):
        if num[i] in primes:
            total += 1
    return total


# Generated test cases:
import pytest


def hex_key(num):
    primes = ('2', '3', '5', '7', 'B', 'D')
    total = 0
    for i in range(0, len(num)):
        if num[i] in primes:
            total += 1
    return total


@pytest.mark.parametrize("input_num,expected", [
    ("AB", 1),
    ("1077E", 2),
    ("ABED1A33", 4),
    ("123456789ABCDEF0", 6),
    ("2020", 2),
])
def test_hex_key_examples(input_num, expected):
    assert hex_key(input_num) == expected


def test_hex_key_empty_string():
    assert hex_key("") == 0


def test_hex_key_single_prime_2():
    assert hex_key("2") == 1


def test_hex_key_single_prime_3():
    assert hex_key("3") == 1


def test_hex_key_single_prime_5():
    assert hex_key("5") == 1


def test_hex_key_single_prime_7():
    assert hex_key("7") == 1


def test_hex_key_single_prime_B():
    assert hex_key("B") == 1


def test_hex_key_single_prime_D():
    assert hex_key("D") == 1


def test_hex_key_single_non_prime_0():
    assert hex_key("0") == 0


def test_hex_key_single_non_prime_1():
    assert hex_key("1") == 0


def test_hex_key_single_non_prime_4():
    assert hex_key("4") == 0


def test_hex_key_single_non_prime_6():
    assert hex_key("6") == 0


def test_hex_key_single_non_prime_8():
    assert hex_key("8") == 0


def test_hex_key_single_non_prime_9():
    assert hex_key("9") == 0


def test_hex_key_single_non_prime_A():
    assert hex_key("A") == 0


def test_hex_key_single_non_prime_C():
    assert hex_key("C") == 0


def test_hex_key_single_non_prime_E():
    assert hex_key("E") == 0


def test_hex_key_single_non_prime_F():
    assert hex_key("F") == 0


def test_hex_key_all_primes():
    assert hex_key("2357BD") == 6


def test_hex_key_all_non_primes():
    assert hex_key("0146891ACEF") == 0


def test_hex_key_mixed_case_not_applicable():
    assert hex_key("2B3D5A7") == 6


def test_hex_key_long_string_with_primes():
    assert hex_key("2222333355557777BBBBDDDD") == 24


def test_hex_key_long_string_no_primes():
    assert hex_key("0000111144446666888899999ACEF") == 0


def test_hex_key_alternating_prime_non_prime():
    assert hex_key("2A3C5E7F") == 4


def test_hex_key_all_hex_digits():
    assert hex_key("0123456789ABCDEF") == 6


def test_hex_key_repeated_single_prime():
    assert hex_key("22222") == 5


def test_hex_key_repeated_single_non_prime():
    assert hex_key("11111") == 0


def test_hex_key_B_and_D_only():
    assert hex_key("BDBD") == 4


def test_hex_key_2_3_5_7_only():
    assert hex_key("2357") == 4