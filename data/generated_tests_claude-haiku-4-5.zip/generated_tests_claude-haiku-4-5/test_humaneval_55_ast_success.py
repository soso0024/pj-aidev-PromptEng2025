# Test cases for HumanEval/55
# Generated using Claude API



def fib(n: int):
    """Return n-th Fibonacci number.
    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """

    if n == 0:
        return 0
    if n == 1:
        return 1
    return fib(n - 1) + fib(n - 2)


# Generated test cases:
import pytest


def fib(n: int):
    if n == 0:
        return 0
    if n == 1:
        return 1
    return fib(n - 1) + fib(n - 2)


class TestFibBaseCases:
    def test_fib_zero(self):
        assert fib(0) == 0

    def test_fib_one(self):
        assert fib(1) == 1


class TestFibSmallNumbers:
    @pytest.mark.parametrize("n,expected", [
        (2, 1),
        (3, 2),
        (4, 3),
        (5, 5),
        (6, 8),
        (7, 13),
        (8, 21),
        (9, 34),
        (10, 55),
    ])
    def test_fib_small_numbers(self, n, expected):
        assert fib(n) == expected


class TestFibMediumNumbers:
    def test_fib_15(self):
        assert fib(15) == 610

    def test_fib_20(self):
        assert fib(20) == 6765


class TestFibSequence:
    def test_fib_sequence_property(self):
        """Test that fib(n) = fib(n-1) + fib(n-2) for n > 1"""
        for n in range(2, 15):
            assert fib(n) == fib(n - 1) + fib(n - 2)


class TestFibMonotonicity:
    def test_fib_is_increasing(self):
        """Test that fibonacci sequence is monotonically increasing for n >= 0"""
        prev = fib(0)
        for n in range(1, 15):
            current = fib(n)
            assert current >= prev
            prev = current


class TestFibPositive:
    def test_fib_returns_positive_for_positive_input(self):
        """Test that fib returns non-negative values for non-negative inputs"""
        for n in range(0, 15):
            assert fib(n) >= 0


class TestFibKnownValues:
    @pytest.mark.parametrize("n,expected", [
        (0, 0),
        (1, 1),
        (2, 1),
        (3, 2),
        (4, 3),
        (5, 5),
        (6, 8),
        (7, 13),
        (8, 21),
        (9, 34),
        (10, 55),
        (11, 89),
        (12, 144),
        (13, 233),
        (14, 377),
    ])
    def test_fib_known_values(self, n, expected):
        assert fib(n) == expected


class TestFibConsistency:
    def test_fib_consistent_calls(self):
        """Test that multiple calls to fib with same input return same result"""
        n = 10
        result1 = fib(n)
        result2 = fib(n)
        assert result1 == result2


class TestFibReturnType:
    def test_fib_returns_int(self):
        """Test that fib returns an integer"""
        result = fib(5)
        assert isinstance(result, int)

    def test_fib_returns_int_for_zero(self):
        assert isinstance(fib(0), int)

    def test_fib_returns_int_for_one(self):
        assert isinstance(fib(1), int)
