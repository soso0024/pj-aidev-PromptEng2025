# Test cases for HumanEval/91
# Generated using Claude API


def is_bored(S):
    """
    You'll be given a string of words, and your task is to count the number
    of boredoms. A boredom is a sentence that starts with the word "I".
    Sentences are delimited by '.', '?' or '!'.
   
    For example:
    >>> is_bored("Hello world")
    0
    >>> is_bored("The sky is blue. The sun is shining. I love this weather")
    1
    """

    import re
    sentences = re.split(r'[.?!]\s*', S)
    return sum(sentence[0:2] == 'I ' for sentence in sentences)


# Generated test cases:
import pytest
import re


def is_bored(S):
    sentences = re.split(r'[.?!]\s*', S)
    return sum(sentence[0:2] == 'I ' for sentence in sentences)


class TestIsBored:
    
    @pytest.mark.parametrize("input_str,expected", [
        ("Hello world", 0),
        ("The sky is blue. The sun is shining. I love this weather", 1),
        ("I am happy", 1),
        ("I am happy. I am sad", 2),
        ("I am happy? I am sad! I am confused.", 3),
        ("", 0),
        (".", 0),
        ("? !", 0),
        ("I", 0),
        ("I.", 0),
        ("I ", 1),
        ("I am. I am. I am.", 3),
        ("This is a test. I am bored. This is another test.", 1),
        ("I am bored! I am so bored? I am very bored.", 3),
        ("The sentence starts with I but not as a boredom", 0),
        ("I am happy.I am sad", 2),
        ("I am happy.  I am sad", 2),
        ("I am happy?I am sad", 2),
        ("I am happy!I am sad", 2),
        ("I am happy. I am sad. I am confused. I am tired.", 4),
        ("Not I am bored", 0),
        ("I. I. I.", 0),
        ("I? I! I.", 0),
        ("I am. I am. I am. I am.", 4),
        ("The quick brown fox. I jump over the lazy dog.", 1),
        ("I love coding! I love testing? I love Python.", 3),
        ("i am bored", 0),
        ("I  am bored", 1),
        ("I\tam bored", 0),
        ("I am bored. i am sad", 1),
        ("I am bored! I am sad? I am confused.", 3),
        ("I am bored.I am sad.I am confused.", 3),
        ("I am bored. I am sad. I am confused.", 3),
        ("I am bored.  I am sad.  I am confused.", 3),
        ("I am bored?  I am sad!  I am confused.", 3),
        ("I am bored", 1),
        ("I am bored.", 1),
        ("I am bored. ", 1),
        ("I am bored.  ", 1),
        ("I am bored?", 1),
        ("I am bored!", 1),
        ("I am bored! ", 1),
        ("I am bored!  ", 1),
        ("I am bored? ", 1),
        ("I am bored?  ", 1),
        ("I am bored. I am sad. I am confused. I am tired. I am happy.", 5),
        ("I am bored. I am sad. I am confused. I am tired. I am happy. I am excited.", 6),
        ("I am bored. I am sad. I am confused. I am tired. I am happy. I am excited. I am amazed.", 7),
        ("I am bored. I am sad. I am confused. I am tired. I am happy. I am excited. I am amazed. I am shocked.", 8),
        ("I am bored. I am sad. I am confused. I am tired. I am happy. I am excited. I am amazed. I am shocked. I am surprised.", 9),
        ("I am bored. I am sad. I am confused. I am tired. I am happy. I am excited. I am amazed. I am shocked. I am surprised. I am delighted.", 10),
    ])
    def test_is_bored(self, input_str, expected):
        assert is_bored(input_str) == expected


def test_is_bored_empty_string():
    assert is_bored("") == 0


def test_is_bored_no_sentences():
    assert is_bored("Hello world") == 0


def test_is_bored_single_boredom():
    assert is_bored("I am bored") == 1


def test_is_bored_multiple_boredoms():
    assert is_bored("I am bored. I am sad. I am confused.") == 3


def test_is_bored_with_question_mark():
    assert is_bored("I am bored?") == 1


def test_is_bored_with_exclamation():
    assert is_bored("I am bored!") == 1


def test_is_bored_mixed_delimiters():
    assert is_bored("I am bored! I am sad? I am confused.") == 3


def test_is_bored_case_sensitive():
    assert is_bored("i am bored") == 0


def test_is_bored_i_not_at_start():
    assert is_bored("The I am bored") == 0


def test_is_bored_only_i():
    assert is_bored("I.") == 0


def test_is_bored_i_with_extra_space():
    assert is_bored("I  am bored") == 1


def test_is_bored_multiple_spaces_between_sentences():
    assert is_bored("I am bored.  I am sad.  I am confused.") == 3


def test_is_bored_no_delimiter_at_end():
    assert is_bored("I am bored") == 1


def test_is_bored_delimiter_at_start():
    assert is_bored(". I am bored") == 1


def test_is_bored_consecutive_delimiters():
    assert is_bored("I am bored.. I am sad") == 2


def test_is_bored_only_delimiters():
    assert is_bored("...") == 0


def test_is_bored_only_i_and_delimiters():
    assert is_bored("I. I. I.") == 0