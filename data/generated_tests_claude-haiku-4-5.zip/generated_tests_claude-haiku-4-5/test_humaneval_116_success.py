# Test cases for HumanEval/116
# Generated using Claude API


def sort_array(arr):
    """
    In this Kata, you have to sort an array of non-negative integers according to
    number of ones in their binary representation in ascending order.
    For similar number of ones, sort based on decimal value.

    It must be implemented like this:
    >>> sort_array([1, 5, 2, 3, 4]) == [1, 2, 3, 4, 5]
    >>> sort_array([-2, -3, -4, -5, -6]) == [-6, -5, -4, -3, -2]
    >>> sort_array([1, 0, 2, 3, 4]) [0, 1, 2, 3, 4]
    """

    return sorted(sorted(arr), key=lambda x: bin(x)[2:].count('1'))


# Generated test cases:
import pytest


def sort_array(arr):
    return sorted(sorted(arr), key=lambda x: bin(x)[2:].count('1'))


class TestSortArray:
    def test_empty_array(self):
        assert sort_array([]) == []

    def test_single_element(self):
        assert sort_array([5]) == [5]

    def test_single_element_zero(self):
        assert sort_array([0]) == [0]

    def test_two_elements_same_bit_count(self):
        result = sort_array([3, 5])
        assert result == [3, 5]

    def test_two_elements_different_bit_count(self):
        result = sort_array([7, 4])
        assert result == [4, 7]

    def test_all_zeros(self):
        assert sort_array([0, 0, 0]) == [0, 0, 0]

    def test_all_ones(self):
        result = sort_array([1, 1, 1])
        assert result == [1, 1, 1]

    def test_mixed_numbers(self):
        result = sort_array([8, 4, 2, 1])
        assert result == [1, 2, 4, 8]

    def test_numbers_with_same_bit_count(self):
        result = sort_array([3, 5, 6])
        assert len(result) == 3
        assert result.count(3) == 1
        assert result.count(5) == 1
        assert result.count(6) == 1

    def test_large_numbers(self):
        result = sort_array([255, 128, 64, 32])
        assert result[0] == 32
        assert result[-1] == 255

    def test_negative_numbers(self):
        result = sort_array([-1, -2, -4])
        assert len(result) == 3

    def test_mixed_positive_negative(self):
        result = sort_array([1, -1, 2, -2])
        assert len(result) == 4

    def test_duplicates(self):
        result = sort_array([5, 5, 3, 3])
        assert result.count(5) == 2
        assert result.count(3) == 2

    def test_unsorted_input(self):
        result = sort_array([15, 7, 3, 1])
        assert len(result) == 4

    def test_already_sorted(self):
        result = sort_array([1, 2, 4, 8])
        assert len(result) == 4

    def test_reverse_sorted(self):
        result = sort_array([8, 4, 2, 1])
        assert result[0] == 1
        assert result[-1] == 8

    def test_bit_count_ordering(self):
        result = sort_array([0, 1, 2, 3, 4, 5, 6, 7])
        assert result[0] == 0
        assert result[1] == 1
        assert result[2] == 2

    def test_large_array(self):
        arr = list(range(100))
        result = sort_array(arr)
        assert len(result) == 100
        assert result[0] == 0

    def test_specific_bit_pattern(self):
        result = sort_array([15, 7, 11, 13, 14])
        assert len(result) == 5

    def test_powers_of_two(self):
        result = sort_array([1, 2, 4, 8, 16, 32])
        assert result == [1, 2, 4, 8, 16, 32]

    def test_all_bits_set(self):
        result = sort_array([255, 127, 63, 31, 15, 7, 3, 1])
        assert result[0] == 1
        assert result[-1] == 255

    @pytest.mark.parametrize("input_arr,expected_first", [
        ([0], 0),
        ([1], 1),
        ([7, 4], 4),
        ([15, 8], 8),
    ])
    def test_parametrized_basic(self, input_arr, expected_first):
        result = sort_array(input_arr)
        assert result[0] == expected_first

    def test_stability_with_same_bit_count(self):
        result = sort_array([6, 3, 5])
        assert len(result) == 3
        assert all(x in [3, 5, 6] for x in result)

    def test_zero_with_others(self):
        result = sort_array([0, 1, 2, 3])
        assert result[0] == 0

    def test_single_bit_numbers(self):
        result = sort_array([1, 2, 4, 8, 16])
        assert result == [1, 2, 4, 8, 16]
