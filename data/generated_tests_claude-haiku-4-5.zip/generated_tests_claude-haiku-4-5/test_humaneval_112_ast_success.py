# Test cases for HumanEval/112
# Generated using Claude API


def reverse_delete(s,c):
    """Task
    We are given two strings s and c, you have to deleted all the characters in s that are equal to any character in c
    then check if the result string is palindrome.
    A string is called palindrome if it reads the same backward as forward.
    You should return a tuple containing the result string and True/False for the check.
    Example
    For s = "abcde", c = "ae", the result should be ('bcd',False)
    For s = "abcdef", c = "b"  the result should be ('acdef',False)
    For s = "abcdedcba", c = "ab", the result should be ('cdedc',True)
    """

    s = ''.join([char for char in s if char not in c])
    return (s,s[::-1] == s)


# Generated test cases:
import pytest


class TestReverseDelete:
    
    def test_empty_string(self):
        from test_humaneval_112_ast import reverse_delete
        result = reverse_delete("", "")
        assert result == ("", True)
    
    def test_empty_delete_chars(self):
        result = reverse_delete("abc", "")
        assert result == ("abc", False)
    
    def test_empty_delete_chars_palindrome(self):
        result = reverse_delete("aba", "")
        assert result == ("aba", True)
    
    def test_single_char_no_delete(self):
        result = reverse_delete("a", "b")
        assert result == ("a", True)
    
    def test_single_char_delete(self):
        result = reverse_delete("a", "a")
        assert result == ("", True)
    
    def test_all_chars_deleted(self):
        result = reverse_delete("aaa", "a")
        assert result == ("", True)
    
    def test_palindrome_no_deletion(self):
        result = reverse_delete("racecar", "")
        assert result == ("racecar", True)
    
    def test_non_palindrome_no_deletion(self):
        result = reverse_delete("hello", "")
        assert result == ("hello", False)
    
    def test_becomes_palindrome_after_deletion(self):
        result = reverse_delete("abcda", "d")
        assert result == ("abca", False)
    
    def test_becomes_non_palindrome_after_deletion(self):
        result = reverse_delete("abcd", "d")
        assert result == ("abc", False)
    
    def test_multiple_chars_to_delete(self):
        result = reverse_delete("abcdef", "ace")
        assert result == ("bdf", False)
    
    def test_delete_creates_empty_string(self):
        result = reverse_delete("aabbcc", "abc")
        assert result == ("", True)
    
    def test_delete_middle_chars(self):
        result = reverse_delete("abcba", "c")
        assert result == ("abba", True)
    
    def test_repeated_chars_palindrome(self):
        result = reverse_delete("aaaa", "")
        assert result == ("aaaa", True)
    
    def test_repeated_chars_partial_delete(self):
        result = reverse_delete("aaabbbccc", "b")
        assert result == ("aaaccc", False)
    
    def test_case_sensitive(self):
        result = reverse_delete("AaBbCc", "a")
        assert result == ("ABbCc", False)
    
    def test_special_chars_no_delete(self):
        result = reverse_delete("a!b!a", "")
        assert result == ("a!b!a", True)
    
    def test_special_chars_delete(self):
        result = reverse_delete("a!b!a", "!")
        assert result == ("aba", True)
    
    def test_numbers_in_string(self):
        result = reverse_delete("12321", "")
        assert result == ("12321", True)
    
    def test_numbers_delete(self):
        result = reverse_delete("1a2a1", "2")
        assert result == ("1aa1", True)
    
    def test_spaces_in_string(self):
        result = reverse_delete("a b a", " ")
        assert result == ("aba", True)
    
    def test_long_palindrome(self):
        result = reverse_delete("abcdefedcba", "")
        assert result == ("abcdefedcba", True)
    
    def test_long_non_palindrome(self):
        result = reverse_delete("abcdefghijk", "")
        assert result == ("abcdefghijk", False)
    
    def test_delete_all_but_one(self):
        result = reverse_delete("aaabbbccc", "abc")
        assert result == ("", True)
    
    def test_delete_chars_not_in_string(self):
        result = reverse_delete("abc", "xyz")
        assert result == ("abc", False)
    
    def test_mixed_case_palindrome(self):
        result = reverse_delete("AaBbAa", "")
        assert result == ("AaBbAa", False)
    
    def test_whitespace_chars(self):
        result = reverse_delete("a b c b a", " ")
        assert result == ("abcba", True)
    
    def test_newline_chars(self):
        result = reverse_delete("a\nb\na", "\n")
        assert result == ("aba", True)
    
    def test_tab_chars(self):
        result = reverse_delete("a\tb\ta", "\t")
        assert result == ("aba", True)


def reverse_delete(s, c):
    s = ''.join([char for char in s if char not in c])
    return (s, s[::-1] == s)


@pytest.mark.parametrize("s,c,expected", [
    ("", "", ("", True)),
    ("a", "", ("a", True)),
    ("ab", "", ("ab", False)),
    ("aa", "", ("aa", True)),
    ("abc", "a", ("bc", False)),
    ("abc", "abc", ("", True)),
    ("abcba", "", ("abcba", True)),
    ("abcde", "ace", ("bd", False)),
    ("racecar", "e", ("raccar", True)),
    ("hello", "lo", ("he", False)),
    ("12321", "2", ("131", True)),
    ("aabbaa", "b", ("aaaa", True)),
])
def test_reverse_delete_parametrized(s, c, expected):
    result = reverse_delete(s, c)
    assert result == expected