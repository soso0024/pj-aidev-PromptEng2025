# Test cases for HumanEval/8
# Generated using Claude API

from typing import List, Tuple


def sum_product(numbers: List[int]) -> Tuple[int, int]:
    """ For a given list of integers, return a tuple consisting of a sum and a product of all the integers in a list.
    Empty sum should be equal to 0 and empty product should be equal to 1.
    >>> sum_product([])
    (0, 1)
    >>> sum_product([1, 2, 3, 4])
    (10, 24)
    """

    sum_value = 0
    prod_value = 1

    for n in numbers:
        sum_value += n
        prod_value *= n
    return sum_value, prod_value


# Generated test cases:
import pytest
from typing import List, Tuple


def sum_product(numbers: List[int]) -> Tuple[int, int]:
    sum_value = 0
    prod_value = 1

    for n in numbers:
        sum_value += n
        prod_value *= n
    return sum_value, prod_value


class TestSumProduct:
    def test_empty_list(self):
        assert sum_product([]) == (0, 1)

    def test_single_element(self):
        assert sum_product([5]) == (5, 5)

    def test_single_zero(self):
        assert sum_product([0]) == (0, 0)

    def test_two_elements(self):
        assert sum_product([2, 3]) == (5, 6)

    def test_multiple_elements(self):
        assert sum_product([1, 2, 3, 4]) == (10, 24)

    def test_with_negative_numbers(self):
        assert sum_product([-1, -2, -3]) == (-6, -6)

    def test_with_mixed_positive_negative(self):
        assert sum_product([1, -2, 3]) == (2, -6)

    def test_with_zeros(self):
        assert sum_product([1, 0, 3]) == (4, 0)

    def test_multiple_zeros(self):
        assert sum_product([0, 0, 0]) == (0, 0)

    def test_large_numbers(self):
        assert sum_product([100, 200, 300]) == (600, 6000000)

    def test_negative_and_zero(self):
        assert sum_product([-5, 0, 10]) == (5, 0)

    def test_all_ones(self):
        assert sum_product([1, 1, 1, 1]) == (4, 1)

    def test_all_negative_ones(self):
        assert sum_product([-1, -1, -1]) == (-3, -1)

    @pytest.mark.parametrize("numbers,expected", [
        ([], (0, 1)),
        ([1], (1, 1)),
        ([0], (0, 0)),
        ([1, 2], (3, 2)),
        ([1, 2, 3, 4], (10, 24)),
        ([-1, -2], (-3, 2)),
        ([2, 0, 5], (7, 0)),
        ([10, 20, 30], (60, 6000)),
    ])
    def test_parametrized_cases(self, numbers, expected):
        assert sum_product(numbers) == expected

    def test_return_type(self):
        result = sum_product([1, 2, 3])
        assert isinstance(result, tuple)
        assert len(result) == 2
        assert isinstance(result[0], int)
        assert isinstance(result[1], int)

    def test_long_list(self):
        numbers = list(range(1, 11))
        assert sum_product(numbers) == (55, 3628800)

    def test_negative_product_odd_negatives(self):
        assert sum_product([-1, 2, 3]) == (4, -6)

    def test_positive_product_even_negatives(self):
        assert sum_product([-1, -2, 3]) == (0, 6)
