# Test cases for HumanEval/130
# Generated using Claude API


def tri(n):
    """Everyone knows Fibonacci sequence, it was studied deeply by mathematicians in 
    the last couple centuries. However, what people don't know is Tribonacci sequence.
    Tribonacci sequence is defined by the recurrence:
    tri(1) = 3
    tri(n) = 1 + n / 2, if n is even.
    tri(n) =  tri(n - 1) + tri(n - 2) + tri(n + 1), if n is odd.
    For example:
    tri(2) = 1 + (2 / 2) = 2
    tri(4) = 3
    tri(3) = tri(2) + tri(1) + tri(4)
           = 2 + 3 + 3 = 8 
    You are given a non-negative integer number n, you have to a return a list of the 
    first n + 1 numbers of the Tribonacci sequence.
    Examples:
    tri(3) = [1, 3, 2, 8]
    """

    if n == 0:
        return [1]
    my_tri = [1, 3]
    for i in range(2, n + 1):
        if i % 2 == 0:
            my_tri.append(i / 2 + 1)
        else:
            my_tri.append(my_tri[i - 1] + my_tri[i - 2] + (i + 3) / 2)
    return my_tri


# Generated test cases:
import pytest


def tri(n):
    if n == 0:
        return [1]
    my_tri = [1, 3]
    for i in range(2, n + 1):
        if i % 2 == 0:
            my_tri.append(i / 2 + 1)
        else:
            my_tri.append(my_tri[i - 1] + my_tri[i - 2] + (i + 3) / 2)
    return my_tri


class TestTri:
    
    def test_tri_zero(self):
        assert tri(0) == [1]
    
    def test_tri_one(self):
        assert tri(1) == [1, 3]
    
    def test_tri_two(self):
        assert tri(2) == [1, 3, 2]
    
    def test_tri_three(self):
        assert tri(3) == [1, 3, 2, 8]
    
    def test_tri_four(self):
        result = tri(4)
        assert result == [1, 3, 2, 8, 3]
    
    def test_tri_five(self):
        result = tri(5)
        assert len(result) == 6
        assert result[0] == 1
        assert result[1] == 3
        assert result[2] == 2
        assert result[3] == 8
        assert result[4] == 3
        assert result[5] == 15.0
    
    def test_tri_six(self):
        result = tri(6)
        assert len(result) == 7
        assert result[0] == 1
        assert result[1] == 3
        assert result[2] == 2
        assert result[3] == 8
        assert result[4] == 3
        assert result[5] == 15.0
        assert result[6] == 4
    
    def test_tri_ten(self):
        result = tri(10)
        assert len(result) == 11
        assert result[0] == 1
        assert result[1] == 3
        assert result[2] == 2
        assert result[3] == 8
    
    def test_tri_returns_list(self):
        result = tri(5)
        assert isinstance(result, list)
    
    def test_tri_length(self):
        assert len(tri(0)) == 1
        assert len(tri(1)) == 2
        assert len(tri(2)) == 3
        assert len(tri(3)) == 4
        assert len(tri(5)) == 6
        assert len(tri(10)) == 11
    
    def test_tri_even_indices(self):
        result = tri(8)
        assert result[2] == 2
        assert result[4] == 3
        assert result[6] == 4
        assert result[8] == 5
    
    def test_tri_first_elements(self):
        result = tri(7)
        assert result[0] == 1
        assert result[1] == 3
    
    def test_tri_large_n(self):
        result = tri(20)
        assert len(result) == 21
        assert result[0] == 1
        assert result[1] == 3
    
    @pytest.mark.parametrize("n,expected_length", [
        (0, 1),
        (1, 2),
        (2, 3),
        (3, 4),
        (4, 5),
        (5, 6),
        (10, 11),
        (15, 16),
    ])
    def test_tri_length_parametrized(self, n, expected_length):
        assert len(tri(n)) == expected_length
    
    @pytest.mark.parametrize("n,first_elements", [
        (0, [1]),
        (1, [1, 3]),
        (2, [1, 3, 2]),
        (3, [1, 3, 2, 8]),
        (4, [1, 3, 2, 8, 3]),
    ])
    def test_tri_values_parametrized(self, n, first_elements):
        result = tri(n)
        assert result == first_elements
    
    def test_tri_contains_floats_and_ints(self):
        result = tri(5)
        assert any(isinstance(x, float) for x in result)
    
    def test_tri_odd_index_calculation(self):
        result = tri(7)
        assert result[5] == result[4] + result[3] + (5 + 3) / 2
        assert result[7] == result[6] + result[5] + (7 + 3) / 2