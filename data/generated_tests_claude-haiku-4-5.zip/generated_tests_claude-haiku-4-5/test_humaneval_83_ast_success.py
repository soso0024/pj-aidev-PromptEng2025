# Test cases for HumanEval/83
# Generated using Claude API


def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """

    if n == 1: return 1
    return 18 * (10 ** (n - 2))


# Generated test cases:
import pytest


def starts_one_ends(n):
    if n == 1: return 1
    return 18 * (10 ** (n - 2))


class TestStartsOneEnds:
    
    @pytest.mark.parametrize("n,expected", [
        (1, 1),
        (2, 18),
        (3, 180),
        (4, 1800),
        (5, 18000),
        (6, 180000),
        (7, 1800000),
        (8, 18000000),
        (9, 180000000),
        (10, 1800000000),
    ])
    def test_starts_one_ends_valid_inputs(self, n, expected):
        assert starts_one_ends(n) == expected
    
    def test_starts_one_ends_n_equals_1(self):
        assert starts_one_ends(1) == 1
    
    def test_starts_one_ends_n_equals_2(self):
        assert starts_one_ends(2) == 18
    
    def test_starts_one_ends_n_equals_3(self):
        assert starts_one_ends(3) == 180
    
    def test_starts_one_ends_large_n(self):
        result = starts_one_ends(15)
        assert result == 18 * (10 ** 13)
    
    def test_starts_one_ends_returns_integer(self):
        result = starts_one_ends(5)
        assert isinstance(result, int)
    
    def test_starts_one_ends_positive_result(self):
        for n in range(1, 11):
            assert starts_one_ends(n) > 0
    
    def test_starts_one_ends_growth_pattern(self):
        prev = starts_one_ends(1)
        for n in range(2, 8):
            current = starts_one_ends(n)
            assert current > prev
            prev = current
    
    def test_starts_one_ends_formula_verification(self):
        for n in range(2, 10):
            expected = 18 * (10 ** (n - 2))
            assert starts_one_ends(n) == expected
    
    def test_starts_one_ends_n_equals_20(self):
        result = starts_one_ends(20)
        assert result == 18 * (10 ** 18)
    
    def test_starts_one_ends_divisibility(self):
        for n in range(2, 8):
            result = starts_one_ends(n)
            assert result % 18 == 0
    
    def test_starts_one_ends_specific_values(self):
        assert starts_one_ends(1) == 1
        assert starts_one_ends(2) == 18
        assert starts_one_ends(3) == 180
        assert starts_one_ends(4) == 1800
        assert starts_one_ends(5) == 18000
