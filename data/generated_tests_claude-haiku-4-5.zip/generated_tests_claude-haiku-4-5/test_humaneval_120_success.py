# Test cases for HumanEval/120
# Generated using Claude API


def maximum(arr, k):
    """
    Given an array arr of integers and a positive integer k, return a sorted list 
    of length k with the maximum k numbers in arr.

    Example 1:

        Input: arr = [-3, -4, 5], k = 3
        Output: [-4, -3, 5]

    Example 2:

        Input: arr = [4, -4, 4], k = 2
        Output: [4, 4]

    Example 3:

        Input: arr = [-3, 2, 1, 2, -1, -2, 1], k = 1
        Output: [2]

    Note:
        1. The length of the array will be in the range of [1, 1000].
        2. The elements in the array will be in the range of [-1000, 1000].
        3. 0 <= k <= len(arr)
    """

    if k == 0:
        return []
    arr.sort()
    ans = arr[-k:]
    return ans


# Generated test cases:
import pytest


class TestMaximum:
    def test_empty_array(self):
        from test_humaneval_120 import maximum
        assert maximum([], 0) == []

    def test_k_zero(self):
        assert maximum([1, 2, 3, 4, 5], 0) == []

    def test_k_equals_array_length(self):
        assert maximum([1, 2, 3, 4, 5], 5) == [1, 2, 3, 4, 5]

    def test_k_less_than_array_length(self):
        assert maximum([1, 2, 3, 4, 5], 3) == [3, 4, 5]

    def test_k_one(self):
        assert maximum([1, 2, 3, 4, 5], 1) == [5]

    def test_unsorted_array(self):
        assert maximum([5, 2, 8, 1, 9], 3) == [5, 8, 9]

    def test_negative_numbers(self):
        assert maximum([-5, -2, -8, -1, -9], 3) == [-5, -2, -1]

    def test_mixed_positive_negative(self):
        assert maximum([-5, 2, -8, 1, 9], 3) == [1, 2, 9]

    def test_duplicate_elements(self):
        assert maximum([1, 2, 2, 3, 3, 3], 3) == [3, 3, 3]

    def test_all_same_elements(self):
        assert maximum([5, 5, 5, 5], 2) == [5, 5]

    def test_single_element_array(self):
        assert maximum([42], 1) == [42]

    def test_single_element_k_zero(self):
        assert maximum([42], 0) == []

    def test_large_array(self):
        arr = list(range(1, 101))
        result = maximum(arr, 10)
        assert result == list(range(91, 101))

    def test_floats(self):
        assert maximum([1.5, 2.3, 0.1, 3.7], 2) == [2.3, 3.7]

    def test_negative_k_behavior(self):
        result = maximum([1, 2, 3, 4, 5], -1)
        assert result == [2, 3, 4, 5]

    def test_k_greater_than_array_length(self):
        result = maximum([1, 2, 3], 10)
        assert result == [1, 2, 3]

    def test_array_with_zeros(self):
        assert maximum([0, 0, 1, 2, 3], 3) == [1, 2, 3]

    def test_array_with_negative_zero(self):
        assert maximum([-0, 0, 1, 2], 2) == [1, 2]

    @pytest.mark.parametrize("arr,k,expected", [
        ([1, 2, 3], 1, [3]),
        ([5, 4, 3, 2, 1], 2, [4, 5]),
        ([10, 20, 30], 3, [10, 20, 30]),
        ([-1, -2, -3], 2, [-2, -1]),
        ([100], 1, [100]),
    ])
    def test_parametrized_cases(self, arr, k, expected):
        assert maximum(arr, k) == expected

    def test_return_type_is_list(self):
        result = maximum([1, 2, 3], 2)
        assert isinstance(result, list)

    def test_return_type_empty_list(self):
        result = maximum([1, 2, 3], 0)
        assert isinstance(result, list)
        assert len(result) == 0