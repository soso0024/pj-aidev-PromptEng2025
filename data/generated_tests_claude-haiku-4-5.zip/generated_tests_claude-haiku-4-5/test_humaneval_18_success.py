# Test cases for HumanEval/18
# Generated using Claude API



def how_many_times(string: str, substring: str) -> int:
    """ Find how many times a given substring can be found in the original string. Count overlaping cases.
    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """

    times = 0

    for i in range(len(string) - len(substring) + 1):
        if string[i:i+len(substring)] == substring:
            times += 1

    return times


# Generated test cases:
import pytest


def how_many_times(string: str, substring: str) -> int:
    times = 0

    for i in range(len(string) - len(substring) + 1):
        if string[i:i+len(substring)] == substring:
            times += 1

    return times


class TestHowManyTimes:
    
    @pytest.mark.parametrize("string,substring,expected", [
        ("hello world", "o", 2),
        ("aaaa", "aa", 3),
        ("abcabcabc", "abc", 3),
        ("test", "test", 1),
        ("", "", 1),
        ("hello", "", 6),
        ("a", "a", 1),
        ("abc", "xyz", 0),
        ("mississippi", "ss", 2),
        ("mississippi", "i", 4),
        ("the quick brown fox", " ", 3),
        ("aaa", "a", 3),
        ("aaa", "aa", 2),
        ("aaa", "aaa", 1),
        ("abab", "ab", 2),
        ("ababab", "ab", 3),
        ("ababab", "abab", 2),
        ("xyz", "abc", 0),
        ("a", "ab", 0),
        ("ab", "a", 1),
        ("ab", "b", 1),
        ("ab", "ab", 1),
        ("aabbaa", "aa", 2),
        ("aabbaa", "ab", 1),
        ("aabbaa", "ba", 1),
        ("aabbaa", "bb", 1),
        ("111111", "11", 5),
        ("111111", "111", 4),
        ("abcdefghijklmnopqrstuvwxyz", "z", 1),
        ("abcdefghijklmnopqrstuvwxyz", "a", 1),
        ("abcdefghijklmnopqrstuvwxyz", "abc", 1),
        ("the the the", "the", 3),
        ("oooo", "oo", 3),
        ("oooo", "ooo", 2),
        ("oooo", "oooo", 1),
        ("x", "x", 1),
        ("x", "y", 0),
        ("xy", "xy", 1),
        ("xy", "yx", 0),
        ("abcabc", "cab", 1),
        ("abcabcabc", "cab", 2),
        ("aabbccdd", "bb", 1),
        ("aabbccdd", "cc", 1),
        ("aabbccdd", "dd", 1),
        ("aabbccdd", "aa", 1),
        ("aabbccdd", "bc", 1),
        ("aabbccdd", "cd", 1),
        ("aabbccdd", "abcd", 0),
        ("pattern pattern pattern", "pattern", 3),
        ("aabaab", "aab", 2),
        ("aabaab", "aba", 1),
        ("aabaab", "baa", 1),
    ])
    def test_how_many_times(self, string, substring, expected):
        assert how_many_times(string, substring) == expected
    
    def test_empty_string_empty_substring(self):
        assert how_many_times("", "") == 1
    
    def test_empty_substring_nonempty_string(self):
        result = how_many_times("hello", "")
        assert result == len("hello") + 1
    
    def test_substring_longer_than_string(self):
        assert how_many_times("hi", "hello") == 0
    
    def test_single_character_match(self):
        assert how_many_times("a", "a") == 1
    
    def test_single_character_no_match(self):
        assert how_many_times("a", "b") == 0
    
    def test_overlapping_occurrences(self):
        assert how_many_times("aaa", "aa") == 2
    
    def test_non_overlapping_occurrences(self):
        assert how_many_times("abab", "ab") == 2
    
    def test_case_sensitive(self):
        assert how_many_times("Hello", "hello") == 0
    
    def test_case_sensitive_match(self):
        assert how_many_times("Hello", "Hello") == 1
    
    def test_special_characters(self):
        assert how_many_times("!@#!@#", "!@#") == 2
    
    def test_spaces_in_substring(self):
        assert how_many_times("a b a b", " ") == 3
    
    def test_numeric_strings(self):
        assert how_many_times("123123123", "123") == 3
    
    def test_repeated_pattern(self):
        assert how_many_times("ababababab", "ab") == 5
    
    def test_no_occurrences(self):
        assert how_many_times("abcdef", "xyz") == 0
    
    def test_entire_string_is_substring(self):
        assert how_many_times("test", "test") == 1
    
    def test_substring_at_start(self):
        assert how_many_times("hello world", "hello") == 1
    
    def test_substring_at_end(self):
        assert how_many_times("hello world", "world") == 1
    
    def test_substring_in_middle(self):
        assert how_many_times("hello world", "lo wo") == 1
