# Test cases for HumanEval/12
# Generated using Claude API

from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    """ Out of list of strings, return the longest one. Return the first one in case of multiple
    strings of the same length. Return None in case the input list is empty.
    >>> longest([])

    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    """

    if not strings:
        return None

    maxlen = max(len(x) for x in strings)
    for s in strings:
        if len(s) == maxlen:
            return s


# Generated test cases:
import pytest
from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    if not strings:
        return None

    maxlen = max(len(x) for x in strings)
    for s in strings:
        if len(s) == maxlen:
            return s


class TestLongest:
    def test_empty_list(self):
        assert longest([]) is None

    def test_single_string(self):
        assert longest(["hello"]) == "hello"

    def test_single_character_strings(self):
        assert longest(["a", "b", "c"]) == "a"

    def test_multiple_strings_different_lengths(self):
        assert longest(["a", "bb", "ccc"]) == "ccc"

    def test_multiple_strings_same_length(self):
        result = longest(["abc", "def", "ghi"])
        assert result == "abc"

    def test_longest_in_middle(self):
        assert longest(["a", "bb", "ccc", "dd", "e"]) == "ccc"

    def test_longest_at_end(self):
        assert longest(["a", "bb", "ccc"]) == "ccc"

    def test_longest_at_beginning(self):
        assert longest(["ccc", "bb", "a"]) == "ccc"

    def test_empty_strings_in_list(self):
        assert longest(["", "a", "bb"]) == "bb"

    def test_all_empty_strings(self):
        result = longest(["", "", ""])
        assert result == ""

    def test_one_empty_one_nonempty(self):
        assert longest(["", "hello"]) == "hello"

    def test_very_long_string(self):
        long_str = "a" * 10000
        assert longest([long_str, "short"]) == long_str

    def test_unicode_strings(self):
        result = longest(["café", "naïve", "résumé"])
        assert result in ["café", "naïve", "résumé"]
        assert len(result) == 6

    def test_strings_with_spaces(self):
        assert longest(["hello world", "hi", "test"]) == "hello world"

    def test_strings_with_special_characters(self):
        assert longest(["!@#$%", "abc", "12345"]) == "!@#$%"

    def test_duplicate_longest_strings(self):
        result = longest(["aaa", "bbb", "cc"])
        assert result in ["aaa", "bbb"]

    def test_two_strings_first_longer(self):
        assert longest(["longer", "short"]) == "longer"

    def test_two_strings_second_longer(self):
        assert longest(["short", "longer"]) == "longer"

    def test_two_strings_equal_length(self):
        assert longest(["abc", "def"]) == "abc"

    def test_numeric_strings(self):
        assert longest(["1", "22", "333"]) == "333"

    def test_mixed_case_strings(self):
        assert longest(["ABC", "def", "GhIjK"]) == "GhIjK"

    def test_newline_in_strings(self):
        assert longest(["a\nb", "cd", "efgh"]) == "efgh"

    def test_tab_in_strings(self):
        assert longest(["a\tb", "cd", "efgh"]) == "efgh"

    @pytest.mark.parametrize("input_list,expected", [
        (["a"], "a"),
        (["ab", "cd"], "ab"),
        (["x", "yy", "zzz"], "zzz"),
        (["test", "testing"], "testing"),
        (["", "a"], "a"),
    ])
    def test_parametrized_cases(self, input_list, expected):
        assert longest(input_list) == expected

    def test_returns_first_occurrence_of_max_length(self):
        strings = ["aa", "bb", "cc"]
        result = longest(strings)
        assert result == "aa"
        assert len(result) == 2

    def test_large_list_of_strings(self):
        strings = ["a"] * 1000 + ["b" * 10]
        assert longest(strings) == "b" * 10

    def test_strings_with_only_spaces(self):
        assert longest(["   ", "  ", " "]) == "   "