# Test cases for HumanEval/117
# Generated using Claude API


def select_words(s, n):
    """Given a string s and a natural number n, you have been tasked to implement 
    a function that returns a list of all words from string s that contain exactly 
    n consonants, in order these words appear in the string s.
    If the string s is empty then the function should return an empty list.
    Note: you may assume the input string contains only letters and spaces.
    Examples:
    select_words("Mary had a little lamb", 4) ==> ["little"]
    select_words("Mary had a little lamb", 3) ==> ["Mary", "lamb"]
    select_words("simple white space", 2) ==> []
    select_words("Hello world", 4) ==> ["world"]
    select_words("Uncle sam", 3) ==> ["Uncle"]
    """

    result = []
    for word in s.split():
        n_consonants = 0
        for i in range(0, len(word)):
            if word[i].lower() not in ["a","e","i","o","u"]:
                n_consonants += 1 
        if n_consonants == n:
            result.append(word)
    return result



# Generated test cases:
import pytest


class TestSelectWords:
    
    def test_empty_string(self):
        from test_humaneval_117_ast import select_words
        assert select_words("", 0) == []
    
    def test_empty_string_with_n(self):
        assert select_words("", 5) == []
    
    def test_single_word_no_consonants(self):
        assert select_words("aeiou", 0) == ["aeiou"]
    
    def test_single_word_all_consonants(self):
        assert select_words("bcdfg", 5) == ["bcdfg"]
    
    def test_single_word_mixed(self):
        assert select_words("hello", 3) == ["hello"]
    
    def test_single_word_no_match(self):
        assert select_words("hello", 2) == []
    
    def test_multiple_words_all_match(self):
        assert select_words("hello world", 3) == ["hello"]
    
    def test_multiple_words_partial_match(self):
        assert select_words("hello world test", 3) == ["hello", "test"]
    
    def test_multiple_words_no_match(self):
        assert select_words("hello world", 10) == []
    
    def test_uppercase_letters(self):
        assert select_words("HELLO WORLD", 3) == ["HELLO"]
    
    def test_mixed_case(self):
        assert select_words("HeLLo WoRLd", 3) == ["HeLLo"]
    
    def test_single_consonant_word(self):
        assert select_words("b", 1) == ["b"]
    
    def test_single_vowel_word(self):
        assert select_words("a", 0) == ["a"]
    
    def test_n_equals_zero_vowel_only(self):
        assert select_words("aaa eee iii", 0) == ["aaa", "eee", "iii"]
    
    def test_n_equals_zero_with_consonants(self):
        assert select_words("aaa bbb eee", 0) == ["aaa", "eee"]
    
    def test_words_with_numbers_and_special_chars(self):
        result = select_words("test123 hello-world", 3)
        assert "test123" not in result
    
    def test_extra_spaces(self):
        assert select_words("hello  world", 3) == ["hello"]
    
    def test_tabs_and_newlines(self):
        result = select_words("hello\tworld\ntest", 3)
        assert len(result) == 2
        assert "hello" in result
        assert "test" in result
    
    def test_long_word_many_consonants(self):
        assert select_words("strengths", 8) == ["strengths"]
    
    def test_long_word_many_consonants_no_match(self):
        assert select_words("strengths", 7) == []
    
    def test_all_vowels_word(self):
        assert select_words("aeiou", 0) == ["aeiou"]
    
    def test_all_consonants_word(self):
        assert select_words("bcdfghjklmnpqrstvwxyz", 21) == ["bcdfghjklmnpqrstvwxyz"]
    
    def test_y_is_consonant(self):
        assert select_words("yes", 2) == ["yes"]
    
    def test_multiple_same_words(self):
        assert select_words("hello hello hello", 3) == ["hello", "hello", "hello"]
    
    def test_single_letter_words(self):
        assert select_words("a b c d e", 1) == ["b", "c", "d"]
    
    def test_single_letter_words_vowels(self):
        assert select_words("a e i o u", 0) == ["a", "e", "i", "o", "u"]
    
    def test_complex_sentence(self):
        result = select_words("The quick brown fox jumps", 3)
        assert "quick" in result
    
    def test_n_larger_than_word_length(self):
        assert select_words("hi", 5) == []
    
    def test_zero_consonants_requirement(self):
        assert select_words("aaa bbb ccc", 0) == ["aaa"]
    
    @pytest.mark.parametrize("s,n,expected", [
        ("hello world", 3, ["hello"]),
        ("test", 3, ["test"]),
        ("aeiou", 0, ["aeiou"]),
        ("bcdfg", 5, ["bcdfg"]),
        ("", 0, []),
        ("a e i o u", 0, ["a", "e", "i", "o", "u"]),
        ("b c d f g", 1, ["b", "c", "d", "f", "g"]),
        ("hello", 4, []),
        ("HELLO", 3, ["HELLO"]),
        ("HeLLo", 3, ["HeLLo"]),
    ])
    def test_parametrized_cases(self, s, n, expected):
        assert select_words(s, n) == expected


if __name__ == "__main__":
    pytest.main([__file__, "-v"])