# Test cases for HumanEval/157
# Generated using Claude API


def right_angle_triangle(a, b, c):
    '''
    Given the lengths of the three sides of a triangle. Return True if the three
    sides form a right-angled triangle, False otherwise.
    A right-angled triangle is a triangle in which one angle is right angle or 
    90 degree.
    Example:
    right_angle_triangle(3, 4, 5) == True
    right_angle_triangle(1, 2, 3) == False
    '''

    return a*a == b*b + c*c or b*b == a*a + c*c or c*c == a*a + b*b


# Generated test cases:
import pytest


def right_angle_triangle(a, b, c):
    return a*a == b*b + c*c or b*b == a*a + c*c or c*c == a*a + b*b


class TestRightAngleTriangle:
    
    @pytest.mark.parametrize("a,b,c,expected", [
        (3, 4, 5, True),
        (5, 4, 3, True),
        (4, 3, 5, True),
        (5, 3, 4, True),
        (1, 2, 3, False),
        (2, 3, 4, False),
        (1, 1, 1, False),
        (5, 12, 13, True),
        (13, 12, 5, True),
        (8, 15, 17, True),
        (7, 24, 25, True),
        (6, 8, 10, True),
        (9, 12, 15, True),
        (20, 21, 29, True),
        (1, 1, 2, False),
        (2, 2, 3, False),
        (10, 10, 10, False),
    ])
    def test_right_angle_triangle_various_cases(self, a, b, c, expected):
        assert right_angle_triangle(a, b, c) == expected
    
    def test_right_angle_triangle_classic_3_4_5(self):
        assert right_angle_triangle(3, 4, 5) is True
    
    def test_right_angle_triangle_not_right_angle(self):
        assert right_angle_triangle(1, 2, 3) is False
    
    def test_right_angle_triangle_with_floats(self):
        assert right_angle_triangle(3.0, 4.0, 5.0) is True
    
    def test_right_angle_triangle_with_floats_not_right_angle(self):
        assert right_angle_triangle(1.5, 2.5, 3.5) is False
    
    def test_right_angle_triangle_zero_sides(self):
        assert right_angle_triangle(0, 0, 0) is True
    
    def test_right_angle_triangle_one_zero_side(self):
        assert right_angle_triangle(0, 0, 5) is False
    
    def test_right_angle_triangle_large_numbers(self):
        assert right_angle_triangle(300, 400, 500) is True
    
    def test_right_angle_triangle_large_numbers_not_right_angle(self):
        assert right_angle_triangle(100, 200, 300) is False
    
    def test_right_angle_triangle_permutation_1(self):
        assert right_angle_triangle(5, 3, 4) is True
    
    def test_right_angle_triangle_permutation_2(self):
        assert right_angle_triangle(4, 5, 3) is True
    
    def test_right_angle_triangle_permutation_3(self):
        assert right_angle_triangle(3, 5, 4) is True
    
    def test_right_angle_triangle_5_12_13(self):
        assert right_angle_triangle(5, 12, 13) is True
    
    def test_right_angle_triangle_8_15_17(self):
        assert right_angle_triangle(8, 15, 17) is True
    
    def test_right_angle_triangle_7_24_25(self):
        assert right_angle_triangle(7, 24, 25) is True
    
    def test_right_angle_triangle_negative_numbers(self):
        assert right_angle_triangle(-3, -4, -5) is True
    
    def test_right_angle_triangle_mixed_signs(self):
        assert right_angle_triangle(-3, 4, 5) is True
    
    def test_right_angle_triangle_very_small_numbers(self):
        assert right_angle_triangle(0.3, 0.4, 0.5) is True
    
    def test_right_angle_triangle_almost_right_angle(self):
        assert right_angle_triangle(3, 4, 5.1) is False
    
    def test_right_angle_triangle_single_side_zero(self):
        assert right_angle_triangle(5, 0, 5) is True
    
    def test_right_angle_triangle_two_sides_equal(self):
        assert right_angle_triangle(5, 5, 5) is False
    
    def test_right_angle_triangle_isosceles_right_angle(self):
        assert right_angle_triangle(1, 1, 1.414213562373095) is False