# Test cases for HumanEval/141
# Generated using Claude API


def file_name_check(file_name):
    """Create a function which takes a string representing a file's name, and returns
    'Yes' if the the file's name is valid, and returns 'No' otherwise.
    A file's name is considered to be valid if and only if all the following conditions 
    are met:
    - There should not be more than three digits ('0'-'9') in the file's name.
    - The file's name contains exactly one dot '.'
    - The substring before the dot should not be empty, and it starts with a letter from 
    the latin alphapet ('a'-'z' and 'A'-'Z').
    - The substring after the dot should be one of these: ['txt', 'exe', 'dll']
    Examples:
    file_name_check("example.txt") # => 'Yes'
    file_name_check("1example.dll") # => 'No' (the name should start with a latin alphapet letter)
    """

    suf = ['txt', 'exe', 'dll']
    lst = file_name.split(sep='.')
    if len(lst) != 2:
        return 'No'
    if not lst[1] in suf:
        return 'No'
    if len(lst[0]) == 0:
        return 'No'
    if not lst[0][0].isalpha():
        return 'No'
    t = len([x for x in lst[0] if x.isdigit()])
    if t > 3:
        return 'No'
    return 'Yes'


# Generated test cases:
import pytest


def file_name_check(file_name):
    suf = ['txt', 'exe', 'dll']
    lst = file_name.split(sep='.')
    if len(lst) != 2:
        return 'No'
    if not lst[1] in suf:
        return 'No'
    if len(lst[0]) == 0:
        return 'No'
    if not lst[0][0].isalpha():
        return 'No'
    t = len([x for x in lst[0] if x.isdigit()])
    if t > 3:
        return 'No'
    return 'Yes'


class TestFileNameCheck:
    
    @pytest.mark.parametrize("file_name,expected", [
        ("test.txt", "Yes"),
        ("file.exe", "Yes"),
        ("document.dll", "Yes"),
        ("a.txt", "Yes"),
        ("abc123.txt", "Yes"),
        ("file123.exe", "Yes"),
        ("doc12.dll", "Yes"),
        ("a1b2c3.txt", "Yes"),
    ])
    def test_valid_filenames(self, file_name, expected):
        assert file_name_check(file_name) == expected
    
    @pytest.mark.parametrize("file_name,expected", [
        ("test.pdf", "No"),
        ("file.doc", "No"),
        ("document.zip", "No"),
        ("test.jpg", "No"),
        ("file.py", "No"),
    ])
    def test_invalid_extension(self, file_name, expected):
        assert file_name_check(file_name) == expected
    
    @pytest.mark.parametrize("file_name,expected", [
        ("test", "No"),
        ("file.txt.bak", "No"),
        ("a.b.c", "No"),
        ("noextension", "No"),
    ])
    def test_invalid_format(self, file_name, expected):
        assert file_name_check(file_name) == expected
    
    @pytest.mark.parametrize("file_name,expected", [
        (".txt", "No"),
        (".exe", "No"),
        (".dll", "No"),
    ])
    def test_empty_filename(self, file_name, expected):
        assert file_name_check(file_name) == expected
    
    @pytest.mark.parametrize("file_name,expected", [
        ("1test.txt", "No"),
        ("_file.exe", "No"),
        ("@doc.dll", "No"),
        ("#test.txt", "No"),
        ("9file.exe", "No"),
    ])
    def test_non_alpha_start(self, file_name, expected):
        assert file_name_check(file_name) == expected
    
    @pytest.mark.parametrize("file_name,expected", [
        ("file1234.txt", "No"),
        ("test12345.exe", "No"),
        ("doc123456.dll", "No"),
        ("a1234.txt", "No"),
    ])
    def test_too_many_digits(self, file_name, expected):
        assert file_name_check(file_name) == expected
    
    @pytest.mark.parametrize("file_name,expected", [
        ("abc123def.txt", "Yes"),
        ("file1a2b3c.exe", "Yes"),
        ("doc1x2y3z.dll", "Yes"),
    ])
    def test_digits_mixed_with_letters(self, file_name, expected):
        assert file_name_check(file_name) == expected
    
    @pytest.mark.parametrize("file_name,expected", [
        ("A.txt", "Yes"),
        ("B.exe", "Yes"),
        ("C.dll", "Yes"),
        ("ABC.txt", "Yes"),
    ])
    def test_uppercase_start(self, file_name, expected):
        assert file_name_check(file_name) == expected
    
    @pytest.mark.parametrize("file_name,expected", [
        ("test123.txt", "Yes"),
        ("file12.exe", "Yes"),
        ("doc1.dll", "Yes"),
    ])
    def test_exactly_three_digits(self, file_name, expected):
        assert file_name_check(file_name) == expected
    
    @pytest.mark.parametrize("file_name,expected", [
        ("abcdefghijklmnop.txt", "Yes"),
        ("verylongfilename.exe", "Yes"),
        ("x.dll", "Yes"),
    ])
    def test_various_filename_lengths(self, file_name, expected):
        assert file_name_check(file_name) == expected
