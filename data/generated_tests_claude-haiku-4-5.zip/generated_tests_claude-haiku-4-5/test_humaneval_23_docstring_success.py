# Test cases for HumanEval/23
# Generated using Claude API



def strlen(string: str) -> int:
    """ Return length of given string
    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """

    return len(string)


# Generated test cases:
import pytest


def strlen(string: str) -> int:
    return len(string)


class TestStrlen:
    def test_empty_string(self):
        assert strlen('') == 0

    def test_single_character(self):
        assert strlen('a') == 1

    def test_multiple_characters(self):
        assert strlen('abc') == 3

    def test_long_string(self):
        assert strlen('abcdefghijklmnopqrstuvwxyz') == 26

    def test_string_with_spaces(self):
        assert strlen('hello world') == 11

    def test_string_with_numbers(self):
        assert strlen('123456') == 6

    def test_string_with_special_characters(self):
        assert strlen('!@#$%^&*()') == 10

    def test_string_with_mixed_content(self):
        assert strlen('Hello123!@#') == 11

    def test_string_with_newline(self):
        assert strlen('hello\nworld') == 11

    def test_string_with_tab(self):
        assert strlen('hello\tworld') == 11

    def test_string_with_unicode_characters(self):
        assert strlen('café') == 4

    def test_string_with_emoji(self):
        assert strlen('hello😀') == 6

    def test_string_with_multiple_spaces(self):
        assert strlen('   ') == 3

    def test_very_long_string(self):
        long_string = 'a' * 10000
        assert strlen(long_string) == 10000

    @pytest.mark.parametrize("input_str,expected", [
        ('', 0),
        ('a', 1),
        ('abc', 3),
        ('hello', 5),
        ('hello world', 11),
        ('123', 3),
        ('!@#', 3),
        ('   ', 3),
        ('a' * 100, 100),
    ])
    def test_parametrized_strlen(self, input_str, expected):
        assert strlen(input_str) == expected
