# Test cases for HumanEval/153
# Generated using Claude API


def Strongest_Extension(class_name, extensions):
    """You will be given the name of a class (a string) and a list of extensions.
    The extensions are to be used to load additional classes to the class. The
    strength of the extension is as follows: Let CAP be the number of the uppercase
    letters in the extension's name, and let SM be the number of lowercase letters 
    in the extension's name, the strength is given by the fraction CAP - SM. 
    You should find the strongest extension and return a string in this 
    format: ClassName.StrongestExtensionName.
    If there are two or more extensions with the same strength, you should
    choose the one that comes first in the list.
    For example, if you are given "Slices" as the class and a list of the
    extensions: ['SErviNGSliCes', 'Cheese', 'StuFfed'] then you should
    return 'Slices.SErviNGSliCes' since 'SErviNGSliCes' is the strongest extension 
    (its strength is -1).
    Example:
    for Strongest_Extension('my_class', ['AA', 'Be', 'CC']) == 'my_class.AA'
    """

    strong = extensions[0]
    my_val = len([x for x in extensions[0] if x.isalpha() and x.isupper()]) - len([x for x in extensions[0] if x.isalpha() and x.islower()])
    for s in extensions:
        val = len([x for x in s if x.isalpha() and x.isupper()]) - len([x for x in s if x.isalpha() and x.islower()])
        if val > my_val:
            strong = s
            my_val = val

    ans = class_name + "." + strong
    return ans



# Generated test cases:
import pytest


def Strongest_Extension(class_name, extensions):
    strong = extensions[0]
    my_val = len([x for x in extensions[0] if x.isalpha() and x.isupper()]) - len([x for x in extensions[0] if x.isalpha() and x.islower()])
    for s in extensions:
        val = len([x for x in s if x.isalpha() and x.isupper()]) - len([x for x in s if x.isalpha() and x.islower()])
        if val > my_val:
            strong = s
            my_val = val

    ans = class_name + "." + strong
    return ans


class TestStrongestExtension:
    
    def test_single_extension(self):
        result = Strongest_Extension("MyClass", ["Extension1"])
        assert result == "MyClass.Extension1"
    
    def test_multiple_extensions_uppercase_dominant(self):
        result = Strongest_Extension("Datastructures", ["SparseVector", "DictVector"])
        assert result == "Datastructures.DictVector"
    
    def test_multiple_extensions_mixed_case(self):
        result = Strongest_Extension("Base", ["abc", "ABC", "AbC"])
        assert result == "Base.ABC"
    
    def test_all_lowercase(self):
        result = Strongest_Extension("MyClass", ["abc", "def", "ghi"])
        assert result == "MyClass.abc"
    
    def test_all_uppercase(self):
        result = Strongest_Extension("MyClass", ["ABC", "DEF", "GHI"])
        assert result == "MyClass.ABC"
    
    def test_with_numbers_and_special_chars(self):
        result = Strongest_Extension("MyClass", ["Ext1", "ext2", "EXT3"])
        assert result == "MyClass.EXT3"
    
    def test_equal_strength_returns_first(self):
        result = Strongest_Extension("MyClass", ["ABC", "DEF", "GHI"])
        assert result == "MyClass.ABC"
    
    def test_negative_strength(self):
        result = Strongest_Extension("MyClass", ["aaa", "bbb", "ccc"])
        assert result == "MyClass.aaa"
    
    def test_mixed_strength_values(self):
        result = Strongest_Extension("MyClass", ["aB", "Ba", "AB"])
        assert result == "MyClass.AB"
    
    def test_extension_with_underscores(self):
        result = Strongest_Extension("MyClass", ["my_ext", "MY_EXT", "My_Ext"])
        assert result == "MyClass.MY_EXT"
    
    def test_extension_with_numbers_only(self):
        result = Strongest_Extension("MyClass", ["123", "456", "789"])
        assert result == "MyClass.123"
    
    def test_single_character_extensions(self):
        result = Strongest_Extension("MyClass", ["a", "B", "c"])
        assert result == "MyClass.B"
    
    def test_long_extension_names(self):
        result = Strongest_Extension("MyClass", ["VeryLongExtensionNameWithManyLetters", "verylongextensionnamewithmanyletters"])
        assert result == "MyClass.VeryLongExtensionNameWithManyLetters"
    
    def test_mixed_case_with_numbers(self):
        result = Strongest_Extension("MyClass", ["Ext1Name", "ext2name", "EXT3NAME"])
        assert result == "MyClass.EXT3NAME"
    
    def test_class_name_with_special_chars(self):
        result = Strongest_Extension("My_Class_123", ["ABC", "def"])
        assert result == "My_Class_123.ABC"
    
    def test_two_extensions_first_stronger(self):
        result = Strongest_Extension("MyClass", ["STRONG", "weak"])
        assert result == "MyClass.STRONG"
    
    def test_two_extensions_second_stronger(self):
        result = Strongest_Extension("MyClass", ["weak", "STRONG"])
        assert result == "MyClass.STRONG"
    
    def test_extension_with_spaces(self):
        result = Strongest_Extension("MyClass", ["My Ext", "MY EXT", "my ext"])
        assert result == "MyClass.MY EXT"
    
    def test_complex_mixed_case(self):
        result = Strongest_Extension("MyClass", ["AaBbCc", "aAbBcC", "AAbbcc"])
        assert result == "MyClass.AaBbCc"
    
    def test_strength_calculation_accuracy(self):
        result = Strongest_Extension("MyClass", ["aAbBcC", "AaBbCc"])
        assert result == "MyClass.aAbBcC"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])