# Test cases for HumanEval/127
# Generated using Claude API


def intersection(interval1, interval2):
    """You are given two intervals,
    where each interval is a pair of integers. For example, interval = (start, end) = (1, 2).
    The given intervals are closed which means that the interval (start, end)
    includes both start and end.
    For each given interval, it is assumed that its start is less or equal its end.
    Your task is to determine whether the length of intersection of these two 
    intervals is a prime number.
    Example, the intersection of the intervals (1, 3), (2, 4) is (2, 3)
    which its length is 1, which not a prime number.
    If the length of the intersection is a prime number, return "YES",
    otherwise, return "NO".
    If the two intervals don't intersect, return "NO".


    [input/output] samples:
    intersection((1, 2), (2, 3)) ==> "NO"
    intersection((-1, 1), (0, 4)) ==> "NO"
    intersection((-3, -1), (-5, 5)) ==> "YES"
    """

    def is_prime(num):
        if num == 1 or num == 0:
            return False
        if num == 2:
            return True
        for i in range(2, num):
            if num%i == 0:
                return False
        return True

    l = max(interval1[0], interval2[0])
    r = min(interval1[1], interval2[1])
    length = r - l
    if length > 0 and is_prime(length):
        return "YES"
    return "NO"


# Generated test cases:
import pytest


class TestIntersection:
    
    @pytest.mark.parametrize("interval1,interval2,expected", [
        ((1, 2), (2, 3), "NO"),
        ((-1, 1), (0, 4), "NO"),
        ((-3, -1), (-5, 5), "YES"),
    ])
    def test_docstring_examples(self, interval1, interval2, expected):
        from test_humaneval_127_docstring_ast import intersection
        assert intersection(interval1, interval2) == expected
    
    @pytest.mark.parametrize("interval1,interval2,expected", [
        ((1, 3), (2, 4), "NO"),
        ((1, 4), (2, 5), "YES"),
        ((1, 5), (3, 7), "YES"),
        ((0, 10), (5, 15), "YES"),
    ])
    def test_prime_length_intersections(self, interval1, interval2, expected):
        assert intersection(interval1, interval2) == expected
    
    @pytest.mark.parametrize("interval1,interval2,expected", [
        ((1, 2), (3, 4), "NO"),
        ((1, 3), (5, 7), "NO"),
        ((0, 1), (2, 3), "NO"),
    ])
    def test_no_intersection(self, interval1, interval2, expected):
        assert intersection(interval1, interval2) == expected
    
    @pytest.mark.parametrize("interval1,interval2,expected", [
        ((1, 2), (1, 2), "NO"),
        ((0, 5), (0, 5), "YES"),
        ((1, 4), (1, 4), "YES"),
    ])
    def test_identical_intervals(self, interval1, interval2, expected):
        assert intersection(interval1, interval2) == expected
    
    @pytest.mark.parametrize("interval1,interval2,expected", [
        ((1, 5), (2, 3), "NO"),
        ((0, 10), (3, 5), "YES"),
        ((1, 10), (4, 6), "YES"),
    ])
    def test_one_interval_contains_other(self, interval1, interval2, expected):
        assert intersection(interval1, interval2) == expected
    
    @pytest.mark.parametrize("interval1,interval2,expected", [
        ((-5, -1), (-3, 0), "YES"),
        ((-10, -5), (-8, -2), "YES"),
        ((-4, -1), (-6, 0), "YES"),
    ])
    def test_negative_intervals(self, interval1, interval2, expected):
        assert intersection(interval1, interval2) == expected
    
    @pytest.mark.parametrize("interval1,interval2,expected", [
        ((-2, 2), (-1, 1), "YES"),
        ((-5, 5), (-2, 2), "NO"),
        ((-3, 3), (-1, 2), "YES"),
    ])
    def test_mixed_sign_intervals(self, interval1, interval2, expected):
        assert intersection(interval1, interval2) == expected
    
    @pytest.mark.parametrize("interval1,interval2,expected", [
        ((0, 0), (0, 0), "NO"),
        ((5, 5), (5, 5), "NO"),
        ((0, 0), (0, 5), "NO"),
    ])
    def test_point_intervals(self, interval1, interval2, expected):
        assert intersection(interval1, interval2) == expected
    
    @pytest.mark.parametrize("interval1,interval2,expected", [
        ((1, 2), (2, 2), "NO"),
        ((1, 3), (3, 5), "NO"),
        ((0, 2), (2, 4), "NO"),
    ])
    def test_touching_intervals(self, interval1, interval2, expected):
        assert intersection(interval1, interval2) == expected
    
    @pytest.mark.parametrize("interval1,interval2,expected", [
        ((1, 100), (50, 55), "YES"),
        ((0, 1000), (500, 505), "YES"),
        ((1, 50), (25, 30), "YES"),
    ])
    def test_large_intervals(self, interval1, interval2, expected):
        assert intersection(interval1, interval2) == expected
    
    @pytest.mark.parametrize("interval1,interval2,expected", [
        ((1, 6), (2, 7), "NO"),
        ((1, 7), (3, 8), "NO"),
        ((2, 8), (4, 9), "NO"),
    ])
    def test_prime_length_2(self, interval1, interval2, expected):
        assert intersection(interval1, interval2) == expected
    
    @pytest.mark.parametrize("interval1,interval2,expected", [
        ((1, 8), (2, 9), "NO"),
        ((0, 10), (3, 10), "YES"),
        ((5, 15), (8, 15), "YES"),
    ])
    def test_prime_length_3(self, interval1, interval2, expected):
        assert intersection(interval1, interval2) == expected
    
    @pytest.mark.parametrize("interval1,interval2,expected", [
        ((1, 5), (2, 6), "YES"),
        ((0, 10), (3, 13), "YES"),
        ((1, 10), (4, 14), "NO"),
    ])
    def test_composite_length_4(self, interval1, interval2, expected):
        assert intersection(interval1, interval2) == expected
    
    @pytest.mark.parametrize("interval1,interval2,expected", [
        ((1, 6), (2, 7), "NO"),
        ((0, 5), (1, 6), "NO"),
        ((10, 15), (11, 16), "NO"),
    ])
    def test_prime_length_5(self, interval1, interval2, expected):
        assert intersection(interval1, interval2) == expected

    def test_return_type_is_string(self):
        result = intersection((1, 2), (2, 3))
        assert isinstance(result, str)
        assert result in ["YES", "NO"]

    def test_symmetry(self):
        assert intersection((1, 5), (2, 4)) == intersection((2, 4), (1, 5))
        assert intersection((0, 10), (5, 15)) == intersection((5, 15), (0, 10))