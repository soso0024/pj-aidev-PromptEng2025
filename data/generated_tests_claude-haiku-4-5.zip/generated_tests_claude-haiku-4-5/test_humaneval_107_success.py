# Test cases for HumanEval/107
# Generated using Claude API


def even_odd_palindrome(n):
    """
    Given a positive integer n, return a tuple that has the number of even and odd
    integer palindromes that fall within the range(1, n), inclusive.

    Example 1:

        Input: 3
        Output: (1, 2)
        Explanation:
        Integer palindrome are 1, 2, 3. one of them is even, and two of them are odd.

    Example 2:

        Input: 12
        Output: (4, 6)
        Explanation:
        Integer palindrome are 1, 2, 3, 4, 5, 6, 7, 8, 9, 11. four of them are even, and 6 of them are odd.

    Note:
        1. 1 <= n <= 10^3
        2. returned tuple has the number of even and odd integer palindromes respectively.
    """

    def is_palindrome(n):
        return str(n) == str(n)[::-1]

    even_palindrome_count = 0
    odd_palindrome_count = 0

    for i in range(1, n+1):
        if i%2 == 1 and is_palindrome(i):
                odd_palindrome_count += 1
        elif i%2 == 0 and is_palindrome(i):
            even_palindrome_count += 1
    return (even_palindrome_count, odd_palindrome_count)


# Generated test cases:
import pytest


def even_odd_palindrome(n):
    def is_palindrome(n):
        return str(n) == str(n)[::-1]

    even_palindrome_count = 0
    odd_palindrome_count = 0

    for i in range(1, n+1):
        if i%2 == 1 and is_palindrome(i):
                odd_palindrome_count += 1
        elif i%2 == 0 and is_palindrome(i):
            even_palindrome_count += 1
    return (even_palindrome_count, odd_palindrome_count)


class TestEvenOddPalindrome:
    
    def test_single_digit_one(self):
        assert even_odd_palindrome(1) == (0, 1)
    
    def test_single_digit_two(self):
        assert even_odd_palindrome(2) == (1, 1)
    
    def test_single_digit_nine(self):
        assert even_odd_palindrome(9) == (4, 5)
    
    def test_two_digits(self):
        assert even_odd_palindrome(10) == (4, 5)
    
    def test_two_digits_eleven(self):
        assert even_odd_palindrome(11) == (4, 6)
    
    def test_two_digits_twenty_two(self):
        assert even_odd_palindrome(22) == (5, 6)
    
    def test_three_digits(self):
        assert even_odd_palindrome(100) == (8, 10)
    
    def test_three_digits_101(self):
        assert even_odd_palindrome(101) == (8, 11)
    
    def test_larger_number(self):
        result = even_odd_palindrome(1000)
        assert isinstance(result, tuple)
        assert len(result) == 2
        assert result[0] >= 0
        assert result[1] >= 0
    
    def test_return_type_is_tuple(self):
        result = even_odd_palindrome(5)
        assert isinstance(result, tuple)
        assert len(result) == 2
    
    def test_return_values_are_integers(self):
        even_count, odd_count = even_odd_palindrome(10)
        assert isinstance(even_count, int)
        assert isinstance(odd_count, int)
    
    def test_counts_are_non_negative(self):
        even_count, odd_count = even_odd_palindrome(50)
        assert even_count >= 0
        assert odd_count >= 0
    
    def test_small_range_manual_verification(self):
        result = even_odd_palindrome(12)
        assert result == (4, 6)
    
    def test_palindromes_up_to_twenty(self):
        result = even_odd_palindrome(20)
        assert result[0] >= 1
        assert result[1] >= 1
    
    def test_large_number_consistency(self):
        result1 = even_odd_palindrome(100)
        result2 = even_odd_palindrome(100)
        assert result1 == result2
    
    def test_increasing_n_increases_counts(self):
        result1 = even_odd_palindrome(10)
        result2 = even_odd_palindrome(20)
        assert result2[0] >= result1[0]
        assert result2[1] >= result1[1]
    
    def test_n_equals_zero(self):
        assert even_odd_palindrome(0) == (0, 0)
    
    def test_single_digit_three(self):
        assert even_odd_palindrome(3) == (1, 2)
    
    def test_single_digit_four(self):
        assert even_odd_palindrome(4) == (2, 2)
    
    def test_single_digit_five(self):
        assert even_odd_palindrome(5) == (2, 3)
    
    def test_single_digit_six(self):
        assert even_odd_palindrome(6) == (3, 3)
    
    def test_single_digit_seven(self):
        assert even_odd_palindrome(7) == (3, 4)
    
    def test_single_digit_eight(self):
        assert even_odd_palindrome(8) == (4, 4)
    
    def test_range_up_to_thirty(self):
        result = even_odd_palindrome(30)
        assert result[0] >= 0
        assert result[1] >= 0
    
    def test_range_up_to_fifty(self):
        result = even_odd_palindrome(50)
        assert result[0] >= 0
        assert result[1] >= 0
    
    def test_range_up_to_one_hundred(self):
        result = even_odd_palindrome(100)
        assert result == (8, 10)
    
    def test_range_up_to_two_hundred(self):
        result = even_odd_palindrome(200)
        assert result[0] >= 8
        assert result[1] >= 10
    
    @pytest.mark.parametrize("n,expected", [
        (1, (0, 1)),
        (2, (1, 1)),
        (9, (4, 5)),
        (10, (4, 5)),
        (11, (4, 6)),
        (22, (5, 6)),
    ])
    def test_parametrized_cases(self, n, expected):
        assert even_odd_palindrome(n) == expected