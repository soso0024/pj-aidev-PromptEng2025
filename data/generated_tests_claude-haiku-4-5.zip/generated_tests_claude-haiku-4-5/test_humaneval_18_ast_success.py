# Test cases for HumanEval/18
# Generated using Claude API



def how_many_times(string: str, substring: str) -> int:
    """ Find how many times a given substring can be found in the original string. Count overlaping cases.
    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """

    times = 0

    for i in range(len(string) - len(substring) + 1):
        if string[i:i+len(substring)] == substring:
            times += 1

    return times


# Generated test cases:
import pytest


def how_many_times(string: str, substring: str) -> int:
    times = 0

    for i in range(len(string) - len(substring) + 1):
        if string[i:i+len(substring)] == substring:
            times += 1

    return times


class TestHowManyTimes:
    
    def test_basic_single_occurrence(self):
        assert how_many_times("hello world", "world") == 1
    
    def test_basic_multiple_occurrences(self):
        assert how_many_times("aaaa", "aa") == 3
    
    def test_no_occurrences(self):
        assert how_many_times("hello", "xyz") == 0
    
    def test_empty_substring(self):
        assert how_many_times("hello", "") == 6
    
    def test_empty_string(self):
        assert how_many_times("", "a") == 0
    
    def test_both_empty(self):
        assert how_many_times("", "") == 1
    
    def test_substring_equals_string(self):
        assert how_many_times("hello", "hello") == 1
    
    def test_substring_longer_than_string(self):
        assert how_many_times("hi", "hello") == 0
    
    def test_single_character_substring(self):
        assert how_many_times("mississippi", "i") == 4
    
    def test_single_character_string(self):
        assert how_many_times("a", "a") == 1
    
    def test_single_character_no_match(self):
        assert how_many_times("a", "b") == 0
    
    def test_overlapping_occurrences(self):
        assert how_many_times("aaa", "aa") == 2
    
    def test_overlapping_pattern(self):
        assert how_many_times("ababab", "ab") == 3
    
    def test_case_sensitive(self):
        assert how_many_times("Hello hello", "hello") == 1
    
    def test_repeated_pattern(self):
        assert how_many_times("abcabcabc", "abc") == 3
    
    def test_substring_at_start(self):
        assert how_many_times("hello world", "hello") == 1
    
    def test_substring_at_end(self):
        assert how_many_times("hello world", "world") == 1
    
    def test_substring_in_middle(self):
        assert how_many_times("hello world", "lo wo") == 1
    
    def test_spaces_in_substring(self):
        assert how_many_times("a b a b a b", " a ") == 2
    
    def test_special_characters(self):
        assert how_many_times("!@#!@#!@#", "!@#") == 3
    
    def test_numbers_as_string(self):
        assert how_many_times("123123123", "123") == 3
    
    def test_long_string_short_substring(self):
        assert how_many_times("a" * 1000 + "b" + "a" * 1000, "b") == 1
    
    def test_repeated_single_char(self):
        assert how_many_times("aaaaaaa", "a") == 7
    
    def test_no_overlap_pattern(self):
        assert how_many_times("abcdefabcdef", "abc") == 2
    
    def test_newline_characters(self):
        assert how_many_times("hello\nworld\nhello", "hello") == 2
    
    def test_tab_characters(self):
        assert how_many_times("a\tb\ta", "\t") == 2
    
    def test_unicode_characters(self):
        assert how_many_times("café café", "café") == 2
    
    def test_single_space(self):
        assert how_many_times("a b c d", " ") == 3
    
    def test_multiple_spaces(self):
        assert how_many_times("a  b  c", "  ") == 2
    
    def test_substring_one_char_less_than_string(self):
        assert how_many_times("abc", "ab") == 1
    
    def test_all_same_characters(self):
        assert how_many_times("aaaa", "a") == 4
    
    def test_pattern_with_numbers_and_letters(self):
        assert how_many_times("a1b2a1b2a1b2", "a1b2") == 3


@pytest.mark.parametrize("string,substring,expected", [
    ("hello", "l", 2),
    ("programming", "m", 2),
    ("test", "t", 2),
    ("mississippi", "ss", 2),
    ("bookkeeper", "o", 2),
    ("aabbcc", "bb", 1),
    ("xyxyxy", "xy", 3),
    ("abcabc", "cab", 1),
])
def test_parametrized_cases(string, substring, expected):
    assert how_many_times(string, substring) == expected
