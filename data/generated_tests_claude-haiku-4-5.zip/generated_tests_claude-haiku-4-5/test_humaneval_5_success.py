# Test cases for HumanEval/5
# Generated using Claude API

from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """ Insert a number 'delimeter' between every two consecutive elements of input list `numbers'
    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """

    if not numbers:
        return []

    result = []

    for n in numbers[:-1]:
        result.append(n)
        result.append(delimeter)

    result.append(numbers[-1])

    return result


# Generated test cases:
import pytest
from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    if not numbers:
        return []

    result = []

    for n in numbers[:-1]:
        result.append(n)
        result.append(delimeter)

    result.append(numbers[-1])

    return result


class TestIntersperse:
    def test_empty_list(self):
        assert intersperse([], 0) == []

    def test_single_element(self):
        assert intersperse([1], 0) == [1]

    def test_two_elements(self):
        assert intersperse([1, 2], 0) == [1, 0, 2]

    def test_multiple_elements(self):
        assert intersperse([1, 2, 3, 4], 0) == [1, 0, 2, 0, 3, 0, 4]

    def test_negative_delimiter(self):
        assert intersperse([1, 2, 3], -1) == [1, -1, 2, -1, 3]

    def test_negative_numbers(self):
        assert intersperse([-1, -2, -3], 0) == [-1, 0, -2, 0, -3]

    def test_zero_delimiter(self):
        assert intersperse([5, 10, 15], 0) == [5, 0, 10, 0, 15]

    def test_large_numbers(self):
        assert intersperse([1000, 2000, 3000], 999) == [1000, 999, 2000, 999, 3000]

    def test_delimiter_same_as_element(self):
        assert intersperse([1, 1, 1], 1) == [1, 1, 1, 1, 1]

    def test_mixed_positive_negative(self):
        assert intersperse([-5, 10, -3, 8], 0) == [-5, 0, 10, 0, -3, 0, 8]

    def test_large_list(self):
        input_list = list(range(1, 11))
        result = intersperse(input_list, 0)
        expected = [1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, 7, 0, 8, 0, 9, 0, 10]
        assert result == expected

    def test_delimiter_larger_than_elements(self):
        assert intersperse([1, 2, 3], 100) == [1, 100, 2, 100, 3]

    def test_all_zeros(self):
        assert intersperse([0, 0, 0], 0) == [0, 0, 0, 0, 0]

    def test_single_zero(self):
        assert intersperse([0], 5) == [0]

    def test_negative_delimiter_with_negative_numbers(self):
        assert intersperse([-1, -2, -3], -5) == [-1, -5, -2, -5, -3]

    @pytest.mark.parametrize("numbers,delimiter,expected", [
        ([1], 0, [1]),
        ([1, 2], 0, [1, 0, 2]),
        ([1, 2, 3], 5, [1, 5, 2, 5, 3]),
        ([], 0, []),
        ([10, 20, 30, 40], 99, [10, 99, 20, 99, 30, 99, 40]),
    ])
    def test_parametrized_cases(self, numbers, delimiter, expected):
        assert intersperse(numbers, delimiter) == expected

    def test_return_type_is_list(self):
        result = intersperse([1, 2, 3], 0)
        assert isinstance(result, list)

    def test_original_list_not_modified(self):
        original = [1, 2, 3]
        original_copy = original.copy()
        intersperse(original, 0)
        assert original == original_copy

    def test_result_length_calculation(self):
        input_list = [1, 2, 3, 4, 5]
        result = intersperse(input_list, 0)
        expected_length = len(input_list) * 2 - 1
        assert len(result) == expected_length
