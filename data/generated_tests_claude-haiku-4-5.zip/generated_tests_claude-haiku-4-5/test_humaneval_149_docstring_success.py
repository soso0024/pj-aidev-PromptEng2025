# Test cases for HumanEval/149
# Generated using Claude API


def sorted_list_sum(lst):
    """Write a function that accepts a list of strings as a parameter,
    deletes the strings that have odd lengths from it,
    and returns the resulted list with a sorted order,
    The list is always a list of strings and never an array of numbers,
    and it may contain duplicates.
    The order of the list should be ascending by length of each word, and you
    should return the list sorted by that rule.
    If two words have the same length, sort the list alphabetically.
    The function should return a list of strings in sorted order.
    You may assume that all words will have the same length.
    For example:
    assert list_sort(["aa", "a", "aaa"]) => ["aa"]
    assert list_sort(["ab", "a", "aaa", "cd"]) => ["ab", "cd"]
    """

    lst.sort()
    new_lst = []
    for i in lst:
        if len(i)%2 == 0:
            new_lst.append(i)
    return sorted(new_lst, key=len)


# Generated test cases:
import pytest


class TestSortedListSum:
    
    def sorted_list_sum(self, lst):
        lst.sort()
        new_lst = []
        for i in lst:
            if len(i)%2 == 0:
                new_lst.append(i)
        return sorted(new_lst, key=len)
    
    def test_basic_example_1(self):
        assert self.sorted_list_sum(["aa", "a", "aaa"]) == ["aa"]
    
    def test_basic_example_2(self):
        assert self.sorted_list_sum(["ab", "a", "aaa", "cd"]) == ["ab", "cd"]
    
    def test_empty_list(self):
        assert self.sorted_list_sum([]) == []
    
    def test_all_odd_lengths(self):
        assert self.sorted_list_sum(["a", "aaa", "aaaaa"]) == []
    
    def test_all_even_lengths(self):
        assert self.sorted_list_sum(["aa", "bb", "cc"]) == ["aa", "bb", "cc"]
    
    def test_single_even_length_word(self):
        assert self.sorted_list_sum(["ab"]) == ["ab"]
    
    def test_single_odd_length_word(self):
        assert self.sorted_list_sum(["abc"]) == []
    
    def test_duplicates_even_length(self):
        assert self.sorted_list_sum(["aa", "aa", "bb"]) == ["aa", "aa", "bb"]
    
    def test_duplicates_mixed(self):
        assert self.sorted_list_sum(["aa", "a", "aa", "aaa"]) == ["aa", "aa"]
    
    def test_alphabetical_sorting_same_length(self):
        assert self.sorted_list_sum(["cd", "ab", "ef"]) == ["ab", "cd", "ef"]
    
    def test_length_sorting_priority(self):
        assert self.sorted_list_sum(["abcd", "ab", "ef", "ghij"]) == ["ab", "ef", "abcd", "ghij"]
    
    def test_mixed_case_strings(self):
        assert self.sorted_list_sum(["Aa", "aa", "BB"]) == ["Aa", "BB", "aa"]
    
    def test_strings_with_numbers(self):
        assert self.sorted_list_sum(["a1", "12", "b2"]) == ["12", "a1", "b2"]
    
    def test_strings_with_special_characters(self):
        assert self.sorted_list_sum(["a!", "!!", "b@"]) == ["!!", "a!", "b@"]
    
    def test_long_even_length_strings(self):
        assert self.sorted_list_sum(["abcdefgh", "ijklmnop", "ab"]) == ["ab", "abcdefgh", "ijklmnop"]
    
    def test_long_odd_length_strings(self):
        assert self.sorted_list_sum(["abcdefg", "ijklmno", "a"]) == []
    
    def test_mixed_long_and_short(self):
        assert self.sorted_list_sum(["a", "ab", "abc", "abcd", "abcde", "abcdef"]) == ["ab", "abcd", "abcdef"]
    
    def test_whitespace_in_strings(self):
        result = self.sorted_list_sum(["a b", "cd", "e f g"])
        assert result == ["cd"]
    
    def test_empty_strings(self):
        assert self.sorted_list_sum(["", "aa", "a"]) == ["", "aa"]
    
    def test_only_empty_strings(self):
        assert self.sorted_list_sum(["", "", ""]) == ["", "", ""]
    
    @pytest.mark.parametrize("input_list,expected", [
        (["aa", "bb", "cc", "dd"], ["aa", "bb", "cc", "dd"]),
        (["a", "b", "c"], []),
        (["ab", "cd", "ef", "gh"], ["ab", "cd", "ef", "gh"]),
        (["aaaa", "bbbb", "cccc"], ["aaaa", "bbbb", "cccc"]),
        (["a", "aa", "aaa", "aaaa"], ["aa", "aaaa"]),
    ])
    def test_parametrized_cases(self, input_list, expected):
        assert self.sorted_list_sum(input_list) == expected
    
    def test_sorting_stability_with_duplicates(self):
        result = self.sorted_list_sum(["zz", "aa", "zz", "aa"])
        assert result == ["aa", "aa", "zz", "zz"]
    
    def test_large_list(self):
        large_list = ["ab"] * 100 + ["cd"] * 100
        result = self.sorted_list_sum(large_list)
        assert len(result) == 200
        assert all(len(word) == 2 for word in result)