# Test cases for HumanEval/11
# Generated using Claude API

from typing import List


def string_xor(a: str, b: str) -> str:
    """ Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.
    >>> string_xor('010', '110')
    '100'
    """

    def xor(i, j):
        if i == j:
            return '0'
        else:
            return '1'

    return ''.join(xor(x, y) for x, y in zip(a, b))


# Generated test cases:
import pytest


def string_xor(a: str, b: str) -> str:
    def xor(i, j):
        if i == j:
            return '0'
        else:
            return '1'

    return ''.join(xor(x, y) for x, y in zip(a, b))


class TestStringXor:
    
    @pytest.mark.parametrize("a,b,expected", [
        ("1", "1", "0"),
        ("1", "0", "1"),
        ("0", "1", "1"),
        ("0", "0", "0"),
    ])
    def test_single_character(self, a, b, expected):
        assert string_xor(a, b) == expected
    
    @pytest.mark.parametrize("a,b,expected", [
        ("11", "11", "00"),
        ("10", "10", "00"),
        ("10", "01", "11"),
        ("01", "10", "11"),
        ("00", "00", "00"),
        ("11", "00", "11"),
    ])
    def test_two_characters(self, a, b, expected):
        assert string_xor(a, b) == expected
    
    @pytest.mark.parametrize("a,b,expected", [
        ("101", "101", "000"),
        ("101", "010", "111"),
        ("111", "000", "111"),
        ("000", "000", "000"),
        ("110", "011", "101"),
    ])
    def test_three_characters(self, a, b, expected):
        assert string_xor(a, b) == expected
    
    @pytest.mark.parametrize("a,b,expected", [
        ("1010", "1010", "0000"),
        ("1010", "0101", "1111"),
        ("1111", "0000", "1111"),
        ("0000", "0000", "0000"),
        ("1100", "0011", "1111"),
    ])
    def test_four_characters(self, a, b, expected):
        assert string_xor(a, b) == expected
    
    def test_longer_strings(self):
        assert string_xor("10101010", "10101010") == "00000000"
        assert string_xor("10101010", "01010101") == "11111111"
        assert string_xor("11110000", "00001111") == "11111111"
    
    def test_empty_strings(self):
        assert string_xor("", "") == ""
    
    def test_single_zero(self):
        assert string_xor("0", "0") == "0"
    
    def test_single_one(self):
        assert string_xor("1", "1") == "0"
    
    def test_different_length_strings_shorter_first(self):
        result = string_xor("10", "1010")
        assert result == "00"
    
    def test_different_length_strings_longer_first(self):
        result = string_xor("1010", "10")
        assert result == "00"
    
    def test_all_zeros(self):
        assert string_xor("0000", "0000") == "0000"
    
    def test_all_ones(self):
        assert string_xor("1111", "1111") == "0000"
    
    def test_alternating_pattern(self):
        assert string_xor("1010", "0101") == "1111"
    
    def test_long_string(self):
        a = "1" * 100
        b = "1" * 100
        assert string_xor(a, b) == "0" * 100
    
    def test_long_string_alternating(self):
        a = "1" * 50 + "0" * 50
        b = "0" * 50 + "1" * 50
        assert string_xor(a, b) == "1" * 100
    
    def test_mixed_pattern(self):
        assert string_xor("110011", "101010") == "011001"
    
    def test_return_type_is_string(self):
        result = string_xor("1", "0")
        assert isinstance(result, str)
    
    def test_xor_commutative(self):
        a = "1010"
        b = "0101"
        assert string_xor(a, b) == string_xor(b, a)
    
    def test_xor_with_self_is_zero(self):
        a = "110101"
        assert string_xor(a, a) == "0" * len(a)
    
    def test_xor_identity_with_zeros(self):
        a = "110101"
        zeros = "0" * len(a)
        assert string_xor(a, zeros) == a
