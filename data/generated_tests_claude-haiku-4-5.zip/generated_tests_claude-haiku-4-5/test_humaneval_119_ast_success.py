# Test cases for HumanEval/119
# Generated using Claude API


def match_parens(lst):
    '''
    You are given a list of two strings, both strings consist of open
    parentheses '(' or close parentheses ')' only.
    Your job is to check if it is possible to concatenate the two strings in
    some order, that the resulting string will be good.
    A string S is considered to be good if and only if all parentheses in S
    are balanced. For example: the string '(())()' is good, while the string
    '())' is not.
    Return 'Yes' if there's a way to make a good string, and return 'No' otherwise.

    Examples:
    match_parens(['()(', ')']) == 'Yes'
    match_parens([')', ')']) == 'No'
    '''

    def check(s):
        val = 0
        for i in s:
            if i == '(':
                val = val + 1
            else:
                val = val - 1
            if val < 0:
                return False
        return True if val == 0 else False

    S1 = lst[0] + lst[1]
    S2 = lst[1] + lst[0]
    return 'Yes' if check(S1) or check(S2) else 'No'


# Generated test cases:
import pytest


class TestMatchParens:
    
    def test_both_empty_strings(self):
        from test_humaneval_119_ast import match_parens
        assert match_parens(['', '']) == 'Yes'
    
    def test_single_pair_first_order(self):
        assert match_parens(['(', ')']) == 'Yes'
    
    def test_single_pair_second_order(self):
        assert match_parens([')', '(']) == 'Yes'
    
    def test_multiple_pairs_first_order(self):
        assert match_parens(['()(', ')']) == 'Yes'
    
    def test_multiple_pairs_second_order(self):
        assert match_parens([')', '()(']) == 'Yes'
    
    def test_unmatched_opening(self):
        assert match_parens(['((', ')']) == 'No'
    
    def test_unmatched_closing(self):
        assert match_parens(['(', '))']) == 'No'
    
    def test_both_unmatched(self):
        assert match_parens(['((', '))']) == 'Yes'
    
    def test_complex_valid_first_order(self):
        assert match_parens(['(())', '']) == 'Yes'
    
    def test_complex_valid_second_order(self):
        assert match_parens(['', '(())']) == 'Yes'
    
    def test_nested_parens_first_order(self):
        assert match_parens(['((', '))']) == 'Yes'
    
    def test_nested_parens_valid(self):
        assert match_parens(['(', ')(']) == 'No'
    
    def test_long_valid_sequence_first(self):
        assert match_parens(['()()(', ')']) == 'Yes'
    
    def test_long_valid_sequence_second(self):
        assert match_parens([')', '()()(']) == 'Yes'
    
    def test_closing_before_opening_first(self):
        assert match_parens([')', '(']) == 'Yes'
    
    def test_closing_before_opening_invalid(self):
        assert match_parens([')', ')']) == 'No'
    
    def test_opening_only_first(self):
        assert match_parens(['(', '(']) == 'No'
    
    def test_opening_only_second(self):
        assert match_parens(['(', '']) == 'No'
    
    def test_closing_only_first(self):
        assert match_parens([')', '']) == 'No'
    
    def test_closing_only_second(self):
        assert match_parens(['', ')']) == 'No'
    
    def test_balanced_complex_first_order(self):
        assert match_parens(['()(', ')()']) == 'Yes'
    
    def test_balanced_complex_second_order(self):
        assert match_parens(['(())', '(']) == 'No'
    
    def test_many_opening_few_closing(self):
        assert match_parens(['(((', ')']) == 'No'
    
    def test_few_opening_many_closing(self):
        assert match_parens(['(', ')))']) == 'No'
    
    def test_alternating_valid(self):
        assert match_parens(['()(', ')()']) == 'Yes'
    
    def test_single_opening_single_closing(self):
        assert match_parens(['(', ')']) == 'Yes'
    
    def test_reversed_single_pair(self):
        assert match_parens([')', '(']) == 'Yes'
    
    def test_three_pairs_first_order(self):
        assert match_parens(['()()(', ')']) == 'Yes'
    
    def test_three_pairs_second_order(self):
        assert match_parens([')', '()()(']) == 'Yes'
    
    def test_deeply_nested_valid(self):
        assert match_parens(['((((', '))))']) == 'Yes'
    
    def test_deeply_nested_invalid(self):
        assert match_parens(['(((', ')))']) == 'Yes'
    
    def test_mixed_valid_first(self):
        assert match_parens(['(())(', ')']) == 'Yes'
    
    def test_mixed_valid_second(self):
        assert match_parens([')', '(())(']) == 'Yes'


@pytest.mark.parametrize("lst,expected", [
    (['', ''], 'Yes'),
    (['(', ')'], 'Yes'),
    ([')', '('], 'Yes'),
    (['((', ')'], 'No'),
    (['(', '))'], 'No'),
    (['((', '))'], 'Yes'),
    (['(())', ''], 'Yes'),
    (['', '(())'], 'Yes'),
    (['()(', ')'], 'Yes'),
    ([')', '()('], 'Yes'),
    ([')', ')'], 'No'),
    (['(', '('], 'No'),
    (['(', ''], 'No'),
    ([')', ''], 'No'),
    (['', ')'], 'No'),
    (['()(', ')()'], 'Yes'),
    (['(((', ')'], 'No'),
    (['(', ')))'], 'No'),
    (['((((', '))))'], 'Yes'),
    (['(((', ')))'], 'Yes'),
])
def test_match_parens_parametrized(lst, expected):
    assert match_parens(lst) == expected