# Test cases for HumanEval/39
# Generated using Claude API



def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """

    import math

    def is_prime(p):
        if p < 2:
            return False
        for k in range(2, min(int(math.sqrt(p)) + 1, p - 1)):
            if p % k == 0:
                return False
        return True
    f = [0, 1]
    while True:
        f.append(f[-1] + f[-2])
        if is_prime(f[-1]):
            n -= 1
        if n == 0:
            return f[-1]


# Generated test cases:
import pytest
import math


def prime_fib(n: int):

    def is_prime(p):
        if p < 2:
            return False
        for k in range(2, min(int(math.sqrt(p)) + 1, p - 1)):
            if p % k == 0:
                return False
        return True
    f = [0, 1]
    while True:
        f.append(f[-1] + f[-2])
        if is_prime(f[-1]):
            n -= 1
        if n == 0:
            return f[-1]


class TestPrimeFib:
    def test_first_prime_fib(self):
        assert prime_fib(1) == 2

    def test_second_prime_fib(self):
        assert prime_fib(2) == 3

    def test_third_prime_fib(self):
        assert prime_fib(3) == 5

    def test_fourth_prime_fib(self):
        assert prime_fib(4) == 13

    def test_fifth_prime_fib(self):
        assert prime_fib(5) == 89

    def test_sixth_prime_fib(self):
        assert prime_fib(6) == 233

    def test_seventh_prime_fib(self):
        assert prime_fib(7) == 1597

    def test_eighth_prime_fib(self):
        assert prime_fib(8) == 28657

    def test_ninth_prime_fib(self):
        assert prime_fib(9) == 514229

    def test_tenth_prime_fib(self):
        assert prime_fib(10) == 433494437

    @pytest.mark.parametrize("n,expected", [
        (1, 2),
        (2, 3),
        (3, 5),
        (4, 13),
        (5, 89),
        (6, 233),
        (7, 1597),
    ])
    def test_prime_fib_parametrized(self, n, expected):
        assert prime_fib(n) == expected

    def test_large_n(self):
        result = prime_fib(11)
        assert isinstance(result, int)
        assert result > 0

    def test_result_is_prime(self):
        def is_prime(p):
            if p < 2:
                return False
            for k in range(2, int(math.sqrt(p)) + 1):
                if p % k == 0:
                    return False
            return True
        
        for i in range(1, 8):
            result = prime_fib(i)
            assert is_prime(result), f"prime_fib({i}) = {result} is not prime"

    def test_result_is_fibonacci(self):
        def generate_fibs(limit):
            fibs = [0, 1]
            while fibs[-1] < limit:
                fibs.append(fibs[-1] + fibs[-2])
            return fibs
        
        for i in range(1, 8):
            result = prime_fib(i)
            fibs = generate_fibs(result * 2)
            assert result in fibs, f"prime_fib({i}) = {result} is not a Fibonacci number"

    def test_increasing_sequence(self):
        results = [prime_fib(i) for i in range(1, 6)]
        for i in range(len(results) - 1):
            assert results[i] < results[i + 1], "Results should be in increasing order"

    def test_return_type_is_int(self):
        result = prime_fib(1)
        assert isinstance(result, int)

    def test_return_type_for_multiple_calls(self):
        for i in range(1, 6):
            result = prime_fib(i)
            assert isinstance(result, int)
