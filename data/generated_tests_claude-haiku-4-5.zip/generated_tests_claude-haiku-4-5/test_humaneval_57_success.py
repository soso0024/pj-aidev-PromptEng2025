# Test cases for HumanEval/57
# Generated using Claude API



def monotonic(l: list):
    """Return True is list elements are monotonically increasing or decreasing.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """

    if l == sorted(l) or l == sorted(l, reverse=True):
        return True
    return False


# Generated test cases:
import pytest


def monotonic(l: list):
    if l == sorted(l) or l == sorted(l, reverse=True):
        return True
    return False


class TestMonotonic:
    
    def test_empty_list(self):
        assert monotonic([]) == True
    
    def test_single_element(self):
        assert monotonic([1]) == True
    
    def test_two_elements_ascending(self):
        assert monotonic([1, 2]) == True
    
    def test_two_elements_descending(self):
        assert monotonic([2, 1]) == True
    
    def test_two_elements_equal(self):
        assert monotonic([1, 1]) == True
    
    def test_ascending_list(self):
        assert monotonic([1, 2, 3, 4, 5]) == True
    
    def test_descending_list(self):
        assert monotonic([5, 4, 3, 2, 1]) == True
    
    def test_all_equal_elements(self):
        assert monotonic([5, 5, 5, 5, 5]) == True
    
    def test_non_monotonic_list(self):
        assert monotonic([1, 3, 2, 4]) == False
    
    def test_non_monotonic_mostly_ascending(self):
        assert monotonic([1, 2, 3, 2, 4]) == False
    
    def test_non_monotonic_mostly_descending(self):
        assert monotonic([5, 4, 3, 4, 2]) == False
    
    def test_ascending_with_duplicates(self):
        assert monotonic([1, 1, 2, 2, 3, 3]) == True
    
    def test_descending_with_duplicates(self):
        assert monotonic([3, 3, 2, 2, 1, 1]) == True
    
    def test_negative_numbers_ascending(self):
        assert monotonic([-5, -3, -1, 0, 2]) == True
    
    def test_negative_numbers_descending(self):
        assert monotonic([2, 0, -1, -3, -5]) == True
    
    def test_mixed_positive_negative_ascending(self):
        assert monotonic([-10, -5, 0, 5, 10]) == True
    
    def test_mixed_positive_negative_descending(self):
        assert monotonic([10, 5, 0, -5, -10]) == True
    
    def test_floats_ascending(self):
        assert monotonic([1.1, 2.2, 3.3, 4.4]) == True
    
    def test_floats_descending(self):
        assert monotonic([4.4, 3.3, 2.2, 1.1]) == True
    
    def test_large_ascending_list(self):
        assert monotonic(list(range(1000))) == True
    
    def test_large_descending_list(self):
        assert monotonic(list(range(1000, 0, -1))) == True
    
    def test_large_non_monotonic_list(self):
        lst = list(range(500)) + [0] + list(range(500, 1000))
        assert monotonic(lst) == False
    
    @pytest.mark.parametrize("input_list,expected", [
        ([1, 2, 3], True),
        ([3, 2, 1], True),
        ([1, 3, 2], False),
        ([], True),
        ([42], True),
        ([1, 1, 1], True),
        ([1, 2, 2, 3], True),
        ([3, 2, 2, 1], True),
        ([1, 2, 1, 3], False),
    ])
    def test_parametrized_cases(self, input_list, expected):
        assert monotonic(input_list) == expected
