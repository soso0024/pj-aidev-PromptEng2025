# Test cases for HumanEval/67
# Generated using Claude API


def fruit_distribution(s,n):
    """
    In this task, you will be given a string that represents a number of apples and oranges 
    that are distributed in a basket of fruit this basket contains 
    apples, oranges, and mango fruits. Given the string that represents the total number of 
    the oranges and apples and an integer that represent the total number of the fruits 
    in the basket return the number of the mango fruits in the basket.
    for examble:
    fruit_distribution("5 apples and 6 oranges", 19) ->19 - 5 - 6 = 8
    fruit_distribution("0 apples and 1 oranges",3) -> 3 - 0 - 1 = 2
    fruit_distribution("2 apples and 3 oranges", 100) -> 100 - 2 - 3 = 95
    fruit_distribution("100 apples and 1 oranges",120) -> 120 - 100 - 1 = 19
    """

    lis = list()
    for i in s.split(' '):
        if i.isdigit():
            lis.append(int(i))
    return n - sum(lis)


# Generated test cases:
import pytest


def fruit_distribution(s, n):
    lis = list()
    for i in s.split(' '):
        if i.isdigit():
            lis.append(int(i))
    return n - sum(lis)


class TestFruitDistribution:
    
    @pytest.mark.parametrize("s,n,expected", [
        ("5 apples and 6 oranges", 19, 8),
        ("0 apples and 1 oranges", 3, 2),
        ("2 apples and 3 oranges", 100, 95),
        ("100 apples and 1 oranges", 120, 19),
    ])
    def test_basic_cases(self, s, n, expected):
        assert fruit_distribution(s, n) == expected
    
    def test_zero_apples_zero_oranges(self):
        assert fruit_distribution("0 apples and 0 oranges", 10) == 10
    
    def test_all_mangoes(self):
        assert fruit_distribution("0 apples and 0 oranges", 50) == 50
    
    def test_no_mangoes(self):
        assert fruit_distribution("5 apples and 5 oranges", 10) == 0
    
    def test_single_digit_numbers(self):
        assert fruit_distribution("1 apples and 1 oranges", 5) == 3
    
    def test_large_numbers(self):
        assert fruit_distribution("999 apples and 999 oranges", 5000) == 3002
    
    def test_large_total_fruits(self):
        assert fruit_distribution("10 apples and 20 oranges", 1000) == 970
    
    def test_two_digit_apples(self):
        assert fruit_distribution("15 apples and 8 oranges", 50) == 27
    
    def test_two_digit_oranges(self):
        assert fruit_distribution("5 apples and 25 oranges", 50) == 20
    
    def test_both_two_digit(self):
        assert fruit_distribution("25 apples and 35 oranges", 100) == 40
    
    def test_three_digit_numbers(self):
        assert fruit_distribution("123 apples and 456 oranges", 1000) == 421
    
    def test_minimal_case(self):
        assert fruit_distribution("0 apples and 0 oranges", 1) == 1
    
    def test_equal_apples_and_oranges(self):
        assert fruit_distribution("10 apples and 10 oranges", 30) == 10
    
    def test_more_apples_than_oranges(self):
        assert fruit_distribution("20 apples and 5 oranges", 50) == 25
    
    def test_more_oranges_than_apples(self):
        assert fruit_distribution("5 apples and 20 oranges", 50) == 25
    
    def test_exact_match(self):
        assert fruit_distribution("7 apples and 8 oranges", 15) == 0
    
    def test_single_digit_total(self):
        assert fruit_distribution("1 apples and 1 oranges", 3) == 1
    
    def test_high_precision_case(self):
        assert fruit_distribution("99 apples and 99 oranges", 500) == 302
    
    def test_asymmetric_distribution(self):
        assert fruit_distribution("1 apples and 99 oranges", 200) == 100
    
    def test_reverse_asymmetric(self):
        assert fruit_distribution("99 apples and 1 oranges", 200) == 100


class TestFruitDistributionEdgeCases:
    
    def test_very_large_numbers(self):
        assert fruit_distribution("9999 apples and 9999 oranges", 50000) == 30002
    
    def test_single_apple(self):
        assert fruit_distribution("1 apples and 0 oranges", 5) == 4
    
    def test_single_orange(self):
        assert fruit_distribution("0 apples and 1 oranges", 5) == 4
    
    def test_return_type_is_int(self):
        result = fruit_distribution("5 apples and 6 oranges", 19)
        assert isinstance(result, int)
    
    def test_negative_result_not_possible(self):
        result = fruit_distribution("5 apples and 5 oranges", 10)
        assert result >= 0
    
    def test_result_equals_total_when_no_apples_oranges(self):
        total = 42
        result = fruit_distribution("0 apples and 0 oranges", total)
        assert result == total
    
    def test_multiple_spaces_handling(self):
        assert fruit_distribution("10 apples and 20 oranges", 100) == 70
    
    def test_consistent_results(self):
        s = "15 apples and 25 oranges"
        n = 100
        result1 = fruit_distribution(s, n)
        result2 = fruit_distribution(s, n)
        assert result1 == result2
