# Test cases for HumanEval/158
# Generated using Claude API


def find_max(words):
    """Write a function that accepts a list of strings.
    The list contains different words. Return the word with maximum number
    of unique characters. If multiple strings have maximum number of unique
    characters, return the one which comes first in lexicographical order.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb" ,"cc"]) == ""aaaaaaa"
    """

    return sorted(words, key = lambda x: (-len(set(x)), x))[0]


# Generated test cases:
import pytest


def find_max(words):
    return sorted(words, key = lambda x: (-len(set(x)), x))[0]


class TestFindMax:
    def test_single_word(self):
        assert find_max(["hello"]) == "hello"
    
    def test_word_with_most_unique_chars(self):
        assert find_max(["aaa", "abc", "ab"]) == "abc"
    
    def test_same_unique_chars_alphabetical_order(self):
        assert find_max(["abc", "bcd"]) == "abc"
    
    def test_repeated_characters(self):
        assert find_max(["aaa", "bbb", "ccc"]) == "aaa"
    
    def test_mixed_unique_and_repeated(self):
        assert find_max(["aaaa", "abcd", "aabb"]) == "abcd"
    
    def test_single_character_words(self):
        assert find_max(["a", "b", "c"]) == "a"
    
    def test_empty_string_in_list(self):
        assert find_max(["", "a", "ab"]) == "ab"
    
    def test_all_same_word(self):
        assert find_max(["test", "test", "test"]) == "test"
    
    def test_two_words_same_unique_count(self):
        assert find_max(["abc", "def"]) == "abc"
    
    def test_longer_word_fewer_unique(self):
        assert find_max(["aaaaaaa", "abc"]) == "abc"
    
    def test_case_sensitive(self):
        assert find_max(["Abc", "abc"]) == "Abc"
    
    def test_special_characters(self):
        assert find_max(["a!b@c#", "aaa", "ab"]) == "a!b@c#"
    
    def test_numbers_as_strings(self):
        assert find_max(["111", "123", "12"]) == "123"
    
    def test_whitespace_characters(self):
        assert find_max(["a b c", "aaa", "abc"]) == "a b c"
    
    def test_unicode_characters(self):
        assert find_max(["café", "aaa", "ab"]) == "café"
    
    def test_multiple_words_different_unique_counts(self):
        result = find_max(["a", "ab", "abc", "abcd"])
        assert result == "abcd"
    
    def test_word_with_all_unique_chars(self):
        assert find_max(["abcdefghij", "aabbccdd"]) == "abcdefghij"
    
    def test_alphabetical_tiebreaker(self):
        assert find_max(["xyz", "abc"]) == "abc"
    
    def test_longer_alphabetically_later_word(self):
        assert find_max(["ab", "zzz"]) == "ab"
    
    def test_complex_mixed_case(self):
        assert find_max(["AaBbCc", "aabbcc", "abc"]) == "AaBbCc"


@pytest.mark.parametrize("words,expected", [
    (["hello"], "hello"),
    (["aaa", "abc", "ab"], "abc"),
    (["abc", "bcd"], "abc"),
    (["a", "b", "c"], "a"),
    (["aaaa", "abcd", "aabb"], "abcd"),
    (["test", "test", "test"], "test"),
    (["abc", "def"], "abc"),
    (["aaaaaaa", "abc"], "abc"),
    (["111", "123", "12"], "123"),
    (["a", "ab", "abc", "abcd"], "abcd"),
])
def test_find_max_parametrized(words, expected):
    assert find_max(words) == expected


def test_find_max_with_empty_strings():
    result = find_max(["", "a"])
    assert result == "a"


def test_find_max_preserves_input():
    original = ["test", "hello", "world"]
    find_max(original)
    assert original == ["test", "hello", "world"]


def test_find_max_with_duplicates_in_list():
    assert find_max(["abc", "abc", "def"]) == "abc"


def test_find_max_single_char_repeated():
    assert find_max(["aaaa", "bbbb", "cccc"]) == "aaaa"


def test_find_max_with_punctuation():
    assert find_max(["a.b.c", "aaa", "ab"]) == "a.b.c"
