# Test cases for HumanEval/35
# Generated using Claude API



def max_element(l: list):
    """Return maximum element in the list.
    >>> max_element([1, 2, 3])
    3
    >>> max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    123
    """

    m = l[0]
    for e in l:
        if e > m:
            m = e
    return m


# Generated test cases:
import pytest


def max_element(l: list):
    m = l[0]
    for e in l:
        if e > m:
            m = e
    return m


class TestMaxElement:
    def test_single_element(self):
        assert max_element([5]) == 5

    def test_two_elements_first_larger(self):
        assert max_element([10, 5]) == 10

    def test_two_elements_second_larger(self):
        assert max_element([5, 10]) == 10

    def test_multiple_elements(self):
        assert max_element([3, 7, 2, 9, 1]) == 9

    def test_all_same_elements(self):
        assert max_element([5, 5, 5, 5]) == 5

    def test_negative_numbers(self):
        assert max_element([-5, -2, -10, -1]) == -1

    def test_mixed_positive_negative(self):
        assert max_element([-5, 10, -3, 8, 0]) == 10

    def test_zero_in_list(self):
        assert max_element([0, -5, -10]) == 0

    def test_large_numbers(self):
        assert max_element([1000000, 999999, 1000001]) == 1000001

    def test_floats(self):
        assert max_element([1.5, 2.7, 1.2, 3.1]) == 3.1

    def test_mixed_int_float(self):
        assert max_element([1, 2.5, 3, 1.5]) == 3

    def test_descending_order(self):
        assert max_element([10, 9, 8, 7, 6, 5]) == 10

    def test_ascending_order(self):
        assert max_element([1, 2, 3, 4, 5, 10]) == 10

    def test_max_at_beginning(self):
        assert max_element([100, 50, 75, 25]) == 100

    def test_max_at_end(self):
        assert max_element([25, 50, 75, 100]) == 100

    def test_max_in_middle(self):
        assert max_element([10, 20, 100, 30, 40]) == 100

    def test_duplicate_max_values(self):
        assert max_element([5, 10, 10, 3]) == 10

    def test_many_duplicates(self):
        assert max_element([7, 7, 7, 7, 7]) == 7

    @pytest.mark.parametrize("input_list,expected", [
        ([1], 1),
        ([42], 42),
        ([-1], -1),
        ([1, 2], 2),
        ([2, 1], 2),
        ([1, 2, 3, 4, 5], 5),
        ([5, 4, 3, 2, 1], 5),
        ([-1, -2, -3], -1),
        ([0, 0, 0], 0),
    ])
    def test_parametrized_cases(self, input_list, expected):
        assert max_element(input_list) == expected

    def test_empty_list_raises_error(self):
        with pytest.raises(IndexError):
            max_element([])

    def test_very_long_list(self):
        long_list = list(range(1000))
        assert max_element(long_list) == 999

    def test_very_long_list_reverse(self):
        long_list = list(range(1000, 0, -1))
        assert max_element(long_list) == 1000
