# Test cases for HumanEval/74
# Generated using Claude API


def total_match(lst1, lst2):
    '''
    Write a function that accepts two lists of strings and returns the list that has 
    total number of chars in the all strings of the list less than the other list.

    if the two lists have the same number of chars, return the first list.

    Examples
    total_match([], []) ➞ []
    total_match(['hi', 'admin'], ['hI', 'Hi']) ➞ ['hI', 'Hi']
    total_match(['hi', 'admin'], ['hi', 'hi', 'admin', 'project']) ➞ ['hi', 'admin']
    total_match(['hi', 'admin'], ['hI', 'hi', 'hi']) ➞ ['hI', 'hi', 'hi']
    total_match(['4'], ['1', '2', '3', '4', '5']) ➞ ['4']
    '''

    l1 = 0
    for st in lst1:
        l1 += len(st)
    
    l2 = 0
    for st in lst2:
        l2 += len(st)
    
    if l1 <= l2:
        return lst1
    else:
        return lst2


# Generated test cases:
import pytest


class TestTotalMatch:
    
    def test_both_empty_lists(self):
        from solution import total_match
        assert total_match([], []) == []
    
    def test_first_list_empty(self):
        assert total_match([], ['hello', 'world']) == []
    
    def test_second_list_empty(self):
        assert total_match(['hello', 'world'], []) == []
    
    def test_example_1(self):
        assert total_match(['hi', 'admin'], ['hI', 'Hi']) == ['hI', 'Hi']
    
    def test_example_2(self):
        assert total_match(['hi', 'admin'], ['hi', 'hi', 'admin', 'project']) == ['hi', 'admin']
    
    def test_example_3(self):
        assert total_match(['hi', 'admin'], ['hI', 'hi', 'hi']) == ['hI', 'hi', 'hi']
    
    def test_example_4(self):
        assert total_match(['4'], ['1', '2', '3', '4', '5']) == ['4']
    
    def test_equal_char_count_returns_first_list(self):
        assert total_match(['ab', 'cd'], ['ef', 'gh']) == ['ab', 'cd']
    
    def test_single_element_lists(self):
        assert total_match(['hello'], ['hi']) == ['hi']
    
    def test_single_element_lists_equal(self):
        assert total_match(['test'], ['test']) == ['test']
    
    def test_first_list_shorter(self):
        assert total_match(['a'], ['bb', 'cc']) == ['a']
    
    def test_second_list_shorter(self):
        assert total_match(['aaa', 'bbb'], ['x']) == ['x']
    
    def test_single_character_strings(self):
        assert total_match(['a', 'b', 'c'], ['d', 'e']) == ['d', 'e']
    
    def test_empty_strings_in_list(self):
        assert total_match(['', 'hello'], ['world']) == ['', 'hello']
    
    def test_multiple_empty_strings(self):
        assert total_match(['', '', ''], ['a']) == ['', '', '']
    
    def test_long_strings(self):
        assert total_match(['a' * 100], ['b' * 50, 'c' * 50]) == ['a' * 100]
    
    def test_many_short_strings_vs_few_long_strings(self):
        assert total_match(['a', 'b', 'c', 'd', 'e'], ['verylongstring']) == ['a', 'b', 'c', 'd', 'e']
    
    def test_special_characters(self):
        assert total_match(['!@#'], ['$%^&']) == ['!@#']
    
    def test_unicode_characters(self):
        assert total_match(['café'], ['naïve']) == ['café']
    
    def test_whitespace_strings(self):
        assert total_match(['   ', '  '], ['    ']) == ['   ', '  ']
    
    def test_mixed_case_strings(self):
        assert total_match(['HeLLo'], ['wOrLd']) == ['HeLLo']
    
    def test_numeric_strings(self):
        assert total_match(['123', '456'], ['12345']) == ['12345']
    
    def test_first_list_much_longer(self):
        result = total_match(['a'] * 100, ['b'])
        assert result == ['b']
    
    def test_second_list_much_longer(self):
        result = total_match(['a'], ['b'] * 100)
        assert result == ['a']
    
    @pytest.mark.parametrize("lst1,lst2,expected", [
        ([], [], []),
        (['hi', 'admin'], ['hI', 'Hi'], ['hI', 'Hi']),
        (['hi', 'admin'], ['hi', 'hi', 'admin', 'project'], ['hi', 'admin']),
        (['hi', 'admin'], ['hI', 'hi', 'hi'], ['hI', 'hi', 'hi']),
        (['4'], ['1', '2', '3', '4', '5'], ['4']),
        (['a'], ['b'], ['a']),
        (['ab'], ['cd'], ['ab']),
        ([''], ['a'], ['']),
        (['x', 'y', 'z'], ['abc'], ['x', 'y', 'z']),
    ])
    def test_parametrized_cases(self, lst1, lst2, expected):
        assert total_match(lst1, lst2) == expected