# Test cases for HumanEval/32
# Generated using Claude API

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


def find_zero(xs: list):
    """ xs are coefficients of a polynomial.
    find_zero find x such that poly(x) = 0.
    find_zero returns only only zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.
    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0
    """

    begin, end = -1., 1.
    while poly(xs, begin) * poly(xs, end) > 0:
        begin *= 2.0
        end *= 2.0
    while end - begin > 1e-10:
        center = (begin + end) / 2.0
        if poly(xs, center) * poly(xs, begin) > 0:
            begin = center
        else:
            end = center
    return begin


# Generated test cases:
import pytest
import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


def find_zero(xs: list):
    """ xs are coefficients of a polynomial.
    find_zero find x such that poly(x) = 0.
    find_zero returns only only zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.
    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0
    """
    begin, end = -1., 1.
    while poly(xs, begin) * poly(xs, end) > 0:
        begin *= 2.0
        end *= 2.0
    while end - begin > 1e-10:
        center = (begin + end) / 2.0
        if poly(xs, center) * poly(xs, begin) > 0:
            begin = center
        else:
            end = center
    return begin


class TestFindZero:
    
    def test_linear_polynomial_simple(self):
        """Test simple linear polynomial: 1 + 2x = 0, x = -0.5"""
        result = find_zero([1, 2])
        assert abs(result - (-0.5)) < 1e-6
    
    def test_linear_polynomial_negative_slope(self):
        """Test linear polynomial with negative slope: 5 - 2x = 0, x = 2.5"""
        result = find_zero([5, -2])
        assert abs(result - 2.5) < 1e-6
    
    def test_cubic_polynomial(self):
        """Test cubic polynomial: -6 + 11x - 6x^2 + x^3 = 0"""
        result = find_zero([-6, 11, -6, 1])
        assert abs(poly([-6, 11, -6, 1], result)) < 1e-6
    
    def test_quadratic_polynomial(self):
        """Test quadratic polynomial: -2 + x + x^2 = 0"""
        result = find_zero([-2, 1, 1])
        assert abs(poly([-2, 1, 1], result)) < 1e-6
    
    def test_quadratic_polynomial_two_roots(self):
        """Test quadratic with two roots: -6 + x + x^2 = 0"""
        result = find_zero([-6, 1, 1])
        assert abs(poly([-6, 1, 1], result)) < 1e-6
    
    def test_polynomial_with_zero_constant(self):
        """Test polynomial with zero constant term: x + x^2 = 0"""
        result = find_zero([0, 1, 1])
        assert abs(poly([0, 1, 1], result)) < 1e-6
    
    def test_polynomial_negative_coefficients(self):
        """Test polynomial with negative coefficients: -1 - 2x = 0"""
        result = find_zero([-1, -2])
        assert abs(result - (-0.5)) < 1e-6
    
    def test_polynomial_large_coefficients(self):
        """Test polynomial with large coefficients: 1000 + 2000x = 0"""
        result = find_zero([1000, 2000])
        assert abs(result - (-0.5)) < 1e-6
    
    def test_polynomial_small_coefficients(self):
        """Test polynomial with small coefficients: 0.001 + 0.002x = 0"""
        result = find_zero([0.001, 0.002])
        assert abs(result - (-0.5)) < 1e-6
    
    def test_higher_degree_polynomial(self):
        """Test higher degree polynomial: -1 + x + x^2 + x^3 + x^4 = 0"""
        result = find_zero([-1, 1, 1, 1, 1])
        assert abs(poly([-1, 1, 1, 1, 1], result)) < 1e-6
    
    def test_polynomial_result_is_zero(self):
        """Verify that the result actually makes poly return approximately zero"""
        xs = [3, -7, 2]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-6
    
    def test_polynomial_result_is_zero_cubic(self):
        """Verify cubic polynomial result makes poly return approximately zero"""
        xs = [-8, 12, -6, 1]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-6
    
    def test_polynomial_with_fractional_coefficients(self):
        """Test polynomial with fractional coefficients: 0.5 + 0.25x = 0"""
        result = find_zero([0.5, 0.25])
        assert abs(result - (-2.0)) < 1e-6
    
    def test_polynomial_negative_root(self):
        """Test polynomial that has negative root: 2 + 4x = 0, x = -0.5"""
        result = find_zero([2, 4])
        assert abs(result - (-0.5)) < 1e-6
    
    def test_polynomial_positive_root(self):
        """Test polynomial that has positive root: -2 + 4x = 0, x = 0.5"""
        result = find_zero([-2, 4])
        assert abs(result - 0.5) < 1e-6


class TestPolyFunction:
    
    def test_poly_constant(self):
        """Test poly with constant polynomial"""
        assert poly([5], 0) == 5
        assert poly([5], 10) == 5
    
    def test_poly_linear(self):
        """Test poly with linear polynomial: 1 + 2x"""
        assert poly([1, 2], 0) == 1
        assert poly([1, 2], 1) == 3
        assert poly([1, 2], -1) == -1
    
    def test_poly_quadratic(self):
        """Test poly with quadratic polynomial: 1 + 2x + 3x^2"""
        assert poly([1, 2, 3], 0) == 1
        assert poly([1, 2, 3], 1) == 6
        assert poly([1, 2, 3], 2) == 17
    
    def test_poly_zero_coefficients(self):
        """Test poly with zero coefficients"""
        assert poly([0, 0, 0], 5) == 0
    
    def test_poly_negative_x(self):
        """Test poly with negative x value"""
        assert poly([1, 2, 1], -1) == 0
    
    def test_poly_fractional_x(self):
        """Test poly with fractional x value"""
        assert poly([1, 2, 1], 0.5) == 2.25