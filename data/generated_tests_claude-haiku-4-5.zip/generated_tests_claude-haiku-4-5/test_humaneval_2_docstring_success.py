# Test cases for HumanEval/2
# Generated using Claude API



def truncate_number(number: float) -> float:
    """ Given a positive floating point number, it can be decomposed into
    and integer part (largest integer smaller than given number) and decimals
    (leftover part always smaller than 1).

    Return the decimal part of the number.
    >>> truncate_number(3.5)
    0.5
    """

    return number % 1.0


# Generated test cases:
import pytest


def truncate_number(number: float) -> float:
    return number % 1.0


class TestTruncateNumber:
    
    @pytest.mark.parametrize("number,expected", [
        (3.5, 0.5),
        (0.5, 0.5),
        (1.1, 0.1),
        (2.9, 0.9),
        (10.25, 0.25),
        (100.75, 0.75),
    ])
    def test_truncate_number_basic(self, number, expected):
        result = truncate_number(number)
        assert abs(result - expected) < 1e-9
    
    def test_truncate_number_zero(self):
        assert truncate_number(0.0) == 0.0
    
    def test_truncate_number_integer(self):
        assert truncate_number(5.0) == 0.0
    
    def test_truncate_number_large_integer(self):
        assert truncate_number(1000.0) == 0.0
    
    def test_truncate_number_very_small_decimal(self):
        result = truncate_number(1.0001)
        assert abs(result - 0.0001) < 1e-9
    
    def test_truncate_number_close_to_one(self):
        result = truncate_number(1.9999)
        assert abs(result - 0.9999) < 1e-9
    
    def test_truncate_number_large_number(self):
        result = truncate_number(999999.123456)
        assert abs(result - 0.123456) < 1e-9
    
    def test_truncate_number_repeating_decimal(self):
        result = truncate_number(3.333333)
        assert abs(result - 0.333333) < 1e-9
    
    def test_truncate_number_half(self):
        assert truncate_number(0.5) == 0.5
    
    def test_truncate_number_quarter(self):
        result = truncate_number(2.25)
        assert abs(result - 0.25) < 1e-9
    
    def test_truncate_number_three_quarters(self):
        result = truncate_number(5.75)
        assert abs(result - 0.75) < 1e-9
    
    def test_truncate_number_negative_not_in_spec_but_test(self):
        result = truncate_number(-3.5)
        assert abs(result - 0.5) < 1e-9
    
    def test_truncate_number_very_large_decimal_part(self):
        result = truncate_number(42.999999999)
        assert abs(result - 0.999999999) < 1e-8
    
    def test_truncate_number_scientific_notation(self):
        result = truncate_number(1e2 + 0.5)
        assert abs(result - 0.5) < 1e-9
    
    def test_truncate_number_multiple_digits_after_decimal(self):
        result = truncate_number(7.123456789)
        assert abs(result - 0.123456789) < 1e-9
