# Test cases for HumanEval/57
# Generated using Claude API



def monotonic(l: list):
    """Return True is list elements are monotonically increasing or decreasing.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """

    if l == sorted(l) or l == sorted(l, reverse=True):
        return True
    return False


# Generated test cases:
import pytest


def monotonic(l: list):
    if l == sorted(l) or l == sorted(l, reverse=True):
        return True
    return False


class TestMonotonic:
    
    def test_monotonic_increasing(self):
        assert monotonic([1, 2, 4, 20]) == True
    
    def test_monotonic_decreasing(self):
        assert monotonic([4, 1, 0, -10]) == True
    
    def test_not_monotonic(self):
        assert monotonic([1, 20, 4, 10]) == False
    
    def test_empty_list(self):
        assert monotonic([]) == True
    
    def test_single_element(self):
        assert monotonic([1]) == True
    
    def test_two_elements_increasing(self):
        assert monotonic([1, 2]) == True
    
    def test_two_elements_decreasing(self):
        assert monotonic([2, 1]) == True
    
    def test_all_same_elements(self):
        assert monotonic([5, 5, 5, 5]) == True
    
    def test_monotonic_with_negative_numbers_increasing(self):
        assert monotonic([-10, -5, 0, 5]) == True
    
    def test_monotonic_with_negative_numbers_decreasing(self):
        assert monotonic([5, 0, -5, -10]) == True
    
    def test_monotonic_with_floats_increasing(self):
        assert monotonic([1.5, 2.3, 3.7, 4.1]) == True
    
    def test_monotonic_with_floats_decreasing(self):
        assert monotonic([4.1, 3.7, 2.3, 1.5]) == True
    
    def test_not_monotonic_valley(self):
        assert monotonic([1, 3, 2, 4]) == False
    
    def test_not_monotonic_peak(self):
        assert monotonic([1, 4, 2, 3]) == False
    
    def test_monotonic_with_duplicates_increasing(self):
        assert monotonic([1, 2, 2, 3, 3, 4]) == True
    
    def test_monotonic_with_duplicates_decreasing(self):
        assert monotonic([4, 3, 3, 2, 2, 1]) == True
    
    def test_not_monotonic_with_duplicates(self):
        assert monotonic([1, 2, 2, 1]) == False
    
    def test_large_increasing_list(self):
        assert monotonic(list(range(1000))) == True
    
    def test_large_decreasing_list(self):
        assert monotonic(list(range(1000, 0, -1))) == True
    
    def test_large_non_monotonic_list(self):
        lst = list(range(500)) + list(range(500, 0, -1))
        assert monotonic(lst) == False
    
    def test_monotonic_with_zero(self):
        assert monotonic([0, 0, 0]) == True
    
    def test_monotonic_mixed_signs_increasing(self):
        assert monotonic([-5, -2, 0, 3, 7]) == True
    
    def test_monotonic_mixed_signs_decreasing(self):
        assert monotonic([7, 3, 0, -2, -5]) == True


@pytest.mark.parametrize("input_list,expected", [
    ([1, 2, 4, 20], True),
    ([1, 20, 4, 10], False),
    ([4, 1, 0, -10], True),
    ([], True),
    ([42], True),
    ([1, 1], True),
    ([5, 5, 5], True),
    ([1, 2, 3, 4, 5], True),
    ([5, 4, 3, 2, 1], True),
    ([1, 3, 2], False),
    ([3, 1, 2], False),
    ([-5, -3, -1], True),
    ([-1, -3, -5], True),
    ([0, 1, 2], True),
    ([2, 1, 0], True),
])
def test_monotonic_parametrized(input_list, expected):
    assert monotonic(input_list) == expected
