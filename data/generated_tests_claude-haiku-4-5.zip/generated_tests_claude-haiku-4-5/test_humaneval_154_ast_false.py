# Test cases for HumanEval/154
# Generated using Claude API


def cycpattern_check(a , b):
    """You are given 2 words. You need to return True if the second word or any of its rotations is a substring in the first word
    cycpattern_check("abcd","abd") => False
    cycpattern_check("hello","ell") => True
    cycpattern_check("whassup","psus") => False
    cycpattern_check("abab","baa") => True
    cycpattern_check("efef","eeff") => False
    cycpattern_check("himenss","simen") => True

    """

    l = len(b)
    pat = b + b
    for i in range(len(a) - l + 1):
        for j in range(l + 1):
            if a[i:i+l] == pat[j:j+l]:
                return True
    return False


# Generated test cases:
import pytest


@pytest.mark.parametrize("a,b,expected", [
    ("abab", "ab", True),
    ("ababab", "baa", True),
    ("abab", "xyz", False),
    ("a", "a", True),
    ("aa", "a", True),
    ("abc", "bca", True),
    ("abc", "cab", True),
    ("abc", "abc", True),
    ("abcabc", "cab", True),
    ("abcabc", "bca", True),
    ("abcabc", "abc", True),
    ("aaaa", "aa", True),
    ("aaaa", "aaa", True),
    ("abcd", "dcba", False),
    ("abcd", "xyz", False),
    ("", "", True),
    ("a", "", True),
    ("ab", "ba", True),
    ("abc", "def", False),
    ("aaa", "aa", True),
    ("aaab", "baa", True),
    ("abcdef", "fab", False),
    ("abcdef", "cde", True),
    ("xyzxyz", "zxy", True),
    ("xyzxyz", "yxz", False),
    ("abcabcabc", "cab", True),
    ("abcabcabc", "bca", True),
    ("abcabcabc", "abc", True),
    ("abcabcabc", "xyz", False),
    ("ababab", "ab", True),
    ("ababab", "ba", True),
    ("ababab", "aab", True),
    ("123123", "231", True),
    ("123123", "312", True),
    ("123123", "123", True),
    ("123123", "456", False),
    ("abcdefg", "cde", True),
    ("abcdefg", "xyz", False),
    ("aabbcc", "bca", False),
    ("aabbcc", "cab", False),
    ("aabbcc", "baa", True),
    ("aaabbbccc", "bca", False),
    ("aaabbbccc", "cab", False),
    ("aaabbbccc", "bca", False),
    ("aaabbbccc", "cab", False),
])
def test_cycpattern_check(a, b, expected):
    from test_humaneval_154_ast import cycpattern_check
    assert cycpattern_check(a, b) == expected


def test_cycpattern_check_single_char():
    assert cycpattern_check("a", "a") == True
    assert cycpattern_check("b", "a") == False


def test_cycpattern_check_empty_pattern():
    assert cycpattern_check("abc", "") == True
    assert cycpattern_check("", "") == True


def test_cycpattern_check_pattern_longer_than_string():
    assert cycpattern_check("ab", "abcd") == False
    assert cycpattern_check("a", "abc") == False


def test_cycpattern_check_identical_strings():
    assert cycpattern_check("abc", "abc") == True
    assert cycpattern_check("abcabc", "abc") == True


def test_cycpattern_check_cyclic_rotations():
    assert cycpattern_check("abcabc", "bca") == True
    assert cycpattern_check("abcabc", "cab") == True
    assert cycpattern_check("abcabc", "abc") == True


def test_cycpattern_check_no_match():
    assert cycpattern_check("abcd", "xyz") == False
    assert cycpattern_check("abcd", "dcba") == False


def test_cycpattern_check_repeated_chars():
    assert cycpattern_check("aaaa", "aa") == True
    assert cycpattern_check("aaaa", "aaa") == True
    assert cycpattern_check("aaaa", "aaaa") == True


def test_cycpattern_check_numbers():
    assert cycpattern_check("123123", "231") == True
    assert cycpattern_check("123123", "312") == True
    assert cycpattern_check("123123", "456") == False


def test_cycpattern_check_long_strings():
    assert cycpattern_check("abcdefghijabcdefghij", "cdefghijab") == True
    assert cycpattern_check("abcdefghijabcdefghij", "xyz") == False