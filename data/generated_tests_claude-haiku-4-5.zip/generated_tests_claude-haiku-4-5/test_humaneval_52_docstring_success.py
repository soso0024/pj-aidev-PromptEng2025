# Test cases for HumanEval/52
# Generated using Claude API



def below_threshold(l: list, t: int):
    """Return True if all numbers in the list l are below threshold t.
    >>> below_threshold([1, 2, 4, 10], 100)
    True
    >>> below_threshold([1, 20, 4, 10], 5)
    False
    """

    for e in l:
        if e >= t:
            return False
    return True


# Generated test cases:
import pytest


def below_threshold(l: list, t: int):
    for e in l:
        if e >= t:
            return False
    return True


class TestBelowThreshold:
    
    def test_all_below_threshold(self):
        assert below_threshold([1, 2, 4, 10], 100) is True
    
    def test_some_above_threshold(self):
        assert below_threshold([1, 20, 4, 10], 5) is False
    
    def test_empty_list(self):
        assert below_threshold([], 10) is True
    
    def test_single_element_below(self):
        assert below_threshold([5], 10) is True
    
    def test_single_element_above(self):
        assert below_threshold([15], 10) is False
    
    def test_single_element_equal_to_threshold(self):
        assert below_threshold([10], 10) is False
    
    def test_all_elements_equal_to_threshold(self):
        assert below_threshold([5, 5, 5], 5) is False
    
    def test_negative_numbers_below_threshold(self):
        assert below_threshold([-10, -5, 0, 5], 10) is True
    
    def test_negative_numbers_above_threshold(self):
        assert below_threshold([-10, -5, 0, 15], 10) is False
    
    def test_all_negative_numbers(self):
        assert below_threshold([-100, -50, -10], 0) is True
    
    def test_zero_threshold(self):
        assert below_threshold([-5, -1], 0) is True
    
    def test_zero_threshold_with_positive(self):
        assert below_threshold([1, 2, 3], 0) is False
    
    def test_negative_threshold(self):
        assert below_threshold([-100, -50], -10) is True
    
    def test_negative_threshold_with_higher_negatives(self):
        assert below_threshold([-5, -1], -10) is False
    
    def test_large_numbers(self):
        assert below_threshold([1000000, 2000000], 3000000) is True
    
    def test_large_numbers_above_threshold(self):
        assert below_threshold([1000000, 5000000], 3000000) is False
    
    def test_mixed_positive_negative_all_below(self):
        assert below_threshold([-50, -10, 0, 10, 50], 100) is True
    
    def test_mixed_positive_negative_one_above(self):
        assert below_threshold([-50, -10, 0, 10, 150], 100) is False
    
    def test_first_element_above_threshold(self):
        assert below_threshold([100, 1, 2, 3], 50) is False
    
    def test_last_element_above_threshold(self):
        assert below_threshold([1, 2, 3, 100], 50) is False
    
    def test_middle_element_above_threshold(self):
        assert below_threshold([1, 2, 100, 3], 50) is False
    
    @pytest.mark.parametrize("input_list,threshold,expected", [
        ([1, 2, 3], 10, True),
        ([1, 2, 3], 3, False),
        ([1, 2, 3], 2, False),
        ([], 5, True),
        ([0], 1, True),
        ([0], 0, False),
        ([-1, -2, -3], 0, True),
        ([-1, -2, -3], -5, False),
    ])
    def test_parametrized_cases(self, input_list, threshold, expected):
        assert below_threshold(input_list, threshold) is expected
