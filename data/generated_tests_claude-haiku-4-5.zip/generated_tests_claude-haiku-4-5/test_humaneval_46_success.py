# Test cases for HumanEval/46
# Generated using Claude API



def fib4(n: int):
    """The Fib4 number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fib4(0) -> 0
    fib4(1) -> 0
    fib4(2) -> 2
    fib4(3) -> 0
    fib4(n) -> fib4(n-1) + fib4(n-2) + fib4(n-3) + fib4(n-4).
    Please write a function to efficiently compute the n-th element of the fib4 number sequence.  Do not use recursion.
    >>> fib4(5)
    4
    >>> fib4(6)
    8
    >>> fib4(7)
    14
    """

    results = [0, 0, 2, 0]
    if n < 4:
        return results[n]

    for _ in range(4, n + 1):
        results.append(results[-1] + results[-2] + results[-3] + results[-4])
        results.pop(0)

    return results[-1]


# Generated test cases:
import pytest


def fib4(n: int):
    results = [0, 0, 2, 0]
    if n < 4:
        return results[n]

    for _ in range(4, n + 1):
        results.append(results[-1] + results[-2] + results[-3] + results[-4])
        results.pop(0)

    return results[-1]


class TestFib4:
    
    @pytest.mark.parametrize("n,expected", [
        (0, 0),
        (1, 0),
        (2, 2),
        (3, 0),
    ])
    def test_base_cases(self, n, expected):
        assert fib4(n) == expected
    
    @pytest.mark.parametrize("n,expected", [
        (4, 2),
        (5, 4),
        (6, 8),
        (7, 14),
        (8, 28),
        (9, 54),
        (10, 104),
    ])
    def test_normal_cases(self, n, expected):
        assert fib4(n) == expected
    
    def test_larger_values(self):
        assert fib4(15) == 2764
        assert fib4(20) == 73552
    
    def test_sequential_consistency(self):
        prev_val = fib4(10)
        curr_val = fib4(11)
        next_val = fib4(12)
        assert next_val == curr_val + prev_val + fib4(9) + fib4(8)
    
    def test_monotonic_increase(self):
        for i in range(4, 15):
            assert fib4(i) > fib4(i - 1)
    
    def test_specific_sequence(self):
        sequence = [fib4(i) for i in range(12)]
        expected = [0, 0, 2, 0, 2, 4, 8, 14, 28, 54, 104, 200]
        assert sequence == expected
    
    def test_recurrence_relation(self):
        for n in range(4, 20):
            assert fib4(n) == fib4(n-1) + fib4(n-2) + fib4(n-3) + fib4(n-4)
    
    def test_zero_input(self):
        assert fib4(0) == 0
    
    def test_one_input(self):
        assert fib4(1) == 0
    
    def test_two_input(self):
        assert fib4(2) == 2
    
    def test_three_input(self):
        assert fib4(3) == 0
    
    def test_four_input(self):
        assert fib4(4) == 2
    
    def test_five_input(self):
        assert fib4(5) == 4
    
    def test_large_n(self):
        result = fib4(50)
        assert isinstance(result, int)
        assert result > 0
    
    def test_very_large_n(self):
        result = fib4(100)
        assert isinstance(result, int)
        assert result > fib4(99)