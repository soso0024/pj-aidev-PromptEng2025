# Test cases for HumanEval/149
# Generated using Claude API


def sorted_list_sum(lst):
    """Write a function that accepts a list of strings as a parameter,
    deletes the strings that have odd lengths from it,
    and returns the resulted list with a sorted order,
    The list is always a list of strings and never an array of numbers,
    and it may contain duplicates.
    The order of the list should be ascending by length of each word, and you
    should return the list sorted by that rule.
    If two words have the same length, sort the list alphabetically.
    The function should return a list of strings in sorted order.
    You may assume that all words will have the same length.
    For example:
    assert list_sort(["aa", "a", "aaa"]) => ["aa"]
    assert list_sort(["ab", "a", "aaa", "cd"]) => ["ab", "cd"]
    """

    lst.sort()
    new_lst = []
    for i in lst:
        if len(i)%2 == 0:
            new_lst.append(i)
    return sorted(new_lst, key=len)


# Generated test cases:
import pytest


class TestSortedListSum:
    
    def test_empty_list(self):
        from test_humaneval_149_ast import sorted_list_sum
        assert sorted_list_sum([]) == []
    
    def test_single_even_length_string(self):
        assert sorted_list_sum(["ab"]) == ["ab"]
    
    def test_single_odd_length_string(self):
        assert sorted_list_sum(["abc"]) == []
    
    def test_all_even_length_strings(self):
        result = sorted_list_sum(["ab", "cd", "ef"])
        assert result == ["ab", "cd", "ef"]
    
    def test_all_odd_length_strings(self):
        assert sorted_list_sum(["a", "abc", "abcde"]) == []
    
    def test_mixed_even_odd_strings(self):
        result = sorted_list_sum(["ab", "abc", "cd", "abcd"])
        assert result == ["ab", "cd", "abcd"]
    
    def test_sorting_by_length(self):
        result = sorted_list_sum(["abcd", "ab", "abcdef"])
        assert result == ["ab", "abcd", "abcdef"]
    
    def test_unsorted_input_with_even_lengths(self):
        result = sorted_list_sum(["zz", "aa", "bb"])
        assert result == ["aa", "bb", "zz"]
    
    def test_duplicate_strings(self):
        result = sorted_list_sum(["ab", "ab", "cd"])
        assert result == ["ab", "ab", "cd"]
    
    def test_empty_strings(self):
        result = sorted_list_sum(["", "ab", ""])
        assert result == ["", "", "ab"]
    
    def test_single_character_strings(self):
        assert sorted_list_sum(["a", "b", "c"]) == []
    
    def test_two_character_strings_only(self):
        result = sorted_list_sum(["xy", "ab", "cd"])
        assert result == ["ab", "cd", "xy"]
    
    def test_mixed_lengths_sorted_output(self):
        result = sorted_list_sum(["a", "ab", "abc", "abcd", "abcde", "abcdef"])
        assert result == ["ab", "abcd", "abcdef"]
    
    def test_large_even_length_string(self):
        large_string = "a" * 100
        result = sorted_list_sum([large_string, "ab"])
        assert result == ["ab", large_string]
    
    def test_numeric_strings_with_even_length(self):
        result = sorted_list_sum(["12", "1234", "123"])
        assert result == ["12", "1234"]
    
    def test_special_characters_even_length(self):
        result = sorted_list_sum(["!!", "@@", "##"])
        assert result == ["!!", "##", "@@"]
    
    def test_whitespace_strings(self):
        result = sorted_list_sum(["  ", "   ", "a"])
        assert result == ["  "]
    
    def test_unicode_strings_even_length(self):
        result = sorted_list_sum(["αβ", "γδ", "α"])
        assert result == ["αβ", "γδ"]
    
    def test_preserves_original_list_sorting(self):
        original = ["zz", "a", "bb"]
        sorted_list_sum(original)
        assert original == ["a", "bb", "zz"]
    
    def test_complex_mixed_case(self):
        result = sorted_list_sum(["Hello", "World!", "Hi", "Test"])
        assert result == ["Hi", "Test", "World!"]
    
    @pytest.mark.parametrize("input_list,expected", [
        ([], []),
        (["ab"], ["ab"]),
        (["abc"], []),
        (["ab", "cd"], ["ab", "cd"]),
        (["a", "b"], []),
        (["abcd", "ab"], ["ab", "abcd"]),
    ])
    def test_parametrized_cases(self, input_list, expected):
        assert sorted_list_sum(input_list) == expected