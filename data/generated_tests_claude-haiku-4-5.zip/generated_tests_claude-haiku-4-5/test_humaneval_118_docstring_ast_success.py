# Test cases for HumanEval/118
# Generated using Claude API


def get_closest_vowel(word):
    """You are given a word. Your task is to find the closest vowel that stands between 
    two consonants from the right side of the word (case sensitive).
    
    Vowels in the beginning and ending doesn't count. Return empty string if you didn't
    find any vowel met the above condition. 

    You may assume that the given string contains English letter only.

    Example:
    get_closest_vowel("yogurt") ==> "u"
    get_closest_vowel("FULL") ==> "U"
    get_closest_vowel("quick") ==> ""
    get_closest_vowel("ab") ==> ""
    """

    if len(word) < 3:
        return ""

    vowels = {"a", "e", "i", "o", "u", "A", "E", 'O', 'U', 'I'}
    for i in range(len(word)-2, 0, -1):
        if word[i] in vowels:
            if (word[i+1] not in vowels) and (word[i-1] not in vowels):
                return word[i]
    return ""


# Generated test cases:
import pytest


class TestGetClosestVowel:
    
    @pytest.mark.parametrize("word,expected", [
        ("yogurt", "u"),
        ("FULL", "U"),
        ("quick", ""),
        ("ab", ""),
    ])
    def test_provided_examples(self, word, expected):
        from test_humaneval_118_docstring_ast import get_closest_vowel
        assert get_closest_vowel(word) == expected
    
    def test_empty_string(self):
        assert get_closest_vowel("") == ""
    
    def test_single_character(self):
        assert get_closest_vowel("a") == ""
    
    def test_two_characters(self):
        assert get_closest_vowel("ab") == ""
    
    def test_three_characters_vowel_in_middle(self):
        assert get_closest_vowel("bat") == "a"
    
    def test_three_characters_consonant_in_middle(self):
        assert get_closest_vowel("bst") == ""
    
    def test_vowel_at_beginning(self):
        assert get_closest_vowel("apple") == ""
    
    def test_vowel_at_end(self):
        assert get_closest_vowel("bake") == "a"
    
    def test_multiple_vowels_between_consonants(self):
        assert get_closest_vowel("beautiful") == "u"
    
    def test_uppercase_vowel(self):
        assert get_closest_vowel("BAT") == "A"
    
    def test_mixed_case(self):
        assert get_closest_vowel("BaT") == "a"
    
    def test_all_consonants(self):
        assert get_closest_vowel("bcdfg") == ""
    
    def test_all_vowels(self):
        assert get_closest_vowel("aeiou") == ""
    
    def test_vowel_surrounded_by_consonants_at_end(self):
        assert get_closest_vowel("test") == "e"
    
    def test_multiple_valid_vowels_returns_closest_from_right(self):
        assert get_closest_vowel("banana") == "a"
    
    def test_vowel_with_consonant_after_at_end(self):
        assert get_closest_vowel("bent") == "e"
    
    def test_complex_word_with_multiple_patterns(self):
        assert get_closest_vowel("programming") == "i"
    
    def test_single_vowel_between_consonants(self):
        assert get_closest_vowel("cat") == "a"
    
    def test_uppercase_full_word(self):
        assert get_closest_vowel("YOGURT") == "U"
    
    def test_vowel_not_between_consonants_skipped(self):
        assert get_closest_vowel("beat") == ""
    
    def test_long_word_with_vowel_in_middle(self):
        assert get_closest_vowel("strength") == "e"
    
    def test_word_ending_with_vowel_consonant(self):
        assert get_closest_vowel("table") == "a"
    
    def test_word_with_consecutive_consonants(self):
        assert get_closest_vowel("string") == "i"
    
    def test_word_starting_with_vowel_consonant(self):
        assert get_closest_vowel("apple") == ""
    
    def test_three_char_all_consonants(self):
        assert get_closest_vowel("bcd") == ""
    
    def test_three_char_vowel_consonant_consonant(self):
        assert get_closest_vowel("att") == ""
    
    def test_three_char_consonant_vowel_consonant(self):
        assert get_closest_vowel("bat") == "a"
    
    def test_word_with_multiple_vowels_between_consonants(self):
        assert get_closest_vowel("beautiful") == "u"
    
    def test_rightmost_vowel_between_consonants(self):
        assert get_closest_vowel("abracadabra") == "a"
    
    def test_vowel_i_lowercase(self):
        assert get_closest_vowel("bit") == "i"
    
    def test_vowel_i_uppercase(self):
        assert get_closest_vowel("BIT") == "I"
    
    def test_vowel_o_lowercase(self):
        assert get_closest_vowel("bot") == "o"
    
    def test_vowel_o_uppercase(self):
        assert get_closest_vowel("BOT") == "O"
    
    def test_vowel_e_lowercase(self):
        assert get_closest_vowel("bet") == "e"
    
    def test_vowel_e_uppercase(self):
        assert get_closest_vowel("BET") == "E"