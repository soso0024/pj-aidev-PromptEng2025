# Test cases for HumanEval/18
# Generated using Claude API



def how_many_times(string: str, substring: str) -> int:
    """ Find how many times a given substring can be found in the original string. Count overlaping cases.
    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """

    times = 0

    for i in range(len(string) - len(substring) + 1):
        if string[i:i+len(substring)] == substring:
            times += 1

    return times


# Generated test cases:
import pytest


def how_many_times(string: str, substring: str) -> int:
    times = 0
    for i in range(len(string) - len(substring) + 1):
        if string[i:i+len(substring)] == substring:
            times += 1
    return times


class TestHowManyTimes:
    
    def test_empty_string_with_substring(self):
        assert how_many_times('', 'a') == 0
    
    def test_single_character_match(self):
        assert how_many_times('aaa', 'a') == 3
    
    def test_overlapping_substrings(self):
        assert how_many_times('aaaa', 'aa') == 3
    
    def test_no_match(self):
        assert how_many_times('hello', 'x') == 0
    
    def test_single_exact_match(self):
        assert how_many_times('hello', 'hello') == 1
    
    def test_substring_longer_than_string(self):
        assert how_many_times('hi', 'hello') == 0
    
    def test_empty_substring(self):
        assert how_many_times('hello', '') == 6
    
    def test_both_empty(self):
        assert how_many_times('', '') == 1
    
    def test_multiple_non_overlapping_matches(self):
        assert how_many_times('abcabc', 'abc') == 2
    
    def test_multiple_overlapping_matches(self):
        assert how_many_times('aaaa', 'aaa') == 2
    
    def test_substring_at_start(self):
        assert how_many_times('hello world', 'hello') == 1
    
    def test_substring_at_end(self):
        assert how_many_times('hello world', 'world') == 1
    
    def test_substring_in_middle(self):
        assert how_many_times('hello world', 'lo wo') == 1
    
    def test_repeated_pattern(self):
        assert how_many_times('ababab', 'ab') == 3
    
    def test_repeated_overlapping_pattern(self):
        assert how_many_times('aaaaaa', 'aaa') == 4
    
    def test_case_sensitive(self):
        assert how_many_times('AaAa', 'Aa') == 2
    
    def test_case_sensitive_no_match(self):
        assert how_many_times('hello', 'HELLO') == 0
    
    def test_special_characters(self):
        assert how_many_times('!@#!@#', '!@#') == 2
    
    def test_spaces_in_substring(self):
        assert how_many_times('a b a b', ' a ') == 1
    
    def test_single_character_string_and_substring(self):
        assert how_many_times('a', 'a') == 1
    
    def test_single_character_no_match(self):
        assert how_many_times('a', 'b') == 0
    
    @pytest.mark.parametrize("string,substring,expected", [
        ('', 'a', 0),
        ('aaa', 'a', 3),
        ('aaaa', 'aa', 3),
        ('abcdef', 'xyz', 0),
        ('test', 'test', 1),
        ('testtest', 'test', 2),
        ('aaaaaa', 'aa', 5),
        ('mississippi', 'ss', 2),
        ('mississippi', 'issi', 2),
        ('abababa', 'aba', 3),
    ])
    def test_parametrized_cases(self, string, substring, expected):
        assert how_many_times(string, substring) == expected