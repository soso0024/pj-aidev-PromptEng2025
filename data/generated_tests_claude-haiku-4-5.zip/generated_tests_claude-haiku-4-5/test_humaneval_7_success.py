# Test cases for HumanEval/7
# Generated using Claude API

from typing import List


def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """ Filter an input list of strings only for ones that contain given substring
    >>> filter_by_substring([], 'a')
    []
    >>> filter_by_substring(['abc', 'bacd', 'cde', 'array'], 'a')
    ['abc', 'bacd', 'array']
    """

    return [x for x in strings if substring in x]


# Generated test cases:
import pytest
from typing import List


def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    return [x for x in strings if substring in x]


class TestFilterBySubstring:
    
    def test_empty_list(self):
        result = filter_by_substring([], "test")
        assert result == []
    
    def test_empty_substring(self):
        result = filter_by_substring(["hello", "world"], "")
        assert result == ["hello", "world"]
    
    def test_no_matches(self):
        result = filter_by_substring(["hello", "world"], "xyz")
        assert result == []
    
    def test_single_match(self):
        result = filter_by_substring(["hello", "world"], "ell")
        assert result == ["hello"]
    
    def test_multiple_matches(self):
        result = filter_by_substring(["hello", "world", "help"], "el")
        assert result == ["hello", "help"]
    
    def test_all_match(self):
        result = filter_by_substring(["hello", "world", "help"], "l")
        assert result == ["hello", "world", "help"]
    
    def test_case_sensitive(self):
        result = filter_by_substring(["Hello", "hello", "HELLO"], "hello")
        assert result == ["hello"]
    
    def test_substring_equals_string(self):
        result = filter_by_substring(["hello", "world"], "hello")
        assert result == ["hello"]
    
    def test_substring_at_start(self):
        result = filter_by_substring(["hello", "world"], "hel")
        assert result == ["hello"]
    
    def test_substring_at_end(self):
        result = filter_by_substring(["hello", "world"], "llo")
        assert result == ["hello"]
    
    def test_substring_in_middle(self):
        result = filter_by_substring(["hello", "world"], "ll")
        assert result == ["hello"]
    
    def test_single_character_substring(self):
        result = filter_by_substring(["hello", "world"], "o")
        assert result == ["hello", "world"]
    
    def test_single_string_in_list(self):
        result = filter_by_substring(["hello"], "ell")
        assert result == ["hello"]
    
    def test_single_string_no_match(self):
        result = filter_by_substring(["hello"], "xyz")
        assert result == []
    
    def test_special_characters(self):
        result = filter_by_substring(["hello@world", "test#case"], "@")
        assert result == ["hello@world"]
    
    def test_numbers_in_strings(self):
        result = filter_by_substring(["test123", "abc456", "123xyz"], "123")
        assert result == ["test123", "123xyz"]
    
    def test_whitespace_in_substring(self):
        result = filter_by_substring(["hello world", "test case", "helloworld"], " ")
        assert result == ["hello world", "test case"]
    
    def test_whitespace_substring(self):
        result = filter_by_substring(["hello world", "test case"], " ")
        assert result == ["hello world", "test case"]
    
    def test_duplicate_strings(self):
        result = filter_by_substring(["hello", "hello", "world"], "ell")
        assert result == ["hello", "hello"]
    
    def test_empty_string_in_list(self):
        result = filter_by_substring(["", "hello", "world"], "ell")
        assert result == ["hello"]
    
    def test_substring_matches_empty_string(self):
        result = filter_by_substring(["", "hello"], "")
        assert result == ["", "hello"]
    
    def test_unicode_characters(self):
        result = filter_by_substring(["café", "naïve", "resume"], "é")
        assert result == ["café"]
    
    def test_long_strings(self):
        long_string = "a" * 1000 + "test" + "b" * 1000
        result = filter_by_substring([long_string, "short"], "test")
        assert result == [long_string]
    
    def test_many_strings(self):
        strings = [f"string{i}" for i in range(100)]
        result = filter_by_substring(strings, "string5")
        assert result == ["string5", "string50", "string51", "string52", "string53", "string54", "string55", "string56", "string57", "string58", "string59"]


@pytest.mark.parametrize("strings,substring,expected", [
    (["hello", "world"], "ell", ["hello"]),
    (["hello", "world"], "o", ["hello", "world"]),
    (["hello", "world"], "xyz", []),
    ([], "test", []),
    (["hello"], "", ["hello"]),
    (["test", "testing", "tested"], "test", ["test", "testing", "tested"]),
    (["abc", "def", "ghi"], "d", ["def"]),
    (["123", "456", "789"], "4", ["456"]),
])
def test_filter_by_substring_parametrized(strings, substring, expected):
    assert filter_by_substring(strings, substring) == expected