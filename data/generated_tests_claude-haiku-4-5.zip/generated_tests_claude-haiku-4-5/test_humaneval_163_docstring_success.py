# Test cases for HumanEval/163
# Generated using Claude API


def generate_integers(a, b):
    """
    Given two positive integers a and b, return the even digits between a
    and b, in ascending order.

    For example:
    generate_integers(2, 8) => [2, 4, 6, 8]
    generate_integers(8, 2) => [2, 4, 6, 8]
    generate_integers(10, 14) => []
    """

    lower = max(2, min(a, b))
    upper = min(8, max(a, b))

    return [i for i in range(lower, upper+1) if i % 2 == 0]


# Generated test cases:
import pytest


def generate_integers(a, b):
    lower = max(2, min(a, b))
    upper = min(8, max(a, b))
    return [i for i in range(lower, upper+1) if i % 2 == 0]


class TestGenerateIntegers:
    
    def test_basic_ascending_order(self):
        assert generate_integers(2, 8) == [2, 4, 6, 8]
    
    def test_basic_descending_order(self):
        assert generate_integers(8, 2) == [2, 4, 6, 8]
    
    def test_no_even_digits_in_range(self):
        assert generate_integers(10, 14) == []
    
    def test_single_even_digit(self):
        assert generate_integers(2, 2) == [2]
    
    def test_single_even_digit_4(self):
        assert generate_integers(4, 4) == [4]
    
    def test_single_even_digit_6(self):
        assert generate_integers(6, 6) == [6]
    
    def test_single_even_digit_8(self):
        assert generate_integers(8, 8) == [8]
    
    def test_range_below_2(self):
        assert generate_integers(0, 1) == []
    
    def test_range_above_8(self):
        assert generate_integers(9, 15) == []
    
    def test_range_partially_below_2(self):
        assert generate_integers(1, 4) == [2, 4]
    
    def test_range_partially_above_8(self):
        assert generate_integers(6, 10) == [6, 8]
    
    def test_range_spanning_all_even_digits(self):
        assert generate_integers(2, 8) == [2, 4, 6, 8]
    
    def test_range_with_odd_numbers_only(self):
        assert generate_integers(3, 7) == [4, 6]
    
    def test_range_with_single_odd_number(self):
        assert generate_integers(5, 5) == []
    
    def test_large_range_encompassing_all(self):
        assert generate_integers(0, 100) == [2, 4, 6, 8]
    
    def test_negative_to_positive(self):
        assert generate_integers(-5, 5) == [2, 4]
    
    def test_both_negative(self):
        assert generate_integers(-10, -5) == []
    
    def test_reversed_large_numbers(self):
        assert generate_integers(100, 0) == [2, 4, 6, 8]
    
    def test_adjacent_even_digits(self):
        assert generate_integers(2, 4) == [2, 4]
    
    def test_adjacent_even_digits_reversed(self):
        assert generate_integers(4, 2) == [2, 4]
    
    def test_range_2_to_3(self):
        assert generate_integers(2, 3) == [2]
    
    def test_range_7_to_8(self):
        assert generate_integers(7, 8) == [8]
    
    @pytest.mark.parametrize("a,b,expected", [
        (2, 8, [2, 4, 6, 8]),
        (8, 2, [2, 4, 6, 8]),
        (10, 14, []),
        (2, 2, [2]),
        (4, 6, [4, 6]),
        (6, 4, [4, 6]),
        (1, 9, [2, 4, 6, 8]),
        (0, 10, [2, 4, 6, 8]),
        (3, 5, [4]),
        (5, 7, [6]),
    ])
    def test_parametrized_cases(self, a, b, expected):
        assert generate_integers(a, b) == expected
