# Test cases for HumanEval/146
# Generated using Claude API


def specialFilter(nums):
    """Write a function that takes an array of numbers as input and returns 
    the number of elements in the array that are greater than 10 and both 
    first and last digits of a number are odd (1, 3, 5, 7, 9).
    For example:
    specialFilter([15, -73, 14, -15]) => 1 
    specialFilter([33, -2, -3, 45, 21, 109]) => 2
    """

    
    count = 0
    for num in nums:
        if num > 10:
            odd_digits = (1, 3, 5, 7, 9)
            number_as_string = str(num)
            if int(number_as_string[0]) in odd_digits and int(number_as_string[-1]) in odd_digits:
                count += 1
        
    return count 


# Generated test cases:
import pytest


def specialFilter(nums):
    
    count = 0
    for num in nums:
        if num > 10:
            odd_digits = (1, 3, 5, 7, 9)
            number_as_string = str(num)
            if int(number_as_string[0]) in odd_digits and int(number_as_string[-1]) in odd_digits:
                count += 1
        
    return count 


class TestSpecialFilter:
    
    def test_example_1(self):
        assert specialFilter([15, -73, 14, -15]) == 1
    
    def test_example_2(self):
        assert specialFilter([33, -2, -3, 45, 21, 109]) == 2
    
    def test_empty_list(self):
        assert specialFilter([]) == 0
    
    def test_no_elements_greater_than_10(self):
        assert specialFilter([1, 2, 3, 4, 5, 10]) == 0
    
    def test_all_elements_greater_than_10_with_odd_first_and_last(self):
        assert specialFilter([11, 13, 15, 17, 19]) == 5
    
    def test_elements_greater_than_10_but_even_first_digit(self):
        assert specialFilter([21, 23, 25, 27, 29]) == 0
    
    def test_elements_greater_than_10_but_even_last_digit(self):
        assert specialFilter([12, 32, 52, 72, 92]) == 0
    
    def test_elements_greater_than_10_with_odd_first_even_last(self):
        assert specialFilter([12, 14, 16, 18]) == 0
    
    def test_elements_greater_than_10_with_even_first_odd_last(self):
        assert specialFilter([21, 23, 25, 27, 29]) == 0
    
    def test_single_element_valid(self):
        assert specialFilter([15]) == 1
    
    def test_single_element_invalid(self):
        assert specialFilter([14]) == 0
    
    def test_single_element_not_greater_than_10(self):
        assert specialFilter([10]) == 0
    
    def test_negative_numbers(self):
        assert specialFilter([-15, -73, -14, -15]) == 0
    
    def test_mixed_positive_negative(self):
        assert specialFilter([15, -73, 14, -15, 31, 39]) == 3
    
    def test_large_numbers(self):
        assert specialFilter([111, 135, 159, 171, 191, 999]) == 6
    
    def test_large_numbers_with_even_digits(self):
        assert specialFilter([112, 134, 156, 172, 194]) == 0
    
    def test_two_digit_numbers_all_valid(self):
        assert specialFilter([11, 13, 15, 17, 19, 31, 33, 35, 37, 39, 51, 53, 55, 57, 59, 71, 73, 75, 77, 79, 91, 93, 95, 97, 99]) == 25
    
    def test_two_digit_numbers_mixed(self):
        assert specialFilter([11, 12, 13, 14, 15]) == 3
    
    def test_three_digit_numbers_valid(self):
        assert specialFilter([111, 131, 151, 171, 191, 313, 333, 353, 373, 393]) == 10
    
    def test_three_digit_numbers_invalid_first_digit(self):
        assert specialFilter([211, 231, 251, 271, 291]) == 0
    
    def test_three_digit_numbers_invalid_last_digit(self):
        assert specialFilter([112, 132, 152, 172, 192]) == 0
    
    def test_boundary_value_10(self):
        assert specialFilter([10]) == 0
    
    def test_boundary_value_11(self):
        assert specialFilter([11]) == 1
    
    def test_zero(self):
        assert specialFilter([0]) == 0
    
    def test_mixed_valid_invalid(self):
        assert specialFilter([15, 20, 31, 40, 57, 60, 73, 80, 99]) == 5
    
    def test_all_even_first_digits(self):
        assert specialFilter([21, 41, 61, 81]) == 0
    
    def test_all_even_last_digits(self):
        assert specialFilter([12, 32, 52, 72]) == 0
    
    def test_very_large_numbers(self):
        assert specialFilter([11111, 13579, 99999, 20000, 31111]) == 4
    
    def test_numbers_with_zeros(self):
        assert specialFilter([101, 103, 105, 107, 109, 301, 303, 305, 307, 309]) == 10