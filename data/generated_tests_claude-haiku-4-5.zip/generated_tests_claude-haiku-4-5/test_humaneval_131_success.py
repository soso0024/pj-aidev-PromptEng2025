# Test cases for HumanEval/131
# Generated using Claude API


def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.
    For example:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """

    product = 1
    odd_count = 0
    for digit in str(n):
        int_digit = int(digit)
        if int_digit%2 == 1:
            product= product*int_digit
            odd_count+=1
    if odd_count ==0:
        return 0
    else:
        return product


# Generated test cases:
import pytest


def digits(n):
    product = 1
    odd_count = 0
    for digit in str(n):
        int_digit = int(digit)
        if int_digit%2 == 1:
            product= product*int_digit
            odd_count+=1
    if odd_count ==0:
        return 0
    else:
        return product


class TestDigits:
    
    @pytest.mark.parametrize("input_val,expected", [
        (0, 0),
        (1, 1),
        (2, 0),
        (3, 3),
        (5, 5),
        (9, 9),
    ])
    def test_single_digit_numbers(self, input_val, expected):
        assert digits(input_val) == expected
    
    @pytest.mark.parametrize("input_val,expected", [
        (13, 3),
        (15, 5),
        (24, 0),
        (35, 15),
        (57, 35),
        (99, 81),
        (11, 1),
        (22, 0),
        (135, 15),
        (246, 0),
    ])
    def test_two_and_three_digit_numbers(self, input_val, expected):
        assert digits(input_val) == expected
    
    @pytest.mark.parametrize("input_val,expected", [
        (1357, 105),
        (2468, 0),
        (1111, 1),
        (1357911, 945),
        (2222, 0),
    ])
    def test_larger_numbers(self, input_val, expected):
        assert digits(input_val) == expected
    
    @pytest.mark.parametrize("input_val,expected", [
        (20, 0),
        (200, 0),
    ])
    def test_numbers_with_only_even_digits(self, input_val, expected):
        assert digits(input_val) == expected
    
    @pytest.mark.parametrize("input_val,expected", [
        (111, 1),
        (333, 27),
        (555, 125),
        (777, 343),
        (999, 729),
    ])
    def test_numbers_with_only_odd_digits(self, input_val, expected):
        assert digits(input_val) == expected
    
    @pytest.mark.parametrize("input_val,expected", [
        (12, 1),
        (21, 1),
        (123, 3),
        (321, 3),
        (1234, 3),
        (4321, 3),
    ])
    def test_mixed_even_and_odd_digits(self, input_val, expected):
        assert digits(input_val) == expected
    
    def test_zero(self):
        assert digits(0) == 0
    
    def test_single_odd_digit(self):
        assert digits(7) == 7
    
    def test_single_even_digit(self):
        assert digits(8) == 0
    
    def test_large_number_with_many_odd_digits(self):
        assert digits(13579) == 945
    
    def test_alternating_odd_even(self):
        assert digits(1212) == 1
    
    def test_alternating_even_odd(self):
        assert digits(2121) == 1
    
    def test_product_of_multiple_odd_digits(self):
        assert digits(135) == 15
        assert digits(1357) == 105
        assert digits(13579) == 945
    
    def test_leading_zeros_not_applicable(self):
        assert digits(101) == 1
        assert digits(1001) == 1
    
    def test_all_ones(self):
        assert digits(1111111) == 1
    
    def test_all_nines(self):
        assert digits(999) == 729
    
    def test_mixed_with_zeros(self):
        assert digits(105) == 5
        assert digits(1050) == 5
        assert digits(10503) == 15