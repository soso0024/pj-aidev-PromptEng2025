# Test cases for HumanEval/130
# Generated using Claude API


def tri(n):
    """Everyone knows Fibonacci sequence, it was studied deeply by mathematicians in 
    the last couple centuries. However, what people don't know is Tribonacci sequence.
    Tribonacci sequence is defined by the recurrence:
    tri(1) = 3
    tri(n) = 1 + n / 2, if n is even.
    tri(n) =  tri(n - 1) + tri(n - 2) + tri(n + 1), if n is odd.
    For example:
    tri(2) = 1 + (2 / 2) = 2
    tri(4) = 3
    tri(3) = tri(2) + tri(1) + tri(4)
           = 2 + 3 + 3 = 8 
    You are given a non-negative integer number n, you have to a return a list of the 
    first n + 1 numbers of the Tribonacci sequence.
    Examples:
    tri(3) = [1, 3, 2, 8]
    """

    if n == 0:
        return [1]
    my_tri = [1, 3]
    for i in range(2, n + 1):
        if i % 2 == 0:
            my_tri.append(i / 2 + 1)
        else:
            my_tri.append(my_tri[i - 1] + my_tri[i - 2] + (i + 3) / 2)
    return my_tri


# Generated test cases:
import pytest


class TestTri:
    def test_n_zero(self):
        from test_humaneval_130_ast import tri
        assert tri(0) == [1]

    def test_n_one(self):
        result = tri(1)
        assert result == [1, 3]

    def test_n_two(self):
        result = tri(2)
        assert result == [1, 3, 2.0]

    def test_n_three(self):
        result = tri(3)
        assert len(result) == 4
        assert result[0] == 1
        assert result[1] == 3
        assert result[2] == 2.0
        assert result[3] == 8.0

    def test_n_four(self):
        result = tri(4)
        assert len(result) == 5
        assert result[0] == 1
        assert result[1] == 3
        assert result[2] == 2.0
        assert result[3] == 8.0
        assert result[4] == 3.0

    def test_n_five(self):
        result = tri(5)
        assert len(result) == 6
        assert result[0] == 1
        assert result[1] == 3
        assert result[2] == 2.0
        assert result[3] == 8.0
        assert result[4] == 3.0
        assert result[5] == 15.0

    def test_n_six(self):
        result = tri(6)
        assert len(result) == 7
        assert result[0] == 1
        assert result[1] == 3
        assert result[2] == 2.0
        assert result[3] == 8.0
        assert result[4] == 3.0
        assert result[5] == 15.0
        assert result[6] == 4.0

    def test_n_ten(self):
        result = tri(10)
        assert len(result) == 11
        assert result[0] == 1
        assert result[1] == 3

    def test_return_type_is_list(self):
        result = tri(5)
        assert isinstance(result, list)

    def test_list_length_matches_n_plus_one(self):
        for n in range(0, 8):
            result = tri(n)
            assert len(result) == n + 1

    def test_first_element_always_one(self):
        for n in range(0, 10):
            result = tri(n)
            assert result[0] == 1

    def test_second_element_is_three_when_n_greater_than_zero(self):
        for n in range(1, 10):
            result = tri(n)
            assert result[1] == 3

    def test_even_indices_calculation(self):
        result = tri(8)
        assert result[2] == 2.0
        assert result[4] == 3.0
        assert result[6] == 4.0
        assert result[8] == 5.0

    def test_odd_indices_use_previous_elements(self):
        result = tri(7)
        assert result[3] == result[2] + result[1] + 3.0
        assert result[5] == result[4] + result[3] + 4.0
        assert result[7] == result[6] + result[5] + 5.0

    def test_large_n(self):
        result = tri(20)
        assert len(result) == 21
        assert result[0] == 1
        assert result[1] == 3

    def test_sequence_grows(self):
        result = tri(15)
        assert len(result) == 16
        for i in range(len(result) - 1):
            assert result[i] is not None

    def test_n_equals_one_returns_correct_list(self):
        assert tri(1) == [1, 3]

    def test_all_elements_are_numeric(self):
        result = tri(10)
        for element in result:
            assert isinstance(element, (int, float))

    def test_even_index_formula(self):
        result = tri(6)
        for i in range(2, 7, 2):
            expected = i / 2 + 1
            assert result[i] == expected

    def test_odd_index_formula(self):
        result = tri(7)
        for i in range(3, 8, 2):
            expected = result[i - 1] + result[i - 2] + (i + 3) / 2
            assert result[i] == expected

    @pytest.mark.parametrize("n,expected_length", [
        (0, 1),
        (1, 2),
        (2, 3),
        (3, 4),
        (4, 5),
        (5, 6),
        (10, 11),
        (20, 21),
    ])
    def test_length_parametrized(self, n, expected_length):
        result = tri(n)
        assert len(result) == expected_length

    @pytest.mark.parametrize("n,first_two", [
        (0, [1]),
        (1, [1, 3]),
        (2, [1, 3]),
        (5, [1, 3]),
        (10, [1, 3]),
    ])
    def test_first_elements_parametrized(self, n, first_two):
        result = tri(n)
        assert result[:len(first_two)] == first_two