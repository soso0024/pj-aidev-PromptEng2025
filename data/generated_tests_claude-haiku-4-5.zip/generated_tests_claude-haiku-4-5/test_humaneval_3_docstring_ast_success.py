# Test cases for HumanEval/3
# Generated using Claude API

from typing import List


def below_zero(operations: List[int]) -> bool:
    """ You're given a list of deposit and withdrawal operations on a bank account that starts with
    zero balance. Your task is to detect if at any point the balance of account fallls below zero, and
    at that point function should return True. Otherwise it should return False.
    >>> below_zero([1, 2, 3])
    False
    >>> below_zero([1, 2, -4, 5])
    True
    """

    balance = 0

    for op in operations:
        balance += op
        if balance < 0:
            return True

    return False


# Generated test cases:
import pytest
from typing import List


def below_zero(operations: List[int]) -> bool:
    balance = 0

    for op in operations:
        balance += op
        if balance < 0:
            return True

    return False


class TestBelowZero:
    def test_empty_list(self):
        assert below_zero([]) == False

    def test_all_positive(self):
        assert below_zero([1, 2, 3]) == False

    def test_single_negative(self):
        assert below_zero([-1]) == True

    def test_single_positive(self):
        assert below_zero([1]) == False

    def test_goes_negative_then_positive(self):
        assert below_zero([1, 2, -4, 5]) == True

    def test_zero_operations(self):
        assert below_zero([0, 0, 0]) == False

    def test_negative_at_end(self):
        assert below_zero([5, 5, -15]) == True

    def test_multiple_negatives(self):
        assert below_zero([-1, -2, -3]) == True

    def test_large_positive_then_large_negative(self):
        assert below_zero([100, -150]) == True

    def test_balanced_operations(self):
        assert below_zero([10, -5, 10, -5]) == False

    def test_goes_negative_immediately(self):
        assert below_zero([-1, 100]) == True

    def test_large_numbers(self):
        assert below_zero([1000000, -1000001]) == True

    def test_many_small_negatives(self):
        assert below_zero([1, -1, -1, -1]) == True

    def test_zero_then_negative(self):
        assert below_zero([0, -1]) == True

    def test_negative_zero_positive(self):
        assert below_zero([-5, 5, 1]) == True

    @pytest.mark.parametrize("operations,expected", [
        ([1, 2, 3], False),
        ([1, 2, -4, 5], True),
        ([], False),
        ([-1], True),
        ([0], False),
        ([5, -10], True),
        ([10, 10, -5], False),
        ([-100, 200], True),
        ([1, 1, 1, -5], True),
        ([0, 0, 0, 0], False),
    ])
    def test_parametrized_cases(self, operations, expected):
        assert below_zero(operations) == expected
