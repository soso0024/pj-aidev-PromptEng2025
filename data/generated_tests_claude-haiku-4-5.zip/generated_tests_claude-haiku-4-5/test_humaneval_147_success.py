# Test cases for HumanEval/147
# Generated using Claude API


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
        For each i (1 ≤ i ≤ n), the value of a[i] = i * i - i + 1.
        Return the number of triples (a[i], a[j], a[k]) of a where i < j < k, 
    and a[i] + a[j] + a[k] is a multiple of 3.

    Example :
        Input: n = 5
        Output: 1
        Explanation: 
        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """

    A = [i*i - i + 1 for i in range(1,n+1)]
    ans = []
    for i in range(n):
        for j in range(i+1,n):
            for k in range(j+1,n):
                if (A[i]+A[j]+A[k])%3 == 0:
                    ans += [(A[i],A[j],A[k])]
    return len(ans)


# Generated test cases:
import pytest


def get_max_triples(n):
    A = [i*i - i + 1 for i in range(1,n+1)]
    ans = []
    for i in range(n):
        for j in range(i+1,n):
            for k in range(j+1,n):
                if (A[i]+A[j]+A[k])%3 == 0:
                    ans += [(A[i],A[j],A[k])]
    return len(ans)


class TestGetMaxTriples:
    
    def test_n_zero(self):
        assert get_max_triples(0) == 0
    
    def test_n_one(self):
        assert get_max_triples(1) == 0
    
    def test_n_two(self):
        assert get_max_triples(2) == 0
    
    def test_n_three(self):
        result = get_max_triples(3)
        assert isinstance(result, int)
        assert result >= 0
    
    def test_n_four(self):
        result = get_max_triples(4)
        assert isinstance(result, int)
        assert result >= 0
    
    def test_n_five(self):
        result = get_max_triples(5)
        assert isinstance(result, int)
        assert result >= 0
    
    def test_n_ten(self):
        result = get_max_triples(10)
        assert isinstance(result, int)
        assert result >= 0
    
    def test_n_fifteen(self):
        result = get_max_triples(15)
        assert isinstance(result, int)
        assert result >= 0
    
    def test_n_twenty(self):
        result = get_max_triples(20)
        assert isinstance(result, int)
        assert result >= 0
    
    def test_return_type_is_int(self):
        result = get_max_triples(5)
        assert isinstance(result, int)
    
    def test_return_value_non_negative(self):
        for n in range(0, 15):
            result = get_max_triples(n)
            assert result >= 0
    
    def test_monotonic_property(self):
        prev_result = get_max_triples(3)
        for n in range(4, 12):
            current_result = get_max_triples(n)
            assert current_result >= prev_result
            prev_result = current_result
    
    def test_n_six(self):
        result = get_max_triples(6)
        assert result == 4
    
    def test_n_seven(self):
        result = get_max_triples(7)
        assert isinstance(result, int)
        assert result >= 1
    
    def test_n_eight(self):
        result = get_max_triples(8)
        assert isinstance(result, int)
        assert result >= 0
    
    def test_n_nine(self):
        result = get_max_triples(9)
        assert isinstance(result, int)
        assert result >= 0
    
    def test_n_twelve(self):
        result = get_max_triples(12)
        assert isinstance(result, int)
        assert result >= 0
    
    def test_large_n(self):
        result = get_max_triples(30)
        assert isinstance(result, int)
        assert result >= 0
    
    def test_consistency_small_values(self):
        assert get_max_triples(3) == get_max_triples(3)
        assert get_max_triples(5) == get_max_triples(5)
    
    def test_n_eleven(self):
        result = get_max_triples(11)
        assert isinstance(result, int)
        assert result >= 0
    
    def test_n_thirteen(self):
        result = get_max_triples(13)
        assert isinstance(result, int)
        assert result >= 0
    
    def test_n_sixteen(self):
        result = get_max_triples(16)
        assert isinstance(result, int)
        assert result >= 0
    
    def test_n_twenty_five(self):
        result = get_max_triples(25)
        assert isinstance(result, int)
        assert result >= 0


@pytest.mark.parametrize("n,expected_type", [
    (0, int),
    (1, int),
    (2, int),
    (3, int),
    (5, int),
    (10, int),
    (20, int),
])
def test_return_type(n, expected_type):
    result = get_max_triples(n)
    assert isinstance(result, expected_type)


@pytest.mark.parametrize("n", [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
def test_non_negative_result(n):
    result = get_max_triples(n)
    assert result >= 0


@pytest.mark.parametrize("n1,n2", [
    (3, 4),
    (5, 6),
    (8, 9),
    (10, 11),
])
def test_increasing_trend(n1, n2):
    result1 = get_max_triples(n1)
    result2 = get_max_triples(n2)
    assert result2 >= result1