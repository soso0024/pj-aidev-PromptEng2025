# Test cases for HumanEval/144
# Generated using Claude API


def simplify(x, n):
    """Your task is to implement a function that will simplify the expression
    x * n. The function returns True if x * n evaluates to a whole number and False
    otherwise. Both x and n, are string representation of a fraction, and have the following format,
    <numerator>/<denominator> where both numerator and denominator are positive whole numbers.

    You can assume that x, and n are valid fractions, and do not have zero as denominator.

    simplify("1/5", "5/1") = True
    simplify("1/6", "2/1") = False
    simplify("7/10", "10/2") = False
    """

    a, b = x.split("/")
    c, d = n.split("/")
    numerator = int(a) * int(c)
    denom = int(b) * int(d)
    if (numerator/denom == int(numerator/denom)):
        return True
    return False


# Generated test cases:
import pytest


@pytest.mark.parametrize("x,n,expected", [
    ("1/5", "5/1", True),
    ("1/6", "2/1", False),
    ("7/10", "10/2", False),
    ("1/1", "1/1", True),
    ("2/2", "1/1", True),
    ("1/2", "2/1", True),
    ("1/3", "3/1", True),
    ("2/3", "3/2", True),
    ("1/4", "4/1", True),
    ("3/4", "4/3", True),
    ("1/2", "1/2", False),
    ("2/5", "5/2", True),
    ("3/7", "7/3", True),
    ("1/10", "10/1", True),
    ("5/6", "6/5", True),
    ("1/100", "100/1", True),
    ("99/100", "100/99", True),
    ("1/2", "3/4", False),
    ("2/3", "3/5", False),
    ("4/5", "5/4", True),
    ("7/8", "8/7", True),
    ("10/11", "11/10", True),
    ("1/1", "2/2", True),
    ("3/3", "1/1", True),
    ("5/5", "1/1", True),
    ("1/7", "7/1", True),
    ("2/7", "7/2", True),
    ("3/8", "8/3", True),
    ("4/9", "9/4", True),
    ("6/7", "7/6", True),
])
def test_simplify(x, n, expected):
    from test_humaneval_144_docstring import simplify
    assert simplify(x, n) == expected


def test_simplify_basic_true():
    assert simplify("1/5", "5/1") is True


def test_simplify_basic_false():
    assert simplify("1/6", "2/1") is False


def test_simplify_identity():
    assert simplify("1/1", "1/1") is True


def test_simplify_reciprocals():
    assert simplify("2/3", "3/2") is True
    assert simplify("4/5", "5/4") is True
    assert simplify("7/8", "8/7") is True


def test_simplify_same_fraction():
    assert simplify("2/2", "1/1") is True
    assert simplify("3/3", "1/1") is True


def test_simplify_large_numbers():
    assert simplify("1/1000", "1000/1") is True
    assert simplify("999/1000", "1000/999") is True


def test_simplify_non_reciprocals():
    assert simplify("1/2", "1/2") is False
    assert simplify("2/3", "3/5") is False
    assert simplify("3/8", "8/3") is True


def test_simplify_whole_number_results():
    assert simplify("1/2", "2/1") is True
    assert simplify("1/3", "3/1") is True
    assert simplify("1/4", "4/1") is True


def test_simplify_complex_fractions():
    assert simplify("5/6", "6/5") is True
    assert simplify("10/11", "11/10") is True
    assert simplify("99/100", "100/99") is True