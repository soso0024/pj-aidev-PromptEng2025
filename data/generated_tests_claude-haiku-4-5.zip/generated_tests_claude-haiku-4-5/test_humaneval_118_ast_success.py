# Test cases for HumanEval/118
# Generated using Claude API


def get_closest_vowel(word):
    """You are given a word. Your task is to find the closest vowel that stands between 
    two consonants from the right side of the word (case sensitive).
    
    Vowels in the beginning and ending doesn't count. Return empty string if you didn't
    find any vowel met the above condition. 

    You may assume that the given string contains English letter only.

    Example:
    get_closest_vowel("yogurt") ==> "u"
    get_closest_vowel("FULL") ==> "U"
    get_closest_vowel("quick") ==> ""
    get_closest_vowel("ab") ==> ""
    """

    if len(word) < 3:
        return ""

    vowels = {"a", "e", "i", "o", "u", "A", "E", 'O', 'U', 'I'}
    for i in range(len(word)-2, 0, -1):
        if word[i] in vowels:
            if (word[i+1] not in vowels) and (word[i-1] not in vowels):
                return word[i]
    return ""


# Generated test cases:
import pytest


class TestGetClosestVowel:
    
    def test_empty_string(self):
        from test_humaneval_118_ast import get_closest_vowel
        assert get_closest_vowel("") == ""
    
    def test_single_character(self):
        assert get_closest_vowel("a") == ""
    
    def test_two_characters(self):
        assert get_closest_vowel("ab") == ""
    
    def test_three_characters_vowel_in_middle(self):
        assert get_closest_vowel("abc") == ""
    
    def test_three_characters_no_vowel_in_middle(self):
        assert get_closest_vowel("bcd") == ""
    
    def test_vowel_surrounded_by_consonants(self):
        assert get_closest_vowel("bcde") == ""
    
    def test_multiple_vowels_returns_closest(self):
        assert get_closest_vowel("abcde") == ""
    
    def test_vowel_at_end_not_valid(self):
        assert get_closest_vowel("bca") == ""
    
    def test_vowel_at_start_not_valid(self):
        assert get_closest_vowel("abc") == ""
    
    def test_consecutive_vowels(self):
        assert get_closest_vowel("aeiou") == ""
    
    def test_uppercase_vowel(self):
        assert get_closest_vowel("bcde") == ""
    
    def test_uppercase_vowel_surrounded(self):
        assert get_closest_vowel("bcdE") == ""
    
    def test_mixed_case_vowels(self):
        assert get_closest_vowel("bcAde") == "A"
    
    def test_long_word_with_multiple_valid_vowels(self):
        assert get_closest_vowel("abcdefghijk") == "i"
    
    def test_vowel_with_vowel_before(self):
        assert get_closest_vowel("aebcd") == ""
    
    def test_vowel_with_vowel_after(self):
        assert get_closest_vowel("bceab") == ""
    
    def test_all_consonants(self):
        assert get_closest_vowel("bcdfg") == ""
    
    def test_all_vowels(self):
        assert get_closest_vowel("aeiou") == ""
    
    def test_word_with_spaces(self):
        assert get_closest_vowel("b c e") == ""
    
    def test_word_with_numbers(self):
        assert get_closest_vowel("b1c2e") == ""
    
    def test_special_characters_as_consonants(self):
        assert get_closest_vowel("b!c@e") == ""
    
    def test_rightmost_valid_vowel_returned(self):
        assert get_closest_vowel("abcbeb") == "e"
    
    def test_single_vowel_valid(self):
        assert get_closest_vowel("bab") == "a"
    
    def test_multiple_valid_vowels_rightmost_returned(self):
        assert get_closest_vowel("babab") == "a"
    
    def test_vowel_surrounded_by_same_consonant(self):
        assert get_closest_vowel("bab") == "a"
    
    def test_long_consonant_sequence_with_vowel(self):
        assert get_closest_vowel("bcdfghjklmnpqrstvwxyz") == ""
    
    def test_vowel_o_lowercase(self):
        assert get_closest_vowel("bcd") == ""
    
    def test_vowel_o_uppercase(self):
        assert get_closest_vowel("bcO") == ""
    
    def test_vowel_u_lowercase(self):
        assert get_closest_vowel("bcu") == ""
    
    def test_vowel_u_uppercase(self):
        assert get_closest_vowel("bcU") == ""
    
    def test_vowel_i_lowercase(self):
        assert get_closest_vowel("bci") == ""
    
    def test_vowel_i_uppercase(self):
        assert get_closest_vowel("bcI") == ""
    
    def test_complex_word_pattern(self):
        assert get_closest_vowel("programming") == "i"
    
    def test_word_ending_with_consonant_cluster(self):
        assert get_closest_vowel("abcdfg") == ""
    
    def test_alternating_vowels_consonants(self):
        assert get_closest_vowel("ababab") == "a"


@pytest.mark.parametrize("word,expected", [
    ("", ""),
    ("a", ""),
    ("ab", ""),
    ("abc", ""),
    ("bcd", ""),
    ("bcde", ""),
    ("abcde", ""),
    ("bca", ""),
    ("aeiou", ""),
    ("bcdfg", ""),
    ("bab", "a"),
    ("bcO", ""),
    ("bcu", ""),
    ("bci", ""),
    ("programming", "i"),
])
def test_get_closest_vowel_parametrized(word, expected):
    assert get_closest_vowel(word) == expected