# Test cases for HumanEval/83
# Generated using Claude API


def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """

    if n == 1: return 1
    return 18 * (10 ** (n - 2))


# Generated test cases:
import pytest


def starts_one_ends(n):
    if n == 1: return 1
    return 18 * (10 ** (n - 2))


class TestStartsOneEnds:
    
    @pytest.mark.parametrize("n,expected", [
        (1, 1),
        (2, 18),
        (3, 180),
        (4, 1800),
        (5, 18000),
        (6, 180000),
        (7, 1800000),
        (8, 18000000),
        (9, 180000000),
        (10, 1800000000),
    ])
    def test_valid_inputs(self, n, expected):
        assert starts_one_ends(n) == expected
    
    def test_n_equals_1(self):
        assert starts_one_ends(1) == 1
    
    def test_n_equals_2(self):
        assert starts_one_ends(2) == 18
    
    def test_n_equals_3(self):
        assert starts_one_ends(3) == 180
    
    def test_large_n(self):
        result = starts_one_ends(20)
        assert result == 18 * (10 ** 18)
    
    def test_return_type_is_int(self):
        assert isinstance(starts_one_ends(1), int)
        assert isinstance(starts_one_ends(5), int)
    
    def test_result_divisible_by_18_for_n_greater_than_1(self):
        for n in range(2, 10):
            assert starts_one_ends(n) % 18 == 0
    
    def test_result_increases_by_factor_of_10(self):
        for n in range(2, 8):
            ratio = starts_one_ends(n + 1) / starts_one_ends(n)
            assert ratio == 10
    
    def test_n_equals_100(self):
        result = starts_one_ends(100)
        assert result == 18 * (10 ** 98)
    
    def test_result_starts_with_1_and_ends_with_8_pattern(self):
        assert starts_one_ends(2) == 18
        assert starts_one_ends(3) == 180
        assert starts_one_ends(4) == 1800
        assert str(starts_one_ends(2)).startswith('1')
        assert str(starts_one_ends(2)).endswith('8')
        assert str(starts_one_ends(3)).startswith('1')
        assert str(starts_one_ends(3)).endswith('0')
