# Test cases for HumanEval/44
# Generated using Claude API



def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """

    ret = ""
    while x > 0:
        ret = str(x % base) + ret
        x //= base
    return ret


# Generated test cases:
import pytest


def change_base(x: int, base: int):
    ret = ""
    while x > 0:
        ret = str(x % base) + ret
        x //= base
    return ret


class TestChangeBase:
    
    @pytest.mark.parametrize("x,base,expected", [
        (8, 3, "22"),
        (8, 2, "1000"),
        (7, 2, "111"),
    ])
    def test_docstring_examples(self, x, base, expected):
        assert change_base(x, base) == expected
    
    @pytest.mark.parametrize("x,base,expected", [
        (0, 2, ""),
        (0, 3, ""),
        (0, 9, ""),
    ])
    def test_zero_input(self, x, base, expected):
        assert change_base(x, base) == expected
    
    @pytest.mark.parametrize("x,base,expected", [
        (1, 2, "1"),
        (1, 3, "1"),
        (1, 9, "1"),
    ])
    def test_one_input(self, x, base, expected):
        assert change_base(x, base) == expected
    
    @pytest.mark.parametrize("x,base,expected", [
        (10, 2, "1010"),
        (10, 3, "101"),
        (10, 5, "20"),
        (10, 9, "11"),
    ])
    def test_base_conversion_10(self, x, base, expected):
        assert change_base(x, base) == expected
    
    @pytest.mark.parametrize("x,base,expected", [
        (15, 2, "1111"),
        (15, 3, "120"),
        (15, 5, "30"),
        (15, 9, "16"),
    ])
    def test_base_conversion_15(self, x, base, expected):
        assert change_base(x, base) == expected
    
    @pytest.mark.parametrize("x,base,expected", [
        (100, 2, "1100100"),
        (100, 3, "10201"),
        (100, 5, "400"),
        (100, 9, "121"),
    ])
    def test_base_conversion_100(self, x, base, expected):
        assert change_base(x, base) == expected
    
    @pytest.mark.parametrize("x,base,expected", [
        (255, 2, "11111111"),
        (255, 3, "100110"),
        (255, 5, "2010"),
        (255, 9, "313"),
    ])
    def test_base_conversion_255(self, x, base, expected):
        assert change_base(x, base) == expected
    
    @pytest.mark.parametrize("x,base,expected", [
        (1000, 2, "1111101000"),
        (1000, 3, "1101001"),
        (1000, 5, "13000"),
        (1000, 9, "1331"),
    ])
    def test_base_conversion_1000(self, x, base, expected):
        assert change_base(x, base) == expected
    
    @pytest.mark.parametrize("x,base,expected", [
        (2, 2, "10"),
        (3, 2, "11"),
        (4, 2, "100"),
        (5, 2, "101"),
        (6, 2, "110"),
        (7, 2, "111"),
    ])
    def test_binary_conversions(self, x, base, expected):
        assert change_base(x, base) == expected
    
    @pytest.mark.parametrize("x,base,expected", [
        (3, 3, "10"),
        (9, 3, "100"),
        (27, 3, "1000"),
        (81, 3, "10000"),
    ])
    def test_ternary_conversions(self, x, base, expected):
        assert change_base(x, base) == expected
    
    @pytest.mark.parametrize("x,base,expected", [
        (5, 5, "10"),
        (25, 5, "100"),
        (125, 5, "1000"),
    ])
    def test_base_5_conversions(self, x, base, expected):
        assert change_base(x, base) == expected
    
    @pytest.mark.parametrize("x,base,expected", [
        (9, 9, "10"),
        (81, 9, "100"),
        (729, 9, "1000"),
    ])
    def test_base_9_conversions(self, x, base, expected):
        assert change_base(x, base) == expected
    
    def test_large_number(self):
        assert change_base(1000000, 2) == "11110100001001000000"
    
    def test_large_number_base_9(self):
        assert change_base(1000000, 9) == "1783661"
    
    def test_return_type_is_string(self):
        result = change_base(8, 2)
        assert isinstance(result, str)
    
    def test_all_bases_2_to_9(self):
        x = 42
        for base in range(2, 10):
            result = change_base(x, base)
            assert isinstance(result, str)
            assert all(c.isdigit() for c in result)