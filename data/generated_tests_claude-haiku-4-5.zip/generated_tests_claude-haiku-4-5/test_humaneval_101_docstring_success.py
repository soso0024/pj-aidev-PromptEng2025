# Test cases for HumanEval/101
# Generated using Claude API


def words_string(s):
    """
    You will be given a string of words separated by commas or spaces. Your task is
    to split the string into words and return an array of the words.
    
    For example:
    words_string("Hi, my name is John") == ["Hi", "my", "name", "is", "John"]
    words_string("One, two, three, four, five, six") == ["One", "two", "three", "four", "five", "six"]
    """

    if not s:
        return []

    s_list = []

    for letter in s:
        if letter == ',':
            s_list.append(' ')
        else:
            s_list.append(letter)

    s_list = "".join(s_list)
    return s_list.split()


# Generated test cases:
import pytest


def words_string(s):
    if not s:
        return []

    s_list = []

    for letter in s:
        if letter == ',':
            s_list.append(' ')
        else:
            s_list.append(letter)

    s_list = "".join(s_list)
    return s_list.split()


class TestWordsString:
    
    @pytest.mark.parametrize("input_str,expected", [
        ("Hi, my name is John", ["Hi", "my", "name", "is", "John"]),
        ("One, two, three, four, five, six", ["One", "two", "three", "four", "five", "six"]),
        ("", []),
        ("hello", ["hello"]),
        ("a b c", ["a", "b", "c"]),
        ("a,b,c", ["a", "b", "c"]),
        ("a, b, c", ["a", "b", "c"]),
        ("  hello  world  ", ["hello", "world"]),
        (",,,,", []),
        ("a,,b", ["a", "b"]),
        ("a  b", ["a", "b"]),
        ("single", ["single"]),
        ("one two three", ["one", "two", "three"]),
        ("one,two,three", ["one", "two", "three"]),
        ("  ,  ,  ", []),
        ("word1, word2, word3, word4", ["word1", "word2", "word3", "word4"]),
        ("a", ["a"]),
        ("a,", ["a"]),
        (",a", ["a"]),
        ("a, b, c, d, e", ["a", "b", "c", "d", "e"]),
        ("multiple   spaces", ["multiple", "spaces"]),
        ("comma,and space, mixed", ["comma", "and", "space", "mixed"]),
    ])
    def test_words_string(self, input_str, expected):
        assert words_string(input_str) == expected
    
    def test_empty_string(self):
        assert words_string("") == []
    
    def test_single_word(self):
        assert words_string("hello") == ["hello"]
    
    def test_words_with_spaces(self):
        assert words_string("hello world") == ["hello", "world"]
    
    def test_words_with_commas(self):
        assert words_string("hello,world") == ["hello", "world"]
    
    def test_words_with_commas_and_spaces(self):
        assert words_string("hello, world") == ["hello", "world"]
    
    def test_multiple_commas(self):
        assert words_string("a,,b") == ["a", "b"]
    
    def test_multiple_spaces(self):
        assert words_string("a  b") == ["a", "b"]
    
    def test_leading_trailing_spaces(self):
        assert words_string("  hello world  ") == ["hello", "world"]
    
    def test_only_commas(self):
        assert words_string(",,,") == []
    
    def test_only_spaces(self):
        assert words_string("   ") == []
    
    def test_complex_string(self):
        assert words_string("One, two, three, four, five, six") == ["One", "two", "three", "four", "five", "six"]
    
    def test_mixed_separators(self):
        assert words_string("a, b c, d e f") == ["a", "b", "c", "d", "e", "f"]
