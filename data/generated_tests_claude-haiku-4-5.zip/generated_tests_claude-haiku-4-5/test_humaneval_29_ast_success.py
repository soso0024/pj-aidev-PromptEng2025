# Test cases for HumanEval/29
# Generated using Claude API

from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    """ Filter an input list of strings only for ones that start with a given prefix.
    >>> filter_by_prefix([], 'a')
    []
    >>> filter_by_prefix(['abc', 'bcd', 'cde', 'array'], 'a')
    ['abc', 'array']
    """

    return [x for x in strings if x.startswith(prefix)]


# Generated test cases:
import pytest
from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    return [x for x in strings if x.startswith(prefix)]


class TestFilterByPrefix:
    def test_empty_list(self):
        result = filter_by_prefix([], "test")
        assert result == []

    def test_empty_prefix(self):
        result = filter_by_prefix(["apple", "banana", "cherry"], "")
        assert result == ["apple", "banana", "cherry"]

    def test_no_matches(self):
        result = filter_by_prefix(["apple", "banana", "cherry"], "z")
        assert result == []

    def test_single_match(self):
        result = filter_by_prefix(["apple", "banana", "cherry"], "app")
        assert result == ["apple"]

    def test_multiple_matches(self):
        result = filter_by_prefix(["apple", "apricot", "application", "banana"], "app")
        assert result == ["apple", "application"]

    def test_exact_match(self):
        result = filter_by_prefix(["test"], "test")
        assert result == ["test"]

    def test_case_sensitive(self):
        result = filter_by_prefix(["Apple", "apple", "APPLE"], "app")
        assert result == ["apple"]

    def test_case_sensitive_uppercase(self):
        result = filter_by_prefix(["Apple", "apple", "APPLE"], "App")
        assert result == ["Apple"]

    def test_single_character_prefix(self):
        result = filter_by_prefix(["apple", "banana", "apricot"], "a")
        assert result == ["apple", "apricot"]

    def test_prefix_longer_than_strings(self):
        result = filter_by_prefix(["a", "ab", "abc"], "abcd")
        assert result == []

    def test_special_characters_in_strings(self):
        result = filter_by_prefix(["@test", "@testing", "#test"], "@")
        assert result == ["@test", "@testing"]

    def test_special_characters_in_prefix(self):
        result = filter_by_prefix(["@test", "@testing", "test"], "@t")
        assert result == ["@test", "@testing"]

    def test_whitespace_in_prefix(self):
        result = filter_by_prefix(["hello world", "hello there", "goodbye"], "hello ")
        assert result == ["hello world", "hello there"]

    def test_whitespace_only_strings(self):
        result = filter_by_prefix(["   ", "  ", " test"], " ")
        assert result == ["   ", "  ", " test"]

    def test_numeric_strings(self):
        result = filter_by_prefix(["123", "124", "234"], "12")
        assert result == ["123", "124"]

    def test_mixed_content(self):
        result = filter_by_prefix(["test123", "test456", "other123"], "test")
        assert result == ["test123", "test456"]

    def test_unicode_characters(self):
        result = filter_by_prefix(["café", "car", "cat"], "ca")
        assert result == ["café", "car", "cat"]

    def test_unicode_prefix(self):
        result = filter_by_prefix(["café", "car", "cat"], "caf")
        assert result == ["café"]

    def test_duplicate_strings(self):
        result = filter_by_prefix(["apple", "apple", "apricot", "apple"], "app")
        assert result == ["apple", "apple", "apple"]

    def test_order_preserved(self):
        result = filter_by_prefix(["zebra", "apple", "banana", "apricot"], "a")
        assert result == ["apple", "apricot"]

    def test_very_long_prefix(self):
        long_prefix = "a" * 1000
        result = filter_by_prefix([long_prefix, long_prefix + "b"], long_prefix)
        assert result == [long_prefix, long_prefix + "b"]

    def test_very_long_list(self):
        strings = [f"test{i}" for i in range(1000)]
        result = filter_by_prefix(strings, "test")
        assert len(result) == 1000
        assert result == strings

    def test_newline_in_strings(self):
        result = filter_by_prefix(["test\nline", "test line", "other"], "test")
        assert result == ["test\nline", "test line"]

    def test_tab_in_strings(self):
        result = filter_by_prefix(["test\ttab", "test tab", "other"], "test")
        assert result == ["test\ttab", "test tab"]


@pytest.mark.parametrize("strings,prefix,expected", [
    (["apple", "apricot", "banana"], "app", ["apple"]),
    (["test", "testing", "tester"], "test", ["test", "testing", "tester"]),
    (["hello", "world"], "x", []),
    ([], "any", []),
    (["a", "b", "c"], "", ["a", "b", "c"]),
    (["abc"], "abc", ["abc"]),
    (["abc"], "abcd", []),
    (["ABC", "abc"], "ab", ["abc"]),
    (["123abc", "456abc"], "123", ["123abc"]),
    (["test-1", "test-2", "other"], "test-", ["test-1", "test-2"]),
])
def test_filter_by_prefix_parametrized(strings, prefix, expected):
    assert filter_by_prefix(strings, prefix) == expected