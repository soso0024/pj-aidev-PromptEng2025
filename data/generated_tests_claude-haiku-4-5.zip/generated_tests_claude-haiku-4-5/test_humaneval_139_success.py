# Test cases for HumanEval/139
# Generated using Claude API


def special_factorial(n):
    """The Brazilian factorial is defined as:
    brazilian_factorial(n) = n! * (n-1)! * (n-2)! * ... * 1!
    where n > 0

    For example:
    >>> special_factorial(4)
    288

    The function will receive an integer as input and should return the special
    factorial of this integer.
    """

    fact_i = 1
    special_fact = 1
    for i in range(1, n+1):
        fact_i *= i
        special_fact *= fact_i
    return special_fact


# Generated test cases:
import pytest


def special_factorial(n):
    fact_i = 1
    special_fact = 1
    for i in range(1, n+1):
        fact_i *= i
        special_fact *= fact_i
    return special_fact


class TestSpecialFactorial:
    
    def test_zero(self):
        assert special_factorial(0) == 1
    
    def test_one(self):
        assert special_factorial(1) == 1
    
    def test_two(self):
        assert special_factorial(2) == 2
    
    def test_three(self):
        assert special_factorial(3) == 12
    
    def test_four(self):
        assert special_factorial(4) == 288
    
    def test_five(self):
        assert special_factorial(5) == 34560
    
    @pytest.mark.parametrize("n,expected", [
        (0, 1),
        (1, 1),
        (2, 2),
        (3, 12),
        (4, 288),
        (5, 34560),
        (6, 24883200),
    ])
    def test_parametrized_values(self, n, expected):
        assert special_factorial(n) == expected
    
    def test_large_number(self):
        result = special_factorial(10)
        assert isinstance(result, int)
        assert result > 0
    
    def test_return_type_is_int(self):
        assert isinstance(special_factorial(3), int)
    
    def test_monotonic_increase(self):
        prev = special_factorial(0)
        for i in range(1, 8):
            current = special_factorial(i)
            assert current >= prev
            prev = current
    
    def test_factorial_property(self):
        n = 4
        result = special_factorial(n)
        expected = 1 * 1 * 2 * 6 * 24
        assert result == expected
    
    def test_small_values_sequence(self):
        values = [special_factorial(i) for i in range(6)]
        assert values == [1, 1, 2, 12, 288, 34560]
