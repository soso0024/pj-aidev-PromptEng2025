# Test cases for HumanEval/25
# Generated using Claude API

from typing import List


def factorize(n: int) -> List[int]:
    """ Return list of prime factors of given integer in the order from smallest to largest.
    Each of the factors should be listed number of times corresponding to how many times it appeares in factorization.
    Input number should be equal to the product of all factors
    >>> factorize(8)
    [2, 2, 2]
    >>> factorize(25)
    [5, 5]
    >>> factorize(70)
    [2, 5, 7]
    """

    import math
    fact = []
    i = 2
    while i <= int(math.sqrt(n) + 1):
        if n % i == 0:
            fact.append(i)
            n //= i
        else:
            i += 1

    if n > 1:
        fact.append(n)
    return fact


# Generated test cases:
import pytest
from typing import List


def factorize(n: int) -> List[int]:
    import math
    fact = []
    i = 2
    while i <= int(math.sqrt(n) + 1):
        if n % i == 0:
            fact.append(i)
            n //= i
        else:
            i += 1

    if n > 1:
        fact.append(n)
    return fact


class TestFactorize:
    
    def test_prime_number(self):
        assert factorize(2) == [2]
        assert factorize(3) == [3]
        assert factorize(5) == [5]
        assert factorize(7) == [7]
        assert factorize(11) == [11]
        assert factorize(13) == [13]
    
    def test_composite_numbers(self):
        assert factorize(4) == [2, 2]
        assert factorize(6) == [2, 3]
        assert factorize(8) == [2, 2, 2]
        assert factorize(9) == [3, 3]
        assert factorize(10) == [2, 5]
        assert factorize(12) == [2, 2, 3]
        assert factorize(15) == [3, 5]
        assert factorize(20) == [2, 2, 5]
    
    def test_large_composite_numbers(self):
        assert factorize(100) == [2, 2, 5, 5]
        assert factorize(144) == [2, 2, 2, 2, 3, 3]
        assert factorize(210) == [2, 3, 5, 7]
        assert factorize(1000) == [2, 2, 2, 5, 5, 5]
    
    def test_number_two(self):
        assert factorize(2) == [2]
    
    def test_perfect_squares(self):
        assert factorize(16) == [2, 2, 2, 2]
        assert factorize(25) == [5, 5]
        assert factorize(36) == [2, 2, 3, 3]
        assert factorize(49) == [7, 7]
        assert factorize(64) == [2, 2, 2, 2, 2, 2]
    
    def test_product_of_two_primes(self):
        assert factorize(14) == [2, 7]
        assert factorize(21) == [3, 7]
        assert factorize(22) == [2, 11]
        assert factorize(26) == [2, 13]
        assert factorize(33) == [3, 11]
    
    def test_powers_of_primes(self):
        assert factorize(32) == [2, 2, 2, 2, 2]
        assert factorize(27) == [3, 3, 3]
        assert factorize(125) == [5, 5, 5]
        assert factorize(128) == [2, 2, 2, 2, 2, 2, 2]
    
    def test_mixed_factors(self):
        assert factorize(30) == [2, 3, 5]
        assert factorize(60) == [2, 2, 3, 5]
        assert factorize(72) == [2, 2, 2, 3, 3]
        assert factorize(84) == [2, 2, 3, 7]
        assert factorize(90) == [2, 3, 3, 5]
    
    def test_large_prime(self):
        assert factorize(97) == [97]
        assert factorize(101) == [101]
        assert factorize(103) == [103]
    
    def test_large_numbers(self):
        assert factorize(1001) == [7, 11, 13]
        assert factorize(2310) == [2, 3, 5, 7, 11]
        assert factorize(9999) == [3, 3, 11, 101]
    
    def test_result_is_list(self):
        result = factorize(12)
        assert isinstance(result, list)
    
    def test_result_product_equals_input(self):
        test_cases = [2, 3, 4, 6, 8, 10, 12, 15, 20, 30, 100]
        for n in test_cases:
            factors = factorize(n)
            product = 1
            for factor in factors:
                product *= factor
            assert product == n
    
    def test_factors_are_sorted_ascending(self):
        test_cases = [12, 30, 60, 100, 210]
        for n in test_cases:
            factors = factorize(n)
            assert factors == sorted(factors)
    
    def test_all_factors_are_prime(self):
        def is_prime(num):
            if num < 2:
                return False
            for i in range(2, int(num ** 0.5) + 1):
                if num % i == 0:
                    return False
            return True
        
        test_cases = [4, 6, 8, 10, 12, 15, 20, 30, 100]
        for n in test_cases:
            factors = factorize(n)
            for factor in factors:
                assert is_prime(factor)
    
    @pytest.mark.parametrize("n,expected", [
        (2, [2]),
        (3, [3]),
        (4, [2, 2]),
        (5, [5]),
        (6, [2, 3]),
        (7, [7]),
        (8, [2, 2, 2]),
        (9, [3, 3]),
        (10, [2, 5]),
        (11, [11]),
        (12, [2, 2, 3]),
        (13, [13]),
        (14, [2, 7]),
        (15, [3, 5]),
        (16, [2, 2, 2, 2]),
        (17, [17]),
        (18, [2, 3, 3]),
        (19, [19]),
        (20, [2, 2, 5]),
    ])
    def test_parametrized_small_numbers(self, n, expected):
        assert factorize(n) == expected
