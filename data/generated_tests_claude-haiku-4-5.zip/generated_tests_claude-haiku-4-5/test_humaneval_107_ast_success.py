# Test cases for HumanEval/107
# Generated using Claude API


def even_odd_palindrome(n):
    """
    Given a positive integer n, return a tuple that has the number of even and odd
    integer palindromes that fall within the range(1, n), inclusive.

    Example 1:

        Input: 3
        Output: (1, 2)
        Explanation:
        Integer palindrome are 1, 2, 3. one of them is even, and two of them are odd.

    Example 2:

        Input: 12
        Output: (4, 6)
        Explanation:
        Integer palindrome are 1, 2, 3, 4, 5, 6, 7, 8, 9, 11. four of them are even, and 6 of them are odd.

    Note:
        1. 1 <= n <= 10^3
        2. returned tuple has the number of even and odd integer palindromes respectively.
    """

    def is_palindrome(n):
        return str(n) == str(n)[::-1]

    even_palindrome_count = 0
    odd_palindrome_count = 0

    for i in range(1, n+1):
        if i%2 == 1 and is_palindrome(i):
                odd_palindrome_count += 1
        elif i%2 == 0 and is_palindrome(i):
            even_palindrome_count += 1
    return (even_palindrome_count, odd_palindrome_count)


# Generated test cases:
import pytest


class TestEvenOddPalindrome:
    
    def even_odd_palindrome(self, n):
        def is_palindrome(n):
            return str(n) == str(n)[::-1]

        even_palindrome_count = 0
        odd_palindrome_count = 0

        for i in range(1, n+1):
            if i%2 == 1 and is_palindrome(i):
                    odd_palindrome_count += 1
            elif i%2 == 0 and is_palindrome(i):
                even_palindrome_count += 1
        return (even_palindrome_count, odd_palindrome_count)
    
    def test_single_digit_one(self):
        assert self.even_odd_palindrome(1) == (0, 1)
    
    def test_single_digit_two(self):
        assert self.even_odd_palindrome(2) == (1, 1)
    
    def test_single_digit_nine(self):
        assert self.even_odd_palindrome(9) == (4, 5)
    
    def test_two_digits(self):
        assert self.even_odd_palindrome(10) == (4, 5)
    
    def test_two_digits_eleven(self):
        assert self.even_odd_palindrome(11) == (4, 6)
    
    def test_two_digits_twenty_two(self):
        assert self.even_odd_palindrome(22) == (5, 6)
    
    def test_three_digits(self):
        assert self.even_odd_palindrome(100) == (8, 10)
    
    def test_three_digits_one_hundred_one(self):
        assert self.even_odd_palindrome(101) == (8, 11)
    
    def test_larger_number(self):
        result = self.even_odd_palindrome(1000)
        assert isinstance(result, tuple)
        assert len(result) == 2
        assert result[0] >= 0
        assert result[1] >= 0
    
    def test_return_type_is_tuple(self):
        result = self.even_odd_palindrome(5)
        assert isinstance(result, tuple)
        assert len(result) == 2
    
    def test_return_values_are_integers(self):
        even_count, odd_count = self.even_odd_palindrome(10)
        assert isinstance(even_count, int)
        assert isinstance(odd_count, int)
    
    def test_counts_are_non_negative(self):
        even_count, odd_count = self.even_odd_palindrome(50)
        assert even_count >= 0
        assert odd_count >= 0
    
    def test_all_single_digits_are_palindromes(self):
        even_count, odd_count = self.even_odd_palindrome(9)
        assert even_count + odd_count == 9
    
    def test_specific_palindromes_in_range(self):
        even_count, odd_count = self.even_odd_palindrome(12)
        assert even_count == 4
        assert odd_count == 6
    
    def test_range_includes_n(self):
        result_11 = self.even_odd_palindrome(11)
        result_10 = self.even_odd_palindrome(10)
        assert result_11[1] > result_10[1]
    
    def test_no_even_palindromes_below_two(self):
        even_count, odd_count = self.even_odd_palindrome(1)
        assert even_count == 0
    
    def test_first_even_palindrome_is_two(self):
        even_count, odd_count = self.even_odd_palindrome(2)
        assert even_count == 1
    
    def test_palindrome_eleven(self):
        even_count, odd_count = self.even_odd_palindrome(11)
        assert odd_count >= 6
    
    def test_palindrome_twenty_two(self):
        even_count, odd_count = self.even_odd_palindrome(22)
        assert even_count >= 5
    
    def test_large_range(self):
        result = self.even_odd_palindrome(10000)
        assert isinstance(result, tuple)
        assert result[0] > 0
        assert result[1] > 0
    
    def test_monotonic_increase_even(self):
        result1 = self.even_odd_palindrome(50)
        result2 = self.even_odd_palindrome(100)
        assert result2[0] >= result1[0]
    
    def test_monotonic_increase_odd(self):
        result1 = self.even_odd_palindrome(50)
        result2 = self.even_odd_palindrome(100)
        assert result2[1] >= result1[1]
    
    def test_specific_case_n_equals_3(self):
        even_count, odd_count = self.even_odd_palindrome(3)
        assert even_count == 1
        assert odd_count == 2
    
    def test_specific_case_n_equals_5(self):
        even_count, odd_count = self.even_odd_palindrome(5)
        assert even_count == 2
        assert odd_count == 3
    
    def test_specific_case_n_equals_7(self):
        even_count, odd_count = self.even_odd_palindrome(7)
        assert even_count == 3
        assert odd_count == 4
    
    def test_specific_case_n_equals_99(self):
        result = self.even_odd_palindrome(99)
        assert result[0] == 8
        assert result[1] == 10
    
    def test_specific_case_n_equals_121(self):
        result = self.even_odd_palindrome(121)
        assert result[0] == 8
        assert result[1] == 13
    
    @pytest.mark.parametrize("n,expected_even,expected_odd", [
        (1, 0, 1),
        (2, 1, 1),
        (3, 1, 2),
        (4, 2, 2),
        (5, 2, 3),
        (9, 4, 5),
        (10, 4, 5),
        (11, 4, 6),
    ])
    def test_parametrized_small_values(self, n, expected_even, expected_odd):
        even_count, odd_count = self.even_odd_palindrome(n)
        assert even_count == expected_even
        assert odd_count == expected_odd