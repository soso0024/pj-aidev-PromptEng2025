# Test cases for HumanEval/108
# Generated using Claude API


def count_nums(arr):
    """
    Write a function count_nums which takes an array of integers and returns
    the number of elements which has a sum of digits > 0.
    If a number is negative, then its first signed digit will be negative:
    e.g. -123 has signed digits -1, 2, and 3.
    >>> count_nums([]) == 0
    >>> count_nums([-1, 11, -11]) == 1
    >>> count_nums([1, 1, 2]) == 3
    """

    def digits_sum(n):
        neg = 1
        if n < 0: n, neg = -1 * n, -1 
        n = [int(i) for i in str(n)]
        n[0] = n[0] * neg
        return sum(n)
    return len(list(filter(lambda x: x > 0, [digits_sum(i) for i in arr])))


# Generated test cases:
import pytest


def count_nums(arr):
    def digits_sum(n):
        neg = 1
        if n < 0: n, neg = -1 * n, -1 
        n = [int(i) for i in str(n)]
        n[0] = n[0] * neg
        return sum(n)
    return len(list(filter(lambda x: x > 0, [digits_sum(i) for i in arr])))


class TestCountNums:
    
    def test_empty_array(self):
        assert count_nums([]) == 0
    
    def test_single_positive_number(self):
        assert count_nums([1]) == 1
    
    def test_single_negative_number(self):
        assert count_nums([-1]) == 0
    
    def test_single_zero(self):
        assert count_nums([0]) == 0
    
    def test_all_positive_single_digits(self):
        assert count_nums([1, 2, 3, 4, 5]) == 5
    
    def test_all_negative_single_digits(self):
        assert count_nums([-1, -2, -3, -4, -5]) == 0
    
    def test_mixed_positive_and_negative(self):
        assert count_nums([1, -1, 2, -2]) == 2
    
    def test_positive_multi_digit_numbers(self):
        assert count_nums([10, 20, 30]) == 3
    
    def test_negative_multi_digit_numbers(self):
        assert count_nums([-10, -20, -30]) == 0
    
    def test_number_with_positive_digit_sum(self):
        assert count_nums([12]) == 1
    
    def test_number_with_negative_digit_sum(self):
        assert count_nums([-12]) == 1
    
    def test_large_positive_number(self):
        assert count_nums([123]) == 1
    
    def test_large_negative_number(self):
        assert count_nums([-123]) == 1
    
    def test_negative_number_with_small_first_digit(self):
        assert count_nums([-1]) == 0
    
    def test_negative_number_with_large_other_digits(self):
        assert count_nums([-199]) == 1
    
    def test_mixed_array_with_zeros(self):
        assert count_nums([0, 1, -1, 0, 2]) == 2
    
    def test_positive_number_digit_sum_zero(self):
        assert count_nums([10]) == 1
    
    def test_negative_number_digit_sum_zero(self):
        assert count_nums([-10]) == 0
    
    def test_array_with_all_zeros(self):
        assert count_nums([0, 0, 0]) == 0
    
    def test_positive_two_digit_numbers(self):
        assert count_nums([11, 22, 33]) == 3
    
    def test_negative_two_digit_numbers(self):
        assert count_nums([-11, -22, -33]) == 0
    
    def test_mixed_positive_negative_multi_digit(self):
        assert count_nums([12, -12, 34, -34]) == 4
    
    def test_number_with_digit_sum_exactly_zero(self):
        result = count_nums([100])
        assert result == 1
    
    def test_negative_number_with_digit_sum_exactly_zero(self):
        result = count_nums([-100])
        assert result == 0
    
    def test_large_array_mixed(self):
        assert count_nums([1, 2, 3, -1, -2, -3, 0, 10, -10]) == 4
    
    def test_single_digit_positive_one(self):
        assert count_nums([1]) == 1
    
    def test_single_digit_negative_one(self):
        assert count_nums([-1]) == 0
    
    def test_number_nine(self):
        assert count_nums([9]) == 1
    
    def test_number_negative_nine(self):
        assert count_nums([-9]) == 0
    
    def test_complex_negative_number(self):
        assert count_nums([-999]) == 1
    
    def test_complex_positive_number(self):
        assert count_nums([999]) == 1
    
    def test_array_with_repeated_values(self):
        assert count_nums([5, 5, 5, 5]) == 4
    
    def test_array_with_repeated_negative_values(self):
        assert count_nums([-5, -5, -5, -5]) == 0
    
    def test_positive_number_with_zero_digit_sum(self):
        result = count_nums([101])
        assert result == 1
    
    def test_negative_number_with_zero_digit_sum(self):
        result = count_nums([-101])
        assert result == 0
    
    def test_very_large_positive_number(self):
        assert count_nums([123456789]) == 1
    
    def test_very_large_negative_number(self):
        assert count_nums([-123456789]) == 1
    
    def test_mixed_with_boundary_values(self):
        assert count_nums([-1, 0, 1]) == 1
    
    def test_positive_numbers_only(self):
        assert count_nums([1, 2, 3, 4, 5, 6, 7, 8, 9]) == 9
    
    def test_negative_numbers_only(self):
        assert count_nums([-1, -2, -3, -4, -5, -6, -7, -8, -9]) == 0