# Test cases for HumanEval/126
# Generated using Claude API


def is_sorted(lst):
    '''
    Given a list of numbers, return whether or not they are sorted
    in ascending order. If list has more than 1 duplicate of the same
    number, return False. Assume no negative numbers and only integers.

    Examples
    is_sorted([5]) ➞ True
    is_sorted([1, 2, 3, 4, 5]) ➞ True
    is_sorted([1, 3, 2, 4, 5]) ➞ False
    is_sorted([1, 2, 3, 4, 5, 6]) ➞ True
    is_sorted([1, 2, 3, 4, 5, 6, 7]) ➞ True
    is_sorted([1, 3, 2, 4, 5, 6, 7]) ➞ False
    is_sorted([1, 2, 2, 3, 3, 4]) ➞ True
    is_sorted([1, 2, 2, 2, 3, 4]) ➞ False
    '''

    count_digit = dict([(i, 0) for i in lst])
    for i in lst:
        count_digit[i]+=1 
    if any(count_digit[i] > 2 for i in lst):
        return False
    if all(lst[i-1] <= lst[i] for i in range(1, len(lst))):
        return True
    else:
        return False
    
    


# Generated test cases:
import pytest


def is_sorted(lst):
    count_digit = dict([(i, 0) for i in lst])
    for i in lst:
        count_digit[i]+=1 
    if any(count_digit[i] > 2 for i in lst):
        return False
    if all(lst[i-1] <= lst[i] for i in range(1, len(lst))):
        return True
    else:
        return False


class TestIsSorted:
    
    def test_empty_list(self):
        assert is_sorted([]) == True
    
    def test_single_element(self):
        assert is_sorted([1]) == True
    
    def test_sorted_ascending(self):
        assert is_sorted([1, 2, 3, 4, 5]) == True
    
    def test_sorted_with_duplicates_allowed(self):
        assert is_sorted([1, 1, 2, 2, 3]) == True
    
    def test_sorted_all_same(self):
        assert is_sorted([5, 5]) == True
    
    def test_unsorted_list(self):
        assert is_sorted([3, 1, 2]) == False
    
    def test_unsorted_descending(self):
        assert is_sorted([5, 4, 3, 2, 1]) == False
    
    def test_more_than_two_duplicates(self):
        assert is_sorted([1, 1, 1, 2, 3]) == False
    
    def test_three_of_same_element(self):
        assert is_sorted([1, 2, 2, 2, 3]) == False
    
    def test_duplicates_at_end(self):
        assert is_sorted([1, 2, 3, 3, 3]) == False
    
    def test_duplicates_at_start(self):
        assert is_sorted([1, 1, 1, 2, 3]) == False
    
    def test_two_elements_sorted(self):
        assert is_sorted([1, 2]) == True
    
    def test_two_elements_unsorted(self):
        assert is_sorted([2, 1]) == False
    
    def test_two_identical_elements(self):
        assert is_sorted([5, 5]) == True
    
    def test_negative_numbers_sorted(self):
        assert is_sorted([-3, -2, -1, 0, 1]) == True
    
    def test_negative_numbers_unsorted(self):
        assert is_sorted([-1, -3, -2]) == False
    
    def test_mixed_positive_negative_sorted(self):
        assert is_sorted([-2, -1, 0, 1, 2]) == True
    
    def test_mixed_positive_negative_unsorted(self):
        assert is_sorted([1, -1, 0]) == False
    
    def test_floats_sorted(self):
        assert is_sorted([1.1, 2.2, 3.3]) == True
    
    def test_floats_unsorted(self):
        assert is_sorted([3.3, 1.1, 2.2]) == False
    
    def test_strings_sorted(self):
        assert is_sorted(['a', 'b', 'c']) == True
    
    def test_strings_unsorted(self):
        assert is_sorted(['c', 'a', 'b']) == False
    
    def test_strings_with_duplicates(self):
        assert is_sorted(['a', 'a', 'b', 'b']) == True
    
    def test_strings_with_three_duplicates(self):
        assert is_sorted(['a', 'a', 'a', 'b']) == False
    
    @pytest.mark.parametrize("lst,expected", [
        ([1, 2, 3], True),
        ([3, 2, 1], False),
        ([1, 1, 2], True),
        ([1, 1, 1], False),
        ([], True),
        ([42], True),
        ([1, 2, 2, 3], True),
        ([1, 2, 2, 2, 3], False),
    ])
    def test_parametrized_cases(self, lst, expected):
        assert is_sorted(lst) == expected
