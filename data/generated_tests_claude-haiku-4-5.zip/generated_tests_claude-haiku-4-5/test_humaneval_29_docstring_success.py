# Test cases for HumanEval/29
# Generated using Claude API

from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    """ Filter an input list of strings only for ones that start with a given prefix.
    >>> filter_by_prefix([], 'a')
    []
    >>> filter_by_prefix(['abc', 'bcd', 'cde', 'array'], 'a')
    ['abc', 'array']
    """

    return [x for x in strings if x.startswith(prefix)]


# Generated test cases:
import pytest
from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    return [x for x in strings if x.startswith(prefix)]


class TestFilterByPrefix:
    
    def test_empty_list(self):
        assert filter_by_prefix([], 'a') == []
    
    def test_empty_prefix(self):
        assert filter_by_prefix(['abc', 'bcd', 'cde'], '') == ['abc', 'bcd', 'cde']
    
    def test_single_match(self):
        assert filter_by_prefix(['abc', 'bcd', 'cde'], 'a') == ['abc']
    
    def test_multiple_matches(self):
        assert filter_by_prefix(['abc', 'bcd', 'cde', 'array'], 'a') == ['abc', 'array']
    
    def test_no_matches(self):
        assert filter_by_prefix(['abc', 'bcd', 'cde'], 'z') == []
    
    def test_all_match(self):
        assert filter_by_prefix(['abc', 'abd', 'abe'], 'a') == ['abc', 'abd', 'abe']
    
    def test_case_sensitive(self):
        assert filter_by_prefix(['abc', 'Abc', 'ABC'], 'a') == ['abc']
    
    def test_prefix_longer_than_strings(self):
        assert filter_by_prefix(['a', 'ab'], 'abc') == []
    
    def test_prefix_equals_string(self):
        assert filter_by_prefix(['abc', 'ab', 'a'], 'abc') == ['abc']
    
    def test_single_character_prefix(self):
        assert filter_by_prefix(['apple', 'apricot', 'banana'], 'a') == ['apple', 'apricot']
    
    def test_multi_character_prefix(self):
        assert filter_by_prefix(['apple', 'application', 'apply', 'banana'], 'app') == ['apple', 'application', 'apply']
    
    def test_special_characters_in_strings(self):
        assert filter_by_prefix(['@abc', '@def', '#abc'], '@') == ['@abc', '@def']
    
    def test_special_characters_in_prefix(self):
        assert filter_by_prefix(['@abc', '@def', '#abc'], '@') == ['@abc', '@def']
    
    def test_whitespace_in_strings(self):
        assert filter_by_prefix(['a bc', 'a de', 'b cd'], 'a ') == ['a bc', 'a de']
    
    def test_whitespace_prefix(self):
        assert filter_by_prefix(['a bc', ' abc', 'abc'], ' ') == [' abc']
    
    def test_numeric_strings(self):
        assert filter_by_prefix(['123', '124', '234'], '12') == ['123', '124']
    
    def test_mixed_alphanumeric(self):
        assert filter_by_prefix(['a1b', 'a2c', 'b1d'], 'a') == ['a1b', 'a2c']
    
    def test_unicode_characters(self):
        assert filter_by_prefix(['café', 'car', 'cat'], 'ca') == ['café', 'car', 'cat']
    
    def test_unicode_prefix(self):
        assert filter_by_prefix(['café', 'car', 'cat'], 'café') == ['café']
    
    def test_empty_strings_in_list(self):
        assert filter_by_prefix(['', 'abc', 'def'], '') == ['', 'abc', 'def']
    
    def test_empty_strings_with_non_empty_prefix(self):
        assert filter_by_prefix(['', 'abc', 'def'], 'a') == ['abc']
    
    def test_duplicate_strings(self):
        assert filter_by_prefix(['abc', 'abc', 'def'], 'a') == ['abc', 'abc']
    
    def test_very_long_strings(self):
        long_string = 'a' * 1000
        assert filter_by_prefix([long_string, 'b' * 1000], 'a') == [long_string]
    
    def test_very_long_prefix(self):
        long_prefix = 'a' * 100
        long_string = long_prefix + 'b' * 100
        assert filter_by_prefix([long_string, 'b' * 200], long_prefix) == [long_string]


@pytest.mark.parametrize("strings,prefix,expected", [
    ([], 'a', []),
    (['abc', 'bcd', 'cde', 'array'], 'a', ['abc', 'array']),
    (['abc', 'bcd', 'cde'], 'z', []),
    (['abc', 'abd', 'abe'], 'a', ['abc', 'abd', 'abe']),
    (['abc', 'Abc', 'ABC'], 'a', ['abc']),
    (['a', 'ab', 'abc'], 'abc', ['abc']),
    (['apple', 'apricot', 'banana'], 'a', ['apple', 'apricot']),
    (['apple', 'application', 'apply', 'banana'], 'app', ['apple', 'application', 'apply']),
    (['@abc', '@def', '#abc'], '@', ['@abc', '@def']),
    (['a bc', 'a de', 'b cd'], 'a ', ['a bc', 'a de']),
    (['123', '124', '234'], '12', ['123', '124']),
    (['a1b', 'a2c', 'b1d'], 'a', ['a1b', 'a2c']),
    (['café', 'car', 'cat'], 'ca', ['café', 'car', 'cat']),
    (['', 'abc', 'def'], '', ['', 'abc', 'def']),
    (['', 'abc', 'def'], 'a', ['abc']),
    (['abc', 'abc', 'def'], 'a', ['abc', 'abc']),
])
def test_filter_by_prefix_parametrized(strings, prefix, expected):
    assert filter_by_prefix(strings, prefix) == expected
