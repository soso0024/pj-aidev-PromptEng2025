# Test cases for HumanEval/86
# Generated using Claude API


def anti_shuffle(s):
    """
    Write a function that takes a string and returns an ordered version of it.
    Ordered version of string, is a string where all words (separated by space)
    are replaced by a new word where all the characters arranged in
    ascending order based on ascii value.
    Note: You should keep the order of words and blank spaces in the sentence.

    For example:
    anti_shuffle('Hi') returns 'Hi'
    anti_shuffle('hello') returns 'ehllo'
    anti_shuffle('Hello World!!!') returns 'Hello !!!Wdlor'
    """

    return ' '.join([''.join(sorted(list(i))) for i in s.split(' ')])


# Generated test cases:
import pytest


def anti_shuffle(s):
    return ' '.join([''.join(sorted(list(i))) for i in s.split(' ')])


class TestAntiShuffle:
    
    def test_empty_string(self):
        assert anti_shuffle('') == ''
    
    def test_single_word(self):
        assert anti_shuffle('hello') == 'ehllo'
    
    def test_single_character(self):
        assert anti_shuffle('a') == 'a'
    
    def test_two_words(self):
        assert anti_shuffle('hello world') == 'ehllo dlorw'
    
    def test_multiple_words(self):
        assert anti_shuffle('the quick brown fox') == 'eht cikqu bnorw fox'
    
    def test_already_sorted_word(self):
        assert anti_shuffle('abc') == 'abc'
    
    def test_reverse_sorted_word(self):
        assert anti_shuffle('cba') == 'abc'
    
    def test_word_with_repeated_characters(self):
        assert anti_shuffle('aabbcc') == 'aabbcc'
    
    def test_word_with_numbers(self):
        assert anti_shuffle('a1b2c3') == '123abc'
    
    def test_word_with_special_characters(self):
        assert anti_shuffle('c!a@b#') == '!#@abc'
    
    def test_multiple_spaces_between_words(self):
        result = anti_shuffle('hello  world')
        assert result == 'ehllo  dlorw'
    
    def test_leading_space(self):
        result = anti_shuffle(' hello')
        assert result == ' ehllo'
    
    def test_trailing_space(self):
        result = anti_shuffle('hello ')
        assert result == 'ehllo '
    
    def test_only_spaces(self):
        assert anti_shuffle('   ') == '   '
    
    def test_single_space(self):
        assert anti_shuffle(' ') == ' '
    
    def test_mixed_case_letters(self):
        assert anti_shuffle('HeLLo') == 'HLLeo'
    
    def test_uppercase_letters(self):
        assert anti_shuffle('HELLO') == 'EHLLO'
    
    def test_lowercase_letters(self):
        assert anti_shuffle('hello') == 'ehllo'
    
    def test_word_with_punctuation(self):
        assert anti_shuffle('hello,world') == ',dehllloorw'
    
    def test_single_letter_words(self):
        assert anti_shuffle('a b c d') == 'a b c d'
    
    def test_two_letter_words(self):
        assert anti_shuffle('ba dc') == 'ab cd'
    
    def test_unicode_characters(self):
        result = anti_shuffle('café')
        assert result == 'acfé'
    
    def test_numbers_only(self):
        assert anti_shuffle('321 654') == '123 456'
    
    def test_mixed_alphanumeric(self):
        assert anti_shuffle('a1b2 c3d4') == '12ab 34cd'
    
    def test_long_word(self):
        assert anti_shuffle('zyxwvutsrqponmlkjihgfedcba') == 'abcdefghijklmnopqrstuvwxyz'
    
    def test_repeated_words(self):
        assert anti_shuffle('hello hello') == 'ehllo ehllo'
    
    def test_palindrome_word(self):
        assert anti_shuffle('racecar') == 'aaccerr'
    
    def test_word_with_spaces_in_middle(self):
        assert anti_shuffle('a b c') == 'a b c'


@pytest.mark.parametrize("input_str,expected", [
    ('', ''),
    ('a', 'a'),
    ('ab', 'ab'),
    ('ba', 'ab'),
    ('hello', 'ehllo'),
    ('world', 'dlorw'),
    ('hello world', 'ehllo dlorw'),
    ('the quick brown fox', 'eht cikqu bnorw fox'),
    ('abc def ghi', 'abc def ghi'),
    ('cba fed ihg', 'abc def ghi'),
])
def test_anti_shuffle_parametrized(input_str, expected):
    assert anti_shuffle(input_str) == expected