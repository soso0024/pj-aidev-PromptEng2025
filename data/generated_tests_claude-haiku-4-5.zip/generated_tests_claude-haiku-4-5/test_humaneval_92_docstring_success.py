# Test cases for HumanEval/92
# Generated using Claude API


def any_int(x, y, z):
    '''
    Create a function that takes 3 numbers.
    Returns true if one of the numbers is equal to the sum of the other two, and all numbers are integers.
    Returns false in any other cases.
    
    Examples
    any_int(5, 2, 7) ➞ True
    
    any_int(3, 2, 2) ➞ False

    any_int(3, -2, 1) ➞ True
    
    any_int(3.6, -2.2, 2) ➞ False
  

    
    '''

    
    if isinstance(x,int) and isinstance(y,int) and isinstance(z,int):
        if (x+y==z) or (x+z==y) or (y+z==x):
            return True
        return False
    return False


# Generated test cases:
import pytest


def any_int(x, y, z):
    
    if isinstance(x,int) and isinstance(y,int) and isinstance(z,int):
        if (x+y==z) or (x+z==y) or (y+z==x):
            return True
        return False
    return False


class TestAnyInt:
    
    @pytest.mark.parametrize("x,y,z,expected", [
        (5, 2, 7, True),
        (3, 2, 2, False),
        (3, -2, 1, True),
        (3.6, -2.2, 2, False),
        (0, 0, 0, True),
        (1, 1, 2, True),
        (-1, -1, -2, True),
        (10, 5, 15, True),
        (10, 5, 14, False),
        (0, 5, 5, True),
        (5, 0, 5, True),
        (5, 5, 0, True),
        (-5, 3, -2, True),
        (-5, -3, -8, True),
        (100, 200, 300, True),
        (100, 200, 301, False),
        (1, 2, 3, True),
        (1, 2, 4, False),
    ])
    def test_any_int_valid_cases(self, x, y, z, expected):
        assert any_int(x, y, z) == expected
    
    @pytest.mark.parametrize("x,y,z,expected", [
        (1.5, 2, 3, False),
        (1, 2.5, 3, False),
        (1, 2, 3.5, False),
        (1.0, 2.0, 3.0, False),
        (5.5, 2.5, 8.0, False),
        (3.6, -2.2, 2, False),
    ])
    def test_any_int_float_cases(self, x, y, z, expected):
        assert any_int(x, y, z) == expected
    
    @pytest.mark.parametrize("x,y,z,expected", [
        ("1", 2, 3, False),
        (1, "2", 3, False),
        (1, 2, "3", False),
        (None, 2, 3, False),
        (1, None, 3, False),
        (1, 2, None, False),
    ])
    def test_any_int_invalid_types(self, x, y, z, expected):
        assert any_int(x, y, z) == expected
    
    def test_any_int_basic_true(self):
        assert any_int(5, 2, 7) == True
    
    def test_any_int_basic_false(self):
        assert any_int(3, 2, 2) == False
    
    def test_any_int_negative_true(self):
        assert any_int(3, -2, 1) == True
    
    def test_any_int_float_false(self):
        assert any_int(3.6, -2.2, 2) == False
    
    def test_any_int_all_zeros(self):
        assert any_int(0, 0, 0) == True
    
    def test_any_int_one_zero(self):
        assert any_int(0, 5, 5) == True
    
    def test_any_int_large_numbers(self):
        assert any_int(1000000, 2000000, 3000000) == True
    
    def test_any_int_large_numbers_false(self):
        assert any_int(1000000, 2000000, 3000001) == False
    
    def test_any_int_negative_sum(self):
        assert any_int(-10, -5, -15) == True
    
    def test_any_int_mixed_signs(self):
        assert any_int(-10, 5, -5) == True
    
    def test_any_int_bool_true(self):
        assert any_int(True, 1, 2) == True
    
    def test_any_int_bool_false(self):
        assert any_int(False, 0, 0) == True
