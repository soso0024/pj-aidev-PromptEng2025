# Test cases for HumanEval/63
# Generated using Claude API



def fibfib(n: int):
    """The FibFib number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fibfib(0) == 0
    fibfib(1) == 0
    fibfib(2) == 1
    fibfib(n) == fibfib(n-1) + fibfib(n-2) + fibfib(n-3).
    Please write a function to efficiently compute the n-th element of the fibfib number sequence.
    >>> fibfib(1)
    0
    >>> fibfib(5)
    4
    >>> fibfib(8)
    24
    """

    if n == 0:
        return 0
    if n == 1:
        return 0
    if n == 2:
        return 1
    return fibfib(n - 1) + fibfib(n - 2) + fibfib(n - 3)


# Generated test cases:
import pytest


def fibfib(n: int):
    if n == 0:
        return 0
    if n == 1:
        return 0
    if n == 2:
        return 1
    return fibfib(n - 1) + fibfib(n - 2) + fibfib(n - 3)


class TestFibfib:
    
    @pytest.mark.parametrize("n,expected", [
        (0, 0),
        (1, 0),
        (2, 1),
        (3, 1),
        (4, 2),
        (5, 4),
        (6, 7),
        (7, 13),
        (8, 24),
        (9, 44),
        (10, 81),
    ])
    def test_fibfib_known_values(self, n, expected):
        assert fibfib(n) == expected
    
    def test_fibfib_base_case_zero(self):
        assert fibfib(0) == 0
    
    def test_fibfib_base_case_one(self):
        assert fibfib(1) == 0
    
    def test_fibfib_base_case_two(self):
        assert fibfib(2) == 1
    
    def test_fibfib_docstring_example_one(self):
        assert fibfib(1) == 0
    
    def test_fibfib_docstring_example_five(self):
        assert fibfib(5) == 4
    
    def test_fibfib_docstring_example_eight(self):
        assert fibfib(8) == 24
    
    def test_fibfib_small_values(self):
        assert fibfib(3) == 1
        assert fibfib(4) == 2
    
    def test_fibfib_medium_values(self):
        assert fibfib(11) == 149
        assert fibfib(12) == 274
    
    def test_fibfib_returns_integer(self):
        result = fibfib(5)
        assert isinstance(result, int)
    
    def test_fibfib_positive_growth(self):
        values = [fibfib(i) for i in range(10)]
        for i in range(3, len(values)):
            assert values[i] >= values[i-1]
    
    def test_fibfib_recurrence_relation(self):
        for n in range(3, 10):
            assert fibfib(n) == fibfib(n-1) + fibfib(n-2) + fibfib(n-3)
    
    def test_fibfib_larger_value(self):
        assert fibfib(15) == 1705