# Test cases for HumanEval/96
# Generated using Claude API


def count_up_to(n):
    """Implement a function that takes an non-negative integer and returns an array of the first n
    integers that are prime numbers and less than n.
    for example:
    count_up_to(5) => [2,3]
    count_up_to(11) => [2,3,5,7]
    count_up_to(0) => []
    count_up_to(20) => [2,3,5,7,11,13,17,19]
    count_up_to(1) => []
    count_up_to(18) => [2,3,5,7,11,13,17]
    """

    primes = []
    for i in range(2, n):
        is_prime = True
        for j in range(2, i):
            if i % j == 0:
                is_prime = False
                break
        if is_prime:
            primes.append(i)
    return primes



# Generated test cases:
import pytest


def count_up_to(n):
    primes = []
    for i in range(2, n):
        is_prime = True
        for j in range(2, i):
            if i % j == 0:
                is_prime = False
                break
        if is_prime:
            primes.append(i)
    return primes


class TestCountUpTo:
    
    def test_empty_list_for_zero(self):
        assert count_up_to(0) == []
    
    def test_empty_list_for_one(self):
        assert count_up_to(1) == []
    
    def test_empty_list_for_two(self):
        assert count_up_to(2) == []
    
    def test_single_prime_three(self):
        assert count_up_to(3) == [2]
    
    def test_primes_up_to_ten(self):
        assert count_up_to(10) == [2, 3, 5, 7]
    
    def test_primes_up_to_twenty(self):
        assert count_up_to(20) == [2, 3, 5, 7, 11, 13, 17, 19]
    
    def test_primes_up_to_thirty(self):
        assert count_up_to(30) == [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
    
    def test_primes_up_to_fifty(self):
        assert count_up_to(50) == [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]
    
    def test_negative_number(self):
        assert count_up_to(-5) == []
    
    def test_negative_one(self):
        assert count_up_to(-1) == []
    
    def test_large_number(self):
        result = count_up_to(100)
        expected = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]
        assert result == expected
    
    def test_return_type_is_list(self):
        assert isinstance(count_up_to(10), list)
    
    def test_all_elements_are_integers(self):
        result = count_up_to(20)
        assert all(isinstance(x, int) for x in result)
    
    def test_all_elements_are_prime(self):
        result = count_up_to(50)
        for num in result:
            is_prime = True
            for i in range(2, num):
                if num % i == 0:
                    is_prime = False
                    break
            assert is_prime
    
    def test_no_duplicates(self):
        result = count_up_to(50)
        assert len(result) == len(set(result))
    
    def test_sorted_order(self):
        result = count_up_to(50)
        assert result == sorted(result)
    
    def test_boundary_at_prime(self):
        assert count_up_to(11) == [2, 3, 5, 7]
    
    def test_boundary_at_composite(self):
        assert count_up_to(12) == [2, 3, 5, 7, 11]
    
    @pytest.mark.parametrize("n,expected_count", [
        (2, 0),
        (3, 1),
        (5, 2),
        (10, 4),
        (20, 8),
        (100, 25),
    ])
    def test_count_of_primes(self, n, expected_count):
        assert len(count_up_to(n)) == expected_count
    
    def test_very_small_positive_number(self):
        assert count_up_to(4) == [2, 3]
    
    def test_consecutive_primes(self):
        result = count_up_to(15)
        assert result == [2, 3, 5, 7, 11, 13]
