# Test cases for HumanEval/116
# Generated using Claude API


def sort_array(arr):
    """
    In this Kata, you have to sort an array of non-negative integers according to
    number of ones in their binary representation in ascending order.
    For similar number of ones, sort based on decimal value.

    It must be implemented like this:
    >>> sort_array([1, 5, 2, 3, 4]) == [1, 2, 3, 4, 5]
    >>> sort_array([-2, -3, -4, -5, -6]) == [-6, -5, -4, -3, -2]
    >>> sort_array([1, 0, 2, 3, 4]) [0, 1, 2, 3, 4]
    """

    return sorted(sorted(arr), key=lambda x: bin(x)[2:].count('1'))


# Generated test cases:
import pytest


def sort_array(arr):
    return sorted(sorted(arr), key=lambda x: bin(x)[2:].count('1'))


class TestSortArray:
    
    def test_empty_array(self):
        assert sort_array([]) == []
    
    def test_single_element(self):
        assert sort_array([5]) == [5]
    
    def test_single_zero(self):
        assert sort_array([0]) == [0]
    
    def test_all_zeros(self):
        assert sort_array([0, 0, 0]) == [0, 0, 0]
    
    def test_numbers_with_same_bit_count(self):
        result = sort_array([3, 5, 6])
        assert result == [3, 5, 6]
    
    def test_numbers_with_different_bit_counts(self):
        result = sort_array([7, 1, 2, 4])
        assert result == [1, 2, 4, 7]
    
    def test_mixed_numbers(self):
        result = sort_array([5, 2, 3, 1, 4])
        assert result == [1, 2, 4, 3, 5]
    
    def test_large_numbers(self):
        result = sort_array([255, 128, 64, 32])
        assert result == [32, 64, 128, 255]
    
    def test_negative_numbers(self):
        result = sort_array([-1, -2, -3, 1, 2, 3])
        assert len(result) == 6
    
    def test_duplicates(self):
        result = sort_array([3, 3, 3, 1, 1])
        assert result == [1, 1, 3, 3, 3]
    
    def test_unsorted_input(self):
        result = sort_array([10, 5, 15, 3, 7])
        assert len(result) == 5
    
    def test_already_sorted(self):
        result = sort_array([1, 2, 3, 4, 5])
        assert len(result) == 5
    
    def test_reverse_sorted(self):
        result = sort_array([5, 4, 3, 2, 1])
        assert len(result) == 5
    
    def test_bit_count_zero(self):
        assert sort_array([0, 0]) == [0, 0]
    
    def test_bit_count_one(self):
        result = sort_array([1, 2, 4, 8])
        assert result == [1, 2, 4, 8]
    
    def test_bit_count_all_ones(self):
        result = sort_array([7, 15, 31])
        assert result == [7, 15, 31]
    
    def test_mixed_bit_counts(self):
        result = sort_array([0, 1, 2, 3, 4, 5, 6, 7])
        assert result == [0, 1, 2, 4, 3, 5, 6, 7]
    
    def test_two_elements_different_bits(self):
        result = sort_array([7, 1])
        assert result == [1, 7]
    
    def test_two_elements_same_bits(self):
        result = sort_array([3, 5])
        assert result == [3, 5]
    
    def test_large_array(self):
        arr = list(range(100))
        result = sort_array(arr)
        assert len(result) == 100
    
    def test_stability_with_same_bit_count(self):
        result = sort_array([6, 3, 5])
        assert result == [3, 5, 6]
    
    @pytest.mark.parametrize("input_arr,expected", [
        ([0], [0]),
        ([1], [1]),
        ([1, 2], [1, 2]),
        ([2, 1], [1, 2]),
        ([3, 1, 2], [1, 2, 3]),
        ([7, 4, 2, 1], [1, 2, 4, 7]),
    ])
    def test_parametrized_cases(self, input_arr, expected):
        assert sort_array(input_arr) == expected
    
    def test_preserves_length(self):
        arr = [5, 3, 8, 1, 9, 2]
        result = sort_array(arr)
        assert len(result) == len(arr)
    
    def test_contains_same_elements(self):
        arr = [5, 3, 8, 1, 9, 2]
        result = sort_array(arr)
        assert sorted(result) == sorted(arr)
    
    def test_bit_count_ordering(self):
        result = sort_array([15, 7, 3, 1])
        bit_counts = [bin(x)[2:].count('1') for x in result]
        assert bit_counts == sorted(bit_counts)