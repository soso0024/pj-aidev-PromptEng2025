# Test cases for HumanEval/55
# Generated using Claude API



def fib(n: int):
    """Return n-th Fibonacci number.
    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """

    if n == 0:
        return 0
    if n == 1:
        return 1
    return fib(n - 1) + fib(n - 2)


# Generated test cases:
import pytest


def fib(n: int):
    if n == 0:
        return 0
    if n == 1:
        return 1
    return fib(n - 1) + fib(n - 2)


class TestFibBasic:
    def test_fib_0(self):
        assert fib(0) == 0

    def test_fib_1(self):
        assert fib(1) == 1

    def test_fib_2(self):
        assert fib(2) == 1

    def test_fib_3(self):
        assert fib(3) == 2

    def test_fib_4(self):
        assert fib(4) == 3

    def test_fib_5(self):
        assert fib(5) == 5

    def test_fib_8(self):
        assert fib(8) == 21

    def test_fib_10(self):
        assert fib(10) == 55


@pytest.mark.parametrize("n,expected", [
    (0, 0),
    (1, 1),
    (2, 1),
    (3, 2),
    (4, 3),
    (5, 5),
    (6, 8),
    (7, 13),
    (8, 21),
    (9, 34),
    (10, 55),
    (11, 89),
    (12, 144),
    (13, 233),
    (14, 377),
    (15, 610),
])
def test_fib_parametrized(n, expected):
    assert fib(n) == expected


class TestFibEdgeCases:
    def test_fib_large_number(self):
        assert fib(20) == 6765

    def test_fib_sequence_property(self):
        for n in range(2, 15):
            assert fib(n) == fib(n - 1) + fib(n - 2)

    def test_fib_monotonic_increasing(self):
        for n in range(1, 15):
            assert fib(n) >= fib(n - 1)

    def test_fib_positive_results(self):
        for n in range(0, 15):
            assert fib(n) >= 0


class TestFibDocstring:
    def test_docstring_example_1(self):
        assert fib(10) == 55

    def test_docstring_example_2(self):
        assert fib(1) == 1

    def test_docstring_example_3(self):
        assert fib(8) == 21
