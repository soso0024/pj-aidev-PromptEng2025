# Test cases for HumanEval/133
# Generated using Claude API



def sum_squares(lst):
    """You are given a list of numbers.
    You need to return the sum of squared numbers in the given list,
    round each element in the list to the upper int(Ceiling) first.
    Examples:
    For lst = [1,2,3] the output should be 14
    For lst = [1,4,9] the output should be 98
    For lst = [1,3,5,7] the output should be 84
    For lst = [1.4,4.2,0] the output should be 29
    For lst = [-2.4,1,1] the output should be 6
    

    """

    import math
    squared = 0
    for i in lst:
        squared += math.ceil(i)**2
    return squared


# Generated test cases:
import pytest
import math


def sum_squares(lst):
    squared = 0
    for i in lst:
        squared += math.ceil(i)**2
    return squared


class TestSumSquares:
    
    @pytest.mark.parametrize("lst,expected", [
        ([1, 2, 3], 14),
        ([1, 4, 9], 98),
        ([1, 3, 5, 7], 84),
        ([1.4, 4.2, 0], 29),
        ([-2.4, 1, 1], 6),
    ])
    def test_examples_from_docstring(self, lst, expected):
        assert sum_squares(lst) == expected
    
    def test_empty_list(self):
        assert sum_squares([]) == 0
    
    def test_single_element_positive(self):
        assert sum_squares([5]) == 25
    
    def test_single_element_negative(self):
        assert sum_squares([-5]) == 25
    
    def test_single_element_zero(self):
        assert sum_squares([0]) == 0
    
    def test_all_zeros(self):
        assert sum_squares([0, 0, 0]) == 0
    
    def test_all_positive_integers(self):
        assert sum_squares([1, 2, 3, 4]) == 1 + 4 + 9 + 16
    
    def test_all_negative_integers(self):
        assert sum_squares([-1, -2, -3]) == 1 + 4 + 9
    
    def test_mixed_positive_negative(self):
        assert sum_squares([-1, 2, -3, 4]) == 1 + 4 + 9 + 16
    
    def test_floats_ceiling_up(self):
        assert sum_squares([1.1, 2.1, 3.1]) == 4 + 9 + 16
    
    def test_floats_ceiling_down(self):
        assert sum_squares([1.9, 2.9, 3.9]) == 4 + 9 + 16
    
    def test_negative_floats_ceiling(self):
        assert sum_squares([-1.5, -2.5, -3.5]) == 1 + 4 + 9
    
    def test_floats_exact_integers(self):
        assert sum_squares([1.0, 2.0, 3.0]) == 1 + 4 + 9
    
    def test_very_small_positive_float(self):
        assert sum_squares([0.1]) == 1
    
    def test_very_small_negative_float(self):
        assert sum_squares([-0.1]) == 0
    
    def test_large_numbers(self):
        assert sum_squares([100, 200, 300]) == 10000 + 40000 + 90000
    
    def test_large_negative_numbers(self):
        assert sum_squares([-100, -200]) == 10000 + 40000
    
    def test_mixed_large_small(self):
        assert sum_squares([0.5, 100.5]) == 1 + 10201
    
    def test_many_elements(self):
        lst = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        expected = sum(i**2 for i in range(1, 11))
        assert sum_squares(lst) == expected
    
    def test_negative_zero_point_something(self):
        assert sum_squares([-0.5]) == 0
    
    def test_negative_one_point_something(self):
        assert sum_squares([-1.1]) == 1
    
    def test_positive_zero_point_something(self):
        assert sum_squares([0.5]) == 1
    
    def test_ceiling_behavior_positive(self):
        assert sum_squares([2.1, 2.5, 2.9]) == 9 + 9 + 9
    
    def test_ceiling_behavior_negative(self):
        assert sum_squares([-2.1, -2.5, -2.9]) == 4 + 4 + 4
