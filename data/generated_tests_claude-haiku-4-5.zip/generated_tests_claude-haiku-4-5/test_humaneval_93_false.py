# Test cases for HumanEval/93
# Generated using Claude API


def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """

    vowels = "aeiouAEIOU"
    vowels_replace = dict([(i, chr(ord(i) + 2)) for i in vowels])
    message = message.swapcase()
    return ''.join([vowels_replace[i] if i in vowels else i for i in message])


# Generated test cases:
import pytest


class TestEncode:
    
    def test_empty_string(self):
        from solution import encode
        assert encode("") == ""
    
    def test_single_lowercase_vowel(self):
        assert encode("a") == "C"
        assert encode("e") == "G"
        assert encode("i") == "K"
        assert encode("o") == "Q"
        assert encode("u") == "W"
    
    def test_single_uppercase_vowel(self):
        assert encode("A") == "c"
        assert encode("E") == "g"
        assert encode("I") == "k"
        assert encode("O") == "q"
        assert encode("U") == "w"
    
    def test_single_lowercase_consonant(self):
        assert encode("b") == "B"
        assert encode("c") == "C"
        assert encode("d") == "D"
        assert encode("z") == "Z"
    
    def test_single_uppercase_consonant(self):
        assert encode("B") == "b"
        assert encode("C") == "c"
        assert encode("D") == "d"
        assert encode("Z") == "z"
    
    def test_simple_word_lowercase(self):
        assert encode("hello") == "HGLLQ"
        assert encode("world") == "WQRLD"
    
    def test_simple_word_uppercase(self):
        assert encode("HELLO") == "hgllq"
        assert encode("WORLD") == "wqrld"
    
    def test_mixed_case_word(self):
        assert encode("HeLLo") == "hGllQ"
        assert encode("WoRLd") == "wQrlD"
    
    def test_all_vowels_lowercase(self):
        assert encode("aeiou") == "CGKQW"
    
    def test_all_vowels_uppercase(self):
        assert encode("AEIOU") == "cgkqw"
    
    def test_all_consonants_lowercase(self):
        assert encode("bcdfg") == "BCDFG"
    
    def test_all_consonants_uppercase(self):
        assert encode("BCDFG") == "bcdfg"
    
    def test_with_spaces(self):
        assert encode("hello world") == "HGLLQ WQRLD"
    
    def test_with_numbers(self):
        assert encode("hello123") == "HGLLQ123"
    
    def test_with_special_characters(self):
        assert encode("hello!") == "HGLLQ!"
        assert encode("test@123") == "TGST@123"
    
    def test_with_punctuation(self):
        assert encode("hello, world!") == "HGLLQ, WQRLD!"
    
    def test_with_newline(self):
        assert encode("hello\nworld") == "HGLLQ\nWQRLD"
    
    def test_with_tab(self):
        assert encode("hello\tworld") == "HGLLQ\tWQRLD"
    
    def test_long_string(self):
        result = encode("The quick brown fox jumps over the lazy dog")
        assert "C" in result or "G" in result or "K" in result or "Q" in result or "W" in result
    
    def test_repeated_vowels(self):
        assert encode("aaa") == "CCC"
        assert encode("AAA") == "ccc"
    
    def test_repeated_consonants(self):
        assert encode("bbb") == "BBB"
        assert encode("BBB") == "bbb"
    
    def test_alternating_vowels_consonants(self):
        assert encode("aba") == "CBC"
        assert encode("ABA") == "cbc"
    
    def test_vowel_encoding_values(self):
        assert encode("a") == "C"
        assert encode("e") == "G"
        assert encode("i") == "K"
        assert encode("o") == "Q"
        assert encode("u") == "W"
    
    def test_uppercase_vowel_encoding_values(self):
        assert encode("A") == "c"
        assert encode("E") == "g"
        assert encode("I") == "k"
        assert encode("O") == "q"
        assert encode("U") == "w"
    
    def test_sentence(self):
        result = encode("Hello World")
        assert result == "hGLLQ wQRLD"
    
    def test_multiple_spaces(self):
        assert encode("hello  world") == "HGLLQ  WQRLD"
    
    def test_only_spaces(self):
        assert encode("   ") == "   "
    
    def test_only_numbers(self):
        assert encode("12345") == "12345"
    
    def test_only_special_chars(self):
        assert encode("!@#$%") == "!@#$%"


@pytest.mark.parametrize("input_str,expected", [
    ("", ""),
    ("a", "C"),
    ("A", "c"),
    ("hello", "HGLLQ"),
    ("HELLO", "hgllq"),
    ("HeLLo", "hGllQ"),
    ("aeiou", "CGKQW"),
    ("AEIOU", "cgkqw"),
    ("bcdfg", "BCDFG"),
    ("BCDFG", "bcdfg"),
    ("hello world", "HGLLQ WQRLD"),
    ("hello123", "HGLLQ123"),
    ("hello!", "HGLLQ!"),
    ("test@123", "TGST@123"),
    ("hello, world!", "HGLLQ, WQRLD!"),
    ("aaa", "CCC"),
    ("AAA", "ccc"),
    ("bbb", "BBB"),
    ("BBB", "bbb"),
    ("aba", "CBC"),
    ("ABA", "cbc"),
    ("Hello World", "hGLLQ wQRLD"),
    ("   ", "   "),
    ("12345", "12345"),
    ("!@#$%", "!@#$%"),
])
def test_encode_parametrized(input_str, expected):
    assert encode(input_str) == expected