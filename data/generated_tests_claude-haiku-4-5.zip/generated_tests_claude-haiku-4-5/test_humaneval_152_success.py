# Test cases for HumanEval/152
# Generated using Claude API


def compare(game,guess):
    """I think we all remember that feeling when the result of some long-awaited
    event is finally known. The feelings and thoughts you have at that moment are
    definitely worth noting down and comparing.
    Your task is to determine if a person correctly guessed the results of a number of matches.
    You are given two arrays of scores and guesses of equal length, where each index shows a match. 
    Return an array of the same length denoting how far off each guess was. If they have guessed correctly,
    the value is 0, and if not, the value is the absolute difference between the guess and the score.
    
    
    example:

    compare([1,2,3,4,5,1],[1,2,3,4,2,-2]) -> [0,0,0,0,3,3]
    compare([0,5,0,0,0,4],[4,1,1,0,0,-2]) -> [4,4,1,0,0,6]
    """

    return [abs(x-y) for x,y in zip(game,guess)]


# Generated test cases:
import pytest


def compare(game, guess):
    return [abs(x - y) for x, y in zip(game, guess)]


class TestCompare:
    def test_identical_lists(self):
        result = compare([1, 2, 3], [1, 2, 3])
        assert result == [0, 0, 0]

    def test_completely_different_lists(self):
        result = compare([1, 2, 3], [4, 5, 6])
        assert result == [3, 3, 3]

    def test_single_element(self):
        result = compare([5], [2])
        assert result == [3]

    def test_empty_lists(self):
        result = compare([], [])
        assert result == []

    def test_negative_numbers(self):
        result = compare([-1, -2, -3], [-4, -5, -6])
        assert result == [3, 3, 3]

    def test_mixed_positive_negative(self):
        result = compare([1, -2, 3], [-1, 2, -3])
        assert result == [2, 4, 6]

    def test_zero_values(self):
        result = compare([0, 0, 0], [0, 0, 0])
        assert result == [0, 0, 0]

    def test_zero_and_nonzero(self):
        result = compare([0, 5, 10], [5, 0, 0])
        assert result == [5, 5, 10]

    def test_large_numbers(self):
        result = compare([1000000, 2000000], [500000, 1500000])
        assert result == [500000, 500000]

    def test_two_elements(self):
        result = compare([10, 20], [5, 15])
        assert result == [5, 5]

    def test_many_elements(self):
        result = compare([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        assert result == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

    def test_floats(self):
        result = compare([1.5, 2.5, 3.5], [1.0, 2.0, 3.0])
        assert result == [0.5, 0.5, 0.5]

    def test_mixed_int_float(self):
        result = compare([1, 2.5, 3], [1.5, 2, 3.5])
        assert result == [0.5, 0.5, 0.5]

    @pytest.mark.parametrize("game,guess,expected", [
        ([1, 2, 3], [1, 2, 3], [0, 0, 0]),
        ([0, 0], [0, 0], [0, 0]),
        ([5], [10], [5]),
        ([1, 2], [3, 4], [2, 2]),
        ([-5, -10], [-5, -10], [0, 0]),
        ([100, 200, 300], [50, 150, 250], [50, 50, 50]),
    ])
    def test_parametrized_cases(self, game, guess, expected):
        result = compare(game, guess)
        assert result == expected

    def test_return_type_is_list(self):
        result = compare([1, 2], [1, 2])
        assert isinstance(result, list)

    def test_result_length_matches_input_length(self):
        result = compare([1, 2, 3, 4], [5, 6, 7, 8])
        assert len(result) == 4

    def test_all_results_are_non_negative(self):
        result = compare([1, 2, 3], [10, 20, 30])
        assert all(x >= 0 for x in result)

    def test_asymmetric_differences(self):
        result = compare([1, 10, 100], [5, 5, 50])
        assert result == [4, 5, 50]
