# Test cases for HumanEval/56
# Generated using Claude API



def correct_bracketing(brackets: str):
    """ brackets is a string of "<" and ">".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """

    depth = 0
    for b in brackets:
        if b == "<":
            depth += 1
        else:
            depth -= 1
        if depth < 0:
            return False
    return depth == 0


# Generated test cases:
import pytest


def correct_bracketing(brackets: str):
    depth = 0
    for b in brackets:
        if b == "<":
            depth += 1
        else:
            depth -= 1
        if depth < 0:
            return False
    return depth == 0


class TestCorrectBracketing:
    
    @pytest.mark.parametrize("input_str,expected", [
        ("", True),
        ("<>", True),
        ("<<>>", True),
        ("<><>", True),
        ("<<<>>>", True),
        ("<><><>", True),
        ("<<><>>", True),
    ])
    def test_valid_brackets(self, input_str, expected):
        assert correct_bracketing(input_str) == expected
    
    @pytest.mark.parametrize("input_str,expected", [
        (">", False),
        ("<", False),
        ("><", False),
        (">>", False),
        ("<<>", False),
        ("><<", False),
        ("<><", False),
        ("><>", False),
        ("<<><", False),
        (">><", False),
    ])
    def test_invalid_brackets(self, input_str, expected):
        assert correct_bracketing(input_str) == expected
    
    def test_empty_string(self):
        assert correct_bracketing("") == True
    
    def test_single_opening_bracket(self):
        assert correct_bracketing("<") == False
    
    def test_single_closing_bracket(self):
        assert correct_bracketing(">") == False
    
    def test_matching_pair(self):
        assert correct_bracketing("<>") == True
    
    def test_nested_brackets(self):
        assert correct_bracketing("<<<>>>") == True
    
    def test_multiple_pairs(self):
        assert correct_bracketing("<><><>") == True
    
    def test_closing_before_opening(self):
        assert correct_bracketing("><") == False
    
    def test_extra_closing_bracket(self):
        assert correct_bracketing("<>>") == False
    
    def test_extra_opening_bracket(self):
        assert correct_bracketing("<<>") == False
    
    def test_closing_in_middle(self):
        assert correct_bracketing("<><><") == False
    
    def test_complex_valid_pattern(self):
        assert correct_bracketing("<<><><>>") == True
    
    def test_complex_invalid_pattern(self):
        assert correct_bracketing("<<><><>") == False
    
    def test_many_nested_brackets(self):
        assert correct_bracketing("<" * 100 + ">" * 100) == True
    
    def test_many_nested_brackets_invalid(self):
        assert correct_bracketing("<" * 100 + ">" * 99) == False
    
    def test_alternating_pattern(self):
        assert correct_bracketing("<>" * 50) == True
    
    def test_all_opening_brackets(self):
        assert correct_bracketing("<" * 10) == False
    
    def test_all_closing_brackets(self):
        assert correct_bracketing(">" * 10) == False
