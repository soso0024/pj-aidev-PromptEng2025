# Test cases for HumanEval/98
# Generated using Claude API


def count_upper(s):
    """
    Given a string s, count the number of uppercase vowels in even indices.
    
    For example:
    count_upper('aBCdEf') returns 1
    count_upper('abcdefg') returns 0
    count_upper('dBBE') returns 0
    """

    count = 0
    for i in range(0,len(s),2):
        if s[i] in "AEIOU":
            count += 1
    return count


# Generated test cases:
import pytest


def count_upper(s):
    count = 0
    for i in range(0, len(s), 2):
        if s[i] in "AEIOU":
            count += 1
    return count


class TestCountUpper:
    def test_example_one(self):
        assert count_upper('aBCdEf') == 1

    def test_example_two(self):
        assert count_upper('abcdefg') == 0

    def test_example_three(self):
        assert count_upper('dBBE') == 0

    def test_empty_string(self):
        assert count_upper('') == 0

    def test_single_uppercase_vowel(self):
        assert count_upper('A') == 1

    def test_single_uppercase_consonant(self):
        assert count_upper('B') == 0

    def test_single_lowercase_vowel(self):
        assert count_upper('a') == 0

    def test_all_uppercase_vowels_at_even_indices(self):
        assert count_upper('AEIOU') == 3

    def test_all_uppercase_vowels_at_odd_indices(self):
        assert count_upper('bAbEiOu') == 0

    def test_mixed_case_vowels(self):
        assert count_upper('AaBbEe') == 2

    def test_uppercase_consonants_at_even_indices(self):
        assert count_upper('BCDFG') == 0

    def test_alternating_uppercase_vowels_and_consonants(self):
        assert count_upper('AxExIxOxU') == 5

    def test_long_string_with_multiple_uppercase_vowels(self):
        assert count_upper('AaBbCcDdEeFfGgHhIiJjOoKkUu') == 5

    def test_only_consonants(self):
        assert count_upper('bcdfghjklmnpqrstvwxyz') == 0

    def test_only_lowercase_vowels(self):
        assert count_upper('aeiouaeiou') == 0

    def test_uppercase_vowels_only(self):
        assert count_upper('AEIOUAEIOU') == 5

    def test_two_character_string_uppercase_vowel(self):
        assert count_upper('Ax') == 1

    def test_two_character_string_uppercase_consonant(self):
        assert count_upper('Bx') == 0

    def test_two_character_string_lowercase_vowel(self):
        assert count_upper('ax') == 0

    def test_special_characters_at_even_indices(self):
        assert count_upper('!@#$%^&*') == 0

    def test_numbers_at_even_indices(self):
        assert count_upper('A1E2I3O4U5') == 5

    def test_mixed_special_chars_and_vowels(self):
        assert count_upper('A!E@I#O$U%') == 5

    def test_string_with_spaces(self):
        assert count_upper('A B E F I J') == 3

    @pytest.mark.parametrize("input_str,expected", [
        ('aBCdEf', 1),
        ('abcdefg', 0),
        ('dBBE', 0),
        ('', 0),
        ('A', 1),
        ('a', 0),
        ('AEIOU', 3),
        ('aeiou', 0),
        ('AaBbCcDdEe', 2),
    ])
    def test_parametrized_cases(self, input_str, expected):
        assert count_upper(input_str) == expected