# Test cases for HumanEval/115
# Generated using Claude API


def max_fill(grid, capacity):
    import math
    """
    You are given a rectangular grid of wells. Each row represents a single well,
    and each 1 in a row represents a single unit of water.
    Each well has a corresponding bucket that can be used to extract water from it, 
    and all buckets have the same capacity.
    Your task is to use the buckets to empty the wells.
    Output the number of times you need to lower the buckets.

    Example 1:
        Input: 
            grid : [[0,0,1,0], [0,1,0,0], [1,1,1,1]]
            bucket_capacity : 1
        Output: 6

    Example 2:
        Input: 
            grid : [[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]]
            bucket_capacity : 2
        Output: 5
    
    Example 3:
        Input: 
            grid : [[0,0,0], [0,0,0]]
            bucket_capacity : 5
        Output: 0

    Constraints:
        * all wells have the same length
        * 1 <= grid.length <= 10^2
        * 1 <= grid[:,1].length <= 10^2
        * grid[i][j] -> 0 | 1
        * 1 <= capacity <= 10
    """

    return sum([math.ceil(sum(arr)/capacity) for arr in grid])


# Generated test cases:
import pytest
import math


def max_fill(grid, capacity):
    return sum([math.ceil(sum(arr)/capacity) for arr in grid])


class TestMaxFill:
    
    def test_single_row_single_element(self):
        grid = [[5]]
        capacity = 5
        assert max_fill(grid, capacity) == 1
    
    def test_single_row_multiple_elements(self):
        grid = [[1, 2, 3]]
        capacity = 3
        assert max_fill(grid, capacity) == 2
    
    def test_multiple_rows(self):
        grid = [[1, 2, 3], [4, 5, 6]]
        capacity = 5
        assert max_fill(grid, capacity) == 5
    
    def test_empty_rows(self):
        grid = [[0], [0], [0]]
        capacity = 5
        assert max_fill(grid, capacity) == 0
    
    def test_large_capacity(self):
        grid = [[1, 2, 3], [4, 5, 6]]
        capacity = 100
        assert max_fill(grid, capacity) == 2
    
    def test_capacity_equals_sum(self):
        grid = [[5, 5], [10]]
        capacity = 10
        assert max_fill(grid, capacity) == 2
    
    def test_single_large_element(self):
        grid = [[100]]
        capacity = 10
        assert max_fill(grid, capacity) == 10
    
    def test_fractional_division(self):
        grid = [[7]]
        capacity = 3
        assert max_fill(grid, capacity) == 3
    
    def test_multiple_rows_different_sums(self):
        grid = [[1], [2], [3], [4]]
        capacity = 2
        assert max_fill(grid, capacity) == 6
    
    def test_all_zeros(self):
        grid = [[0, 0, 0]]
        capacity = 1
        assert max_fill(grid, capacity) == 0
    
    def test_single_element_per_row(self):
        grid = [[1], [1], [1]]
        capacity = 1
        assert max_fill(grid, capacity) == 3
    
    def test_capacity_one(self):
        grid = [[5, 5, 5]]
        capacity = 1
        assert max_fill(grid, capacity) == 15
    
    def test_mixed_values(self):
        grid = [[0, 5, 0], [3, 0, 2]]
        capacity = 4
        assert max_fill(grid, capacity) == 4
    
    def test_large_grid(self):
        grid = [[1, 2, 3, 4, 5], [6, 7, 8, 9, 10]]
        capacity = 10
        assert max_fill(grid, capacity) == 6
    
    def test_single_row_empty_list(self):
        grid = [[]]
        capacity = 5
        assert max_fill(grid, capacity) == 0
    
    def test_decimal_like_division(self):
        grid = [[10, 10, 10]]
        capacity = 7
        assert max_fill(grid, capacity) == 5
    
    def test_exact_division(self):
        grid = [[10, 10], [20]]
        capacity = 10
        assert max_fill(grid, capacity) == 4
    
    def test_many_small_values(self):
        grid = [[1, 1, 1, 1, 1]]
        capacity = 2
        assert max_fill(grid, capacity) == 3
    
    def test_single_row_large_values(self):
        grid = [[100, 200, 300]]
        capacity = 150
        assert max_fill(grid, capacity) == 4
    
    @pytest.mark.parametrize("grid,capacity,expected", [
        ([[5]], 5, 1),
        ([[1, 2, 3]], 3, 2),
        ([[0]], 1, 0),
        ([[10]], 3, 4),
        ([[1, 1, 1]], 1, 3),
    ])
    def test_parametrized_cases(self, grid, capacity, expected):
        assert max_fill(grid, capacity) == expected