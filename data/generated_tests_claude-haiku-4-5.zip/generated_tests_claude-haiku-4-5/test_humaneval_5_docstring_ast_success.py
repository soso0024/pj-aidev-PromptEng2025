# Test cases for HumanEval/5
# Generated using Claude API

from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """ Insert a number 'delimeter' between every two consecutive elements of input list `numbers'
    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """

    if not numbers:
        return []

    result = []

    for n in numbers[:-1]:
        result.append(n)
        result.append(delimeter)

    result.append(numbers[-1])

    return result


# Generated test cases:
import pytest
from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    if not numbers:
        return []

    result = []

    for n in numbers[:-1]:
        result.append(n)
        result.append(delimeter)

    result.append(numbers[-1])

    return result


class TestIntersperse:
    def test_empty_list(self):
        assert intersperse([], 4) == []

    def test_single_element(self):
        assert intersperse([1], 4) == [1]

    def test_two_elements(self):
        assert intersperse([1, 2], 4) == [1, 4, 2]

    def test_three_elements(self):
        assert intersperse([1, 2, 3], 4) == [1, 4, 2, 4, 3]

    def test_multiple_elements(self):
        assert intersperse([1, 2, 3, 4, 5], 0) == [1, 0, 2, 0, 3, 0, 4, 0, 5]

    def test_negative_delimiter(self):
        assert intersperse([1, 2, 3], -1) == [1, -1, 2, -1, 3]

    def test_negative_numbers(self):
        assert intersperse([-1, -2, -3], 0) == [-1, 0, -2, 0, -3]

    def test_zero_delimiter(self):
        assert intersperse([5, 10, 15], 0) == [5, 0, 10, 0, 15]

    def test_large_numbers(self):
        assert intersperse([1000, 2000, 3000], 999) == [1000, 999, 2000, 999, 3000]

    def test_delimiter_same_as_element(self):
        assert intersperse([5, 5, 5], 5) == [5, 5, 5, 5, 5]

    def test_all_zeros(self):
        assert intersperse([0, 0, 0], 0) == [0, 0, 0, 0, 0]

    def test_mixed_positive_negative(self):
        assert intersperse([-5, 10, -3, 7], 0) == [-5, 0, 10, 0, -3, 0, 7]

    @pytest.mark.parametrize("numbers,delimiter,expected", [
        ([], 4, []),
        ([1], 4, [1]),
        ([1, 2], 4, [1, 4, 2]),
        ([1, 2, 3], 4, [1, 4, 2, 4, 3]),
        ([10, 20, 30, 40], 5, [10, 5, 20, 5, 30, 5, 40]),
        ([1, 1, 1], 2, [1, 2, 1, 2, 1]),
        ([-1, -2, -3], -99, [-1, -99, -2, -99, -3]),
    ])
    def test_parametrized(self, numbers, delimiter, expected):
        assert intersperse(numbers, delimiter) == expected

    def test_result_length(self):
        numbers = [1, 2, 3, 4]
        result = intersperse(numbers, 0)
        assert len(result) == 2 * len(numbers) - 1

    def test_result_length_single_element(self):
        numbers = [42]
        result = intersperse(numbers, 0)
        assert len(result) == 1

    def test_result_length_empty(self):
        numbers = []
        result = intersperse(numbers, 0)
        assert len(result) == 0

    def test_original_list_unchanged(self):
        original = [1, 2, 3]
        original_copy = original.copy()
        intersperse(original, 4)
        assert original == original_copy

    def test_delimiter_appears_correct_times(self):
        numbers = [1, 2, 3, 4, 5]
        delimiter = 99
        result = intersperse(numbers, delimiter)
        assert result.count(delimiter) == len(numbers) - 1

    def test_original_elements_preserved(self):
        numbers = [1, 2, 3, 4]
        delimiter = 0
        result = intersperse(numbers, delimiter)
        original_elements = [x for x in result if x != delimiter]
        assert original_elements == numbers
