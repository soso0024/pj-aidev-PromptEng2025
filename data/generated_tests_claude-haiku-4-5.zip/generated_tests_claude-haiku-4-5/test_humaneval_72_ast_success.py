# Test cases for HumanEval/72
# Generated using Claude API


def will_it_fly(q,w):
    '''
    Write a function that returns True if the object q will fly, and False otherwise.
    The object q will fly if it's balanced (it is a palindromic list) and the sum of its elements is less than or equal the maximum possible weight w.

    Example:
    will_it_fly([1, 2], 5) ➞ False 
    # 1+2 is less than the maximum possible weight, but it's unbalanced.

    will_it_fly([3, 2, 3], 1) ➞ False
    # it's balanced, but 3+2+3 is more than the maximum possible weight.

    will_it_fly([3, 2, 3], 9) ➞ True
    # 3+2+3 is less than the maximum possible weight, and it's balanced.

    will_it_fly([3], 5) ➞ True
    # 3 is less than the maximum possible weight, and it's balanced.
    '''

    if sum(q) > w:
        return False

    i, j = 0, len(q)-1
    while i<j:
        if q[i] != q[j]:
            return False
        i+=1
        j-=1
    return True


# Generated test cases:
import pytest


def will_it_fly(q, w):
    if sum(q) > w:
        return False

    i, j = 0, len(q) - 1
    while i < j:
        if q[i] != q[j]:
            return False
        i += 1
        j -= 1
    return True


class TestWillItFly:
    
    def test_palindrome_within_weight(self):
        assert will_it_fly([1, 2, 1], 5) == True
    
    def test_palindrome_exact_weight(self):
        assert will_it_fly([1, 2, 1], 4) == True
    
    def test_palindrome_exceeds_weight(self):
        assert will_it_fly([1, 2, 1], 3) == False
    
    def test_not_palindrome(self):
        assert will_it_fly([1, 2, 3], 6) == False
    
    def test_single_element(self):
        assert will_it_fly([5], 10) == True
    
    def test_single_element_exceeds_weight(self):
        assert will_it_fly([10], 5) == False
    
    def test_two_elements_palindrome(self):
        assert will_it_fly([2, 2], 4) == True
    
    def test_two_elements_not_palindrome(self):
        assert will_it_fly([2, 3], 5) == False
    
    def test_empty_list(self):
        assert will_it_fly([], 10) == True
    
    def test_all_zeros(self):
        assert will_it_fly([0, 0, 0], 1) == True
    
    def test_large_palindrome(self):
        assert will_it_fly([1, 2, 3, 2, 1], 10) == True
    
    def test_large_palindrome_exceeds_weight(self):
        assert will_it_fly([5, 5, 5, 5, 5], 20) == False
    
    def test_negative_numbers_palindrome(self):
        assert will_it_fly([-1, 0, -1], 0) == True
    
    def test_negative_numbers_not_palindrome(self):
        assert will_it_fly([-1, 0, 1], 0) == False
    
    def test_mixed_positive_negative_palindrome(self):
        assert will_it_fly([-5, 3, -5], 0) == True
    
    def test_mixed_positive_negative_exceeds_weight(self):
        assert will_it_fly([-5, 3, -5], -15) == False
    
    def test_even_length_palindrome(self):
        assert will_it_fly([1, 1, 1, 1], 4) == True
    
    def test_even_length_not_palindrome(self):
        assert will_it_fly([1, 2, 2, 1], 6) == True
    
    def test_odd_length_palindrome(self):
        assert will_it_fly([1, 2, 3, 2, 1], 9) == True
    
    def test_zero_weight_limit(self):
        assert will_it_fly([0], 0) == True
    
    def test_zero_weight_limit_with_positive(self):
        assert will_it_fly([1], 0) == False
    
    def test_large_numbers_palindrome(self):
        assert will_it_fly([1000, 2000, 1000], 4000) == True
    
    def test_large_numbers_exceeds_weight(self):
        assert will_it_fly([1000, 2000, 1000], 3999) == False
    
    def test_float_like_integers(self):
        assert will_it_fly([1, 1], 2) == True
    
    def test_repeated_elements_palindrome(self):
        assert will_it_fly([5, 5, 5, 5, 5], 25) == True
    
    def test_repeated_elements_not_palindrome(self):
        assert will_it_fly([5, 5, 3, 5, 5], 25) == True
    
    def test_weight_exactly_sum(self):
        assert will_it_fly([1, 2, 3, 2, 1], 9) == True
    
    def test_weight_one_less_than_sum(self):
        assert will_it_fly([1, 2, 3, 2, 1], 8) == False
    
    def test_complex_palindrome(self):
        assert will_it_fly([10, 20, 30, 20, 10], 90) == True
    
    def test_complex_not_palindrome(self):
        assert will_it_fly([10, 20, 30, 20, 11], 91) == False


@pytest.mark.parametrize("q,w,expected", [
    ([1, 2, 1], 5, True),
    ([1, 2, 1], 3, False),
    ([1, 2, 3], 6, False),
    ([5], 10, True),
    ([10], 5, False),
    ([2, 2], 4, True),
    ([2, 3], 5, False),
    ([], 10, True),
    ([0, 0, 0], 1, True),
    ([1, 2, 3, 2, 1], 10, True),
    ([5, 5, 5, 5, 5], 20, False),
    ([-1, 0, -1], 0, True),
    ([-1, 0, 1], 0, False),
    ([1, 1, 1, 1], 4, True),
    ([1, 2, 2, 1], 6, True),
    ([0], 0, True),
    ([1], 0, False),
    ([1000, 2000, 1000], 4000, True),
    ([1000, 2000, 1000], 3999, False),
    ([5, 5, 5, 5, 5], 25, True),
])
def test_will_it_fly_parametrized(q, w, expected):
    assert will_it_fly(q, w) == expected