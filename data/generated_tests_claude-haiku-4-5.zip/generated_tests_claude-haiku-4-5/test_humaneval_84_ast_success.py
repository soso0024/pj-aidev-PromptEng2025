# Test cases for HumanEval/84
# Generated using Claude API


def solve(N):
    """Given a positive integer N, return the total sum of its digits in binary.
    
    Example
        For N = 1000, the sum of digits will be 1 the output should be "1".
        For N = 150, the sum of digits will be 6 the output should be "110".
        For N = 147, the sum of digits will be 12 the output should be "1100".
    
    Variables:
        @N integer
             Constraints: 0 ≤ N ≤ 10000.
    Output:
         a string of binary number
    """

    return bin(sum(int(i) for i in str(N)))[2:]


# Generated test cases:
import pytest


def solve(N):
    return bin(sum(int(i) for i in str(N)))[2:]


class TestSolve:
    def test_single_digit_zero(self):
        assert solve(0) == '0'
    
    def test_single_digit_one(self):
        assert solve(1) == '1'
    
    def test_single_digit_nine(self):
        assert solve(9) == '1001'
    
    def test_two_digits_sum_one(self):
        assert solve(10) == '1'
    
    def test_two_digits_sum_three(self):
        assert solve(12) == '11'
    
    def test_two_digits_sum_eighteen(self):
        assert solve(99) == '10010'
    
    def test_three_digits_sum_six(self):
        assert solve(123) == '110'
    
    def test_three_digits_sum_twenty_seven(self):
        assert solve(999) == '11011'
    
    def test_large_number(self):
        assert solve(123456789) == '101101'
    
    def test_number_with_zeros(self):
        assert solve(1001) == '10'
    
    def test_number_with_leading_zeros_in_digits(self):
        assert solve(100) == '1'
    
    def test_sum_equals_two(self):
        assert solve(2) == '10'
    
    def test_sum_equals_four(self):
        assert solve(4) == '100'
    
    def test_sum_equals_eight(self):
        assert solve(8) == '1000'
    
    def test_sum_equals_sixteen(self):
        assert solve(79) == '10000'
    
    def test_sum_equals_thirty_six(self):
        assert solve(9999) == '100100'
    
    def test_number_with_all_same_digits(self):
        assert solve(111) == '11'
    
    def test_number_with_all_same_digits_fives(self):
        assert solve(555) == '1111'
    
    def test_small_sum_binary(self):
        assert solve(11) == '10'
    
    def test_medium_number(self):
        assert solve(456) == '1111'
    
    def test_return_type_is_string(self):
        result = solve(42)
        assert isinstance(result, str)
    
    def test_return_value_is_binary(self):
        result = solve(15)
        assert all(c in '01' for c in result)
    
    def test_no_0b_prefix(self):
        result = solve(10)
        assert not result.startswith('0b')


@pytest.mark.parametrize("input_val,expected", [
    (0, '0'),
    (1, '1'),
    (9, '1001'),
    (10, '1'),
    (12, '11'),
    (99, '10010'),
    (123, '110'),
    (999, '11011'),
    (100, '1'),
    (2, '10'),
    (4, '100'),
    (8, '1000'),
    (79, '10000'),
    (111, '11'),
    (555, '1111'),
    (11, '10'),
    (456, '1111'),
    (15, '110'),
])
def test_solve_parametrized(input_val, expected):
    assert solve(input_val) == expected