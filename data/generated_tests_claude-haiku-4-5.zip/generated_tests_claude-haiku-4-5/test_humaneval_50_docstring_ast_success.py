# Test cases for HumanEval/50
# Generated using Claude API



def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


def decode_shift(s: str):
    """
    takes as input string encoded with encode_shift function. Returns decoded string.
    """

    return "".join([chr(((ord(ch) - 5 - ord("a")) % 26) + ord("a")) for ch in s])


# Generated test cases:
import pytest


def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


def decode_shift(s: str):
    """
    takes as input string encoded with encode_shift function. Returns decoded string.
    """
    return "".join([chr(((ord(ch) - 5 - ord("a")) % 26) + ord("a")) for ch in s])


class TestDecodeShift:
    
    def test_decode_empty_string(self):
        assert decode_shift("") == ""
    
    def test_decode_single_character(self):
        encoded = encode_shift("a")
        assert decode_shift(encoded) == "a"
    
    def test_decode_single_character_z(self):
        encoded = encode_shift("z")
        assert decode_shift(encoded) == "z"
    
    def test_decode_simple_word(self):
        encoded = encode_shift("hello")
        assert decode_shift(encoded) == "hello"
    
    def test_decode_alphabet(self):
        encoded = encode_shift("abcdefghijklmnopqrstuvwxyz")
        assert decode_shift(encoded) == "abcdefghijklmnopqrstuvwxyz"
    
    def test_decode_with_wrapping_start(self):
        encoded = encode_shift("abc")
        assert decode_shift(encoded) == "abc"
    
    def test_decode_with_wrapping_end(self):
        encoded = encode_shift("xyz")
        assert decode_shift(encoded) == "xyz"
    
    def test_decode_long_string(self):
        original = "thequickbrownfoxjumpsoverthelazydog"
        encoded = encode_shift(original)
        assert decode_shift(encoded) == original
    
    def test_decode_repeated_characters(self):
        encoded = encode_shift("aaaa")
        assert decode_shift(encoded) == "aaaa"
    
    def test_decode_repeated_characters_z(self):
        encoded = encode_shift("zzzz")
        assert decode_shift(encoded) == "zzzz"
    
    @pytest.mark.parametrize("original", [
        "a",
        "z",
        "m",
        "hello",
        "world",
        "python",
        "testing",
        "abcdefghijklmnopqrstuvwxyz",
        "zzzzaaaa",
        "aabbccdd"
    ])
    def test_decode_various_strings(self, original):
        encoded = encode_shift(original)
        assert decode_shift(encoded) == original
    
    def test_decode_is_inverse_of_encode(self):
        test_strings = [
            "a",
            "abc",
            "xyz",
            "hello",
            "thequickbrownfox",
            "abcdefghijklmnopqrstuvwxyz"
        ]
        for s in test_strings:
            encoded = encode_shift(s)
            decoded = decode_shift(encoded)
            assert decoded == s
    
    def test_decode_double_encoding_decoding(self):
        original = "test"
        encoded_once = encode_shift(original)
        encoded_twice = encode_shift(encoded_once)
        decoded_once = decode_shift(encoded_twice)
        decoded_twice = decode_shift(decoded_once)
        assert decoded_twice == original
    
    def test_decode_specific_encoded_values(self):
        assert decode_shift("f") == "a"
        assert decode_shift("g") == "b"
        assert decode_shift("k") == "f"
    
    def test_decode_wrapping_cases(self):
        assert decode_shift("e") == "z"
        assert decode_shift("d") == "y"
        assert decode_shift("c") == "x"
    
    def test_decode_all_letters(self):
        for i in range(26):
            char = chr(ord("a") + i)
            encoded = encode_shift(char)
            decoded = decode_shift(encoded)
            assert decoded == char
