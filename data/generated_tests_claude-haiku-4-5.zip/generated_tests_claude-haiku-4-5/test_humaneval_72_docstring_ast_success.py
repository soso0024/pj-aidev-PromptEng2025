# Test cases for HumanEval/72
# Generated using Claude API


def will_it_fly(q,w):
    '''
    Write a function that returns True if the object q will fly, and False otherwise.
    The object q will fly if it's balanced (it is a palindromic list) and the sum of its elements is less than or equal the maximum possible weight w.

    Example:
    will_it_fly([1, 2], 5) ➞ False 
    # 1+2 is less than the maximum possible weight, but it's unbalanced.

    will_it_fly([3, 2, 3], 1) ➞ False
    # it's balanced, but 3+2+3 is more than the maximum possible weight.

    will_it_fly([3, 2, 3], 9) ➞ True
    # 3+2+3 is less than the maximum possible weight, and it's balanced.

    will_it_fly([3], 5) ➞ True
    # 3 is less than the maximum possible weight, and it's balanced.
    '''

    if sum(q) > w:
        return False

    i, j = 0, len(q)-1
    while i<j:
        if q[i] != q[j]:
            return False
        i+=1
        j-=1
    return True


# Generated test cases:
import pytest


def will_it_fly(q, w):
    if sum(q) > w:
        return False

    i, j = 0, len(q) - 1
    while i < j:
        if q[i] != q[j]:
            return False
        i += 1
        j -= 1
    return True


class TestWillItFly:
    
    @pytest.mark.parametrize("q,w,expected", [
        ([1, 2], 5, False),
        ([3, 2, 3], 1, False),
        ([3, 2, 3], 9, True),
        ([3], 5, True),
    ])
    def test_docstring_examples(self, q, w, expected):
        assert will_it_fly(q, w) == expected
    
    def test_empty_list(self):
        assert will_it_fly([], 10) == True
    
    def test_single_element_within_weight(self):
        assert will_it_fly([5], 10) == True
    
    def test_single_element_exceeds_weight(self):
        assert will_it_fly([15], 10) == False
    
    def test_two_element_palindrome_within_weight(self):
        assert will_it_fly([2, 2], 10) == True
    
    def test_two_element_palindrome_exceeds_weight(self):
        assert will_it_fly([6, 6], 10) == False
    
    def test_two_element_not_palindrome(self):
        assert will_it_fly([1, 2], 10) == False
    
    def test_odd_length_palindrome_within_weight(self):
        assert will_it_fly([1, 2, 1], 10) == True
    
    def test_odd_length_palindrome_exceeds_weight(self):
        assert will_it_fly([5, 5, 5], 10) == False
    
    def test_odd_length_not_palindrome(self):
        assert will_it_fly([1, 2, 3], 10) == False
    
    def test_even_length_palindrome_within_weight(self):
        assert will_it_fly([2, 3, 3, 2], 20) == True
    
    def test_even_length_palindrome_exceeds_weight(self):
        assert will_it_fly([5, 5, 5, 5], 10) == False
    
    def test_even_length_not_palindrome(self):
        assert will_it_fly([1, 2, 3, 4], 20) == False
    
    def test_long_palindrome_within_weight(self):
        assert will_it_fly([1, 2, 3, 2, 1], 20) == True
    
    def test_long_palindrome_exceeds_weight(self):
        assert will_it_fly([10, 10, 10, 10, 10], 40) == False
    
    def test_zero_weight_empty_list(self):
        assert will_it_fly([], 0) == True
    
    def test_zero_weight_non_empty_list(self):
        assert will_it_fly([1], 0) == False
    
    def test_negative_numbers_palindrome(self):
        assert will_it_fly([-1, 0, -1], 10) == True
    
    def test_negative_numbers_not_palindrome(self):
        assert will_it_fly([-1, 0, 1], 10) == False
    
    def test_all_zeros_palindrome(self):
        assert will_it_fly([0, 0, 0], 10) == True
    
    def test_large_numbers_palindrome_within_weight(self):
        assert will_it_fly([100, 200, 100], 500) == True
    
    def test_large_numbers_palindrome_exceeds_weight(self):
        assert will_it_fly([100, 200, 100], 300) == False
    
    def test_weight_equals_sum(self):
        assert will_it_fly([1, 2, 1], 4) == True
    
    def test_weight_one_less_than_sum(self):
        assert will_it_fly([1, 2, 1], 3) == False
    
    def test_mixed_positive_negative_palindrome(self):
        assert will_it_fly([-5, 10, -5], 10) == True
    
    def test_mixed_positive_negative_not_palindrome(self):
        assert will_it_fly([-5, 10, 5], 10) == False
    
    def test_very_long_palindrome(self):
        q = [1] * 100 + [2] + [1] * 100
        assert will_it_fly(q, 300) == True
    
    def test_very_long_palindrome_exceeds_weight(self):
        q = [1] * 100 + [2] + [1] * 100
        assert will_it_fly(q, 100) == False
    
    def test_palindrome_with_floats(self):
        assert will_it_fly([1.5, 2.5, 1.5], 10) == True
    
    def test_not_palindrome_with_floats(self):
        assert will_it_fly([1.5, 2.5, 3.5], 10) == False
