# Test cases for HumanEval/7
# Generated using Claude API

from typing import List


def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """ Filter an input list of strings only for ones that contain given substring
    >>> filter_by_substring([], 'a')
    []
    >>> filter_by_substring(['abc', 'bacd', 'cde', 'array'], 'a')
    ['abc', 'bacd', 'array']
    """

    return [x for x in strings if substring in x]


# Generated test cases:
import pytest
from typing import List


def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    return [x for x in strings if substring in x]


class TestFilterBySubstring:
    
    def test_empty_list(self):
        assert filter_by_substring([], 'a') == []
    
    def test_empty_substring(self):
        assert filter_by_substring(['abc', 'def', 'ghi'], '') == ['abc', 'def', 'ghi']
    
    def test_basic_filtering(self):
        assert filter_by_substring(['abc', 'bacd', 'cde', 'array'], 'a') == ['abc', 'bacd', 'array']
    
    def test_no_matches(self):
        assert filter_by_substring(['xyz', 'def', 'ghi'], 'a') == []
    
    def test_all_matches(self):
        assert filter_by_substring(['apple', 'apricot', 'application'], 'ap') == ['apple', 'apricot', 'application']
    
    def test_single_element_match(self):
        assert filter_by_substring(['hello'], 'ell') == ['hello']
    
    def test_single_element_no_match(self):
        assert filter_by_substring(['hello'], 'xyz') == []
    
    def test_substring_at_start(self):
        assert filter_by_substring(['apple', 'banana', 'apricot'], 'ap') == ['apple', 'apricot']
    
    def test_substring_at_end(self):
        assert filter_by_substring(['cat', 'bat', 'rat', 'dog'], 'at') == ['cat', 'bat', 'rat']
    
    def test_substring_in_middle(self):
        assert filter_by_substring(['hello', 'world', 'help'], 'ell') == ['hello']
    
    def test_case_sensitive(self):
        assert filter_by_substring(['Apple', 'apple', 'APPLE'], 'app') == ['apple']
    
    def test_substring_equals_string(self):
        assert filter_by_substring(['abc', 'def', 'abc'], 'abc') == ['abc', 'abc']
    
    def test_duplicate_strings(self):
        assert filter_by_substring(['test', 'test', 'best'], 'test') == ['test', 'test']
    
    def test_special_characters(self):
        assert filter_by_substring(['hello!', 'world?', 'test!'], '!') == ['hello!', 'test!']
    
    def test_numbers_in_strings(self):
        assert filter_by_substring(['abc123', 'def456', 'ghi123'], '123') == ['abc123', 'ghi123']
    
    def test_whitespace_in_substring(self):
        assert filter_by_substring(['hello world', 'helloworld', 'hello there'], ' ') == ['hello world', 'hello there']
    
    def test_single_character_substring(self):
        assert filter_by_substring(['a', 'b', 'c', 'ab'], 'a') == ['a', 'ab']
    
    def test_long_substring(self):
        assert filter_by_substring(['thequickbrownfox', 'quickbrown', 'brown'], 'quickbrown') == ['thequickbrownfox', 'quickbrown']
    
    def test_unicode_characters(self):
        assert filter_by_substring(['café', 'naïve', 'resume'], 'é') == ['café']
    
    def test_repeated_substring_in_string(self):
        assert filter_by_substring(['aaa', 'bbb', 'aba'], 'a') == ['aaa', 'aba']


@pytest.mark.parametrize("strings,substring,expected", [
    ([], 'a', []),
    (['abc', 'bacd', 'cde', 'array'], 'a', ['abc', 'bacd', 'array']),
    (['test'], 'test', ['test']),
    (['a', 'b', 'c'], 'x', []),
    (['hello', 'world'], 'o', ['hello', 'world']),
    (['python', 'java', 'javascript'], 'java', ['java', 'javascript']),
    (['123', '456', '789'], '1', ['123']),
])
def test_filter_by_substring_parametrized(strings, substring, expected):
    assert filter_by_substring(strings, substring) == expected