# Test cases for HumanEval/45
# Generated using Claude API



def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """

    return a * h / 2.0


# Generated test cases:
import pytest


class TestTriangleArea:
    
    def test_basic_triangle(self):
        assert triangle_area(4, 5) == 10.0
    
    def test_unit_triangle(self):
        assert triangle_area(1, 1) == 0.5
    
    def test_zero_base(self):
        assert triangle_area(0, 5) == 0.0
    
    def test_zero_height(self):
        assert triangle_area(5, 0) == 0.0
    
    def test_both_zero(self):
        assert triangle_area(0, 0) == 0.0
    
    def test_large_numbers(self):
        assert triangle_area(1000, 2000) == 1000000.0
    
    def test_decimal_values(self):
        assert triangle_area(2.5, 4.0) == 5.0
    
    def test_small_decimal_values(self):
        assert triangle_area(0.5, 0.5) == 0.125
    
    def test_negative_base(self):
        assert triangle_area(-4, 5) == -10.0
    
    def test_negative_height(self):
        assert triangle_area(4, -5) == -10.0
    
    def test_both_negative(self):
        assert triangle_area(-4, -5) == 10.0
    
    def test_float_precision(self):
        result = triangle_area(3, 7)
        assert abs(result - 10.5) < 1e-9
    
    def test_very_small_values(self):
        result = triangle_area(0.001, 0.001)
        assert abs(result - 0.0000005) < 1e-10
    
    def test_mixed_sign_values(self):
        assert triangle_area(-2.5, 4.0) == -5.0
    
    @pytest.mark.parametrize("a,h,expected", [
        (3, 4, 6.0),
        (5, 2, 5.0),
        (10, 10, 50.0),
        (1.5, 2.0, 1.5),
        (0.1, 0.1, 0.005),
        (100, 0.01, 0.5),
    ])
    def test_parametrized_valid_inputs(self, a, h, expected):
        assert abs(triangle_area(a, h) - expected) < 1e-9
    
    @pytest.mark.parametrize("a,h", [
        (0, 0),
        (0, 10),
        (10, 0),
        (-5, -5),
    ])
    def test_parametrized_zero_or_negative(self, a, h):
        result = triangle_area(a, h)
        assert isinstance(result, float)


def triangle_area(a, h):
    return a * h / 2.0