# Test cases for HumanEval/160
# Generated using Claude API


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and 
    the second list is a list of integers. Use the two given lists to build the algebric 
    expression and return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + ) 
    Subtraction ( - ) 
    Multiplication ( * ) 
    Floor division ( // ) 
    Exponentiation ( ** ) 

    Example:
    operator['+', '*', '-']
    array = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9

    Note:
        The length of operator list is equal to the length of operand list minus one.
        Operand is a list of of non-negative integers.
        Operator list has at least one operator, and operand list has at least two operands.

    """

    expression = str(operand[0])
    for oprt, oprn in zip(operator, operand[1:]):
        expression+= oprt + str(oprn)
    return eval(expression)


# Generated test cases:
import pytest


def do_algebra(operator, operand):
    expression = str(operand[0])
    for oprt, oprn in zip(operator, operand[1:]):
        expression+= oprt + str(oprn)
    return eval(expression)


class TestDoAlgebra:
    
    def test_simple_addition(self):
        assert do_algebra(['+'], [1, 2]) == 3
    
    def test_simple_subtraction(self):
        assert do_algebra(['-'], [5, 2]) == 3
    
    def test_simple_multiplication(self):
        assert do_algebra(['*'], [3, 4]) == 12
    
    def test_simple_division(self):
        assert do_algebra(['/'], [10, 2]) == 5
    
    def test_multiple_operations(self):
        assert do_algebra(['+', '*'], [1, 2, 3]) == 7
    
    def test_multiple_additions(self):
        assert do_algebra(['+', '+'], [1, 2, 3]) == 6
    
    def test_multiple_subtractions(self):
        assert do_algebra(['-', '-'], [10, 3, 2]) == 5
    
    def test_order_of_operations(self):
        assert do_algebra(['+', '*'], [2, 3, 4]) == 14
    
    def test_order_of_operations_division(self):
        assert do_algebra(['*', '/'], [2, 3, 2]) == 3
    
    def test_negative_numbers(self):
        assert do_algebra(['+'], [-5, 3]) == -2
    
    def test_negative_operands(self):
        assert do_algebra(['-'], [-5, -3]) == -2
    
    def test_zero_operand(self):
        assert do_algebra(['+'], [0, 5]) == 5
    
    def test_zero_result(self):
        assert do_algebra(['-'], [5, 5]) == 0
    
    def test_multiplication_by_zero(self):
        assert do_algebra(['*'], [5, 0]) == 0
    
    def test_division_result_float(self):
        assert do_algebra(['/'], [5, 2]) == 2.5
    
    def test_complex_expression(self):
        assert do_algebra(['+', '-', '*'], [1, 2, 3, 4]) == -9
    
    def test_long_chain_operations(self):
        assert do_algebra(['+', '+', '+'], [1, 1, 1, 1]) == 4
    
    def test_large_numbers(self):
        assert do_algebra(['+'], [1000000, 2000000]) == 3000000
    
    def test_large_multiplication(self):
        assert do_algebra(['*'], [1000, 1000]) == 1000000
    
    def test_float_operands(self):
        assert do_algebra(['+'], [1.5, 2.5]) == 4.0
    
    def test_float_division(self):
        result = do_algebra(['/'], [7, 2])
        assert result == 3.5
    
    def test_mixed_int_float(self):
        result = do_algebra(['+'], [1, 2.5])
        assert result == 3.5
    
    def test_subtraction_negative_result(self):
        assert do_algebra(['-'], [2, 5]) == -3
    
    def test_division_by_one(self):
        assert do_algebra(['/'], [42, 1]) == 42
    
    def test_multiplication_by_one(self):
        assert do_algebra(['*'], [42, 1]) == 42
    
    def test_single_operand_no_operators(self):
        assert do_algebra([], [5]) == 5
    
    def test_operators_and_operands_length_match(self):
        assert do_algebra(['+', '-', '*'], [10, 5, 2, 3]) == 9
    
    def test_parentheses_not_needed_left_to_right(self):
        assert do_algebra(['-', '-'], [10, 3, 2]) == 5
    
    def test_division_precedence(self):
        assert do_algebra(['+', '/'], [2, 4, 2]) == 4
    
    def test_multiplication_precedence(self):
        assert do_algebra(['+', '*'], [1, 2, 3]) == 7
    
    def test_very_small_numbers(self):
        result = do_algebra(['+'], [0.1, 0.2])
        assert abs(result - 0.3) < 0.0001
    
    def test_negative_division(self):
        assert do_algebra(['/'], [-10, 2]) == -5
    
    def test_negative_multiplication(self):
        assert do_algebra(['*'], [-3, 4]) == -12
    
    def test_negative_times_negative(self):
        assert do_algebra(['*'], [-3, -4]) == 12