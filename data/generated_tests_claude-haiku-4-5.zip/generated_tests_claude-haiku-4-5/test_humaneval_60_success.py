# Test cases for HumanEval/60
# Generated using Claude API



def sum_to_n(n: int):
    """sum_to_n is a function that sums numbers from 1 to n.
    >>> sum_to_n(30)
    465
    >>> sum_to_n(100)
    5050
    >>> sum_to_n(5)
    15
    >>> sum_to_n(10)
    55
    >>> sum_to_n(1)
    1
    """

    return sum(range(n + 1))


# Generated test cases:
import pytest


def sum_to_n(n: int):
    return sum(range(n + 1))


class TestSumToN:
    def test_zero(self):
        assert sum_to_n(0) == 0

    def test_one(self):
        assert sum_to_n(1) == 1

    def test_two(self):
        assert sum_to_n(2) == 3

    def test_five(self):
        assert sum_to_n(5) == 15

    def test_ten(self):
        assert sum_to_n(10) == 55

    def test_hundred(self):
        assert sum_to_n(100) == 5050

    def test_negative_one(self):
        assert sum_to_n(-1) == 0

    def test_negative_five(self):
        assert sum_to_n(-5) == 0

    def test_large_number(self):
        assert sum_to_n(1000) == 500500

    def test_very_large_number(self):
        assert sum_to_n(10000) == 50005000

    @pytest.mark.parametrize("n,expected", [
        (0, 0),
        (1, 1),
        (2, 3),
        (3, 6),
        (4, 10),
        (5, 15),
        (6, 21),
        (7, 28),
        (8, 36),
        (9, 45),
        (10, 55),
    ])
    def test_parametrized_small_numbers(self, n, expected):
        assert sum_to_n(n) == expected

    @pytest.mark.parametrize("n,expected", [
        (20, 210),
        (50, 1275),
        (100, 5050),
        (200, 20100),
    ])
    def test_parametrized_medium_numbers(self, n, expected):
        assert sum_to_n(n) == expected

    def test_return_type_is_int(self):
        result = sum_to_n(5)
        assert isinstance(result, int)

    def test_result_is_non_negative(self):
        assert sum_to_n(10) >= 0

    def test_monotonic_increasing(self):
        assert sum_to_n(5) < sum_to_n(6)
        assert sum_to_n(10) < sum_to_n(11)

    def test_formula_verification(self):
        n = 15
        expected = n * (n + 1) // 2
        assert sum_to_n(n) == expected

    def test_negative_numbers_return_zero(self):
        for n in [-1, -5, -10, -100]:
            assert sum_to_n(n) == 0

    def test_consecutive_differences(self):
        for n in range(1, 10):
            diff = sum_to_n(n) - sum_to_n(n - 1)
            assert diff == n
