# Test cases for HumanEval/80
# Generated using Claude API


def is_happy(s):
    """You are given a string s.
    Your task is to check if the string is happy or not.
    A string is happy if its length is at least 3 and every 3 consecutive letters are distinct
    For example:
    is_happy(a) => False
    is_happy(aa) => False
    is_happy(abcd) => True
    is_happy(aabb) => False
    is_happy(adb) => True
    is_happy(xyy) => False
    """

    if len(s) < 3:
      return False

    for i in range(len(s) - 2):
      
      if s[i] == s[i+1] or s[i+1] == s[i+2] or s[i] == s[i+2]:
        return False
    return True


# Generated test cases:
import pytest


def is_happy(s):
    if len(s) < 3:
      return False

    for i in range(len(s) - 2):
      
      if s[i] == s[i+1] or s[i+1] == s[i+2] or s[i] == s[i+2]:
        return False
    return True


@pytest.mark.parametrize("input_str,expected", [
    ("a", False),
    ("aa", False),
    ("", False),
    ("ab", False),
    ("abc", True),
    ("abcd", True),
    ("aabb", False),
    ("adb", True),
    ("xyy", False),
    ("abcdef", True),
    ("abcdefg", True),
    ("aaa", False),
    ("aba", False),
    ("abab", False),
    ("abac", False),
    ("abcde", True),
    ("xyzabc", True),
    ("abcdefgh", True),
    ("abcdefghi", True),
    ("abcdefghij", True),
    ("abcdefghijk", True),
    ("abcdefghijkl", True),
    ("abcdefghijklm", True),
    ("abcdefghijklmn", True),
    ("abcdefghijklmno", True),
    ("abcdefghijklmnop", True),
    ("aac", False),
    ("aca", False),
    ("caa", False),
    ("bca", True),
    ("cab", True),
    ("abcdefghijklmnopqrstuvwxyz", True),
])
def test_is_happy(input_str, expected):
    assert is_happy(input_str) == expected


def test_is_happy_single_char():
    assert is_happy("a") == False


def test_is_happy_two_chars():
    assert is_happy("ab") == False


def test_is_happy_empty_string():
    assert is_happy("") == False


def test_is_happy_three_distinct_chars():
    assert is_happy("abc") == True


def test_is_happy_three_chars_with_duplicate_first_second():
    assert is_happy("aab") == False


def test_is_happy_three_chars_with_duplicate_second_third():
    assert is_happy("abb") == False


def test_is_happy_three_chars_with_duplicate_first_third():
    assert is_happy("aba") == False


def test_is_happy_four_chars_all_distinct():
    assert is_happy("abcd") == True


def test_is_happy_four_chars_duplicate_at_start():
    assert is_happy("aabc") == False


def test_is_happy_four_chars_duplicate_at_end():
    assert is_happy("abcc") == False


def test_is_happy_four_chars_duplicate_in_middle():
    assert is_happy("abbc") == False


def test_is_happy_long_string_all_distinct():
    assert is_happy("abcdefghijklmnopqrstuvwxyz") == True


def test_is_happy_numbers_as_string():
    assert is_happy("123") == True


def test_is_happy_numbers_with_duplicate():
    assert is_happy("1123") == False


def test_is_happy_special_characters():
    assert is_happy("!@#") == True


def test_is_happy_special_characters_with_duplicate():
    assert is_happy("!!@#") == False


def test_is_happy_mixed_case():
    assert is_happy("AbC") == True


def test_is_happy_mixed_case_with_duplicate():
    assert is_happy("AaBc") == True


def test_is_happy_spaces():
    assert is_happy("a b") == True


def test_is_happy_spaces_with_duplicate():
    assert is_happy("a ab") == False