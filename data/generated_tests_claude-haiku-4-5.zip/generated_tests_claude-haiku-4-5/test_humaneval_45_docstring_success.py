# Test cases for HumanEval/45
# Generated using Claude API



def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """

    return a * h / 2.0


# Generated test cases:
import pytest


class TestTriangleArea:
    
    @pytest.mark.parametrize("a,h,expected", [
        (5, 3, 7.5),
        (10, 4, 20.0),
        (2, 2, 2.0),
        (1, 1, 0.5),
        (100, 50, 2500.0),
    ])
    def test_triangle_area_normal_cases(self, a, h, expected):
        assert triangle_area(a, h) == expected
    
    @pytest.mark.parametrize("a,h,expected", [
        (0, 5, 0.0),
        (5, 0, 0.0),
        (0, 0, 0.0),
    ])
    def test_triangle_area_zero_values(self, a, h, expected):
        assert triangle_area(a, h) == expected
    
    @pytest.mark.parametrize("a,h,expected", [
        (0.5, 0.5, 0.125),
        (1.5, 2.5, 1.875),
        (0.1, 0.1, 0.005),
    ])
    def test_triangle_area_decimal_values(self, a, h, expected):
        assert abs(triangle_area(a, h) - expected) < 1e-10
    
    @pytest.mark.parametrize("a,h,expected", [
        (-5, 3, -7.5),
        (5, -3, -7.5),
        (-5, -3, 7.5),
    ])
    def test_triangle_area_negative_values(self, a, h, expected):
        assert triangle_area(a, h) == expected
    
    def test_triangle_area_large_numbers(self):
        assert triangle_area(1000000, 2000000) == 1000000000000.0
    
    def test_triangle_area_very_small_numbers(self):
        result = triangle_area(0.0001, 0.0001)
        assert abs(result - 0.000000005) < 1e-12
    
    def test_triangle_area_docstring_example(self):
        assert triangle_area(5, 3) == 7.5
    
    def test_triangle_area_return_type(self):
        result = triangle_area(5, 3)
        assert isinstance(result, float)
    
    @pytest.mark.parametrize("a,h", [
        (float('inf'), 5),
        (5, float('inf')),
        (float('inf'), float('inf')),
    ])
    def test_triangle_area_infinity(self, a, h):
        result = triangle_area(a, h)
        assert result == float('inf') or result == float('-inf')


def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """
    return a * h / 2.0