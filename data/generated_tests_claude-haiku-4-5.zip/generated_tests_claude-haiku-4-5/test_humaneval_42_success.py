# Test cases for HumanEval/42
# Generated using Claude API



def incr_list(l: list):
    """Return list with elements incremented by 1.
    >>> incr_list([1, 2, 3])
    [2, 3, 4]
    >>> incr_list([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [6, 4, 6, 3, 4, 4, 10, 1, 124]
    """

    return [(e + 1) for e in l]


# Generated test cases:
import pytest


def incr_list(l: list):
    return [(e + 1) for e in l]


class TestIncrList:
    def test_empty_list(self):
        assert incr_list([]) == []

    def test_single_element(self):
        assert incr_list([1]) == [2]

    def test_multiple_elements(self):
        assert incr_list([1, 2, 3]) == [2, 3, 4]

    def test_negative_numbers(self):
        assert incr_list([-1, -2, -3]) == [0, -1, -2]

    def test_mixed_positive_negative(self):
        assert incr_list([-1, 0, 1]) == [0, 1, 2]

    def test_zeros(self):
        assert incr_list([0, 0, 0]) == [1, 1, 1]

    def test_large_numbers(self):
        assert incr_list([1000000, 2000000]) == [1000001, 2000001]

    def test_floats(self):
        assert incr_list([1.5, 2.5, 3.5]) == [2.5, 3.5, 4.5]

    def test_mixed_int_float(self):
        assert incr_list([1, 2.5, 3]) == [2, 3.5, 4]

    def test_negative_floats(self):
        assert incr_list([-1.5, -2.5]) == [-0.5, -1.5]

    @pytest.mark.parametrize("input_list,expected", [
        ([1], [2]),
        ([1, 2], [2, 3]),
        ([0], [1]),
        ([-1], [0]),
        ([1, 2, 3, 4, 5], [2, 3, 4, 5, 6]),
    ])
    def test_parametrized_cases(self, input_list, expected):
        assert incr_list(input_list) == expected

    def test_preserves_order(self):
        result = incr_list([5, 1, 3, 2, 4])
        assert result == [6, 2, 4, 3, 5]

    def test_very_long_list(self):
        long_list = list(range(1000))
        result = incr_list(long_list)
        assert len(result) == 1000
        assert result[0] == 1
        assert result[-1] == 1000

    def test_returns_new_list(self):
        original = [1, 2, 3]
        result = incr_list(original)
        assert result is not original
        assert original == [1, 2, 3]

    def test_with_scientific_notation(self):
        assert incr_list([1e2, 2e2]) == [101.0, 201.0]

    def test_single_zero(self):
        assert incr_list([0]) == [1]

    def test_alternating_signs(self):
        assert incr_list([1, -1, 2, -2]) == [2, 0, 3, -1]
