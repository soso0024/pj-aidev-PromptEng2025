# Test cases for HumanEval/102
# Generated using Claude API


def choose_num(x, y):
    """This function takes two positive numbers x and y and returns the
    biggest even integer number that is in the range [x, y] inclusive. If 
    there's no such number, then the function should return -1.

    For example:
    choose_num(12, 15) = 14
    choose_num(13, 12) = -1
    """

    if x > y:
        return -1
    if y % 2 == 0:
        return y
    if x == y:
        return -1
    return y - 1


# Generated test cases:
import pytest


def choose_num(x, y):
    if x > y:
        return -1
    if y % 2 == 0:
        return y
    if x == y:
        return -1
    return y - 1


class TestChooseNum:
    
    @pytest.mark.parametrize("x,y,expected", [
        (12, 15, 14),
        (13, 12, -1),
        (1, 1, -1),
        (2, 2, 2),
        (1, 2, 2),
        (1, 100, 100),
        (50, 100, 100),
        (99, 100, 100),
        (100, 100, 100),
        (1, 3, 2),
        (5, 7, 6),
        (10, 20, 20),
        (11, 20, 20),
        (11, 19, 18),
        (0, 0, -1),
        (0, 1, 0),
        (0, 2, 2),
        (1, 1000000, 1000000),
        (999999, 1000000, 1000000),
        (2, 4, 4),
        (3, 5, 4),
        (100, 101, 100),
        (101, 102, 102),
    ])
    def test_choose_num_various_cases(self, x, y, expected):
        assert choose_num(x, y) == expected
    
    def test_choose_num_basic_example_1(self):
        assert choose_num(12, 15) == 14
    
    def test_choose_num_basic_example_2(self):
        assert choose_num(13, 12) == -1
    
    def test_choose_num_x_greater_than_y(self):
        assert choose_num(20, 10) == -1
    
    def test_choose_num_x_equals_y_even(self):
        assert choose_num(4, 4) == 4
    
    def test_choose_num_x_equals_y_odd(self):
        assert choose_num(5, 5) == -1
    
    def test_choose_num_y_is_even(self):
        assert choose_num(1, 8) == 8
    
    def test_choose_num_y_is_odd(self):
        assert choose_num(1, 9) == 8
    
    def test_choose_num_both_even(self):
        assert choose_num(2, 6) == 6
    
    def test_choose_num_both_odd(self):
        assert choose_num(3, 7) == 6
    
    def test_choose_num_x_even_y_odd(self):
        assert choose_num(2, 5) == 4
    
    def test_choose_num_x_odd_y_even(self):
        assert choose_num(3, 6) == 6
    
    def test_choose_num_consecutive_numbers_even_even(self):
        assert choose_num(2, 3) == 2
    
    def test_choose_num_consecutive_numbers_odd_even(self):
        assert choose_num(1, 2) == 2
    
    def test_choose_num_large_range(self):
        assert choose_num(1, 1000) == 1000
    
    def test_choose_num_large_odd_range(self):
        assert choose_num(1, 999) == 998
    
    def test_choose_num_zero_included(self):
        assert choose_num(0, 5) == 4
    
    def test_choose_num_zero_and_zero(self):
        assert choose_num(0, 0) == -1
    
    def test_choose_num_negative_range_not_applicable(self):
        assert choose_num(10, 5) == -1