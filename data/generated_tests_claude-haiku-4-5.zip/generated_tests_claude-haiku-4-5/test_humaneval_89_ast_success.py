# Test cases for HumanEval/89
# Generated using Claude API


def encrypt(s):
    """Create a function encrypt that takes a string as an argument and
    returns a string encrypted with the alphabet being rotated. 
    The alphabet should be rotated in a manner such that the letters 
    shift down by two multiplied to two places.
    For example:
    encrypt('hi') returns 'lm'
    encrypt('asdfghjkl') returns 'ewhjklnop'
    encrypt('gf') returns 'kj'
    encrypt('et') returns 'ix'
    """

    d = 'abcdefghijklmnopqrstuvwxyz'
    out = ''
    for c in s:
        if c in d:
            out += d[(d.index(c)+2*2) % 26]
        else:
            out += c
    return out


# Generated test cases:
import pytest


def encrypt(s):
    d = 'abcdefghijklmnopqrstuvwxyz'
    out = ''
    for c in s:
        if c in d:
            out += d[(d.index(c)+2*2) % 26]
        else:
            out += c
    return out


@pytest.mark.parametrize("input_str,expected", [
    ("a", "e"),
    ("b", "f"),
    ("z", "d"),
    ("abc", "efg"),
    ("xyz", "bcd"),
    ("hello", "lipps"),
    ("world", "asvph"),
    ("", ""),
    ("abcdefghijklmnopqrstuvwxyz", "efghijklmnopqrstuvwxyzabcd"),
])
def test_encrypt_lowercase(input_str, expected):
    assert encrypt(input_str) == expected


@pytest.mark.parametrize("input_str,expected", [
    ("A", "A"),
    ("B", "B"),
    ("Z", "Z"),
    ("ABC", "ABC"),
    ("HELLO", "HELLO"),
])
def test_encrypt_uppercase(input_str, expected):
    assert encrypt(input_str) == expected


@pytest.mark.parametrize("input_str,expected", [
    ("a1b2c3", "e1f2g3"),
    ("hello123", "lipps123"),
    ("test!", "xiwx!"),
    ("a-b-c", "e-f-g"),
    ("hello world", "lipps asvph"),
])
def test_encrypt_mixed_characters(input_str, expected):
    assert encrypt(input_str) == expected


@pytest.mark.parametrize("input_str,expected", [
    ("123", "123"),
    ("!@#$%", "!@#$%"),
    ("   ", "   "),
    ("\n\t", "\n\t"),
])
def test_encrypt_non_alphabetic(input_str, expected):
    assert encrypt(input_str) == expected


def test_encrypt_single_character():
    assert encrypt("a") == "e"
    assert encrypt("m") == "q"
    assert encrypt("z") == "d"


def test_encrypt_all_lowercase_alphabet():
    result = encrypt("abcdefghijklmnopqrstuvwxyz")
    assert result == "efghijklmnopqrstuvwxyzabcd"
    assert len(result) == 26


def test_encrypt_repeated_characters():
    assert encrypt("aaa") == "eee"
    assert encrypt("zzz") == "ddd"
    assert encrypt("abab") == "efef"


def test_encrypt_empty_string():
    assert encrypt("") == ""


def test_encrypt_shift_amount():
    for i, char in enumerate("abcdefghijklmnopqrstuvwxyz"):
        encrypted_char = encrypt(char)
        expected_index = (i + 4) % 26
        expected_char = "abcdefghijklmnopqrstuvwxyz"[expected_index]
        assert encrypted_char == expected_char


def test_encrypt_preserves_non_alpha():
    assert encrypt("hello, world!") == "lipps, asvph!"
    assert encrypt("test@123") == "xiwx@123"
    assert encrypt("a.b.c") == "e.f.g"


def test_encrypt_special_characters():
    assert encrypt("!@#$%^&*()") == "!@#$%^&*()"
    assert encrypt("a!b@c#") == "e!f@g#"


def test_encrypt_numbers_only():
    assert encrypt("0123456789") == "0123456789"


def test_encrypt_whitespace():
    assert encrypt("a b c") == "e f g"
    assert encrypt("hello\nworld") == "lipps\nasvph"
    assert encrypt("test\tcase") == "xiwx\tgewi"


def test_encrypt_long_string():
    long_string = "abcdefghijklmnopqrstuvwxyz" * 10
    result = encrypt(long_string)
    expected = "efghijklmnopqrstuvwxyzabcd" * 10
    assert result == expected


def test_encrypt_mixed_case_and_special():
    assert encrypt("Hello, World!") == "Hipps, Wsvph!"
    assert encrypt("PyThOn123") == "PcTlOr123"