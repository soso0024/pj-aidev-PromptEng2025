# Test cases for HumanEval/141
# Generated using Claude API


def file_name_check(file_name):
    """Create a function which takes a string representing a file's name, and returns
    'Yes' if the the file's name is valid, and returns 'No' otherwise.
    A file's name is considered to be valid if and only if all the following conditions 
    are met:
    - There should not be more than three digits ('0'-'9') in the file's name.
    - The file's name contains exactly one dot '.'
    - The substring before the dot should not be empty, and it starts with a letter from 
    the latin alphapet ('a'-'z' and 'A'-'Z').
    - The substring after the dot should be one of these: ['txt', 'exe', 'dll']
    Examples:
    file_name_check("example.txt") # => 'Yes'
    file_name_check("1example.dll") # => 'No' (the name should start with a latin alphapet letter)
    """

    suf = ['txt', 'exe', 'dll']
    lst = file_name.split(sep='.')
    if len(lst) != 2:
        return 'No'
    if not lst[1] in suf:
        return 'No'
    if len(lst[0]) == 0:
        return 'No'
    if not lst[0][0].isalpha():
        return 'No'
    t = len([x for x in lst[0] if x.isdigit()])
    if t > 3:
        return 'No'
    return 'Yes'


# Generated test cases:
import pytest


def file_name_check(file_name):
    """Create a function which takes a string representing a file's name, and returns
    'Yes' if the the file's name is valid, and returns 'No' otherwise.
    A file's name is considered to be valid if and only if all the following conditions 
    are met:
    - There should not be more than three digits ('0'-'9') in the file's name.
    - The file's name contains exactly one dot '.'
    - The substring before the dot should not be empty, and it starts with a letter from 
    the latin alphapet ('a'-'z' and 'A'-'Z').
    - The substring after the dot should be one of these: ['txt', 'exe', 'dll']
    Examples:
    file_name_check("example.txt") # => 'Yes'
    file_name_check("1example.dll") # => 'No' (the name should start with a latin alphapet letter)
    """
    suf = ['txt', 'exe', 'dll']
    lst = file_name.split(sep='.')
    if len(lst) != 2:
        return 'No'
    if not lst[1] in suf:
        return 'No'
    if len(lst[0]) == 0:
        return 'No'
    if not lst[0][0].isalpha():
        return 'No'
    t = len([x for x in lst[0] if x.isdigit()])
    if t > 3:
        return 'No'
    return 'Yes'


class TestFileNameCheck:
    
    @pytest.mark.parametrize("file_name,expected", [
        ("example.txt", "Yes"),
        ("test.exe", "Yes"),
        ("file.dll", "Yes"),
        ("a.txt", "Yes"),
        ("Z.exe", "Yes"),
        ("abc123.dll", "Yes"),
        ("test1.txt", "Yes"),
        ("file12.exe", "Yes"),
        ("name123.dll", "Yes"),
    ])
    def test_valid_filenames(self, file_name, expected):
        assert file_name_check(file_name) == expected
    
    @pytest.mark.parametrize("file_name,expected", [
        ("1example.dll", "No"),
        ("9test.txt", "No"),
        ("0file.exe", "No"),
    ])
    def test_starts_with_digit(self, file_name, expected):
        assert file_name_check(file_name) == expected
    
    @pytest.mark.parametrize("file_name,expected", [
        ("example.doc", "No"),
        ("test.pdf", "No"),
        ("file.zip", "No"),
        ("name.txt.bak", "No"),
    ])
    def test_invalid_extension(self, file_name, expected):
        assert file_name_check(file_name) == expected
    
    @pytest.mark.parametrize("file_name,expected", [
        (".txt", "No"),
        (".exe", "No"),
        (".dll", "No"),
    ])
    def test_empty_filename_before_dot(self, file_name, expected):
        assert file_name_check(file_name) == expected
    
    @pytest.mark.parametrize("file_name,expected", [
        ("example", "No"),
        ("test", "No"),
        ("file", "No"),
    ])
    def test_no_dot(self, file_name, expected):
        assert file_name_check(file_name) == expected
    
    @pytest.mark.parametrize("file_name,expected", [
        ("example.txt.exe", "No"),
        ("test.txt.dll", "No"),
        ("file.exe.txt", "No"),
    ])
    def test_multiple_dots(self, file_name, expected):
        assert file_name_check(file_name) == expected
    
    @pytest.mark.parametrize("file_name,expected", [
        ("test1234.txt", "No"),
        ("file12345.exe", "No"),
        ("name123456.dll", "No"),
        ("abc1234.txt", "No"),
    ])
    def test_more_than_three_digits(self, file_name, expected):
        assert file_name_check(file_name) == expected
    
    @pytest.mark.parametrize("file_name,expected", [
        ("_test.txt", "No"),
        ("-file.exe", "No"),
        ("@name.dll", "No"),
        ("#example.txt", "No"),
    ])
    def test_starts_with_special_character(self, file_name, expected):
        assert file_name_check(file_name) == expected
    
    @pytest.mark.parametrize("file_name,expected", [
        ("a1b2c3.txt", "Yes"),
        ("test123.exe", "Yes"),
        ("file1a2b3.dll", "Yes"),
    ])
    def test_exactly_three_digits(self, file_name, expected):
        assert file_name_check(file_name) == expected
    
    @pytest.mark.parametrize("file_name,expected", [
        ("A.txt", "Yes"),
        ("B.exe", "Yes"),
        ("Z.dll", "Yes"),
        ("ABC.txt", "Yes"),
    ])
    def test_uppercase_start(self, file_name, expected):
        assert file_name_check(file_name) == expected
    
    @pytest.mark.parametrize("file_name,expected", [
        ("a.txt", "Yes"),
        ("b.exe", "Yes"),
        ("z.dll", "Yes"),
        ("abc.txt", "Yes"),
    ])
    def test_lowercase_start(self, file_name, expected):
        assert file_name_check(file_name) == expected
    
    @pytest.mark.parametrize("file_name,expected", [
        ("test.TXT", "No"),
        ("file.EXE", "No"),
        ("name.DLL", "No"),
    ])
    def test_uppercase_extension(self, file_name, expected):
        assert file_name_check(file_name) == expected
    
    @pytest.mark.parametrize("file_name,expected", [
        ("test1.txt", "Yes"),
        ("file2.exe", "Yes"),
        ("name3.dll", "Yes"),
    ])
    def test_single_digit(self, file_name, expected):
        assert file_name_check(file_name) == expected
    
    @pytest.mark.parametrize("file_name,expected", [
        ("test12.txt", "Yes"),
        ("file34.exe", "Yes"),
        ("name56.dll", "Yes"),
    ])
    def test_two_digits(self, file_name, expected):
        assert file_name_check(file_name) == expected
    
    @pytest.mark.parametrize("file_name,expected", [
        ("verylongfilenamewithnumbersinit123.txt", "Yes"),
        ("anotherexamplewithnumbers456.exe", "Yes"),
    ])
    def test_long_valid_filenames(self, file_name, expected):
        assert file_name_check(file_name) == expected
