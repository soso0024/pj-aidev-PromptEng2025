# Test cases for HumanEval/91
# Generated using Claude API


def is_bored(S):
    """
    You'll be given a string of words, and your task is to count the number
    of boredoms. A boredom is a sentence that starts with the word "I".
    Sentences are delimited by '.', '?' or '!'.
   
    For example:
    >>> is_bored("Hello world")
    0
    >>> is_bored("The sky is blue. The sun is shining. I love this weather")
    1
    """

    import re
    sentences = re.split(r'[.?!]\s*', S)
    return sum(sentence[0:2] == 'I ' for sentence in sentences)


# Generated test cases:
import pytest
import re


def is_bored(S):
    sentences = re.split(r'[.?!]\s*', S)
    return sum(sentence[0:2] == 'I ' for sentence in sentences)


class TestIsBored:
    def test_single_i_sentence(self):
        assert is_bored("I am bored.") == 1

    def test_multiple_i_sentences(self):
        assert is_bored("I am bored. I am tired.") == 2

    def test_no_i_sentences(self):
        assert is_bored("You are bored. He is tired.") == 0

    def test_mixed_sentences(self):
        assert is_bored("I am bored. You are tired. I am sad.") == 2

    def test_i_not_at_start(self):
        assert is_bored("The I is here. I am bored.") == 1

    def test_lowercase_i(self):
        assert is_bored("i am bored. I am tired.") == 1

    def test_empty_string(self):
        assert is_bored("") == 0

    def test_single_word(self):
        assert is_bored("I") == 0

    def test_question_mark_delimiter(self):
        assert is_bored("I am bored? I am tired?") == 2

    def test_exclamation_mark_delimiter(self):
        assert is_bored("I am bored! I am tired!") == 2

    def test_mixed_delimiters(self):
        assert is_bored("I am bored. I am tired? I am sad!") == 3

    def test_multiple_spaces_after_delimiter(self):
        assert is_bored("I am bored.  I am tired.") == 2

    def test_no_delimiter_at_end(self):
        assert is_bored("I am bored") == 1

    def test_only_i_space(self):
        assert is_bored("I . I ?") == 2

    def test_i_with_different_second_char(self):
        assert is_bored("Ia am bored. I am tired.") == 1

    def test_sentence_starting_with_space(self):
        assert is_bored("I am bored.  You are tired.") == 1

    def test_consecutive_delimiters(self):
        assert is_bored("I am bored.. I am tired.") == 2

    def test_only_delimiters(self):
        assert is_bored("...???!!!") == 0

    def test_i_followed_by_non_space(self):
        assert is_bored("Ibored. I am tired.") == 1

    def test_long_text_multiple_i(self):
        assert is_bored("I love coding. I enjoy Python. I am happy.") == 3

    def test_text_with_newlines_and_delimiters(self):
        assert is_bored("I am bored.\nI am tired.") == 2

    def test_single_character_sentences(self):
        assert is_bored("I. a. I.") == 0

    def test_empty_sentences_from_split(self):
        assert is_bored("I am bored...") == 1

    @pytest.mark.parametrize("text,expected", [
        ("I am bored.", 1),
        ("I am bored. I am tired.", 2),
        ("You are bored.", 0),
        ("I. I.", 0),
        ("", 0),
        ("I am bored? I am tired!", 2),
        ("i am bored. I am tired.", 1),
    ])
    def test_parametrized_cases(self, text, expected):
        assert is_bored(text) == expected

    def test_very_long_string(self):
        text = "I am bored. " * 100
        assert is_bored(text) == 100

    def test_no_spaces_after_i(self):
        assert is_bored("Iambored. I am tired.") == 1

    def test_only_i_space_sentences(self):
        assert is_bored("I . I ? I !") == 3

    def test_mixed_case_i(self):
        assert is_bored("I am bored. i am tired.") == 1

    def test_sentence_with_only_i(self):
        assert is_bored("I. You are here.") == 0

    def test_multiple_consecutive_spaces(self):
        assert is_bored("I  am bored. I am tired.") == 2