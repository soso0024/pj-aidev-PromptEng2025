# Test cases for HumanEval/153
# Generated using Claude API


def Strongest_Extension(class_name, extensions):
    """You will be given the name of a class (a string) and a list of extensions.
    The extensions are to be used to load additional classes to the class. The
    strength of the extension is as follows: Let CAP be the number of the uppercase
    letters in the extension's name, and let SM be the number of lowercase letters 
    in the extension's name, the strength is given by the fraction CAP - SM. 
    You should find the strongest extension and return a string in this 
    format: ClassName.StrongestExtensionName.
    If there are two or more extensions with the same strength, you should
    choose the one that comes first in the list.
    For example, if you are given "Slices" as the class and a list of the
    extensions: ['SErviNGSliCes', 'Cheese', 'StuFfed'] then you should
    return 'Slices.SErviNGSliCes' since 'SErviNGSliCes' is the strongest extension 
    (its strength is -1).
    Example:
    for Strongest_Extension('my_class', ['AA', 'Be', 'CC']) == 'my_class.AA'
    """

    strong = extensions[0]
    my_val = len([x for x in extensions[0] if x.isalpha() and x.isupper()]) - len([x for x in extensions[0] if x.isalpha() and x.islower()])
    for s in extensions:
        val = len([x for x in s if x.isalpha() and x.isupper()]) - len([x for x in s if x.isalpha() and x.islower()])
        if val > my_val:
            strong = s
            my_val = val

    ans = class_name + "." + strong
    return ans



# Generated test cases:
import pytest


def Strongest_Extension(class_name, extensions):
    strong = extensions[0]
    my_val = len([x for x in extensions[0] if x.isalpha() and x.isupper()]) - len([x for x in extensions[0] if x.isalpha() and x.islower()])
    for s in extensions:
        val = len([x for x in s if x.isalpha() and x.isupper()]) - len([x for x in s if x.isalpha() and x.islower()])
        if val > my_val:
            strong = s
            my_val = val

    ans = class_name + "." + strong
    return ans


class TestStrongestExtension:
    
    @pytest.mark.parametrize("class_name,extensions,expected", [
        ("my_class", ["AA", "Be", "CC"], "my_class.AA"),
        ("Slices", ["SErviNGSliCes", "Cheese", "StuFfed"], "Slices.SErviNGSliCes"),
        ("MyClass", ["ABC", "def", "GHI"], "MyClass.ABC"),
        ("Test", ["a", "B", "c"], "Test.B"),
        ("Class", ["UPPER", "lower", "MiXeD"], "Class.UPPER"),
    ])
    def test_basic_cases(self, class_name, extensions, expected):
        assert Strongest_Extension(class_name, extensions) == expected
    
    def test_single_extension(self):
        assert Strongest_Extension("MyClass", ["Extension"]) == "MyClass.Extension"
    
    def test_all_uppercase(self):
        assert Strongest_Extension("Test", ["ABC", "DEF", "GHI"]) == "Test.ABC"
    
    def test_all_lowercase(self):
        assert Strongest_Extension("Test", ["abc", "def", "ghi"]) == "Test.abc"
    
    def test_mixed_case_extensions(self):
        assert Strongest_Extension("Base", ["AaBbCc", "AAaa", "aaBB"]) == "Base.AaBbCc"
    
    def test_same_strength_first_wins(self):
        assert Strongest_Extension("Class", ["AB", "CD", "EF"]) == "Class.AB"
    
    def test_same_strength_with_lowercase(self):
        assert Strongest_Extension("Class", ["ab", "cd", "ef"]) == "Class.ab"
    
    def test_negative_strength(self):
        assert Strongest_Extension("Test", ["aaa", "bbb", "ccc"]) == "Test.aaa"
    
    def test_zero_strength(self):
        assert Strongest_Extension("Test", ["Aa", "Bb", "Cc"]) == "Test.Aa"
    
    def test_with_numbers_and_special_chars(self):
        assert Strongest_Extension("Class", ["A1b2", "C3d4", "E5f6"]) == "Class.A1b2"
    
    def test_empty_string_class_name(self):
        assert Strongest_Extension("", ["ABC", "def"]) == ".ABC"
    
    def test_extension_with_numbers_only(self):
        assert Strongest_Extension("Test", ["123", "456", "789"]) == "Test.123"
    
    def test_extension_with_special_characters(self):
        assert Strongest_Extension("Test", ["A@b", "C#d", "E$f"]) == "Test.A@b"
    
    def test_large_strength_difference(self):
        assert Strongest_Extension("Class", ["AAAAAAA", "a", "Aa"]) == "Class.AAAAAAA"
    
    def test_very_negative_strength(self):
        assert Strongest_Extension("Class", ["aaaaaaa", "A", "aA"]) == "Class.A"
    
    def test_mixed_extensions_order_matters(self):
        result = Strongest_Extension("MyClass", ["Aa", "AA", "aa"])
        assert result == "MyClass.AA"
    
    def test_first_extension_strongest(self):
        assert Strongest_Extension("Test", ["STRONG", "weak", "medium"]) == "Test.STRONG"
    
    def test_last_extension_strongest(self):
        assert Strongest_Extension("Test", ["weak", "medium", "STRONG"]) == "Test.STRONG"
    
    def test_middle_extension_strongest(self):
        assert Strongest_Extension("Test", ["weak", "STRONG", "medium"]) == "Test.STRONG"
    
    @pytest.mark.parametrize("class_name,extensions,expected", [
        ("A", ["B"], "A.B"),
        ("X", ["Y", "Z"], "X.Y"),
        ("Test123", ["Ext1", "Ext2"], "Test123.Ext1"),
    ])
    def test_various_class_names(self, class_name, extensions, expected):
        assert Strongest_Extension(class_name, extensions) == expected
    
    def test_strength_calculation_accuracy(self):
        result = Strongest_Extension("Base", ["AAaa", "AAAa", "aaAA"])
        assert result == "Base.AAAa"
    
    def test_two_extensions_equal_strength(self):
        assert Strongest_Extension("Class", ["AB", "CD"]) == "Class.AB"
    
    def test_three_extensions_first_two_equal(self):
        assert Strongest_Extension("Class", ["AB", "CD", "EFGH"]) == "Class.EFGH"