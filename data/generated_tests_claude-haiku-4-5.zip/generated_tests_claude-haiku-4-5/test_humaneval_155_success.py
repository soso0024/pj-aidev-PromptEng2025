# Test cases for HumanEval/155
# Generated using Claude API


def even_odd_count(num):
    """Given an integer. return a tuple that has the number of even and odd digits respectively.

     Example:
        even_odd_count(-12) ==> (1, 1)
        even_odd_count(123) ==> (1, 2)
    """

    even_count = 0
    odd_count = 0
    for i in str(abs(num)):
        if int(i)%2==0:
            even_count +=1
        else:
            odd_count +=1
    return (even_count, odd_count)


# Generated test cases:
import pytest


def even_odd_count(num):
    even_count = 0
    odd_count = 0
    for i in str(abs(num)):
        if int(i)%2==0:
            even_count +=1
        else:
            odd_count +=1
    return (even_count, odd_count)


class TestEvenOddCount:
    
    @pytest.mark.parametrize("num,expected", [
        (0, (1, 0)),
        (1, (0, 1)),
        (2, (1, 0)),
        (10, (1, 1)),
        (123, (1, 2)),
        (2468, (4, 0)),
        (13579, (0, 5)),
        (1234567890, (5, 5)),
    ])
    def test_positive_numbers(self, num, expected):
        assert even_odd_count(num) == expected
    
    @pytest.mark.parametrize("num,expected", [
        (-1, (0, 1)),
        (-10, (1, 1)),
        (-123, (1, 2)),
        (-2468, (4, 0)),
        (-13579, (0, 5)),
        (-1234567890, (5, 5)),
    ])
    def test_negative_numbers(self, num, expected):
        assert even_odd_count(num) == expected
    
    def test_single_digit_even(self):
        assert even_odd_count(2) == (1, 0)
        assert even_odd_count(4) == (1, 0)
        assert even_odd_count(6) == (1, 0)
        assert even_odd_count(8) == (1, 0)
    
    def test_single_digit_odd(self):
        assert even_odd_count(1) == (0, 1)
        assert even_odd_count(3) == (0, 1)
        assert even_odd_count(5) == (0, 1)
        assert even_odd_count(7) == (0, 1)
        assert even_odd_count(9) == (0, 1)
    
    def test_all_even_digits(self):
        assert even_odd_count(2468) == (4, 0)
        assert even_odd_count(20) == (2, 0)
        assert even_odd_count(2222) == (4, 0)
    
    def test_all_odd_digits(self):
        assert even_odd_count(13579) == (0, 5)
        assert even_odd_count(111) == (0, 3)
        assert even_odd_count(9) == (0, 1)
    
    def test_mixed_digits(self):
        assert even_odd_count(12345) == (2, 3)
        assert even_odd_count(246135) == (3, 3)
        assert even_odd_count(102030) == (4, 2)
    
    def test_zero(self):
        assert even_odd_count(0) == (1, 0)
    
    def test_large_numbers(self):
        assert even_odd_count(123456789) == (4, 5)
        assert even_odd_count(9876543210) == (5, 5)
    
    def test_negative_zero(self):
        assert even_odd_count(-0) == (1, 0)
    
    def test_numbers_with_zeros(self):
        assert even_odd_count(101) == (1, 2)
        assert even_odd_count(1001) == (2, 2)
        assert even_odd_count(10203) == (3, 2)
    
    def test_return_type(self):
        result = even_odd_count(123)
        assert isinstance(result, tuple)
        assert len(result) == 2
        assert isinstance(result[0], int)
        assert isinstance(result[1], int)
    
    def test_symmetry_positive_negative(self):
        pos_result = even_odd_count(12345)
        neg_result = even_odd_count(-12345)
        assert pos_result == neg_result
    
    def test_edge_case_large_negative(self):
        assert even_odd_count(-9876543210) == (5, 5)
    
    def test_repeated_digits(self):
        assert even_odd_count(1111) == (0, 4)
        assert even_odd_count(2222) == (4, 0)
        assert even_odd_count(121212) == (3, 3)