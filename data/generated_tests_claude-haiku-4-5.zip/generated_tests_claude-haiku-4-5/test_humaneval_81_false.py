# Test cases for HumanEval/81
# Generated using Claude API


def numerical_letter_grade(grades):
    """It is the last week of the semester and the teacher has to give the grades
    to students. The teacher has been making her own algorithm for grading.
    The only problem is, she has lost the code she used for grading.
    She has given you a list of GPAs for some students and you have to write 
    a function that can output a list of letter grades using the following table:
             GPA       |    Letter grade
              4.0                A+
            > 3.7                A 
            > 3.3                A- 
            > 3.0                B+
            > 2.7                B 
            > 2.3                B-
            > 2.0                C+
            > 1.7                C
            > 1.3                C-
            > 1.0                D+ 
            > 0.7                D 
            > 0.0                D-
              0.0                E
    

    Example:
    grade_equation([4.0, 3, 1.7, 2, 3.5]) ==> ['A+', 'B', 'C-', 'C', 'A-']
    """


   
    letter_grade = []
    for gpa in grades:
        if gpa == 4.0:
            letter_grade.append("A+")
        elif gpa > 3.7:
            letter_grade.append("A")
        elif gpa > 3.3:
            letter_grade.append("A-")
        elif gpa > 3.0:
            letter_grade.append("B+")
        elif gpa > 2.7:
            letter_grade.append("B")
        elif gpa > 2.3:
            letter_grade.append("B-")
        elif gpa > 2.0:
            letter_grade.append("C+")
        elif gpa > 1.7:
            letter_grade.append("C")
        elif gpa > 1.3:
            letter_grade.append("C-")
        elif gpa > 1.0:
            letter_grade.append("D+")
        elif gpa > 0.7:
            letter_grade.append("D")
        elif gpa > 0.0:
            letter_grade.append("D-")
        else:
            letter_grade.append("E")
    return letter_grade


# Generated test cases:
import pytest


def numerical_letter_grade(grades):
    letter_grade = []
    for gpa in grades:
        if gpa == 4.0:
            letter_grade.append("A+")
        elif gpa > 3.7:
            letter_grade.append("A")
        elif gpa > 3.3:
            letter_grade.append("A-")
        elif gpa > 3.0:
            letter_grade.append("B+")
        elif gpa > 2.7:
            letter_grade.append("B")
        elif gpa > 2.3:
            letter_grade.append("B-")
        elif gpa > 2.0:
            letter_grade.append("C+")
        elif gpa > 1.7:
            letter_grade.append("C")
        elif gpa > 1.3:
            letter_grade.append("C-")
        elif gpa > 1.0:
            letter_grade.append("D+")
        elif gpa > 0.7:
            letter_grade.append("D")
        elif gpa > 0.0:
            letter_grade.append("D-")
        else:
            letter_grade.append("E")
    return letter_grade


class TestNumericalLetterGrade:
    
    def test_perfect_score(self):
        assert numerical_letter_grade([4.0]) == ["A+"]
    
    def test_a_grade(self):
        assert numerical_letter_grade([3.9]) == ["A"]
        assert numerical_letter_grade([3.8]) == ["A"]
    
    def test_a_minus_grade(self):
        assert numerical_letter_grade([3.7]) == ["A-"]
        assert numerical_letter_grade([3.5]) == ["A-"]
    
    def test_b_plus_grade(self):
        assert numerical_letter_grade([3.3]) == ["B+"]
        assert numerical_letter_grade([3.1]) == ["B+"]
    
    def test_b_grade(self):
        assert numerical_letter_grade([3.0]) == ["B"]
        assert numerical_letter_grade([2.8]) == ["B"]
    
    def test_b_minus_grade(self):
        assert numerical_letter_grade([2.7]) == ["B-"]
        assert numerical_letter_grade([2.5]) == ["B-"]
    
    def test_c_plus_grade(self):
        assert numerical_letter_grade([2.3]) == ["C+"]
        assert numerical_letter_grade([2.1]) == ["C+"]
    
    def test_c_grade(self):
        assert numerical_letter_grade([2.0]) == ["C"]
        assert numerical_letter_grade([1.8]) == ["C"]
    
    def test_c_minus_grade(self):
        assert numerical_letter_grade([1.7]) == ["C-"]
        assert numerical_letter_grade([1.5]) == ["C-"]
    
    def test_d_plus_grade(self):
        assert numerical_letter_grade([1.3]) == ["D+"]
        assert numerical_letter_grade([1.1]) == ["D+"]
    
    def test_d_grade(self):
        assert numerical_letter_grade([1.0]) == ["D"]
        assert numerical_letter_grade([0.8]) == ["D"]
    
    def test_d_minus_grade(self):
        assert numerical_letter_grade([0.7]) == ["D-"]
        assert numerical_letter_grade([0.5]) == ["D-"]
    
    def test_e_grade(self):
        assert numerical_letter_grade([0.0]) == ["E"]
        assert numerical_letter_grade([0.1]) == ["D-"]
    
    def test_multiple_grades(self):
        assert numerical_letter_grade([4.0, 3.9, 3.7, 3.0, 2.0, 1.0, 0.0]) == ["A+", "A", "A-", "B", "C", "D", "E"]
    
    def test_empty_list(self):
        assert numerical_letter_grade([]) == []
    
    def test_boundary_values(self):
        assert numerical_letter_grade([4.0, 3.7, 3.3, 3.0, 2.7, 2.3, 2.0, 1.7, 1.3, 1.0, 0.7, 0.0]) == ["A+", "A-", "B+", "B", "B-", "C+", "C", "C-", "D+", "D", "D-", "E"]
    
    def test_just_above_boundaries(self):
        assert numerical_letter_grade([3.71, 3.31, 3.01, 2.71, 2.31, 2.01, 1.71, 1.31, 1.01, 0.71, 0.01]) == ["A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D+", "D", "D-"]
    
    def test_just_below_boundaries(self):
        assert numerical_letter_grade([3.69, 3.29, 2.99, 2.69, 2.29, 1.99, 1.69, 1.29, 0.99, 0.69]) == ["A-", "B+", "B", "B", "B-", "C+", "C", "C-", "D+", "D"]
    
    def test_single_grade_a_plus(self):
        assert numerical_letter_grade([4.0]) == ["A+"]
    
    def test_single_grade_e(self):
        assert numerical_letter_grade([0.0]) == ["E"]
    
    def test_all_same_grade(self):
        assert numerical_letter_grade([3.5, 3.5, 3.5]) == ["A-", "A-", "A-"]
    
    def test_descending_grades(self):
        assert numerical_letter_grade([4.0, 3.0, 2.0, 1.0, 0.0]) == ["A+", "B", "C", "D", "E"]
    
    def test_ascending_grades(self):
        assert numerical_letter_grade([0.0, 1.0, 2.0, 3.0, 4.0]) == ["E", "D", "C", "B", "A+"]