# Test cases for HumanEval/114
# Generated using Claude API


def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """

    max_sum = 0
    s = 0
    for num in nums:
        s += -num
        if (s < 0):
            s = 0
        max_sum = max(s, max_sum)
    if max_sum == 0:
        max_sum = max(-i for i in nums)
    min_sum = -max_sum
    return min_sum


# Generated test cases:
import pytest


class TestMinSubArraySum:
    
    @pytest.mark.parametrize("nums,expected", [
        ([1, 2, 3, 4], -1),
        ([-1, -2, -3, -4], -10),
        ([1, -2, 3, -4], -4),
        ([5], -5),
        ([-5], -5),
        ([0], 0),
        ([0, 0, 0], 0),
        ([1, 2, -5, 4], -5),
        ([-2, 1, -3, 4, -1, 2, 1, -5, 4], -5),
        ([2, 3, 4], -2),
        ([-1, -2, -3], -6),
        ([1, 2, 3, 4, 5], -1),
        ([10, -5, 20, -30, 15], -30),
        ([100], -100),
        ([-100], -100),
        ([1, 1, 1, 1], -1),
        ([-1, -1, -1, -1], -4),
        ([5, -3, 5], -3),
        ([1, 2, 3, -10, 4, 5], -10),
        ([0, -1, 0, -2, 0], -3),
        ([3, -1, 2, -1, 3], -1),
    ])
    def test_min_sub_array_sum(self, nums, expected):
        from test_humaneval_114 import minSubArraySum
        result = minSubArraySum(nums)
        assert result == expected, f"Expected {expected}, got {result} for input {nums}"
    
    def test_single_positive_element(self):
        assert minSubArraySum([42]) == -42
    
    def test_single_negative_element(self):
        assert minSubArraySum([-42]) == -42
    
    def test_all_zeros(self):
        assert minSubArraySum([0, 0, 0, 0]) == 0
    
    def test_mixed_positive_negative(self):
        assert minSubArraySum([1, -2, 3, -4, 5]) == -4
    
    def test_large_positive_numbers(self):
        assert minSubArraySum([1000, 2000, 3000]) == -1000
    
    def test_large_negative_numbers(self):
        assert minSubArraySum([-1000, -2000, -3000]) == -6000
    
    def test_alternating_signs(self):
        assert minSubArraySum([1, -1, 1, -1, 1]) == -1
    
    def test_minimum_at_end(self):
        assert minSubArraySum([1, 2, 3, -10]) == -10
    
    def test_minimum_at_start(self):
        assert minSubArraySum([-10, 1, 2, 3]) == -10
    
    def test_minimum_in_middle(self):
        assert minSubArraySum([1, 2, -10, 3, 4]) == -10
    
    def test_two_elements_positive(self):
        assert minSubArraySum([5, 10]) == -5
    
    def test_two_elements_negative(self):
        assert minSubArraySum([-5, -10]) == -15
    
    def test_two_elements_mixed(self):
        assert minSubArraySum([5, -10]) == -10
    
    def test_long_array_with_one_negative(self):
        assert minSubArraySum([1, 1, 1, 1, -100, 1, 1, 1]) == -100
    
    def test_array_with_zeros_and_negatives(self):
        assert minSubArraySum([0, 0, -5, 0, 0]) == -5