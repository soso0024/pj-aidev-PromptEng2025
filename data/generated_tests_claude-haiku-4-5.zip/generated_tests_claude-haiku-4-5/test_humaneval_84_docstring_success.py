# Test cases for HumanEval/84
# Generated using Claude API


def solve(N):
    """Given a positive integer N, return the total sum of its digits in binary.
    
    Example
        For N = 1000, the sum of digits will be 1 the output should be "1".
        For N = 150, the sum of digits will be 6 the output should be "110".
        For N = 147, the sum of digits will be 12 the output should be "1100".
    
    Variables:
        @N integer
             Constraints: 0 ≤ N ≤ 10000.
    Output:
         a string of binary number
    """

    return bin(sum(int(i) for i in str(N)))[2:]


# Generated test cases:
import pytest


class TestSolve:
    
    @pytest.mark.parametrize("N,expected", [
        (1000, "1"),
        (150, "110"),
        (147, "1100"),
        (0, "0"),
        (1, "1"),
        (9, "1001"),
        (10, "1"),
        (99, "10010"),
        (123, "110"),
        (456, "1111"),
        (789, "11000"),
        (1111, "100"),
        (9999, "100100"),
        (5, "101"),
        (15, "110"),
        (100, "1"),
        (101, "10"),
        (999, "11011"),
        (2468, "10100"),
        (1357, "10000"),
    ])
    def test_solve_various_inputs(self, N, expected):
        from test_humaneval_84_docstring import solve
        assert solve(N) == expected
    
    def test_solve_zero(self):
        assert solve(0) == "0"
    
    def test_solve_single_digit(self):
        assert solve(1) == "1"
        assert solve(2) == "10"
        assert solve(3) == "11"
        assert solve(4) == "100"
        assert solve(5) == "101"
        assert solve(6) == "110"
        assert solve(7) == "111"
        assert solve(8) == "1000"
        assert solve(9) == "1001"
    
    def test_solve_two_digits(self):
        assert solve(10) == "1"
        assert solve(11) == "10"
        assert solve(12) == "11"
        assert solve(18) == "1001"
        assert solve(99) == "10010"
    
    def test_solve_three_digits(self):
        assert solve(100) == "1"
        assert solve(111) == "11"
        assert solve(123) == "110"
        assert solve(999) == "11011"
    
    def test_solve_four_digits(self):
        assert solve(1000) == "1"
        assert solve(1111) == "100"
        assert solve(5555) == "10100"
        assert solve(9999) == "100100"
    
    def test_solve_max_constraint(self):
        assert solve(10000) == "1"
    
    def test_solve_returns_string(self):
        result = solve(150)
        assert isinstance(result, str)
    
    def test_solve_binary_format(self):
        result = solve(147)
        assert all(c in '01' for c in result)
        assert result[0] == '1'
    
    def test_solve_digit_sum_correctness(self):
        N = 456
        digit_sum = sum(int(d) for d in str(N))
        expected_binary = bin(digit_sum)[2:]
        assert solve(N) == expected_binary
    
    def test_solve_all_zeros_digits(self):
        assert solve(1000) == "1"
        assert solve(2000) == "10"
        assert solve(3000) == "11"
    
    def test_solve_mixed_digits(self):
        assert solve(102) == "11"
        assert solve(201) == "11"
        assert solve(1020) == "11"