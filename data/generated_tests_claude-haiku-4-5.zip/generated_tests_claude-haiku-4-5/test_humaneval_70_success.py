# Test cases for HumanEval/70
# Generated using Claude API


def strange_sort_list(lst):
    '''
    Given list of integers, return list in strange order.
    Strange sorting, is when you start with the minimum value,
    then maximum of the remaining integers, then minimum and so on.

    Examples:
    strange_sort_list([1, 2, 3, 4]) == [1, 4, 2, 3]
    strange_sort_list([5, 5, 5, 5]) == [5, 5, 5, 5]
    strange_sort_list([]) == []
    '''

    res, switch = [], True
    while lst:
        res.append(min(lst) if switch else max(lst))
        lst.remove(res[-1])
        switch = not switch
    return res


# Generated test cases:
import pytest


def strange_sort_list(lst):
    res, switch = [], True
    while lst:
        res.append(min(lst) if switch else max(lst))
        lst.remove(res[-1])
        switch = not switch
    return res


class TestStrangeSortList:
    def test_empty_list(self):
        assert strange_sort_list([]) == []

    def test_single_element(self):
        assert strange_sort_list([5]) == [5]

    def test_two_elements(self):
        assert strange_sort_list([5, 3]) == [3, 5]

    def test_two_elements_reversed(self):
        assert strange_sort_list([3, 5]) == [3, 5]

    def test_three_elements(self):
        assert strange_sort_list([5, 3, 7]) == [3, 7, 5]

    def test_four_elements(self):
        assert strange_sort_list([5, 3, 7, 1]) == [1, 7, 3, 5]

    def test_negative_numbers(self):
        assert strange_sort_list([-5, -3, -7, -1]) == [-7, -1, -5, -3]

    def test_mixed_positive_negative(self):
        assert strange_sort_list([-5, 3, -7, 1]) == [-7, 3, -5, 1]

    def test_duplicates(self):
        assert strange_sort_list([5, 5, 3, 3]) == [3, 5, 3, 5]

    def test_all_same_elements(self):
        assert strange_sort_list([5, 5, 5, 5]) == [5, 5, 5, 5]

    def test_large_list(self):
        input_list = [9, 2, 8, 3, 7, 4, 6, 5, 1]
        result = strange_sort_list(input_list)
        assert result == [1, 9, 2, 8, 3, 7, 4, 6, 5]

    def test_already_sorted(self):
        assert strange_sort_list([1, 2, 3, 4, 5]) == [1, 5, 2, 4, 3]

    def test_reverse_sorted(self):
        assert strange_sort_list([5, 4, 3, 2, 1]) == [1, 5, 2, 4, 3]

    def test_floats(self):
        assert strange_sort_list([5.5, 3.2, 7.1, 1.9]) == [1.9, 7.1, 3.2, 5.5]

    def test_zero_in_list(self):
        assert strange_sort_list([5, 0, 3, -2]) == [-2, 5, 0, 3]

    def test_large_numbers(self):
        assert strange_sort_list([1000000, 1, 999999]) == [1, 1000000, 999999]

    @pytest.mark.parametrize("input_list,expected", [
        ([1], [1]),
        ([2, 1], [1, 2]),
        ([1, 2, 3], [1, 3, 2]),
        ([3, 2, 1], [1, 3, 2]),
        ([5, 5], [5, 5]),
        ([-1, -2, -3], [-3, -1, -2]),
    ])
    def test_parametrized_cases(self, input_list, expected):
        assert strange_sort_list(input_list) == expected

    def test_preserves_original_behavior_min_max_alternation(self):
        lst = [10, 20, 30, 40, 50]
        result = strange_sort_list(lst)
        assert result[0] == 10
        assert result[1] == 50
        assert result[2] == 20
        assert result[3] == 40
        assert result[4] == 30

    def test_with_string_numbers_as_integers(self):
        assert strange_sort_list([5, 3, 7, 1, 9]) == [1, 9, 3, 7, 5]

    def test_odd_length_list(self):
        result = strange_sort_list([4, 2, 6, 1, 5])
        assert len(result) == 5
        assert result[0] == min([4, 2, 6, 1, 5])

    def test_even_length_list(self):
        result = strange_sort_list([4, 2, 6, 1])
        assert len(result) == 4
        assert result[0] == min([4, 2, 6, 1])
        assert result[1] == max([4, 2, 6, 1])
