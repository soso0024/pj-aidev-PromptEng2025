# Test cases for HumanEval/158
# Generated using Claude API


def find_max(words):
    """Write a function that accepts a list of strings.
    The list contains different words. Return the word with maximum number
    of unique characters. If multiple strings have maximum number of unique
    characters, return the one which comes first in lexicographical order.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb" ,"cc"]) == ""aaaaaaa"
    """

    return sorted(words, key = lambda x: (-len(set(x)), x))[0]


# Generated test cases:
import pytest


def find_max(words):
    return sorted(words, key = lambda x: (-len(set(x)), x))[0]


@pytest.mark.parametrize("input_words,expected", [
    (["name", "of", "string"], "string"),
    (["name", "enam", "game"], "enam"),
    (["aaaaaaa", "bb", "cc"], "aaaaaaa"),
])
def test_find_max_basic(input_words, expected):
    assert find_max(input_words) == expected


def test_find_max_single_word():
    assert find_max(["hello"]) == "hello"


def test_find_max_all_same_unique_count():
    result = find_max(["ab", "cd", "ef"])
    assert result == "ab"


def test_find_max_lexicographical_order():
    assert find_max(["xyz", "abc"]) == "abc"


def test_find_max_duplicate_characters():
    assert find_max(["aaa", "bbb", "abc"]) == "abc"


def test_find_max_mixed_lengths():
    assert find_max(["a", "ab", "abc", "abcd"]) == "abcd"


def test_find_max_empty_strings_in_list():
    result = find_max(["", "a", "ab"])
    assert result == "ab"


def test_find_max_single_empty_string():
    assert find_max([""]) == ""


def test_find_max_multiple_words_same_unique_chars():
    result = find_max(["abc", "bca", "cab"])
    assert result == "abc"


def test_find_max_case_sensitive():
    result = find_max(["Aa", "aa"])
    assert result == "Aa"


def test_find_max_special_characters():
    result = find_max(["!@#", "abc", "!@#$"])
    assert result == "!@#$"


def test_find_max_numbers_as_strings():
    result = find_max(["123", "1234", "12"])
    assert result == "1234"


def test_find_max_repeated_unique_chars():
    assert find_max(["aabbcc", "abcdef"]) == "abcdef"


def test_find_max_two_words_same_unique_count():
    result = find_max(["abc", "def"])
    assert result == "abc"


def test_find_max_long_word_with_repeats():
    result = find_max(["aaabbbccc", "abcdefgh"])
    assert result == "abcdefgh"


def test_find_max_unicode_characters():
    result = find_max(["café", "naïve", "résumé"])
    assert result == "naïve"


def test_find_max_whitespace():
    result = find_max(["a b", "ab", "a  b"])
    assert result == "a  b"


def test_find_max_all_same_word():
    assert find_max(["test", "test", "test"]) == "test"


def test_find_max_lexicographical_with_same_unique():
    result = find_max(["xyz", "abc", "def"])
    assert result == "abc"


def test_find_max_single_char_words():
    result = find_max(["a", "b", "c"])
    assert result == "a"


def test_find_max_complex_scenario():
    result = find_max(["programming", "python", "code"])
    assert result == "programming"