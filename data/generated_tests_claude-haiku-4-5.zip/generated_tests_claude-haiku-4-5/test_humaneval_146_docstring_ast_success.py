# Test cases for HumanEval/146
# Generated using Claude API


def specialFilter(nums):
    """Write a function that takes an array of numbers as input and returns 
    the number of elements in the array that are greater than 10 and both 
    first and last digits of a number are odd (1, 3, 5, 7, 9).
    For example:
    specialFilter([15, -73, 14, -15]) => 1 
    specialFilter([33, -2, -3, 45, 21, 109]) => 2
    """

    
    count = 0
    for num in nums:
        if num > 10:
            odd_digits = (1, 3, 5, 7, 9)
            number_as_string = str(num)
            if int(number_as_string[0]) in odd_digits and int(number_as_string[-1]) in odd_digits:
                count += 1
        
    return count 


# Generated test cases:
import pytest


class TestSpecialFilter:
    
    def test_example_1(self):
        from test_humaneval_146_docstring_ast import specialFilter
        assert specialFilter([15, -73, 14, -15]) == 1
    
    def test_example_2(self):
        assert specialFilter([33, -2, -3, 45, 21, 109]) == 2
    
    def test_empty_list(self):
        assert specialFilter([]) == 0
    
    def test_all_numbers_less_than_or_equal_10(self):
        assert specialFilter([1, 2, 3, 4, 5, 10]) == 0
    
    def test_all_numbers_greater_than_10_with_odd_first_and_last(self):
        assert specialFilter([11, 13, 15, 17, 19, 31, 33, 35, 37, 39]) == 10
    
    def test_numbers_greater_than_10_with_even_first_digit(self):
        assert specialFilter([21, 23, 25, 27, 29]) == 0
    
    def test_numbers_greater_than_10_with_even_last_digit(self):
        assert specialFilter([11, 12, 13, 14, 15, 16]) == 3
    
    def test_numbers_greater_than_10_with_both_even_digits(self):
        assert specialFilter([20, 22, 24, 26, 28]) == 0
    
    def test_single_element_valid(self):
        assert specialFilter([15]) == 1
    
    def test_single_element_invalid_less_than_10(self):
        assert specialFilter([5]) == 0
    
    def test_single_element_invalid_even_digits(self):
        assert specialFilter([22]) == 0
    
    def test_negative_numbers_only(self):
        assert specialFilter([-15, -73, -99, -11]) == 0
    
    def test_mixed_positive_negative(self):
        assert specialFilter([15, -15, 35, -35, 55, -55]) == 3
    
    def test_large_numbers(self):
        assert specialFilter([111, 135, 159, 313, 999]) == 5
    
    def test_large_numbers_with_even_digits(self):
        assert specialFilter([111, 112, 135, 136, 159, 160]) == 3
    
    def test_two_digit_numbers_odd_first_odd_last(self):
        assert specialFilter([11, 13, 15, 17, 19, 31, 33, 35, 37, 39, 51, 53, 55, 57, 59, 71, 73, 75, 77, 79, 91, 93, 95, 97, 99]) == 25
    
    def test_two_digit_numbers_odd_first_even_last(self):
        assert specialFilter([10, 12, 14, 16, 18, 30, 32, 34, 36, 38]) == 0
    
    def test_two_digit_numbers_even_first_odd_last(self):
        assert specialFilter([21, 23, 25, 27, 29, 41, 43, 45, 47, 49]) == 0
    
    def test_boundary_value_10(self):
        assert specialFilter([10]) == 0
    
    def test_boundary_value_11(self):
        assert specialFilter([11]) == 1
    
    def test_three_digit_numbers(self):
        assert specialFilter([111, 113, 115, 117, 119, 131, 151, 171, 191]) == 9
    
    def test_three_digit_numbers_with_even_middle(self):
        assert specialFilter([121, 141, 161, 181]) == 4
    
    def test_three_digit_numbers_even_first(self):
        assert specialFilter([211, 213, 215, 217, 219]) == 0
    
    def test_three_digit_numbers_even_last(self):
        assert specialFilter([111, 112, 113, 114, 115]) == 3
    
    def test_mixed_valid_invalid(self):
        assert specialFilter([15, 20, 35, 40, 55, 60, 75, 80, 95, 100]) == 5
    
    def test_all_odd_digits_numbers(self):
        assert specialFilter([11, 13, 15, 17, 19, 31, 33, 35, 37, 39, 51, 53, 55, 57, 59, 71, 73, 75, 77, 79, 91, 93, 95, 97, 99, 111, 113, 115, 117, 119]) == 30
    
    def test_zero_in_list(self):
        assert specialFilter([0, 15, 35]) == 2
    
    def test_very_large_number(self):
        assert specialFilter([123456789]) == 1
    
    def test_very_large_number_odd_first_last(self):
        assert specialFilter([123456789, 111111111, 999999999]) == 3


@pytest.mark.parametrize("nums,expected", [
    ([15, -73, 14, -15], 1),
    ([33, -2, -3, 45, 21, 109], 2),
    ([], 0),
    ([11], 1),
    ([10], 0),
    ([15, 35, 55, 75, 95], 5),
    ([20, 40, 60, 80], 0),
    ([-15, -35, -55], 0),
    ([111, 135, 159], 3),
    ([121, 141, 161], 3),
])
def test_special_filter_parametrized(nums, expected):
    assert specialFilter(nums) == expected