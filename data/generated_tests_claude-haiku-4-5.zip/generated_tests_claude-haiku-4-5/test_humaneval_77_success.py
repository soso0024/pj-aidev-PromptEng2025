# Test cases for HumanEval/77
# Generated using Claude API


def iscube(a):
    '''
    Write a function that takes an integer a and returns True 
    if this ingeger is a cube of some integer number.
    Note: you may assume the input is always valid.
    Examples:
    iscube(1) ==> True
    iscube(2) ==> False
    iscube(-1) ==> True
    iscube(64) ==> True
    iscube(0) ==> True
    iscube(180) ==> False
    '''

    a = abs(a)
    return int(round(a ** (1. / 3))) ** 3 == a


# Generated test cases:
import pytest


def iscube(a):
    a = abs(a)
    return int(round(a ** (1. / 3))) ** 3 == a


class TestIscube:
    
    @pytest.mark.parametrize("input_val,expected", [
        (0, True),
        (1, True),
        (8, True),
        (27, True),
        (64, True),
        (125, True),
        (216, True),
        (343, True),
        (512, True),
        (729, True),
        (1000, True),
        (-1, True),
        (-8, True),
        (-27, True),
        (-64, True),
        (-125, True),
        (-216, True),
        (-1000, True),
    ])
    def test_perfect_cubes(self, input_val, expected):
        assert iscube(input_val) == expected
    
    @pytest.mark.parametrize("input_val,expected", [
        (2, False),
        (3, False),
        (4, False),
        (5, False),
        (6, False),
        (7, False),
        (9, False),
        (10, False),
        (26, False),
        (28, False),
        (63, False),
        (65, False),
        (100, False),
        (999, False),
        (1001, False),
        (-2, False),
        (-3, False),
        (-7, False),
        (-26, False),
        (-100, False),
    ])
    def test_non_perfect_cubes(self, input_val, expected):
        assert iscube(input_val) == expected
    
    def test_zero(self):
        assert iscube(0) == True
    
    def test_one(self):
        assert iscube(1) == True
    
    def test_negative_one(self):
        assert iscube(-1) == True
    
    def test_large_perfect_cube(self):
        assert iscube(1000000) == True
    
    def test_large_negative_perfect_cube(self):
        assert iscube(-1000000) == True
    
    def test_large_non_perfect_cube(self):
        assert iscube(1000001) == False
    
    def test_large_negative_non_perfect_cube(self):
        assert iscube(-1000001) == False
    
    def test_float_perfect_cube(self):
        assert iscube(8.0) == True
    
    def test_float_non_perfect_cube(self):
        assert iscube(8.5) == False
    
    def test_negative_float_perfect_cube(self):
        assert iscube(-27.0) == True
    
    def test_negative_float_non_perfect_cube(self):
        assert iscube(-27.5) == False
    
    def test_very_small_positive(self):
        assert iscube(0.001) == False
    
    def test_very_small_negative(self):
        assert iscube(-0.001) == False
    
    @pytest.mark.parametrize("input_val", [
        2**3,
        3**3,
        4**3,
        5**3,
        10**3,
        20**3,
        100**3,
    ])
    def test_cubes_of_integers(self, input_val):
        assert iscube(input_val) == True
    
    @pytest.mark.parametrize("input_val", [
        -(2**3),
        -(3**3),
        -(4**3),
        -(5**3),
        -(10**3),
        -(20**3),
        -(100**3),
    ])
    def test_negative_cubes_of_integers(self, input_val):
        assert iscube(input_val) == True
