# Test cases for HumanEval/108
# Generated using Claude API


def count_nums(arr):
    """
    Write a function count_nums which takes an array of integers and returns
    the number of elements which has a sum of digits > 0.
    If a number is negative, then its first signed digit will be negative:
    e.g. -123 has signed digits -1, 2, and 3.
    >>> count_nums([]) == 0
    >>> count_nums([-1, 11, -11]) == 1
    >>> count_nums([1, 1, 2]) == 3
    """

    def digits_sum(n):
        neg = 1
        if n < 0: n, neg = -1 * n, -1 
        n = [int(i) for i in str(n)]
        n[0] = n[0] * neg
        return sum(n)
    return len(list(filter(lambda x: x > 0, [digits_sum(i) for i in arr])))


# Generated test cases:
import pytest


def count_nums(arr):
    def digits_sum(n):
        neg = 1
        if n < 0: n, neg = -1 * n, -1 
        n = [int(i) for i in str(n)]
        n[0] = n[0] * neg
        return sum(n)
    return len(list(filter(lambda x: x > 0, [digits_sum(i) for i in arr])))


class TestCountNums:
    
    def test_empty_array(self):
        assert count_nums([]) == 0
    
    def test_single_positive_number(self):
        assert count_nums([1]) == 1
    
    def test_single_negative_number(self):
        assert count_nums([-1]) == 0
    
    def test_single_zero(self):
        assert count_nums([0]) == 0
    
    def test_all_positive_numbers(self):
        assert count_nums([1, 2, 3]) == 3
    
    def test_all_negative_numbers(self):
        assert count_nums([-1, -2, -3]) == 0
    
    def test_mixed_positive_negative(self):
        assert count_nums([-1, 11, -11]) == 1
    
    def test_mixed_with_zero(self):
        assert count_nums([0, 1, -1]) == 1
    
    def test_large_positive_number(self):
        assert count_nums([123]) == 1
    
    def test_large_negative_number(self):
        assert count_nums([-123]) == 1
    
    def test_negative_with_positive_digit_sum(self):
        assert count_nums([-1, 2, 3]) == 2
    
    def test_negative_number_with_large_digits(self):
        assert count_nums([-199]) == 1
    
    def test_negative_number_with_small_digits(self):
        assert count_nums([-100]) == 0
    
    def test_multiple_zeros(self):
        assert count_nums([0, 0, 0]) == 0
    
    def test_positive_single_digit(self):
        assert count_nums([5]) == 1
    
    def test_negative_single_digit(self):
        assert count_nums([-5]) == 0
    
    def test_mixed_array_complex(self):
        assert count_nums([1, 1, 2]) == 3
    
    def test_negative_with_zero_sum(self):
        assert count_nums([-10]) == 0
    
    def test_positive_with_zero_sum(self):
        assert count_nums([10]) == 1
    
    def test_large_array(self):
        assert count_nums([1, 2, 3, 4, 5, -1, -2, -3]) == 5
    
    def test_negative_number_sum_positive(self):
        assert count_nums([-19]) == 1
    
    def test_negative_number_sum_positive_case(self):
        assert count_nums([-91]) == 0
    
    def test_all_same_positive(self):
        assert count_nums([5, 5, 5]) == 3
    
    def test_all_same_negative(self):
        assert count_nums([-5, -5, -5]) == 0
    
    def test_negative_with_many_digits(self):
        assert count_nums([-9999]) == 1
    
    def test_positive_with_many_digits(self):
        assert count_nums([9999]) == 1
    
    def test_negative_leading_digit_dominates(self):
        assert count_nums([-9111]) == 0
    
    def test_negative_small_leading_digit(self):
        assert count_nums([-1999]) == 1
    
    @pytest.mark.parametrize("arr,expected", [
        ([], 0),
        ([1], 1),
        ([-1], 0),
        ([0], 0),
        ([1, 2, 3], 3),
        ([-1, -2, -3], 0),
        ([-1, 11, -11], 1),
        ([1, 1, 2], 3),
        ([0, 1, -1], 1),
        ([-10], 0),
        ([10], 1),
        ([-91], 0),
        ([-19], 1),
    ])
    def test_parametrized(self, arr, expected):
        assert count_nums(arr) == expected