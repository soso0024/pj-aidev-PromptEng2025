# Test cases for HumanEval/22
# Generated using Claude API

from typing import List, Any


def filter_integers(values: List[Any]) -> List[int]:
    """ Filter given list of any python values only for integers
    >>> filter_integers(['a', 3.14, 5])
    [5]
    >>> filter_integers([1, 2, 3, 'abc', {}, []])
    [1, 2, 3]
    """

    return [x for x in values if isinstance(x, int)]


# Generated test cases:
import pytest
from typing import List, Any


def filter_integers(values: List[Any]) -> List[int]:
    return [x for x in values if isinstance(x, int)]


class TestFilterIntegers:
    def test_empty_list(self):
        assert filter_integers([]) == []

    def test_only_integers(self):
        assert filter_integers([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

    def test_only_strings(self):
        assert filter_integers(["a", "b", "c"]) == []

    def test_only_floats(self):
        assert filter_integers([1.5, 2.7, 3.14]) == []

    def test_mixed_types(self):
        assert filter_integers([1, "hello", 2.5, 3, None, 4]) == [1, 3, 4]

    def test_negative_integers(self):
        assert filter_integers([-1, -2, -3]) == [-1, -2, -3]

    def test_zero(self):
        assert filter_integers([0, 1, 2]) == [0, 1, 2]

    def test_mixed_positive_negative(self):
        assert filter_integers([-5, 0, 5, -10, 10]) == [-5, 0, 5, -10, 10]

    def test_with_booleans(self):
        assert filter_integers([True, False, 1, 2]) == [True, False, 1, 2]

    def test_with_none(self):
        assert filter_integers([None, 1, None, 2, None]) == [1, 2]

    def test_with_lists(self):
        assert filter_integers([[1, 2], 3, [4, 5], 6]) == [3, 6]

    def test_with_dicts(self):
        assert filter_integers([{"a": 1}, 5, {"b": 2}, 10]) == [5, 10]

    def test_with_tuples(self):
        assert filter_integers([(1, 2), 3, (4, 5), 6]) == [3, 6]

    def test_with_sets(self):
        assert filter_integers([{1, 2}, 3, {4, 5}, 6]) == [3, 6]

    def test_large_integers(self):
        assert filter_integers([10**10, 10**20, 1]) == [10**10, 10**20, 1]

    def test_very_small_integers(self):
        assert filter_integers([-10**10, -10**20, -1]) == [-10**10, -10**20, -1]

    def test_single_integer(self):
        assert filter_integers([42]) == [42]

    def test_single_non_integer(self):
        assert filter_integers(["string"]) == []

    def test_preserves_order(self):
        assert filter_integers([5, 1, 3, 2, 4]) == [5, 1, 3, 2, 4]

    def test_duplicate_integers(self):
        assert filter_integers([1, 1, 2, 2, 3, 3]) == [1, 1, 2, 2, 3, 3]

    def test_with_complex_numbers(self):
        assert filter_integers([1+2j, 3, 4+5j, 6]) == [3, 6]

    def test_with_bytes(self):
        assert filter_integers([b"hello", 1, b"world", 2]) == [1, 2]

    @pytest.mark.parametrize("input_list,expected", [
        ([1, 2, 3], [1, 2, 3]),
        ([], []),
        ([1], [1]),
        (["a", "b"], []),
        ([1, "a", 2, "b", 3], [1, 2, 3]),
        ([0], [0]),
        ([-1, -2, -3], [-1, -2, -3]),
    ])
    def test_parametrized_cases(self, input_list, expected):
        assert filter_integers(input_list) == expected

    def test_returns_list_type(self):
        result = filter_integers([1, 2, 3])
        assert isinstance(result, list)

    def test_returns_new_list(self):
        original = [1, 2, 3]
        result = filter_integers(original)
        assert result is not original

    def test_with_float_that_looks_like_int(self):
        assert filter_integers([1.0, 2.0, 3]) == [3]

    def test_with_string_numbers(self):
        assert filter_integers(["1", "2", "3", 4]) == [4]
