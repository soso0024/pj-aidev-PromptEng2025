# Test cases for HumanEval/40
# Generated using Claude API



def triples_sum_to_zero(l: list):
    """
    triples_sum_to_zero takes a list of integers as an input.
    it returns True if there are three distinct elements in the list that
    sum to zero, and False otherwise.

    >>> triples_sum_to_zero([1, 3, 5, 0])
    False
    >>> triples_sum_to_zero([1, 3, -2, 1])
    True
    >>> triples_sum_to_zero([1, 2, 3, 7])
    False
    >>> triples_sum_to_zero([2, 4, -5, 3, 9, 7])
    True
    >>> triples_sum_to_zero([1])
    False
    """

    for i in range(len(l)):
        for j in range(i + 1, len(l)):
            for k in range(j + 1, len(l)):
                if l[i] + l[j] + l[k] == 0:
                    return True
    return False


# Generated test cases:
import pytest


def triples_sum_to_zero(l: list):
    for i in range(len(l)):
        for j in range(i + 1, len(l)):
            for k in range(j + 1, len(l)):
                if l[i] + l[j] + l[k] == 0:
                    return True
    return False


class TestTriplessSumToZero:
    
    @pytest.mark.parametrize("input_list,expected", [
        ([1, 3, 5, 0], False),
        ([1, 3, -2, 1], True),
        ([1, 2, 3, 7], False),
        ([2, 4, -5, 3, 9, 7], True),
        ([1], False),
    ])
    def test_docstring_examples(self, input_list, expected):
        assert triples_sum_to_zero(input_list) == expected
    
    def test_empty_list(self):
        assert triples_sum_to_zero([]) == False
    
    def test_single_element(self):
        assert triples_sum_to_zero([0]) == False
    
    def test_two_elements(self):
        assert triples_sum_to_zero([1, -1]) == False
    
    def test_three_elements_sum_to_zero(self):
        assert triples_sum_to_zero([1, 2, -3]) == True
    
    def test_three_elements_no_sum_to_zero(self):
        assert triples_sum_to_zero([1, 2, 3]) == False
    
    def test_all_zeros(self):
        assert triples_sum_to_zero([0, 0, 0]) == True
    
    def test_negative_numbers(self):
        assert triples_sum_to_zero([-1, -2, 3]) == True
    
    def test_all_negative(self):
        assert triples_sum_to_zero([-1, -2, -3]) == False
    
    def test_large_positive_and_negative(self):
        assert triples_sum_to_zero([100, -50, -50]) == True
    
    def test_multiple_valid_triples(self):
        assert triples_sum_to_zero([1, -1, 0, 2, -2]) == True
    
    def test_no_valid_triple_with_many_elements(self):
        assert triples_sum_to_zero([1, 2, 3, 4, 5, 6]) == False
    
    def test_duplicate_elements(self):
        assert triples_sum_to_zero([1, 1, 1, -2, -2]) == True
    
    def test_zero_with_positive_negative(self):
        assert triples_sum_to_zero([0, 5, -5]) == True
    
    def test_mixed_values(self):
        assert triples_sum_to_zero([-5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5]) == True
    
    def test_four_elements_with_valid_triple(self):
        assert triples_sum_to_zero([1, 2, -3, 4]) == True
    
    def test_four_elements_no_valid_triple(self):
        assert triples_sum_to_zero([1, 2, 3, 4]) == False
    
    def test_distinct_elements_requirement(self):
        assert triples_sum_to_zero([0, 0, 0, 1]) == True
    
    def test_large_numbers(self):
        assert triples_sum_to_zero([1000000, -500000, -500000]) == True
    
    def test_very_small_numbers(self):
        assert triples_sum_to_zero([-1000000, 500000, 500000]) == True
