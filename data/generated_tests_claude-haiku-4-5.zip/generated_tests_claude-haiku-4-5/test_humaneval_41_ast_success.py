# Test cases for HumanEval/41
# Generated using Claude API



def car_race_collision(n: int):
    """
    Imagine a road that's a perfectly straight infinitely long line.
    n cars are driving left to right;  simultaneously, a different set of n cars
    are driving right to left.   The two sets of cars start out being very far from
    each other.  All cars move in the same speed.  Two cars are said to collide
    when a car that's moving left to right hits a car that's moving right to left.
    However, the cars are infinitely sturdy and strong; as a result, they continue moving
    in their trajectory as if they did not collide.

    This function outputs the number of such collisions.
    """

    return n**2


# Generated test cases:
import pytest


def car_race_collision(n: int):
    return n**2


class TestCarRaceCollision:
    def test_zero(self):
        assert car_race_collision(0) == 0

    def test_one(self):
        assert car_race_collision(1) == 1

    def test_positive_small_numbers(self):
        assert car_race_collision(2) == 4
        assert car_race_collision(3) == 9
        assert car_race_collision(4) == 16
        assert car_race_collision(5) == 25

    def test_positive_medium_numbers(self):
        assert car_race_collision(10) == 100
        assert car_race_collision(15) == 225
        assert car_race_collision(20) == 400

    def test_positive_large_numbers(self):
        assert car_race_collision(100) == 10000
        assert car_race_collision(1000) == 1000000

    def test_negative_numbers(self):
        assert car_race_collision(-1) == 1
        assert car_race_collision(-2) == 4
        assert car_race_collision(-5) == 25
        assert car_race_collision(-10) == 100

    @pytest.mark.parametrize("n,expected", [
        (0, 0),
        (1, 1),
        (2, 4),
        (3, 9),
        (5, 25),
        (10, 100),
        (-1, 1),
        (-5, 25),
        (7, 49),
        (11, 121),
    ])
    def test_parametrized_values(self, n, expected):
        assert car_race_collision(n) == expected

    def test_return_type_is_int(self):
        result = car_race_collision(5)
        assert isinstance(result, int)

    def test_return_type_is_int_for_zero(self):
        result = car_race_collision(0)
        assert isinstance(result, int)

    def test_return_type_is_int_for_negative(self):
        result = car_race_collision(-3)
        assert isinstance(result, int)

    def test_commutative_property(self):
        assert car_race_collision(7) == car_race_collision(-7)
        assert car_race_collision(12) == car_race_collision(-12)

    def test_very_large_number(self):
        assert car_race_collision(999) == 998001

    def test_result_always_non_negative(self):
        for n in range(-20, 21):
            assert car_race_collision(n) >= 0
