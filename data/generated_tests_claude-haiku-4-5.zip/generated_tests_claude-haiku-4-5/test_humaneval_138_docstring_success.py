# Test cases for HumanEval/138
# Generated using Claude API


def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """

    return n%2 == 0 and n >= 8


# Generated test cases:
import pytest


def is_equal_to_sum_even(n):
    return n%2 == 0 and n >= 8


class TestIsEqualToSumEven:
    
    @pytest.mark.parametrize("n,expected", [
        (4, False),
        (6, False),
        (8, True),
        (10, True),
        (12, True),
        (14, True),
        (100, True),
        (1000, True),
    ])
    def test_valid_cases(self, n, expected):
        assert is_equal_to_sum_even(n) == expected
    
    @pytest.mark.parametrize("n,expected", [
        (1, False),
        (3, False),
        (5, False),
        (7, False),
        (9, False),
        (11, False),
        (99, False),
        (101, False),
    ])
    def test_odd_numbers(self, n, expected):
        assert is_equal_to_sum_even(n) == expected
    
    @pytest.mark.parametrize("n,expected", [
        (0, False),
        (2, False),
    ])
    def test_small_even_numbers(self, n, expected):
        assert is_equal_to_sum_even(n) == expected
    
    def test_boundary_below_eight(self):
        assert is_equal_to_sum_even(6) == False
    
    def test_boundary_at_eight(self):
        assert is_equal_to_sum_even(8) == True
    
    def test_boundary_above_eight(self):
        assert is_equal_to_sum_even(9) == False
        assert is_equal_to_sum_even(10) == True
    
    def test_large_even_number(self):
        assert is_equal_to_sum_even(10000) == True
    
    def test_large_odd_number(self):
        assert is_equal_to_sum_even(9999) == False
    
    @pytest.mark.parametrize("n", [8, 10, 12, 14, 16, 18, 20, 100, 1000])
    def test_all_even_numbers_eight_and_above(self, n):
        assert is_equal_to_sum_even(n) == True
    
    @pytest.mark.parametrize("n", [1, 3, 5, 7, 9, 11, 13, 15, 17, 19])
    def test_all_odd_numbers(self, n):
        assert is_equal_to_sum_even(n) == False
    
    @pytest.mark.parametrize("n", [0, 2, 4, 6])
    def test_even_numbers_below_eight(self, n):
        assert is_equal_to_sum_even(n) == False
