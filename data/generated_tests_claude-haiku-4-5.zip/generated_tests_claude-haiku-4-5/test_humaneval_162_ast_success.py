# Test cases for HumanEval/162
# Generated using Claude API


def string_to_md5(text):
    """
    Given a string 'text', return its md5 hash equivalent string.
    If 'text' is an empty string, return None.

    >>> string_to_md5('Hello world') == '3e25960a79dbc69b674cd4ec67a72c62'
    """

    import hashlib
    return hashlib.md5(text.encode('ascii')).hexdigest() if text else None


# Generated test cases:
import pytest
import hashlib


def string_to_md5(text):
    return hashlib.md5(text.encode('ascii')).hexdigest() if text else None


class TestStringToMd5:
    
    def test_simple_string(self):
        result = string_to_md5("hello")
        expected = hashlib.md5("hello".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_empty_string(self):
        result = string_to_md5("")
        assert result is None
    
    def test_none_input(self):
        result = string_to_md5(None)
        assert result is None
    
    def test_single_character(self):
        result = string_to_md5("a")
        expected = hashlib.md5("a".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_numeric_string(self):
        result = string_to_md5("12345")
        expected = hashlib.md5("12345".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_special_characters(self):
        result = string_to_md5("!@#$%^&*()")
        expected = hashlib.md5("!@#$%^&*()".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_whitespace(self):
        result = string_to_md5("   ")
        expected = hashlib.md5("   ".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_long_string(self):
        long_text = "a" * 1000
        result = string_to_md5(long_text)
        expected = hashlib.md5(long_text.encode('ascii')).hexdigest()
        assert result == expected
    
    def test_mixed_case(self):
        result = string_to_md5("HeLLo WoRLd")
        expected = hashlib.md5("HeLLo WoRLd".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_result_is_hexdigest(self):
        result = string_to_md5("test")
        assert isinstance(result, str)
        assert len(result) == 32
        assert all(c in '0123456789abcdef' for c in result)
    
    def test_newline_character(self):
        result = string_to_md5("hello\nworld")
        expected = hashlib.md5("hello\nworld".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_tab_character(self):
        result = string_to_md5("hello\tworld")
        expected = hashlib.md5("hello\tworld".encode('ascii')).hexdigest()
        assert result == expected
    
    def test_same_input_same_output(self):
        text = "consistent"
        result1 = string_to_md5(text)
        result2 = string_to_md5(text)
        assert result1 == result2
    
    def test_different_inputs_different_outputs(self):
        result1 = string_to_md5("test1")
        result2 = string_to_md5("test2")
        assert result1 != result2
    
    @pytest.mark.parametrize("input_text,expected_none", [
        ("", True),
        (None, True),
        ("a", False),
        ("test", False),
        ("0", False),
    ])
    def test_parametrized_none_check(self, input_text, expected_none):
        result = string_to_md5(input_text)
        if expected_none:
            assert result is None
        else:
            assert result is not None
    
    @pytest.mark.parametrize("input_text", [
        "hello",
        "world",
        "123",
        "!@#",
        "a b c",
    ])
    def test_parametrized_valid_inputs(self, input_text):
        result = string_to_md5(input_text)
        expected = hashlib.md5(input_text.encode('ascii')).hexdigest()
        assert result == expected
    
    def test_ascii_characters_only(self):
        ascii_text = "The quick brown fox jumps over the lazy dog"
        result = string_to_md5(ascii_text)
        expected = hashlib.md5(ascii_text.encode('ascii')).hexdigest()
        assert result == expected
    
    def test_result_format(self):
        result = string_to_md5("format_test")
        assert isinstance(result, str)
        assert result.islower() or all(c in '0123456789abcdef' for c in result)
