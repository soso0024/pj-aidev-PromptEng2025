# Test cases for HumanEval/15
# Generated using Claude API



def string_sequence(n: int) -> str:
    """ Return a string containing space-delimited numbers starting from 0 upto n inclusive.
    >>> string_sequence(0)
    '0'
    >>> string_sequence(5)
    '0 1 2 3 4 5'
    """

    return ' '.join([str(x) for x in range(n + 1)])


# Generated test cases:
import pytest


def string_sequence(n: int) -> str:
    return ' '.join([str(x) for x in range(n + 1)])


class TestStringSequence:
    def test_zero(self):
        assert string_sequence(0) == "0"

    def test_one(self):
        assert string_sequence(1) == "0 1"

    def test_two(self):
        assert string_sequence(2) == "0 1 2"

    def test_five(self):
        assert string_sequence(5) == "0 1 2 3 4 5"

    def test_ten(self):
        assert string_sequence(10) == "0 1 2 3 4 5 6 7 8 9 10"

    def test_large_number(self):
        result = string_sequence(100)
        expected = ' '.join([str(x) for x in range(101)])
        assert result == expected

    def test_result_type(self):
        result = string_sequence(5)
        assert isinstance(result, str)

    def test_contains_spaces(self):
        result = string_sequence(3)
        assert ' ' in result

    def test_starts_with_zero(self):
        result = string_sequence(5)
        assert result.startswith('0')

    def test_ends_with_n(self):
        n = 7
        result = string_sequence(n)
        assert result.endswith(str(n))

    def test_correct_number_of_elements(self):
        n = 5
        result = string_sequence(n)
        elements = result.split(' ')
        assert len(elements) == n + 1

    def test_all_elements_are_numbers(self):
        result = string_sequence(5)
        elements = result.split(' ')
        for element in elements:
            assert element.isdigit()

    def test_elements_are_sequential(self):
        n = 8
        result = string_sequence(n)
        elements = [int(x) for x in result.split(' ')]
        expected = list(range(n + 1))
        assert elements == expected

    @pytest.mark.parametrize("n,expected", [
        (0, "0"),
        (1, "0 1"),
        (2, "0 1 2"),
        (3, "0 1 2 3"),
        (4, "0 1 2 3 4"),
        (5, "0 1 2 3 4 5"),
    ])
    def test_parametrized_cases(self, n, expected):
        assert string_sequence(n) == expected

    def test_negative_number(self):
        result = string_sequence(-1)
        assert result == ""

    def test_very_large_number(self):
        n = 1000
        result = string_sequence(n)
        elements = result.split(' ')
        assert len(elements) == 1001
        assert elements[0] == "0"
        assert elements[-1] == "1000"

    def test_no_leading_trailing_spaces(self):
        result = string_sequence(5)
        assert result == result.strip()

    def test_single_spaces_between_elements(self):
        result = string_sequence(5)
        assert "  " not in result
