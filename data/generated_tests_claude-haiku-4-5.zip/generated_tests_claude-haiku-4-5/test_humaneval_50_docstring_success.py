# Test cases for HumanEval/50
# Generated using Claude API



def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


def decode_shift(s: str):
    """
    takes as input string encoded with encode_shift function. Returns decoded string.
    """

    return "".join([chr(((ord(ch) - 5 - ord("a")) % 26) + ord("a")) for ch in s])


# Generated test cases:
import pytest


def encode_shift(s: str):
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


def decode_shift(s: str):
    return "".join([chr(((ord(ch) - 5 - ord("a")) % 26) + ord("a")) for ch in s])


class TestDecodeShift:
    
    def test_decode_single_character(self):
        encoded = encode_shift("a")
        assert decode_shift(encoded) == "a"
    
    def test_decode_single_character_z(self):
        encoded = encode_shift("z")
        assert decode_shift(encoded) == "z"
    
    def test_decode_simple_word(self):
        encoded = encode_shift("hello")
        assert decode_shift(encoded) == "hello"
    
    def test_decode_alphabet(self):
        encoded = encode_shift("abcdefghijklmnopqrstuvwxyz")
        assert decode_shift(encoded) == "abcdefghijklmnopqrstuvwxyz"
    
    def test_decode_empty_string(self):
        assert decode_shift("") == ""
    
    def test_decode_single_letter_a(self):
        encoded = encode_shift("a")
        decoded = decode_shift(encoded)
        assert decoded == "a"
    
    def test_decode_single_letter_m(self):
        encoded = encode_shift("m")
        decoded = decode_shift(encoded)
        assert decoded == "m"
    
    def test_decode_wrapping_letters(self):
        encoded = encode_shift("xyz")
        decoded = decode_shift(encoded)
        assert decoded == "xyz"
    
    def test_decode_long_string(self):
        original = "thequickbrownfoxjumpsoverthelazydog"
        encoded = encode_shift(original)
        decoded = decode_shift(encoded)
        assert decoded == original
    
    def test_decode_repeated_characters(self):
        original = "aaaa"
        encoded = encode_shift(original)
        decoded = decode_shift(encoded)
        assert decoded == original
    
    def test_decode_repeated_z(self):
        original = "zzzz"
        encoded = encode_shift(original)
        decoded = decode_shift(encoded)
        assert decoded == original
    
    @pytest.mark.parametrize("original", [
        "a", "b", "c", "d", "e", "f", "g", "h", "i", "j",
        "k", "l", "m", "n", "o", "p", "q", "r", "s", "t",
        "u", "v", "w", "x", "y", "z"
    ])
    def test_decode_all_letters(self, original):
        encoded = encode_shift(original)
        decoded = decode_shift(encoded)
        assert decoded == original
    
    def test_decode_is_inverse_of_encode(self):
        test_strings = [
            "a", "z", "abc", "xyz", "hello", "world",
            "thequickbrownfox", "abcdefghijklmnopqrstuvwxyz"
        ]
        for test_str in test_strings:
            encoded = encode_shift(test_str)
            decoded = decode_shift(encoded)
            assert decoded == test_str
    
    def test_decode_double_encoding_decoding(self):
        original = "testing"
        encoded_once = encode_shift(original)
        encoded_twice = encode_shift(encoded_once)
        decoded_once = decode_shift(encoded_twice)
        decoded_twice = decode_shift(decoded_once)
        assert decoded_twice == original
    
    def test_decode_specific_encoded_value(self):
        encoded = "mjqqt"
        decoded = decode_shift(encoded)
        assert decoded == "hello"
    
    def test_decode_preserves_length(self):
        original = "abcdefghijklmnopqrstuvwxyz"
        encoded = encode_shift(original)
        decoded = decode_shift(encoded)
        assert len(decoded) == len(original)
    
    def test_decode_returns_string(self):
        encoded = encode_shift("test")
        result = decode_shift(encoded)
        assert isinstance(result, str)
