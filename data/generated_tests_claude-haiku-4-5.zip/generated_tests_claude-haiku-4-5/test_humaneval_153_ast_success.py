# Test cases for HumanEval/153
# Generated using Claude API


def Strongest_Extension(class_name, extensions):
    """You will be given the name of a class (a string) and a list of extensions.
    The extensions are to be used to load additional classes to the class. The
    strength of the extension is as follows: Let CAP be the number of the uppercase
    letters in the extension's name, and let SM be the number of lowercase letters 
    in the extension's name, the strength is given by the fraction CAP - SM. 
    You should find the strongest extension and return a string in this 
    format: ClassName.StrongestExtensionName.
    If there are two or more extensions with the same strength, you should
    choose the one that comes first in the list.
    For example, if you are given "Slices" as the class and a list of the
    extensions: ['SErviNGSliCes', 'Cheese', 'StuFfed'] then you should
    return 'Slices.SErviNGSliCes' since 'SErviNGSliCes' is the strongest extension 
    (its strength is -1).
    Example:
    for Strongest_Extension('my_class', ['AA', 'Be', 'CC']) == 'my_class.AA'
    """

    strong = extensions[0]
    my_val = len([x for x in extensions[0] if x.isalpha() and x.isupper()]) - len([x for x in extensions[0] if x.isalpha() and x.islower()])
    for s in extensions:
        val = len([x for x in s if x.isalpha() and x.isupper()]) - len([x for x in s if x.isalpha() and x.islower()])
        if val > my_val:
            strong = s
            my_val = val

    ans = class_name + "." + strong
    return ans



# Generated test cases:
import pytest


def Strongest_Extension(class_name, extensions):
    strong = extensions[0]
    my_val = len([x for x in extensions[0] if x.isalpha() and x.isupper()]) - len([x for x in extensions[0] if x.isalpha() and x.islower()])
    for s in extensions:
        val = len([x for x in s if x.isalpha() and x.isupper()]) - len([x for x in s if x.isalpha() and x.islower()])
        if val > my_val:
            strong = s
            my_val = val

    ans = class_name + "." + strong
    return ans


class TestStrongestExtension:
    
    def test_single_extension(self):
        result = Strongest_Extension("MyClass", ["Extension1"])
        assert result == "MyClass.Extension1"
    
    def test_multiple_extensions_first_strongest(self):
        result = Strongest_Extension("MyClass", ["ABC", "abc", "Abc"])
        assert result == "MyClass.ABC"
    
    def test_multiple_extensions_last_strongest(self):
        result = Strongest_Extension("MyClass", ["abc", "Abc", "ABC"])
        assert result == "MyClass.ABC"
    
    def test_multiple_extensions_middle_strongest(self):
        result = Strongest_Extension("MyClass", ["abc", "ABC", "Abc"])
        assert result == "MyClass.ABC"
    
    def test_all_uppercase(self):
        result = Strongest_Extension("Test", ["ABCD", "EFGH", "IJKL"])
        assert result == "Test.ABCD"
    
    def test_all_lowercase(self):
        result = Strongest_Extension("Test", ["abcd", "efgh", "ijkl"])
        assert result == "Test.abcd"
    
    def test_mixed_case_extensions(self):
        result = Strongest_Extension("MyClass", ["Abc1def", "ABCdef", "abcDEF"])
        assert result == "MyClass.ABCdef"
    
    def test_with_numbers_and_special_chars(self):
        result = Strongest_Extension("MyClass", ["Ab12cd", "AB12cd", "ab12CD"])
        assert result == "MyClass.AB12cd"
    
    def test_equal_strength_returns_first(self):
        result = Strongest_Extension("MyClass", ["ABC", "ABC", "abc"])
        assert result == "MyClass.ABC"
    
    def test_single_character_extensions(self):
        result = Strongest_Extension("MyClass", ["A", "a", "B"])
        assert result == "MyClass.A"
    
    def test_empty_string_extension(self):
        result = Strongest_Extension("MyClass", ["", "A", "a"])
        assert result == "MyClass.A"
    
    def test_only_numbers(self):
        result = Strongest_Extension("MyClass", ["123", "456", "789"])
        assert result == "MyClass.123"
    
    def test_only_special_characters(self):
        result = Strongest_Extension("MyClass", ["!@#", "$%^", "&*()"])
        assert result == "MyClass.!@#"
    
    def test_mixed_with_spaces(self):
        result = Strongest_Extension("MyClass", ["A b C", "a B c", "ABC"])
        assert result == "MyClass.ABC"
    
    def test_class_name_with_numbers(self):
        result = Strongest_Extension("MyClass123", ["ABC", "abc"])
        assert result == "MyClass123.ABC"
    
    def test_class_name_with_special_chars(self):
        result = Strongest_Extension("My_Class", ["ABC", "abc"])
        assert result == "My_Class.ABC"
    
    def test_long_extensions(self):
        result = Strongest_Extension("MyClass", ["ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"])
        assert result == "MyClass.ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    
    def test_negative_strength(self):
        result = Strongest_Extension("MyClass", ["aaa", "aaab", "aaabc"])
        assert result == "MyClass.aaa"
    
    def test_zero_strength(self):
        result = Strongest_Extension("MyClass", ["Aa", "Bb", "Cc"])
        assert result == "MyClass.Aa"
    
    def test_two_extensions_different_strength(self):
        result = Strongest_Extension("MyClass", ["abc", "ABC"])
        assert result == "MyClass.ABC"
    
    def test_extension_with_underscores(self):
        result = Strongest_Extension("MyClass", ["_ABC_", "_abc_", "ABC"])
        assert result == "MyClass._ABC_"
    
    def test_extension_with_hyphens(self):
        result = Strongest_Extension("MyClass", ["-ABC-", "-abc-", "ABC"])
        assert result == "MyClass.-ABC-"
    
    @pytest.mark.parametrize("class_name,extensions,expected", [
        ("Class1", ["Ext1", "ext2", "EXT3"], "Class1.EXT3"),
        ("MyApp", ["Plugin", "PLUGIN", "plugin"], "MyApp.PLUGIN"),
        ("Test", ["A", "B", "C"], "Test.A"),
        ("Mod", ["XYZ", "xyz", "Xyz"], "Mod.XYZ"),
    ])
    def test_parametrized_cases(self, class_name, extensions, expected):
        result = Strongest_Extension(class_name, extensions)
        assert result == expected