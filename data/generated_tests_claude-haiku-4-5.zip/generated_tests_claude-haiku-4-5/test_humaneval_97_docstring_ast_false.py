# Test cases for HumanEval/97
# Generated using Claude API


def multiply(a, b):
    """Complete the function that takes two integers and returns 
    the product of their unit digits.
    Assume the input is always valid.
    Examples:
    multiply(148, 412) should return 16.
    multiply(19, 28) should return 72.
    multiply(2020, 1851) should return 0.
    multiply(14,-15) should return 20.
    """

    return abs(a % 10) * abs(b % 10)


# Generated test cases:
import pytest


def multiply(a, b):
    return abs(a % 10) * abs(b % 10)


@pytest.mark.parametrize("a,b,expected", [
    (148, 412, 16),
    (19, 28, 72),
    (2020, 1851, 0),
    (14, -15, 20),
])
def test_multiply_examples(a, b, expected):
    assert multiply(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    (0, 0, 0),
    (0, 5, 0),
    (5, 0, 0),
    (10, 10, 0),
    (100, 200, 0),
])
def test_multiply_with_zero(a, b, expected):
    assert multiply(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    (1, 1, 1),
    (2, 3, 6),
    (5, 7, 35),
    (9, 9, 81),
])
def test_multiply_single_digits(a, b, expected):
    assert multiply(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    (-1, -1, 1),
    (-2, -3, 6),
    (-5, -7, 35),
    (-9, -9, 81),
])
def test_multiply_negative_single_digits(a, b, expected):
    assert multiply(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    (-148, 412, 16),
    (-19, 28, 72),
    (-2020, 1851, 0),
    (-14, -15, 20),
    (148, -412, 16),
])
def test_multiply_negative_numbers(a, b, expected):
    assert multiply(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    (11, 22, 2),
    (23, 34, 12),
    (45, 56, 30),
    (67, 78, 56),
    (89, 90, 0),
])
def test_multiply_two_digit_numbers(a, b, expected):
    assert multiply(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    (123, 456, 18),
    (789, 321, 9),
    (555, 444, 20),
    (999, 111, 9),
])
def test_multiply_three_digit_numbers(a, b, expected):
    assert multiply(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    (1000, 2000, 0),
    (1234, 5678, 32),
    (9999, 8888, 72),
])
def test_multiply_large_numbers(a, b, expected):
    assert multiply(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    (1, 0, 0),
    (0, 1, 0),
    (10, 0, 0),
    (0, 10, 0),
])
def test_multiply_one_operand_zero(a, b, expected):
    assert multiply(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    (11, 11, 1),
    (22, 22, 4),
    (33, 33, 9),
    (44, 44, 16),
    (55, 55, 25),
])
def test_multiply_same_numbers(a, b, expected):
    assert multiply(a, b) == expected


def test_multiply_commutative():
    assert multiply(12, 34) == multiply(34, 12)
    assert multiply(5, 7) == multiply(7, 5)
    assert multiply(-3, 8) == multiply(8, -3)


def test_multiply_returns_integer():
    result = multiply(12, 34)
    assert isinstance(result, int)


def test_multiply_non_negative_result():
    assert multiply(14, -15) >= 0
    assert multiply(-14, -15) >= 0
    assert multiply(14, 15) >= 0