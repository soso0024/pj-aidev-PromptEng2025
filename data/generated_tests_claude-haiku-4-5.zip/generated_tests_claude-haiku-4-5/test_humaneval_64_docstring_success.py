# Test cases for HumanEval/64
# Generated using Claude API


FIX = """
Add more test cases.
"""

def vowels_count(s):
    """Write a function vowels_count which takes a string representing
    a word as input and returns the number of vowels in the string.
    Vowels in this case are 'a', 'e', 'i', 'o', 'u'. Here, 'y' is also a
    vowel, but only when it is at the end of the given word.

    Example:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    """

    vowels = "aeiouAEIOU"
    n_vowels = sum(c in vowels for c in s)
    if s[-1] == 'y' or s[-1] == 'Y':
        n_vowels += 1
    return n_vowels


# Generated test cases:
import pytest


def vowels_count(s):
    vowels = "aeiouAEIOU"
    n_vowels = sum(c in vowels for c in s)
    if s[-1] == 'y' or s[-1] == 'Y':
        n_vowels += 1
    return n_vowels


@pytest.mark.parametrize("input_str,expected", [
    ("abcde", 2),
    ("ACEDY", 3),
    ("hello", 2),
    ("world", 1),
    ("aeiou", 5),
    ("AEIOU", 5),
    ("bcdfg", 0),
    ("y", 1),
    ("Y", 1),
    ("happy", 2),
    ("HAPPY", 2),
    ("sky", 1),
    ("SKY", 1),
    ("day", 2),
    ("DAY", 2),
    ("a", 1),
    ("e", 1),
    ("i", 1),
    ("o", 1),
    ("u", 1),
    ("b", 0),
    ("by", 1),
    ("BY", 1),
    ("my", 1),
    ("MY", 1),
    ("try", 1),
    ("TRY", 1),
    ("rhythm", 0),
    ("RHYTHM", 0),
    ("beautiful", 5),
    ("BEAUTIFUL", 5),
    ("queue", 4),
    ("QUEUE", 4),
    ("education", 5),
    ("EDUCATION", 5),
    ("xyz", 0),
    ("XYZ", 0),
    ("aay", 3),
    ("AAY", 3),
    ("eey", 3),
    ("EEY", 3),
    ("iiy", 3),
    ("IIY", 3),
    ("ooy", 3),
    ("OOY", 3),
    ("uuy", 3),
    ("UUY", 3),
    ("bcdfghjklmnpqrstvwxz", 0),
    ("BCDFGHJKLMNPQRSTVWXZ", 0),
    ("aeiouaeiou", 10),
    ("AEIOUAEIOU", 10),
    ("aeiouay", 7),
    ("AEIOUAY", 7),
    ("programming", 3),
    ("PROGRAMMING", 3),
    ("python", 1),
    ("PYTHON", 1),
    ("why", 1),
    ("WHY", 1),
    ("cry", 1),
    ("CRY", 1),
    ("dry", 1),
    ("DRY", 1),
    ("fly", 1),
    ("FLY", 1),
    ("fry", 1),
    ("FRY", 1),
    ("pry", 1),
    ("PRY", 1),
    ("sly", 1),
    ("SLY", 1),
    ("spy", 1),
    ("SPY", 1),
    ("sty", 1),
    ("STY", 1),
    ("try", 1),
    ("TRY", 1),
    ("wry", 1),
    ("WRY", 1),
])
def test_vowels_count(input_str, expected):
    assert vowels_count(input_str) == expected


def test_vowels_count_single_vowel():
    assert vowels_count("a") == 1
    assert vowels_count("e") == 1
    assert vowels_count("i") == 1
    assert vowels_count("o") == 1
    assert vowels_count("u") == 1


def test_vowels_count_single_consonant():
    assert vowels_count("b") == 0
    assert vowels_count("c") == 0
    assert vowels_count("d") == 0


def test_vowels_count_y_at_end():
    assert vowels_count("y") == 1
    assert vowels_count("Y") == 1
    assert vowels_count("happy") == 2
    assert vowels_count("day") == 2


def test_vowels_count_y_not_at_end():
    assert vowels_count("yes") == 1
    assert vowels_count("YES") == 1
    assert vowels_count("yell") == 1
    assert vowels_count("YELL") == 1


def test_vowels_count_mixed_case():
    assert vowels_count("AeIoU") == 5
    assert vowels_count("aEiOu") == 5
    assert vowels_count("HeLLo") == 2


def test_vowels_count_no_vowels():
    assert vowels_count("bcdfg") == 0
    assert vowels_count("BCDFG") == 0
    assert vowels_count("xyz") == 0


def test_vowels_count_all_vowels():
    assert vowels_count("aeiou") == 5
    assert vowels_count("AEIOU") == 5


def test_vowels_count_repeated_vowels():
    assert vowels_count("aaa") == 3
    assert vowels_count("AAA") == 3
    assert vowels_count("eeee") == 4


def test_vowels_count_long_words():
    assert vowels_count("beautiful") == 5
    assert vowels_count("BEAUTIFUL") == 5
    assert vowels_count("education") == 5