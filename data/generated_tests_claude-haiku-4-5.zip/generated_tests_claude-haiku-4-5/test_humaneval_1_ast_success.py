# Test cases for HumanEval/1
# Generated using Claude API

from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """ Input to this function is a string containing multiple groups of nested parentheses. Your goal is to
    separate those group into separate strings and return the list of those.
    Separate groups are balanced (each open brace is properly closed) and not nested within each other
    Ignore any spaces in the input string.
    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """

    result = []
    current_string = []
    current_depth = 0

    for c in paren_string:
        if c == '(':
            current_depth += 1
            current_string.append(c)
        elif c == ')':
            current_depth -= 1
            current_string.append(c)

            if current_depth == 0:
                result.append(''.join(current_string))
                current_string.clear()

    return result


# Generated test cases:
import pytest
from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    result = []
    current_string = []
    current_depth = 0

    for c in paren_string:
        if c == '(':
            current_depth += 1
            current_string.append(c)
        elif c == ')':
            current_depth -= 1
            current_string.append(c)

            if current_depth == 0:
                result.append(''.join(current_string))
                current_string.clear()

    return result


class TestSeparateParenGroups:
    
    def test_single_group(self):
        assert separate_paren_groups("()") == ["()"]
    
    def test_multiple_groups(self):
        assert separate_paren_groups("()()") == ["()", "()"]
    
    def test_nested_parens(self):
        assert separate_paren_groups("(())") == ["(())"]
    
    def test_complex_nested(self):
        assert separate_paren_groups("((()))") == ["((()))"]
    
    def test_multiple_with_nesting(self):
        assert separate_paren_groups("(())(())") == ["(())", "(())"]
    
    def test_empty_string(self):
        assert separate_paren_groups("") == []
    
    def test_single_open_paren(self):
        assert separate_paren_groups("(") == []
    
    def test_single_close_paren(self):
        assert separate_paren_groups(")") == []
    
    def test_three_groups(self):
        assert separate_paren_groups("()()()") == ["()", "()", "()"]
    
    def test_deeply_nested(self):
        assert separate_paren_groups("(((())))") == ["(((())))"]
    
    def test_mixed_depth_groups(self):
        assert separate_paren_groups("()(())(())()") == ["()", "(())", "(())", "()"]
    
    def test_complex_pattern(self):
        assert separate_paren_groups("(()())(())") == ["(()())", "(())"]
    
    def test_unbalanced_incomplete(self):
        assert separate_paren_groups("(()") == []
    
    def test_unbalanced_extra_close(self):
        assert separate_paren_groups("())") == ["()"]
    
    def test_multiple_unbalanced(self):
        assert separate_paren_groups("()(()") == ["()"]
    
    def test_very_long_single_group(self):
        result = separate_paren_groups("(" * 100 + ")" * 100)
        assert len(result) == 1
        assert result[0] == "(" * 100 + ")" * 100
    
    def test_many_single_groups(self):
        result = separate_paren_groups("()" * 50)
        assert len(result) == 50
        assert all(g == "()" for g in result)
    
    def test_alternating_depth(self):
        assert separate_paren_groups("()()(())()") == ["()", "()", "(())", "()"]
    
    def test_pyramid_pattern(self):
        assert separate_paren_groups("()(())((())) ") == ["()", "(())", "((()))"]
    
    @pytest.mark.parametrize("input_str,expected", [
        ("()", ["()"]),
        ("()()", ["()", "()"]),
        ("(())", ["(())"]),
        ("", []),
        ("()(())(())", ["()", "(())", "(())"]),
    ])
    def test_parametrized_cases(self, input_str, expected):
        assert separate_paren_groups(input_str) == expected
    
    def test_return_type_is_list(self):
        result = separate_paren_groups("()")
        assert isinstance(result, list)
    
    def test_return_elements_are_strings(self):
        result = separate_paren_groups("()()")
        assert all(isinstance(item, str) for item in result)
    
    def test_no_modification_of_input(self):
        input_str = "()()"
        separate_paren_groups(input_str)
        assert input_str == "()()"
    
    def test_whitespace_not_processed(self):
        result = separate_paren_groups("() ()")
        assert result == ["()", "()"]
    
    def test_special_chars_ignored(self):
        result = separate_paren_groups("()a()")
        assert result == ["()", "()"]
    
    def test_numbers_ignored(self):
        result = separate_paren_groups("()123()")
        assert result == ["()", "()"]