# Test cases for HumanEval/123
# Generated using Claude API


def get_odd_collatz(n):
    """
    Given a positive integer n, return a sorted list that has the odd numbers in collatz sequence.

    The Collatz conjecture is a conjecture in mathematics that concerns a sequence defined
    as follows: start with any positive integer n. Then each term is obtained from the 
    previous term as follows: if the previous term is even, the next term is one half of 
    the previous term. If the previous term is odd, the next term is 3 times the previous
    term plus 1. The conjecture is that no matter what value of n, the sequence will always reach 1.

    Note: 
        1. Collatz(1) is [1].
        2. returned list sorted in increasing order.

    For example:
    get_odd_collatz(5) returns [1, 5] # The collatz sequence for 5 is [5, 16, 8, 4, 2, 1], so the odd numbers are only 1, and 5.
    """

    if n%2==0:
        odd_collatz = [] 
    else:
        odd_collatz = [n]
    while n > 1:
        if n % 2 == 0:
            n = n/2
        else:
            n = n*3 + 1
            
        if n%2 == 1:
            odd_collatz.append(int(n))

    return sorted(odd_collatz)


# Generated test cases:
import pytest


def get_odd_collatz(n):
    if n%2==0:
        odd_collatz = [] 
    else:
        odd_collatz = [n]
    while n > 1:
        if n % 2 == 0:
            n = n/2
        else:
            n = n*3 + 1
            
        if n%2 == 1:
            odd_collatz.append(int(n))

    return sorted(odd_collatz)


class TestGetOddCollatz:
    
    def test_even_number_one(self):
        result = get_odd_collatz(2)
        assert result == [1]
    
    def test_even_number_four(self):
        result = get_odd_collatz(4)
        assert result == [1]
    
    def test_even_number_six(self):
        result = get_odd_collatz(6)
        assert result == [1, 3, 5]
    
    def test_odd_number_one(self):
        result = get_odd_collatz(1)
        assert result == [1]
    
    def test_odd_number_three(self):
        result = get_odd_collatz(3)
        assert result == [1, 3, 5]
    
    def test_odd_number_five(self):
        result = get_odd_collatz(5)
        assert result == [1, 5]
    
    def test_odd_number_seven(self):
        result = get_odd_collatz(7)
        assert result == [1, 5, 7, 11, 13, 17]
    
    def test_even_number_eight(self):
        result = get_odd_collatz(8)
        assert result == [1]
    
    def test_even_number_ten(self):
        result = get_odd_collatz(10)
        assert result == [1, 5]
    
    def test_odd_number_nine(self):
        result = get_odd_collatz(9)
        assert result == [1, 5, 7, 9, 11, 13, 17]
    
    def test_result_is_sorted(self):
        result = get_odd_collatz(9)
        assert result == sorted(result)
    
    def test_result_contains_only_odd_numbers(self):
        result = get_odd_collatz(10)
        for num in result:
            assert num % 2 == 1
    
    def test_result_is_list(self):
        result = get_odd_collatz(5)
        assert isinstance(result, list)
    
    def test_large_even_number(self):
        result = get_odd_collatz(100)
        assert isinstance(result, list)
        assert all(num % 2 == 1 for num in result)
        assert result == sorted(result)
    
    def test_large_odd_number(self):
        result = get_odd_collatz(99)
        assert isinstance(result, list)
        assert all(num % 2 == 1 for num in result)
        assert result == sorted(result)
    
    def test_even_number_two(self):
        result = get_odd_collatz(2)
        assert result == [1]
    
    def test_odd_number_eleven(self):
        result = get_odd_collatz(11)
        assert isinstance(result, list)
        assert all(num % 2 == 1 for num in result)
    
    def test_result_contains_initial_odd_number(self):
        result = get_odd_collatz(5)
        assert 5 in result
    
    def test_result_does_not_contain_initial_even_number(self):
        result = get_odd_collatz(6)
        assert 6 not in result
    
    def test_result_always_contains_one(self):
        for n in range(1, 20):
            result = get_odd_collatz(n)
            assert 1 in result
    
    @pytest.mark.parametrize("n,expected", [
        (1, [1]),
        (2, [1]),
        (3, [1, 3, 5]),
        (4, [1]),
        (5, [1, 5]),
    ])
    def test_parametrized_cases(self, n, expected):
        assert get_odd_collatz(n) == expected