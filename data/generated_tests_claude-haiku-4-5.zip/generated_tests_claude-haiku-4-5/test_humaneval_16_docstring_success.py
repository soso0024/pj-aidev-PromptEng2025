# Test cases for HumanEval/16
# Generated using Claude API



def count_distinct_characters(string: str) -> int:
    """ Given a string, find out how many distinct characters (regardless of case) does it consist of
    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """

    return len(set(string.lower()))


# Generated test cases:
import pytest


def count_distinct_characters(string: str) -> int:
    return len(set(string.lower()))


class TestCountDistinctCharacters:
    
    @pytest.mark.parametrize("input_string,expected", [
        ('xyzXYZ', 3),
        ('Jerry', 4),
        ('', 0),
        ('a', 1),
        ('A', 1),
        ('aA', 1),
        ('aAbBcC', 3),
        ('hello', 4),
        ('HELLO', 4),
        ('HeLLo', 4),
        ('aabbcc', 3),
        ('AABBCC', 3),
        ('abcdefghijklmnopqrstuvwxyz', 26),
        ('ABCDEFGHIJKLMNOPQRSTUVWXYZ', 26),
        ('abcABC', 3),
        ('123', 3),
        ('111', 1),
        ('1a2b3c', 6),
        ('1A2B3C', 6),
        ('!@#$%', 5),
        ('!@#$%!@#$%', 5),
        ('a!b@c#', 6),
        ('A!B@C#', 6),
        (' ', 1),
        ('  ', 1),
        ('a b c', 4),
        ('A B C', 4),
        ('the quick brown fox', 16),
        ('THE QUICK BROWN FOX', 16),
        ('The Quick Brown Fox', 16),
        ('aabbccddee', 5),
        ('AABBCCDDEE', 5),
        ('aaaa', 1),
        ('AAAA', 1),
        ('abcdefg', 7),
        ('ABCDEFG', 7),
        ('xyz', 3),
        ('XYZ', 3),
        ('0123456789', 10),
        ('0000000000', 1),
        ('!@#$%^&*()', 10),
        ('aaa!bbb@ccc#', 6),
    ])
    def test_count_distinct_characters(self, input_string, expected):
        assert count_distinct_characters(input_string) == expected
    
    def test_empty_string(self):
        assert count_distinct_characters('') == 0
    
    def test_single_character(self):
        assert count_distinct_characters('a') == 1
    
    def test_case_insensitive(self):
        assert count_distinct_characters('aA') == 1
        assert count_distinct_characters('AaBbCc') == 3
    
    def test_all_same_character(self):
        assert count_distinct_characters('aaaa') == 1
        assert count_distinct_characters('AAAA') == 1
    
    def test_all_different_characters(self):
        assert count_distinct_characters('abcdefg') == 7
    
    def test_with_numbers(self):
        assert count_distinct_characters('a1b2c3') == 6
        assert count_distinct_characters('111222333') == 3
    
    def test_with_special_characters(self):
        assert count_distinct_characters('!@#$%') == 5
        assert count_distinct_characters('!!!') == 1
    
    def test_with_spaces(self):
        assert count_distinct_characters('a b c') == 4
        assert count_distinct_characters('   ') == 1
    
    def test_mixed_case_and_numbers(self):
        assert count_distinct_characters('Aa11Bb22') == 4
    
    def test_long_string(self):
        assert count_distinct_characters('abcdefghijklmnopqrstuvwxyz') == 26
        assert count_distinct_characters('ABCDEFGHIJKLMNOPQRSTUVWXYZ') == 26
    
    def test_repeated_characters(self):
        assert count_distinct_characters('aabbccdd') == 4
        assert count_distinct_characters('AABBCCDD') == 4