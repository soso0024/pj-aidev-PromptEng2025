# Test cases for HumanEval/96
# Generated using Claude API


def count_up_to(n):
    """Implement a function that takes an non-negative integer and returns an array of the first n
    integers that are prime numbers and less than n.
    for example:
    count_up_to(5) => [2,3]
    count_up_to(11) => [2,3,5,7]
    count_up_to(0) => []
    count_up_to(20) => [2,3,5,7,11,13,17,19]
    count_up_to(1) => []
    count_up_to(18) => [2,3,5,7,11,13,17]
    """

    primes = []
    for i in range(2, n):
        is_prime = True
        for j in range(2, i):
            if i % j == 0:
                is_prime = False
                break
        if is_prime:
            primes.append(i)
    return primes



# Generated test cases:
import pytest


def count_up_to(n):
    primes = []
    for i in range(2, n):
        is_prime = True
        for j in range(2, i):
            if i % j == 0:
                is_prime = False
                break
        if is_prime:
            primes.append(i)
    return primes


class TestCountUpTo:
    
    def test_empty_list_for_n_less_than_2(self):
        assert count_up_to(0) == []
        assert count_up_to(1) == []
        assert count_up_to(-5) == []
    
    def test_empty_list_for_n_equals_2(self):
        assert count_up_to(2) == []
    
    def test_single_prime(self):
        assert count_up_to(3) == [2]
    
    def test_multiple_primes(self):
        assert count_up_to(10) == [2, 3, 5, 7]
    
    def test_primes_up_to_20(self):
        assert count_up_to(20) == [2, 3, 5, 7, 11, 13, 17, 19]
    
    def test_primes_up_to_30(self):
        assert count_up_to(30) == [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
    
    def test_primes_up_to_50(self):
        expected = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]
        assert count_up_to(50) == expected
    
    def test_primes_up_to_100(self):
        expected = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]
        assert count_up_to(100) == expected
    
    def test_returns_list(self):
        result = count_up_to(10)
        assert isinstance(result, list)
    
    def test_all_elements_are_prime(self):
        result = count_up_to(50)
        for num in result:
            is_prime = True
            for divisor in range(2, num):
                if num % divisor == 0:
                    is_prime = False
                    break
            assert is_prime
    
    def test_all_elements_less_than_n(self):
        n = 50
        result = count_up_to(n)
        for num in result:
            assert num < n
    
    def test_all_elements_greater_than_or_equal_to_2(self):
        result = count_up_to(100)
        for num in result:
            assert num >= 2
    
    def test_no_duplicates(self):
        result = count_up_to(100)
        assert len(result) == len(set(result))
    
    def test_sorted_order(self):
        result = count_up_to(100)
        assert result == sorted(result)
    
    def test_large_n(self):
        result = count_up_to(1000)
        assert len(result) > 0
        assert result[0] == 2
        assert result[-1] < 1000
    
    def test_negative_n(self):
        assert count_up_to(-10) == []
    
    def test_n_equals_4(self):
        assert count_up_to(4) == [2, 3]
    
    def test_n_equals_5(self):
        assert count_up_to(5) == [2, 3]
    
    def test_n_equals_6(self):
        assert count_up_to(6) == [2, 3, 5]
    
    def test_n_equals_7(self):
        assert count_up_to(7) == [2, 3, 5]
    
    def test_n_equals_8(self):
        assert count_up_to(8) == [2, 3, 5, 7]


@pytest.mark.parametrize("n,expected", [
    (0, []),
    (1, []),
    (2, []),
    (3, [2]),
    (4, [2, 3]),
    (5, [2, 3]),
    (6, [2, 3, 5]),
    (7, [2, 3, 5]),
    (8, [2, 3, 5, 7]),
    (10, [2, 3, 5, 7]),
    (11, [2, 3, 5, 7]),
    (12, [2, 3, 5, 7, 11]),
])
def test_count_up_to_parametrized(n, expected):
    assert count_up_to(n) == expected
