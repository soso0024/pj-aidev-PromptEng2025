# Test cases for HumanEval/125
# Generated using Claude API


def split_words(txt):
    '''
    Given a string of words, return a list of words split on whitespace, if no whitespaces exists in the text you
    should split on commas ',' if no commas exists you should return the number of lower-case letters with odd order in the
    alphabet, ord('a') = 0, ord('b') = 1, ... ord('z') = 25
    Examples
    split_words("Hello world!") ➞ ["Hello", "world!"]
    split_words("Hello,world!") ➞ ["Hello", "world!"]
    split_words("abcdef") == 3 
    '''

    if " " in txt:
        return txt.split()
    elif "," in txt:
        return txt.replace(',',' ').split()
    else:
        return len([i for i in txt if i.islower() and ord(i)%2 == 0])


# Generated test cases:
import pytest


class TestSplitWords:
    
    @pytest.mark.parametrize("input_text,expected", [
        ("Hello world!", ["Hello", "world!"]),
        ("Hello world", ["Hello", "world"]),
        ("one two three four", ["one", "two", "three", "four"]),
        ("a b c", ["a", "b", "c"]),
        ("test string here", ["test", "string", "here"]),
    ])
    def test_split_on_whitespace(self, input_text, expected):
        from test_humaneval_125_docstring import split_words
        assert split_words(input_text) == expected
    
    @pytest.mark.parametrize("input_text,expected", [
        ("Hello,world!", ["Hello", "world!"]),
        ("one,two,three", ["one", "two", "three"]),
        ("a,b,c,d", ["a", "b", "c", "d"]),
        ("apple,banana,cherry", ["apple", "banana", "cherry"]),
    ])
    def test_split_on_comma(self, input_text, expected):
        assert split_words(input_text) == expected
    
    @pytest.mark.parametrize("input_text,expected", [
        ("abcdef", 3),
        ("abc", 1),
        ("abcd", 2),
        ("a", 0),
        ("b", 1),
        ("ace", 0),
        ("bdf", 3),
        ("aabbcc", 3),
    ])
    def test_count_odd_order_lowercase(self, input_text, expected):
        assert split_words(input_text) == expected
    
    def test_empty_string(self):
        assert split_words("") == 0
    
    def test_single_space(self):
        assert split_words(" ") == []
    
    def test_multiple_spaces(self):
        assert split_words("  ") == []
    
    def test_only_uppercase(self):
        assert split_words("ABC") == 0
    
    def test_only_numbers(self):
        assert split_words("123") == 0
    
    def test_mixed_case_no_space_no_comma(self):
        assert split_words("AbCdEf") == 3
    
    def test_special_characters_no_space_no_comma(self):
        assert split_words("a!b@c#") == 1
    
    def test_whitespace_priority_over_comma(self):
        result = split_words("Hello world,test")
        assert result == ["Hello", "world,test"]
    
    def test_comma_priority_over_count(self):
        result = split_words("a,b,c")
        assert result == ["a", "b", "c"]
    
    def test_multiple_commas(self):
        result = split_words("one,two,three,four,five")
        assert result == ["one", "two", "three", "four", "five"]
    
    def test_lowercase_letters_with_even_ord(self):
        assert split_words("bdf") == 3
    
    def test_lowercase_letters_with_odd_ord(self):
        assert split_words("ace") == 0
    
    def test_mixed_lowercase_and_uppercase_no_space_no_comma(self):
        assert split_words("AaBbCc") == 1
    
    def test_single_lowercase_letter_a(self):
        assert split_words("a") == 0
    
    def test_single_lowercase_letter_z(self):
        assert split_words("z") == 1
    
    def test_all_lowercase_alphabet(self):
        assert split_words("abcdefghijklmnopqrstuvwxyz") == 13
    
    def test_whitespace_with_special_characters(self):
        result = split_words("hello! world?")
        assert result == ["hello!", "world?"]
    
    def test_comma_with_special_characters(self):
        result = split_words("hello!,world?")
        assert result == ["hello!", "world?"]