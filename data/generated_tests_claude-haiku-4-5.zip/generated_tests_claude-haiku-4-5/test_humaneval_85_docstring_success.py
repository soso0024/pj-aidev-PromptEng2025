# Test cases for HumanEval/85
# Generated using Claude API


def add(lst):
    """Given a non-empty list of integers lst. add the even elements that are at odd indices..


    Examples:
        add([4, 2, 6, 7]) ==> 2 
    """

    return sum([lst[i] for i in range(1, len(lst), 2) if lst[i]%2 == 0])


# Generated test cases:
import pytest


def add(lst):
    return sum([lst[i] for i in range(1, len(lst), 2) if lst[i]%2 == 0])


class TestAdd:
    
    def test_example_case(self):
        assert add([4, 2, 6, 7]) == 2
    
    def test_single_element(self):
        assert add([5]) == 0
    
    def test_two_elements_even_at_odd_index(self):
        assert add([1, 2]) == 2
    
    def test_two_elements_odd_at_odd_index(self):
        assert add([1, 3]) == 0
    
    def test_all_even_at_odd_indices(self):
        assert add([1, 2, 3, 4, 5, 6]) == 12
    
    def test_all_odd_at_odd_indices(self):
        assert add([1, 3, 5, 7, 9, 11]) == 0
    
    def test_mixed_values(self):
        assert add([10, 5, 20, 3, 15, 8]) == 8
    
    def test_negative_even_numbers(self):
        assert add([1, -2, 3, -4, 5, -6]) == -12
    
    def test_zero_at_odd_index(self):
        assert add([1, 0, 3, 5]) == 0
    
    def test_multiple_zeros(self):
        assert add([1, 0, 2, 0, 3, 0]) == 0
    
    def test_large_numbers(self):
        assert add([100, 200, 300, 400]) == 600
    
    def test_negative_and_positive_mix(self):
        assert add([1, -2, 3, 4, 5, -6, 7, 8]) == 4
    
    def test_odd_length_list(self):
        assert add([1, 2, 3, 4, 5]) == 6
    
    def test_even_length_list(self):
        assert add([1, 2, 3, 4]) == 6
    
    def test_all_negative_even(self):
        assert add([1, -2, 3, -4, 5, -6]) == -12
    
    def test_single_even_at_index_one(self):
        assert add([5, 4, 7]) == 4
    
    def test_no_even_numbers(self):
        assert add([1, 1, 1, 1]) == 0
    
    def test_large_list(self):
        assert add([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == 30


@pytest.mark.parametrize("input_list,expected", [
    ([4, 2, 6, 7], 2),
    ([1, 2], 2),
    ([1, 3], 0),
    ([5], 0),
    ([1, 2, 3, 4, 5, 6], 12),
    ([10, 5, 20, 3, 15, 8], 8),
    ([1, 0, 3, 5], 0),
    ([100, 200, 300, 400], 600),
    ([1, -2, 3, 4, 5, -6, 7, 8], 4),
    ([1, 1, 1, 1], 0),
])
def test_add_parametrized(input_list, expected):
    assert add(input_list) == expected