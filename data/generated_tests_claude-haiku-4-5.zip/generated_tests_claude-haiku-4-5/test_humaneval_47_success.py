# Test cases for HumanEval/47
# Generated using Claude API



def median(l: list):
    """Return median of elements in the list l.
    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """

    l = sorted(l)
    if len(l) % 2 == 1:
        return l[len(l) // 2]
    else:
        return (l[len(l) // 2 - 1] + l[len(l) // 2]) / 2.0


# Generated test cases:
import pytest


def median(l: list):
    l = sorted(l)
    if len(l) % 2 == 1:
        return l[len(l) // 2]
    else:
        return (l[len(l) // 2 - 1] + l[len(l) // 2]) / 2.0


class TestMedian:
    
    def test_single_element(self):
        assert median([5]) == 5
    
    def test_single_element_negative(self):
        assert median([-10]) == -10
    
    def test_two_elements(self):
        assert median([1, 2]) == 1.5
    
    def test_two_elements_same(self):
        assert median([5, 5]) == 5.0
    
    def test_odd_length_sorted(self):
        assert median([1, 2, 3]) == 2
    
    def test_odd_length_unsorted(self):
        assert median([3, 1, 2]) == 2
    
    def test_even_length_sorted(self):
        assert median([1, 2, 3, 4]) == 2.5
    
    def test_even_length_unsorted(self):
        assert median([4, 1, 3, 2]) == 2.5
    
    def test_negative_numbers_odd(self):
        assert median([-3, -1, -2]) == -2
    
    def test_negative_numbers_even(self):
        assert median([-4, -1, -3, -2]) == -2.5
    
    def test_mixed_positive_negative_odd(self):
        assert median([-2, 0, 2]) == 0
    
    def test_mixed_positive_negative_even(self):
        assert median([-2, -1, 1, 2]) == 0.0
    
    def test_duplicates_odd(self):
        assert median([1, 1, 1, 2, 3]) == 1
    
    def test_duplicates_even(self):
        assert median([1, 1, 2, 2]) == 1.5
    
    def test_large_numbers(self):
        assert median([1000000, 2000000, 3000000]) == 2000000
    
    def test_float_numbers_odd(self):
        assert median([1.5, 2.5, 3.5]) == 2.5
    
    def test_float_numbers_even(self):
        assert median([1.5, 2.5, 3.5, 4.5]) == 3.0
    
    def test_five_elements(self):
        assert median([5, 2, 8, 1, 9]) == 5
    
    def test_six_elements(self):
        assert median([6, 2, 8, 1, 9, 3]) == 4.5
    
    def test_all_same_elements_odd(self):
        assert median([7, 7, 7]) == 7
    
    def test_all_same_elements_even(self):
        assert median([7, 7, 7, 7]) == 7.0
    
    def test_zero_in_list(self):
        assert median([0, 1, 2]) == 1
    
    def test_zero_only(self):
        assert median([0]) == 0
    
    def test_zeros_and_negatives(self):
        assert median([-1, 0, 1]) == 0
    
    @pytest.mark.parametrize("input_list,expected", [
        ([1], 1),
        ([1, 2], 1.5),
        ([1, 2, 3], 2),
        ([1, 2, 3, 4], 2.5),
        ([5, 3, 1, 4, 2], 3),
        ([-1, -2, -3], -2),
        ([0, 0, 0], 0),
    ])
    def test_parametrized_cases(self, input_list, expected):
        assert median(input_list) == expected
    
    def test_very_large_list_odd(self):
        test_list = list(range(1, 1002))
        assert median(test_list) == 501
    
    def test_very_large_list_even(self):
        test_list = list(range(1, 1001))
        assert median(test_list) == 500.5
    
    def test_unsorted_large_list(self):
        test_list = [100, 50, 75, 25, 150]
        assert median(test_list) == 75
    
    def test_decimal_precision(self):
        result = median([1.1, 2.2, 3.3, 4.4])
        assert abs(result - 2.75) < 1e-10
