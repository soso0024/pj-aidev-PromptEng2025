# Test cases for HumanEval/150
# Generated using Claude API


def x_or_y(n, x, y):
    """A simple program which should return the value of x if n is 
    a prime number and should return the value of y otherwise.

    Examples:
    for x_or_y(7, 34, 12) == 34
    for x_or_y(15, 8, 5) == 5
    
    """

    if n == 1:
        return y
    for i in range(2, n):
        if n % i == 0:
            return y
            break
    else:
        return x


# Generated test cases:
import pytest


def x_or_y(n, x, y):
    if n == 1:
        return y
    for i in range(2, n):
        if n % i == 0:
            return y
            break
    else:
        return x


class TestXOrY:
    
    @pytest.mark.parametrize("n,x,y,expected", [
        (1, 10, 20, 20),
        (2, 10, 20, 10),
        (3, 10, 20, 10),
        (4, 10, 20, 20),
        (5, 10, 20, 10),
        (6, 10, 20, 20),
        (7, 10, 20, 10),
        (8, 10, 20, 20),
        (9, 10, 20, 20),
        (10, 10, 20, 20),
        (11, 10, 20, 10),
        (13, 10, 20, 10),
        (15, 10, 20, 20),
        (17, 10, 20, 10),
        (20, 10, 20, 20),
        (23, 10, 20, 10),
        (25, 10, 20, 20),
        (29, 10, 20, 10),
        (30, 10, 20, 20),
    ])
    def test_x_or_y_various_inputs(self, n, x, y, expected):
        assert x_or_y(n, x, y) == expected
    
    def test_x_or_y_n_equals_1(self):
        assert x_or_y(1, 5, 15) == 15
        assert x_or_y(1, 100, 200) == 200
        assert x_or_y(1, 0, 1) == 1
    
    def test_x_or_y_prime_numbers(self):
        assert x_or_y(2, 10, 20) == 10
        assert x_or_y(3, 10, 20) == 10
        assert x_or_y(5, 10, 20) == 10
        assert x_or_y(7, 10, 20) == 10
        assert x_or_y(11, 10, 20) == 10
        assert x_or_y(13, 10, 20) == 10
        assert x_or_y(19, 10, 20) == 10
    
    def test_x_or_y_composite_numbers(self):
        assert x_or_y(4, 10, 20) == 20
        assert x_or_y(6, 10, 20) == 20
        assert x_or_y(8, 10, 20) == 20
        assert x_or_y(9, 10, 20) == 20
        assert x_or_y(10, 10, 20) == 20
        assert x_or_y(12, 10, 20) == 20
        assert x_or_y(15, 10, 20) == 20
    
    def test_x_or_y_negative_x_y(self):
        assert x_or_y(2, -10, -20) == -10
        assert x_or_y(4, -10, -20) == -20
        assert x_or_y(1, -5, -15) == -15
    
    def test_x_or_y_zero_values(self):
        assert x_or_y(2, 0, 10) == 0
        assert x_or_y(4, 0, 10) == 10
        assert x_or_y(1, 0, 10) == 10
    
    def test_x_or_y_same_x_y(self):
        assert x_or_y(2, 5, 5) == 5
        assert x_or_y(4, 5, 5) == 5
        assert x_or_y(1, 5, 5) == 5
    
    def test_x_or_y_large_prime(self):
        assert x_or_y(97, 10, 20) == 10
        assert x_or_y(101, 10, 20) == 10
    
    def test_x_or_y_large_composite(self):
        assert x_or_y(100, 10, 20) == 20
        assert x_or_y(99, 10, 20) == 20
        assert x_or_y(98, 10, 20) == 20
    
    def test_x_or_y_float_like_integers(self):
        assert x_or_y(2, 1, 2) == 1
        assert x_or_y(3, 1, 2) == 1
        assert x_or_y(4, 1, 2) == 2
    
    def test_x_or_y_large_numbers(self):
        assert x_or_y(1000, 10, 20) == 20
        assert x_or_y(997, 10, 20) == 10
        assert x_or_y(1001, 10, 20) == 20
