# Test cases for HumanEval/131
# Generated using Claude API


def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.
    For example:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """

    product = 1
    odd_count = 0
    for digit in str(n):
        int_digit = int(digit)
        if int_digit%2 == 1:
            product= product*int_digit
            odd_count+=1
    if odd_count ==0:
        return 0
    else:
        return product


# Generated test cases:
import pytest


@pytest.mark.parametrize("input_val,expected", [
    (1, 1),
    (4, 0),
    (235, 15),
    (2, 0),
    (3, 3),
    (5, 5),
    (7, 7),
    (9, 9),
    (10, 1),
    (11, 1),
    (13, 3),
    (24, 0),
    (135, 15),
    (246, 0),
    (111, 1),
    (357, 105),
    (2468, 0),
    (13579, 945),
    (100, 0),
    (101, 1),
    (123, 3),
    (456, 0),
    (789, 63),
    (999, 729),
    (1357, 105),
    (2468, 0),
    (5, 5),
    (50, 5),
    (505, 25),
    (5050, 25),
])
def test_digits_parametrized(input_val, expected):
    from test_humaneval_131_docstring_ast import digits
    assert digits(input_val) == expected


def test_digits_single_odd_digit():
    assert digits(1) == 1
    assert digits(3) == 3
    assert digits(5) == 5
    assert digits(7) == 7
    assert digits(9) == 9


def test_digits_single_even_digit():
    assert digits(2) == 0
    assert digits(4) == 0
    assert digits(6) == 0
    assert digits(8) == 0


def test_digits_all_even():
    assert digits(2468) == 0
    assert digits(246) == 0
    assert digits(24) == 0
    assert digits(2) == 0


def test_digits_all_odd():
    assert digits(135) == 15
    assert digits(357) == 105
    assert digits(13579) == 945
    assert digits(111) == 1
    assert digits(999) == 729


def test_digits_mixed():
    assert digits(235) == 15
    assert digits(123) == 3
    assert digits(456) == 0
    assert digits(789) == 63
    assert digits(101) == 1


def test_digits_with_zeros():
    assert digits(100) == 0
    assert digits(101) == 1
    assert digits(505) == 25
    assert digits(5050) == 25
    assert digits(1001) == 1


def test_digits_large_numbers():
    assert digits(123456789) == 945
    assert digits(2468101214) == 1
    assert digits(1111111111) == 1
    assert digits(2222222222) == 0


def test_digits_two_digit_numbers():
    assert digits(11) == 1
    assert digits(13) == 3
    assert digits(15) == 5
    assert digits(22) == 0
    assert digits(24) == 0
    assert digits(35) == 15
    assert digits(57) == 35


def test_digits_three_digit_numbers():
    assert digits(111) == 1
    assert digits(135) == 15
    assert digits(246) == 0
    assert digits(357) == 105
    assert digits(789) == 63


def test_digits_product_calculation():
    assert digits(13) == 1 * 3
    assert digits(35) == 3 * 5
    assert digits(579) == 5 * 7 * 9
    assert digits(1357) == 1 * 3 * 5 * 7


def test_digits_edge_case_single_digit():
    assert digits(0) == 0
    assert digits(1) == 1
    assert digits(9) == 9