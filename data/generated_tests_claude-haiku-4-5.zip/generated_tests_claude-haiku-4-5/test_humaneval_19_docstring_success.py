# Test cases for HumanEval/19
# Generated using Claude API

from typing import List


def sort_numbers(numbers: str) -> str:
    """ Input is a space-delimited string of numberals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight' and 'nine'.
    Return the string with numbers sorted from smallest to largest
    >>> sort_numbers('three one five')
    'one three five'
    """

    value_map = {
        'zero': 0,
        'one': 1,
        'two': 2,
        'three': 3,
        'four': 4,
        'five': 5,
        'six': 6,
        'seven': 7,
        'eight': 8,
        'nine': 9
    }
    return ' '.join(sorted([x for x in numbers.split(' ') if x], key=lambda x: value_map[x]))


# Generated test cases:
import pytest


def sort_numbers(numbers: str) -> str:
    value_map = {
        'zero': 0,
        'one': 1,
        'two': 2,
        'three': 3,
        'four': 4,
        'five': 5,
        'six': 6,
        'seven': 7,
        'eight': 8,
        'nine': 9
    }
    return ' '.join(sorted([x for x in numbers.split(' ') if x], key=lambda x: value_map[x]))


class TestSortNumbers:
    
    def test_example_case(self):
        assert sort_numbers('three one five') == 'one three five'
    
    def test_single_number(self):
        assert sort_numbers('five') == 'five'
    
    def test_two_numbers(self):
        assert sort_numbers('nine zero') == 'zero nine'
    
    def test_all_numbers_in_order(self):
        assert sort_numbers('zero one two three four five six seven eight nine') == 'zero one two three four five six seven eight nine'
    
    def test_all_numbers_reverse_order(self):
        assert sort_numbers('nine eight seven six five four three two one zero') == 'zero one two three four five six seven eight nine'
    
    def test_duplicate_numbers(self):
        assert sort_numbers('five five three three') == 'three three five five'
    
    def test_all_same_number(self):
        assert sort_numbers('seven seven seven') == 'seven seven seven'
    
    def test_zero_first(self):
        assert sort_numbers('five zero three') == 'zero three five'
    
    def test_nine_last(self):
        assert sort_numbers('five nine three') == 'three five nine'
    
    def test_mixed_order(self):
        assert sort_numbers('eight two six one nine') == 'one two six eight nine'
    
    def test_two_elements_sorted(self):
        assert sort_numbers('one two') == 'one two'
    
    def test_two_elements_unsorted(self):
        assert sort_numbers('two one') == 'one two'
    
    def test_large_sequence(self):
        assert sort_numbers('nine one eight two seven three six four five zero') == 'zero one two three four five six seven eight nine'
    
    def test_with_extra_spaces(self):
        assert sort_numbers('three  one  five') == 'one three five'
    
    def test_leading_space(self):
        assert sort_numbers(' three one five') == 'one three five'
    
    def test_trailing_space(self):
        assert sort_numbers('three one five ') == 'one three five'
    
    def test_multiple_extra_spaces(self):
        assert sort_numbers('three   one   five') == 'one three five'
    
    @pytest.mark.parametrize("input_str,expected", [
        ('zero', 'zero'),
        ('one', 'one'),
        ('nine', 'nine'),
        ('zero one', 'zero one'),
        ('one zero', 'zero one'),
        ('five four three two one zero', 'zero one two three four five'),
        ('nine eight seven six five four three two one zero', 'zero one two three four five six seven eight nine'),
    ])
    def test_parametrized_cases(self, input_str, expected):
        assert sort_numbers(input_str) == expected
