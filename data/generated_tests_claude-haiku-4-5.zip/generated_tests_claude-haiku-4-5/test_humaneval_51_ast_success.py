# Test cases for HumanEval/51
# Generated using Claude API



def remove_vowels(text):
    """
    remove_vowels is a function that takes string and returns string without vowels.
    >>> remove_vowels('')
    ''
    >>> remove_vowels("abcdef\nghijklm")
    'bcdf\nghjklm'
    >>> remove_vowels('abcdef')
    'bcdf'
    >>> remove_vowels('aaaaa')
    ''
    >>> remove_vowels('aaBAA')
    'B'
    >>> remove_vowels('zbcd')
    'zbcd'
    """

    return "".join([s for s in text if s.lower() not in ["a", "e", "i", "o", "u"]])


# Generated test cases:
import pytest


def remove_vowels(text):
    return "".join([s for s in text if s.lower() not in ["a", "e", "i", "o", "u"]])


class TestRemoveVowels:
    
    @pytest.mark.parametrize("input_text,expected", [
        ("hello", "hll"),
        ("world", "wrld"),
        ("aeiou", ""),
        ("AEIOU", ""),
        ("bcdfg", "bcdfg"),
        ("", ""),
        ("a", ""),
        ("b", "b"),
        ("Hello World", "Hll Wrld"),
        ("Python", "Pythn"),
        ("AEIOUaeiou", ""),
        ("xyz", "xyz"),
        ("123", "123"),
        ("a1e2i3o4u5", "12345"),
        ("The quick brown fox", "Th qck brwn fx"),
        ("HELLO", "HLL"),
        ("hello", "hll"),
        ("HeLLo", "HLL"),
        ("programming", "prgrmmng"),
        ("vowels", "vwls"),
        ("aaa", ""),
        ("eee", ""),
        ("iii", ""),
        ("ooo", ""),
        ("uuu", ""),
        ("bbb", "bbb"),
        ("a e i o u", "    "),
        ("!@#$%", "!@#$%"),
        ("test123test", "tst123tst"),
        ("AaEeIiOoUu", ""),
    ])
    def test_remove_vowels_various_inputs(self, input_text, expected):
        assert remove_vowels(input_text) == expected
    
    def test_remove_vowels_empty_string(self):
        assert remove_vowels("") == ""
    
    def test_remove_vowels_only_vowels(self):
        assert remove_vowels("aeiou") == ""
    
    def test_remove_vowels_only_consonants(self):
        assert remove_vowels("bcdfg") == "bcdfg"
    
    def test_remove_vowels_mixed_case_vowels(self):
        assert remove_vowels("AaEeIiOoUu") == ""
    
    def test_remove_vowels_with_numbers(self):
        assert remove_vowels("a1b2c3") == "1b2c3"
    
    def test_remove_vowels_with_special_characters(self):
        assert remove_vowels("a!e@i#o$u%") == "!@#$%"
    
    def test_remove_vowels_with_spaces(self):
        assert remove_vowels("a e i o u") == "    "
    
    def test_remove_vowels_single_vowel(self):
        assert remove_vowels("a") == ""
    
    def test_remove_vowels_single_consonant(self):
        assert remove_vowels("b") == "b"
    
    def test_remove_vowels_uppercase_vowels(self):
        assert remove_vowels("AEIOU") == ""
    
    def test_remove_vowels_lowercase_vowels(self):
        assert remove_vowels("aeiou") == ""
    
    def test_remove_vowels_sentence(self):
        assert remove_vowels("The quick brown fox jumps") == "Th qck brwn fx jmps"
    
    def test_remove_vowels_repeated_consonants(self):
        assert remove_vowels("bbbcccdddfff") == "bbbcccdddfff"
    
    def test_remove_vowels_repeated_vowels(self):
        assert remove_vowels("aaabbbeeeccc") == "bbbccc"
    
    def test_remove_vowels_alternating(self):
        assert remove_vowels("ababab") == "bbb"
    
    def test_remove_vowels_newline_and_tabs(self):
        result = remove_vowels("a\ne\ti")
        assert result == "\n\t"
    
    def test_remove_vowels_unicode_vowels(self):
        assert remove_vowels("café") == "cfé"
    
    def test_remove_vowels_long_string(self):
        long_string = "a" * 1000 + "b" * 1000
        assert remove_vowels(long_string) == "b" * 1000
    
    def test_remove_vowels_preserves_order(self):
        assert remove_vowels("zebra") == "zbr"
    
    def test_remove_vowels_all_vowel_types(self):
        assert remove_vowels("aAeEiIoOuU") == ""


if __name__ == "__main__":
    pytest.main([__file__, "-v"])