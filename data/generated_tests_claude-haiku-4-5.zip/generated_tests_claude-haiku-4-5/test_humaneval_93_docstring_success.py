# Test cases for HumanEval/93
# Generated using Claude API


def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """

    vowels = "aeiouAEIOU"
    vowels_replace = dict([(i, chr(ord(i) + 2)) for i in vowels])
    message = message.swapcase()
    return ''.join([vowels_replace[i] if i in vowels else i for i in message])


# Generated test cases:
import pytest


def encode(message):
    vowels = "aeiouAEIOU"
    vowels_replace = dict([(i, chr(ord(i) + 2)) for i in vowels])
    message = message.swapcase()
    return ''.join([vowels_replace[i] if i in vowels else i for i in message])


class TestEncode:
    
    @pytest.mark.parametrize("input_msg,expected", [
        ("test", "TGST"),
        ("This is a message", "tHKS KS C MGSSCGG"),
        ("a", "C"),
        ("A", "c"),
        ("e", "G"),
        ("E", "g"),
        ("i", "K"),
        ("I", "k"),
        ("o", "Q"),
        ("O", "q"),
        ("u", "W"),
        ("U", "w"),
    ])
    def test_encode_vowel_replacement(self, input_msg, expected):
        assert encode(input_msg) == expected
    
    @pytest.mark.parametrize("input_msg,expected", [
        ("b", "B"),
        ("B", "b"),
        ("c", "C"),
        ("C", "c"),
        ("xyz", "XYZ"),
        ("XYZ", "xyz"),
    ])
    def test_encode_consonants_only(self, input_msg, expected):
        assert encode(input_msg) == expected
    
    @pytest.mark.parametrize("input_msg,expected", [
        ("", ""),
    ])
    def test_encode_empty_string(self, input_msg, expected):
        assert encode(input_msg) == expected
    
    @pytest.mark.parametrize("input_msg,expected", [
        ("aeiou", "CGKQW"),
        ("AEIOU", "cgkqw"),
    ])
    def test_encode_all_vowels(self, input_msg, expected):
        assert encode(input_msg) == expected
    
    @pytest.mark.parametrize("input_msg,expected", [
        ("bcdfg", "BCDFG"),
        ("BCDFG", "bcdfg"),
    ])
    def test_encode_all_consonants(self, input_msg, expected):
        assert encode(input_msg) == expected
    
    @pytest.mark.parametrize("input_msg,expected", [
        ("Hello World", "hGLLQ wQRLD"),
        ("HELLO WORLD", "hgllq wqrld"),
        ("hello world", "HGLLQ WQRLD"),
    ])
    def test_encode_mixed_case_words(self, input_msg, expected):
        assert encode(input_msg) == expected
    
    @pytest.mark.parametrize("input_msg,expected", [
        ("aA", "Cc"),
        ("eE", "Gg"),
        ("iI", "Kk"),
        ("oO", "Qq"),
        ("uU", "Ww"),
    ])
    def test_encode_vowel_pairs(self, input_msg, expected):
        assert encode(input_msg) == expected
    
    @pytest.mark.parametrize("input_msg,expected", [
        ("Programming", "pRQGRCMMKNG"),
        ("Python", "pYTHQN"),
        ("Encode", "gNCQDG"),
    ])
    def test_encode_real_words(self, input_msg, expected):
        assert encode(input_msg) == expected
    
    @pytest.mark.parametrize("input_msg,expected", [
        ("a e i o u", "C G K Q W"),
        ("A E I O U", "c g k q w"),
    ])
    def test_encode_vowels_with_spaces(self, input_msg, expected):
        assert encode(input_msg) == expected
    
    def test_encode_single_lowercase_letter(self):
        assert encode("a") == "C"
    
    def test_encode_single_uppercase_letter(self):
        assert encode("A") == "c"
    
    def test_encode_long_message(self):
        long_msg = "The quick brown fox jumps over the lazy dog"
        result = encode(long_msg)
        assert isinstance(result, str)
        assert len(result) == len(long_msg)
    
    def test_encode_preserves_spaces(self):
        msg = "a b c"
        result = encode(msg)
        assert result[1] == " "
        assert result[3] == " "
    
    def test_encode_case_swap_with_vowels(self):
        msg = "AaBbEe"
        result = encode(msg)
        assert result == "cCbBgG"