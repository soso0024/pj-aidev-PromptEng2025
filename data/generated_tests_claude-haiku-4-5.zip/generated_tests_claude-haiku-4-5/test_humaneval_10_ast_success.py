# Test cases for HumanEval/10
# Generated using Claude API



def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """ Find the shortest palindrome that begins with a supplied string.
    Algorithm idea is simple:
    - Find the longest postfix of supplied string that is a palindrome.
    - Append to the end of the string reverse of a string prefix that comes before the palindromic suffix.
    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    """

    if not string:
        return ''

    beginning_of_suffix = 0

    while not is_palindrome(string[beginning_of_suffix:]):
        beginning_of_suffix += 1

    return string + string[:beginning_of_suffix][::-1]


# Generated test cases:
import pytest


def is_palindrome(string: str) -> bool:
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    if not string:
        return ''

    beginning_of_suffix = 0

    while not is_palindrome(string[beginning_of_suffix:]):
        beginning_of_suffix += 1

    return string + string[:beginning_of_suffix][::-1]


class TestMakePalindrome:
    
    def test_empty_string(self):
        assert make_palindrome('') == ''
    
    def test_single_character(self):
        assert make_palindrome('a') == 'a'
    
    def test_already_palindrome(self):
        assert make_palindrome('aba') == 'aba'
    
    def test_already_palindrome_even_length(self):
        assert make_palindrome('abba') == 'abba'
    
    def test_single_character_repeated(self):
        assert make_palindrome('aaa') == 'aaa'
    
    def test_two_same_characters(self):
        assert make_palindrome('aa') == 'aa'
    
    def test_two_different_characters(self):
        result = make_palindrome('ab')
        assert is_palindrome(result)
        assert result.startswith('ab')
    
    def test_simple_case_abc(self):
        result = make_palindrome('abc')
        assert is_palindrome(result)
        assert result.startswith('abc')
    
    def test_simple_case_abcd(self):
        result = make_palindrome('abcd')
        assert is_palindrome(result)
        assert result.startswith('abcd')
    
    def test_result_is_palindrome_race(self):
        result = make_palindrome('race')
        assert is_palindrome(result)
        assert result.startswith('race')
    
    def test_result_is_palindrome_hello(self):
        result = make_palindrome('hello')
        assert is_palindrome(result)
        assert result.startswith('hello')
    
    def test_result_is_palindrome_world(self):
        result = make_palindrome('world')
        assert is_palindrome(result)
        assert result.startswith('world')
    
    def test_result_contains_original(self):
        original = 'test'
        result = make_palindrome(original)
        assert original in result
    
    def test_result_is_palindrome_generic(self):
        test_strings = ['a', 'ab', 'abc', 'abcd', 'abcde', 'xyz', 'programming']
        for s in test_strings:
            result = make_palindrome(s)
            assert is_palindrome(result), f"Result '{result}' is not a palindrome for input '{s}'"
    
    def test_result_starts_with_original(self):
        test_strings = ['a', 'ab', 'abc', 'test', 'hello']
        for s in test_strings:
            result = make_palindrome(s)
            assert result.startswith(s), f"Result '{result}' does not start with '{s}'"
    
    def test_minimal_addition(self):
        result = make_palindrome('ab')
        assert len(result) >= len('ab')
    
    def test_case_sensitive(self):
        result = make_palindrome('Ab')
        assert is_palindrome(result)
    
    def test_with_numbers(self):
        result = make_palindrome('123')
        assert is_palindrome(result)
        assert result.startswith('123')
    
    def test_with_special_characters(self):
        result = make_palindrome('a!b')
        assert is_palindrome(result)
        assert result.startswith('a!b')
    
    def test_with_spaces(self):
        result = make_palindrome('a b')
        assert is_palindrome(result)
        assert result.startswith('a b')
    
    def test_long_string(self):
        long_string = 'abcdefghijklmnop'
        result = make_palindrome(long_string)
        assert is_palindrome(result)
        assert result.startswith(long_string)
    
    def test_repeated_pattern(self):
        result = make_palindrome('ababab')
        assert is_palindrome(result)
        assert result.startswith('ababab')
    
    def test_all_same_character(self):
        result = make_palindrome('zzzzz')
        assert is_palindrome(result)
        assert result == 'zzzzz'
    
    @pytest.mark.parametrize("input_str,expected_palindrome", [
        ('a', True),
        ('ab', True),
        ('abc', True),
        ('abcd', True),
        ('racecar', True),
        ('', True),
    ])
    def test_parametrized_palindrome_check(self, input_str, expected_palindrome):
        result = make_palindrome(input_str)
        assert is_palindrome(result) == expected_palindrome
    
    def test_unicode_characters(self):
        result = make_palindrome('café')
        assert is_palindrome(result)
        assert result.startswith('café')
    
    def test_very_long_string(self):
        long_string = 'a' * 100 + 'b'
        result = make_palindrome(long_string)
        assert is_palindrome(result)
        assert result.startswith(long_string)
