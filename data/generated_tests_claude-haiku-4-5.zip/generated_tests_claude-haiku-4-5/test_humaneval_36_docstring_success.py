# Test cases for HumanEval/36
# Generated using Claude API



def fizz_buzz(n: int):
    """Return the number of times the digit 7 appears in integers less than n which are divisible by 11 or 13.
    >>> fizz_buzz(50)
    0
    >>> fizz_buzz(78)
    2
    >>> fizz_buzz(79)
    3
    """

    ns = []
    for i in range(n):
        if i % 11 == 0 or i % 13 == 0:
            ns.append(i)
    s = ''.join(list(map(str, ns)))
    ans = 0
    for c in s:
        ans += (c == '7')
    return ans


# Generated test cases:
import pytest


def fizz_buzz(n: int):
    ns = []
    for i in range(n):
        if i % 11 == 0 or i % 13 == 0:
            ns.append(i)
    s = ''.join(list(map(str, ns)))
    ans = 0
    for c in s:
        ans += (c == '7')
    return ans


class TestFizzBuzz:
    
    def test_fizz_buzz_50(self):
        assert fizz_buzz(50) == 0
    
    def test_fizz_buzz_78(self):
        assert fizz_buzz(78) == 2
    
    def test_fizz_buzz_79(self):
        assert fizz_buzz(79) == 3
    
    def test_fizz_buzz_zero(self):
        assert fizz_buzz(0) == 0
    
    def test_fizz_buzz_one(self):
        assert fizz_buzz(1) == 0
    
    def test_fizz_buzz_eleven(self):
        assert fizz_buzz(11) == 0
    
    def test_fizz_buzz_thirteen(self):
        assert fizz_buzz(13) == 0
    
    def test_fizz_buzz_small_number(self):
        assert fizz_buzz(10) == 0
    
    def test_fizz_buzz_includes_zero(self):
        assert fizz_buzz(12) == 0
    
    def test_fizz_buzz_includes_eleven(self):
        assert fizz_buzz(12) == 0
    
    def test_fizz_buzz_includes_thirteen(self):
        assert fizz_buzz(14) == 0
    
    def test_fizz_buzz_includes_22(self):
        assert fizz_buzz(23) == 0
    
    def test_fizz_buzz_includes_26(self):
        assert fizz_buzz(27) == 0
    
    def test_fizz_buzz_includes_33(self):
        assert fizz_buzz(34) == 0
    
    def test_fizz_buzz_includes_39(self):
        assert fizz_buzz(40) == 0
    
    def test_fizz_buzz_includes_44(self):
        assert fizz_buzz(45) == 0
    
    def test_fizz_buzz_includes_52(self):
        assert fizz_buzz(53) == 0
    
    def test_fizz_buzz_includes_55(self):
        assert fizz_buzz(56) == 0
    
    def test_fizz_buzz_includes_65(self):
        assert fizz_buzz(66) == 0
    
    def test_fizz_buzz_includes_66(self):
        assert fizz_buzz(67) == 0
    
    def test_fizz_buzz_includes_77(self):
        assert fizz_buzz(78) == 2
    
    def test_fizz_buzz_large_number(self):
        result = fizz_buzz(100)
        assert isinstance(result, int)
        assert result >= 0
    
    def test_fizz_buzz_very_large_number(self):
        result = fizz_buzz(1000)
        assert isinstance(result, int)
        assert result >= 0
    
    def test_fizz_buzz_negative_input(self):
        assert fizz_buzz(-1) == 0
    
    def test_fizz_buzz_negative_large_input(self):
        assert fizz_buzz(-100) == 0
    
    @pytest.mark.parametrize("n,expected", [
        (0, 0),
        (1, 0),
        (11, 0),
        (12, 0),
        (13, 0),
        (14, 0),
        (22, 0),
        (26, 0),
        (50, 0),
        (65, 0),
        (66, 0),
        (78, 2),
        (79, 3),
    ])
    def test_fizz_buzz_parametrized(self, n, expected):
        assert fizz_buzz(n) == expected