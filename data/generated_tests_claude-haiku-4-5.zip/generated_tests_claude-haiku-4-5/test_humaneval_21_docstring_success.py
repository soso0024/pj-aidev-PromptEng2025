# Test cases for HumanEval/21
# Generated using Claude API

from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    """ Given list of numbers (of at least two elements), apply a linear transform to that list,
    such that the smallest number will become 0 and the largest will become 1
    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.25, 0.5, 0.75, 1.0]
    """

    min_number = min(numbers)
    max_number = max(numbers)
    return [(x - min_number) / (max_number - min_number) for x in numbers]


# Generated test cases:
import pytest
from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    min_number = min(numbers)
    max_number = max(numbers)
    return [(x - min_number) / (max_number - min_number) for x in numbers]


class TestRescaleToUnit:
    
    def test_basic_example(self):
        result = rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
        expected = [0.0, 0.25, 0.5, 0.75, 1.0]
        assert result == expected
    
    def test_two_elements(self):
        result = rescale_to_unit([0.0, 1.0])
        expected = [0.0, 1.0]
        assert result == expected
    
    def test_two_elements_negative(self):
        result = rescale_to_unit([-1.0, 1.0])
        expected = [0.0, 1.0]
        assert result == expected
    
    def test_negative_numbers(self):
        result = rescale_to_unit([-5.0, -3.0, -1.0])
        expected = [0.0, 0.5, 1.0]
        assert result == expected
    
    def test_all_same_numbers(self):
        with pytest.raises(ZeroDivisionError):
            rescale_to_unit([5.0, 5.0, 5.0])
    
    def test_large_range(self):
        result = rescale_to_unit([0.0, 1000.0])
        expected = [0.0, 1.0]
        assert result == expected
    
    def test_small_range(self):
        result = rescale_to_unit([0.0, 0.001])
        expected = [0.0, 1.0]
        assert result == expected
    
    def test_mixed_positive_negative(self):
        result = rescale_to_unit([-10.0, 0.0, 10.0])
        expected = [0.0, 0.5, 1.0]
        assert result == expected
    
    def test_unsorted_input(self):
        result = rescale_to_unit([5.0, 1.0, 3.0, 2.0, 4.0])
        expected = [1.0, 0.0, 0.5, 0.25, 0.75]
        assert result == expected
    
    def test_decimal_values(self):
        result = rescale_to_unit([1.5, 2.5, 3.5])
        expected = [0.0, 0.5, 1.0]
        assert result == expected
    
    def test_very_close_values(self):
        result = rescale_to_unit([1.0, 1.0000001, 1.0000002])
        assert len(result) == 3
        assert result[0] == 0.0
        assert result[2] == 1.0
    
    def test_single_min_max_pair(self):
        result = rescale_to_unit([10.0, 20.0])
        expected = [0.0, 1.0]
        assert result == expected
    
    def test_negative_to_positive_range(self):
        result = rescale_to_unit([-100.0, 100.0])
        expected = [0.0, 1.0]
        assert result == expected
    
    def test_fractional_numbers(self):
        result = rescale_to_unit([0.1, 0.2, 0.3, 0.4, 0.5])
        expected = [0.0, 0.25, 0.5, 0.75, 1.0]
        for i, (r, e) in enumerate(zip(result, expected)):
            assert abs(r - e) < 1e-9, f"Index {i}: {r} != {e}"
    
    def test_return_type_is_list(self):
        result = rescale_to_unit([1.0, 2.0, 3.0])
        assert isinstance(result, list)
    
    def test_return_length_matches_input(self):
        input_list = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0]
        result = rescale_to_unit(input_list)
        assert len(result) == len(input_list)
    
    def test_first_element_is_zero(self):
        result = rescale_to_unit([5.0, 10.0, 15.0])
        assert result[0] == 0.0
    
    def test_last_element_is_one(self):
        result = rescale_to_unit([5.0, 10.0, 15.0])
        assert result[-1] == 1.0
    
    def test_monotonic_increasing(self):
        result = rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
        for i in range(len(result) - 1):
            assert result[i] <= result[i + 1]
    
    @pytest.mark.parametrize("input_list,expected", [
        ([0.0, 10.0], [0.0, 1.0]),
        ([1.0, 2.0], [0.0, 1.0]),
        ([-5.0, 5.0], [0.0, 1.0]),
        ([100.0, 200.0, 300.0], [0.0, 0.5, 1.0]),
    ])
    def test_parametrized_cases(self, input_list, expected):
        result = rescale_to_unit(input_list)
        assert result == expected