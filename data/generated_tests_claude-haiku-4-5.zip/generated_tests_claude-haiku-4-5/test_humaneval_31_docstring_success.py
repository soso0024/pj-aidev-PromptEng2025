# Test cases for HumanEval/31
# Generated using Claude API



def is_prime(n):
    """Return true if a given number is prime, and false otherwise.
    >>> is_prime(6)
    False
    >>> is_prime(101)
    True
    >>> is_prime(11)
    True
    >>> is_prime(13441)
    True
    >>> is_prime(61)
    True
    >>> is_prime(4)
    False
    >>> is_prime(1)
    False
    """

    if n < 2:
        return False
    for k in range(2, n - 1):
        if n % k == 0:
            return False
    return True


# Generated test cases:
import pytest


def is_prime(n):
    if n < 2:
        return False
    for k in range(2, n - 1):
        if n % k == 0:
            return False
    return True


class TestIsPrime:
    
    @pytest.mark.parametrize("n,expected", [
        (6, False),
        (101, True),
        (11, True),
        (13441, True),
        (61, True),
        (4, False),
        (1, False),
    ])
    def test_docstring_examples(self, n, expected):
        assert is_prime(n) == expected
    
    @pytest.mark.parametrize("n", [0, -1, -5, -100])
    def test_negative_and_zero(self, n):
        assert is_prime(n) is False
    
    @pytest.mark.parametrize("n", [2, 3, 5, 7, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47])
    def test_small_primes(self, n):
        assert is_prime(n) is True
    
    @pytest.mark.parametrize("n", [4, 6, 8, 9, 10, 12, 14, 15, 16, 18, 20, 21, 22, 24, 25, 26, 27, 28])
    def test_small_composites(self, n):
        assert is_prime(n) is False
    
    @pytest.mark.parametrize("n", [97, 103, 107, 109, 113, 127, 131, 137, 139, 149])
    def test_larger_primes(self, n):
        assert is_prime(n) is True
    
    @pytest.mark.parametrize("n", [100, 102, 104, 105, 106, 108, 110, 111, 112, 114, 115, 116, 117, 118, 119, 120])
    def test_larger_composites(self, n):
        assert is_prime(n) is False
    
    def test_two_is_prime(self):
        assert is_prime(2) is True
    
    def test_three_is_prime(self):
        assert is_prime(3) is True
    
    def test_one_is_not_prime(self):
        assert is_prime(1) is False
    
    def test_perfect_squares(self):
        assert is_prime(4) is False
        assert is_prime(9) is False
        assert is_prime(25) is False
        assert is_prime(49) is False
        assert is_prime(121) is False
    
    def test_even_numbers(self):
        assert is_prime(2) is True
        assert is_prime(4) is False
        assert is_prime(6) is False
        assert is_prime(8) is False
        assert is_prime(10) is False
    
    def test_twin_primes(self):
        assert is_prime(11) is True
        assert is_prime(13) is True
        assert is_prime(17) is True
        assert is_prime(19) is True
        assert is_prime(29) is True
        assert is_prime(31) is True
    
    def test_mersenne_like_numbers(self):
        assert is_prime(127) is True
        assert is_prime(128) is False
        assert is_prime(255) is False
        assert is_prime(256) is False
