# Test cases for HumanEval/100
# Generated using Claude API


def make_a_pile(n):
    """
    Given a positive integer n, you have to make a pile of n levels of stones.
    The first level has n stones.
    The number of stones in the next level is:
        - the next odd number if n is odd.
        - the next even number if n is even.
    Return the number of stones in each level in a list, where element at index
    i represents the number of stones in the level (i+1).

    Examples:
    >>> make_a_pile(3)
    [3, 5, 7]
    """

    return [n + 2*i for i in range(n)]


# Generated test cases:
import pytest


def make_a_pile(n):
    return [n + 2*i for i in range(n)]


class TestMakeAPile:
    
    def test_example_case_n_3(self):
        assert make_a_pile(3) == [3, 5, 7]
    
    def test_n_1(self):
        assert make_a_pile(1) == [1]
    
    def test_n_2(self):
        assert make_a_pile(2) == [2, 4]
    
    def test_n_4(self):
        assert make_a_pile(4) == [4, 6, 8, 10]
    
    def test_n_5(self):
        assert make_a_pile(5) == [5, 7, 9, 11, 13]
    
    def test_n_10(self):
        assert make_a_pile(10) == [10, 12, 14, 16, 18, 20, 22, 24, 26, 28]
    
    def test_large_n(self):
        result = make_a_pile(100)
        assert len(result) == 100
        assert result[0] == 100
        assert result[-1] == 100 + 2 * 99
        assert result[-1] == 298
    
    def test_return_type_is_list(self):
        result = make_a_pile(5)
        assert isinstance(result, list)
    
    def test_list_length_equals_n(self):
        for n in [1, 2, 3, 5, 10, 20]:
            assert len(make_a_pile(n)) == n
    
    def test_arithmetic_progression(self):
        result = make_a_pile(6)
        for i in range(len(result) - 1):
            assert result[i + 1] - result[i] == 2
    
    def test_first_element_is_n(self):
        for n in [1, 2, 3, 5, 10, 15]:
            assert make_a_pile(n)[0] == n
    
    def test_odd_n_produces_odd_sequence(self):
        result = make_a_pile(3)
        for stone_count in result:
            assert stone_count % 2 == 1
    
    def test_even_n_produces_even_sequence(self):
        result = make_a_pile(4)
        for stone_count in result:
            assert stone_count % 2 == 0
    
    def test_n_7(self):
        result = make_a_pile(7)
        assert result == [7, 9, 11, 13, 15, 17, 19]
    
    def test_n_8(self):
        result = make_a_pile(8)
        assert result == [8, 10, 12, 14, 16, 18, 20, 22]
    
    def test_consecutive_differences(self):
        result = make_a_pile(15)
        for i in range(len(result) - 1):
            assert result[i + 1] - result[i] == 2
    
    def test_formula_verification(self):
        n = 12
        result = make_a_pile(n)
        for i in range(n):
            assert result[i] == n + 2 * i
    
    def test_very_large_n(self):
        result = make_a_pile(1000)
        assert len(result) == 1000
        assert result[0] == 1000
        assert result[999] == 1000 + 2 * 999
        assert result[999] == 2998


@pytest.mark.parametrize("n,expected", [
    (1, [1]),
    (2, [2, 4]),
    (3, [3, 5, 7]),
    (4, [4, 6, 8, 10]),
    (5, [5, 7, 9, 11, 13]),
    (6, [6, 8, 10, 12, 14, 16]),
])
def test_make_a_pile_parametrized(n, expected):
    assert make_a_pile(n) == expected


@pytest.mark.parametrize("n", [1, 2, 3, 5, 7, 10, 15, 20, 50, 100])
def test_make_a_pile_length(n):
    assert len(make_a_pile(n)) == n


@pytest.mark.parametrize("n", [1, 3, 5, 7, 9, 11])
def test_make_a_pile_odd_n_all_odd(n):
    result = make_a_pile(n)
    assert all(x % 2 == 1 for x in result)


@pytest.mark.parametrize("n", [2, 4, 6, 8, 10, 12])
def test_make_a_pile_even_n_all_even(n):
    result = make_a_pile(n)
    assert all(x % 2 == 0 for x in result)
