# Test cases for HumanEval/20
# Generated using Claude API

from typing import List, Tuple


def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    """ From a supplied list of numbers (of length at least two) select and return two that are the closest to each
    other and return them in order (smaller number, larger number).
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.2])
    (2.0, 2.2)
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.0])
    (2.0, 2.0)
    """

    closest_pair = None
    distance = None

    for idx, elem in enumerate(numbers):
        for idx2, elem2 in enumerate(numbers):
            if idx != idx2:
                if distance is None:
                    distance = abs(elem - elem2)
                    closest_pair = tuple(sorted([elem, elem2]))
                else:
                    new_distance = abs(elem - elem2)
                    if new_distance < distance:
                        distance = new_distance
                        closest_pair = tuple(sorted([elem, elem2]))

    return closest_pair


# Generated test cases:
import pytest
from typing import List, Tuple


def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    closest_pair = None
    distance = None

    for idx, elem in enumerate(numbers):
        for idx2, elem2 in enumerate(numbers):
            if idx != idx2:
                if distance is None:
                    distance = abs(elem - elem2)
                    closest_pair = tuple(sorted([elem, elem2]))
                else:
                    new_distance = abs(elem - elem2)
                    if new_distance < distance:
                        distance = new_distance
                        closest_pair = tuple(sorted([elem, elem2]))

    return closest_pair


class TestFindClosestElements:
    
    def test_two_elements(self):
        result = find_closest_elements([1.0, 2.0])
        assert result == (1.0, 2.0)
    
    def test_two_identical_elements(self):
        result = find_closest_elements([5.0, 5.0])
        assert result == (5.0, 5.0)
    
    def test_three_elements_closest_at_start(self):
        result = find_closest_elements([1.0, 1.1, 10.0])
        assert result == (1.0, 1.1)
    
    def test_three_elements_closest_at_end(self):
        result = find_closest_elements([1.0, 10.0, 10.1])
        assert result == (10.0, 10.1)
    
    def test_three_elements_closest_in_middle(self):
        result = find_closest_elements([1.0, 5.0, 5.05])
        assert result == (5.0, 5.05)
    
    def test_negative_numbers(self):
        result = find_closest_elements([-5.0, -4.9, 10.0])
        assert result == (-5.0, -4.9)
    
    def test_mixed_positive_negative(self):
        result = find_closest_elements([-1.0, 0.0, 1.0])
        assert result == (-1.0, 0.0) or result == (0.0, 1.0)
    
    def test_large_list(self):
        numbers = [1.0, 2.0, 3.0, 4.0, 5.0, 5.1, 10.0]
        result = find_closest_elements(numbers)
        assert result == (5.0, 5.1)
    
    def test_very_close_floats(self):
        result = find_closest_elements([1.0, 1.0000001, 2.0])
        assert result == (1.0, 1.0000001)
    
    def test_unsorted_input(self):
        result = find_closest_elements([10.0, 1.0, 5.0, 5.1])
        assert result == (5.0, 5.1)
    
    def test_duplicate_pairs(self):
        result = find_closest_elements([1.0, 2.0, 2.0, 3.0])
        assert result == (2.0, 2.0)
    
    def test_all_same_elements(self):
        result = find_closest_elements([5.0, 5.0, 5.0])
        assert result == (5.0, 5.0)
    
    def test_negative_floats(self):
        result = find_closest_elements([-10.5, -10.4, -5.0])
        assert result == (-10.5, -10.4)
    
    def test_zero_included(self):
        result = find_closest_elements([0.0, 0.1, 1.0])
        assert result == (0.0, 0.1)
    
    def test_large_numbers(self):
        result = find_closest_elements([1000000.0, 1000001.0, 2000000.0])
        assert result == (1000000.0, 1000001.0)
    
    def test_small_decimal_differences(self):
        result = find_closest_elements([0.001, 0.002, 0.1])
        assert result == (0.001, 0.002)
    
    def test_four_elements(self):
        result = find_closest_elements([1.0, 2.0, 2.5, 3.0])
        assert result == (2.0, 2.5)
    
    def test_result_is_sorted_tuple(self):
        result = find_closest_elements([5.0, 1.0])
        assert isinstance(result, tuple)
        assert len(result) == 2
        assert result[0] <= result[1]
    
    def test_five_elements_with_closest_pair(self):
        result = find_closest_elements([1.0, 3.0, 3.01, 5.0, 10.0])
        assert result == (3.0, 3.01)
    
    def test_negative_and_positive_close(self):
        result = find_closest_elements([-0.5, 0.5, 10.0])
        assert result == (-0.5, 0.5)


@pytest.mark.parametrize("numbers,expected", [
    ([1.0, 2.0], (1.0, 2.0)),
    ([5.0, 5.0], (5.0, 5.0)),
    ([1.0, 1.1, 10.0], (1.0, 1.1)),
    ([-5.0, -4.9, 10.0], (-5.0, -4.9)),
    ([10.0, 1.0, 5.0, 5.1], (5.0, 5.1)),
    ([1.0, 2.0, 2.0, 3.0], (2.0, 2.0)),
    ([5.0, 5.0, 5.0], (5.0, 5.0)),
    ([0.0, 0.1, 1.0], (0.0, 0.1)),
])
def test_find_closest_elements_parametrized(numbers, expected):
    result = find_closest_elements(numbers)
    assert result == expected


def test_find_closest_elements_returns_tuple():
    result = find_closest_elements([1.0, 2.0, 3.0])
    assert isinstance(result, tuple)


def test_find_closest_elements_tuple_length():
    result = find_closest_elements([1.0, 2.0, 3.0])
    assert len(result) == 2


def test_find_closest_elements_sorted_output():
    result = find_closest_elements([10.0, 1.0, 5.0])
    assert result[0] <= result[1]
