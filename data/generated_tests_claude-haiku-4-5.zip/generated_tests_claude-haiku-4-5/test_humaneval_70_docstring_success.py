# Test cases for HumanEval/70
# Generated using Claude API


def strange_sort_list(lst):
    '''
    Given list of integers, return list in strange order.
    Strange sorting, is when you start with the minimum value,
    then maximum of the remaining integers, then minimum and so on.

    Examples:
    strange_sort_list([1, 2, 3, 4]) == [1, 4, 2, 3]
    strange_sort_list([5, 5, 5, 5]) == [5, 5, 5, 5]
    strange_sort_list([]) == []
    '''

    res, switch = [], True
    while lst:
        res.append(min(lst) if switch else max(lst))
        lst.remove(res[-1])
        switch = not switch
    return res


# Generated test cases:
import pytest


def strange_sort_list(lst):
    res, switch = [], True
    while lst:
        res.append(min(lst) if switch else max(lst))
        lst.remove(res[-1])
        switch = not switch
    return res


class TestStrangeSortList:
    
    def test_basic_example_1(self):
        assert strange_sort_list([1, 2, 3, 4]) == [1, 4, 2, 3]
    
    def test_basic_example_2(self):
        assert strange_sort_list([5, 5, 5, 5]) == [5, 5, 5, 5]
    
    def test_empty_list(self):
        assert strange_sort_list([]) == []
    
    def test_single_element(self):
        assert strange_sort_list([1]) == [1]
    
    def test_two_elements(self):
        assert strange_sort_list([1, 2]) == [1, 2]
    
    def test_two_elements_reversed(self):
        assert strange_sort_list([2, 1]) == [1, 2]
    
    def test_negative_numbers(self):
        assert strange_sort_list([-1, -2, -3, -4]) == [-4, -1, -3, -2]
    
    def test_mixed_positive_negative(self):
        assert strange_sort_list([-2, 1, 3, -1]) == [-2, 3, -1, 1]
    
    def test_unsorted_list(self):
        assert strange_sort_list([3, 1, 4, 1, 5, 9, 2, 6]) == [1, 9, 1, 6, 2, 5, 3, 4]
    
    def test_duplicates(self):
        assert strange_sort_list([1, 1, 2, 2, 3, 3]) == [1, 3, 1, 3, 2, 2]
    
    def test_all_same_elements(self):
        assert strange_sort_list([7, 7, 7]) == [7, 7, 7]
    
    def test_large_numbers(self):
        assert strange_sort_list([1000, 2000, 3000]) == [1000, 3000, 2000]
    
    def test_zero_included(self):
        assert strange_sort_list([0, 1, 2, 3]) == [0, 3, 1, 2]
    
    def test_negative_zero_positive(self):
        assert strange_sort_list([-5, 0, 5]) == [-5, 5, 0]
    
    def test_five_elements(self):
        assert strange_sort_list([5, 4, 3, 2, 1]) == [1, 5, 2, 4, 3]
    
    def test_six_elements(self):
        assert strange_sort_list([6, 5, 4, 3, 2, 1]) == [1, 6, 2, 5, 3, 4]
    
    def test_already_sorted(self):
        assert strange_sort_list([1, 2, 3, 4, 5]) == [1, 5, 2, 4, 3]
    
    def test_reverse_sorted(self):
        assert strange_sort_list([5, 4, 3, 2, 1]) == [1, 5, 2, 4, 3]
    
    def test_with_duplicates_at_extremes(self):
        assert strange_sort_list([1, 1, 5, 5]) == [1, 5, 1, 5]
    
    def test_three_elements(self):
        assert strange_sort_list([1, 2, 3]) == [1, 3, 2]


@pytest.mark.parametrize("input_list,expected", [
    ([1, 2, 3, 4], [1, 4, 2, 3]),
    ([5, 5, 5, 5], [5, 5, 5, 5]),
    ([], []),
    ([1], [1]),
    ([2, 1], [1, 2]),
    ([-1, -2, -3, -4], [-4, -1, -3, -2]),
    ([0, 1, 2, 3], [0, 3, 1, 2]),
    ([10, 20, 30, 40, 50], [10, 50, 20, 40, 30]),
])
def test_strange_sort_list_parametrized(input_list, expected):
    assert strange_sort_list(input_list) == expected
