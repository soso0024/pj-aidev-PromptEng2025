# Test cases for HumanEval/97
# Generated using Claude API


def multiply(a, b):
    """Complete the function that takes two integers and returns 
    the product of their unit digits.
    Assume the input is always valid.
    Examples:
    multiply(148, 412) should return 16.
    multiply(19, 28) should return 72.
    multiply(2020, 1851) should return 0.
    multiply(14,-15) should return 20.
    """

    return abs(a % 10) * abs(b % 10)


# Generated test cases:
import pytest


class TestMultiply:
    
    def test_positive_single_digits(self):
        from solution import multiply
        assert multiply(3, 4) == 12
    
    def test_positive_double_digits(self):
        assert multiply(23, 45) == 15
    
    def test_positive_double_digits_result_zero(self):
        assert multiply(20, 35) == 0
    
    def test_negative_single_digits(self):
        assert multiply(-3, -4) == 12
    
    def test_negative_and_positive_mix(self):
        assert multiply(-3, 4) == 12
    
    def test_negative_double_digits(self):
        assert multiply(-23, -45) == 15
    
    def test_zero_first_argument(self):
        assert multiply(0, 5) == 0
    
    def test_zero_second_argument(self):
        assert multiply(5, 0) == 0
    
    def test_both_zero(self):
        assert multiply(0, 0) == 0
    
    def test_one_first_argument(self):
        assert multiply(1, 5) == 5
    
    def test_one_second_argument(self):
        assert multiply(5, 1) == 5
    
    def test_both_one(self):
        assert multiply(1, 1) == 1
    
    def test_ten_first_argument(self):
        assert multiply(10, 5) == 0
    
    def test_ten_second_argument(self):
        assert multiply(5, 10) == 0
    
    def test_both_ten(self):
        assert multiply(10, 10) == 0
    
    def test_negative_zero_modulo(self):
        assert multiply(-10, 5) == 0
    
    def test_large_positive_numbers(self):
        assert multiply(123, 456) == 18
    
    def test_large_negative_numbers(self):
        assert multiply(-123, -456) == 18
    
    def test_nine_and_nine(self):
        assert multiply(9, 9) == 81
    
    def test_negative_nine_and_nine(self):
        assert multiply(-9, 9) == 81
    
    def test_last_digit_extraction(self):
        assert multiply(17, 23) == 21
    
    def test_negative_with_last_digit_zero(self):
        assert multiply(-30, 45) == 0
    
    def test_very_large_numbers(self):
        assert multiply(999999, 888888) == 72
    
    def test_negative_very_large_numbers(self):
        assert multiply(-999999, -888888) == 72
    
    @pytest.mark.parametrize("a,b,expected", [
        (5, 7, 35),
        (12, 34, 8),
        (-5, 7, 35),
        (5, -7, 35),
        (-5, -7, 35),
        (0, 100, 0),
        (100, 0, 0),
        (11, 11, 1),
        (99, 99, 81),
        (25, 36, 30),
    ])
    def test_parametrized_cases(self, a, b, expected):
        assert multiply(a, b) == expected