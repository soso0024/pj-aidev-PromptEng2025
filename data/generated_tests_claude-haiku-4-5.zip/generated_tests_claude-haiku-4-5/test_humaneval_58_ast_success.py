# Test cases for HumanEval/58
# Generated using Claude API



def common(l1: list, l2: list):
    """Return sorted unique common elements for two lists.
    >>> common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121])
    [1, 5, 653]
    >>> common([5, 3, 2, 8], [3, 2])
    [2, 3]

    """

    ret = set()
    for e1 in l1:
        for e2 in l2:
            if e1 == e2:
                ret.add(e1)
    return sorted(list(ret))


# Generated test cases:
import pytest


def common(l1: list, l2: list):
    ret = set()
    for e1 in l1:
        for e2 in l2:
            if e1 == e2:
                ret.add(e1)
    return sorted(list(ret))


class TestCommon:
    def test_empty_lists(self):
        assert common([], []) == []

    def test_first_list_empty(self):
        assert common([], [1, 2, 3]) == []

    def test_second_list_empty(self):
        assert common([1, 2, 3], []) == []

    def test_no_common_elements(self):
        assert common([1, 2, 3], [4, 5, 6]) == []

    def test_all_common_elements(self):
        assert common([1, 2, 3], [1, 2, 3]) == [1, 2, 3]

    def test_partial_common_elements(self):
        assert common([1, 2, 3, 4], [3, 4, 5, 6]) == [3, 4]

    def test_single_common_element(self):
        assert common([1, 2, 3], [3, 4, 5]) == [3]

    def test_duplicates_in_first_list(self):
        assert common([1, 1, 2, 2, 3], [2, 3, 4]) == [2, 3]

    def test_duplicates_in_second_list(self):
        assert common([1, 2, 3], [2, 2, 3, 3, 4]) == [2, 3]

    def test_duplicates_in_both_lists(self):
        assert common([1, 1, 2, 2], [2, 2, 3, 3]) == [2]

    def test_result_is_sorted(self):
        assert common([5, 3, 1, 4, 2], [2, 4, 1, 5, 3]) == [1, 2, 3, 4, 5]

    def test_strings(self):
        assert common(['a', 'b', 'c'], ['b', 'c', 'd']) == ['b', 'c']

    def test_mixed_types_no_common(self):
        assert common([1, 2, 3], ['1', '2', '3']) == []

    def test_negative_numbers(self):
        assert common([-1, -2, -3], [-2, -3, -4]) == [-3, -2]

    def test_floats(self):
        assert common([1.5, 2.5, 3.5], [2.5, 3.5, 4.5]) == [2.5, 3.5]

    def test_single_element_lists_match(self):
        assert common([5], [5]) == [5]

    def test_single_element_lists_no_match(self):
        assert common([5], [6]) == []

    def test_large_lists(self):
        l1 = list(range(1000))
        l2 = list(range(500, 1500))
        result = common(l1, l2)
        assert result == list(range(500, 1000))

    def test_zero_in_lists(self):
        assert common([0, 1, 2], [0, 3, 4]) == [0]

    def test_boolean_values(self):
        assert common([True, False], [True, 1]) == [True]

    def test_none_values(self):
        assert common([None, 1, 2], [None, 3, 4]) == [None]

    def test_result_type_is_list(self):
        result = common([1, 2], [2, 3])
        assert isinstance(result, list)

    def test_result_contains_no_duplicates(self):
        result = common([1, 1, 1], [1, 1, 1])
        assert result == [1]
        assert len(result) == 1

    @pytest.mark.parametrize("l1,l2,expected", [
        ([1, 2, 3], [2, 3, 4], [2, 3]),
        ([10, 20, 30], [20, 30, 40], [20, 30]),
        (['x', 'y', 'z'], ['y', 'z', 'w'], ['y', 'z']),
        ([1], [1], [1]),
        ([], [], []),
    ])
    def test_parametrized_cases(self, l1, l2, expected):
        assert common(l1, l2) == expected
