# Test cases for HumanEval/86
# Generated using Claude API


def anti_shuffle(s):
    """
    Write a function that takes a string and returns an ordered version of it.
    Ordered version of string, is a string where all words (separated by space)
    are replaced by a new word where all the characters arranged in
    ascending order based on ascii value.
    Note: You should keep the order of words and blank spaces in the sentence.

    For example:
    anti_shuffle('Hi') returns 'Hi'
    anti_shuffle('hello') returns 'ehllo'
    anti_shuffle('Hello World!!!') returns 'Hello !!!Wdlor'
    """

    return ' '.join([''.join(sorted(list(i))) for i in s.split(' ')])


# Generated test cases:
import pytest


class TestAntiShuffle:
    
    def anti_shuffle(self, s):
        return ' '.join([''.join(sorted(list(i))) for i in s.split(' ')])
    
    def test_single_word_already_sorted(self):
        assert self.anti_shuffle('Hi') == 'Hi'
    
    def test_single_word_needs_sorting(self):
        assert self.anti_shuffle('hello') == 'ehllo'
    
    def test_multiple_words_with_punctuation(self):
        assert self.anti_shuffle('Hello World!!!') == 'Hello !!!Wdlor'
    
    def test_empty_string(self):
        assert self.anti_shuffle('') == ''
    
    def test_single_character(self):
        assert self.anti_shuffle('a') == 'a'
    
    def test_single_space(self):
        assert self.anti_shuffle(' ') == ' '
    
    def test_multiple_spaces(self):
        assert self.anti_shuffle('a  b') == 'a  b'
    
    def test_word_with_numbers(self):
        assert self.anti_shuffle('abc123') == '123abc'
    
    def test_word_with_special_characters(self):
        assert self.anti_shuffle('!@#abc') == '!#@abc'
    
    def test_mixed_case_letters(self):
        assert self.anti_shuffle('BaC') == 'BCa'
    
    def test_multiple_words(self):
        assert self.anti_shuffle('the quick brown') == 'eht cikqu bnorw'
    
    def test_word_with_spaces_at_start(self):
        assert self.anti_shuffle(' hello') == ' ehllo'
    
    def test_word_with_spaces_at_end(self):
        assert self.anti_shuffle('hello ') == 'ehllo '
    
    def test_word_with_spaces_at_both_ends(self):
        assert self.anti_shuffle(' hello ') == ' ehllo '
    
    def test_all_same_characters(self):
        assert self.anti_shuffle('aaaa') == 'aaaa'
    
    def test_reverse_order_characters(self):
        assert self.anti_shuffle('dcba') == 'abcd'
    
    def test_ascii_ordering_with_symbols(self):
        assert self.anti_shuffle('z!a') == '!az'
    
    def test_sentence_with_multiple_spaces_between_words(self):
        assert self.anti_shuffle('hello  world') == 'ehllo  dlorw'
    
    def test_single_space_between_words(self):
        assert self.anti_shuffle('a b c') == 'a b c'
    
    def test_complex_sentence(self):
        assert self.anti_shuffle('The Quick Brown Fox') == 'Teh Qciku Bnorw Fox'
    
    def test_numbers_and_letters_mixed(self):
        assert self.anti_shuffle('a1b2c3') == '123abc'
    
    def test_uppercase_letters_come_before_lowercase(self):
        result = self.anti_shuffle('aA')
        assert result == 'Aa'
    
    def test_punctuation_at_different_positions(self):
        assert self.anti_shuffle('a!b@c#') == '!#@abc'
    
    def test_only_spaces(self):
        assert self.anti_shuffle('   ') == '   '
    
    def test_tab_character_treated_as_regular_character(self):
        result = self.anti_shuffle('a\tb')
        assert '\t' in result
    
    def test_newline_character_treated_as_regular_character(self):
        result = self.anti_shuffle('a\nb')
        assert '\n' in result
    
    @pytest.mark.parametrize("input_str,expected", [
        ('', ''),
        ('a', 'a'),
        ('ab', 'ab'),
        ('ba', 'ab'),
        ('hello world', 'ehllo dlorw'),
        ('zyx', 'xyz'),
        ('123', '123'),
        ('cba', 'abc'),
    ])
    def test_parametrized_cases(self, input_str, expected):
        assert self.anti_shuffle(input_str) == expected