# Test cases for HumanEval/100
# Generated using Claude API


def make_a_pile(n):
    """
    Given a positive integer n, you have to make a pile of n levels of stones.
    The first level has n stones.
    The number of stones in the next level is:
        - the next odd number if n is odd.
        - the next even number if n is even.
    Return the number of stones in each level in a list, where element at index
    i represents the number of stones in the level (i+1).

    Examples:
    >>> make_a_pile(3)
    [3, 5, 7]
    """

    return [n + 2*i for i in range(n)]


# Generated test cases:
import pytest


def make_a_pile(n):
    return [n + 2*i for i in range(n)]


class TestMakeAPile:
    def test_zero(self):
        assert make_a_pile(0) == []
    
    def test_one(self):
        assert make_a_pile(1) == [1]
    
    def test_two(self):
        assert make_a_pile(2) == [2, 4]
    
    def test_three(self):
        assert make_a_pile(3) == [3, 5, 7]
    
    def test_four(self):
        assert make_a_pile(4) == [4, 6, 8, 10]
    
    def test_five(self):
        assert make_a_pile(5) == [5, 7, 9, 11, 13]
    
    def test_ten(self):
        assert make_a_pile(10) == [10, 12, 14, 16, 18, 20, 22, 24, 26, 28]
    
    def test_large_number(self):
        result = make_a_pile(100)
        assert len(result) == 100
        assert result[0] == 100
        assert result[-1] == 100 + 2*99
        assert result[-1] == 298
    
    def test_arithmetic_sequence(self):
        result = make_a_pile(7)
        assert len(result) == 7
        for i in range(1, len(result)):
            assert result[i] - result[i-1] == 2
    
    def test_first_element_equals_n(self):
        for n in range(1, 20):
            assert make_a_pile(n)[0] == n
    
    def test_length_equals_n(self):
        for n in range(0, 20):
            assert len(make_a_pile(n)) == n
    
    def test_returns_list(self):
        assert isinstance(make_a_pile(5), list)
    
    def test_all_elements_are_integers(self):
        result = make_a_pile(10)
        for element in result:
            assert isinstance(element, int)
    
    def test_elements_are_increasing(self):
        result = make_a_pile(15)
        for i in range(1, len(result)):
            assert result[i] > result[i-1]
    
    @pytest.mark.parametrize("n,expected", [
        (0, []),
        (1, [1]),
        (2, [2, 4]),
        (3, [3, 5, 7]),
        (4, [4, 6, 8, 10]),
        (5, [5, 7, 9, 11, 13]),
        (6, [6, 8, 10, 12, 14, 16]),
    ])
    def test_parametrized_cases(self, n, expected):
        assert make_a_pile(n) == expected
    
    def test_formula_verification(self):
        n = 8
        result = make_a_pile(n)
        for i in range(n):
            assert result[i] == n + 2*i
    
    def test_negative_input_returns_empty(self):
        assert make_a_pile(-1) == []
    
    def test_negative_input_large(self):
        assert make_a_pile(-10) == []
