# Test cases for HumanEval/116
# Generated using Claude API


def sort_array(arr):
    """
    In this Kata, you have to sort an array of non-negative integers according to
    number of ones in their binary representation in ascending order.
    For similar number of ones, sort based on decimal value.

    It must be implemented like this:
    >>> sort_array([1, 5, 2, 3, 4]) == [1, 2, 3, 4, 5]
    >>> sort_array([-2, -3, -4, -5, -6]) == [-6, -5, -4, -3, -2]
    >>> sort_array([1, 0, 2, 3, 4]) [0, 1, 2, 3, 4]
    """

    return sorted(sorted(arr), key=lambda x: bin(x)[2:].count('1'))


# Generated test cases:
import pytest


class TestSortArray:
    
    def sort_array(self, arr):
        return sorted(sorted(arr), key=lambda x: bin(x)[2:].count('1'))
    
    def test_basic_example(self):
        assert self.sort_array([1, 5, 2, 3, 4]) == [1, 2, 3, 4, 5]
    
    def test_negative_numbers(self):
        assert self.sort_array([-2, -3, -4, -5, -6]) == [-6, -5, -4, -3, -2]
    
    def test_with_zero(self):
        assert self.sort_array([1, 0, 2, 3, 4]) == [0, 1, 2, 3, 4]
    
    def test_empty_array(self):
        assert self.sort_array([]) == []
    
    def test_single_element(self):
        assert self.sort_array([5]) == [5]
    
    def test_all_same_number(self):
        assert self.sort_array([3, 3, 3]) == [3, 3, 3]
    
    def test_zero_only(self):
        assert self.sort_array([0, 0, 0]) == [0, 0, 0]
    
    def test_powers_of_two(self):
        assert self.sort_array([1, 2, 4, 8, 16]) == [1, 2, 4, 8, 16]
    
    def test_same_bit_count_different_values(self):
        result = self.sort_array([3, 5, 6])
        assert result == [3, 5, 6]
    
    def test_mixed_positive_and_negative(self):
        result = self.sort_array([1, -1, 2, -2, 3, -3])
        assert len(result) == 6
    
    def test_large_numbers(self):
        result = self.sort_array([255, 127, 63, 31, 15, 7, 3, 1])
        assert result[0] == 1
    
    def test_numbers_with_many_ones(self):
        result = self.sort_array([15, 7, 3, 1])
        assert result == [1, 3, 7, 15]
    
    def test_unsorted_input(self):
        result = self.sort_array([10, 5, 3, 8, 1])
        assert len(result) == 5
    
    def test_duplicate_values(self):
        result = self.sort_array([5, 5, 3, 3, 1, 1])
        assert result == [1, 1, 3, 3, 5, 5]
    
    def test_binary_representation_sorting(self):
        result = self.sort_array([6, 5, 3])
        assert result == [3, 5, 6]
    
    def test_zero_with_others(self):
        result = self.sort_array([0, 1, 2, 4, 8])
        assert result[0] == 0
    
    def test_negative_zero_equivalence(self):
        result = self.sort_array([0, -0])
        assert len(result) == 2
    
    def test_large_array(self):
        arr = list(range(100))
        result = self.sort_array(arr)
        assert len(result) == 100
    
    def test_bit_count_ordering(self):
        result = self.sort_array([7, 11, 13, 14])
        bit_counts = [bin(x).count('1') for x in result]
        assert bit_counts == sorted(bit_counts)
    
    @pytest.mark.parametrize("input_arr,expected", [
        ([1], [1]),
        ([0], [0]),
        ([1, 2], [1, 2]),
        ([2, 1], [1, 2]),
        ([3, 1, 2], [1, 2, 3]),
        ([7, 4, 2, 1], [1, 2, 4, 7]),
    ])
    def test_parametrized_cases(self, input_arr, expected):
        assert self.sort_array(input_arr) == expected