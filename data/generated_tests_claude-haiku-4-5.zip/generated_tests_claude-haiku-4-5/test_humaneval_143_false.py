# Test cases for HumanEval/143
# Generated using Claude API


def words_in_sentence(sentence):
    """
    You are given a string representing a sentence,
    the sentence contains some words separated by a space,
    and you have to return a string that contains the words from the original sentence,
    whose lengths are prime numbers,
    the order of the words in the new string should be the same as the original one.

    Example 1:
        Input: sentence = "This is a test"
        Output: "is"

    Example 2:
        Input: sentence = "lets go for swimming"
        Output: "go for"

    Constraints:
        * 1 <= len(sentence) <= 100
        * sentence contains only letters
    """

    new_lst = []
    for word in sentence.split():
        flg = 0
        if len(word) == 1:
            flg = 1
        for i in range(2, len(word)):
            if len(word)%i == 0:
                flg = 1
        if flg == 0 or len(word) == 2:
            new_lst.append(word)
    return " ".join(new_lst)


# Generated test cases:
import pytest


class TestWordsInSentence:
    
    def words_in_sentence(self, sentence):
        new_lst = []
        for word in sentence.split():
            flg = 0
            if len(word) == 1:
                flg = 1
            for i in range(2, len(word)):
                if len(word)%i == 0:
                    flg = 1
            if flg == 0 or len(word) == 2:
                new_lst.append(word)
        return " ".join(new_lst)
    
    def test_empty_string(self):
        assert self.words_in_sentence("") == ""
    
    def test_single_word_length_one(self):
        assert self.words_in_sentence("a") == ""
    
    def test_single_word_length_two(self):
        assert self.words_in_sentence("ab") == "ab"
    
    def test_single_word_prime_length(self):
        assert self.words_in_sentence("abc") == "abc"
    
    def test_single_word_composite_length(self):
        assert self.words_in_sentence("abcd") == ""
    
    def test_multiple_words_mixed(self):
        assert self.words_in_sentence("a ab abc abcd") == "ab abc"
    
    def test_all_single_letters(self):
        assert self.words_in_sentence("a b c d e") == ""
    
    def test_all_two_letter_words(self):
        assert self.words_in_sentence("ab cd ef gh") == "ab cd ef gh"
    
    def test_all_prime_length_words(self):
        assert self.words_in_sentence("abc defg hijklm") == "abc"
    
    def test_all_composite_length_words(self):
        assert self.words_in_sentence("abcd abcdef abcdefgh") == ""
    
    def test_word_length_five_prime(self):
        assert self.words_in_sentence("abcde") == "abcde"
    
    def test_word_length_six_composite(self):
        assert self.words_in_sentence("abcdef") == ""
    
    def test_word_length_seven_prime(self):
        assert self.words_in_sentence("abcdefg") == "abcdefg"
    
    def test_word_length_eight_composite(self):
        assert self.words_in_sentence("abcdefgh") == ""
    
    def test_word_length_nine_composite(self):
        assert self.words_in_sentence("abcdefghi") == ""
    
    def test_word_length_eleven_prime(self):
        assert self.words_in_sentence("abcdefghijk") == "abcdefghijk"
    
    def test_mixed_sentence_complex(self):
        assert self.words_in_sentence("I am learning Python") == "am"
    
    def test_sentence_with_punctuation_attached(self):
        assert self.words_in_sentence("hello world") == "hello world"
    
    def test_sentence_with_numbers(self):
        assert self.words_in_sentence("a1 ab abc1 abcd") == "a1 ab"
    
    def test_very_long_prime_word(self):
        assert self.words_in_sentence("abcdefghijklm") == "abcdefghijklm"
    
    def test_very_long_composite_word(self):
        assert self.words_in_sentence("abcdefghijklmn") == ""
    
    def test_multiple_spaces_between_words(self):
        result = self.words_in_sentence("ab  cd")
        assert "ab" in result and "cd" in result
    
    def test_word_length_four_composite(self):
        assert self.words_in_sentence("abcd") == ""
    
    def test_word_length_ten_composite(self):
        assert self.words_in_sentence("abcdefghij") == ""
    
    def test_word_length_twelve_composite(self):
        assert self.words_in_sentence("abcdefghijkl") == ""
    
    @pytest.mark.parametrize("sentence,expected", [
        ("a", ""),
        ("ab", "ab"),
        ("abc", "abc"),
        ("abcd", ""),
        ("abcde", "abcde"),
        ("abcdef", ""),
        ("ab cd ef", "ab cd ef"),
        ("abc def ghi", "abc"),
        ("abcd efgh ijkl", ""),
        ("a ab abc abcd abcde", "ab abc abcde"),
    ])
    def test_parametrized_cases(self, sentence, expected):
        assert self.words_in_sentence(sentence) == expected