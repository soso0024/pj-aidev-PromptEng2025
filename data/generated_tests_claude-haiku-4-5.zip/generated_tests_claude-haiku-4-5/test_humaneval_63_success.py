# Test cases for HumanEval/63
# Generated using Claude API



def fibfib(n: int):
    """The FibFib number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fibfib(0) == 0
    fibfib(1) == 0
    fibfib(2) == 1
    fibfib(n) == fibfib(n-1) + fibfib(n-2) + fibfib(n-3).
    Please write a function to efficiently compute the n-th element of the fibfib number sequence.
    >>> fibfib(1)
    0
    >>> fibfib(5)
    4
    >>> fibfib(8)
    24
    """

    if n == 0:
        return 0
    if n == 1:
        return 0
    if n == 2:
        return 1
    return fibfib(n - 1) + fibfib(n - 2) + fibfib(n - 3)


# Generated test cases:
import pytest


def fibfib(n: int):
    if n == 0:
        return 0
    if n == 1:
        return 0
    if n == 2:
        return 1
    return fibfib(n - 1) + fibfib(n - 2) + fibfib(n - 3)


class TestFibfib:
    
    @pytest.mark.parametrize("n,expected", [
        (0, 0),
        (1, 0),
        (2, 1),
        (3, 1),
        (4, 2),
        (5, 4),
        (6, 7),
        (7, 13),
        (8, 24),
        (9, 44),
        (10, 81),
    ])
    def test_fibfib_basic_cases(self, n, expected):
        assert fibfib(n) == expected
    
    def test_fibfib_zero(self):
        assert fibfib(0) == 0
    
    def test_fibfib_one(self):
        assert fibfib(1) == 0
    
    def test_fibfib_two(self):
        assert fibfib(2) == 1
    
    def test_fibfib_three(self):
        assert fibfib(3) == 1
    
    def test_fibfib_four(self):
        assert fibfib(4) == 2
    
    def test_fibfib_five(self):
        assert fibfib(5) == 4
    
    def test_fibfib_six(self):
        assert fibfib(6) == 7
    
    def test_fibfib_seven(self):
        assert fibfib(7) == 13
    
    def test_fibfib_eight(self):
        assert fibfib(8) == 24
    
    def test_fibfib_nine(self):
        assert fibfib(9) == 44
    
    def test_fibfib_ten(self):
        assert fibfib(10) == 81
    
    def test_fibfib_returns_integer(self):
        result = fibfib(5)
        assert isinstance(result, int)
    
    def test_fibfib_positive_result(self):
        for n in range(2, 11):
            assert fibfib(n) >= 0
    
    def test_fibfib_increasing_sequence(self):
        prev = fibfib(2)
        for n in range(3, 11):
            current = fibfib(n)
            assert current >= prev
            prev = current
    
    def test_fibfib_large_number(self):
        result = fibfib(15)
        assert isinstance(result, int)
        assert result > 0
