# Test cases for HumanEval/69
# Generated using Claude API


def search(lst):
    '''
    You are given a non-empty list of positive integers. Return the greatest integer that is greater than 
    zero, and has a frequency greater than or equal to the value of the integer itself. 
    The frequency of an integer is the number of times it appears in the list.
    If no such a value exist, return -1.
    Examples:
        search([4, 1, 2, 2, 3, 1]) == 2
        search([1, 2, 2, 3, 3, 3, 4, 4, 4]) == 3
        search([5, 5, 4, 4, 4]) == -1
    '''

    frq = [0] * (max(lst) + 1)
    for i in lst:
        frq[i] += 1;

    ans = -1
    for i in range(1, len(frq)):
        if frq[i] >= i:
            ans = i
    
    return ans


# Generated test cases:
import pytest


@pytest.mark.parametrize("input_list,expected", [
    ([1, 1, 1, 1], 1),
    ([8, 8, 3, 0, 1, 3, 2, 2, 4], 2),
    ([1], 1),
    ([0], -1),
    ([1, 2, 3, 4, 5], 1),
    ([1, 1], 1),
    ([2, 2], 2),
    ([3, 3, 3], 3),
    ([1, 1, 1, 2, 2], 2),
    ([0, 0, 0, 0], -1),
    ([1, 1, 1, 1, 1], 1),
    ([2, 2, 2, 2], 2),
    ([5, 5, 5, 5, 5], 5),
    ([1, 2, 2, 3, 3, 3], 3),
    ([0, 1, 1], 1),
    ([10], -1),
    ([1, 1, 1, 1, 1, 1, 1, 1, 1, 1], 1),
    ([2, 2, 2, 2, 2, 2], 2),
    ([3, 3, 3, 3, 3, 3, 3, 3, 3], 3),
    ([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 1),
    ([1, 1, 2, 2, 2, 3, 3, 3, 3], 3),
    ([0, 0, 1, 1], 1),
    ([4, 4, 4, 4], 4),
    ([100], -1),
    ([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], 1),
])
def test_search_parametrized(input_list, expected):
    from test_humaneval_69 import search
    assert search(input_list) == expected


def test_search_single_element_one():
    assert search([1]) == 1


def test_search_single_element_zero():
    assert search([0]) == -1


def test_search_single_element_large():
    assert search([100]) == -1


def test_search_all_zeros():
    assert search([0, 0, 0]) == -1


def test_search_all_ones():
    assert search([1, 1, 1, 1]) == 1


def test_search_all_twos():
    assert search([2, 2]) == 2


def test_search_mixed_with_zero():
    assert search([0, 1, 1]) == 1


def test_search_increasing_sequence():
    assert search([1, 2, 3, 4, 5]) == 1


def test_search_valid_case():
    assert search([8, 8, 3, 0, 1, 3, 2, 2, 4]) == 2


def test_search_two_elements_same():
    assert search([1, 1]) == 1


def test_search_frequency_matches_value():
    assert search([3, 3, 3]) == 3


def test_search_multiple_valid_answers():
    assert search([1, 1, 1, 2, 2]) == 2


def test_search_large_frequency():
    assert search([5, 5, 5, 5, 5]) == 5


def test_search_complex_case():
    assert search([1, 2, 2, 3, 3, 3]) == 3


def test_search_returns_largest_valid():
    assert search([1, 1, 2, 2, 2, 3, 3, 3, 3]) == 3


def test_search_no_valid_answer():
    assert search([10, 20, 30]) == -1


def test_search_with_gaps():
    assert search([1, 1, 1, 1, 1, 1, 1, 1, 1, 1]) == 1


def test_search_four_fours():
    assert search([4, 4, 4, 4]) == 4


def test_search_six_twos():
    assert search([2, 2, 2, 2, 2, 2]) == 2


def test_search_nine_threes():
    assert search([3, 3, 3, 3, 3, 3, 3, 3, 3]) == 3