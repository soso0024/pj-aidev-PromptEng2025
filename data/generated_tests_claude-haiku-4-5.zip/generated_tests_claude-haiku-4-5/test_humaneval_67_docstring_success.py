# Test cases for HumanEval/67
# Generated using Claude API


def fruit_distribution(s,n):
    """
    In this task, you will be given a string that represents a number of apples and oranges 
    that are distributed in a basket of fruit this basket contains 
    apples, oranges, and mango fruits. Given the string that represents the total number of 
    the oranges and apples and an integer that represent the total number of the fruits 
    in the basket return the number of the mango fruits in the basket.
    for examble:
    fruit_distribution("5 apples and 6 oranges", 19) ->19 - 5 - 6 = 8
    fruit_distribution("0 apples and 1 oranges",3) -> 3 - 0 - 1 = 2
    fruit_distribution("2 apples and 3 oranges", 100) -> 100 - 2 - 3 = 95
    fruit_distribution("100 apples and 1 oranges",120) -> 120 - 100 - 1 = 19
    """

    lis = list()
    for i in s.split(' '):
        if i.isdigit():
            lis.append(int(i))
    return n - sum(lis)


# Generated test cases:
import pytest


def fruit_distribution(s, n):
    lis = list()
    for i in s.split(' '):
        if i.isdigit():
            lis.append(int(i))
    return n - sum(lis)


class TestFruitDistribution:
    
    @pytest.mark.parametrize("s,n,expected", [
        ("5 apples and 6 oranges", 19, 8),
        ("0 apples and 1 oranges", 3, 2),
        ("2 apples and 3 oranges", 100, 95),
        ("100 apples and 1 oranges", 120, 19),
    ])
    def test_basic_cases(self, s, n, expected):
        assert fruit_distribution(s, n) == expected
    
    def test_no_apples_no_oranges(self):
        assert fruit_distribution("0 apples and 0 oranges", 10) == 10
    
    def test_all_mangoes(self):
        assert fruit_distribution("0 apples and 0 oranges", 50) == 50
    
    def test_no_mangoes(self):
        assert fruit_distribution("5 apples and 5 oranges", 10) == 0
    
    def test_single_digit_numbers(self):
        assert fruit_distribution("1 apples and 1 oranges", 5) == 3
    
    def test_large_numbers(self):
        assert fruit_distribution("999 apples and 999 oranges", 5000) == 3002
    
    def test_zero_total_fruits(self):
        assert fruit_distribution("0 apples and 0 oranges", 0) == 0
    
    def test_single_apple(self):
        assert fruit_distribution("1 apples and 0 oranges", 10) == 9
    
    def test_single_orange(self):
        assert fruit_distribution("0 apples and 1 oranges", 10) == 9
    
    def test_equal_apples_and_oranges(self):
        assert fruit_distribution("7 apples and 7 oranges", 30) == 16
    
    def test_more_apples_than_oranges(self):
        assert fruit_distribution("10 apples and 2 oranges", 20) == 8
    
    def test_more_oranges_than_apples(self):
        assert fruit_distribution("2 apples and 10 oranges", 20) == 8
    
    def test_total_equals_sum_of_fruits(self):
        assert fruit_distribution("5 apples and 5 oranges", 10) == 0
    
    def test_large_total_small_fruits(self):
        assert fruit_distribution("1 apples and 1 oranges", 1000) == 998
    
    def test_small_total_large_fruits(self):
        assert fruit_distribution("0 apples and 0 oranges", 1) == 1
    
    @pytest.mark.parametrize("s,n,expected", [
        ("10 apples and 20 oranges", 50, 20),
        ("15 apples and 25 oranges", 100, 60),
        ("3 apples and 7 oranges", 15, 5),
        ("50 apples and 50 oranges", 150, 50),
    ])
    def test_various_distributions(self, s, n, expected):
        assert fruit_distribution(s, n) == expected
