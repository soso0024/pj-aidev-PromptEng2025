# Test cases for HumanEval/160
# Generated using Claude API


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and 
    the second list is a list of integers. Use the two given lists to build the algebric 
    expression and return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + ) 
    Subtraction ( - ) 
    Multiplication ( * ) 
    Floor division ( // ) 
    Exponentiation ( ** ) 

    Example:
    operator['+', '*', '-']
    array = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9

    Note:
        The length of operator list is equal to the length of operand list minus one.
        Operand is a list of of non-negative integers.
        Operator list has at least one operator, and operand list has at least two operands.

    """

    expression = str(operand[0])
    for oprt, oprn in zip(operator, operand[1:]):
        expression+= oprt + str(oprn)
    return eval(expression)


# Generated test cases:
import pytest


def do_algebra(operator, operand):
    expression = str(operand[0])
    for oprt, oprn in zip(operator, operand[1:]):
        expression+= oprt + str(oprn)
    return eval(expression)


class TestDoAlgebra:
    
    def test_addition_only(self):
        assert do_algebra(['+'], [2, 3]) == 5
    
    def test_subtraction_only(self):
        assert do_algebra(['-'], [10, 3]) == 7
    
    def test_multiplication_only(self):
        assert do_algebra(['*'], [4, 5]) == 20
    
    def test_floor_division_only(self):
        assert do_algebra(['//'], [10, 3]) == 3
    
    def test_exponentiation_only(self):
        assert do_algebra(['**'], [2, 3]) == 8
    
    def test_mixed_operations_with_precedence(self):
        assert do_algebra(['+', '*', '-'], [2, 3, 4, 5]) == 9
    
    def test_multiple_additions(self):
        assert do_algebra(['+', '+', '+'], [1, 2, 3, 4]) == 10
    
    def test_multiple_multiplications(self):
        assert do_algebra(['*', '*'], [2, 3, 4]) == 24
    
    def test_exponentiation_with_other_ops(self):
        assert do_algebra(['**', '+'], [2, 3, 5]) == 13
    
    def test_floor_division_with_other_ops(self):
        assert do_algebra(['//', '+'], [10, 2, 3]) == 8
    
    def test_complex_expression(self):
        assert do_algebra(['+', '*', '//', '-', '**'], [1, 2, 3, 4, 2, 3]) == -6
    
    def test_zero_operand(self):
        assert do_algebra(['+'], [0, 5]) == 5
    
    def test_zero_in_middle(self):
        assert do_algebra(['+', '+'], [5, 0, 3]) == 8
    
    def test_subtraction_resulting_in_zero(self):
        assert do_algebra(['-'], [5, 5]) == 0
    
    def test_multiplication_by_zero(self):
        assert do_algebra(['*'], [5, 0]) == 0
    
    def test_exponentiation_to_zero(self):
        assert do_algebra(['**'], [5, 0]) == 1
    
    def test_zero_to_power(self):
        assert do_algebra(['**'], [0, 5]) == 0
    
    def test_large_numbers(self):
        assert do_algebra(['+', '*'], [100, 200, 3]) == 700
    
    def test_large_exponentiation(self):
        assert do_algebra(['**'], [2, 10]) == 1024
    
    def test_division_with_remainder(self):
        assert do_algebra(['//'], [7, 2]) == 3
    
    def test_long_chain_of_operations(self):
        assert do_algebra(['+', '-', '+', '-'], [10, 5, 3, 2, 1]) == 13
    
    def test_subtraction_chain(self):
        assert do_algebra(['-', '-', '-'], [20, 5, 3, 2]) == 10
    
    def test_mixed_with_floor_division(self):
        assert do_algebra(['*', '//', '+'], [3, 4, 2, 5]) == 11
    
    def test_single_operand_pair_addition(self):
        assert do_algebra(['+'], [1, 1]) == 2
    
    def test_single_operand_pair_subtraction(self):
        assert do_algebra(['-'], [10, 1]) == 9
    
    def test_single_operand_pair_multiplication(self):
        assert do_algebra(['*'], [7, 8]) == 56
    
    def test_single_operand_pair_division(self):
        assert do_algebra(['//'], [20, 4]) == 5
    
    def test_single_operand_pair_exponentiation(self):
        assert do_algebra(['**'], [3, 2]) == 9
    
    def test_operator_precedence_mult_before_add(self):
        assert do_algebra(['+', '*'], [2, 3, 4]) == 14
    
    def test_operator_precedence_exp_before_mult(self):
        assert do_algebra(['*', '**'], [2, 3, 2]) == 18
    
    def test_all_operations_combined(self):
        assert do_algebra(['+', '-', '*', '//', '**'], [1, 2, 3, 4, 5, 2]) == 3