# Test cases for HumanEval/34
# Generated using Claude API



def unique(l: list):
    """Return sorted unique elements in a list
    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """

    return sorted(list(set(l)))


# Generated test cases:
import pytest


def unique(l: list):
    return sorted(list(set(l)))


class TestUnique:
    def test_empty_list(self):
        assert unique([]) == []

    def test_single_element(self):
        assert unique([1]) == [1]

    def test_no_duplicates(self):
        assert unique([1, 2, 3]) == [1, 2, 3]

    def test_with_duplicates(self):
        assert unique([1, 2, 2, 3, 3, 3]) == [1, 2, 3]

    def test_all_same_elements(self):
        assert unique([5, 5, 5, 5]) == [5]

    def test_unsorted_input(self):
        assert unique([3, 1, 2]) == [1, 2, 3]

    def test_unsorted_with_duplicates(self):
        assert unique([3, 1, 2, 1, 3]) == [1, 2, 3]

    def test_negative_numbers(self):
        assert unique([-1, -2, -3, -1]) == [-3, -2, -1]

    def test_mixed_positive_negative(self):
        assert unique([1, -1, 2, -2, 1]) == [-2, -1, 1, 2]

    def test_with_zero(self):
        assert unique([0, 1, 0, 2]) == [0, 1, 2]

    def test_strings(self):
        assert unique(['a', 'b', 'a', 'c']) == ['a', 'b', 'c']

    def test_mixed_case_strings(self):
        assert unique(['A', 'a', 'B', 'b']) == ['A', 'B', 'a', 'b']

    def test_floats(self):
        assert unique([1.5, 2.5, 1.5, 3.5]) == [1.5, 2.5, 3.5]

    def test_large_list(self):
        input_list = list(range(100)) + list(range(50))
        result = unique(input_list)
        assert result == list(range(100))

    def test_preserves_type_integers(self):
        result = unique([3, 1, 2])
        assert all(isinstance(x, int) for x in result)

    def test_preserves_type_strings(self):
        result = unique(['c', 'a', 'b'])
        assert all(isinstance(x, str) for x in result)

    def test_result_is_sorted(self):
        result = unique([5, 2, 8, 1, 9, 2])
        assert result == sorted(result)

    def test_result_is_list(self):
        result = unique([1, 2, 3])
        assert isinstance(result, list)

    def test_no_duplicates_in_result(self):
        result = unique([1, 1, 2, 2, 3, 3])
        assert len(result) == len(set(result))

    @pytest.mark.parametrize("input_list,expected", [
        ([1, 2, 3], [1, 2, 3]),
        ([3, 2, 1], [1, 2, 3]),
        ([1, 1, 1], [1]),
        ([], []),
        ([1], [1]),
        ([2, 1, 3, 1, 2], [1, 2, 3]),
    ])
    def test_parametrized_cases(self, input_list, expected):
        assert unique(input_list) == expected

    def test_with_boolean_values(self):
        result = unique([True, False, True, False])
        assert sorted(result) == [False, True]

    def test_duplicate_at_start(self):
        assert unique([1, 1, 2, 3]) == [1, 2, 3]

    def test_duplicate_at_end(self):
        assert unique([1, 2, 3, 3]) == [1, 2, 3]

    def test_duplicate_in_middle(self):
        assert unique([1, 2, 2, 3]) == [1, 2, 3]

    def test_alternating_duplicates(self):
        assert unique([1, 2, 1, 2, 1, 2]) == [1, 2]
