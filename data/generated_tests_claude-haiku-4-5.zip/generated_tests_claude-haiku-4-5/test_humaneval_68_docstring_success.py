# Test cases for HumanEval/68
# Generated using Claude API


def pluck(arr):
    """
    "Given an array representing a branch of a tree that has non-negative integer nodes
    your task is to pluck one of the nodes and return it.
    The plucked node should be the node with the smallest even value.
    If multiple nodes with the same smallest even value are found return the node that has smallest index.

    The plucked node should be returned in a list, [ smalest_value, its index ],
    If there are no even values or the given array is empty, return [].

    Example 1:
        Input: [4,2,3]
        Output: [2, 1]
        Explanation: 2 has the smallest even value, and 2 has the smallest index.

    Example 2:
        Input: [1,2,3]
        Output: [2, 1]
        Explanation: 2 has the smallest even value, and 2 has the smallest index. 

    Example 3:
        Input: []
        Output: []
    
    Example 4:
        Input: [5, 0, 3, 0, 4, 2]
        Output: [0, 1]
        Explanation: 0 is the smallest value, but  there are two zeros,
                     so we will choose the first zero, which has the smallest index.

    Constraints:
        * 1 <= nodes.length <= 10000
        * 0 <= node.value
    """

    if(len(arr) == 0): return []
    evens = list(filter(lambda x: x%2 == 0, arr))
    if(evens == []): return []
    return [min(evens), arr.index(min(evens))]


# Generated test cases:
import pytest


def pluck(arr):
    if(len(arr) == 0): return []
    evens = list(filter(lambda x: x%2 == 0, arr))
    if(evens == []): return []
    return [min(evens), arr.index(min(evens))]


@pytest.mark.parametrize("input_arr,expected", [
    ([4, 2, 3], [2, 1]),
    ([1, 2, 3], [2, 1]),
    ([], []),
    ([5, 0, 3, 0, 4, 2], [0, 1]),
    ([1, 3, 5, 7], []),
    ([0], [0, 0]),
    ([2], [2, 0]),
    ([1], []),
    ([0, 0, 0], [0, 0]),
    ([10, 8, 6, 4, 2], [2, 4]),
    ([2, 4, 6, 8, 10], [2, 0]),
    ([1, 1, 1, 2, 1, 1], [2, 3]),
    ([100, 50, 25, 12, 6], [6, 4]),
    ([7, 9, 11, 13], []),
    ([0, 1, 2, 3, 4, 5, 6, 7, 8, 9], [0, 0]),
    ([9, 8, 7, 6, 5, 4, 3, 2, 1, 0], [0, 9]),
    ([1000000, 999999, 500000], [500000, 2]),
    ([2, 2, 2, 2], [2, 0]),
    ([1, 3, 5, 7, 9, 11], []),
    ([11, 13, 15, 2, 17], [2, 3]),
])
def test_pluck(input_arr, expected):
    assert pluck(input_arr) == expected


def test_pluck_empty_array():
    assert pluck([]) == []


def test_pluck_no_even_values():
    assert pluck([1, 3, 5, 7, 9]) == []


def test_pluck_single_even():
    assert pluck([4]) == [4, 0]


def test_pluck_single_odd():
    assert pluck([3]) == []


def test_pluck_zero_is_smallest_even():
    assert pluck([5, 0, 3, 0, 4, 2]) == [0, 1]


def test_pluck_multiple_same_even_values():
    assert pluck([4, 4, 4, 4]) == [4, 0]


def test_pluck_large_array():
    arr = list(range(1, 1001))
    assert pluck(arr) == [2, 1]


def test_pluck_all_zeros():
    assert pluck([0, 0, 0, 0]) == [0, 0]


def test_pluck_mixed_large_and_small():
    assert pluck([1000, 2, 500, 4]) == [2, 1]


def test_pluck_even_at_end():
    assert pluck([1, 3, 5, 7, 2]) == [2, 4]


def test_pluck_alternating_odd_even():
    assert pluck([1, 2, 3, 4, 5, 6]) == [2, 1]
