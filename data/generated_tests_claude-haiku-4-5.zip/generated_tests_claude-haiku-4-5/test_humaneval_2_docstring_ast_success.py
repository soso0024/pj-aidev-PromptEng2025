# Test cases for HumanEval/2
# Generated using Claude API



def truncate_number(number: float) -> float:
    """ Given a positive floating point number, it can be decomposed into
    and integer part (largest integer smaller than given number) and decimals
    (leftover part always smaller than 1).

    Return the decimal part of the number.
    >>> truncate_number(3.5)
    0.5
    """

    return number % 1.0


# Generated test cases:
import pytest


def truncate_number(number: float) -> float:
    return number % 1.0


class TestTruncateNumber:
    
    @pytest.mark.parametrize("input_num,expected", [
        (3.5, 0.5),
        (0.5, 0.5),
        (1.0, 0.0),
        (0.0, 0.0),
        (10.25, 0.25),
        (99.99, 0.99),
        (0.1, 0.1),
        (0.9, 0.9),
        (5.123456, 0.123456),
        (100.001, 0.001),
    ])
    def test_truncate_number_basic(self, input_num, expected):
        result = truncate_number(input_num)
        assert abs(result - expected) < 1e-9
    
    def test_truncate_number_zero(self):
        assert truncate_number(0.0) == 0.0
    
    def test_truncate_number_one(self):
        assert truncate_number(1.0) == 0.0
    
    def test_truncate_number_large_integer(self):
        assert truncate_number(1000.0) == 0.0
    
    def test_truncate_number_small_decimal(self):
        result = truncate_number(0.0001)
        assert abs(result - 0.0001) < 1e-9
    
    def test_truncate_number_close_to_one(self):
        result = truncate_number(0.9999999)
        assert abs(result - 0.9999999) < 1e-6
    
    def test_truncate_number_large_with_decimal(self):
        result = truncate_number(12345.6789)
        assert abs(result - 0.6789) < 1e-9
    
    def test_truncate_number_negative_not_in_spec(self):
        # Testing behavior with negative numbers even though spec says positive
        result = truncate_number(-3.5)
        assert abs(result - 0.5) < 1e-9
    
    def test_truncate_number_very_small_positive(self):
        result = truncate_number(0.00001)
        assert abs(result - 0.00001) < 1e-9
    
    def test_truncate_number_returns_float(self):
        result = truncate_number(3.5)
        assert isinstance(result, float)
    
    def test_truncate_number_result_less_than_one(self):
        result = truncate_number(42.7)
        assert result < 1.0
    
    def test_truncate_number_result_non_negative(self):
        result = truncate_number(5.5)
        assert result >= 0.0
    
    @pytest.mark.parametrize("input_num", [
        1.5,
        2.3,
        7.8,
        15.42,
        100.5,
    ])
    def test_truncate_number_decimal_part_only(self, input_num):
        result = truncate_number(input_num)
        assert 0.0 <= result < 1.0
    
    def test_truncate_number_precision(self):
        # Test with high precision decimal
        result = truncate_number(3.141592653589793)
        expected = 0.141592653589793
        assert abs(result - expected) < 1e-14
