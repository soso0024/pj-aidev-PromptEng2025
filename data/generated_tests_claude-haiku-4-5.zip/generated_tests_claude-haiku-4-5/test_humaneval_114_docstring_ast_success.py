# Test cases for HumanEval/114
# Generated using Claude API


def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """

    max_sum = 0
    s = 0
    for num in nums:
        s += -num
        if (s < 0):
            s = 0
        max_sum = max(s, max_sum)
    if max_sum == 0:
        max_sum = max(-i for i in nums)
    min_sum = -max_sum
    return min_sum


# Generated test cases:
import pytest


class TestMinSubArraySum:
    
    @pytest.mark.parametrize("nums,expected", [
        ([2, 3, 4, 1, 2, 4], 1),
        ([-1, -2, -3], -6),
        ([1], 1),
        ([-1], -1),
        ([5, -3, 5], -3),
        ([-2, 1, -3, 4, -1, 2, 1, -5, 4], -5),
        ([0], 0),
        ([0, 0, 0], 0),
        ([-5, -2, -8, -1, -4], -20),
        ([1, 2, 3, 4, 5], 1),
        ([-1, -2, -3, -4, -5], -15),
        ([10, -5, 3, -2, 8], -5),
        ([100, -200, 50], -200),
        ([-10, 5, -3, 2, -1], -10),
        ([1, -1, 1, -1, 1], -1),
        ([0, -5, 0], -5),
        ([-100], -100),
        ([100], 100),
        ([1, 2, -5, 4, 5], -5),
        ([-1, -1, -1, -1], -4),
        ([5, 5, 5, 5], 5),
        ([0, 0, -1, 0, 0], -1),
        ([-3, -1, -4, -1, -5], -14),
        ([2, -1, 2, -1, 4, -5], -5),
        ([1, 1, 1, 1, 1], 1),
    ])
    def test_minSubArraySum(self, nums, expected):
        from test_humaneval_114_docstring_ast import minSubArraySum
        assert minSubArraySum(nums) == expected
    
    def test_single_positive_element(self):
        assert minSubArraySum([42]) == 42
    
    def test_single_negative_element(self):
        assert minSubArraySum([-42]) == -42
    
    def test_all_positive(self):
        assert minSubArraySum([1, 2, 3, 4, 5]) == 1
    
    def test_all_negative(self):
        assert minSubArraySum([-1, -2, -3, -4, -5]) == -15
    
    def test_mixed_with_zero(self):
        assert minSubArraySum([0, -5, 0, 3]) == -5
    
    def test_large_negative_number(self):
        assert minSubArraySum([-1000, 1, 2, 3]) == -1000
    
    def test_large_positive_number(self):
        assert minSubArraySum([1000, -1, -2, -3]) == -6
    
    def test_alternating_signs(self):
        assert minSubArraySum([5, -10, 5, -10, 5]) == -15
    
    def test_minimum_at_end(self):
        assert minSubArraySum([1, 2, 3, -10]) == -10
    
    def test_minimum_at_start(self):
        assert minSubArraySum([-10, 1, 2, 3]) == -10
    
    def test_minimum_in_middle(self):
        assert minSubArraySum([5, 5, -20, 5, 5]) == -20
    
    def test_two_elements_positive(self):
        assert minSubArraySum([3, 5]) == 3
    
    def test_two_elements_negative(self):
        assert minSubArraySum([-3, -5]) == -8
    
    def test_two_elements_mixed(self):
        assert minSubArraySum([5, -10]) == -10
    
    def test_subarray_sum_better_than_single(self):
        assert minSubArraySum([2, -5, 3]) == -5
    
    def test_multiple_subarrays_same_sum(self):
        result = minSubArraySum([-3, -3, -3])
        assert result == -9
    
    def test_zero_in_array(self):
        assert minSubArraySum([1, 0, 2]) == 0
    
    def test_multiple_zeros(self):
        assert minSubArraySum([0, 0, 0, 0]) == 0