# Test cases for HumanEval/20
# Generated using Claude API

from typing import List, Tuple


def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    """ From a supplied list of numbers (of length at least two) select and return two that are the closest to each
    other and return them in order (smaller number, larger number).
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.2])
    (2.0, 2.2)
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.0])
    (2.0, 2.0)
    """

    closest_pair = None
    distance = None

    for idx, elem in enumerate(numbers):
        for idx2, elem2 in enumerate(numbers):
            if idx != idx2:
                if distance is None:
                    distance = abs(elem - elem2)
                    closest_pair = tuple(sorted([elem, elem2]))
                else:
                    new_distance = abs(elem - elem2)
                    if new_distance < distance:
                        distance = new_distance
                        closest_pair = tuple(sorted([elem, elem2]))

    return closest_pair


# Generated test cases:
import pytest
from typing import List, Tuple


def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    closest_pair = None
    distance = None

    for idx, elem in enumerate(numbers):
        for idx2, elem2 in enumerate(numbers):
            if idx != idx2:
                if distance is None:
                    distance = abs(elem - elem2)
                    closest_pair = tuple(sorted([elem, elem2]))
                else:
                    new_distance = abs(elem - elem2)
                    if new_distance < distance:
                        distance = new_distance
                        closest_pair = tuple(sorted([elem, elem2]))

    return closest_pair


class TestFindClosestElements:
    
    def test_basic_example_from_docstring(self):
        result = find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.2])
        assert result == (2.0, 2.2)
    
    def test_duplicate_elements_from_docstring(self):
        result = find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.0])
        assert result == (2.0, 2.0)
    
    def test_two_elements_only(self):
        result = find_closest_elements([1.0, 2.0])
        assert result == (1.0, 2.0)
    
    def test_two_identical_elements(self):
        result = find_closest_elements([5.0, 5.0])
        assert result == (5.0, 5.0)
    
    def test_negative_numbers(self):
        result = find_closest_elements([-1.0, -2.0, -1.5])
        assert result == (-1.5, -1.0)
    
    def test_mixed_positive_negative(self):
        result = find_closest_elements([-1.0, 0.0, 1.0, 0.1])
        assert result == (0.0, 0.1)
    
    def test_very_close_numbers(self):
        result = find_closest_elements([1.0, 1.0001, 1.0002])
        assert result == (1.0, 1.0001)
    
    def test_large_numbers(self):
        result = find_closest_elements([1000000.0, 1000001.0, 2000000.0])
        assert result == (1000000.0, 1000001.0)
    
    def test_unsorted_list(self):
        result = find_closest_elements([5.0, 1.0, 3.0, 2.0])
        assert result == (1.0, 2.0)
    
    def test_returns_sorted_pair(self):
        result = find_closest_elements([10.0, 5.0])
        assert result[0] < result[1]
    
    def test_multiple_pairs_same_distance(self):
        result = find_closest_elements([1.0, 2.0, 3.0, 4.0])
        assert result in [(1.0, 2.0), (2.0, 3.0), (3.0, 4.0)]
    
    def test_three_elements_closest_at_end(self):
        result = find_closest_elements([1.0, 10.0, 10.1])
        assert result == (10.0, 10.1)
    
    def test_three_elements_closest_at_start(self):
        result = find_closest_elements([1.0, 1.1, 10.0])
        assert result == (1.0, 1.1)
    
    def test_decimal_precision(self):
        result = find_closest_elements([0.1, 0.2, 0.15])
        assert result == (0.1, 0.15)
    
    def test_zero_in_list(self):
        result = find_closest_elements([0.0, 0.5, -0.1])
        assert result == (-0.1, 0.0)
    
    def test_all_same_elements(self):
        result = find_closest_elements([7.0, 7.0, 7.0, 7.0])
        assert result == (7.0, 7.0)
    
    def test_long_list(self):
        numbers = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 5.5]
        result = find_closest_elements(numbers)
        assert result == (5.0, 5.5)
    
    def test_negative_and_positive_close(self):
        result = find_closest_elements([-0.05, 0.05, 1.0])
        assert result == (-0.05, 0.05)
    
    def test_fractional_numbers(self):
        result = find_closest_elements([1.5, 2.7, 1.6])
        assert result == (1.5, 1.6)
    
    @pytest.mark.parametrize("numbers,expected", [
        ([1.0, 2.0, 3.0], (1.0, 2.0)),
        ([10.0, 20.0, 15.0], (10.0, 15.0)),
        ([-5.0, -4.0, -3.0], (-5.0, -4.0)),
        ([0.0, 1.0, 0.5], (0.0, 0.5)),
    ])
    def test_parametrized_cases(self, numbers, expected):
        result = find_closest_elements(numbers)
        assert result == expected