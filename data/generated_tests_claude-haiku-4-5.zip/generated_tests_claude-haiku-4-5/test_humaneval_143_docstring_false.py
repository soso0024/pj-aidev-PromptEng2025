# Test cases for HumanEval/143
# Generated using Claude API


def words_in_sentence(sentence):
    """
    You are given a string representing a sentence,
    the sentence contains some words separated by a space,
    and you have to return a string that contains the words from the original sentence,
    whose lengths are prime numbers,
    the order of the words in the new string should be the same as the original one.

    Example 1:
        Input: sentence = "This is a test"
        Output: "is"

    Example 2:
        Input: sentence = "lets go for swimming"
        Output: "go for"

    Constraints:
        * 1 <= len(sentence) <= 100
        * sentence contains only letters
    """

    new_lst = []
    for word in sentence.split():
        flg = 0
        if len(word) == 1:
            flg = 1
        for i in range(2, len(word)):
            if len(word)%i == 0:
                flg = 1
        if flg == 0 or len(word) == 2:
            new_lst.append(word)
    return " ".join(new_lst)


# Generated test cases:
import pytest


def is_prime(n):
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False
    for i in range(3, int(n**0.5) + 1, 2):
        if n % i == 0:
            return False
    return True


def words_in_sentence(sentence):
    new_lst = []
    for word in sentence.split():
        if is_prime(len(word)):
            new_lst.append(word)
    return " ".join(new_lst)


class TestWordsInSentence:
    
    @pytest.mark.parametrize("sentence,expected", [
        ("This is a test", "is"),
        ("lets go for swimming", "go for"),
        ("a", ""),
        ("ab", "ab"),
        ("abc", "abc"),
        ("abcd", ""),
        ("abcde", "abcde"),
        ("abcdef", ""),
        ("I am learning Python", "am"),
        ("hello world", "hello world"),
        ("hi", "hi"),
        ("bye", "bye"),
        ("python", ""),
        ("code", ""),
        ("is it", "is it"),
        ("a b c d e", ""),
        ("ab cd ef gh", "ab cd ef gh"),
        ("programming", "programming"),
        ("go", "go"),
        ("for", "for"),
        ("swimming", ""),
        ("test", ""),
        ("This", ""),
        ("a aa aaa aaaa aaaaa", "aa aaaaa"),
        ("x y z", ""),
        ("ox", "ox"),
        ("box", "box"),
        ("boxes", "boxes"),
        ("boxing", ""),
        ("be or not be", "be or not be"),
        ("the quick brown fox", "the quick brown fox"),
        ("a bb ccc dddd eeeee", "bb ccc eeeee"),
    ])
    def test_words_in_sentence(self, sentence, expected):
        assert words_in_sentence(sentence) == expected
    
    def test_single_word_prime_length(self):
        assert words_in_sentence("hi") == "hi"
    
    def test_single_word_composite_length(self):
        assert words_in_sentence("test") == ""
    
    def test_single_character(self):
        assert words_in_sentence("a") == ""
    
    def test_all_prime_length_words(self):
        assert words_in_sentence("hi go or") == "hi go or"
    
    def test_all_composite_length_words(self):
        assert words_in_sentence("test code") == ""
    
    def test_mixed_lengths(self):
        result = words_in_sentence("I am a programmer")
        assert result == "am"
    
    def test_two_letter_words_only(self):
        assert words_in_sentence("is it or") == "is it or"
    
    def test_preserves_order(self):
        assert words_in_sentence("go for it now") == "go for it now"
    
    def test_long_sentence(self):
        sentence = "the quick brown fox jumps over the lazy dog"
        result = words_in_sentence(sentence)
        assert "the" in result
        assert "quick" in result
    
    def test_repeated_words(self):
        assert words_in_sentence("go go go") == "go go go"
    
    def test_single_prime_word(self):
        assert words_in_sentence("hello") == "hello"
    
    def test_word_length_seven(self):
        assert words_in_sentence("example") == "example"
    
    def test_word_length_eleven(self):
        assert words_in_sentence("programming") == "programming"
    
    def test_word_length_thirteen(self):
        assert words_in_sentence("understanding") == "understanding"