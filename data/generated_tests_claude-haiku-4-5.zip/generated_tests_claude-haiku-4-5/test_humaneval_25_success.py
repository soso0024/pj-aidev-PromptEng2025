# Test cases for HumanEval/25
# Generated using Claude API

from typing import List


def factorize(n: int) -> List[int]:
    """ Return list of prime factors of given integer in the order from smallest to largest.
    Each of the factors should be listed number of times corresponding to how many times it appeares in factorization.
    Input number should be equal to the product of all factors
    >>> factorize(8)
    [2, 2, 2]
    >>> factorize(25)
    [5, 5]
    >>> factorize(70)
    [2, 5, 7]
    """

    import math
    fact = []
    i = 2
    while i <= int(math.sqrt(n) + 1):
        if n % i == 0:
            fact.append(i)
            n //= i
        else:
            i += 1

    if n > 1:
        fact.append(n)
    return fact


# Generated test cases:
import pytest
from typing import List


def factorize(n: int) -> List[int]:
    import math
    fact = []
    i = 2
    while i <= int(math.sqrt(n) + 1):
        if n % i == 0:
            fact.append(i)
            n //= i
        else:
            i += 1

    if n > 1:
        fact.append(n)
    return fact


class TestFactorize:
    
    @pytest.mark.parametrize("n,expected", [
        (2, [2]),
        (3, [3]),
        (4, [2, 2]),
        (5, [5]),
        (6, [2, 3]),
        (8, [2, 2, 2]),
        (9, [3, 3]),
        (10, [2, 5]),
        (12, [2, 2, 3]),
        (15, [3, 5]),
        (20, [2, 2, 5]),
        (24, [2, 2, 2, 3]),
        (30, [2, 3, 5]),
        (100, [2, 2, 5, 5]),
        (97, [97]),
        (1000, [2, 2, 2, 5, 5, 5]),
    ])
    def test_factorize_normal_cases(self, n, expected):
        assert factorize(n) == expected
    
    def test_factorize_prime_number(self):
        assert factorize(7) == [7]
        assert factorize(11) == [11]
        assert factorize(13) == [13]
    
    def test_factorize_power_of_two(self):
        assert factorize(16) == [2, 2, 2, 2]
        assert factorize(32) == [2, 2, 2, 2, 2]
        assert factorize(64) == [2, 2, 2, 2, 2, 2]
    
    def test_factorize_power_of_three(self):
        assert factorize(27) == [3, 3, 3]
        assert factorize(81) == [3, 3, 3, 3]
    
    def test_factorize_two(self):
        assert factorize(2) == [2]
    
    def test_factorize_large_prime(self):
        assert factorize(101) == [101]
        assert factorize(997) == [997]
    
    def test_factorize_product_of_two_primes(self):
        assert factorize(21) == [3, 7]
        assert factorize(35) == [5, 7]
        assert factorize(77) == [7, 11]
    
    def test_factorize_large_number(self):
        result = factorize(360)
        assert result == [2, 2, 2, 3, 3, 5]
    
    def test_factorize_very_large_number(self):
        result = factorize(1000000)
        assert result == [2, 2, 2, 2, 2, 2, 5, 5, 5, 5, 5, 5]
    
    def test_factorize_composite_with_repeated_factors(self):
        assert factorize(18) == [2, 3, 3]
        assert factorize(50) == [2, 5, 5]
        assert factorize(72) == [2, 2, 2, 3, 3]
    
    def test_factorize_returns_list(self):
        result = factorize(10)
        assert isinstance(result, list)
    
    def test_factorize_product_is_correct(self):
        for n in [2, 3, 4, 5, 6, 10, 15, 20, 30, 100]:
            factors = factorize(n)
            product = 1
            for factor in factors:
                product *= factor
            assert product == n
    
    def test_factorize_factors_are_sorted(self):
        for n in [10, 20, 30, 60, 100]:
            factors = factorize(n)
            assert factors == sorted(factors)
    
    def test_factorize_all_factors_are_prime_or_greater_than_one(self):
        for n in [2, 3, 4, 5, 6, 10, 15, 20, 30, 100]:
            factors = factorize(n)
            for factor in factors:
                assert factor >= 2
