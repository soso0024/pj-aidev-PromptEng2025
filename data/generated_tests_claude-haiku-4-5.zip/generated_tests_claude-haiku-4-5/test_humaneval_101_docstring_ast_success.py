# Test cases for HumanEval/101
# Generated using Claude API


def words_string(s):
    """
    You will be given a string of words separated by commas or spaces. Your task is
    to split the string into words and return an array of the words.
    
    For example:
    words_string("Hi, my name is John") == ["Hi", "my", "name", "is", "John"]
    words_string("One, two, three, four, five, six") == ["One", "two", "three", "four", "five", "six"]
    """

    if not s:
        return []

    s_list = []

    for letter in s:
        if letter == ',':
            s_list.append(' ')
        else:
            s_list.append(letter)

    s_list = "".join(s_list)
    return s_list.split()


# Generated test cases:
import pytest


def words_string(s):
    if not s:
        return []

    s_list = []

    for letter in s:
        if letter == ',':
            s_list.append(' ')
        else:
            s_list.append(letter)

    s_list = "".join(s_list)
    return s_list.split()


class TestWordsString:
    
    @pytest.mark.parametrize("input_str,expected", [
        ("Hi, my name is John", ["Hi", "my", "name", "is", "John"]),
        ("One, two, three, four, five, six", ["One", "two", "three", "four", "five", "six"]),
    ])
    def test_basic_examples(self, input_str, expected):
        assert words_string(input_str) == expected
    
    def test_empty_string(self):
        assert words_string("") == []
    
    def test_single_word(self):
        assert words_string("Hello") == ["Hello"]
    
    def test_words_with_spaces_only(self):
        assert words_string("Hello world test") == ["Hello", "world", "test"]
    
    def test_words_with_commas_only(self):
        assert words_string("Hello,world,test") == ["Hello", "world", "test"]
    
    def test_words_with_mixed_separators(self):
        assert words_string("Hello, world test") == ["Hello", "world", "test"]
    
    def test_multiple_spaces(self):
        assert words_string("Hello  world   test") == ["Hello", "world", "test"]
    
    def test_multiple_commas(self):
        assert words_string("Hello,,world") == ["Hello", "world"]
    
    def test_comma_and_space_combinations(self):
        assert words_string("Hello, , world") == ["Hello", "world"]
    
    def test_leading_comma(self):
        assert words_string(",Hello world") == ["Hello", "world"]
    
    def test_trailing_comma(self):
        assert words_string("Hello world,") == ["Hello", "world"]
    
    def test_leading_space(self):
        assert words_string(" Hello world") == ["Hello", "world"]
    
    def test_trailing_space(self):
        assert words_string("Hello world ") == ["Hello", "world"]
    
    def test_only_commas(self):
        assert words_string(",,,") == []
    
    def test_only_spaces(self):
        assert words_string("   ") == []
    
    def test_single_character(self):
        assert words_string("a") == ["a"]
    
    def test_single_comma(self):
        assert words_string(",") == []
    
    def test_single_space(self):
        assert words_string(" ") == []
    
    def test_numbers_as_words(self):
        assert words_string("1, 2, 3, 4, 5") == ["1", "2", "3", "4", "5"]
    
    def test_special_characters_in_words(self):
        assert words_string("hello-world, test@case") == ["hello-world", "test@case"]
    
    def test_mixed_case_words(self):
        assert words_string("HeLLo, WoRLd, TeSt") == ["HeLLo", "WoRLd", "TeSt"]
    
    def test_long_string(self):
        long_input = "word1, word2, word3, word4, word5, word6, word7, word8, word9, word10"
        expected = ["word1", "word2", "word3", "word4", "word5", "word6", "word7", "word8", "word9", "word10"]
        assert words_string(long_input) == expected
    
    def test_tabs_and_newlines(self):
        assert words_string("Hello\tworld\ntest") == ["Hello", "world", "test"]
    
    def test_comma_space_comma_pattern(self):
        assert words_string("a, , b") == ["a", "b"]
