# Test cases for HumanEval/62
# Generated using Claude API



def derivative(xs: list):
    """ xs represent coefficients of a polynomial.
    xs[0] + xs[1] * x + xs[2] * x^2 + ....
     Return derivative of this polynomial in the same form.
    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    """

    return [(i * x) for i, x in enumerate(xs)][1:]


# Generated test cases:
import pytest


def derivative(xs: list):
    return [(i * x) for i, x in enumerate(xs)][1:]


class TestDerivative:
    def test_example_case_1(self):
        assert derivative([3, 1, 2, 4, 5]) == [1, 4, 12, 20]

    def test_example_case_2(self):
        assert derivative([1, 2, 3]) == [2, 6]

    def test_single_element(self):
        assert derivative([5]) == []

    def test_two_elements(self):
        assert derivative([3, 4]) == [4]

    def test_empty_list(self):
        assert derivative([]) == []

    def test_zeros(self):
        assert derivative([0, 0, 0, 0]) == [0, 0, 0]

    def test_negative_coefficients(self):
        assert derivative([-1, -2, -3]) == [-2, -6]

    def test_mixed_signs(self):
        assert derivative([1, -2, 3, -4]) == [-2, 6, -12]

    def test_large_coefficients(self):
        assert derivative([1, 100, 1000, 10000]) == [100, 2000, 30000]

    def test_float_coefficients(self):
        assert derivative([1.5, 2.5, 3.5]) == [2.5, 7.0]

    def test_zero_first_coefficient(self):
        assert derivative([0, 5, 10, 15]) == [5, 20, 45]

    def test_constant_polynomial(self):
        assert derivative([42]) == []

    def test_linear_polynomial(self):
        assert derivative([7, 3]) == [3]

    def test_quadratic_polynomial(self):
        assert derivative([1, 2, 3]) == [2, 6]

    def test_cubic_polynomial(self):
        assert derivative([1, 0, 0, 1]) == [0, 0, 3]

    def test_many_terms(self):
        result = derivative([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        expected = [2, 6, 12, 20, 30, 42, 56, 72, 90]
        assert result == expected

    @pytest.mark.parametrize("input_list,expected", [
        ([0], []),
        ([1], []),
        ([0, 0], [0]),
        ([5, 10], [10]),
        ([1, 1, 1], [1, 2]),
        ([-5, -10, -15], [-10, -30]),
        ([0, 1, 2, 3], [1, 4, 9]),
    ])
    def test_parametrized_cases(self, input_list, expected):
        assert derivative(input_list) == expected
