# Test cases for HumanEval/26
# Generated using Claude API

from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    """ From a list of integers, remove all elements that occur more than once.
    Keep order of elements left the same as in the input.
    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """

    import collections
    c = collections.Counter(numbers)
    return [n for n in numbers if c[n] <= 1]


# Generated test cases:
import pytest
from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    import collections
    c = collections.Counter(numbers)
    return [n for n in numbers if c[n] <= 1]


class TestRemoveDuplicates:
    
    def test_example_from_docstring(self):
        assert remove_duplicates([1, 2, 3, 2, 4]) == [1, 3, 4]
    
    def test_empty_list(self):
        assert remove_duplicates([]) == []
    
    def test_single_element(self):
        assert remove_duplicates([1]) == [1]
    
    def test_no_duplicates(self):
        assert remove_duplicates([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    
    def test_all_duplicates(self):
        assert remove_duplicates([1, 1, 2, 2, 3, 3]) == []
    
    def test_all_same_element(self):
        assert remove_duplicates([5, 5, 5, 5]) == []
    
    def test_duplicates_at_start(self):
        assert remove_duplicates([1, 1, 2, 3]) == [2, 3]
    
    def test_duplicates_at_end(self):
        assert remove_duplicates([1, 2, 3, 3]) == [1, 2]
    
    def test_duplicates_in_middle(self):
        assert remove_duplicates([1, 2, 2, 3]) == [1, 3]
    
    def test_multiple_duplicates_same_element(self):
        assert remove_duplicates([1, 1, 1, 2, 3]) == [2, 3]
    
    def test_multiple_different_duplicates(self):
        assert remove_duplicates([1, 1, 2, 2, 3, 3, 4]) == [4]
    
    def test_negative_numbers(self):
        assert remove_duplicates([-1, -2, -1, 3]) == [-2, 3]
    
    def test_mixed_positive_negative(self):
        assert remove_duplicates([-1, 0, 1, -1, 0, 1]) == []
    
    def test_zero_in_list(self):
        assert remove_duplicates([0, 1, 2, 0]) == [1, 2]
    
    def test_large_numbers(self):
        assert remove_duplicates([1000000, 2000000, 1000000]) == [2000000]
    
    def test_order_preserved(self):
        assert remove_duplicates([5, 1, 3, 1, 2, 5, 4]) == [3, 2, 4]
    
    def test_two_elements_same(self):
        assert remove_duplicates([1, 1]) == []
    
    def test_two_elements_different(self):
        assert remove_duplicates([1, 2]) == [1, 2]
    
    def test_three_elements_one_duplicate(self):
        assert remove_duplicates([1, 2, 1]) == [2]
    
    def test_complex_pattern(self):
        assert remove_duplicates([1, 2, 3, 1, 2, 3, 4, 5]) == [4, 5]
    
    @pytest.mark.parametrize("input_list,expected", [
        ([1, 2, 3, 2, 4], [1, 3, 4]),
        ([], []),
        ([1], [1]),
        ([1, 1], []),
        ([1, 2, 3], [1, 2, 3]),
        ([1, 1, 1], []),
        ([-5, -5, 10], [10]),
        ([0, 0, 1, 2], [1, 2]),
    ])
    def test_parametrized_cases(self, input_list, expected):
        assert remove_duplicates(input_list) == expected
