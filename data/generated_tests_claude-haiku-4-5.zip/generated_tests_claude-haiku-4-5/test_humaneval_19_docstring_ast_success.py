# Test cases for HumanEval/19
# Generated using Claude API

from typing import List


def sort_numbers(numbers: str) -> str:
    """ Input is a space-delimited string of numberals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight' and 'nine'.
    Return the string with numbers sorted from smallest to largest
    >>> sort_numbers('three one five')
    'one three five'
    """

    value_map = {
        'zero': 0,
        'one': 1,
        'two': 2,
        'three': 3,
        'four': 4,
        'five': 5,
        'six': 6,
        'seven': 7,
        'eight': 8,
        'nine': 9
    }
    return ' '.join(sorted([x for x in numbers.split(' ') if x], key=lambda x: value_map[x]))


# Generated test cases:
import pytest


def sort_numbers(numbers: str) -> str:
    value_map = {
        'zero': 0,
        'one': 1,
        'two': 2,
        'three': 3,
        'four': 4,
        'five': 5,
        'six': 6,
        'seven': 7,
        'eight': 8,
        'nine': 9
    }
    return ' '.join(sorted([x for x in numbers.split(' ') if x], key=lambda x: value_map[x]))


class TestSortNumbers:
    
    def test_example_from_docstring(self):
        assert sort_numbers('three one five') == 'one three five'
    
    def test_single_number(self):
        assert sort_numbers('five') == 'five'
    
    def test_already_sorted(self):
        assert sort_numbers('zero one two three four') == 'zero one two three four'
    
    def test_reverse_sorted(self):
        assert sort_numbers('nine eight seven six five') == 'five six seven eight nine'
    
    def test_all_numbers(self):
        assert sort_numbers('nine zero five two eight one six four three seven') == 'zero one two three four five six seven eight nine'
    
    def test_duplicate_numbers(self):
        assert sort_numbers('three three one one five five') == 'one one three three five five'
    
    def test_two_numbers(self):
        assert sort_numbers('nine zero') == 'zero nine'
    
    def test_unsorted_middle(self):
        assert sort_numbers('one five three') == 'one three five'
    
    def test_all_same_number(self):
        assert sort_numbers('five five five five') == 'five five five five'
    
    def test_zero_first(self):
        assert sort_numbers('five zero three') == 'zero three five'
    
    def test_nine_last(self):
        assert sort_numbers('five nine three') == 'three five nine'
    
    def test_mixed_order(self):
        assert sort_numbers('seven two nine one four') == 'one two four seven nine'
    
    def test_two_elements_reversed(self):
        assert sort_numbers('eight one') == 'one eight'
    
    def test_consecutive_numbers(self):
        assert sort_numbers('three two one') == 'one two three'
    
    def test_large_gaps(self):
        assert sort_numbers('zero nine') == 'zero nine'
    
    def test_random_order_all_digits(self):
        assert sort_numbers('four one nine zero six two seven five three eight') == 'zero one two three four five six seven eight nine'
    
    def test_single_digit_zero(self):
        assert sort_numbers('zero') == 'zero'
    
    def test_single_digit_nine(self):
        assert sort_numbers('nine') == 'nine'
    
    def test_pairs_unsorted(self):
        assert sort_numbers('six two four one') == 'one two four six'


class TestSortNumbersParametrized:
    
    @pytest.mark.parametrize("input_str,expected", [
        ('three one five', 'one three five'),
        ('five', 'five'),
        ('zero one two three four', 'zero one two three four'),
        ('nine eight seven six five', 'five six seven eight nine'),
        ('nine zero five two eight one six four three seven', 'zero one two three four five six seven eight nine'),
        ('three three one one five five', 'one one three three five five'),
        ('nine zero', 'zero nine'),
        ('one five three', 'one three five'),
        ('five five five five', 'five five five five'),
        ('five zero three', 'zero three five'),
        ('five nine three', 'three five nine'),
        ('seven two nine one four', 'one two four seven nine'),
        ('eight one', 'one eight'),
        ('three two one', 'one two three'),
        ('zero nine', 'zero nine'),
        ('four one nine zero six two seven five three eight', 'zero one two three four five six seven eight nine'),
        ('zero', 'zero'),
        ('nine', 'nine'),
        ('six two four one', 'one two four six'),
        ('two', 'two'),
        ('one one one', 'one one one'),
        ('nine nine nine nine nine', 'nine nine nine nine nine'),
    ])
    def test_sort_numbers_parametrized(self, input_str, expected):
        assert sort_numbers(input_str) == expected
