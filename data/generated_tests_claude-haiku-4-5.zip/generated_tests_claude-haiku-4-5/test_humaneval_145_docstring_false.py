# Test cases for HumanEval/145
# Generated using Claude API


def order_by_points(nums):
    """
    Write a function which sorts the given list of integers
    in ascending order according to the sum of their digits.
    Note: if there are several items with similar sum of their digits,
    order them based on their index in original list.

    For example:
    >>> order_by_points([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    >>> order_by_points([]) == []
    """

    def digits_sum(n):
        neg = 1
        if n < 0: n, neg = -1 * n, -1 
        n = [int(i) for i in str(n)]
        n[0] = n[0] * neg
        return sum(n)
    return sorted(nums, key=digits_sum)


# Generated test cases:
import pytest


def order_by_points(nums):
    def digits_sum(n):
        neg = 1
        if n < 0: n, neg = -1 * n, -1 
        n = [int(i) for i in str(n)]
        n[0] = n[0] * neg
        return sum(n)
    return sorted(nums, key=digits_sum)


@pytest.mark.parametrize("input_list,expected", [
    ([1, 11, -1, -11, -12], [-1, -11, 1, -12, 11]),
    ([], []),
    ([0], [0]),
    ([5], [5]),
    ([-5], [-5]),
    ([1, 2, 3], [1, 2, 3]),
    ([3, 2, 1], [1, 2, 3]),
    ([10, 1], [1, 10]),
    ([100, 10, 1], [1, 10, 100]),
    ([-1, -2, -3], [-1, -2, -3]),
    ([12, 21], [12, 21]),
    ([99, 9], [9, 99]),
    ([-99, -9], [-9, -99]),
    ([0, 0, 0], [0, 0, 0]),
    ([123, 456, 789], [123, 456, 789]),
    ([111, 11, 1], [1, 11, 111]),
    ([-111, -11, -1], [-1, -11, -111]),
    ([5, 50, 500], [5, 50, 500]),
    ([505, 50, 5], [5, 50, 505]),
    ([1, 10, 100, 1000], [1, 10, 100, 1000]),
    ([9, 18, 27], [9, 18, 27]),
    ([27, 18, 9], [9, 18, 27]),
    ([-27, -18, -9], [-9, -18, -27]),
    ([0, 1, -1], [-1, 0, 1]),
    ([15, 24, 33], [15, 24, 33]),
    ([33, 24, 15], [15, 24, 33]),
    ([-15, -24, -33], [-33, -24, -15]),
    ([11, 2, 20], [2, 11, 20]),
    ([101, 11, 2], [2, 11, 101]),
    ([-101, -11, -2], [-2, -11, -101]),
    ([999, 99, 9], [9, 99, 999]),
    ([1, 1, 1], [1, 1, 1]),
    ([5, 5, 5], [5, 5, 5]),
    ([-5, -5, -5], [-5, -5, -5]),
    ([10, 1, 10], [1, 10, 10]),
    ([100, 10, 100], [10, 100, 100]),
    ([0, 10, 20, 30], [0, 10, 20, 30]),
    ([30, 20, 10, 0], [0, 10, 20, 30]),
    ([-30, -20, -10, 0], [-10, 0, -20, -30]),
    ([123, 321, 213], [123, 213, 321]),
    ([1000, 100, 10, 1], [1, 10, 100, 1000]),
    ([-1000, -100, -10, -1], [-1, -10, -100, -1000]),
    ([505, 514, 523], [505, 514, 523]),
    ([9999, 999, 99, 9], [9, 99, 999, 9999]),
])
def test_order_by_points(input_list, expected):
    assert order_by_points(input_list) == expected


def test_order_by_points_preserves_order_for_equal_sums():
    result = order_by_points([11, 20, 2])
    assert result == [2, 11, 20]


def test_order_by_points_negative_and_positive_mix():
    result = order_by_points([1, -1, 2, -2])
    assert result == [-1, 1, -2, 2]


def test_order_by_points_large_numbers():
    result = order_by_points([9999999, 1, 10])
    assert result[0] == 1
    assert result[1] == 10


def test_order_by_points_single_element():
    assert order_by_points([42]) == [42]


def test_order_by_points_two_elements():
    assert order_by_points([20, 11]) == [11, 20]


def test_order_by_points_stability():
    nums = [12, 21, 30]
    result = order_by_points(nums)
    assert result == [30, 12, 21]