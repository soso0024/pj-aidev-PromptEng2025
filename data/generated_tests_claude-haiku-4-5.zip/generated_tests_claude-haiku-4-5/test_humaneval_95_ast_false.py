# Test cases for HumanEval/95
# Generated using Claude API


def check_dict_case(dict):
    """
    Given a dictionary, return True if all keys are strings in lower 
    case or all keys are strings in upper case, else return False.
    The function should return False is the given dictionary is empty.
    Examples:
    check_dict_case({"a":"apple", "b":"banana"}) should return True.
    check_dict_case({"a":"apple", "A":"banana", "B":"banana"}) should return False.
    check_dict_case({"a":"apple", 8:"banana", "a":"apple"}) should return False.
    check_dict_case({"Name":"John", "Age":"36", "City":"Houston"}) should return False.
    check_dict_case({"STATE":"NC", "ZIP":"12345" }) should return True.
    """

    if len(dict.keys()) == 0:
        return False
    else:
        state = "start"
        for key in dict.keys():

            if isinstance(key, str) == False:
                state = "mixed"
                break
            if state == "start":
                if key.isupper():
                    state = "upper"
                elif key.islower():
                    state = "lower"
                else:
                    break
            elif (state == "upper" and not key.isupper()) or (state == "lower" and not key.islower()):
                    state = "mixed"
                    break
            else:
                break
        return state == "upper" or state == "lower" 


# Generated test cases:
import pytest


class TestCheckDictCase:
    
    def test_empty_dict(self):
        def check_dict_case(dict):
            if len(dict.keys()) == 0:
                return False
            else:
                state = "start"
                for key in dict.keys():

                    if isinstance(key, str) == False:
                        state = "mixed"
                        break
                    if state == "start":
                        if key.isupper():
                            state = "upper"
                        elif key.islower():
                            state = "lower"
                        else:
                            break
                    elif (state == "upper" and not key.isupper()) or (state == "lower" and not key.islower()):
                            state = "mixed"
                            break
                    else:
                        break
                return state == "upper" or state == "lower"
        assert check_dict_case({}) == False
    
    def test_single_uppercase_key(self):
        def check_dict_case(dict):
            if len(dict.keys()) == 0:
                return False
            else:
                state = "start"
                for key in dict.keys():

                    if isinstance(key, str) == False:
                        state = "mixed"
                        break
                    if state == "start":
                        if key.isupper():
                            state = "upper"
                        elif key.islower():
                            state = "lower"
                        else:
                            break
                    elif (state == "upper" and not key.isupper()) or (state == "lower" and not key.islower()):
                            state = "mixed"
                            break
                    else:
                        break
                return state == "upper" or state == "lower"
        assert check_dict_case({"A": 1}) == True
    
    def test_single_lowercase_key(self):
        def check_dict_case(dict):
            if len(dict.keys()) == 0:
                return False
            else:
                state = "start"
                for key in dict.keys():

                    if isinstance(key, str) == False:
                        state = "mixed"
                        break
                    if state == "start":
                        if key.isupper():
                            state = "upper"
                        elif key.islower():
                            state = "lower"
                        else:
                            break
                    elif (state == "upper" and not key.isupper()) or (state == "lower" and not key.islower()):
                            state = "mixed"
                            break
                    else:
                        break
                return state == "upper" or state == "lower"
        assert check_dict_case({"a": 1}) == True
    
    def test_multiple_uppercase_keys(self):
        def check_dict_case(dict):
            if len(dict.keys()) == 0:
                return False
            else:
                state = "start"
                for key in dict.keys():

                    if isinstance(key, str) == False:
                        state = "mixed"
                        break
                    if state == "start":
                        if key.isupper():
                            state = "upper"
                        elif key.islower():
                            state = "lower"
                        else:
                            break
                    elif (state == "upper" and not key.isupper()) or (state == "lower" and not key.islower()):
                            state = "mixed"
                            break
                    else:
                        break
                return state == "upper" or state == "lower"
        assert check_dict_case({"A": 1, "B": 2, "C": 3}) == True
    
    def test_multiple_lowercase_keys(self):
        def check_dict_case(dict):
            if len(dict.keys()) == 0:
                return False
            else:
                state = "start"
                for key in dict.keys():

                    if isinstance(key, str) == False:
                        state = "mixed"
                        break
                    if state == "start":
                        if key.isupper():
                            state = "upper"
                        elif key.islower():
                            state = "lower"
                        else:
                            break
                    elif (state == "upper" and not key.isupper()) or (state == "lower" and not key.islower()):
                            state = "mixed"
                            break
                    else:
                        break
                return state == "upper" or state == "lower"
        assert check_dict_case({"a": 1, "b": 2, "c": 3}) == True
    
    def test_mixed_case_keys(self):
        def check_dict_case(dict):
            if len(dict.keys()) == 0:
                return False
            else:
                state = "start"
                for key in dict.keys():

                    if isinstance(key, str) == False:
                        state = "mixed"
                        break
                    if state == "start":
                        if key.isupper():
                            state = "upper"
                        elif key.islower():
                            state = "lower"
                        else:
                            break
                    elif (state == "upper" and not key.isupper()) or (state == "lower" and not key.islower()):
                            state = "mixed"
                            break
                    else:
                        break
                return state == "upper" or state == "lower"
        assert check_dict_case({"A": 1, "b": 2}) == False
    
    def test_uppercase_then_lowercase(self):
        def check_dict_case(dict):
            if len(dict.keys()) == 0:
                return False
            else:
                state = "start"
                for key in dict.keys():

                    if isinstance(key, str) == False:
                        state = "mixed"
                        break
                    if state == "start":
                        if key.isupper():
                            state = "upper"
                        elif key.islower():
                            state = "lower"
                        else:
                            break
                    elif (state == "upper" and not key.isupper()) or (state == "lower" and not key.islower()):
                            state = "mixed"
                            break
                    else:
                        break
                return state == "upper" or state == "lower"
        assert check_dict_case({"A": 1, "B": 2, "c": 3}) == False
    
    def test_lowercase_then_uppercase(self):
        def check_dict_case(dict):
            if len(dict.keys()) == 0:
                return False
            else:
                state = "start"
                for key in dict.keys():

                    if isinstance(key, str) == False:
                        state = "mixed"
                        break
                    if state == "start":
                        if key.isupper():
                            state = "upper"
                        elif key.islower():
                            state = "lower"
                        else:
                            break
                    elif (state == "upper" and not key.isupper()) or (state == "lower" and not key.islower()):
                            state = "mixed"
                            break
                    else:
                        break
                return state == "upper" or state == "lower"
        assert check_dict_case({"a": 1, "b": 2, "C": 3}) == False
    
    def test_non_string_key(self):
        def check_dict_case(dict):
            if len(dict.keys()) == 0:
                return False
            else:
                state = "start"
                for key in dict.keys():

                    if isinstance(key, str) == False:
                        state = "mixed"
                        break
                    if state == "start":
                        if key.isupper():
                            state = "upper"
                        elif key.islower():
                            state = "lower"
                        else:
                            break
                    elif (state == "upper" and not key.isupper()) or (state == "lower" and not key.islower()):
                            state = "mixed"
                            break
                    else:
                        break
                return state == "upper" or state == "lower"
        assert check_dict_case({1: "value"}) == False
    
    def test_mixed_string_and_non_string_keys(self):
        def check_dict_case(dict):
            if len(dict.keys()) == 0:
                return False
            else:
                state = "start"
                for key in dict.keys():

                    if isinstance(key, str) == False:
                        state = "mixed"
                        break
                    if state == "start":
                        if key.isupper():
                            state = "upper"
                        elif key.islower():
                            state = "lower"
                        else:
                            break
                    elif (state == "upper" and not key.isupper()) or (state == "lower" and not key.islower()):
                            state = "mixed"
                            break
                    else:
                        break
                return state == "upper" or state == "lower"
        assert check_dict_case({"A": 1, 2: "value"}) == False
    
    def test_uppercase_with_numbers(self):
        def check_dict_case(dict):
            if len(dict.keys()) == 0:
                return False
            else:
                state = "start"
                for key in dict.keys():

                    if isinstance(key, str) == False:
                        state = "mixed"
                        break
                    if state == "start":
                        if key.isupper():
                            state = "upper"
                        elif key.islower():
                            state = "lower"
                        else:
                            break
                    elif (state == "upper" and not key.isupper()) or (state == "lower" and not key.islower()):
                            state = "mixed"
                            break
                    else:
                        break
                return state == "upper" or state == "lower"
        assert check_dict_case({"A1": 1, "B2": 2}) == True
    
    def test_lowercase_with_numbers(self):
        def check_dict_case(dict):
            if len(dict.keys()) == 0:
                return False
            else:
                state = "start"
                for key in dict.keys():

                    if isinstance(key, str) == False:
                        state = "mixed"
                        break
                    if state == "start":
                        if key.isupper():
                            state = "upper"
                        elif key.islower():
                            state = "lower"
                        else:
                            break
                    elif (state == "upper" and not key.isupper()) or (state == "lower" and not key.islower()):
                            state = "mixed"
                            break
                    else:
                        break
                return state == "upper" or state == "lower"
        assert check_dict_case({"a1": 1, "b2": 2}) == True
    
    def test_mixed_case_with_numbers(self):
        def check_dict_case(dict):
            if len(dict.keys()) == 0:
                return False
            else:
                state = "start"
                for key in dict.keys():

                    if isinstance(key, str) == False:
                        state = "mixed"
                        break
                    if state == "start":
                        if key.isupper():
                            state = "upper"
                        elif key.islower():
                            state = "lower"
                        else:
                            break
                    elif (state == "upper" and not key.isupper()) or (state == "lower" and not key.islower()):
                            state = "mixed"
                            break
                    else:
                        break
                return state ==