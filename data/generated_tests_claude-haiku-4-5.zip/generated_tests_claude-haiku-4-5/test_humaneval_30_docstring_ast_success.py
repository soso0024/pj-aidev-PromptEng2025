# Test cases for HumanEval/30
# Generated using Claude API



def get_positive(l: list):
    """Return only positive numbers in the list.
    >>> get_positive([-1, 2, -4, 5, 6])
    [2, 5, 6]
    >>> get_positive([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    [5, 3, 2, 3, 9, 123, 1]
    """

    return [e for e in l if e > 0]


# Generated test cases:
import pytest


def get_positive(l: list):
    return [e for e in l if e > 0]


class TestGetPositive:
    def test_example_1(self):
        assert get_positive([-1, 2, -4, 5, 6]) == [2, 5, 6]

    def test_example_2(self):
        assert get_positive([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10]) == [5, 3, 2, 3, 9, 123, 1]

    def test_empty_list(self):
        assert get_positive([]) == []

    def test_all_positive(self):
        assert get_positive([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

    def test_all_negative(self):
        assert get_positive([-1, -2, -3, -4, -5]) == []

    def test_all_zeros(self):
        assert get_positive([0, 0, 0]) == []

    def test_single_positive(self):
        assert get_positive([5]) == [5]

    def test_single_negative(self):
        assert get_positive([-5]) == []

    def test_single_zero(self):
        assert get_positive([0]) == []

    def test_mixed_with_zeros(self):
        assert get_positive([0, 1, 0, 2, 0, 3]) == [1, 2, 3]

    def test_large_positive_numbers(self):
        assert get_positive([1000000, -1000000, 999999]) == [1000000, 999999]

    def test_floats_positive(self):
        assert get_positive([1.5, -2.5, 3.7, 0.0]) == [1.5, 3.7]

    def test_floats_negative(self):
        assert get_positive([-1.5, -2.5, -3.7]) == []

    def test_mixed_int_float(self):
        assert get_positive([1, -2.5, 3, 4.5, -5]) == [1, 3, 4.5]

    def test_preserves_order(self):
        assert get_positive([5, 1, 3, 2, 4]) == [5, 1, 3, 2, 4]

    def test_preserves_duplicates(self):
        assert get_positive([1, 1, 2, 2, 3, 3]) == [1, 1, 2, 2, 3, 3]

    def test_very_small_positive(self):
        assert get_positive([0.0001, -0.0001, 0.00001]) == [0.0001, 0.00001]

    @pytest.mark.parametrize("input_list,expected", [
        ([1, 2, 3], [1, 2, 3]),
        ([-1, -2, -3], []),
        ([0, 0, 0], []),
        ([1, -1, 2, -2], [1, 2]),
        ([100], [100]),
        ([-100], []),
    ])
    def test_parametrized(self, input_list, expected):
        assert get_positive(input_list) == expected
