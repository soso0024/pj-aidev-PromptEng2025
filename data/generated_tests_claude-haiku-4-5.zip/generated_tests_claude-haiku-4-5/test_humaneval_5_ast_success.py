# Test cases for HumanEval/5
# Generated using Claude API

from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """ Insert a number 'delimeter' between every two consecutive elements of input list `numbers'
    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """

    if not numbers:
        return []

    result = []

    for n in numbers[:-1]:
        result.append(n)
        result.append(delimeter)

    result.append(numbers[-1])

    return result


# Generated test cases:
import pytest
from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    if not numbers:
        return []

    result = []

    for n in numbers[:-1]:
        result.append(n)
        result.append(delimeter)

    result.append(numbers[-1])

    return result


class TestIntersperse:
    def test_empty_list(self):
        assert intersperse([], 0) == []

    def test_single_element(self):
        assert intersperse([1], 0) == [1]

    def test_two_elements(self):
        assert intersperse([1, 2], 0) == [1, 0, 2]

    def test_three_elements(self):
        assert intersperse([1, 2, 3], 0) == [1, 0, 2, 0, 3]

    def test_multiple_elements(self):
        assert intersperse([1, 2, 3, 4, 5], 0) == [1, 0, 2, 0, 3, 0, 4, 0, 5]

    def test_negative_delimiter(self):
        assert intersperse([1, 2, 3], -1) == [1, -1, 2, -1, 3]

    def test_negative_numbers(self):
        assert intersperse([-1, -2, -3], 0) == [-1, 0, -2, 0, -3]

    def test_zero_delimiter(self):
        assert intersperse([5, 10, 15], 0) == [5, 0, 10, 0, 15]

    def test_large_delimiter(self):
        assert intersperse([1, 2, 3], 999) == [1, 999, 2, 999, 3]

    def test_all_same_numbers(self):
        assert intersperse([5, 5, 5], 1) == [5, 1, 5, 1, 5]

    def test_delimiter_same_as_numbers(self):
        assert intersperse([1, 1, 1], 1) == [1, 1, 1, 1, 1]

    def test_large_list(self):
        numbers = list(range(100))
        result = intersperse(numbers, -1)
        assert len(result) == 199
        assert result[0] == 0
        assert result[1] == -1
        assert result[-1] == 99

    def test_preserves_order(self):
        assert intersperse([10, 20, 30, 40], 5) == [10, 5, 20, 5, 30, 5, 40]

    def test_result_length(self):
        numbers = [1, 2, 3, 4]
        result = intersperse(numbers, 0)
        assert len(result) == 2 * len(numbers) - 1

    def test_result_length_single_element(self):
        result = intersperse([42], 0)
        assert len(result) == 1

    def test_result_length_empty(self):
        result = intersperse([], 0)
        assert len(result) == 0

    @pytest.mark.parametrize("numbers,delimeter,expected", [
        ([1], 0, [1]),
        ([1, 2], 0, [1, 0, 2]),
        ([1, 2, 3], 0, [1, 0, 2, 0, 3]),
        ([5, 10], 3, [5, 3, 10]),
        ([-1, -2], 0, [-1, 0, -2]),
        ([100, 200, 300], 50, [100, 50, 200, 50, 300]),
    ])
    def test_parametrized_cases(self, numbers, delimeter, expected):
        assert intersperse(numbers, delimeter) == expected

    def test_does_not_modify_input(self):
        original = [1, 2, 3]
        original_copy = original.copy()
        intersperse(original, 0)
        assert original == original_copy

    def test_returns_new_list(self):
        numbers = [1, 2, 3]
        result = intersperse(numbers, 0)
        assert result is not numbers

    def test_mixed_positive_negative(self):
        assert intersperse([-5, 10, -3, 8], 0) == [-5, 0, 10, 0, -3, 0, 8]

    def test_zero_in_numbers(self):
        assert intersperse([0, 1, 0], 5) == [0, 5, 1, 5, 0]

    def test_all_zeros(self):
        assert intersperse([0, 0, 0], 1) == [0, 1, 0, 1, 0]
