# Test cases for HumanEval/133
# Generated using Claude API



def sum_squares(lst):
    """You are given a list of numbers.
    You need to return the sum of squared numbers in the given list,
    round each element in the list to the upper int(Ceiling) first.
    Examples:
    For lst = [1,2,3] the output should be 14
    For lst = [1,4,9] the output should be 98
    For lst = [1,3,5,7] the output should be 84
    For lst = [1.4,4.2,0] the output should be 29
    For lst = [-2.4,1,1] the output should be 6
    

    """

    import math
    squared = 0
    for i in lst:
        squared += math.ceil(i)**2
    return squared


# Generated test cases:
import pytest
import math


def sum_squares(lst):
    squared = 0
    for i in lst:
        squared += math.ceil(i)**2
    return squared


@pytest.mark.parametrize("lst,expected", [
    ([1, 2, 3], 14),
    ([1, 4, 9], 98),
    ([1, 3, 5, 7], 84),
    ([1.4, 4.2, 0], 29),
    ([-2.4, 1, 1], 6),
])
def test_sum_squares_examples(lst, expected):
    assert sum_squares(lst) == expected


def test_sum_squares_empty_list():
    assert sum_squares([]) == 0


def test_sum_squares_single_element():
    assert sum_squares([5]) == 25


def test_sum_squares_single_element_float():
    assert sum_squares([5.1]) == 36


def test_sum_squares_all_zeros():
    assert sum_squares([0, 0, 0]) == 0


def test_sum_squares_negative_numbers():
    assert sum_squares([-1, -2, -3]) == 14


def test_sum_squares_negative_floats():
    assert sum_squares([-1.5, -2.5]) == 5


def test_sum_squares_mixed_positive_negative():
    assert sum_squares([-1, 2, -3, 4]) == 30


def test_sum_squares_ceiling_behavior():
    assert sum_squares([1.1]) == 4
    assert sum_squares([1.9]) == 4
    assert sum_squares([2.0]) == 4


def test_sum_squares_ceiling_negative():
    assert sum_squares([-1.1]) == 1
    assert sum_squares([-1.9]) == 1
    assert sum_squares([-2.0]) == 4


def test_sum_squares_large_numbers():
    assert sum_squares([100, 200]) == 50000


def test_sum_squares_large_floats():
    assert sum_squares([99.5, 199.9]) == 50000


def test_sum_squares_very_small_floats():
    assert sum_squares([0.1, 0.2, 0.3]) == 3


def test_sum_squares_fractional_values():
    assert sum_squares([0.5, 1.5, 2.5]) == 14


def test_sum_squares_many_elements():
    assert sum_squares([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == 385


def test_sum_squares_repeated_elements():
    assert sum_squares([2, 2, 2]) == 12


def test_sum_squares_zero_with_others():
    assert sum_squares([0, 1, 2]) == 5


def test_sum_squares_negative_zero():
    assert sum_squares([-0.0]) == 0


def test_sum_squares_precision():
    result = sum_squares([1.0000001])
    assert result == 4


def test_sum_squares_negative_fractional():
    assert sum_squares([-0.5, -0.1]) == 0