# Test cases for HumanEval/100
# Generated using Claude API


def make_a_pile(n):
    """
    Given a positive integer n, you have to make a pile of n levels of stones.
    The first level has n stones.
    The number of stones in the next level is:
        - the next odd number if n is odd.
        - the next even number if n is even.
    Return the number of stones in each level in a list, where element at index
    i represents the number of stones in the level (i+1).

    Examples:
    >>> make_a_pile(3)
    [3, 5, 7]
    """

    return [n + 2*i for i in range(n)]


# Generated test cases:
import pytest


def make_a_pile(n):
    return [n + 2*i for i in range(n)]


class TestMakeAPile:
    
    def test_example_case_n_3(self):
        assert make_a_pile(3) == [3, 5, 7]
    
    def test_n_1(self):
        assert make_a_pile(1) == [1]
    
    def test_n_2(self):
        assert make_a_pile(2) == [2, 4]
    
    def test_n_4(self):
        assert make_a_pile(4) == [4, 6, 8, 10]
    
    def test_n_5(self):
        assert make_a_pile(5) == [5, 7, 9, 11, 13]
    
    def test_n_6(self):
        assert make_a_pile(6) == [6, 8, 10, 12, 14, 16]
    
    def test_n_10(self):
        result = make_a_pile(10)
        assert len(result) == 10
        assert result[0] == 10
        assert result[-1] == 28
        assert result == [10, 12, 14, 16, 18, 20, 22, 24, 26, 28]
    
    def test_odd_numbers_sequence(self):
        result = make_a_pile(7)
        assert len(result) == 7
        assert result == [7, 9, 11, 13, 15, 17, 19]
        for i in range(len(result)):
            assert result[i] == 7 + 2*i
    
    def test_even_numbers_sequence(self):
        result = make_a_pile(8)
        assert len(result) == 8
        assert result == [8, 10, 12, 14, 16, 18, 20, 22]
        for i in range(len(result)):
            assert result[i] == 8 + 2*i
    
    def test_return_type_is_list(self):
        result = make_a_pile(3)
        assert isinstance(result, list)
    
    def test_all_elements_are_integers(self):
        result = make_a_pile(5)
        for element in result:
            assert isinstance(element, int)
    
    def test_list_length_equals_n(self):
        for n in [1, 2, 3, 5, 10, 15]:
            result = make_a_pile(n)
            assert len(result) == n
    
    def test_increasing_sequence(self):
        result = make_a_pile(6)
        for i in range(len(result) - 1):
            assert result[i] < result[i + 1]
    
    def test_difference_between_consecutive_elements(self):
        result = make_a_pile(5)
        for i in range(len(result) - 1):
            assert result[i + 1] - result[i] == 2
    
    def test_large_n(self):
        result = make_a_pile(100)
        assert len(result) == 100
        assert result[0] == 100
        assert result[-1] == 100 + 2*99
        assert result[-1] == 298
    
    def test_first_element_equals_n(self):
        for n in [1, 2, 3, 5, 10, 20]:
            result = make_a_pile(n)
            assert result[0] == n
    
    def test_arithmetic_progression(self):
        result = make_a_pile(9)
        assert len(result) == 9
        for i in range(len(result)):
            assert result[i] == 9 + 2*i
    
    @pytest.mark.parametrize("n,expected", [
        (1, [1]),
        (2, [2, 4]),
        (3, [3, 5, 7]),
        (4, [4, 6, 8, 10]),
        (5, [5, 7, 9, 11, 13]),
    ])
    def test_parametrized_cases(self, n, expected):
        assert make_a_pile(n) == expected
