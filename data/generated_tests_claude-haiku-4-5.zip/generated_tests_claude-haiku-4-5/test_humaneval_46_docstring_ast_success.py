# Test cases for HumanEval/46
# Generated using Claude API



def fib4(n: int):
    """The Fib4 number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fib4(0) -> 0
    fib4(1) -> 0
    fib4(2) -> 2
    fib4(3) -> 0
    fib4(n) -> fib4(n-1) + fib4(n-2) + fib4(n-3) + fib4(n-4).
    Please write a function to efficiently compute the n-th element of the fib4 number sequence.  Do not use recursion.
    >>> fib4(5)
    4
    >>> fib4(6)
    8
    >>> fib4(7)
    14
    """

    results = [0, 0, 2, 0]
    if n < 4:
        return results[n]

    for _ in range(4, n + 1):
        results.append(results[-1] + results[-2] + results[-3] + results[-4])
        results.pop(0)

    return results[-1]


# Generated test cases:
import pytest


class TestFib4:
    
    @pytest.mark.parametrize("n,expected", [
        (0, 0),
        (1, 0),
        (2, 2),
        (3, 0),
    ])
    def test_base_cases(self, n, expected):
        from test_humaneval_46_docstring_ast import fib4
        assert fib4(n) == expected
    
    @pytest.mark.parametrize("n,expected", [
        (4, 2),
        (5, 4),
        (6, 8),
        (7, 14),
    ])
    def test_documented_cases(self, n, expected):
        assert fib4(n) == expected
    
    @pytest.mark.parametrize("n,expected", [
        (8, 28),
        (9, 54),
        (10, 104),
    ])
    def test_extended_sequence(self, n, expected):
        assert fib4(n) == expected
    
    def test_fib4_5(self):
        assert fib4(5) == 4
    
    def test_fib4_6(self):
        assert fib4(6) == 8
    
    def test_fib4_7(self):
        assert fib4(7) == 14
    
    def test_fib4_0(self):
        assert fib4(0) == 0
    
    def test_fib4_1(self):
        assert fib4(1) == 0
    
    def test_fib4_2(self):
        assert fib4(2) == 2
    
    def test_fib4_3(self):
        assert fib4(3) == 0
    
    def test_fib4_4(self):
        assert fib4(4) == 2
    
    def test_fib4_large_number(self):
        result = fib4(20)
        assert isinstance(result, int)
        assert result > 0
    
    def test_fib4_sequence_growth(self):
        prev = fib4(5)
        curr = fib4(6)
        assert curr > prev
    
    def test_fib4_returns_integer(self):
        for n in range(10):
            result = fib4(n)
            assert isinstance(result, int)
    
    def test_fib4_non_negative(self):
        for n in range(15):
            result = fib4(n)
            assert result >= 0
    
    def test_fib4_11(self):
        assert fib4(11) == 200
    
    def test_fib4_12(self):
        assert fib4(12) == 386
    
    def test_fib4_13(self):
        assert fib4(13) == 744
    
    def test_fib4_14(self):
        assert fib4(14) == 1434
    
    def test_fib4_15(self):
        assert fib4(15) == 2764


class TestFib4EdgeCases:
    
    def test_fib4_zero(self):
        assert fib4(0) == 0
    
    def test_fib4_one(self):
        assert fib4(1) == 0
    
    def test_fib4_two(self):
        assert fib4(2) == 2
    
    def test_fib4_three(self):
        assert fib4(3) == 0
    
    def test_fib4_boundary_at_4(self):
        assert fib4(4) == fib4(3) + fib4(2) + fib4(1) + fib4(0)
    
    def test_fib4_very_large_n(self):
        result = fib4(50)
        assert isinstance(result, int)
        assert result > 0


class TestFib4Properties:
    
    def test_fib4_monotonic_increase_after_base(self):
        values = [fib4(n) for n in range(4, 12)]
        for i in range(1, len(values)):
            assert values[i] >= values[i-1]
    
    def test_fib4_recurrence_relation(self):
        for n in range(4, 10):
            expected = fib4(n-1) + fib4(n-2) + fib4(n-3) + fib4(n-4)
            assert fib4(n) == expected
    
    def test_fib4_consistency(self):
        assert fib4(5) == fib4(5)
        assert fib4(10) == fib4(10)