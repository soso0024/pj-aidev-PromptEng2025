# Test cases for HumanEval/60
# Generated using Claude API



def sum_to_n(n: int):
    """sum_to_n is a function that sums numbers from 1 to n.
    >>> sum_to_n(30)
    465
    >>> sum_to_n(100)
    5050
    >>> sum_to_n(5)
    15
    >>> sum_to_n(10)
    55
    >>> sum_to_n(1)
    1
    """

    return sum(range(n + 1))


# Generated test cases:
import pytest


def sum_to_n(n: int):
    return sum(range(n + 1))


class TestSumToN:
    
    @pytest.mark.parametrize("n,expected", [
        (1, 1),
        (5, 15),
        (10, 55),
        (30, 465),
        (100, 5050),
    ])
    def test_sum_to_n_basic_cases(self, n, expected):
        assert sum_to_n(n) == expected
    
    def test_sum_to_n_zero(self):
        assert sum_to_n(0) == 0
    
    def test_sum_to_n_two(self):
        assert sum_to_n(2) == 3
    
    def test_sum_to_n_three(self):
        assert sum_to_n(3) == 6
    
    def test_sum_to_n_large_number(self):
        assert sum_to_n(1000) == 500500
    
    def test_sum_to_n_very_large_number(self):
        assert sum_to_n(10000) == 50005000
    
    @pytest.mark.parametrize("n,expected", [
        (4, 10),
        (6, 21),
        (7, 28),
        (8, 36),
        (9, 45),
        (15, 120),
        (20, 210),
        (50, 1275),
    ])
    def test_sum_to_n_various_values(self, n, expected):
        assert sum_to_n(n) == expected
    
    def test_sum_to_n_returns_integer(self):
        result = sum_to_n(5)
        assert isinstance(result, int)
    
    def test_sum_to_n_formula_verification(self):
        n = 25
        expected = n * (n + 1) // 2
        assert sum_to_n(n) == expected
    
    def test_sum_to_n_incremental(self):
        assert sum_to_n(1) == 1
        assert sum_to_n(2) == sum_to_n(1) + 2
        assert sum_to_n(3) == sum_to_n(2) + 3
        assert sum_to_n(4) == sum_to_n(3) + 4
    
    def test_sum_to_n_negative_number(self):
        assert sum_to_n(-1) == 0
    
    def test_sum_to_n_negative_large_number(self):
        assert sum_to_n(-10) == 0
