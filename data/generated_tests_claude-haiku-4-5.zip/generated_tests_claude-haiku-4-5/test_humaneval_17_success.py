# Test cases for HumanEval/17
# Generated using Claude API

from typing import List


def parse_music(music_string: str) -> List[int]:
    """ Input to this function is a string representing musical notes in a special ASCII format.
    Your task is to parse this string and return list of integers corresponding to how many beats does each
    not last.

    Here is a legend:
    'o' - whole note, lasts four beats
    'o|' - half note, lasts two beats
    '.|' - quater note, lasts one beat

    >>> parse_music('o o| .| o| o| .| .| .| .| o o')
    [4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4]
    """

    note_map = {'o': 4, 'o|': 2, '.|': 1}
    return [note_map[x] for x in music_string.split(' ') if x]


# Generated test cases:
import pytest
from typing import List


def parse_music(music_string: str) -> List[int]:
    note_map = {'o': 4, 'o|': 2, '.|': 1}
    return [note_map[x] for x in music_string.split(' ') if x]


class TestParseMusic:
    def test_single_whole_note(self):
        assert parse_music('o') == [4]

    def test_single_half_note(self):
        assert parse_music('o|') == [2]

    def test_single_quarter_note(self):
        assert parse_music('.|') == [1]

    def test_multiple_notes(self):
        assert parse_music('o o| .|') == [4, 2, 1]

    def test_repeated_notes(self):
        assert parse_music('o o o') == [4, 4, 4]

    def test_mixed_notes(self):
        assert parse_music('o o| o .| o|') == [4, 2, 4, 1, 2]

    def test_empty_string(self):
        assert parse_music('') == []

    def test_only_spaces(self):
        assert parse_music('   ') == []

    def test_extra_spaces_between_notes(self):
        assert parse_music('o  o|   .|') == [4, 2, 1]

    def test_leading_spaces(self):
        assert parse_music('  o o|') == [4, 2]

    def test_trailing_spaces(self):
        assert parse_music('o o|  ') == [4, 2]

    def test_leading_and_trailing_spaces(self):
        assert parse_music('  o o| .|  ') == [4, 2, 1]

    def test_single_space(self):
        assert parse_music(' ') == []

    def test_multiple_consecutive_spaces(self):
        assert parse_music('o     o|') == [4, 2]

    @pytest.mark.parametrize("music_input,expected", [
        ('o', [4]),
        ('o|', [2]),
        ('.|', [1]),
        ('o o| .|', [4, 2, 1]),
        ('o o o o', [4, 4, 4, 4]),
        ('o| o| o|', [2, 2, 2]),
    ])
    def test_parametrized_valid_inputs(self, music_input, expected):
        assert parse_music(music_input) == expected

    def test_long_sequence(self):
        result = parse_music('o o| .| o o| .| o o| .|')
        assert result == [4, 2, 1, 4, 2, 1, 4, 2, 1]

    def test_return_type_is_list(self):
        result = parse_music('o o|')
        assert isinstance(result, list)

    def test_return_elements_are_integers(self):
        result = parse_music('o o| .|')
        assert all(isinstance(x, int) for x in result)

    def test_all_note_types_present(self):
        result = parse_music('o o| .|')
        assert 4 in result
        assert 2 in result
        assert 1 in result

    def test_order_preserved(self):
        result = parse_music('.| o| o')
        assert result == [1, 2, 4]

    def test_complex_pattern(self):
        result = parse_music('o .| o| .| o o o|')
        assert result == [4, 1, 2, 1, 4, 4, 2]