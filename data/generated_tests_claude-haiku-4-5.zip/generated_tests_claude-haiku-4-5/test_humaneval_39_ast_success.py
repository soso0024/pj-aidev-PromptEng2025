# Test cases for HumanEval/39
# Generated using Claude API



def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """

    import math

    def is_prime(p):
        if p < 2:
            return False
        for k in range(2, min(int(math.sqrt(p)) + 1, p - 1)):
            if p % k == 0:
                return False
        return True
    f = [0, 1]
    while True:
        f.append(f[-1] + f[-2])
        if is_prime(f[-1]):
            n -= 1
        if n == 0:
            return f[-1]


# Generated test cases:
import pytest


def prime_fib(n: int):
    import math

    def is_prime(p):
        if p < 2:
            return False
        for k in range(2, min(int(math.sqrt(p)) + 1, p - 1)):
            if p % k == 0:
                return False
        return True
    f = [0, 1]
    while True:
        f.append(f[-1] + f[-2])
        if is_prime(f[-1]):
            n -= 1
        if n == 0:
            return f[-1]


class TestPrimeFib:
    def test_first_prime_fib(self):
        assert prime_fib(1) == 2

    def test_second_prime_fib(self):
        assert prime_fib(2) == 3

    def test_third_prime_fib(self):
        assert prime_fib(3) == 5

    def test_fourth_prime_fib(self):
        assert prime_fib(4) == 13

    def test_fifth_prime_fib(self):
        assert prime_fib(5) == 89

    def test_sixth_prime_fib(self):
        assert prime_fib(6) == 233

    def test_seventh_prime_fib(self):
        assert prime_fib(7) == 1597

    def test_eighth_prime_fib(self):
        assert prime_fib(8) == 28657

    def test_ninth_prime_fib(self):
        assert prime_fib(9) == 514229

    def test_tenth_prime_fib(self):
        assert prime_fib(10) == 433494437

    @pytest.mark.parametrize("n,expected", [
        (1, 2),
        (2, 3),
        (3, 5),
        (4, 13),
        (5, 89),
        (6, 233),
        (7, 1597),
    ])
    def test_prime_fib_parametrized(self, n, expected):
        assert prime_fib(n) == expected

    def test_large_n(self):
        result = prime_fib(11)
        assert isinstance(result, int)
        assert result > 0

    def test_result_is_prime(self):
        result = prime_fib(1)
        assert result == 2
        assert result > 1

    def test_result_is_fibonacci(self):
        result = prime_fib(3)
        assert result == 5
        fib_sequence = [0, 1]
        while fib_sequence[-1] < result:
            fib_sequence.append(fib_sequence[-1] + fib_sequence[-2])
        assert result in fib_sequence

    def test_increasing_sequence(self):
        results = [prime_fib(i) for i in range(1, 6)]
        for i in range(len(results) - 1):
            assert results[i] < results[i + 1]

    def test_return_type_is_int(self):
        result = prime_fib(1)
        assert isinstance(result, int)

    def test_positive_result(self):
        result = prime_fib(1)
        assert result > 0

    def test_multiple_calls_consistency(self):
        assert prime_fib(1) == prime_fib(1)
        assert prime_fib(5) == prime_fib(5)

    def test_prime_fib_12(self):
        result = prime_fib(12)
        assert isinstance(result, int)
        assert result > prime_fib(11)
