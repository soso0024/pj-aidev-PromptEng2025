# Test cases for HumanEval/75
# Generated using Claude API


def is_multiply_prime(a):
    """Write a function that returns true if the given number is the multiplication of 3 prime numbers
    and false otherwise.
    Knowing that (a) is less then 100. 
    Example:
    is_multiply_prime(30) == True
    30 = 2 * 3 * 5
    """

    def is_prime(n):
        for j in range(2,n):
            if n%j == 0:
                return False
        return True

    for i in range(2,101):
        if not is_prime(i): continue
        for j in range(2,101):
            if not is_prime(j): continue
            for k in range(2,101):
                if not is_prime(k): continue
                if i*j*k == a: return True
    return False


# Generated test cases:
import pytest


class TestIsMultiplyPrime:
    
    @pytest.mark.parametrize("input_val,expected", [
        (8, True),
        (30, True),
        (42, True),
        (66, True),
        (70, True),
        (78, True),
        (102, True),
        (110, True),
        (114, True),
        (130, True),
        (154, True),
        (165, True),
        (170, True),
        (174, True),
        (182, True),
        (186, True),
        (195, True),
        (222, True),
        (230, True),
        (231, True),
        (238, True),
        (246, True),
        (255, True),
        (258, True),
        (266, True),
        (273, True),
        (282, True),
        (285, True),
        (286, True),
        (290, True),
        (310, True),
        (318, True),
        (322, True),
        (345, True),
        (357, True),
        (370, True),
        (374, True),
        (385, True),
        (399, True),
    ])
    def test_multiply_prime_true(self, input_val, expected):
        from test_humaneval_75 import is_multiply_prime
        assert is_multiply_prime(input_val) == expected
    
    @pytest.mark.parametrize("input_val,expected", [
        (1, False),
        (2, False),
        (3, False),
        (4, False),
        (5, False),
        (6, False),
        (7, False),
        (9, False),
        (10, False),
        (11, False),
        (13, False),
        (14, False),
        (15, False),
        (16, False),
        (17, False),
        (19, False),
        (21, False),
        (22, False),
        (23, False),
        (24, False),
        (25, False),
        (26, False),
        (29, False),
        (31, False),
        (32, False),
        (33, False),
        (34, False),
        (35, False),
        (36, False),
        (37, False),
        (38, False),
        (39, False),
        (40, False),
        (41, False),
        (43, False),
        (46, False),
        (47, False),
        (48, False),
        (49, False),
        (100, False),
        (1000, False),
    ])
    def test_multiply_prime_false(self, input_val, expected):
        assert is_multiply_prime(input_val) == expected
    
    def test_multiply_prime_edge_case_zero(self):
        assert is_multiply_prime(0) == False
    
    def test_multiply_prime_edge_case_negative(self):
        assert is_multiply_prime(-8) == False
    
    def test_multiply_prime_small_product(self):
        assert is_multiply_prime(8) == True
    
    def test_multiply_prime_prime_number(self):
        assert is_multiply_prime(2) == False
        assert is_multiply_prime(3) == False
        assert is_multiply_prime(5) == False
        assert is_multiply_prime(7) == False
    
    def test_multiply_prime_composite_non_triple(self):
        assert is_multiply_prime(4) == False
        assert is_multiply_prime(6) == False
        assert is_multiply_prime(9) == False