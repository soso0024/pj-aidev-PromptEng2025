# Test cases for HumanEval/83
# Generated using Claude API


def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """

    if n == 1: return 1
    return 18 * (10 ** (n - 2))


# Generated test cases:
import pytest


def starts_one_ends(n):
    if n == 1: return 1
    return 18 * (10 ** (n - 2))


class TestStartsOneEnds:
    
    @pytest.mark.parametrize("n,expected", [
        (1, 1),
        (2, 18),
        (3, 180),
        (4, 1800),
        (5, 18000),
        (6, 180000),
        (7, 1800000),
        (10, 1800000000),
    ])
    def test_valid_inputs(self, n, expected):
        assert starts_one_ends(n) == expected
    
    def test_n_equals_1(self):
        result = starts_one_ends(1)
        assert result == 1
    
    def test_n_equals_2(self):
        result = starts_one_ends(2)
        assert result == 18
    
    def test_n_equals_3(self):
        result = starts_one_ends(3)
        assert result == 180
    
    def test_large_n(self):
        result = starts_one_ends(15)
        expected = 18 * (10 ** 13)
        assert result == expected
    
    def test_return_type_is_int(self):
        result = starts_one_ends(1)
        assert isinstance(result, int)
    
    def test_return_type_is_int_for_larger_n(self):
        result = starts_one_ends(5)
        assert isinstance(result, int)
    
    def test_result_increases_with_n(self):
        result_2 = starts_one_ends(2)
        result_3 = starts_one_ends(3)
        result_4 = starts_one_ends(4)
        assert result_2 < result_3 < result_4
    
    def test_formula_consistency(self):
        for n in range(2, 8):
            result = starts_one_ends(n)
            expected = 18 * (10 ** (n - 2))
            assert result == expected
    
    def test_n_equals_2_manual_calculation(self):
        assert starts_one_ends(2) == 18
    
    def test_n_equals_3_manual_calculation(self):
        assert starts_one_ends(3) == 180
    
    def test_positive_integer_requirement(self):
        assert starts_one_ends(1) > 0
        assert starts_one_ends(2) > 0
        assert starts_one_ends(10) > 0
    
    def test_exponential_growth(self):
        result_n = starts_one_ends(5)
        result_n_plus_1 = starts_one_ends(6)
        assert result_n_plus_1 == result_n * 10
    
    def test_exponential_growth_multiple_steps(self):
        result_2 = starts_one_ends(2)
        result_5 = starts_one_ends(5)
        assert result_5 == result_2 * (10 ** 3)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])