# Test cases for HumanEval/107
# Generated using Claude API


def even_odd_palindrome(n):
    """
    Given a positive integer n, return a tuple that has the number of even and odd
    integer palindromes that fall within the range(1, n), inclusive.

    Example 1:

        Input: 3
        Output: (1, 2)
        Explanation:
        Integer palindrome are 1, 2, 3. one of them is even, and two of them are odd.

    Example 2:

        Input: 12
        Output: (4, 6)
        Explanation:
        Integer palindrome are 1, 2, 3, 4, 5, 6, 7, 8, 9, 11. four of them are even, and 6 of them are odd.

    Note:
        1. 1 <= n <= 10^3
        2. returned tuple has the number of even and odd integer palindromes respectively.
    """

    def is_palindrome(n):
        return str(n) == str(n)[::-1]

    even_palindrome_count = 0
    odd_palindrome_count = 0

    for i in range(1, n+1):
        if i%2 == 1 and is_palindrome(i):
                odd_palindrome_count += 1
        elif i%2 == 0 and is_palindrome(i):
            even_palindrome_count += 1
    return (even_palindrome_count, odd_palindrome_count)


# Generated test cases:
import pytest


def even_odd_palindrome(n):
    def is_palindrome(n):
        return str(n) == str(n)[::-1]

    even_palindrome_count = 0
    odd_palindrome_count = 0

    for i in range(1, n+1):
        if i%2 == 1 and is_palindrome(i):
                odd_palindrome_count += 1
        elif i%2 == 0 and is_palindrome(i):
            even_palindrome_count += 1
    return (even_palindrome_count, odd_palindrome_count)


class TestEvenOddPalindrome:
    
    @pytest.mark.parametrize("n,expected", [
        (1, (0, 1)),
        (2, (1, 1)),
        (3, (1, 2)),
        (4, (2, 2)),
        (5, (2, 3)),
        (9, (4, 5)),
        (10, (4, 5)),
        (11, (4, 6)),
        (12, (4, 6)),
    ])
    def test_basic_cases(self, n, expected):
        assert even_odd_palindrome(n) == expected
    
    def test_single_digit_one(self):
        result = even_odd_palindrome(1)
        assert result == (0, 1)
        assert isinstance(result, tuple)
        assert len(result) == 2
    
    def test_single_digit_two(self):
        result = even_odd_palindrome(2)
        assert result == (1, 1)
    
    def test_example_one(self):
        assert even_odd_palindrome(3) == (1, 2)
    
    def test_example_two(self):
        assert even_odd_palindrome(12) == (4, 6)
    
    def test_all_single_digits(self):
        result = even_odd_palindrome(9)
        assert result == (4, 5)
    
    def test_includes_double_digit_palindrome(self):
        result = even_odd_palindrome(11)
        assert result == (4, 6)
    
    def test_large_range(self):
        result = even_odd_palindrome(100)
        assert isinstance(result, tuple)
        assert len(result) == 2
        assert result[0] >= 0
        assert result[1] >= 0
    
    def test_maximum_constraint(self):
        result = even_odd_palindrome(1000)
        assert isinstance(result, tuple)
        assert len(result) == 2
        assert result[0] >= 0
        assert result[1] >= 0
    
    def test_return_type_is_tuple(self):
        result = even_odd_palindrome(5)
        assert isinstance(result, tuple)
        assert len(result) == 2
    
    def test_return_values_are_integers(self):
        result = even_odd_palindrome(10)
        assert isinstance(result[0], int)
        assert isinstance(result[1], int)
    
    def test_return_values_non_negative(self):
        result = even_odd_palindrome(50)
        assert result[0] >= 0
        assert result[1] >= 0
    
    def test_sum_of_palindromes(self):
        n = 20
        result = even_odd_palindrome(n)
        total_palindromes = result[0] + result[1]
        assert total_palindromes > 0
    
    def test_boundary_at_10(self):
        result = even_odd_palindrome(10)
        assert result == (4, 5)
    
    def test_boundary_at_11(self):
        result = even_odd_palindrome(11)
        assert result == (4, 6)
    
    def test_range_20_to_30(self):
        result_20 = even_odd_palindrome(20)
        result_30 = even_odd_palindrome(30)
        assert result_20[0] <= result_30[0]
        assert result_20[1] <= result_30[1]
    
    def test_palindromes_in_range_15(self):
        result = even_odd_palindrome(15)
        assert isinstance(result, tuple)
        assert result[0] + result[1] > 0
    
    def test_no_even_palindromes_below_2(self):
        result = even_odd_palindrome(1)
        assert result[0] == 0
    
    def test_odd_palindromes_always_present(self):
        for n in range(1, 20):
            result = even_odd_palindrome(n)
            assert result[1] > 0
