# Test cases for HumanEval/99
# Generated using Claude API


def closest_integer(value):
    '''
    Create a function that takes a value (string) representing a number
    and returns the closest integer to it. If the number is equidistant
    from two integers, round it away from zero.

    Examples
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15

    Note:
    Rounding away from zero means that if the given number is equidistant
    from two integers, the one you should return is the one that is the
    farthest from zero. For example closest_integer("14.5") should
    return 15 and closest_integer("-14.5") should return -15.
    '''

    from math import floor, ceil

    if value.count('.') == 1:
        # remove trailing zeros
        while (value[-1] == '0'):
            value = value[:-1]

    num = float(value)
    if value[-2:] == '.5':
        if num > 0:
            res = ceil(num)
        else:
            res = floor(num)
    elif len(value) > 0:
        res = int(round(num))
    else:
        res = 0

    return res



# Generated test cases:
import pytest
from math import floor, ceil


def closest_integer(value):

    if value.count('.') == 1:
        # remove trailing zeros
        while (value[-1] == '0'):
            value = value[:-1]

    num = float(value)
    if value[-2:] == '.5':
        if num > 0:
            res = ceil(num)
        else:
            res = floor(num)
    elif len(value) > 0:
        res = int(round(num))
    else:
        res = 0

    return res


class TestClosestInteger:
    
    @pytest.mark.parametrize("value,expected", [
        ("1.5", 2),
        ("2.5", 3),
        ("3.5", 4),
        ("10.5", 11),
        ("100.5", 101),
    ])
    def test_positive_half_values(self, value, expected):
        assert closest_integer(value) == expected
    
    @pytest.mark.parametrize("value,expected", [
        ("-1.5", -2),
        ("-2.5", -3),
        ("-3.5", -4),
        ("-10.5", -11),
        ("-100.5", -101),
    ])
    def test_negative_half_values(self, value, expected):
        assert closest_integer(value) == expected
    
    @pytest.mark.parametrize("value,expected", [
        ("1.4", 1),
        ("1.6", 2),
        ("2.3", 2),
        ("2.7", 3),
        ("3.1", 3),
        ("3.9", 4),
    ])
    def test_positive_non_half_values(self, value, expected):
        assert closest_integer(value) == expected
    
    @pytest.mark.parametrize("value,expected", [
        ("-1.4", -1),
        ("-1.6", -2),
        ("-2.3", -2),
        ("-2.7", -3),
        ("-3.1", -3),
        ("-3.9", -4),
    ])
    def test_negative_non_half_values(self, value, expected):
        assert closest_integer(value) == expected
    
    @pytest.mark.parametrize("value,expected", [
        ("1", 1),
        ("2", 2),
        ("10", 10),
        ("-1", -1),
        ("-5", -5),
        ("0", 0),
    ])
    def test_integer_values(self, value, expected):
        assert closest_integer(value) == expected
    
    @pytest.mark.parametrize("value,expected", [
        ("1.0", 1),
        ("2.0", 2),
        ("10.0", 10),
        ("-1.0", -1),
        ("-5.0", -5),
        ("0.0", 0),
    ])
    def test_trailing_zeros(self, value, expected):
        assert closest_integer(value) == expected
    
    @pytest.mark.parametrize("value,expected", [
        ("1.50", 2),
        ("2.500", 3),
        ("3.5000", 4),
        ("-1.50", -2),
        ("-2.500", -3),
    ])
    def test_trailing_zeros_with_half(self, value, expected):
        assert closest_integer(value) == expected
    
    @pytest.mark.parametrize("value,expected", [
        ("0.5", 1),
        ("-0.5", -1),
        ("0.1", 0),
        ("0.9", 1),
        ("-0.1", 0),
        ("-0.9", -1),
    ])
    def test_values_near_zero(self, value, expected):
        assert closest_integer(value) == expected
    
    @pytest.mark.parametrize("value,expected", [
        ("1.00000", 1),
        ("2.10000", 2),
        ("3.50000", 4),
        ("4.90000", 5),
    ])
    def test_multiple_trailing_zeros(self, value, expected):
        assert closest_integer(value) == expected
    
    def test_empty_string(self):
        try:
            closest_integer("")
        except ValueError:
            pass
    
    @pytest.mark.parametrize("value,expected", [
        ("0.4", 0),
        ("0.6", 1),
        ("1.2", 1),
        ("1.8", 2),
    ])
    def test_rounding_standard_cases(self, value, expected):
        assert closest_integer(value) == expected
    
    @pytest.mark.parametrize("value,expected", [
        ("999.5", 1000),
        ("-999.5", -1000),
        ("1000.5", 1001),
        ("-1000.5", -1001),
    ])
    def test_large_numbers(self, value, expected):
        assert closest_integer(value) == expected
    
    @pytest.mark.parametrize("value,expected", [
        ("0.05", 0),
        ("0.15", 0),
        ("0.25", 0),
        ("0.35", 0),
        ("0.45", 0),
        ("0.55", 1),
        ("0.65", 1),
        ("0.75", 1),
        ("0.85", 1),
        ("0.95", 1),
    ])
    def test_decimal_precision(self, value, expected):
        assert closest_integer(value) == expected