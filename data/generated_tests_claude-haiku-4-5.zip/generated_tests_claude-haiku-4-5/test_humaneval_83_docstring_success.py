# Test cases for HumanEval/83
# Generated using Claude API


def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """

    if n == 1: return 1
    return 18 * (10 ** (n - 2))


# Generated test cases:
import pytest


def starts_one_ends(n):
    if n == 1: return 1
    return 18 * (10 ** (n - 2))


class TestStartsOneEnds:
    
    @pytest.mark.parametrize("n,expected", [
        (1, 1),
        (2, 18),
        (3, 180),
        (4, 1800),
        (5, 18000),
        (6, 180000),
        (7, 1800000),
        (8, 18000000),
    ])
    def test_valid_inputs(self, n, expected):
        assert starts_one_ends(n) == expected
    
    def test_n_equals_1(self):
        assert starts_one_ends(1) == 1
    
    def test_n_equals_2(self):
        assert starts_one_ends(2) == 18
    
    def test_n_equals_3(self):
        assert starts_one_ends(3) == 180
    
    def test_large_n(self):
        result = starts_one_ends(10)
        assert result == 18 * (10 ** 8)
        assert result == 1800000000
    
    def test_return_type_is_int(self):
        result = starts_one_ends(2)
        assert isinstance(result, int)
    
    def test_return_type_is_int_for_n_1(self):
        result = starts_one_ends(1)
        assert isinstance(result, int)
    
    def test_result_is_positive(self):
        for n in range(1, 10):
            assert starts_one_ends(n) > 0
    
    def test_result_increases_with_n(self):
        prev = starts_one_ends(1)
        for n in range(2, 8):
            current = starts_one_ends(n)
            assert current > prev
            prev = current
    
    def test_n_equals_9(self):
        assert starts_one_ends(9) == 18 * (10 ** 7)
    
    def test_n_equals_15(self):
        assert starts_one_ends(15) == 18 * (10 ** 13)
    
    def test_formula_consistency(self):
        for n in range(2, 12):
            expected = 18 * (10 ** (n - 2))
            assert starts_one_ends(n) == expected
    
    def test_n_equals_20(self):
        result = starts_one_ends(20)
        assert result == 18 * (10 ** 18)
