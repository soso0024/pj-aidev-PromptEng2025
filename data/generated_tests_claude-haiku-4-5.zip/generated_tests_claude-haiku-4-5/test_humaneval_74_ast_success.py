# Test cases for HumanEval/74
# Generated using Claude API


def total_match(lst1, lst2):
    '''
    Write a function that accepts two lists of strings and returns the list that has 
    total number of chars in the all strings of the list less than the other list.

    if the two lists have the same number of chars, return the first list.

    Examples
    total_match([], []) ➞ []
    total_match(['hi', 'admin'], ['hI', 'Hi']) ➞ ['hI', 'Hi']
    total_match(['hi', 'admin'], ['hi', 'hi', 'admin', 'project']) ➞ ['hi', 'admin']
    total_match(['hi', 'admin'], ['hI', 'hi', 'hi']) ➞ ['hI', 'hi', 'hi']
    total_match(['4'], ['1', '2', '3', '4', '5']) ➞ ['4']
    '''

    l1 = 0
    for st in lst1:
        l1 += len(st)
    
    l2 = 0
    for st in lst2:
        l2 += len(st)
    
    if l1 <= l2:
        return lst1
    else:
        return lst2


# Generated test cases:
import pytest


class TestTotalMatch:
    
    def test_empty_lists(self):
        from test_humaneval_74_ast import total_match
        result = total_match([], [])
        assert result == []
    
    def test_first_list_empty(self):
        result = total_match([], ["hello", "world"])
        assert result == []
    
    def test_second_list_empty(self):
        result = total_match(["hello", "world"], [])
        assert result == []
    
    def test_equal_total_length(self):
        lst1 = ["ab", "cd"]
        lst2 = ["abcd"]
        result = total_match(lst1, lst2)
        assert result == lst1
    
    def test_first_list_shorter(self):
        lst1 = ["a", "b"]
        lst2 = ["hello", "world"]
        result = total_match(lst1, lst2)
        assert result == lst1
    
    def test_second_list_shorter(self):
        lst1 = ["hello", "world"]
        lst2 = ["a", "b"]
        result = total_match(lst1, lst2)
        assert result == lst2
    
    def test_single_element_lists(self):
        lst1 = ["short"]
        lst2 = ["verylongstring"]
        result = total_match(lst1, lst2)
        assert result == lst1
    
    def test_single_element_lists_reversed(self):
        lst1 = ["verylongstring"]
        lst2 = ["short"]
        result = total_match(lst1, lst2)
        assert result == lst2
    
    def test_many_short_strings_vs_few_long_strings(self):
        lst1 = ["a", "b", "c", "d", "e"]
        lst2 = ["hello"]
        result = total_match(lst1, lst2)
        assert result == lst1
    
    def test_many_short_strings_vs_few_long_strings_reversed(self):
        lst1 = ["hello"]
        lst2 = ["a", "b", "c", "d", "e"]
        result = total_match(lst1, lst2)
        assert result == lst1
    
    def test_empty_strings_in_list(self):
        lst1 = ["", "", ""]
        lst2 = ["a"]
        result = total_match(lst1, lst2)
        assert result == lst1
    
    def test_mixed_empty_and_nonempty_strings(self):
        lst1 = ["", "hello", ""]
        lst2 = ["world"]
        result = total_match(lst1, lst2)
        assert result == lst1
    
    def test_unicode_strings(self):
        lst1 = ["café", "naïve"]
        lst2 = ["hello"]
        result = total_match(lst1, lst2)
        assert result == lst2
    
    def test_numeric_strings(self):
        lst1 = ["123", "456"]
        lst2 = ["12345"]
        result = total_match(lst1, lst2)
        assert result == lst2
    
    def test_special_characters(self):
        lst1 = ["!@#", "$%^"]
        lst2 = ["&*()"]
        result = total_match(lst1, lst2)
        assert result == lst2
    
    def test_whitespace_strings(self):
        lst1 = ["   ", "  "]
        lst2 = ["     "]
        result = total_match(lst1, lst2)
        assert result == lst1
    
    def test_very_long_strings(self):
        lst1 = ["a" * 1000]
        lst2 = ["b" * 999]
        result = total_match(lst1, lst2)
        assert result == lst2
    
    def test_many_elements_equal_length(self):
        lst1 = ["x"] * 10
        lst2 = ["y"] * 10
        result = total_match(lst1, lst2)
        assert result == lst1
    
    @pytest.mark.parametrize("lst1,lst2,expected", [
        (["a"], ["b"], ["a"]),
        (["ab"], ["a"], ["a"]),
        (["abc"], ["ab"], ["ab"]),
        (["a", "b"], ["c"], ["c"]),
        (["hello"], ["h", "e", "l", "l", "o"], ["hello"]),
    ])
    def test_parametrized_cases(self, lst1, lst2, expected):
        result = total_match(lst1, lst2)
        assert result == expected
    
    def test_returns_list_not_copy(self):
        lst1 = ["test"]
        lst2 = ["longer"]
        result = total_match(lst1, lst2)
        assert result is lst1
    
    def test_returns_list_not_copy_second(self):
        lst1 = ["longer"]
        lst2 = ["test"]
        result = total_match(lst1, lst2)
        assert result is lst2
    
    def test_identical_lists(self):
        lst = ["same", "list"]
        result = total_match(lst, lst)
        assert result is lst
    
    def test_newline_characters(self):
        lst1 = ["hello\nworld"]
        lst2 = ["hi"]
        result = total_match(lst1, lst2)
        assert result == lst2
    
    def test_tab_characters(self):
        lst1 = ["a\tb"]
        lst2 = ["abc"]
        result = total_match(lst1, lst2)
        assert result == lst1