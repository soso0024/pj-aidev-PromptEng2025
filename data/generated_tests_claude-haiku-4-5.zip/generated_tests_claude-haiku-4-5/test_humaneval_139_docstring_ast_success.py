# Test cases for HumanEval/139
# Generated using Claude API


def special_factorial(n):
    """The Brazilian factorial is defined as:
    brazilian_factorial(n) = n! * (n-1)! * (n-2)! * ... * 1!
    where n > 0

    For example:
    >>> special_factorial(4)
    288

    The function will receive an integer as input and should return the special
    factorial of this integer.
    """

    fact_i = 1
    special_fact = 1
    for i in range(1, n+1):
        fact_i *= i
        special_fact *= fact_i
    return special_fact


# Generated test cases:
import pytest


def special_factorial(n):
    fact_i = 1
    special_fact = 1
    for i in range(1, n+1):
        fact_i *= i
        special_fact *= fact_i
    return special_fact


class TestSpecialFactorial:
    
    def test_example_case(self):
        assert special_factorial(4) == 288
    
    def test_n_equals_1(self):
        assert special_factorial(1) == 1
    
    def test_n_equals_2(self):
        assert special_factorial(2) == 2
    
    def test_n_equals_3(self):
        assert special_factorial(3) == 12
    
    def test_n_equals_5(self):
        assert special_factorial(5) == 34560
    
    def test_n_equals_6(self):
        assert special_factorial(6) == 24883200
    
    @pytest.mark.parametrize("n,expected", [
        (1, 1),
        (2, 2),
        (3, 12),
        (4, 288),
        (5, 34560),
    ])
    def test_parametrized_values(self, n, expected):
        assert special_factorial(n) == expected
    
    def test_large_number(self):
        result = special_factorial(10)
        assert isinstance(result, int)
        assert result > 0
    
    def test_return_type_is_integer(self):
        result = special_factorial(3)
        assert isinstance(result, int)
    
    def test_result_is_positive(self):
        for n in range(1, 8):
            assert special_factorial(n) > 0
    
    def test_increasing_sequence(self):
        prev = special_factorial(1)
        for n in range(2, 7):
            current = special_factorial(n)
            assert current > prev
            prev = current
