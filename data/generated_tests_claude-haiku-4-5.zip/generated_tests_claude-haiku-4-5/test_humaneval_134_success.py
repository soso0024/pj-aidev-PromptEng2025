# Test cases for HumanEval/134
# Generated using Claude API


def check_if_last_char_is_a_letter(txt):
    '''
    Create a function that returns True if the last character
    of a given string is an alphabetical character and is not
    a part of a word, and False otherwise.
    Note: "word" is a group of characters separated by space.

    Examples:
    check_if_last_char_is_a_letter("apple pie") ➞ False
    check_if_last_char_is_a_letter("apple pi e") ➞ True
    check_if_last_char_is_a_letter("apple pi e ") ➞ False
    check_if_last_char_is_a_letter("") ➞ False 
    '''

 
    check = txt.split(' ')[-1]
    return True if len(check) == 1 and (97 <= ord(check.lower()) <= 122) else False


# Generated test cases:
import pytest


def check_if_last_char_is_a_letter(txt):
    check = txt.split(' ')[-1]
    return True if len(check) == 1 and (97 <= ord(check.lower()) <= 122) else False


class TestCheckIfLastCharIsALetter:
    
    @pytest.mark.parametrize("input_text,expected", [
        ("hello a", True),
        ("test b", True),
        ("world z", True),
        ("foo A", True),
        ("bar Z", True),
        ("text 1", False),
        ("hello 12", False),
        ("test @", False),
        ("world !", False),
        ("foo  ", False),
        ("hello ab", False),
        ("test abc", False),
        ("a", True),
        ("z", True),
        ("A", True),
        ("Z", True),
        ("1", False),
        ("@", False),
        (" ", False),
        ("hello world a", True),
        ("hello world 1", False),
        ("hello world ab", False),
        ("test  a", True),
        ("multiple words here x", True),
        ("multiple words here 99", False),
        ("multiple words here xy", False),
    ])
    def test_check_if_last_char_is_a_letter(self, input_text, expected):
        assert check_if_last_char_is_a_letter(input_text) == expected
    
    def test_single_letter_lowercase(self):
        assert check_if_last_char_is_a_letter("a") is True
    
    def test_single_letter_uppercase(self):
        assert check_if_last_char_is_a_letter("Z") is True
    
    def test_single_digit(self):
        assert check_if_last_char_is_a_letter("5") is False
    
    def test_single_special_char(self):
        assert check_if_last_char_is_a_letter("@") is False
    
    def test_two_words_last_is_letter(self):
        assert check_if_last_char_is_a_letter("hello x") is True
    
    def test_two_words_last_is_digit(self):
        assert check_if_last_char_is_a_letter("hello 9") is False
    
    def test_two_words_last_is_multiple_chars(self):
        assert check_if_last_char_is_a_letter("hello xy") is False
    
    def test_multiple_spaces_between_words(self):
        assert check_if_last_char_is_a_letter("hello  world  a") is True
    
    def test_trailing_space(self):
        assert check_if_last_char_is_a_letter("hello a ") is False
    
    def test_leading_space(self):
        assert check_if_last_char_is_a_letter(" hello a") is True
    
    def test_only_spaces(self):
        assert check_if_last_char_is_a_letter("   ") is False
    
    def test_empty_last_word(self):
        assert check_if_last_char_is_a_letter("hello ") is False
    
    def test_mixed_case_last_letter(self):
        assert check_if_last_char_is_a_letter("test M") is True
    
    def test_last_word_with_numbers(self):
        assert check_if_last_char_is_a_letter("test 123") is False
    
    def test_last_word_with_special_chars(self):
        assert check_if_last_char_is_a_letter("test !@#") is False
    
    def test_boundary_letter_a(self):
        assert check_if_last_char_is_a_letter("word a") is True
    
    def test_boundary_letter_z(self):
        assert check_if_last_char_is_a_letter("word z") is True
    
    def test_boundary_before_a(self):
        assert check_if_last_char_is_a_letter("word `") is False
    
    def test_boundary_after_z(self):
        assert check_if_last_char_is_a_letter("word {") is False
    
    def test_unicode_letter(self):
        assert check_if_last_char_is_a_letter("test é") is False
    
    def test_very_long_text_ending_with_letter(self):
        assert check_if_last_char_is_a_letter("a b c d e f g h i j k l m n o p q r s t u v w x y z") is True
    
    def test_very_long_text_ending_with_digit(self):
        assert check_if_last_char_is_a_letter("a b c d e f g h i j k l m n o p q r s t u v w x y 9") is False
