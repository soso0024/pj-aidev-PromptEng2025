# Test cases for HumanEval/127
# Generated using Claude API


def intersection(interval1, interval2):
    """You are given two intervals,
    where each interval is a pair of integers. For example, interval = (start, end) = (1, 2).
    The given intervals are closed which means that the interval (start, end)
    includes both start and end.
    For each given interval, it is assumed that its start is less or equal its end.
    Your task is to determine whether the length of intersection of these two 
    intervals is a prime number.
    Example, the intersection of the intervals (1, 3), (2, 4) is (2, 3)
    which its length is 1, which not a prime number.
    If the length of the intersection is a prime number, return "YES",
    otherwise, return "NO".
    If the two intervals don't intersect, return "NO".


    [input/output] samples:
    intersection((1, 2), (2, 3)) ==> "NO"
    intersection((-1, 1), (0, 4)) ==> "NO"
    intersection((-3, -1), (-5, 5)) ==> "YES"
    """

    def is_prime(num):
        if num == 1 or num == 0:
            return False
        if num == 2:
            return True
        for i in range(2, num):
            if num%i == 0:
                return False
        return True

    l = max(interval1[0], interval2[0])
    r = min(interval1[1], interval2[1])
    length = r - l
    if length > 0 and is_prime(length):
        return "YES"
    return "NO"


# Generated test cases:
import pytest


def intersection(interval1, interval2):
    def is_prime(num):
        if num == 1 or num == 0:
            return False
        if num == 2:
            return True
        for i in range(2, num):
            if num%i == 0:
                return False
        return True

    l = max(interval1[0], interval2[0])
    r = min(interval1[1], interval2[1])
    length = r - l
    if length > 0 and is_prime(length):
        return "YES"
    return "NO"


@pytest.mark.parametrize("interval1,interval2,expected", [
    ((1, 2), (2, 3), "NO"),
    ((-1, 1), (0, 4), "NO"),
    ((-3, -1), (-5, 5), "YES"),
    ((1, 3), (2, 4), "NO"),
    ((1, 10), (5, 15), "YES"),
    ((0, 5), (3, 8), "YES"),
    ((1, 2), (3, 4), "NO"),
    ((1, 5), (6, 10), "NO"),
    ((1, 1), (1, 1), "NO"),
    ((0, 0), (0, 0), "NO"),
    ((1, 100), (50, 60), "NO"),
    ((10, 20), (15, 25), "YES"),
    ((-10, -5), (-8, -3), "YES"),
    ((-5, 5), (-3, 3), "NO"),
    ((0, 10), (5, 15), "YES"),
    ((1, 2), (1, 2), "NO"),
    ((1, 3), (1, 3), "YES"),
    ((2, 5), (3, 6), "YES"),
    ((0, 100), (50, 52), "YES"),
    ((1, 1000), (500, 510), "NO"),
    ((-100, 100), (0, 5), "YES"),
    ((5, 10), (1, 4), "NO"),
    ((1, 4), (5, 8), "NO"),
    ((10, 15), (12, 20), "YES"),
    ((0, 2), (1, 3), "NO"),
    ((100, 200), (150, 160), "NO"),
    ((-50, -40), (-45, -35), "YES"),
    ((1, 1), (1, 100), "NO"),
    ((5, 5), (5, 5), "NO"),
    ((1, 7), (4, 10), "YES"),
])
def test_intersection(interval1, interval2, expected):
    assert intersection(interval1, interval2) == expected


def test_intersection_no_overlap_left():
    assert intersection((1, 2), (3, 4)) == "NO"


def test_intersection_no_overlap_right():
    assert intersection((5, 6), (1, 2)) == "NO"


def test_intersection_single_point_overlap():
    assert intersection((1, 2), (2, 3)) == "NO"


def test_intersection_complete_overlap():
    assert intersection((1, 10), (1, 10)) == "NO"


def test_intersection_partial_overlap_prime():
    assert intersection((1, 5), (3, 7)) == "YES"


def test_intersection_partial_overlap_non_prime():
    assert intersection((1, 5), (4, 8)) == "NO"


def test_intersection_negative_intervals():
    assert intersection((-10, -5), (-8, -3)) == "YES"


def test_intersection_mixed_sign_intervals():
    assert intersection((-5, 5), (-2, 3)) == "YES"


def test_intersection_zero_in_interval():
    assert intersection((-2, 2), (0, 4)) == "YES"


def test_intersection_large_numbers():
    assert intersection((1000, 2000), (1500, 1510)) == "NO"


def test_intersection_length_two():
    assert intersection((0, 5), (3, 5)) == "YES"


def test_intersection_length_three():
    assert intersection((0, 10), (5, 8)) == "YES"


def test_intersection_length_five():
    assert intersection((0, 20), (10, 15)) == "YES"


def test_intersection_length_four():
    assert intersection((0, 10), (5, 9)) == "NO"


def test_intersection_identical_intervals():
    assert intersection((5, 10), (5, 10)) == "YES"


def test_intersection_one_inside_other():
    assert intersection((1, 100), (10, 13)) == "YES"


def test_intersection_touching_at_point():
    assert intersection((1, 5), (5, 10)) == "NO"


def test_intersection_negative_to_positive():
    assert intersection((-3, 2), (-1, 4)) == "YES"