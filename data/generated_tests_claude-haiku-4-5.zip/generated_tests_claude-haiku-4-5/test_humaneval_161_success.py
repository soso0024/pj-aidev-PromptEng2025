# Test cases for HumanEval/161
# Generated using Claude API


def solve(s):
    """You are given a string s.
    if s[i] is a letter, reverse its case from lower to upper or vise versa, 
    otherwise keep it as it is.
    If the string contains no letters, reverse the string.
    The function should return the resulted string.
    Examples
    solve("1234") = "4321"
    solve("ab") = "AB"
    solve("#a@C") = "#A@c"
    """

    flg = 0
    idx = 0
    new_str = list(s)
    for i in s:
        if i.isalpha():
            new_str[idx] = i.swapcase()
            flg = 1
        idx += 1
    s = ""
    for i in new_str:
        s += i
    if flg == 0:
        return s[len(s)::-1]
    return s


# Generated test cases:
import pytest


def solve(s):
    flg = 0
    idx = 0
    new_str = list(s)
    for i in s:
        if i.isalpha():
            new_str[idx] = i.swapcase()
            flg = 1
        idx += 1
    s = ""
    for i in new_str:
        s += i
    if flg == 0:
        return s[len(s)::-1]
    return s


class TestSolve:
    
    @pytest.mark.parametrize("input_str,expected", [
        ("abc", "ABC"),
        ("ABC", "abc"),
        ("aBc", "AbC"),
        ("a", "A"),
        ("Z", "z"),
    ])
    def test_basic_case_swap(self, input_str, expected):
        assert solve(input_str) == expected
    
    @pytest.mark.parametrize("input_str,expected", [
        ("123", "321"),
        ("456", "654"),
        ("1", "1"),
        ("999", "999"),
    ])
    def test_numbers_only_reversed(self, input_str, expected):
        assert solve(input_str) == expected
    
    @pytest.mark.parametrize("input_str,expected", [
        ("", ""),
    ])
    def test_empty_string(self, input_str, expected):
        assert solve(input_str) == expected
    
    @pytest.mark.parametrize("input_str,expected", [
        ("a1b2c3", "A1B2C3"),
        ("A1B2C3", "a1b2c3"),
        ("1a2b3c", "1A2B3C"),
        ("123abc", "123ABC"),
    ])
    def test_mixed_alphanumeric(self, input_str, expected):
        assert solve(input_str) == expected
    
    @pytest.mark.parametrize("input_str,expected", [
        ("!@#$", "$#@!"),
        ("!@#", "#@!"),
        (".", "."),
        ("!a@b#c", "!A@B#C"),
    ])
    def test_special_characters(self, input_str, expected):
        assert solve(input_str) == expected
    
    @pytest.mark.parametrize("input_str,expected", [
        ("   ", "   "),
        (" a b ", " A B "),
        ("a b c", "A B C"),
    ])
    def test_spaces(self, input_str, expected):
        assert solve(input_str) == expected
    
    @pytest.mark.parametrize("input_str,expected", [
        ("aA", "Aa"),
        ("AaBbCc", "aAbBcC"),
        ("abcABC", "ABCabc"),
    ])
    def test_mixed_case(self, input_str, expected):
        assert solve(input_str) == expected
    
    @pytest.mark.parametrize("input_str,expected", [
        ("Hello", "hELLO"),
        ("WORLD", "world"),
        ("PyThOn", "pYtHoN"),
    ])
    def test_words(self, input_str, expected):
        assert solve(input_str) == expected
    
    @pytest.mark.parametrize("input_str,expected", [
        ("123456789", "987654321"),
        ("abcdefghij", "ABCDEFGHIJ"),
    ])
    def test_longer_strings(self, input_str, expected):
        assert solve(input_str) == expected
    
    @pytest.mark.parametrize("input_str,expected", [
        ("aAbBcC", "AaBbCc"),
        ("ZzYyXx", "zZyYxX"),
    ])
    def test_alternating_case(self, input_str, expected):
        assert solve(input_str) == expected
    
    def test_single_lowercase_letter(self):
        assert solve("x") == "X"
    
    def test_single_uppercase_letter(self):
        assert solve("X") == "x"
    
    def test_single_digit(self):
        assert solve("5") == "5"
    
    def test_single_special_char(self):
        assert solve("@") == "@"