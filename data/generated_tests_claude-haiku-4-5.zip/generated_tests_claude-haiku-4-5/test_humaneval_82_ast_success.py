# Test cases for HumanEval/82
# Generated using Claude API


def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise
    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """

    l = len(string)
    if l == 0 or l == 1:
        return False
    for i in range(2, l):
        if l % i == 0:
            return False
    return True


# Generated test cases:
import pytest


def prime_length(string):
    l = len(string)
    if l == 0 or l == 1:
        return False
    for i in range(2, l):
        if l % i == 0:
            return False
    return True


class TestPrimeLength:
    
    @pytest.mark.parametrize("input_string,expected", [
        ("", False),
        ("a", False),
        ("ab", True),
        ("abc", True),
        ("abcd", False),
        ("abcde", True),
        ("abcdef", False),
        ("abcdefg", True),
        ("abcdefgh", False),
        ("abcdefghi", False),
        ("abcdefghij", False),
        ("abcdefghijk", True),
        ("abcdefghijkl", False),
        ("abcdefghijklm", True),
        ("abcdefghijklmn", False),
        ("abcdefghijklmno", False),
        ("abcdefghijklmnop", False),
        ("abcdefghijklmnopq", True),
        ("abcdefghijklmnopqr", False),
        ("abcdefghijklmnopqrs", True),
    ])
    def test_prime_length_various_strings(self, input_string, expected):
        assert prime_length(input_string) == expected
    
    def test_empty_string(self):
        assert prime_length("") is False
    
    def test_single_character(self):
        assert prime_length("a") is False
    
    def test_two_characters_prime(self):
        assert prime_length("ab") is True
    
    def test_three_characters_prime(self):
        assert prime_length("abc") is True
    
    def test_four_characters_not_prime(self):
        assert prime_length("abcd") is False
    
    def test_five_characters_prime(self):
        assert prime_length("abcde") is True
    
    def test_six_characters_not_prime(self):
        assert prime_length("abcdef") is False
    
    def test_seven_characters_prime(self):
        assert prime_length("abcdefg") is True
    
    def test_eight_characters_not_prime(self):
        assert prime_length("abcdefgh") is False
    
    def test_nine_characters_not_prime(self):
        assert prime_length("abcdefghi") is False
    
    def test_ten_characters_not_prime(self):
        assert prime_length("abcdefghij") is False
    
    def test_eleven_characters_prime(self):
        assert prime_length("abcdefghijk") is True
    
    def test_thirteen_characters_prime(self):
        assert prime_length("abcdefghijklm") is True
    
    def test_seventeen_characters_prime(self):
        assert prime_length("abcdefghijklmnopq") is True
    
    def test_nineteen_characters_prime(self):
        assert prime_length("abcdefghijklmnopqrs") is True
    
    def test_twenty_characters_not_prime(self):
        assert prime_length("abcdefghijklmnopqrst") is False
    
    def test_special_characters(self):
        assert prime_length("!@") is True
    
    def test_numbers_as_string(self):
        assert prime_length("12") is True
    
    def test_spaces(self):
        assert prime_length("  ") is True
    
    def test_mixed_content_prime_length(self):
        assert prime_length("a1!b2@") is False
    
    def test_unicode_characters(self):
        assert prime_length("αβ") is True
    
    def test_unicode_characters_non_prime(self):
        assert prime_length("αβγδ") is False
    
    def test_long_prime_length(self):
        assert prime_length("a" * 23) is True
    
    def test_long_non_prime_length(self):
        assert prime_length("a" * 24) is False
    
    def test_return_type_is_boolean(self):
        result = prime_length("ab")
        assert isinstance(result, bool)
    
    def test_return_type_false_is_boolean(self):
        result = prime_length("a")
        assert isinstance(result, bool)
