# Test cases for HumanEval/117
# Generated using Claude API


def select_words(s, n):
    """Given a string s and a natural number n, you have been tasked to implement 
    a function that returns a list of all words from string s that contain exactly 
    n consonants, in order these words appear in the string s.
    If the string s is empty then the function should return an empty list.
    Note: you may assume the input string contains only letters and spaces.
    Examples:
    select_words("Mary had a little lamb", 4) ==> ["little"]
    select_words("Mary had a little lamb", 3) ==> ["Mary", "lamb"]
    select_words("simple white space", 2) ==> []
    select_words("Hello world", 4) ==> ["world"]
    select_words("Uncle sam", 3) ==> ["Uncle"]
    """

    result = []
    for word in s.split():
        n_consonants = 0
        for i in range(0, len(word)):
            if word[i].lower() not in ["a","e","i","o","u"]:
                n_consonants += 1 
        if n_consonants == n:
            result.append(word)
    return result



# Generated test cases:
import pytest


class TestSelectWords:
    
    def test_empty_string(self):
        from test_humaneval_117 import select_words
        assert select_words("", 0) == []
    
    def test_empty_string_with_n(self):
        assert select_words("", 5) == []
    
    def test_single_word_matching(self):
        assert select_words("hello", 3) == ["hello"]
    
    def test_single_word_not_matching(self):
        assert select_words("hello", 2) == []
    
    def test_multiple_words_some_match(self):
        assert select_words("hello world", 3) == ["hello"]
    
    def test_multiple_words_all_match(self):
        assert select_words("hello world", 3) == ["hello"]
    
    def test_multiple_words_none_match(self):
        assert select_words("hello world", 10) == []
    
    def test_zero_consonants(self):
        assert select_words("aaa eee", 0) == ["aaa", "eee"]
    
    def test_uppercase_letters(self):
        assert select_words("HELLO WORLD", 3) == ["HELLO"]
    
    def test_mixed_case(self):
        assert select_words("HeLLo WoRLd", 3) == ["HeLLo"]
    
    def test_single_consonant(self):
        assert select_words("b a c", 1) == ["b", "c"]
    
    def test_all_consonants(self):
        assert select_words("bcdfg", 5) == ["bcdfg"]
    
    def test_all_vowels(self):
        assert select_words("aeiou", 0) == ["aeiou"]
    
    def test_multiple_spaces(self):
        assert select_words("hello  world", 3) == ["hello"]
    
    def test_words_with_numbers(self):
        result = select_words("hello123 world456", 3)
        assert result == []
    
    def test_words_with_special_characters(self):
        result = select_words("hello! world?", 3)
        assert result == []
    
    def test_single_letter_words(self):
        assert select_words("a b c d e", 0) == ["a", "e"]
    
    def test_single_letter_words_consonants(self):
        assert select_words("a b c d e", 1) == ["b", "c", "d"]
    
    def test_long_string(self):
        result = select_words("programming is fun", 3)
        assert result == []
    
    def test_case_insensitive_counting(self):
        result = select_words("ABC def GHI", 3)
        assert result == []
    
    def test_n_equals_word_length(self):
        assert select_words("xyz", 3) == ["xyz"]
    
    def test_n_greater_than_word_length(self):
        assert select_words("xyz", 4) == []
    
    def test_repeated_words(self):
        result = select_words("hello hello world", 3)
        assert result == ["hello", "hello"]
    
    def test_words_with_apostrophes(self):
        result = select_words("don't can't", 3)
        assert result == []
    
    def test_words_with_hyphens(self):
        result = select_words("well-known test", 3)
        assert result == ["test"]
    
    def test_very_long_word(self):
        long_word = "b" * 10
        assert select_words(long_word, 10) == [long_word]
    
    def test_mixed_content(self):
        result = select_words("The quick brown fox jumps", 3)
        assert "quick" in result
    
    @pytest.mark.parametrize("input_str,n,expected", [
        ("hello world", 3, ["hello"]),
        ("test case", 4, []),
        ("aeiou", 0, ["aeiou"]),
        ("bcdfg", 5, ["bcdfg"]),
        ("a e i o u", 0, ["a", "e", "i", "o", "u"]),
        ("b c d f g", 1, ["b", "c", "d", "f", "g"]),
        ("", 0, []),
        ("xyz", 3, ["xyz"]),
        ("HELLO", 3, ["HELLO"]),
        ("HeLLo", 3, ["HeLLo"]),
    ])
    def test_parametrized(self, input_str, n, expected):
        assert select_words(input_str, n) == expected