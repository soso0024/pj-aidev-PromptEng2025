# Test cases for HumanEval/38
# Generated using Claude API



def encode_cyclic(s: str):
    """
    returns encoded string by cycling groups of three characters.
    """
    # split string to groups. Each of length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # cycle elements in each group. Unless group has fewer elements than 3.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def decode_cyclic(s: str):
    """
    takes as input string encoded with encode_cyclic function. Returns decoded string.
    """

    return encode_cyclic(encode_cyclic(s))


# Generated test cases:
import pytest


def encode_cyclic(s: str):
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def decode_cyclic(s: str):
    return encode_cyclic(encode_cyclic(s))


class TestEncodeCyclic:
    def test_empty_string(self):
        assert encode_cyclic("") == ""

    def test_single_character(self):
        assert encode_cyclic("a") == "a"

    def test_two_characters(self):
        assert encode_cyclic("ab") == "ab"

    def test_three_characters(self):
        assert encode_cyclic("abc") == "bca"

    def test_four_characters(self):
        assert encode_cyclic("abcd") == "bcad"

    def test_five_characters(self):
        assert encode_cyclic("abcde") == "bcade"

    def test_six_characters(self):
        assert encode_cyclic("abcdef") == "bcaefd"

    def test_nine_characters(self):
        assert encode_cyclic("abcdefghi") == "bcaefdhig"

    def test_ten_characters(self):
        assert encode_cyclic("abcdefghij") == "bcaefdhigj"

    def test_long_string(self):
        result = encode_cyclic("abcdefghijklmnopqrst")
        assert result == "bcaefdhigkljnomqrpst"

    def test_special_characters(self):
        assert encode_cyclic("!@#") == "@#!"

    def test_numbers(self):
        assert encode_cyclic("123456") == "231564"

    def test_mixed_content(self):
        assert encode_cyclic("a1b2c3") == "1bac32"

    def test_spaces(self):
        assert encode_cyclic("a b c") == " ba c"

    def test_unicode_characters(self):
        assert encode_cyclic("αβγ") == "βγα"


class TestDecodeCyclic:
    def test_empty_string(self):
        assert decode_cyclic("") == ""

    def test_single_character(self):
        assert decode_cyclic("a") == "a"

    def test_two_characters(self):
        assert decode_cyclic("ab") == "ab"

    def test_three_characters(self):
        assert decode_cyclic("bca") == "abc"

    def test_four_characters(self):
        assert decode_cyclic("bcad") == "abcd"

    def test_five_characters(self):
        assert decode_cyclic("bcade") == "abcde"

    def test_six_characters(self):
        assert decode_cyclic("bcaefd") == "abcdef"

    def test_nine_characters(self):
        assert decode_cyclic("bcaefdhig") == "abcdefghi"

    def test_ten_characters(self):
        assert decode_cyclic("bcaefdhigj") == "abcdefghij"

    def test_long_string(self):
        original = "abcdefghijklmnopqrst"
        encoded = encode_cyclic(original)
        assert decode_cyclic(encoded) == original

    def test_special_characters(self):
        original = "!@#$%^"
        encoded = encode_cyclic(original)
        assert decode_cyclic(encoded) == original

    def test_numbers(self):
        original = "0123456789"
        encoded = encode_cyclic(original)
        assert decode_cyclic(encoded) == original

    def test_mixed_content(self):
        original = "Hello123!@#"
        encoded = encode_cyclic(original)
        assert decode_cyclic(encoded) == original

    def test_spaces_and_newlines(self):
        original = "a b\nc d"
        encoded = encode_cyclic(original)
        assert decode_cyclic(encoded) == original

    def test_unicode_characters(self):
        original = "αβγδεζ"
        encoded = encode_cyclic(original)
        assert decode_cyclic(encoded) == original


class TestRoundTrip:
    @pytest.mark.parametrize("text", [
        "",
        "a",
        "ab",
        "abc",
        "abcd",
        "abcdefghijklmnopqrstuvwxyz",
        "The quick brown fox jumps over the lazy dog",
        "123456789",
        "!@#$%^&*()",
        "αβγδεζηθικλμνξοπρστυφχψω",
        "   ",
        "a\nb\nc",
        "MixedCASE123!@#",
    ])
    def test_encode_decode_roundtrip(self, text):
        encoded = encode_cyclic(text)
        decoded = decode_cyclic(encoded)
        assert decoded == text

    def test_double_encode_decode(self):
        original = "abcdefghijklmnop"
        once_encoded = encode_cyclic(original)
        twice_encoded = encode_cyclic(once_encoded)
        decoded = decode_cyclic(twice_encoded)
        assert decoded == once_encoded

    def test_triple_encode_decode(self):
        original = "teststring"
        encoded1 = encode_cyclic(original)
        encoded2 = encode_cyclic(encoded1)
        encoded3 = encode_cyclic(encoded2)
        decoded = decode_cyclic(encoded3)
        assert decoded == encoded2