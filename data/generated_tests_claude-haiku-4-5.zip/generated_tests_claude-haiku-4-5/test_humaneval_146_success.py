# Test cases for HumanEval/146
# Generated using Claude API


def specialFilter(nums):
    """Write a function that takes an array of numbers as input and returns 
    the number of elements in the array that are greater than 10 and both 
    first and last digits of a number are odd (1, 3, 5, 7, 9).
    For example:
    specialFilter([15, -73, 14, -15]) => 1 
    specialFilter([33, -2, -3, 45, 21, 109]) => 2
    """

    
    count = 0
    for num in nums:
        if num > 10:
            odd_digits = (1, 3, 5, 7, 9)
            number_as_string = str(num)
            if int(number_as_string[0]) in odd_digits and int(number_as_string[-1]) in odd_digits:
                count += 1
        
    return count 


# Generated test cases:
import pytest


class TestSpecialFilter:
    
    def test_empty_list(self):
        from test_humaneval_146 import specialFilter
        assert specialFilter([]) == 0
    
    def test_single_element_valid(self):
        assert specialFilter([11]) == 1
    
    def test_single_element_invalid_too_small(self):
        assert specialFilter([10]) == 0
    
    def test_single_element_invalid_first_digit_even(self):
        assert specialFilter([21]) == 0
    
    def test_single_element_invalid_last_digit_even(self):
        assert specialFilter([12]) == 0
    
    def test_single_element_valid_both_odd(self):
        assert specialFilter([13]) == 1
    
    def test_multiple_elements_all_valid(self):
        assert specialFilter([11, 13, 15, 17, 19]) == 5
    
    def test_multiple_elements_all_invalid(self):
        assert specialFilter([10, 20, 30, 40, 50]) == 0
    
    def test_multiple_elements_mixed(self):
        assert specialFilter([11, 12, 13, 14, 15]) == 3
    
    def test_numbers_below_threshold(self):
        assert specialFilter([1, 2, 3, 4, 5, 9, 10]) == 0
    
    def test_three_digit_numbers_valid(self):
        assert specialFilter([111, 131, 151, 171, 191]) == 5
    
    def test_three_digit_numbers_invalid_first_digit_even(self):
        assert specialFilter([211, 231, 251]) == 0
    
    def test_three_digit_numbers_invalid_last_digit_even(self):
        assert specialFilter([112, 132, 152]) == 0
    
    def test_three_digit_numbers_mixed(self):
        assert specialFilter([111, 112, 113, 114, 115]) == 3
    
    def test_large_numbers(self):
        assert specialFilter([11111, 22222, 33333, 99999]) == 3
    
    def test_large_numbers_valid(self):
        assert specialFilter([11111, 13131, 15151, 17171, 19191]) == 5
    
    def test_negative_numbers(self):
        assert specialFilter([-11, -13, -15]) == 0
    
    def test_mixed_positive_negative(self):
        assert specialFilter([-11, 11, -13, 13]) == 2
    
    def test_zero(self):
        assert specialFilter([0]) == 0
    
    def test_boundary_value_11(self):
        assert specialFilter([11]) == 1
    
    def test_boundary_value_10(self):
        assert specialFilter([10]) == 0
    
    def test_even_first_digit_odd_last_digit(self):
        assert specialFilter([21, 23, 25, 27, 29]) == 0
    
    def test_odd_first_digit_even_last_digit(self):
        assert specialFilter([11, 12, 13, 14, 15]) == 3
    
    def test_both_digits_odd(self):
        assert specialFilter([11, 13, 15, 17, 19, 31, 33, 35, 37, 39]) == 10
    
    def test_large_list(self):
        nums = list(range(11, 100))
        result = specialFilter(nums)
        assert result > 0
    
    def test_all_even_first_digits(self):
        assert specialFilter([21, 41, 61, 81]) == 0
    
    def test_all_even_last_digits(self):
        assert specialFilter([12, 14, 16, 18]) == 0
    
    def test_specific_valid_cases(self):
        assert specialFilter([11, 33, 55, 77, 99]) == 5
    
    def test_specific_invalid_cases(self):
        assert specialFilter([22, 44, 66, 88]) == 0
    
    def test_mixed_two_and_three_digit(self):
        assert specialFilter([11, 111, 13, 131, 15, 151]) == 6
    
    def test_numbers_with_zero_in_middle(self):
        assert specialFilter([101, 103, 105, 107, 109]) == 5
    
    def test_numbers_ending_in_zero(self):
        assert specialFilter([110, 130, 150, 170, 190]) == 0
    
    def test_numbers_starting_with_zero_conceptually(self):
        assert specialFilter([11, 13, 15]) == 3


@pytest.mark.parametrize("nums,expected", [
    ([], 0),
    ([11], 1),
    ([10], 0),
    ([21], 0),
    ([12], 0),
    ([13], 1),
    ([11, 13, 15, 17, 19], 5),
    ([10, 20, 30, 40, 50], 0),
    ([11, 12, 13, 14, 15], 3),
    ([111, 131, 151, 171, 191], 5),
    ([211, 231, 251], 0),
    ([112, 132, 152], 0),
    ([11111, 22222, 33333, 99999], 3),
    ([-11, -13, -15], 0),
    ([0], 0),
    ([21, 23, 25, 27, 29], 0),
    ([11, 33, 55, 77, 99], 5),
    ([101, 103, 105, 107, 109], 5),
    ([110, 130, 150, 170, 190], 0),
])
def test_special_filter_parametrized(nums, expected):
    assert specialFilter(nums) == expected