# Test cases for HumanEval/76
# Generated using Claude API


def is_simple_power(x, n):
    """Your task is to write a function that returns true if a number x is a simple
    power of n and false in other cases.
    x is a simple power of n if n**int=x
    For example:
    is_simple_power(1, 4) => true
    is_simple_power(2, 2) => true
    is_simple_power(8, 2) => true
    is_simple_power(3, 2) => false
    is_simple_power(3, 1) => false
    is_simple_power(5, 3) => false
    """

    if (n == 1): 
        return (x == 1) 
    power = 1
    while (power < x): 
        power = power * n 
    return (power == x) 


# Generated test cases:
import pytest


def is_simple_power(x, n):
    if (n == 1): 
        return (x == 1) 
    power = 1
    while (power < x): 
        power = power * n 
    return (power == x) 


class TestIsSimplePower:
    
    @pytest.mark.parametrize("x,n,expected", [
        (1, 1, True),
        (1, 2, True),
        (1, 3, True),
        (1, 100, True),
        (2, 2, True),
        (4, 2, True),
        (8, 2, True),
        (16, 2, True),
        (32, 2, True),
        (27, 3, True),
        (81, 3, True),
        (125, 5, True),
        (1024, 2, True),
        (1000, 10, True),
        (7, 7, True),
        (3, 3, True),
    ])
    def test_valid_powers(self, x, n, expected):
        assert is_simple_power(x, n) == expected
    
    @pytest.mark.parametrize("x,n,expected", [
        (2, 1, False),
        (3, 1, False),
        (100, 1, False),
        (3, 2, False),
        (5, 2, False),
        (10, 2, False),
        (15, 3, False),
        (26, 3, False),
        (100, 3, False),
        (50, 5, False),
        (999, 10, False),
        (2, 3, False),
        (5, 7, False),
    ])
    def test_invalid_powers(self, x, n, expected):
        assert is_simple_power(x, n) == expected
    
    @pytest.mark.parametrize("x,n,expected", [
        (0, 2, False),
        (0, 3, False),
        (0, 1, False),
    ])
    def test_zero_cases(self, x, n, expected):
        assert is_simple_power(x, n) == expected
    
    @pytest.mark.parametrize("x,n,expected", [
        (2, 2, True),
        (4, 2, True),
        (8, 2, True),
        (16, 2, True),
        (32, 2, True),
        (64, 2, True),
        (128, 2, True),
        (256, 2, True),
        (512, 2, True),
        (1024, 2, True),
    ])
    def test_powers_of_two(self, x, n, expected):
        assert is_simple_power(x, n) == expected
    
    @pytest.mark.parametrize("x,n,expected", [
        (3, 3, True),
        (9, 3, True),
        (27, 3, True),
        (81, 3, True),
        (243, 3, True),
    ])
    def test_powers_of_three(self, x, n, expected):
        assert is_simple_power(x, n) == expected
    
    @pytest.mark.parametrize("x,n,expected", [
        (5, 5, True),
        (25, 5, True),
        (125, 5, True),
        (625, 5, True),
    ])
    def test_powers_of_five(self, x, n, expected):
        assert is_simple_power(x, n) == expected
    
    def test_single_element_power(self):
        assert is_simple_power(1, 1) == True
    
    def test_base_equals_result(self):
        assert is_simple_power(7, 7) == True
        assert is_simple_power(11, 11) == True
    
    def test_large_numbers(self):
        assert is_simple_power(1048576, 2) == True
        assert is_simple_power(59049, 3) == True
    
    def test_not_power_near_boundary(self):
        assert is_simple_power(3, 2) == False
        assert is_simple_power(5, 2) == False
        assert is_simple_power(7, 2) == False
        assert is_simple_power(15, 3) == False
        assert is_simple_power(28, 3) == False