# Test cases for HumanEval/34
# Generated using Claude API



def unique(l: list):
    """Return sorted unique elements in a list
    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """

    return sorted(list(set(l)))


# Generated test cases:
import pytest


def unique(l: list):
    return sorted(list(set(l)))


class TestUnique:
    def test_basic_example(self):
        assert unique([5, 3, 5, 2, 3, 3, 9, 0, 123]) == [0, 2, 3, 5, 9, 123]
    
    def test_empty_list(self):
        assert unique([]) == []
    
    def test_single_element(self):
        assert unique([42]) == [42]
    
    def test_all_unique_elements(self):
        assert unique([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    
    def test_all_duplicate_elements(self):
        assert unique([7, 7, 7, 7]) == [7]
    
    def test_negative_numbers(self):
        assert unique([-5, -1, -5, 0, 1, 5]) == [-5, -1, 0, 1, 5]
    
    def test_mixed_positive_negative(self):
        assert unique([10, -10, 5, -5, 0]) == [-10, -5, 0, 5, 10]
    
    def test_large_numbers(self):
        assert unique([1000000, 999999, 1000000]) == [999999, 1000000]
    
    def test_two_elements_same(self):
        assert unique([5, 5]) == [5]
    
    def test_two_elements_different(self):
        assert unique([5, 3]) == [3, 5]
    
    def test_unsorted_input(self):
        assert unique([9, 1, 5, 3, 7]) == [1, 3, 5, 7, 9]
    
    def test_reverse_sorted_input(self):
        assert unique([5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5]
    
    def test_already_sorted_unique(self):
        assert unique([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    
    def test_floats(self):
        assert unique([1.5, 2.5, 1.5, 0.5]) == [0.5, 1.5, 2.5]
    
    def test_mixed_int_float(self):
        result = unique([1, 1.0, 2, 2.0])
        assert len(result) == 2
        assert 1 in result or 1.0 in result
        assert 2 in result or 2.0 in result
    
    def test_zero_included(self):
        assert unique([0, 1, 0, -1]) == [-1, 0, 1]
    
    def test_many_duplicates(self):
        assert unique([1, 1, 1, 2, 2, 2, 3, 3, 3]) == [1, 2, 3]
    
    def test_alternating_pattern(self):
        assert unique([1, 2, 1, 2, 1, 2]) == [1, 2]
    
    def test_large_list(self):
        large_list = list(range(100)) + list(range(100))
        assert unique(large_list) == list(range(100))
    
    def test_return_type_is_list(self):
        result = unique([3, 1, 2])
        assert isinstance(result, list)
    
    def test_result_is_sorted(self):
        result = unique([9, 3, 7, 1, 5])
        assert result == sorted(result)


@pytest.mark.parametrize("input_list,expected", [
    ([5, 3, 5, 2, 3, 3, 9, 0, 123], [0, 2, 3, 5, 9, 123]),
    ([], []),
    ([1], [1]),
    ([1, 1, 1], [1]),
    ([3, 1, 2], [1, 2, 3]),
    ([-1, 0, 1], [-1, 0, 1]),
    ([10, 5, 10, 5], [5, 10]),
])
def test_unique_parametrized(input_list, expected):
    assert unique(input_list) == expected
