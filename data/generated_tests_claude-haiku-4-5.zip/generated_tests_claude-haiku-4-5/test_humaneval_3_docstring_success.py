# Test cases for HumanEval/3
# Generated using Claude API

from typing import List


def below_zero(operations: List[int]) -> bool:
    """ You're given a list of deposit and withdrawal operations on a bank account that starts with
    zero balance. Your task is to detect if at any point the balance of account fallls below zero, and
    at that point function should return True. Otherwise it should return False.
    >>> below_zero([1, 2, 3])
    False
    >>> below_zero([1, 2, -4, 5])
    True
    """

    balance = 0

    for op in operations:
        balance += op
        if balance < 0:
            return True

    return False


# Generated test cases:
import pytest
from typing import List


def below_zero(operations: List[int]) -> bool:
    balance = 0

    for op in operations:
        balance += op
        if balance < 0:
            return True

    return False


class TestBelowZero:
    def test_empty_list(self):
        assert below_zero([]) == False

    def test_single_positive_operation(self):
        assert below_zero([1]) == False

    def test_single_negative_operation(self):
        assert below_zero([-1]) == True

    def test_single_large_negative_operation(self):
        assert below_zero([-100]) == True

    def test_all_positive_operations(self):
        assert below_zero([1, 2, 3]) == False

    def test_positive_then_negative_below_zero(self):
        assert below_zero([1, 2, -4, 5]) == True

    def test_negative_at_end(self):
        assert below_zero([5, 5, -15]) == True

    def test_negative_in_middle(self):
        assert below_zero([10, -5, -10]) == True

    def test_balance_reaches_zero_exactly(self):
        assert below_zero([5, -5]) == False

    def test_multiple_negatives_cumulative(self):
        assert below_zero([1, -1, -1]) == True

    def test_large_positive_then_large_negative(self):
        assert below_zero([1000, -1001]) == True

    def test_zero_operations(self):
        assert below_zero([0, 0, 0]) == False

    def test_mixed_with_zeros(self):
        assert below_zero([5, 0, -3, 0, -2]) == False

    def test_mixed_with_zeros_goes_negative(self):
        assert below_zero([5, 0, -3, 0, -3]) == True

    def test_negative_first_operation(self):
        assert below_zero([-1, 5, 10]) == True

    def test_negative_immediately_below_zero(self):
        assert below_zero([-0.5]) == True

    def test_alternating_positive_negative(self):
        assert below_zero([1, -1, 1, -1, 1]) == False

    def test_alternating_positive_negative_goes_below(self):
        assert below_zero([1, -2, 1, -2, 1]) == True

    def test_large_list_no_negative(self):
        assert below_zero([1] * 100) == False

    def test_large_list_negative_at_end(self):
        operations = [1] * 50 + [-100]
        assert below_zero(operations) == True

    def test_large_list_negative_at_start(self):
        operations = [-100] + [1] * 50
        assert below_zero(operations) == True

    def test_negative_zero_boundary(self):
        assert below_zero([0, -1]) == True

    def test_very_large_numbers(self):
        assert below_zero([1000000, -1000001]) == True

    def test_very_large_positive_stays_positive(self):
        assert below_zero([1000000, -999999]) == False


@pytest.mark.parametrize("operations,expected", [
    ([], False),
    ([1, 2, 3], False),
    ([1, 2, -4, 5], True),
    ([-1], True),
    ([0], False),
    ([5, -5], False),
    ([5, -6], True),
    ([10, -5, -10], True),
    ([1, 1, 1, -5], True),
    ([100, -50, -40], False),
    ([100, -50, -51], True),
])
def test_below_zero_parametrized(operations, expected):
    assert below_zero(operations) == expected