# Test cases for HumanEval/141
# Generated using Claude API


def file_name_check(file_name):
    """Create a function which takes a string representing a file's name, and returns
    'Yes' if the the file's name is valid, and returns 'No' otherwise.
    A file's name is considered to be valid if and only if all the following conditions 
    are met:
    - There should not be more than three digits ('0'-'9') in the file's name.
    - The file's name contains exactly one dot '.'
    - The substring before the dot should not be empty, and it starts with a letter from 
    the latin alphapet ('a'-'z' and 'A'-'Z').
    - The substring after the dot should be one of these: ['txt', 'exe', 'dll']
    Examples:
    file_name_check("example.txt") # => 'Yes'
    file_name_check("1example.dll") # => 'No' (the name should start with a latin alphapet letter)
    """

    suf = ['txt', 'exe', 'dll']
    lst = file_name.split(sep='.')
    if len(lst) != 2:
        return 'No'
    if not lst[1] in suf:
        return 'No'
    if len(lst[0]) == 0:
        return 'No'
    if not lst[0][0].isalpha():
        return 'No'
    t = len([x for x in lst[0] if x.isdigit()])
    if t > 3:
        return 'No'
    return 'Yes'


# Generated test cases:
import pytest


class TestFileNameCheck:
    
    @pytest.mark.parametrize("file_name,expected", [
        ("example.txt", "Yes"),
        ("test.exe", "Yes"),
        ("file.dll", "Yes"),
        ("a.txt", "Yes"),
        ("abc123.txt", "Yes"),
        ("file123.exe", "Yes"),
        ("test1234.txt", "No"),
        ("file12345.dll", "No"),
        ("example.pdf", "No"),
        ("test.doc", "No"),
        ("file.zip", "No"),
        (".txt", "No"),
        (".exe", "No"),
        ("example.", "No"),
        ("example", "No"),
        ("example.txt.bak", "No"),
        ("file.txt.exe", "No"),
        ("1example.txt", "No"),
        ("_example.txt", "No"),
        ("@file.exe", "No"),
        ("example123.txt", "Yes"),
        ("test12.exe", "Yes"),
        ("file1.dll", "Yes"),
        ("a1b2c3.txt", "Yes"),
        ("abc1234.txt", "No"),
        ("test12345.exe", "No"),
        ("file123456.dll", "No"),
        ("A.txt", "Yes"),
        ("B.exe", "Yes"),
        ("C.dll", "Yes"),
        ("Example.txt", "Yes"),
        ("Test.exe", "Yes"),
        ("File.dll", "Yes"),
        ("a123.txt", "Yes"),
        ("b12.exe", "Yes"),
        ("c1.dll", "Yes"),
        ("abc.txt", "Yes"),
        ("def.exe", "Yes"),
        ("ghi.dll", "Yes"),
        ("a1b2c3d4.txt", "No"),
        ("test1234567.exe", "No"),
        ("file999999.dll", "No"),
        ("example.TXT", "No"),
        ("test.EXE", "No"),
        ("file.DLL", "No"),
        ("example.Txt", "No"),
        ("test.Exe", "No"),
        ("file.Dll", "No"),
    ])
    def test_file_name_check(self, file_name, expected):
        from test_humaneval_141_ast import file_name_check
        assert file_name_check(file_name) == expected
    
    def test_valid_txt_file(self):
        assert file_name_check("document.txt") == "Yes"
    
    def test_valid_exe_file(self):
        assert file_name_check("program.exe") == "Yes"
    
    def test_valid_dll_file(self):
        assert file_name_check("library.dll") == "Yes"
    
    def test_invalid_extension(self):
        assert file_name_check("file.pdf") == "No"
    
    def test_no_extension(self):
        assert file_name_check("filename") == "No"
    
    def test_multiple_dots(self):
        assert file_name_check("file.backup.txt") == "No"
    
    def test_empty_filename(self):
        assert file_name_check(".txt") == "No"
    
    def test_starts_with_digit(self):
        assert file_name_check("1file.txt") == "No"
    
    def test_starts_with_special_char(self):
        assert file_name_check("@file.exe") == "No"
    
    def test_three_digits_valid(self):
        assert file_name_check("file123.txt") == "Yes"
    
    def test_four_digits_invalid(self):
        assert file_name_check("file1234.txt") == "No"
    
    def test_single_letter_filename(self):
        assert file_name_check("a.txt") == "Yes"
    
    def test_uppercase_start(self):
        assert file_name_check("File.exe") == "Yes"
    
    def test_mixed_case_start(self):
        assert file_name_check("MyFile.dll") == "Yes"
    
    def test_filename_with_underscore(self):
        assert file_name_check("my_file.txt") == "Yes"
    
    def test_filename_with_hyphen(self):
        assert file_name_check("my-file.exe") == "Yes"
    
    def test_filename_with_space(self):
        assert file_name_check("my file.dll") == "Yes"
    
    def test_only_digits_in_filename(self):
        assert file_name_check("123.txt") == "No"
    
    def test_digits_at_end(self):
        assert file_name_check("file123.txt") == "Yes"
    
    def test_digits_at_start_after_letter(self):
        assert file_name_check("a123.exe") == "Yes"
    
    def test_mixed_digits_and_letters(self):
        assert file_name_check("a1b2c3.dll") == "Yes"
    
    def test_exactly_two_parts(self):
        assert file_name_check("test.txt") == "Yes"
    
    def test_more_than_two_parts(self):
        assert file_name_check("test.backup.txt") == "No"
    
    def test_less_than_two_parts(self):
        assert file_name_check("test") == "No"
    
    def test_empty_extension(self):
        assert file_name_check("file.") == "No"
    
    def test_case_sensitive_extension(self):
        assert file_name_check("file.TXT") == "No"
    
    def test_long_valid_filename(self):
        assert file_name_check("verylongfilenamewithnumbers123.txt") == "Yes"
    
    def test_single_digit_filename(self):
        assert file_name_check("a1.exe") == "Yes"
    
    def test_two_digits_filename(self):
        assert file_name_check("ab12.dll") == "Yes"