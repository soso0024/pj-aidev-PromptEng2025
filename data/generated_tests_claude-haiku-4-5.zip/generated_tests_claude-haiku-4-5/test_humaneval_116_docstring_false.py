# Test cases for HumanEval/116
# Generated using Claude API


def sort_array(arr):
    """
    In this Kata, you have to sort an array of non-negative integers according to
    number of ones in their binary representation in ascending order.
    For similar number of ones, sort based on decimal value.

    It must be implemented like this:
    >>> sort_array([1, 5, 2, 3, 4]) == [1, 2, 3, 4, 5]
    >>> sort_array([-2, -3, -4, -5, -6]) == [-6, -5, -4, -3, -2]
    >>> sort_array([1, 0, 2, 3, 4]) [0, 1, 2, 3, 4]
    """

    return sorted(sorted(arr), key=lambda x: bin(x)[2:].count('1'))


# Generated test cases:
import pytest


class TestSortArray:
    
    def sort_array(self, arr):
        return sorted(arr, key=lambda x: (bin(x)[2:].count('1'), x))
    
    def test_basic_example(self):
        assert self.sort_array([1, 5, 2, 3, 4]) == [1, 2, 3, 4, 5]
    
    def test_negative_numbers(self):
        assert self.sort_array([-2, -3, -4, -5, -6]) == [-6, -5, -4, -3, -2]
    
    def test_with_zero(self):
        assert self.sort_array([1, 0, 2, 3, 4]) == [0, 1, 2, 3, 4]
    
    def test_empty_array(self):
        assert self.sort_array([]) == []
    
    def test_single_element(self):
        assert self.sort_array([5]) == [5]
    
    def test_all_zeros(self):
        assert self.sort_array([0, 0, 0]) == [0, 0, 0]
    
    def test_all_same_number(self):
        assert self.sort_array([7, 7, 7]) == [7, 7, 7]
    
    def test_same_ones_count_different_values(self):
        assert self.sort_array([5, 3]) == [3, 5]
    
    def test_different_ones_count(self):
        assert self.sort_array([7, 1, 3]) == [1, 3, 7]
    
    def test_large_numbers(self):
        assert self.sort_array([255, 128, 256]) == [128, 256, 255]
    
    def test_mixed_positive_and_negative(self):
        result = self.sort_array([1, -1, 2, -2])
        assert result == [-2, -1, 1, 2]
    
    def test_powers_of_two(self):
        assert self.sort_array([16, 1, 4, 2, 8]) == [1, 2, 4, 8, 16]
    
    def test_all_ones_binary(self):
        assert self.sort_array([15, 1, 7, 3]) == [1, 3, 7, 15]
    
    def test_complex_mixed_case(self):
        result = self.sort_array([5, 2, 3, 1, 4, 0])
        assert result == [0, 1, 2, 4, 3, 5]
    
    def test_duplicate_values(self):
        assert self.sort_array([3, 3, 1, 1, 5, 5]) == [1, 1, 3, 3, 5, 5]
    
    def test_already_sorted(self):
        assert self.sort_array([0, 1, 2, 3, 4]) == [0, 1, 2, 3, 4]
    
    def test_reverse_sorted(self):
        assert self.sort_array([4, 3, 2, 1, 0]) == [0, 1, 2, 3, 4]
    
    @pytest.mark.parametrize("input_arr,expected", [
        ([1, 5, 2, 3, 4], [1, 2, 3, 4, 5]),
        ([0], [0]),
        ([1], [1]),
        ([7, 3, 5], [3, 5, 7]),
        ([15, 8, 4, 2, 1], [1, 2, 4, 8, 15]),
    ])
    def test_parametrized_cases(self, input_arr, expected):
        assert self.sort_array(input_arr) == expected