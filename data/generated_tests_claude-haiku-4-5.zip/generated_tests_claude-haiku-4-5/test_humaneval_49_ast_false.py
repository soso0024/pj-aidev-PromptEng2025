# Test cases for HumanEval/49
# Generated using Claude API



def modp(n: int, p: int):
    """Return 2^n modulo p (be aware of numerics).
    >>> modp(3, 5)
    3
    >>> modp(1101, 101)
    2
    >>> modp(0, 101)
    1
    >>> modp(3, 11)
    8
    >>> modp(100, 101)
    1
    """

    ret = 1
    for i in range(n):
        ret = (2 * ret) % p
    return ret


# Generated test cases:
import pytest


class TestModp:
    
    @pytest.mark.parametrize("n,p,expected", [
        (0, 5, 1),
        (1, 5, 2),
        (2, 5, 4),
        (3, 5, 3),
        (4, 5, 1),
        (5, 5, 2),
    ])
    def test_basic_cases(self, n, p, expected):
        from solution import modp
        assert modp(n, p) == expected
    
    @pytest.mark.parametrize("n,p,expected", [
        (0, 1, 1),
        (1, 1, 0),
        (5, 1, 0),
        (100, 1, 0),
    ])
    def test_modulo_one(self, n, p, expected):
        assert modp(n, p) == expected
    
    @pytest.mark.parametrize("n,p,expected", [
        (0, 2, 1),
        (1, 2, 0),
        (2, 2, 0),
        (3, 2, 0),
    ])
    def test_modulo_two(self, n, p, expected):
        assert modp(n, p) == expected
    
    @pytest.mark.parametrize("n,p,expected", [
        (0, 7, 1),
        (1, 7, 2),
        (2, 7, 4),
        (3, 7, 1),
        (4, 7, 2),
        (5, 7, 4),
        (6, 7, 1),
    ])
    def test_modulo_seven(self, n, p, expected):
        assert modp(n, p) == expected
    
    @pytest.mark.parametrize("n,p,expected", [
        (10, 13, 10),
        (20, 17, 16),
        (15, 11, 10),
    ])
    def test_larger_values(self, n, p, expected):
        assert modp(n, p) == expected
    
    @pytest.mark.parametrize("n,p,expected", [
        (0, 1000000007, 1),
        (1, 1000000007, 2),
        (100, 1000000007, 976371285),
    ])
    def test_large_prime_modulo(self, n, p, expected):
        assert modp(n, p) == expected
    
    def test_zero_n_any_p(self):
        assert modp(0, 5) == 1
        assert modp(0, 100) == 1
        assert modp(0, 1) == 1
    
    def test_large_n_small_p(self):
        result = modp(1000, 7)
        assert 0 <= result < 7
        assert result == modp(1000, 7)
    
    def test_n_equals_p(self):
        assert modp(5, 5) == 2
        assert modp(7, 7) == 2
    
    def test_n_greater_than_p(self):
        result = modp(10, 3)
        assert 0 <= result < 3
    
    def test_return_type_is_int(self):
        result = modp(5, 7)
        assert isinstance(result, int)
    
    def test_result_always_less_than_p(self):
        for n in range(20):
            for p in range(2, 20):
                result = modp(n, p)
                assert 0 <= result < p
    
    def test_result_always_non_negative(self):
        for n in range(15):
            for p in range(1, 15):
                result = modp(n, p)
                assert result >= 0
    
    @pytest.mark.parametrize("n,p", [
        (100, 97),
        (50, 53),
        (1000, 1009),
    ])
    def test_with_prime_moduli(self, n, p):
        result = modp(n, p)
        assert 0 <= result < p
    
    def test_consistency(self):
        assert modp(5, 11) == modp(5, 11)
        assert modp(10, 7) == modp(10, 7)
    
    def test_small_modulo_large_n(self):
        result = modp(100, 3)
        assert result in [0, 1, 2]
    
    def test_modulo_three_pattern(self):
        results = [modp(i, 3) for i in range(10)]
        assert results == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]