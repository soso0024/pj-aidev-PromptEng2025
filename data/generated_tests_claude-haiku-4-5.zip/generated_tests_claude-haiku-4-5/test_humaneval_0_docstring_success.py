# Test cases for HumanEval/0
# Generated using Claude API

from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """

    for idx, elem in enumerate(numbers):
        for idx2, elem2 in enumerate(numbers):
            if idx != idx2:
                distance = abs(elem - elem2)
                if distance < threshold:
                    return True

    return False


# Generated test cases:
import pytest
from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    for idx, elem in enumerate(numbers):
        for idx2, elem2 in enumerate(numbers):
            if idx != idx2:
                distance = abs(elem - elem2)
                if distance < threshold:
                    return True

    return False


class TestHasCloseElements:
    
    def test_no_close_elements(self):
        assert has_close_elements([1.0, 2.0, 3.0], 0.5) == False
    
    def test_has_close_elements(self):
        assert has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3) == True
    
    def test_empty_list(self):
        assert has_close_elements([], 0.5) == False
    
    def test_single_element(self):
        assert has_close_elements([1.0], 0.5) == False
    
    def test_two_elements_close(self):
        assert has_close_elements([1.0, 1.1], 0.2) == True
    
    def test_two_elements_not_close(self):
        assert has_close_elements([1.0, 2.0], 0.5) == False
    
    def test_two_elements_exactly_at_threshold(self):
        assert has_close_elements([1.0, 1.5], 0.5) == False
    
    def test_two_elements_just_below_threshold(self):
        assert has_close_elements([1.0, 1.49], 0.5) == True
    
    def test_negative_numbers(self):
        assert has_close_elements([-1.0, -1.1], 0.2) == True
    
    def test_negative_and_positive(self):
        assert has_close_elements([-0.1, 0.1], 0.3) == True
    
    def test_zero_threshold(self):
        assert has_close_elements([1.0, 1.0], 0.0) == False
    
    def test_very_small_threshold(self):
        assert has_close_elements([1.0, 1.0000001], 0.00001) == True
    
    def test_very_large_numbers(self):
        assert has_close_elements([1000000.0, 1000000.5], 1.0) == True
    
    def test_very_small_numbers(self):
        assert has_close_elements([0.0000001, 0.0000002], 0.00000005) == False
    
    def test_multiple_pairs_close(self):
        assert has_close_elements([1.0, 1.1, 5.0, 5.05], 0.2) == True
    
    def test_all_same_numbers(self):
        assert has_close_elements([1.0, 1.0, 1.0], 0.1) == True
    
    def test_large_list_no_close_elements(self):
        assert has_close_elements([1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0], 0.5) == False
    
    def test_large_list_with_close_elements(self):
        assert has_close_elements([1.0, 2.0, 3.0, 4.0, 5.0, 5.1, 6.0, 7.0, 8.0, 9.0], 0.2) == True
    
    def test_close_elements_at_end(self):
        assert has_close_elements([1.0, 2.0, 3.0, 4.0, 4.05], 0.1) == True
    
    def test_close_elements_at_start(self):
        assert has_close_elements([1.0, 1.05, 3.0, 4.0, 5.0], 0.1) == True
    
    def test_duplicate_elements(self):
        assert has_close_elements([1.0, 2.0, 1.0, 3.0], 0.5) == True
    
    @pytest.mark.parametrize("numbers,threshold,expected", [
        ([1.0, 2.0, 3.0], 0.5, False),
        ([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3, True),
        ([1.5, 1.51], 0.02, True),
        ([1.5, 1.51], 0.009, False),
        ([-5.0, -4.9], 0.15, True),
        ([0.0, 0.0], 0.1, True),
    ])
    def test_parametrized_cases(self, numbers, threshold, expected):
        assert has_close_elements(numbers, threshold) == expected