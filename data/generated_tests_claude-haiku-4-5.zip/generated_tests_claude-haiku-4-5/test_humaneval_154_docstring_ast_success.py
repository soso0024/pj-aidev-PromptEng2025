# Test cases for HumanEval/154
# Generated using Claude API


def cycpattern_check(a , b):
    """You are given 2 words. You need to return True if the second word or any of its rotations is a substring in the first word
    cycpattern_check("abcd","abd") => False
    cycpattern_check("hello","ell") => True
    cycpattern_check("whassup","psus") => False
    cycpattern_check("abab","baa") => True
    cycpattern_check("efef","eeff") => False
    cycpattern_check("himenss","simen") => True

    """

    l = len(b)
    pat = b + b
    for i in range(len(a) - l + 1):
        for j in range(l + 1):
            if a[i:i+l] == pat[j:j+l]:
                return True
    return False


# Generated test cases:
import pytest


@pytest.mark.parametrize("a,b,expected", [
    ("abcd", "abd", False),
    ("hello", "ell", True),
    ("whassup", "psus", False),
    ("abab", "baa", True),
    ("efef", "eeff", False),
    ("himenss", "simen", True),
])
def test_cycpattern_check_docstring_examples(a, b, expected):
    from test_humaneval_154_docstring_ast import cycpattern_check
    assert cycpattern_check(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    ("a", "a", True),
    ("ab", "ba", True),
    ("abc", "cab", True),
    ("abc", "bca", True),
    ("abc", "abc", True),
])
def test_cycpattern_check_single_and_double_char(a, b, expected):
    assert cycpattern_check(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    ("aaaa", "aa", True),
    ("aaaa", "aaa", True),
    ("aaa", "aa", True),
    ("aa", "aaa", False),
])
def test_cycpattern_check_repeated_chars(a, b, expected):
    assert cycpattern_check(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    ("abcdefgh", "xyz", False),
    ("abcdefgh", "fgh", True),
    ("abcdefgh", "hfg", True),
    ("abcdefgh", "ghf", True),
])
def test_cycpattern_check_longer_strings(a, b, expected):
    assert cycpattern_check(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    ("x", "y", False),
    ("a", "b", False),
    ("abc", "d", False),
])
def test_cycpattern_check_no_match(a, b, expected):
    assert cycpattern_check(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    ("abcabc", "cab", True),
    ("abcabc", "bca", True),
    ("abcabc", "abc", True),
    ("xyxyxy", "yxy", True),
    ("xyxyxy", "xyx", True),
])
def test_cycpattern_check_cyclic_patterns(a, b, expected):
    assert cycpattern_check(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    ("programming", "mming", True),
])
def test_cycpattern_check_real_words(a, b, expected):
    assert cycpattern_check(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    ("abcd", "abcd", True),
    ("test", "test", True),
    ("hello", "hello", True),
])
def test_cycpattern_check_identical_strings(a, b, expected):
    assert cycpattern_check(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    ("abcdef", "cab", True),
    ("abcdef", "bab", False),
])
def test_cycpattern_check_rotations_at_end(a, b, expected):
    assert cycpattern_check(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    ("aabbcc", "bca", False),
    ("aabbcc", "cab", False),
    ("aabbcc", "abc", False),
])
def test_cycpattern_check_no_rotation_match(a, b, expected):
    assert cycpattern_check(a, b) == expected


def test_cycpattern_check_b_longer_than_a():
    assert cycpattern_check("ab", "abcd") == False


def test_cycpattern_check_empty_like_patterns():
    assert cycpattern_check("abcdef", "xyz") == False