# Test cases for HumanEval/121
# Generated using Claude API


def solution(lst):
    """Given a non-empty list of integers, return the sum of all of the odd elements that are in even positions.
    

    Examples
    solution([5, 8, 7, 1]) ==> 12
    solution([3, 3, 3, 3, 3]) ==> 9
    solution([30, 13, 24, 321]) ==>0
    """

    return sum([x for idx, x in enumerate(lst) if idx%2==0 and x%2==1])


# Generated test cases:
import pytest


def solution(lst):
    return sum([x for idx, x in enumerate(lst) if idx%2==0 and x%2==1])


class TestSolution:
    
    def test_example_1(self):
        assert solution([5, 8, 7, 1]) == 12
    
    def test_example_2(self):
        assert solution([3, 3, 3, 3, 3]) == 9
    
    def test_example_3(self):
        assert solution([30, 13, 24, 321]) == 0
    
    def test_single_odd_element_at_even_position(self):
        assert solution([5]) == 5
    
    def test_single_even_element_at_even_position(self):
        assert solution([4]) == 0
    
    def test_all_even_numbers(self):
        assert solution([2, 4, 6, 8]) == 0
    
    def test_all_odd_numbers(self):
        assert solution([1, 3, 5, 7]) == 6
    
    def test_odd_at_odd_positions_only(self):
        assert solution([2, 1, 4, 3, 6, 5]) == 0
    
    def test_mixed_positive_and_negative_odd(self):
        assert solution([1, 2, -3, 4, 5, 6]) == 3
    
    def test_negative_odd_numbers(self):
        assert solution([-1, 2, -3, 4, -5]) == -9
    
    def test_zero_at_even_positions(self):
        assert solution([0, 1, 0, 3]) == 0
    
    def test_large_odd_numbers(self):
        assert solution([999, 2, 1001, 4]) == 2000
    
    def test_two_elements_both_odd(self):
        assert solution([1, 3]) == 1
    
    def test_two_elements_first_odd_second_even(self):
        assert solution([1, 2]) == 1
    
    def test_two_elements_first_even_second_odd(self):
        assert solution([2, 1]) == 0
    
    def test_two_elements_both_even(self):
        assert solution([2, 4]) == 0
    
    def test_alternating_pattern(self):
        assert solution([1, 0, 1, 0, 1, 0]) == 3
    
    def test_long_list(self):
        assert solution([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == 25
    
    def test_negative_and_positive_mix(self):
        assert solution([-5, 10, 7, -2, -3, 8]) == -1
    
    def test_single_negative_odd(self):
        assert solution([-7]) == -7
    
    def test_single_negative_even(self):
        assert solution([-4]) == 0


@pytest.mark.parametrize("lst,expected", [
    ([5, 8, 7, 1], 12),
    ([3, 3, 3, 3, 3], 9),
    ([30, 13, 24, 321], 0),
    ([1], 1),
    ([2], 0),
    ([1, 1, 1, 1], 2),
    ([0, 0, 0, 0], 0),
    ([-1, 0, -3, 0], -4),
    ([11, 22, 33, 44, 55], 99),
    ([2, 3, 4, 5, 6, 7], 0),
])
def test_solution_parametrized(lst, expected):
    assert solution(lst) == expected