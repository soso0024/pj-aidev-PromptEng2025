# Test cases for HumanEval/42
# Generated using Claude API



def incr_list(l: list):
    """Return list with elements incremented by 1.
    >>> incr_list([1, 2, 3])
    [2, 3, 4]
    >>> incr_list([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [6, 4, 6, 3, 4, 4, 10, 1, 124]
    """

    return [(e + 1) for e in l]


# Generated test cases:
import pytest


def incr_list(l: list):
    return [(e + 1) for e in l]


class TestIncrList:
    def test_basic_list(self):
        assert incr_list([1, 2, 3]) == [2, 3, 4]

    def test_longer_list(self):
        assert incr_list([5, 3, 5, 2, 3, 3, 9, 0, 123]) == [6, 4, 6, 3, 4, 4, 10, 1, 124]

    def test_empty_list(self):
        assert incr_list([]) == []

    def test_single_element(self):
        assert incr_list([0]) == [1]

    def test_single_element_negative(self):
        assert incr_list([-5]) == [-4]

    def test_negative_numbers(self):
        assert incr_list([-1, -2, -3]) == [0, -1, -2]

    def test_mixed_positive_negative(self):
        assert incr_list([-1, 0, 1]) == [0, 1, 2]

    def test_large_numbers(self):
        assert incr_list([999999, 1000000]) == [1000000, 1000001]

    def test_large_negative_numbers(self):
        assert incr_list([-999999, -1000000]) == [-999998, -999999]

    def test_floats(self):
        assert incr_list([1.5, 2.5, 3.5]) == [2.5, 3.5, 4.5]

    def test_mixed_int_float(self):
        assert incr_list([1, 2.5, 3]) == [2, 3.5, 4]

    def test_zero(self):
        assert incr_list([0, 0, 0]) == [1, 1, 1]

    def test_preserves_order(self):
        assert incr_list([3, 1, 4, 1, 5]) == [4, 2, 5, 2, 6]

    def test_duplicates(self):
        assert incr_list([5, 5, 5]) == [6, 6, 6]

    @pytest.mark.parametrize("input_list,expected", [
        ([1, 2, 3], [2, 3, 4]),
        ([0], [1]),
        ([-1], [0]),
        ([100, 200, 300], [101, 201, 301]),
        ([], []),
    ])
    def test_parametrized_cases(self, input_list, expected):
        assert incr_list(input_list) == expected

    def test_return_type_is_list(self):
        result = incr_list([1, 2, 3])
        assert isinstance(result, list)

    def test_original_list_unchanged(self):
        original = [1, 2, 3]
        original_copy = original.copy()
        incr_list(original)
        assert original == original_copy

    def test_very_long_list(self):
        long_list = list(range(1000))
        result = incr_list(long_list)
        assert len(result) == 1000
        assert result[0] == 1
        assert result[-1] == 1000

    def test_negative_zero(self):
        assert incr_list([-0.0]) == [1.0]
