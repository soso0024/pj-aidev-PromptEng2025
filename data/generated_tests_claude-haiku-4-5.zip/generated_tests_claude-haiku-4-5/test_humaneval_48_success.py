# Test cases for HumanEval/48
# Generated using Claude API



def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """

    for i in range(len(text)):
        if text[i] != text[len(text) - 1 - i]:
            return False
    return True


# Generated test cases:
import pytest


def is_palindrome(text: str):
    for i in range(len(text)):
        if text[i] != text[len(text) - 1 - i]:
            return False
    return True


class TestIsPalindrome:
    
    @pytest.mark.parametrize("text,expected", [
        ("a", True),
        ("aa", True),
        ("aba", True),
        ("abba", True),
        ("racecar", True),
        ("madam", True),
        ("noon", True),
        ("level", True),
        ("", True),
    ])
    def test_valid_palindromes(self, text, expected):
        assert is_palindrome(text) == expected
    
    @pytest.mark.parametrize("text,expected", [
        ("ab", False),
        ("abc", False),
        ("abcd", False),
        ("hello", False),
        ("world", False),
        ("python", False),
        ("test", False),
    ])
    def test_invalid_palindromes(self, text, expected):
        assert is_palindrome(text) == expected
    
    def test_single_character(self):
        assert is_palindrome("a") == True
    
    def test_two_same_characters(self):
        assert is_palindrome("aa") == True
    
    def test_two_different_characters(self):
        assert is_palindrome("ab") == False
    
    def test_empty_string(self):
        assert is_palindrome("") == True
    
    def test_palindrome_with_spaces(self):
        assert is_palindrome("a b a") == True
    
    def test_palindrome_with_numbers(self):
        assert is_palindrome("12321") == True
    
    def test_palindrome_with_special_characters(self):
        assert is_palindrome("a!a") == True
    
    def test_long_palindrome(self):
        assert is_palindrome("abcdefghijihgfedcba") == True
    
    def test_long_non_palindrome(self):
        assert is_palindrome("abcdefghijklmnopqrst") == False
    
    def test_case_sensitive_palindrome(self):
        assert is_palindrome("Aa") == False
    
    def test_case_sensitive_same_case(self):
        assert is_palindrome("AA") == True
    
    def test_palindrome_with_mixed_case(self):
        assert is_palindrome("AaBbAa") == False
    
    def test_repeated_character(self):
        assert is_palindrome("aaaa") == True
    
    def test_repeated_non_palindrome(self):
        assert is_palindrome("abab") == False