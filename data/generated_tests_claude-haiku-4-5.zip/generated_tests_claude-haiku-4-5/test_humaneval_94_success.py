# Test cases for HumanEval/94
# Generated using Claude API



def skjkasdkd(lst):
    """You are given a list of integers.
    You need to find the largest prime value and return the sum of its digits.

    Examples:
    For lst = [0,3,2,1,3,5,7,4,5,5,5,2,181,32,4,32,3,2,32,324,4,3] the output should be 10
    For lst = [1,0,1,8,2,4597,2,1,3,40,1,2,1,2,4,2,5,1] the output should be 25
    For lst = [1,3,1,32,5107,34,83278,109,163,23,2323,32,30,1,9,3] the output should be 13
    For lst = [0,724,32,71,99,32,6,0,5,91,83,0,5,6] the output should be 11
    For lst = [0,81,12,3,1,21] the output should be 3
    For lst = [0,8,1,2,1,7] the output should be 7
    """

    def isPrime(n):
        for i in range(2,int(n**0.5)+1):
            if n%i==0:
                return False

        return True
    maxx = 0
    i = 0
    while i < len(lst):
        if(lst[i] > maxx and isPrime(lst[i])):
            maxx = lst[i]
        i+=1
    result = sum(int(digit) for digit in str(maxx))
    return result



# Generated test cases:
import pytest


def skjkasdkd(lst):
    def isPrime(n):
        for i in range(2,int(n**0.5)+1):
            if n%i==0:
                return False

        return True
    maxx = 0
    i = 0
    while i < len(lst):
        if(lst[i] > maxx and isPrime(lst[i])):
            maxx = lst[i]
        i+=1
    result = sum(int(digit) for digit in str(maxx))
    return result


class TestSkjkasdkd:
    
    def test_single_prime(self):
        assert skjkasdkd([5]) == 5
    
    def test_single_non_prime(self):
        assert skjkasdkd([4]) == 0
    
    def test_multiple_primes(self):
        assert skjkasdkd([2, 3, 5, 7]) == 7
    
    def test_multiple_primes_unordered(self):
        assert skjkasdkd([7, 2, 5, 3]) == 7
    
    def test_mixed_primes_and_non_primes(self):
        assert skjkasdkd([4, 5, 6, 7, 8, 9]) == 7
    
    def test_no_primes(self):
        assert skjkasdkd([4, 6, 8, 9, 10]) == 0
    
    def test_empty_list(self):
        assert skjkasdkd([]) == 0
    
    def test_large_prime(self):
        assert skjkasdkd([97]) == 16
    
    def test_two_digit_prime_sum(self):
        assert skjkasdkd([11]) == 2
    
    def test_two_digit_prime_sum_13(self):
        assert skjkasdkd([13]) == 4
    
    def test_two_digit_prime_sum_29(self):
        assert skjkasdkd([29]) == 11
    
    def test_largest_prime_among_many(self):
        assert skjkasdkd([2, 3, 5, 7, 11, 13, 17, 19, 23]) == 5
    
    def test_negative_numbers(self):
        assert skjkasdkd([-5, -3, 2, 3]) == 3
    
    def test_zero_in_list(self):
        assert skjkasdkd([0, 2, 3, 5]) == 5
    
    def test_one_in_list(self):
        assert skjkasdkd([1, 2, 3, 5]) == 5
    
    def test_duplicate_primes(self):
        assert skjkasdkd([5, 5, 5, 7, 7]) == 7
    
    def test_prime_2(self):
        assert skjkasdkd([2]) == 2
    
    def test_prime_3(self):
        assert skjkasdkd([3]) == 3
    
    def test_large_list_with_large_prime(self):
        assert skjkasdkd([1, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 97]) == 16
    
    def test_all_same_non_prime(self):
        assert skjkasdkd([4, 4, 4, 4]) == 0
    
    def test_all_same_prime(self):
        assert skjkasdkd([5, 5, 5, 5]) == 5
    
    def test_prime_31(self):
        assert skjkasdkd([31]) == 4
    
    def test_prime_41(self):
        assert skjkasdkd([41]) == 5
    
    def test_prime_53(self):
        assert skjkasdkd([53]) == 8
    
    def test_mixed_with_negatives_and_primes(self):
        assert skjkasdkd([-10, -5, 0, 1, 2, 3, 4, 5]) == 5
    
    def test_large_composite_numbers(self):
        assert skjkasdkd([100, 200, 300, 400]) == 0
    
    def test_prime_89(self):
        assert skjkasdkd([89]) == 17
    
    def test_multiple_large_primes(self):
        assert skjkasdkd([83, 89, 97]) == 16
