# Test cases for HumanEval/128
# Generated using Claude API


def prod_signs(arr):
    """
    You are given an array arr of integers and you need to return
    sum of magnitudes of integers multiplied by product of all signs
    of each number in the array, represented by 1, -1 or 0.
    Note: return None for empty arr.

    Example:
    >>> prod_signs([1, 2, 2, -4]) == -9
    >>> prod_signs([0, 1]) == 0
    >>> prod_signs([]) == None
    """

    if not arr: return None
    prod = 0 if 0 in arr else (-1) ** len(list(filter(lambda x: x < 0, arr)))
    return prod * sum([abs(i) for i in arr])


# Generated test cases:
import pytest


def prod_signs(arr):
    if not arr: return None
    prod = 0 if 0 in arr else (-1) ** len(list(filter(lambda x: x < 0, arr)))
    return prod * sum([abs(i) for i in arr])


class TestProdSigns:
    
    def test_empty_array(self):
        assert prod_signs([]) is None
    
    def test_single_positive(self):
        assert prod_signs([5]) == 5
    
    def test_single_negative(self):
        assert prod_signs([-5]) == -5
    
    def test_single_zero(self):
        assert prod_signs([0]) == 0
    
    def test_all_positive(self):
        assert prod_signs([1, 2, 3]) == 6
    
    def test_all_negative(self):
        assert prod_signs([-1, -2, -3]) == -6
    
    def test_mixed_positive_negative_even_negatives(self):
        assert prod_signs([1, 2, -3, -4]) == 10
    
    def test_mixed_positive_negative_odd_negatives(self):
        assert prod_signs([1, 2, 2, -4]) == -9
    
    def test_with_zero_in_middle(self):
        assert prod_signs([1, 0, 2]) == 0
    
    def test_with_zero_at_start(self):
        assert prod_signs([0, 1, 2]) == 0
    
    def test_with_zero_at_end(self):
        assert prod_signs([1, 2, 0]) == 0
    
    def test_zero_with_negatives(self):
        assert prod_signs([0, 1]) == 0
    
    def test_zero_with_all_negatives(self):
        assert prod_signs([-1, -2, 0]) == 0
    
    def test_large_positive_numbers(self):
        assert prod_signs([100, 200, 300]) == 600
    
    def test_large_negative_numbers(self):
        assert prod_signs([-100, -200]) == 300
    
    def test_mixed_large_numbers(self):
        assert prod_signs([100, -200, 300]) == -600
    
    def test_one_negative_one_positive(self):
        assert prod_signs([-5, 10]) == -15
    
    def test_two_negatives_one_positive(self):
        assert prod_signs([-5, -10, 3]) == 18
    
    def test_three_negatives(self):
        assert prod_signs([-1, -2, -3]) == -6
    
    def test_four_negatives(self):
        assert prod_signs([-1, -2, -3, -4]) == 10
    
    def test_many_ones(self):
        assert prod_signs([1, 1, 1, 1]) == 4
    
    def test_many_negative_ones(self):
        assert prod_signs([-1, -1, -1, -1]) == 4
    
    def test_mixed_with_ones(self):
        assert prod_signs([1, -1, 1, -1]) == 4
    
    def test_large_array_all_positive(self):
        assert prod_signs([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == 55
    
    def test_large_array_even_negatives(self):
        arr = [1, 2, 3, -4, -5, 6]
        assert prod_signs(arr) == 21
    
    def test_large_array_odd_negatives(self):
        arr = [1, 2, 3, -4, -5, -6]
        assert prod_signs(arr) == -21
    
    def test_single_zero_only(self):
        assert prod_signs([0]) == 0
    
    def test_multiple_zeros(self):
        assert prod_signs([0, 0, 0]) == 0
    
    def test_negative_and_positive_same_magnitude(self):
        assert prod_signs([-5, 5]) == -10
    
    def test_result_is_zero_from_zero_in_array(self):
        assert prod_signs([5, 10, 0, 20]) == 0
    
    def test_negative_numbers_only_odd_count(self):
        assert prod_signs([-2, -3, -4]) == -9
    
    def test_negative_numbers_only_even_count(self):
        assert prod_signs([-2, -3]) == 5
    
    @pytest.mark.parametrize("arr,expected", [
        ([1, 2, 2, -4], -9),
        ([0, 1], 0),
        ([], None),
        ([5], 5),
        ([-5], -5),
        ([1, 2, 3], 6),
        ([-1, -2, -3], -6),
        ([1, -1], -2),
        ([0], 0),
    ])
    def test_parametrized_cases(self, arr, expected):
        assert prod_signs(arr) == expected
