# Test cases for HumanEval/149
# Generated using Claude API


def sorted_list_sum(lst):
    """Write a function that accepts a list of strings as a parameter,
    deletes the strings that have odd lengths from it,
    and returns the resulted list with a sorted order,
    The list is always a list of strings and never an array of numbers,
    and it may contain duplicates.
    The order of the list should be ascending by length of each word, and you
    should return the list sorted by that rule.
    If two words have the same length, sort the list alphabetically.
    The function should return a list of strings in sorted order.
    You may assume that all words will have the same length.
    For example:
    assert list_sort(["aa", "a", "aaa"]) => ["aa"]
    assert list_sort(["ab", "a", "aaa", "cd"]) => ["ab", "cd"]
    """

    lst.sort()
    new_lst = []
    for i in lst:
        if len(i)%2 == 0:
            new_lst.append(i)
    return sorted(new_lst, key=len)


# Generated test cases:
import pytest


class TestSortedListSum:
    
    def sorted_list_sum(self, lst):
        lst.sort()
        new_lst = []
        for i in lst:
            if len(i)%2 == 0:
                new_lst.append(i)
        return sorted(new_lst, key=len)
    
    def test_empty_list(self):
        assert self.sorted_list_sum([]) == []
    
    def test_single_even_length_string(self):
        assert self.sorted_list_sum(["ab"]) == ["ab"]
    
    def test_single_odd_length_string(self):
        assert self.sorted_list_sum(["abc"]) == []
    
    def test_all_even_length_strings(self):
        result = self.sorted_list_sum(["ab", "cd", "ef"])
        assert result == ["ab", "cd", "ef"]
    
    def test_all_odd_length_strings(self):
        assert self.sorted_list_sum(["a", "abc", "abcde"]) == []
    
    def test_mixed_even_odd_strings(self):
        result = self.sorted_list_sum(["ab", "abc", "cd", "abcd"])
        assert result == ["ab", "cd", "abcd"]
    
    def test_sorted_by_length(self):
        result = self.sorted_list_sum(["abcd", "ab", "abcdef"])
        assert result == ["ab", "abcd", "abcdef"]
        assert len(result[0]) <= len(result[1]) <= len(result[2])
    
    def test_unsorted_input_list(self):
        result = self.sorted_list_sum(["zz", "aa", "bb"])
        assert result == ["aa", "bb", "zz"]
    
    def test_duplicate_strings(self):
        result = self.sorted_list_sum(["ab", "ab", "cd"])
        assert result == ["ab", "ab", "cd"]
    
    def test_empty_strings(self):
        result = self.sorted_list_sum(["", "ab", ""])
        assert result == ["", "", "ab"]
    
    def test_strings_with_spaces(self):
        result = self.sorted_list_sum(["a b", "abc", "cd ef"])
        assert result == []
    
    def test_strings_with_special_characters(self):
        result = self.sorted_list_sum(["!!", "abc", "@@@@"])
        assert result == ["!!", "@@@@"]
    
    def test_numeric_strings(self):
        result = self.sorted_list_sum(["12", "123", "1234"])
        assert result == ["12", "1234"]
    
    def test_very_long_even_string(self):
        long_string = "a" * 100
        result = self.sorted_list_sum([long_string, "ab"])
        assert result == ["ab", long_string]
    
    def test_very_long_odd_string(self):
        long_string = "a" * 101
        result = self.sorted_list_sum([long_string, "ab"])
        assert result == ["ab"]
    
    def test_mixed_case_strings(self):
        result = self.sorted_list_sum(["Ab", "CD", "aBcD"])
        assert result == ["Ab", "CD", "aBcD"]
    
    def test_unicode_strings(self):
        result = self.sorted_list_sum(["café", "naïve", "test"])
        assert "test" in result
    
    @pytest.mark.parametrize("input_list,expected", [
        (["ab", "cd"], ["ab", "cd"]),
        (["a", "b"], []),
        (["abcd", "ab"], ["ab", "abcd"]),
        (["zz", "aa"], ["aa", "zz"]),
        (["test", "ok"], ["ok", "test"]),
    ])
    def test_parametrized_cases(self, input_list, expected):
        assert self.sorted_list_sum(input_list) == expected
    
    def test_preserves_original_list_sorting(self):
        original = ["zz", "aa", "bb"]
        self.sorted_list_sum(original)
        assert original == ["aa", "bb", "zz"]
    
    def test_large_list(self):
        large_list = [f"str{i}" for i in range(100)]
        result = self.sorted_list_sum(large_list)
        assert all(len(s) % 2 == 0 for s in result)
        assert result == sorted(result, key=len)