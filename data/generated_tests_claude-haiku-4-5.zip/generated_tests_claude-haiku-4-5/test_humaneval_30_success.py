# Test cases for HumanEval/30
# Generated using Claude API



def get_positive(l: list):
    """Return only positive numbers in the list.
    >>> get_positive([-1, 2, -4, 5, 6])
    [2, 5, 6]
    >>> get_positive([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    [5, 3, 2, 3, 9, 123, 1]
    """

    return [e for e in l if e > 0]


# Generated test cases:
import pytest


def get_positive(l: list):
    return [e for e in l if e > 0]


class TestGetPositive:
    def test_empty_list(self):
        assert get_positive([]) == []

    def test_all_positive(self):
        assert get_positive([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

    def test_all_negative(self):
        assert get_positive([-1, -2, -3, -4, -5]) == []

    def test_mixed_positive_negative(self):
        assert get_positive([-2, -1, 0, 1, 2]) == [1, 2]

    def test_with_zero(self):
        assert get_positive([0, 0, 0]) == []

    def test_single_positive(self):
        assert get_positive([5]) == [5]

    def test_single_negative(self):
        assert get_positive([-5]) == []

    def test_single_zero(self):
        assert get_positive([0]) == []

    def test_floats_positive(self):
        assert get_positive([1.5, 2.7, 3.1]) == [1.5, 2.7, 3.1]

    def test_floats_mixed(self):
        assert get_positive([-1.5, 0.0, 1.5, 2.7]) == [1.5, 2.7]

    def test_floats_negative(self):
        assert get_positive([-1.5, -2.7, -3.1]) == []

    def test_large_numbers(self):
        assert get_positive([1000000, -1000000, 999999]) == [1000000, 999999]

    def test_very_small_positive(self):
        assert get_positive([0.0001, -0.0001]) == [0.0001]

    def test_mixed_int_float(self):
        assert get_positive([-1, 1.5, 2, -3.5, 4]) == [1.5, 2, 4]

    def test_preserves_order(self):
        assert get_positive([5, -3, 2, -1, 4]) == [5, 2, 4]

    def test_duplicate_positive_values(self):
        assert get_positive([1, 1, 2, 2, 3, 3]) == [1, 1, 2, 2, 3, 3]

    def test_duplicate_mixed_values(self):
        assert get_positive([-1, -1, 1, 1, 0, 0]) == [1, 1]

    @pytest.mark.parametrize("input_list,expected", [
        ([1, 2, 3], [1, 2, 3]),
        ([-1, -2, -3], []),
        ([0], []),
        ([1], [1]),
        ([], []),
        ([1, -1, 2, -2, 3, -3], [1, 2, 3]),
    ])
    def test_parametrized_cases(self, input_list, expected):
        assert get_positive(input_list) == expected

    def test_returns_list_type(self):
        result = get_positive([1, 2, 3])
        assert isinstance(result, list)

    def test_does_not_modify_original(self):
        original = [1, -2, 3, -4]
        original_copy = original.copy()
        get_positive(original)
        assert original == original_copy

    def test_negative_zero_float(self):
        assert get_positive([-0.0, 0.0]) == []

    def test_scientific_notation(self):
        assert get_positive([1e-5, -1e-5, 1e5]) == [1e-5, 1e5]
