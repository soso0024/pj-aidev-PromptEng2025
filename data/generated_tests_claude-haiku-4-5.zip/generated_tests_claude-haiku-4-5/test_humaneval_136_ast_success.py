# Test cases for HumanEval/136
# Generated using Claude API


def largest_smallest_integers(lst):
    '''
    Create a function that returns a tuple (a, b), where 'a' is
    the largest of negative integers, and 'b' is the smallest
    of positive integers in a list.
    If there is no negative or positive integers, return them as None.

    Examples:
    largest_smallest_integers([2, 4, 1, 3, 5, 7]) == (None, 1)
    largest_smallest_integers([]) == (None, None)
    largest_smallest_integers([0]) == (None, None)
    '''

    smallest = list(filter(lambda x: x < 0, lst))
    largest = list(filter(lambda x: x > 0, lst))
    return (max(smallest) if smallest else None, min(largest) if largest else None)


# Generated test cases:
import pytest


def largest_smallest_integers(lst):
    smallest = list(filter(lambda x: x < 0, lst))
    largest = list(filter(lambda x: x > 0, lst))
    return (max(smallest) if smallest else None, min(largest) if largest else None)


class TestLargestSmallestIntegers:
    
    def test_normal_case_with_positive_and_negative(self):
        result = largest_smallest_integers([1, 2, 3, -1, -2, -3])
        assert result == (-1, 1)
    
    def test_single_negative_single_positive(self):
        result = largest_smallest_integers([-5, 10])
        assert result == (-5, 10)
    
    def test_only_negative_numbers(self):
        result = largest_smallest_integers([-1, -2, -3, -4])
        assert result == (-1, None)
    
    def test_only_positive_numbers(self):
        result = largest_smallest_integers([1, 2, 3, 4])
        assert result == (None, 1)
    
    def test_empty_list(self):
        result = largest_smallest_integers([])
        assert result == (None, None)
    
    def test_with_zero(self):
        result = largest_smallest_integers([-5, 0, 5])
        assert result == (-5, 5)
    
    def test_only_zeros(self):
        result = largest_smallest_integers([0, 0, 0])
        assert result == (None, None)
    
    def test_large_negative_and_positive(self):
        result = largest_smallest_integers([-1000, 1000])
        assert result == (-1000, 1000)
    
    def test_multiple_negatives_find_largest(self):
        result = largest_smallest_integers([-10, -5, -1, -20])
        assert result == (-1, None)
    
    def test_multiple_positives_find_smallest(self):
        result = largest_smallest_integers([100, 50, 1, 200])
        assert result == (None, 1)
    
    def test_mixed_with_duplicates(self):
        result = largest_smallest_integers([-5, -5, 5, 5])
        assert result == (-5, 5)
    
    def test_single_element_negative(self):
        result = largest_smallest_integers([-7])
        assert result == (-7, None)
    
    def test_single_element_positive(self):
        result = largest_smallest_integers([7])
        assert result == (None, 7)
    
    def test_single_element_zero(self):
        result = largest_smallest_integers([0])
        assert result == (None, None)
    
    def test_negative_one_positive_one(self):
        result = largest_smallest_integers([-1, 1])
        assert result == (-1, 1)
    
    def test_complex_mixed_list(self):
        result = largest_smallest_integers([-100, -50, -1, 0, 1, 50, 100])
        assert result == (-1, 1)
    
    def test_all_same_negative(self):
        result = largest_smallest_integers([-5, -5, -5])
        assert result == (-5, None)
    
    def test_all_same_positive(self):
        result = largest_smallest_integers([5, 5, 5])
        assert result == (None, 5)
    
    def test_negative_zero_positive(self):
        result = largest_smallest_integers([-3, 0, 3])
        assert result == (-3, 3)
    
    def test_large_list_mixed(self):
        result = largest_smallest_integers(list(range(-50, 51)))
        assert result == (-1, 1)


@pytest.mark.parametrize("input_list,expected", [
    ([1, 2, 3, -1, -2, -3], (-1, 1)),
    ([-5, 10], (-5, 10)),
    ([-1, -2, -3, -4], (-1, None)),
    ([1, 2, 3, 4], (None, 1)),
    ([], (None, None)),
    ([-5, 0, 5], (-5, 5)),
    ([0, 0, 0], (None, None)),
    ([-1000, 1000], (-1000, 1000)),
    ([-10, -5, -1, -20], (-1, None)),
    ([100, 50, 1, 200], (None, 1)),
    ([-5, -5, 5, 5], (-5, 5)),
    ([-7], (-7, None)),
    ([7], (None, 7)),
    ([0], (None, None)),
    ([-1, 1], (-1, 1)),
])
def test_largest_smallest_integers_parametrized(input_list, expected):
    assert largest_smallest_integers(input_list) == expected
