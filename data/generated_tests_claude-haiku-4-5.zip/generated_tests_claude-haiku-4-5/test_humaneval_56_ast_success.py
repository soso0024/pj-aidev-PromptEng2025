# Test cases for HumanEval/56
# Generated using Claude API



def correct_bracketing(brackets: str):
    """ brackets is a string of "<" and ">".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """

    depth = 0
    for b in brackets:
        if b == "<":
            depth += 1
        else:
            depth -= 1
        if depth < 0:
            return False
    return depth == 0


# Generated test cases:
import pytest


def correct_bracketing(brackets: str):
    depth = 0
    for b in brackets:
        if b == "<":
            depth += 1
        else:
            depth -= 1
        if depth < 0:
            return False
    return depth == 0


class TestCorrectBracketing:
    
    @pytest.mark.parametrize("brackets,expected", [
        ("", True),
        ("<>", True),
        ("<<>>", True),
        ("<><>", True),
        ("<<<>>>", True),
        ("<><><>", True),
        ("<<><>>", True),
        ("<><<>>", True),
    ])
    def test_valid_brackets(self, brackets, expected):
        assert correct_bracketing(brackets) == expected
    
    @pytest.mark.parametrize("brackets,expected", [
        (">", False),
        (">>", False),
        ("<", False),
        ("<<", False),
        ("<>>", False),
        ("><", False),
        (">><", False),
        ("<<>", False),
        ("<><>>", False),
        ("><><", False),
    ])
    def test_invalid_brackets(self, brackets, expected):
        assert correct_bracketing(brackets) == expected
    
    def test_empty_string(self):
        assert correct_bracketing("") == True
    
    def test_single_open_bracket(self):
        assert correct_bracketing("<") == False
    
    def test_single_close_bracket(self):
        assert correct_bracketing(">") == False
    
    def test_matching_pair(self):
        assert correct_bracketing("<>") == True
    
    def test_nested_brackets(self):
        assert correct_bracketing("<<>>") == True
    
    def test_multiple_pairs(self):
        assert correct_bracketing("<><>") == True
    
    def test_close_before_open(self):
        assert correct_bracketing("><") == False
    
    def test_extra_close_bracket(self):
        assert correct_bracketing("<>>") == False
    
    def test_extra_open_bracket(self):
        assert correct_bracketing("<<>") == False
    
    def test_complex_valid(self):
        assert correct_bracketing("<<><>>") == True
    
    def test_complex_invalid_early_close(self):
        assert correct_bracketing("<><>>") == False
    
    def test_long_valid_sequence(self):
        assert correct_bracketing("<" * 10 + ">" * 10) == True
    
    def test_long_invalid_sequence(self):
        assert correct_bracketing(">" + "<" * 10 + ">" * 9) == False
    
    def test_alternating_valid(self):
        assert correct_bracketing("<>" * 5) == True
    
    def test_deeply_nested(self):
        assert correct_bracketing("<" * 100 + ">" * 100) == True
    
    def test_deeply_nested_invalid(self):
        assert correct_bracketing("<" * 100 + ">" * 101) == False


def test_correct_bracketing_empty():
    assert correct_bracketing("") == True


def test_correct_bracketing_valid_simple():
    assert correct_bracketing("<>") == True


def test_correct_bracketing_valid_nested():
    assert correct_bracketing("<<>>") == True


def test_correct_bracketing_valid_multiple():
    assert correct_bracketing("<><>") == True


def test_correct_bracketing_invalid_single_open():
    assert correct_bracketing("<") == False


def test_correct_bracketing_invalid_single_close():
    assert correct_bracketing(">") == False


def test_correct_bracketing_invalid_close_first():
    assert correct_bracketing("><") == False


def test_correct_bracketing_invalid_extra_close():
    assert correct_bracketing("<>>") == False


def test_correct_bracketing_invalid_extra_open():
    assert correct_bracketing("<<>") == False
