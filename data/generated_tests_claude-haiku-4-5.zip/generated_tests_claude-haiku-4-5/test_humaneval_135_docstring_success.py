# Test cases for HumanEval/135
# Generated using Claude API


def can_arrange(arr):
    """Create a function which returns the largest index of an element which
    is not greater than or equal to the element immediately preceding it. If
    no such element exists then return -1. The given array will not contain
    duplicate values.

    Examples:
    can_arrange([1,2,4,3,5]) = 3
    can_arrange([1,2,3]) = -1
    """

    ind=-1
    i=1
    while i<len(arr):
      if arr[i]<arr[i-1]:
        ind=i
      i+=1
    return ind


# Generated test cases:
import pytest


def can_arrange(arr):
    ind=-1
    i=1
    while i<len(arr):
      if arr[i]<arr[i-1]:
        ind=i
      i+=1
    return ind


@pytest.mark.parametrize("arr,expected", [
    ([1, 2, 4, 3, 5], 3),
    ([1, 2, 3], -1),
    ([5, 4, 3, 2, 1], 4),
    ([1], -1),
    ([2, 1], 1),
    ([1, 3, 2, 4], 2),
    ([1, 2, 3, 4, 5], -1),
    ([5, 1, 2, 3, 4], 1),
    ([1, 2, 5, 3, 4], 3),
    ([10, 20, 30, 25, 40], 3),
    ([1, 2, 3, 2, 5], 3),
    ([], -1),
    ([100], -1),
    ([2, 1, 3], 1),
    ([1, 5, 0, 3, 4, 5], 2),
    ([3, 2, 1], 2),
    ([1, 2, 3, 4, 3], 4),
    ([5, 4], 1),
    ([1, 1000, 2], 2),
    ([-5, -3, -1], -1),
    ([-1, -5, 0], 1),
    ([0, -1, 1], 1),
    ([100, 50, 75, 25], 3),
])
def test_can_arrange(arr, expected):
    assert can_arrange(arr) == expected


def test_can_arrange_single_element():
    assert can_arrange([42]) == -1


def test_can_arrange_two_elements_ascending():
    assert can_arrange([1, 2]) == -1


def test_can_arrange_two_elements_descending():
    assert can_arrange([2, 1]) == 1


def test_can_arrange_empty_array():
    assert can_arrange([]) == -1


def test_can_arrange_all_ascending():
    assert can_arrange([1, 2, 3, 4, 5, 6, 7]) == -1


def test_can_arrange_all_descending():
    assert can_arrange([7, 6, 5, 4, 3, 2, 1]) == 6


def test_can_arrange_multiple_violations():
    result = can_arrange([1, 2, 4, 3, 5, 4])
    assert result == 5


def test_can_arrange_violation_at_end():
    result = can_arrange([1, 2, 3, 4, 5, 3])
    assert result == 5


def test_can_arrange_violation_at_start():
    result = can_arrange([5, 1, 2, 3, 4])
    assert result == 1


def test_can_arrange_negative_numbers():
    assert can_arrange([-10, -5, -3, -1]) == -1


def test_can_arrange_mixed_positive_negative():
    assert can_arrange([-5, 0, 5, 10]) == -1


def test_can_arrange_large_numbers():
    assert can_arrange([1000000, 2000000, 3000000]) == -1


def test_can_arrange_large_numbers_with_violation():
    assert can_arrange([1000000, 2000000, 1500000]) == 2