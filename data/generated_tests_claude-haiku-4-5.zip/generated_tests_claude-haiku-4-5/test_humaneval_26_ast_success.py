# Test cases for HumanEval/26
# Generated using Claude API

from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    """ From a list of integers, remove all elements that occur more than once.
    Keep order of elements left the same as in the input.
    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """

    import collections
    c = collections.Counter(numbers)
    return [n for n in numbers if c[n] <= 1]


# Generated test cases:
import pytest
from typing import List
import collections


def remove_duplicates(numbers: List[int]) -> List[int]:
    c = collections.Counter(numbers)
    return [n for n in numbers if c[n] <= 1]


class TestRemoveDuplicates:
    
    def test_empty_list(self):
        assert remove_duplicates([]) == []
    
    def test_single_element(self):
        assert remove_duplicates([1]) == [1]
    
    def test_no_duplicates(self):
        assert remove_duplicates([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    
    def test_all_duplicates(self):
        assert remove_duplicates([1, 1, 1, 1]) == []
    
    def test_some_duplicates(self):
        assert remove_duplicates([1, 2, 2, 3, 3, 3, 4]) == [1, 4]
    
    def test_duplicates_at_start(self):
        assert remove_duplicates([1, 1, 2, 3]) == [2, 3]
    
    def test_duplicates_at_end(self):
        assert remove_duplicates([1, 2, 3, 3]) == [1, 2]
    
    def test_duplicates_in_middle(self):
        assert remove_duplicates([1, 2, 2, 3]) == [1, 3]
    
    def test_negative_numbers(self):
        assert remove_duplicates([-1, -2, -2, -3]) == [-1, -3]
    
    def test_mixed_positive_negative(self):
        assert remove_duplicates([-1, 1, -1, 1, 2]) == [2]
    
    def test_zero_included(self):
        assert remove_duplicates([0, 0, 1, 2]) == [1, 2]
    
    def test_zero_single(self):
        assert remove_duplicates([0, 1, 2]) == [0, 1, 2]
    
    def test_large_numbers(self):
        assert remove_duplicates([1000000, 1000000, 2000000]) == [2000000]
    
    def test_preserves_order(self):
        assert remove_duplicates([5, 1, 5, 2, 3, 2, 4]) == [1, 3, 4]
    
    def test_two_elements_same(self):
        assert remove_duplicates([1, 1]) == []
    
    def test_two_elements_different(self):
        assert remove_duplicates([1, 2]) == [1, 2]
    
    def test_triple_duplicates(self):
        assert remove_duplicates([1, 1, 1, 2, 2, 3]) == [3]
    
    def test_alternating_duplicates(self):
        assert remove_duplicates([1, 2, 1, 2, 1, 2]) == []
    
    def test_single_duplicate_multiple_times(self):
        assert remove_duplicates([5, 5, 5, 5, 5]) == []
    
    def test_many_unique_with_one_duplicate(self):
        result = remove_duplicates([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 5])
        assert result == [1, 2, 3, 4, 6, 7, 8, 9, 10]
    
    @pytest.mark.parametrize("input_list,expected", [
        ([1, 2, 3], [1, 2, 3]),
        ([1, 1, 2], [2]),
        ([1, 2, 2], [1]),
        ([1, 1, 1], []),
        ([], []),
        ([42], [42]),
        ([0], [0]),
        ([-5, -5, 10], [10]),
    ])
    def test_parametrized_cases(self, input_list, expected):
        assert remove_duplicates(input_list) == expected
