# Test cases for HumanEval/109
# Generated using Claude API


def move_one_ball(arr):
    """We have an array 'arr' of N integers arr[1], arr[2], ..., arr[N].The
    numbers in the array will be randomly ordered. Your task is to determine if
    it is possible to get an array sorted in non-decreasing order by performing 
    the following operation on the given array:
        You are allowed to perform right shift operation any number of times.
    
    One right shift operation means shifting all elements of the array by one
    position in the right direction. The last element of the array will be moved to
    the starting position in the array i.e. 0th index. 

    If it is possible to obtain the sorted array by performing the above operation
    then return True else return False.
    If the given array is empty then return True.

    Note: The given list is guaranteed to have unique elements.

    For Example:
    
    move_one_ball([3, 4, 5, 1, 2])==>True
    Explanation: By performin 2 right shift operations, non-decreasing order can
                 be achieved for the given array.
    move_one_ball([3, 5, 4, 1, 2])==>False
    Explanation:It is not possible to get non-decreasing order for the given
                array by performing any number of right shift operations.
                
    """

    if len(arr)==0:
      return True
    sorted_array=sorted(arr)
    my_arr=[]
    
    min_value=min(arr)
    min_index=arr.index(min_value)
    my_arr=arr[min_index:]+arr[0:min_index]
    for i in range(len(arr)):
      if my_arr[i]!=sorted_array[i]:
        return False
    return True


# Generated test cases:
import pytest


class TestMoveOneBall:
    
    def test_empty_array(self):
        from test_humaneval_109_ast import move_one_ball
        assert move_one_ball([]) == True
    
    def test_single_element(self):
        assert move_one_ball([1]) == True
    
    def test_already_sorted(self):
        assert move_one_ball([1, 2, 3, 4, 5]) == True
    
    def test_rotated_sorted_array(self):
        assert move_one_ball([3, 4, 5, 1, 2]) == True
    
    def test_rotated_sorted_array_two_elements(self):
        assert move_one_ball([2, 1]) == True
    
    def test_not_rotated_sorted(self):
        assert move_one_ball([1, 3, 2]) == False
    
    def test_completely_unsorted(self):
        assert move_one_ball([5, 1, 3, 2, 4]) == False
    
    def test_two_elements_sorted(self):
        assert move_one_ball([1, 2]) == True
    
    def test_duplicate_elements_sorted(self):
        assert move_one_ball([1, 1, 1, 1]) == True
    
    def test_duplicate_elements_rotated(self):
        assert move_one_ball([2, 2, 1, 1]) == True
    
    def test_negative_numbers_sorted(self):
        assert move_one_ball([-5, -3, -1, 0, 2]) == True
    
    def test_negative_numbers_rotated(self):
        assert move_one_ball([-1, 0, 2, -5, -3]) == True
    
    def test_mixed_positive_negative_sorted(self):
        assert move_one_ball([-2, -1, 0, 1, 2]) == True
    
    def test_mixed_positive_negative_rotated(self):
        assert move_one_ball([0, 1, 2, -2, -1]) == True
    
    def test_large_array_sorted(self):
        assert move_one_ball(list(range(1, 101))) == True
    
    def test_large_array_rotated(self):
        arr = list(range(50, 101)) + list(range(1, 50))
        assert move_one_ball(arr) == True
    
    def test_large_array_unsorted(self):
        assert move_one_ball([100, 1, 50, 25, 75]) == False
    
    def test_three_elements_rotated(self):
        assert move_one_ball([2, 3, 1]) == True
    
    def test_three_elements_unsorted(self):
        assert move_one_ball([3, 1, 2]) == True
    
    def test_all_same_elements(self):
        assert move_one_ball([5, 5, 5, 5, 5]) == True
    
    def test_two_different_elements_sorted(self):
        assert move_one_ball([1, 2, 2, 2]) == True
    
    def test_two_different_elements_rotated(self):
        assert move_one_ball([2, 2, 2, 1]) == True
    
    def test_descending_order(self):
        assert move_one_ball([5, 4, 3, 2, 1]) == False
    
    def test_almost_sorted_one_swap(self):
        assert move_one_ball([2, 1, 3, 4, 5]) == False
    
    def test_rotation_at_end(self):
        assert move_one_ball([5, 1, 2, 3, 4]) == True
    
    def test_rotation_at_start(self):
        assert move_one_ball([1, 2, 3, 4, 5]) == True
    
    def test_zero_in_array(self):
        assert move_one_ball([0, 1, 2, 3]) == True
    
    def test_zero_rotated(self):
        assert move_one_ball([2, 3, 0, 1]) == True
    
    def test_float_numbers(self):
        assert move_one_ball([1.5, 2.5, 3.5]) == True
    
    def test_float_numbers_rotated(self):
        assert move_one_ball([2.5, 3.5, 1.5]) == True


@pytest.mark.parametrize("arr,expected", [
    ([], True),
    ([1], True),
    ([1, 2], True),
    ([2, 1], True),
    ([1, 2, 3], True),
    ([2, 3, 1], True),
    ([3, 1, 2], True),
    ([1, 2, 3, 4, 5], True),
    ([3, 4, 5, 1, 2], True),
    ([5, 1, 2, 3, 4], True),
    ([1, 3, 2, 4, 5], False),
    ([5, 4, 3, 2, 1], False),
    ([1, 1, 1, 1], True),
    ([2, 1, 1, 1], True),
    ([-5, -3, -1, 0, 2], True),
    ([-1, 0, 2, -5, -3], True),
])
def test_move_one_ball_parametrized(arr, expected):
    assert move_one_ball(arr) == expected