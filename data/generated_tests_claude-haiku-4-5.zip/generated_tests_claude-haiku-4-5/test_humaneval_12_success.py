# Test cases for HumanEval/12
# Generated using Claude API

from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    """ Out of list of strings, return the longest one. Return the first one in case of multiple
    strings of the same length. Return None in case the input list is empty.
    >>> longest([])

    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    """

    if not strings:
        return None

    maxlen = max(len(x) for x in strings)
    for s in strings:
        if len(s) == maxlen:
            return s


# Generated test cases:
import pytest
from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    if not strings:
        return None

    maxlen = max(len(x) for x in strings)
    for s in strings:
        if len(s) == maxlen:
            return s


class TestLongest:
    def test_empty_list(self):
        assert longest([]) is None

    def test_single_string(self):
        assert longest(["hello"]) == "hello"

    def test_single_empty_string(self):
        assert longest([""]) == ""

    def test_multiple_strings_different_lengths(self):
        assert longest(["a", "bb", "ccc"]) == "ccc"

    def test_multiple_strings_same_length(self):
        result = longest(["abc", "def", "ghi"])
        assert result == "abc"

    def test_first_is_longest(self):
        assert longest(["longest", "short", "mid"]) == "longest"

    def test_last_is_longest(self):
        assert longest(["short", "mid", "longest"]) == "longest"

    def test_middle_is_longest(self):
        assert longest(["short", "longest", "mid"]) == "longest"

    def test_multiple_same_length_returns_first(self):
        assert longest(["abc", "def", "ghi", "jkl"]) == "abc"

    def test_with_empty_strings_mixed(self):
        assert longest(["", "a", ""]) == "a"

    def test_all_empty_strings(self):
        assert longest(["", "", ""]) == ""

    def test_single_character_strings(self):
        assert longest(["a", "b", "c"]) == "a"

    def test_long_strings(self):
        long_str = "a" * 1000
        assert longest([long_str, "short"]) == long_str

    def test_unicode_strings(self):
        assert longest(["café", "ab", "xyz"]) == "café"

    def test_strings_with_spaces(self):
        assert longest(["hello world", "hi", "test"]) == "hello world"

    def test_strings_with_special_characters(self):
        assert longest(["!@#$%", "ab", "test"]) == "!@#$%"

    @pytest.mark.parametrize("input_list,expected", [
        (["a"], "a"),
        (["ab", "a"], "ab"),
        (["a", "ab"], "ab"),
        (["abc", "ab", "a"], "abc"),
        (["x", "xx", "xxx", "xxxx"], "xxxx"),
    ])
    def test_parametrized_cases(self, input_list, expected):
        assert longest(input_list) == expected

    def test_with_newlines(self):
        assert longest(["hello\nworld", "hi"]) == "hello\nworld"

    def test_with_tabs(self):
        assert longest(["hello\tworld", "hi"]) == "hello\tworld"

    def test_numeric_strings(self):
        assert longest(["123", "12", "1234"]) == "1234"

    def test_mixed_case_strings(self):
        assert longest(["ABC", "abc", "AbC"]) == "ABC"

    def test_very_long_list(self):
        strings = ["a" * i for i in range(1, 101)]
        assert longest(strings) == "a" * 100

    def test_duplicate_longest_strings(self):
        result = longest(["abc", "def", "abc"])
        assert result == "abc"
        assert len(result) == 3