# Test cases for HumanEval/86
# Generated using Claude API


def anti_shuffle(s):
    """
    Write a function that takes a string and returns an ordered version of it.
    Ordered version of string, is a string where all words (separated by space)
    are replaced by a new word where all the characters arranged in
    ascending order based on ascii value.
    Note: You should keep the order of words and blank spaces in the sentence.

    For example:
    anti_shuffle('Hi') returns 'Hi'
    anti_shuffle('hello') returns 'ehllo'
    anti_shuffle('Hello World!!!') returns 'Hello !!!Wdlor'
    """

    return ' '.join([''.join(sorted(list(i))) for i in s.split(' ')])


# Generated test cases:
import pytest


def anti_shuffle(s):
    return ' '.join([''.join(sorted(list(i))) for i in s.split(' ')])


@pytest.mark.parametrize("input_str,expected", [
    ("Hi", "Hi"),
    ("hello", "ehllo"),
    ("Hello World!!!", "Hello !!!Wdlor"),
    ("", ""),
    ("a", "a"),
    ("abc", "abc"),
    ("cba", "abc"),
    ("hello world", "ehllo dlorw"),
    ("The quick brown fox", "Teh cikqu bnorw fox"),
    ("123", "123"),
    ("321", "123"),
    ("a b c", "a b c"),
    ("zzz aaa bbb", "zzz aaa bbb"),
    ("dcba", "abcd"),
    ("zyx", "xyz"),
    ("Hello", "Hello"),
    ("HELLO", "EHLLO"),
    ("HeLLo", "HLLeo"),
    ("a1b2c3", "123abc"),
    ("!@#$%", "!#$%@"),
    ("   ", "   "),
    ("a  b", "a  b"),
    ("word1 word2 word3", "1dorw 2dorw 3dorw"),
    ("!!! ??? ***", "!!! ??? ***"),
    ("aAbBcC", "ABCabc"),
    ("zyxwvutsrqponmlkjihgfedcba", "abcdefghijklmnopqrstuvwxyz"),
    ("ZYXWVUTSRQPONMLKJIHGFEDCBA", "ABCDEFGHIJKLMNOPQRSTUVWXYZ"),
    ("The Quick BROWN fox jumps", "Teh Qciku BNORW fox jmpsu"),
    ("single", "egilns"),
    ("a", "a"),
    ("ab", "ab"),
    ("ba", "ab"),
    ("aaa", "aaa"),
    ("aab", "aab"),
    ("baa", "aab"),
    ("test string here", "estt ginrst eehr"),
    ("xyz abc def", "xyz abc def"),
    ("zyx cba fed", "xyz abc def"),
])
def test_anti_shuffle(input_str, expected):
    assert anti_shuffle(input_str) == expected


def test_anti_shuffle_preserves_word_count():
    result = anti_shuffle("hello world test")
    assert len(result.split(' ')) == 3


def test_anti_shuffle_preserves_spaces():
    result = anti_shuffle("a  b")
    assert result == "a  b"


def test_anti_shuffle_with_special_characters():
    result = anti_shuffle("!@# $%^")
    assert len(result.split(' ')) == 2


def test_anti_shuffle_empty_string():
    assert anti_shuffle("") == ""


def test_anti_shuffle_single_space():
    assert anti_shuffle(" ") == " "


def test_anti_shuffle_multiple_spaces():
    result = anti_shuffle("a   b")
    assert result == "a   b"


def test_anti_shuffle_numbers_and_letters():
    result = anti_shuffle("a1z9")
    assert result == "19az"


def test_anti_shuffle_mixed_case():
    result = anti_shuffle("AaBbCc")
    assert result == "ABCabc"


def test_anti_shuffle_long_word():
    long_word = "zyxwvutsrqponmlkjihgfedcba"
    result = anti_shuffle(long_word)
    assert result == "abcdefghijklmnopqrstuvwxyz"


def test_anti_shuffle_sentence_with_punctuation():
    result = anti_shuffle("Hello, World!")
    words = result.split(' ')
    assert len(words) == 2


def test_anti_shuffle_tabs_and_special_spaces():
    result = anti_shuffle("hello world")
    assert len(result.split(' ')) == 2