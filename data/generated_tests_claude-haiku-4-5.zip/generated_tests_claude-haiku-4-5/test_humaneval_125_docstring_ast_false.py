# Test cases for HumanEval/125
# Generated using Claude API


def split_words(txt):
    '''
    Given a string of words, return a list of words split on whitespace, if no whitespaces exists in the text you
    should split on commas ',' if no commas exists you should return the number of lower-case letters with odd order in the
    alphabet, ord('a') = 0, ord('b') = 1, ... ord('z') = 25
    Examples
    split_words("Hello world!") ➞ ["Hello", "world!"]
    split_words("Hello,world!") ➞ ["Hello", "world!"]
    split_words("abcdef") == 3 
    '''

    if " " in txt:
        return txt.split()
    elif "," in txt:
        return txt.replace(',',' ').split()
    else:
        return len([i for i in txt if i.islower() and ord(i)%2 == 0])


# Generated test cases:
import pytest


class TestSplitWordsWhitespace:
    def test_simple_whitespace_split(self):
        from test_humaneval_125_docstring_ast import split_words
        assert split_words("Hello world!") == ["Hello", "world!"]
    
    def test_multiple_whitespace_split(self):
        assert split_words("Hello world foo bar") == ["Hello", "world", "foo", "bar"]
    
    def test_single_word_no_whitespace(self):
        result = split_words("Hello")
        assert isinstance(result, int)
    
    def test_whitespace_with_multiple_spaces(self):
        assert split_words("Hello  world") == ["Hello", "world"]
    
    def test_whitespace_at_start_and_end(self):
        result = split_words(" Hello world ")
        assert "Hello" in result and "world" in result


class TestSplitWordsComma:
    def test_simple_comma_split(self):
        assert split_words("Hello,world!") == ["Hello", "world!"]
    
    def test_multiple_comma_split(self):
        assert split_words("apple,banana,cherry") == ["apple", "banana", "cherry"]
    
    def test_comma_with_spaces_around(self):
        assert split_words("Hello, world") == ["Hello,", "world"]
    
    def test_single_comma(self):
        assert split_words("a,b") == ["a", "b"]
    
    def test_multiple_commas(self):
        assert split_words("a,b,c,d") == ["a", "b", "c", "d"]


class TestSplitWordsOddEvenLetters:
    def test_abcdef_returns_3(self):
        assert split_words("abcdef") == 3
    
    def test_single_even_letter(self):
        assert split_words("a") == 0
    
    def test_single_odd_letter(self):
        assert split_words("b") == 1
    
    def test_all_even_letters(self):
        assert split_words("ace") == 0
    
    def test_all_odd_letters(self):
        assert split_words("bdf") == 3
    
    def test_mixed_case_only_lowercase_counted(self):
        assert split_words("AaBbCc") == 1
    
    def test_with_numbers_and_special_chars(self):
        assert split_words("a1b2c3") == 1
    
    def test_empty_string(self):
        assert split_words("") == 0
    
    def test_no_lowercase_letters(self):
        assert split_words("ABC123") == 0
    
    def test_alphabet_positions(self):
        assert split_words("abcdef") == 3
    
    def test_only_uppercase(self):
        assert split_words("ABCDEF") == 0
    
    def test_special_characters_only(self):
        assert split_words("!@#$%^") == 0


class TestSplitWordsPriority:
    def test_whitespace_priority_over_comma(self):
        result = split_words("Hello world,test")
        assert result == ["Hello", "world,test"]
    
    def test_comma_priority_over_letters(self):
        result = split_words("a,b")
        assert result == ["a", "b"]


class TestSplitWordsEdgeCases:
    def test_only_spaces(self):
        result = split_words("   ")
        assert result == []
    
    def test_only_commas(self):
        result = split_words(",,,")
        assert result == []
    
    def test_tab_character_whitespace_for_split(self):
        result = split_words("Hello\tworld")
        assert isinstance(result, list) and "Hello" in result and "world" in result
    
    def test_newline_character(self):
        result = split_words("Hello\nworld")
        assert isinstance(result, list) and "Hello" in result and "world" in result
    
    def test_unicode_lowercase_letters(self):
        assert split_words("café") == 1


class TestSplitWordsReturnTypes:
    def test_whitespace_returns_list(self):
        result = split_words("Hello world")
        assert isinstance(result, list)
    
    def test_comma_returns_list(self):
        result = split_words("Hello,world")
        assert isinstance(result, list)
    
    def test_letters_returns_int(self):
        result = split_words("abcdef")
        assert isinstance(result, int)


class TestSplitWordsComprehensive:
    @pytest.mark.parametrize("input_str,expected", [
        ("Hello world!", ["Hello", "world!"]),
        ("Hello,world!", ["Hello", "world!"]),
        ("abcdef", 3),
        ("a", 0),
        ("b", 1),
        ("ace", 0),
        ("bdf", 3),
        ("", 0),
        ("ABC", 0),
        ("a,b,c", ["a", "b", "c"]),
        ("one two three", ["one", "two", "three"]),
    ])
    def test_various_inputs(self, input_str, expected):
        assert split_words(input_str) == expected