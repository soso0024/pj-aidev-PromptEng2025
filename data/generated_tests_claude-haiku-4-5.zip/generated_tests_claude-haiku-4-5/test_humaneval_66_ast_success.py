# Test cases for HumanEval/66
# Generated using Claude API


def digitSum(s):
    """Task
    Write a function that takes a string as input and returns the sum of the upper characters only'
    ASCII codes.

    Examples:
        digitSum("") => 0
        digitSum("abAB") => 131
        digitSum("abcCd") => 67
        digitSum("helloE") => 69
        digitSum("woArBld") => 131
        digitSum("aAaaaXa") => 153
    """

    if s == "": return 0
    return sum(ord(char) if char.isupper() else 0 for char in s)


# Generated test cases:
import pytest


def digitSum(s):
    if s == "": return 0
    return sum(ord(char) if char.isupper() else 0 for char in s)


class TestDigitSum:
    def test_empty_string(self):
        assert digitSum("") == 0
    
    def test_single_uppercase_letter(self):
        assert digitSum("A") == ord("A")
    
    def test_single_lowercase_letter(self):
        assert digitSum("a") == 0
    
    def test_multiple_uppercase_letters(self):
        assert digitSum("ABC") == ord("A") + ord("B") + ord("C")
    
    def test_multiple_lowercase_letters(self):
        assert digitSum("abc") == 0
    
    def test_mixed_case_letters(self):
        assert digitSum("AaBbCc") == ord("A") + ord("B") + ord("C")
    
    def test_uppercase_with_numbers(self):
        assert digitSum("A1B2C3") == ord("A") + ord("B") + ord("C")
    
    def test_lowercase_with_numbers(self):
        assert digitSum("a1b2c3") == 0
    
    def test_uppercase_with_special_characters(self):
        assert digitSum("A!B@C#") == ord("A") + ord("B") + ord("C")
    
    def test_lowercase_with_special_characters(self):
        assert digitSum("a!b@c#") == 0
    
    def test_mixed_with_special_characters(self):
        assert digitSum("A!a@B#b$C%c") == ord("A") + ord("B") + ord("C")
    
    def test_only_numbers(self):
        assert digitSum("123456") == 0
    
    def test_only_special_characters(self):
        assert digitSum("!@#$%^&*()") == 0
    
    def test_spaces_and_uppercase(self):
        assert digitSum("A B C") == ord("A") + ord("B") + ord("C")
    
    def test_spaces_and_lowercase(self):
        assert digitSum("a b c") == 0
    
    def test_all_uppercase_alphabet(self):
        expected = sum(ord(char) for char in "ABCDEFGHIJKLMNOPQRSTUVWXYZ")
        assert digitSum("ABCDEFGHIJKLMNOPQRSTUVWXYZ") == expected
    
    def test_all_lowercase_alphabet(self):
        assert digitSum("abcdefghijklmnopqrstuvwxyz") == 0
    
    def test_single_space(self):
        assert digitSum(" ") == 0
    
    def test_multiple_spaces(self):
        assert digitSum("   ") == 0
    
    def test_uppercase_z(self):
        assert digitSum("Z") == ord("Z")
    
    def test_uppercase_a(self):
        assert digitSum("A") == ord("A")
    
    def test_repeated_uppercase_letter(self):
        assert digitSum("AAA") == 3 * ord("A")
    
    def test_repeated_lowercase_letter(self):
        assert digitSum("aaa") == 0
    
    def test_complex_mixed_string(self):
        test_str = "Hello World"
        expected = ord("H") + ord("W")
        assert digitSum(test_str) == expected
    
    def test_string_with_tabs(self):
        assert digitSum("A\tB\tC") == ord("A") + ord("B") + ord("C")
    
    def test_string_with_newlines(self):
        assert digitSum("A\nB\nC") == ord("A") + ord("B") + ord("C")


@pytest.mark.parametrize("input_str,expected", [
    ("", 0),
    ("A", ord("A")),
    ("a", 0),
    ("ABC", ord("A") + ord("B") + ord("C")),
    ("abc", 0),
    ("AaBbCc", ord("A") + ord("B") + ord("C")),
    ("123", 0),
    ("!@#", 0),
    ("A1a2B3b4", ord("A") + ord("B")),
])
def test_digitSum_parametrized(input_str, expected):
    assert digitSum(input_str) == expected
