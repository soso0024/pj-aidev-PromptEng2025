# Test cases for HumanEval/121
# Generated using Claude API


def solution(lst):
    """Given a non-empty list of integers, return the sum of all of the odd elements that are in even positions.
    

    Examples
    solution([5, 8, 7, 1]) ==> 12
    solution([3, 3, 3, 3, 3]) ==> 9
    solution([30, 13, 24, 321]) ==>0
    """

    return sum([x for idx, x in enumerate(lst) if idx%2==0 and x%2==1])


# Generated test cases:
import pytest


def solution(lst):
    return sum([x for idx, x in enumerate(lst) if idx%2==0 and x%2==1])


class TestSolution:
    
    @pytest.mark.parametrize("input_list,expected", [
        ([5, 8, 7, 1], 12),
        ([3, 3, 3, 3, 3], 9),
        ([30, 13, 24, 321], 0),
    ])
    def test_provided_examples(self, input_list, expected):
        assert solution(input_list) == expected
    
    def test_single_odd_element_at_even_position(self):
        assert solution([5]) == 5
    
    def test_single_even_element_at_even_position(self):
        assert solution([4]) == 0
    
    def test_all_even_numbers(self):
        assert solution([2, 4, 6, 8]) == 0
    
    def test_all_odd_numbers(self):
        assert solution([1, 3, 5, 7]) == 1 + 5
    
    def test_odd_at_odd_positions_only(self):
        assert solution([2, 1, 4, 3, 6, 5]) == 0
    
    def test_odd_at_even_positions_only(self):
        assert solution([1, 2, 3, 4, 5, 6]) == 1 + 3 + 5
    
    def test_two_elements_odd_at_even_position(self):
        assert solution([7, 2]) == 7
    
    def test_two_elements_even_at_even_position(self):
        assert solution([4, 3]) == 0
    
    def test_negative_odd_numbers(self):
        assert solution([-5, 2, -3, 4]) == -5 + (-3)
    
    def test_negative_even_numbers(self):
        assert solution([-4, -2, -6, -8]) == 0
    
    def test_mixed_positive_negative_odd(self):
        assert solution([-1, 2, 3, 4, -5, 6]) == -1 + 3 + (-5)
    
    def test_zero_at_even_position(self):
        assert solution([0, 1, 2, 3]) == 0
    
    def test_large_odd_numbers(self):
        assert solution([999, 2, 1001, 4]) == 999 + 1001
    
    def test_large_list(self):
        lst = list(range(1, 101))
        result = solution(lst)
        expected = sum([x for i, x in enumerate(lst) if i % 2 == 0 and x % 2 == 1])
        assert result == expected
    
    def test_alternating_pattern(self):
        assert solution([1, 0, 1, 0, 1, 0]) == 1 + 1 + 1
    
    def test_single_zero(self):
        assert solution([0]) == 0
    
    def test_negative_one(self):
        assert solution([-1]) == -1
    
    def test_multiple_same_odd_values(self):
        assert solution([7, 0, 7, 0, 7, 0]) == 7 + 7 + 7
