# Test cases for HumanEval/46
# Generated using Claude API



def fib4(n: int):
    """The Fib4 number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fib4(0) -> 0
    fib4(1) -> 0
    fib4(2) -> 2
    fib4(3) -> 0
    fib4(n) -> fib4(n-1) + fib4(n-2) + fib4(n-3) + fib4(n-4).
    Please write a function to efficiently compute the n-th element of the fib4 number sequence.  Do not use recursion.
    >>> fib4(5)
    4
    >>> fib4(6)
    8
    >>> fib4(7)
    14
    """

    results = [0, 0, 2, 0]
    if n < 4:
        return results[n]

    for _ in range(4, n + 1):
        results.append(results[-1] + results[-2] + results[-3] + results[-4])
        results.pop(0)

    return results[-1]


# Generated test cases:
import pytest


class TestFib4:
    
    @pytest.mark.parametrize("n,expected", [
        (0, 0),
        (1, 0),
        (2, 2),
        (3, 0),
    ])
    def test_base_cases(self, n, expected):
        from test_humaneval_46_ast import fib4
        assert fib4(n) == expected
    
    @pytest.mark.parametrize("n,expected", [
        (4, 2),
        (5, 4),
        (6, 8),
        (7, 14),
        (8, 28),
        (9, 54),
        (10, 104),
    ])
    def test_normal_cases(self, n, expected):
        assert fib4(n) == expected
    
    def test_fib4_4(self):
        assert fib4(4) == 2
    
    def test_fib4_5(self):
        assert fib4(5) == 4
    
    def test_fib4_6(self):
        assert fib4(6) == 8
    
    def test_fib4_7(self):
        assert fib4(7) == 14
    
    def test_fib4_8(self):
        assert fib4(8) == 28
    
    def test_fib4_9(self):
        assert fib4(9) == 54
    
    def test_fib4_10(self):
        assert fib4(10) == 104
    
    def test_fib4_11(self):
        assert fib4(11) == 200
    
    def test_fib4_12(self):
        assert fib4(12) == 386
    
    def test_fib4_large_number(self):
        result = fib4(20)
        assert isinstance(result, int)
        assert result > 0
    
    def test_fib4_sequence_property(self):
        for n in range(4, 15):
            result = fib4(n)
            prev1 = fib4(n - 1)
            prev2 = fib4(n - 2)
            prev3 = fib4(n - 3)
            prev4 = fib4(n - 4)
            assert result == prev1 + prev2 + prev3 + prev4
    
    def test_fib4_monotonic_increase(self):
        for n in range(4, 20):
            assert fib4(n) >= fib4(n - 1)
    
    def test_fib4_returns_integer(self):
        for n in range(0, 15):
            result = fib4(n)
            assert isinstance(result, int)
    
    def test_fib4_non_negative(self):
        for n in range(0, 15):
            assert fib4(n) >= 0
    
    def test_fib4_specific_values(self):
        assert fib4(0) == 0
        assert fib4(1) == 0
        assert fib4(2) == 2
        assert fib4(3) == 0
        assert fib4(4) == 2
        assert fib4(5) == 4
        assert fib4(6) == 8
        assert fib4(7) == 14
        assert fib4(8) == 28
        assert fib4(9) == 54
        assert fib4(10) == 104
        assert fib4(15) == 2764
    
    def test_fib4_very_large_n(self):
        result = fib4(50)
        assert isinstance(result, int)
        assert result > 0
    
    def test_fib4_consistency(self):
        assert fib4(10) == fib4(10)
        assert fib4(5) == fib4(5)