# Test cases for HumanEval/71
# Generated using Claude API


def triangle_area(a, b, c):
    '''
    Given the lengths of the three sides of a triangle. Return the area of
    the triangle rounded to 2 decimal points if the three sides form a valid triangle. 
    Otherwise return -1
    Three sides make a valid triangle when the sum of any two sides is greater 
    than the third side.
    Example:
    triangle_area(3, 4, 5) == 6.00
    triangle_area(1, 2, 10) == -1
    '''

    if a + b <= c or a + c <= b or b + c <= a:
        return -1 
    s = (a + b + c)/2    
    area = (s * (s - a) * (s - b) * (s - c)) ** 0.5
    area = round(area, 2)
    return area


# Generated test cases:
import pytest


def triangle_area(a, b, c):
    '''
    Given the lengths of the three sides of a triangle. Return the area of
    the triangle rounded to 2 decimal points if the three sides form a valid triangle. 
    Otherwise return -1
    Three sides make a valid triangle when the sum of any two sides is greater 
    than the third side.
    Example:
    triangle_area(3, 4, 5) == 6.00
    triangle_area(1, 2, 10) == -1
    '''

    if a + b <= c or a + c <= b or b + c <= a:
        return -1 
    s = (a + b + c)/2    
    area = (s * (s - a) * (s - b) * (s - c)) ** 0.5
    area = round(area, 2)
    return area


class TestTriangleArea:
    
    @pytest.mark.parametrize("a,b,c,expected", [
        (3, 4, 5, 6.0),
        (5, 5, 5, pytest.approx(4.33, abs=0.01)),
        (6, 8, 10, 24.0),
        (1, 1, 1, pytest.approx(0.43, abs=0.01)),
        (7, 8, 9, pytest.approx(26.83, abs=0.01)),
        (10, 10, 10, pytest.approx(43.3, abs=0.01)),
        (13, 14, 15, pytest.approx(84.0, abs=0.01)),
    ])
    def test_valid_triangles(self, a, b, c, expected):
        assert triangle_area(a, b, c) == expected
    
    @pytest.mark.parametrize("a,b,c", [
        (1, 2, 10),
        (1, 1, 2),
        (1, 1, 3),
        (1, 2, 3),
        (2, 3, 5),
        (1, 2, 4),
        (0, 1, 1),
        (5, 2, 2),
    ])
    def test_invalid_triangles(self, a, b, c):
        assert triangle_area(a, b, c) == -1
    
    def test_right_triangle_3_4_5(self):
        assert triangle_area(3, 4, 5) == 6.0
    
    def test_right_triangle_5_12_13(self):
        assert triangle_area(5, 12, 13) == 30.0
    
    def test_equilateral_triangle(self):
        result = triangle_area(2, 2, 2)
        assert result == pytest.approx(1.73, abs=0.01)
    
    def test_isosceles_triangle(self):
        result = triangle_area(5, 5, 6)
        assert result == pytest.approx(12.0, abs=0.01)
    
    def test_very_small_triangle(self):
        result = triangle_area(0.1, 0.1, 0.1)
        assert result >= 0
    
    def test_large_triangle(self):
        result = triangle_area(100, 100, 100)
        assert result > 0
    
    def test_degenerate_triangle_sum_equals_third(self):
        assert triangle_area(1, 2, 3) == -1
    
    def test_degenerate_triangle_one_side_too_long(self):
        assert triangle_area(1, 1, 2) == -1
    
    def test_invalid_triangle_first_condition(self):
        assert triangle_area(1, 2, 10) == -1
    
    def test_invalid_triangle_second_condition(self):
        assert triangle_area(10, 1, 2) == -1
    
    def test_invalid_triangle_third_condition(self):
        assert triangle_area(2, 10, 1) == -1
    
    def test_rounding_to_two_decimals(self):
        result = triangle_area(3, 4, 5)
        assert isinstance(result, float)
        assert len(str(result).split('.')[-1]) <= 2
    
    def test_float_sides(self):
        result = triangle_area(3.5, 4.5, 5.5)
        assert result > 0
    
    def test_very_close_to_degenerate(self):
        result = triangle_area(1, 2, 2.99)
        assert result > 0
    
    def test_scalene_triangle(self):
        result = triangle_area(7, 8, 9)
        assert result == pytest.approx(26.83, abs=0.01)
    
    def test_return_type_valid(self):
        result = triangle_area(3, 4, 5)
        assert isinstance(result, float)
    
    def test_return_type_invalid(self):
        result = triangle_area(1, 2, 10)
        assert isinstance(result, int)
        assert result == -1