# Test cases for HumanEval/120
# Generated using Claude API


def maximum(arr, k):
    """
    Given an array arr of integers and a positive integer k, return a sorted list 
    of length k with the maximum k numbers in arr.

    Example 1:

        Input: arr = [-3, -4, 5], k = 3
        Output: [-4, -3, 5]

    Example 2:

        Input: arr = [4, -4, 4], k = 2
        Output: [4, 4]

    Example 3:

        Input: arr = [-3, 2, 1, 2, -1, -2, 1], k = 1
        Output: [2]

    Note:
        1. The length of the array will be in the range of [1, 1000].
        2. The elements in the array will be in the range of [-1000, 1000].
        3. 0 <= k <= len(arr)
    """

    if k == 0:
        return []
    arr.sort()
    ans = arr[-k:]
    return ans


# Generated test cases:
import pytest


def maximum(arr, k):
    """
    Given an array arr of integers and a positive integer k, return a sorted list 
    of length k with the maximum k numbers in arr.

    Example 1:

        Input: arr = [-3, -4, 5], k = 3
        Output: [-4, -3, 5]

    Example 2:

        Input: arr = [4, -4, 4], k = 2
        Output: [4, 4]

    Example 3:

        Input: arr = [-3, 2, 1, 2, -1, -2, 1], k = 1
        Output: [2]

    Note:
        1. The length of the array will be in the range of [1, 1000].
        2. The elements in the array will be in the range of [-1000, 1000].
        3. 0 <= k <= len(arr)
    """

    if k == 0:
        return []
    arr.sort()
    ans = arr[-k:]
    return ans


class TestMaximum:
    
    def test_example_1(self):
        assert maximum([-3, -4, 5], 3) == [-4, -3, 5]
    
    def test_example_2(self):
        assert maximum([4, -4, 4], 2) == [4, 4]
    
    def test_example_3(self):
        assert maximum([-3, 2, 1, 2, -1, -2, 1], 1) == [2]
    
    def test_k_equals_zero(self):
        assert maximum([1, 2, 3], 0) == []
    
    def test_k_equals_array_length(self):
        assert maximum([3, 1, 2], 3) == [1, 2, 3]
    
    def test_single_element_array_k_one(self):
        assert maximum([5], 1) == [5]
    
    def test_single_element_array_k_zero(self):
        assert maximum([5], 0) == []
    
    def test_all_negative_numbers(self):
        assert maximum([-5, -2, -8, -1], 2) == [-2, -1]
    
    def test_all_positive_numbers(self):
        assert maximum([1, 2, 3, 4, 5], 3) == [3, 4, 5]
    
    def test_mixed_positive_negative(self):
        assert maximum([-10, 5, -3, 8, 0], 3) == [0, 5, 8]
    
    def test_duplicate_values(self):
        assert maximum([1, 1, 1, 1], 2) == [1, 1]
    
    def test_duplicate_max_values(self):
        assert maximum([5, 5, 5, 1, 2], 3) == [5, 5, 5]
    
    def test_large_k_value(self):
        assert maximum([1, 2, 3, 4, 5], 5) == [1, 2, 3, 4, 5]
    
    def test_negative_and_zero(self):
        assert maximum([-5, 0, -3], 2) == [-3, 0]
    
    def test_unsorted_array(self):
        assert maximum([9, 3, 7, 1, 5], 3) == [5, 7, 9]
    
    def test_array_with_zeros(self):
        assert maximum([0, 0, 0, 1], 2) == [0, 1]
    
    def test_k_one_with_mixed_values(self):
        assert maximum([-100, 50, -50, 100], 1) == [100]
    
    def test_large_negative_numbers(self):
        assert maximum([-1000, -999, -500], 2) == [-999, -500]
    
    def test_large_positive_numbers(self):
        assert maximum([1000, 999, 500], 2) == [999, 1000]
    
    def test_two_elements_k_one(self):
        assert maximum([10, 20], 1) == [20]
    
    def test_two_elements_k_two(self):
        assert maximum([10, 20], 2) == [10, 20]
    
    def test_result_is_sorted(self):
        result = maximum([5, 2, 8, 1, 9], 4)
        assert result == sorted(result)
    
    def test_result_length_equals_k(self):
        result = maximum([1, 2, 3, 4, 5], 3)
        assert len(result) == 3
    
    def test_array_with_repeated_elements(self):
        assert maximum([3, 3, 3, 2, 2, 1], 4) == [2, 3, 3, 3]


@pytest.mark.parametrize("arr,k,expected", [
    ([-3, -4, 5], 3, [-4, -3, 5]),
    ([4, -4, 4], 2, [4, 4]),
    ([-3, 2, 1, 2, -1, -2, 1], 1, [2]),
    ([1, 2, 3], 0, []),
    ([5], 1, [5]),
    ([-5, -2, -8, -1], 2, [-2, -1]),
    ([1, 2, 3, 4, 5], 3, [3, 4, 5]),
    ([-10, 5, -3, 8, 0], 3, [0, 5, 8]),
])
def test_maximum_parametrized(arr, k, expected):
    assert maximum(arr, k) == expected