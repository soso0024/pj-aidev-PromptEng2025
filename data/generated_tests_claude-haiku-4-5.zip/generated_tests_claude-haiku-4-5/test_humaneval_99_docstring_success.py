# Test cases for HumanEval/99
# Generated using Claude API


def closest_integer(value):
    '''
    Create a function that takes a value (string) representing a number
    and returns the closest integer to it. If the number is equidistant
    from two integers, round it away from zero.

    Examples
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15

    Note:
    Rounding away from zero means that if the given number is equidistant
    from two integers, the one you should return is the one that is the
    farthest from zero. For example closest_integer("14.5") should
    return 15 and closest_integer("-14.5") should return -15.
    '''

    from math import floor, ceil

    if value.count('.') == 1:
        # remove trailing zeros
        while (value[-1] == '0'):
            value = value[:-1]

    num = float(value)
    if value[-2:] == '.5':
        if num > 0:
            res = ceil(num)
        else:
            res = floor(num)
    elif len(value) > 0:
        res = int(round(num))
    else:
        res = 0

    return res



# Generated test cases:
import pytest
from math import floor, ceil


def closest_integer(value):

    if value.count('.') == 1:
        # remove trailing zeros
        while (value[-1] == '0'):
            value = value[:-1]

    num = float(value)
    if value[-2:] == '.5':
        if num > 0:
            res = ceil(num)
        else:
            res = floor(num)
    elif len(value) > 0:
        res = int(round(num))
    else:
        res = 0

    return res


class TestClosestInteger:
    
    @pytest.mark.parametrize("input_value,expected", [
        ("10", 10),
        ("15.3", 15),
        ("0", 0),
        ("1", 1),
        ("-1", -1),
    ])
    def test_basic_cases(self, input_value, expected):
        assert closest_integer(input_value) == expected
    
    @pytest.mark.parametrize("input_value,expected", [
        ("14.5", 15),
        ("-14.5", -15),
        ("0.5", 1),
        ("-0.5", -1),
        ("2.5", 3),
        ("-2.5", -3),
    ])
    def test_equidistant_cases_round_away_from_zero(self, input_value, expected):
        assert closest_integer(input_value) == expected
    
    @pytest.mark.parametrize("input_value,expected", [
        ("15.1", 15),
        ("15.2", 15),
        ("15.3", 15),
        ("15.4", 15),
        ("15.6", 16),
        ("15.7", 16),
        ("15.8", 16),
        ("15.9", 16),
    ])
    def test_rounding_positive_decimals(self, input_value, expected):
        assert closest_integer(input_value) == expected
    
    @pytest.mark.parametrize("input_value,expected", [
        ("-15.1", -15),
        ("-15.2", -15),
        ("-15.3", -15),
        ("-15.4", -15),
        ("-15.6", -16),
        ("-15.7", -16),
        ("-15.8", -16),
        ("-15.9", -16),
    ])
    def test_rounding_negative_decimals(self, input_value, expected):
        assert closest_integer(input_value) == expected
    
    @pytest.mark.parametrize("input_value,expected", [
        ("10.0", 10),
        ("15.00", 15),
        ("20.000", 20),
        ("-5.0", -5),
        ("-10.00", -10),
    ])
    def test_trailing_zeros(self, input_value, expected):
        assert closest_integer(input_value) == expected
    
    @pytest.mark.parametrize("input_value,expected", [
        ("0.1", 0),
        ("0.4", 0),
        ("0.6", 1),
        ("0.9", 1),
        ("-0.1", 0),
        ("-0.4", 0),
        ("-0.6", -1),
        ("-0.9", -1),
    ])
    def test_small_decimals(self, input_value, expected):
        assert closest_integer(input_value) == expected
    
    @pytest.mark.parametrize("input_value,expected", [
        ("100", 100),
        ("1000", 1000),
        ("-100", -100),
        ("-1000", -1000),
    ])
    def test_large_integers(self, input_value, expected):
        assert closest_integer(input_value) == expected
    
    @pytest.mark.parametrize("input_value,expected", [
        ("100.5", 101),
        ("1000.5", 1001),
        ("-100.5", -101),
        ("-1000.5", -1001),
    ])
    def test_large_numbers_with_half(self, input_value, expected):
        assert closest_integer(input_value) == expected
    
    @pytest.mark.parametrize("input_value,expected", [
        ("3.5", 4),
        ("4.5", 5),
        ("5.5", 6),
        ("-3.5", -4),
        ("-4.5", -5),
        ("-5.5", -6),
    ])
    def test_consecutive_half_values(self, input_value, expected):
        assert closest_integer(input_value) == expected
    
    def test_zero_string(self):
        assert closest_integer("0") == 0
    
    def test_zero_with_decimal(self):
        assert closest_integer("0.0") == 0
    
    def test_very_small_positive_decimal(self):
        assert closest_integer("0.01") == 0
    
    def test_very_small_negative_decimal(self):
        assert closest_integer("-0.01") == 0
