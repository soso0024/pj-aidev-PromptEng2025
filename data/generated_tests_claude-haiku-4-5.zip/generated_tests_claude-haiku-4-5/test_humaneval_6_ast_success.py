# Test cases for HumanEval/6
# Generated using Claude API

from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """

    def parse_paren_group(s):
        depth = 0
        max_depth = 0
        for c in s:
            if c == '(':
                depth += 1
                max_depth = max(depth, max_depth)
            else:
                depth -= 1

        return max_depth

    return [parse_paren_group(x) for x in paren_string.split(' ') if x]


# Generated test cases:
import pytest
from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    def parse_paren_group(s):
        depth = 0
        max_depth = 0
        for c in s:
            if c == '(':
                depth += 1
                max_depth = max(depth, max_depth)
            else:
                depth -= 1

        return max_depth

    return [parse_paren_group(x) for x in paren_string.split(' ') if x]


class TestParseNestedParens:
    
    def test_single_group_single_paren(self):
        result = parse_nested_parens("()")
        assert result == [1]
    
    def test_single_group_nested_parens(self):
        result = parse_nested_parens("(())")
        assert result == [2]
    
    def test_single_group_deeply_nested(self):
        result = parse_nested_parens("((()))")
        assert result == [3]
    
    def test_multiple_groups_single_depth(self):
        result = parse_nested_parens("() () ()")
        assert result == [1, 1, 1]
    
    def test_multiple_groups_varying_depth(self):
        result = parse_nested_parens("() (()) ((()))")
        assert result == [1, 2, 3]
    
    def test_multiple_groups_mixed_depth(self):
        result = parse_nested_parens("(()) () (()())")
        assert result == [2, 1, 2]
    
    def test_empty_string(self):
        result = parse_nested_parens("")
        assert result == []
    
    def test_only_spaces(self):
        result = parse_nested_parens("   ")
        assert result == []
    
    def test_single_open_paren(self):
        result = parse_nested_parens("(")
        assert result == [1]
    
    def test_single_close_paren(self):
        result = parse_nested_parens(")")
        assert result == [0]
    
    def test_multiple_spaces_between_groups(self):
        result = parse_nested_parens("()  ()   ()")
        assert result == [1, 1, 1]
    
    def test_leading_spaces(self):
        result = parse_nested_parens("  () ()")
        assert result == [1, 1]
    
    def test_trailing_spaces(self):
        result = parse_nested_parens("() ()  ")
        assert result == [1, 1]
    
    def test_complex_nested_pattern(self):
        result = parse_nested_parens("(()()) ((())) ()()")
        assert result == [2, 3, 1]
    
    def test_unbalanced_parens_more_open(self):
        result = parse_nested_parens("((((")
        assert result == [4]
    
    def test_unbalanced_parens_more_close(self):
        result = parse_nested_parens("))))")
        assert result == [0]
    
    def test_mixed_unbalanced(self):
        result = parse_nested_parens("(() ))))")
        assert result == [2, 0]
    
    def test_single_group_with_spaces_around(self):
        result = parse_nested_parens(" (()) ")
        assert result == [2]
    
    def test_alternating_open_close(self):
        result = parse_nested_parens("()()()")
        assert result == [1]
    
    def test_nested_then_flat(self):
        result = parse_nested_parens("(()) ()()")
        assert result == [2, 1]
    
    def test_flat_then_nested(self):
        result = parse_nested_parens("()() (())")
        assert result == [1, 2]
    
    def test_very_deep_nesting(self):
        result = parse_nested_parens("(" * 10 + ")" * 10)
        assert result == [10]
    
    def test_multiple_very_deep_groups(self):
        result = parse_nested_parens("(" * 5 + ")" * 5 + " " + "(" * 7 + ")" * 7)
        assert result == [5, 7]
    
    def test_single_space_separated_groups(self):
        result = parse_nested_parens("( ) ( )")
        assert result == [1, 0, 1, 0]
    
    @pytest.mark.parametrize("input_str,expected", [
        ("()", [1]),
        ("(())", [2]),
        ("() ()", [1, 1]),
        ("(()) (()())", [2, 2]),
        ("((()))", [3]),
        ("", []),
        ("(", [1]),
        (")", [0]),
    ])
    def test_parametrized_cases(self, input_str, expected):
        result = parse_nested_parens(input_str)
        assert result == expected