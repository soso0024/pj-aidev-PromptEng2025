# Test cases for HumanEval/7
# Generated using Claude API

from typing import List


def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """ Filter an input list of strings only for ones that contain given substring
    >>> filter_by_substring([], 'a')
    []
    >>> filter_by_substring(['abc', 'bacd', 'cde', 'array'], 'a')
    ['abc', 'bacd', 'array']
    """

    return [x for x in strings if substring in x]


# Generated test cases:
import pytest
from typing import List


def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    return [x for x in strings if substring in x]


class TestFilterBySubstring:
    def test_empty_list(self):
        result = filter_by_substring([], "test")
        assert result == []

    def test_empty_substring(self):
        result = filter_by_substring(["hello", "world"], "")
        assert result == ["hello", "world"]

    def test_no_matches(self):
        result = filter_by_substring(["apple", "banana", "cherry"], "xyz")
        assert result == []

    def test_single_match(self):
        result = filter_by_substring(["apple", "banana", "cherry"], "app")
        assert result == ["apple"]

    def test_multiple_matches(self):
        result = filter_by_substring(["apple", "application", "apply"], "app")
        assert result == ["apple", "application", "apply"]

    def test_case_sensitive(self):
        result = filter_by_substring(["Apple", "apple", "APPLE"], "app")
        assert result == ["apple"]

    def test_substring_at_start(self):
        result = filter_by_substring(["hello", "world"], "hel")
        assert result == ["hello"]

    def test_substring_at_end(self):
        result = filter_by_substring(["hello", "world"], "llo")
        assert result == ["hello"]

    def test_substring_in_middle(self):
        result = filter_by_substring(["hello", "world"], "ell")
        assert result == ["hello"]

    def test_exact_match(self):
        result = filter_by_substring(["hello", "world"], "hello")
        assert result == ["hello"]

    def test_substring_longer_than_strings(self):
        result = filter_by_substring(["hi", "bye"], "hello")
        assert result == []

    def test_single_character_substring(self):
        result = filter_by_substring(["apple", "banana", "cherry"], "a")
        assert result == ["apple", "banana"]

    def test_single_string_match(self):
        result = filter_by_substring(["test"], "test")
        assert result == ["test"]

    def test_single_string_no_match(self):
        result = filter_by_substring(["test"], "xyz")
        assert result == []

    def test_special_characters_in_substring(self):
        result = filter_by_substring(["hello-world", "hello_world", "helloworld"], "-")
        assert result == ["hello-world"]

    def test_special_characters_in_strings(self):
        result = filter_by_substring(["test@123", "test#456", "test$789"], "@")
        assert result == ["test@123"]

    def test_whitespace_in_substring(self):
        result = filter_by_substring(["hello world", "helloworld", "hello  world"], " ")
        assert result == ["hello world", "hello  world"]

    def test_numbers_in_strings(self):
        result = filter_by_substring(["test123", "test456", "abc123"], "123")
        assert result == ["test123", "abc123"]

    def test_unicode_characters(self):
        result = filter_by_substring(["café", "naïve", "résumé"], "é")
        assert result == ["café", "résumé"]

    def test_empty_strings_in_list(self):
        result = filter_by_substring(["", "hello", "", "world"], "")
        assert result == ["", "hello", "", "world"]

    def test_empty_strings_with_nonempty_substring(self):
        result = filter_by_substring(["", "hello", "", "world"], "h")
        assert result == ["hello"]

    def test_repeated_substring(self):
        result = filter_by_substring(["aaa", "aa", "a", "aaaa"], "aa")
        assert result == ["aaa", "aa", "aaaa"]

    def test_overlapping_matches(self):
        result = filter_by_substring(["aaaa", "aaa", "aa"], "aa")
        assert result == ["aaaa", "aaa", "aa"]

    def test_large_list(self):
        strings = [f"string{i}" for i in range(1000)]
        result = filter_by_substring(strings, "string5")
        assert "string5" in result
        assert len(result) == 111

    def test_preserve_order(self):
        strings = ["zebra", "apple", "banana", "cherry"]
        result = filter_by_substring(strings, "a")
        assert result == ["zebra", "apple", "banana"]

    def test_duplicate_strings(self):
        result = filter_by_substring(["hello", "hello", "world", "hello"], "hello")
        assert result == ["hello", "hello", "hello"]

    @pytest.mark.parametrize("strings,substring,expected", [
        (["hello", "world"], "o", ["hello", "world"]),
        (["test"], "test", ["test"]),
        (["a", "b", "c"], "d", []),
        (["abc", "def", "ghi"], "ef", ["def"]),
        (["123", "456", "789"], "45", ["456"]),
    ])
    def test_parametrized_cases(self, strings, substring, expected):
        result = filter_by_substring(strings, substring)
        assert result == expected

    def test_return_type_is_list(self):
        result = filter_by_substring(["hello"], "h")
        assert isinstance(result, list)

    def test_return_elements_are_strings(self):
        result = filter_by_substring(["hello", "world"], "o")
        assert all(isinstance(x, str) for x in result)

    def test_no_modification_of_original_list(self):
        original = ["hello", "world"]
        original_copy = original.copy()
        filter_by_substring(original, "o")
        assert original == original_copy

    def test_newline_in_substring(self):
        result = filter_by_substring(["hello\nworld", "helloworld"], "\n")
        assert result == ["hello\nworld"]

    def test_tab_in_substring(self):
        result = filter_by_substring(["hello\tworld", "helloworld"], "\t")
        assert result == ["hello\tworld"]