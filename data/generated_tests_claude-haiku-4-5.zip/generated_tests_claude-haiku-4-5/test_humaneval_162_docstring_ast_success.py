# Test cases for HumanEval/162
# Generated using Claude API


def string_to_md5(text):
    """
    Given a string 'text', return its md5 hash equivalent string.
    If 'text' is an empty string, return None.

    >>> string_to_md5('Hello world') == '3e25960a79dbc69b674cd4ec67a72c62'
    """

    import hashlib
    return hashlib.md5(text.encode('ascii')).hexdigest() if text else None


# Generated test cases:
import pytest
import hashlib


def string_to_md5(text):
    return hashlib.md5(text.encode('ascii')).hexdigest() if text else None


class TestStringToMd5:
    
    def test_hello_world(self):
        result = string_to_md5('Hello world')
        assert result == '3e25960a79dbc69b674cd4ec67a72c62'
    
    def test_empty_string(self):
        result = string_to_md5('')
        assert result is None
    
    def test_single_character(self):
        result = string_to_md5('a')
        expected = hashlib.md5('a'.encode('ascii')).hexdigest()
        assert result == expected
    
    def test_numbers(self):
        result = string_to_md5('12345')
        expected = hashlib.md5('12345'.encode('ascii')).hexdigest()
        assert result == expected
    
    def test_special_characters(self):
        result = string_to_md5('!@#$%^&*()')
        expected = hashlib.md5('!@#$%^&*()'.encode('ascii')).hexdigest()
        assert result == expected
    
    def test_spaces(self):
        result = string_to_md5('   ')
        expected = hashlib.md5('   '.encode('ascii')).hexdigest()
        assert result == expected
    
    def test_long_string(self):
        long_text = 'a' * 1000
        result = string_to_md5(long_text)
        expected = hashlib.md5(long_text.encode('ascii')).hexdigest()
        assert result == expected
    
    def test_mixed_case(self):
        result = string_to_md5('HeLLo WoRLd')
        expected = hashlib.md5('HeLLo WoRLd'.encode('ascii')).hexdigest()
        assert result == expected
    
    def test_newline_character(self):
        result = string_to_md5('hello\nworld')
        expected = hashlib.md5('hello\nworld'.encode('ascii')).hexdigest()
        assert result == expected
    
    def test_tab_character(self):
        result = string_to_md5('hello\tworld')
        expected = hashlib.md5('hello\tworld'.encode('ascii')).hexdigest()
        assert result == expected
    
    def test_result_is_string(self):
        result = string_to_md5('test')
        assert isinstance(result, str)
    
    def test_result_length(self):
        result = string_to_md5('test')
        assert len(result) == 32
    
    def test_result_is_hexadecimal(self):
        result = string_to_md5('test')
        try:
            int(result, 16)
            is_hex = True
        except ValueError:
            is_hex = False
        assert is_hex
    
    def test_empty_string_returns_none(self):
        result = string_to_md5('')
        assert result is None
        assert result is not False
        assert result is not 0
    
    def test_same_input_same_output(self):
        text = 'consistent'
        result1 = string_to_md5(text)
        result2 = string_to_md5(text)
        assert result1 == result2
    
    def test_different_inputs_different_outputs(self):
        result1 = string_to_md5('test1')
        result2 = string_to_md5('test2')
        assert result1 != result2
    
    @pytest.mark.parametrize("text,expected", [
        ('', None),
        ('a', '0cc175b9c0f1b6a831c399e269772661'),
        ('abc', '900150983cd24fb0d6963f7d28e17f72'),
        ('test', '098f6bcd4621d373cade4e832627b4f6'),
    ])
    def test_parametrized_cases(self, text, expected):
        result = string_to_md5(text)
        assert result == expected
