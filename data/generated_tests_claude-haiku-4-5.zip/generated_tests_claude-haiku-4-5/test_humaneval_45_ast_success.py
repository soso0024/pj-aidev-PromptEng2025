# Test cases for HumanEval/45
# Generated using Claude API



def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """

    return a * h / 2.0


# Generated test cases:
import pytest


def triangle_area(a, h):
    return a * h / 2.0


class TestTriangleArea:
    
    def test_basic_triangle(self):
        assert triangle_area(10, 5) == 25.0
    
    def test_unit_triangle(self):
        assert triangle_area(1, 1) == 0.5
    
    def test_zero_base(self):
        assert triangle_area(0, 5) == 0.0
    
    def test_zero_height(self):
        assert triangle_area(10, 0) == 0.0
    
    def test_both_zero(self):
        assert triangle_area(0, 0) == 0.0
    
    def test_float_values(self):
        assert triangle_area(3.5, 4.2) == pytest.approx(7.35)
    
    def test_large_values(self):
        assert triangle_area(1000, 2000) == 1000000.0
    
    def test_small_float_values(self):
        assert triangle_area(0.1, 0.2) == pytest.approx(0.01)
    
    def test_negative_base(self):
        assert triangle_area(-10, 5) == -25.0
    
    def test_negative_height(self):
        assert triangle_area(10, -5) == -25.0
    
    def test_both_negative(self):
        assert triangle_area(-10, -5) == 25.0
    
    def test_decimal_precision(self):
        result = triangle_area(7, 3)
        assert result == pytest.approx(10.5)
    
    def test_very_small_values(self):
        assert triangle_area(0.001, 0.001) == pytest.approx(0.0000005)
    
    def test_mixed_sign_values(self):
        assert triangle_area(-5, 8) == -20.0
    
    @pytest.mark.parametrize("a,h,expected", [
        (5, 4, 10.0),
        (10, 10, 50.0),
        (2, 3, 3.0),
        (100, 1, 50.0),
        (1, 100, 50.0),
        (0.5, 0.5, 0.125),
        (15, 8, 60.0),
    ])
    def test_parametrized_valid_inputs(self, a, h, expected):
        assert triangle_area(a, h) == pytest.approx(expected)
    
    @pytest.mark.parametrize("a,h", [
        (0, 0),
        (0, 10),
        (10, 0),
        (-5, -10),
    ])
    def test_parametrized_edge_cases(self, a, h):
        result = triangle_area(a, h)
        assert isinstance(result, float)
    
    def test_return_type_is_float(self):
        result = triangle_area(5, 4)
        assert isinstance(result, float)
    
    def test_commutative_property(self):
        assert triangle_area(5, 8) == triangle_area(8, 5)
    
    def test_scaling_property(self):
        base_area = triangle_area(5, 4)
        scaled_area = triangle_area(10, 4)
        assert scaled_area == pytest.approx(2 * base_area)
    
    def test_height_scaling_property(self):
        base_area = triangle_area(5, 4)
        scaled_area = triangle_area(5, 8)
        assert scaled_area == pytest.approx(2 * base_area)
