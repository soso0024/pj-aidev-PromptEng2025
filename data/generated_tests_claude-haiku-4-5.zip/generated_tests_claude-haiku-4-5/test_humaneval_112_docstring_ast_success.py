# Test cases for HumanEval/112
# Generated using Claude API


def reverse_delete(s,c):
    """Task
    We are given two strings s and c, you have to deleted all the characters in s that are equal to any character in c
    then check if the result string is palindrome.
    A string is called palindrome if it reads the same backward as forward.
    You should return a tuple containing the result string and True/False for the check.
    Example
    For s = "abcde", c = "ae", the result should be ('bcd',False)
    For s = "abcdef", c = "b"  the result should be ('acdef',False)
    For s = "abcdedcba", c = "ab", the result should be ('cdedc',True)
    """

    s = ''.join([char for char in s if char not in c])
    return (s,s[::-1] == s)


# Generated test cases:
import pytest


def reverse_delete(s, c):
    s = ''.join([char for char in s if char not in c])
    return (s, s[::-1] == s)


class TestReverseDelete:
    
    def test_example_1(self):
        result = reverse_delete("abcde", "ae")
        assert result == ('bcd', False)
    
    def test_example_2(self):
        result = reverse_delete("abcdef", "b")
        assert result == ('acdef', False)
    
    def test_example_3(self):
        result = reverse_delete("abcdedcba", "ab")
        assert result == ('cdedc', True)
    
    def test_empty_string(self):
        result = reverse_delete("", "a")
        assert result == ('', True)
    
    def test_empty_delete_chars(self):
        result = reverse_delete("abc", "")
        assert result == ('abc', False)
    
    def test_both_empty(self):
        result = reverse_delete("", "")
        assert result == ('', True)
    
    def test_delete_all_chars(self):
        result = reverse_delete("aaa", "a")
        assert result == ('', True)
    
    def test_single_char_palindrome(self):
        result = reverse_delete("a", "b")
        assert result == ('a', True)
    
    def test_single_char_deleted(self):
        result = reverse_delete("a", "a")
        assert result == ('', True)
    
    def test_palindrome_no_deletion(self):
        result = reverse_delete("racecar", "")
        assert result == ('racecar', True)
    
    def test_palindrome_with_deletion(self):
        result = reverse_delete("aabbaa", "b")
        assert result == ('aaaa', True)
    
    def test_non_palindrome_no_deletion(self):
        result = reverse_delete("abc", "")
        assert result == ('abc', False)
    
    def test_non_palindrome_with_deletion(self):
        result = reverse_delete("abcdef", "ace")
        assert result == ('bdf', False)
    
    def test_delete_multiple_chars(self):
        result = reverse_delete("aabbccdd", "bd")
        assert result == ('aacc', False)
    
    def test_case_sensitive(self):
        result = reverse_delete("AaBbCc", "a")
        assert result == ('ABbCc', False)
    
    def test_case_sensitive_palindrome(self):
        result = reverse_delete("AaBbAa", "a")
        assert result == ('ABbA', False)
    
    def test_special_characters(self):
        result = reverse_delete("a!b@c#", "!@#")
        assert result == ('abc', False)
    
    def test_special_characters_palindrome(self):
        result = reverse_delete("a!b!a", "!")
        assert result == ('aba', True)
    
    def test_spaces(self):
        result = reverse_delete("a b c", " ")
        assert result == ('abc', False)
    
    def test_numbers(self):
        result = reverse_delete("12321", "1")
        assert result == ('232', True)
    
    def test_long_string_palindrome(self):
        result = reverse_delete("abcdefedcba", "xyz")
        assert result == ('abcdefedcba', True)
    
    def test_long_string_non_palindrome(self):
        result = reverse_delete("abcdefghij", "")
        assert result == ('abcdefghij', False)
    
    def test_repeated_delete_chars(self):
        result = reverse_delete("aabbcc", "aabbcc")
        assert result == ('', True)
    
    def test_delete_chars_not_in_string(self):
        result = reverse_delete("abc", "xyz")
        assert result == ('abc', False)
    
    def test_mixed_case_and_numbers(self):
        result = reverse_delete("A1b2B1a", "12")
        assert result == ('AbBa', False)
    
    def test_unicode_characters(self):
        result = reverse_delete("café", "é")
        assert result == ('caf', False)
    
    def test_result_is_tuple(self):
        result = reverse_delete("test", "t")
        assert isinstance(result, tuple)
        assert len(result) == 2
    
    def test_result_first_element_is_string(self):
        result = reverse_delete("test", "t")
        assert isinstance(result[0], str)
    
    def test_result_second_element_is_bool(self):
        result = reverse_delete("test", "t")
        assert isinstance(result[1], bool)


@pytest.mark.parametrize("s,c,expected", [
    ("abcde", "ae", ('bcd', False)),
    ("abcdef", "b", ('acdef', False)),
    ("abcdedcba", "ab", ('cdedc', True)),
    ("", "a", ('', True)),
    ("abc", "", ('abc', False)),
    ("", "", ('', True)),
    ("aaa", "a", ('', True)),
    ("a", "b", ('a', True)),
    ("racecar", "", ('racecar', True)),
    ("aabbaa", "b", ('aaaa', True)),
    ("abc", "", ('abc', False)),
    ("abcdef", "ace", ('bdf', False)),
    ("aabbccdd", "bd", ('aacc', False)),
    ("12321", "1", ('232', True)),
    ("abcdefedcba", "xyz", ('abcdefedcba', True)),
])
def test_reverse_delete_parametrized(s, c, expected):
    assert reverse_delete(s, c) == expected