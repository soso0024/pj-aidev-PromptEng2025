# Test cases for HumanEval/34
# Generated using Claude API



def unique(l: list):
    """Return sorted unique elements in a list
    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """

    return sorted(list(set(l)))


# Generated test cases:
import pytest


class TestUnique:
    def unique(self, l: list):
        return sorted(list(set(l)))

    def test_empty_list(self):
        assert self.unique([]) == []

    def test_single_element(self):
        assert self.unique([1]) == [1]

    def test_no_duplicates(self):
        assert self.unique([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

    def test_with_duplicates(self):
        assert self.unique([1, 2, 2, 3, 3, 3]) == [1, 2, 3]

    def test_all_same_elements(self):
        assert self.unique([5, 5, 5, 5]) == [5]

    def test_unsorted_input(self):
        assert self.unique([3, 1, 4, 1, 5, 9, 2, 6]) == [1, 2, 3, 4, 5, 6, 9]

    def test_negative_numbers(self):
        assert self.unique([-1, -2, -1, 0, 1, 2]) == [-2, -1, 0, 1, 2]

    def test_mixed_positive_negative(self):
        assert self.unique([5, -5, 3, -3, 5, -5]) == [-5, -3, 3, 5]

    def test_strings(self):
        assert self.unique(['apple', 'banana', 'apple', 'cherry']) == ['apple', 'banana', 'cherry']

    def test_strings_case_sensitive(self):
        assert self.unique(['Apple', 'apple', 'APPLE']) == ['APPLE', 'Apple', 'apple']

    def test_floats(self):
        assert self.unique([1.5, 2.5, 1.5, 3.5]) == [1.5, 2.5, 3.5]

    def test_mixed_types_numbers(self):
        assert self.unique([1, 1.0, 2, 2.0]) == [1, 2]

    def test_large_list(self):
        large_list = list(range(1000)) + list(range(500))
        result = self.unique(large_list)
        assert result == list(range(1000))

    def test_preserves_sorted_order(self):
        assert self.unique([5, 3, 8, 3, 1, 5]) == [1, 3, 5, 8]

    def test_single_duplicate(self):
        assert self.unique([1, 1]) == [1]

    def test_alternating_duplicates(self):
        assert self.unique([1, 2, 1, 2, 1, 2]) == [1, 2]

    def test_zero_in_list(self):
        assert self.unique([0, 1, 0, 2, 0]) == [0, 1, 2]

    def test_negative_zero_and_positive_zero(self):
        assert self.unique([0, -0, 1]) == [0, 1]

    def test_empty_strings(self):
        assert self.unique(['', 'a', '', 'b']) == ['', 'a', 'b']

    def test_whitespace_strings(self):
        assert self.unique([' ', '  ', ' ']) == [' ', '  ']

    def test_boolean_values(self):
        result = self.unique([True, False, True, False])
        assert result == [False, True]

    def test_parametrized_basic(self):
        test_cases = [
            ([1, 2, 3], [1, 2, 3]),
            ([3, 2, 1], [1, 2, 3]),
            ([1, 1, 1], [1]),
            ([], []),
            ([5], [5]),
        ]
        for input_list, expected in test_cases:
            assert self.unique(input_list) == expected

    def test_parametrized_negative(self):
        test_cases = [
            ([-5, -1, 0, 1, 5], [-5, -1, 0, 1, 5]),
            ([5, -5, 0, -5, 5], [-5, 0, 5]),
            ([-1, -1, -1], [-1]),
        ]
        for input_list, expected in test_cases:
            assert self.unique(input_list) == expected

    def test_parametrized_strings(self):
        test_cases = [
            (['z', 'a', 'z'], ['a', 'z']),
            (['apple', 'Apple'], ['Apple', 'apple']),
            ([''], ['']),
        ]
        for input_list, expected in test_cases:
            assert self.unique(input_list) == expected