# Test cases for HumanEval/16
# Generated using Claude API



def count_distinct_characters(string: str) -> int:
    """ Given a string, find out how many distinct characters (regardless of case) does it consist of
    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """

    return len(set(string.lower()))


# Generated test cases:
import pytest


def count_distinct_characters(string: str) -> int:
    return len(set(string.lower()))


class TestCountDistinctCharacters:
    
    def test_empty_string(self):
        assert count_distinct_characters("") == 0
    
    def test_single_character(self):
        assert count_distinct_characters("a") == 1
    
    def test_all_same_character(self):
        assert count_distinct_characters("aaaa") == 1
    
    def test_all_different_characters(self):
        assert count_distinct_characters("abcd") == 4
    
    def test_case_insensitive_lowercase(self):
        assert count_distinct_characters("abc") == 3
    
    def test_case_insensitive_uppercase(self):
        assert count_distinct_characters("ABC") == 3
    
    def test_case_insensitive_mixed(self):
        assert count_distinct_characters("AaBbCc") == 3
    
    def test_with_spaces(self):
        assert count_distinct_characters("a b c") == 4
    
    def test_with_numbers(self):
        assert count_distinct_characters("a1b2c3") == 6
    
    def test_with_special_characters(self):
        assert count_distinct_characters("a!b@c#") == 6
    
    def test_with_punctuation(self):
        assert count_distinct_characters("hello, world!") == 10
    
    def test_repeated_characters_different_cases(self):
        assert count_distinct_characters("AaAaAa") == 1
    
    def test_long_string_with_repeats(self):
        assert count_distinct_characters("aabbccddee") == 5
    
    def test_alphabet_lowercase(self):
        assert count_distinct_characters("abcdefghijklmnopqrstuvwxyz") == 26
    
    def test_alphabet_uppercase(self):
        assert count_distinct_characters("ABCDEFGHIJKLMNOPQRSTUVWXYZ") == 26
    
    def test_alphabet_mixed_case(self):
        assert count_distinct_characters("AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz") == 26
    
    def test_digits_only(self):
        assert count_distinct_characters("0123456789") == 10
    
    def test_repeated_digits(self):
        assert count_distinct_characters("1111222233334444") == 4
    
    def test_whitespace_characters(self):
        assert count_distinct_characters("a\tb\nc") == 5
    
    def test_unicode_characters(self):
        assert count_distinct_characters("café") == 4
    
    def test_unicode_repeated(self):
        assert count_distinct_characters("ééé") == 1
    
    def test_mixed_unicode_and_ascii(self):
        assert count_distinct_characters("aéaé") == 2
    
    @pytest.mark.parametrize("input_str,expected", [
        ("", 0),
        ("a", 1),
        ("aa", 1),
        ("ab", 2),
        ("ABC", 3),
        ("AaBbCc", 3),
        ("hello", 4),
        ("HELLO", 4),
        ("HeLLo", 4),
        ("123", 3),
        ("111", 1),
        ("a1b2c3", 6),
        ("!@#$%", 5),
        ("the quick brown fox", 16),
        ("THE QUICK BROWN FOX", 16),
    ])
    def test_parametrized_cases(self, input_str, expected):
        assert count_distinct_characters(input_str) == expected