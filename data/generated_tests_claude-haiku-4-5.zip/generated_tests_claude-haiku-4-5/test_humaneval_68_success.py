# Test cases for HumanEval/68
# Generated using Claude API


def pluck(arr):
    """
    "Given an array representing a branch of a tree that has non-negative integer nodes
    your task is to pluck one of the nodes and return it.
    The plucked node should be the node with the smallest even value.
    If multiple nodes with the same smallest even value are found return the node that has smallest index.

    The plucked node should be returned in a list, [ smalest_value, its index ],
    If there are no even values or the given array is empty, return [].

    Example 1:
        Input: [4,2,3]
        Output: [2, 1]
        Explanation: 2 has the smallest even value, and 2 has the smallest index.

    Example 2:
        Input: [1,2,3]
        Output: [2, 1]
        Explanation: 2 has the smallest even value, and 2 has the smallest index. 

    Example 3:
        Input: []
        Output: []
    
    Example 4:
        Input: [5, 0, 3, 0, 4, 2]
        Output: [0, 1]
        Explanation: 0 is the smallest value, but  there are two zeros,
                     so we will choose the first zero, which has the smallest index.

    Constraints:
        * 1 <= nodes.length <= 10000
        * 0 <= node.value
    """

    if(len(arr) == 0): return []
    evens = list(filter(lambda x: x%2 == 0, arr))
    if(evens == []): return []
    return [min(evens), arr.index(min(evens))]


# Generated test cases:
import pytest


def pluck(arr):
    if(len(arr) == 0): return []
    evens = list(filter(lambda x: x%2 == 0, arr))
    if(evens == []): return []
    return [min(evens), arr.index(min(evens))]


class TestPluck:
    def test_empty_array(self):
        assert pluck([]) == []

    def test_no_even_numbers(self):
        assert pluck([1, 3, 5, 7]) == []

    def test_single_even_number(self):
        assert pluck([2]) == [2, 0]

    def test_single_odd_number(self):
        assert pluck([1]) == []

    def test_all_even_numbers(self):
        assert pluck([2, 4, 6, 8]) == [2, 0]

    def test_mixed_numbers_min_at_start(self):
        assert pluck([2, 1, 3, 5]) == [2, 0]

    def test_mixed_numbers_min_at_end(self):
        assert pluck([1, 3, 5, 2]) == [2, 3]

    def test_mixed_numbers_min_in_middle(self):
        assert pluck([1, 4, 3, 2, 5]) == [2, 3]

    def test_duplicate_even_numbers(self):
        assert pluck([4, 2, 4, 6]) == [2, 1]

    def test_duplicate_even_numbers_same_value(self):
        assert pluck([4, 4, 4]) == [4, 0]

    def test_negative_even_numbers(self):
        assert pluck([-2, 1, 3, 5]) == [-2, 0]

    def test_negative_and_positive_evens(self):
        assert pluck([1, -4, 3, 2, 5]) == [-4, 1]

    def test_zero_as_even(self):
        assert pluck([1, 0, 3, 5]) == [0, 1]

    def test_zero_with_other_evens(self):
        assert pluck([1, 4, 0, 3]) == [0, 2]

    def test_large_numbers(self):
        assert pluck([1000000, 999999, 500000]) == [500000, 2]

    def test_negative_large_numbers(self):
        assert pluck([-1000000, -500000, 1]) == [-1000000, 0]

    @pytest.mark.parametrize("arr,expected", [
        ([2, 4, 6], [2, 0]),
        ([1, 2, 3, 4], [2, 1]),
        ([10, 5, 8, 3], [8, 2]),
        ([7, 9, 11], []),
        ([0], [0, 0]),
        ([-2, -4, -6], [-6, 2]),
        ([1, 1, 1, 2], [2, 3]),
    ])
    def test_parametrized_cases(self, arr, expected):
        assert pluck(arr) == expected

    def test_first_occurrence_of_min(self):
        result = pluck([1, 4, 3, 4, 2])
        assert result == [2, 4]

    def test_two_elements_both_even(self):
        assert pluck([4, 2]) == [2, 1]

    def test_two_elements_one_even(self):
        assert pluck([1, 2]) == [2, 1]

    def test_alternating_odd_even(self):
        assert pluck([1, 2, 3, 4, 5, 6]) == [2, 1]
