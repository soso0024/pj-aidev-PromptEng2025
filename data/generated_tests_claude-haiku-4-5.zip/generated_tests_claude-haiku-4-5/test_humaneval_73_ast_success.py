# Test cases for HumanEval/73
# Generated using Claude API


def smallest_change(arr):
    """
    Given an array arr of integers, find the minimum number of elements that
    need to be changed to make the array palindromic. A palindromic array is an array that
    is read the same backwards and forwards. In one change, you can change one element to any other element.

    For example:
    smallest_change([1,2,3,5,4,7,9,6]) == 4
    smallest_change([1, 2, 3, 4, 3, 2, 2]) == 1
    smallest_change([1, 2, 3, 2, 1]) == 0
    """

    ans = 0
    for i in range(len(arr) // 2):
        if arr[i] != arr[len(arr) - i - 1]:
            ans += 1
    return ans


# Generated test cases:
import pytest


def smallest_change(arr):
    ans = 0
    for i in range(len(arr) // 2):
        if arr[i] != arr[len(arr) - i - 1]:
            ans += 1
    return ans


@pytest.mark.parametrize("arr,expected", [
    ([], 0),
    ([1], 0),
    ([1, 1], 0),
    ([1, 2], 1),
    ([1, 2, 1], 0),
    ([1, 2, 3], 1),
    ([1, 2, 2, 1], 0),
    ([1, 2, 3, 4], 2),
    ([1, 2, 3, 2, 1], 0),
    ([1, 2, 3, 4, 5], 2),
    ([5, 4, 3, 2, 1], 2),
    ([1, 1, 1, 1, 1], 0),
    ([1, 2, 1, 2, 1], 0),
    ([1, 2, 3, 4, 5, 6], 3),
    ([1, 2, 3, 4, 5, 6, 7], 3),
    ([7, 6, 5, 4, 3, 2, 1], 3),
    ([1, 1, 1, 1, 1, 1, 1, 1], 0),
    ([1, 2, 3, 4, 4, 3, 2, 1], 0),
    ([1, 2, 3, 4, 5, 3, 2, 1], 1),
    ([0, 0], 0),
    ([0, 1], 1),
    ([-1, -1], 0),
    ([-1, 1], 1),
    ([100, 200, 300, 200, 100], 0),
    ([100, 200, 300, 200, 101], 1),
])
def test_smallest_change(arr, expected):
    assert smallest_change(arr) == expected


def test_smallest_change_empty_list():
    assert smallest_change([]) == 0


def test_smallest_change_single_element():
    assert smallest_change([42]) == 0


def test_smallest_change_two_same_elements():
    assert smallest_change([5, 5]) == 0


def test_smallest_change_two_different_elements():
    assert smallest_change([5, 3]) == 1


def test_smallest_change_palindrome():
    assert smallest_change([1, 2, 3, 2, 1]) == 0


def test_smallest_change_not_palindrome():
    assert smallest_change([1, 2, 3, 4, 5]) == 2


def test_smallest_change_all_same():
    assert smallest_change([7, 7, 7, 7, 7, 7, 7]) == 0


def test_smallest_change_all_different():
    assert smallest_change([1, 2, 3, 4, 5, 6, 7]) == 3


def test_smallest_change_large_array():
    arr = list(range(100))
    assert smallest_change(arr) == 50


def test_smallest_change_large_palindrome():
    arr = list(range(50)) + list(range(49, -1, -1))
    assert smallest_change(arr) == 0


def test_smallest_change_negative_numbers():
    assert smallest_change([-5, -3, -1, -3, -5]) == 0


def test_smallest_change_mixed_numbers():
    assert smallest_change([-1, 0, 1, 0, -1]) == 0


def test_smallest_change_mixed_numbers_not_palindrome():
    assert smallest_change([-1, 0, 1, 0, 2]) == 1


def test_smallest_change_float_numbers():
    assert smallest_change([1.5, 2.5, 2.5, 1.5]) == 0


def test_smallest_change_float_numbers_not_palindrome():
    assert smallest_change([1.5, 2.5, 3.5, 1.5]) == 1


def test_smallest_change_strings():
    assert smallest_change(['a', 'b', 'b', 'a']) == 0


def test_smallest_change_strings_not_palindrome():
    assert smallest_change(['a', 'b', 'c', 'a']) == 1


def test_smallest_change_odd_length():
    assert smallest_change([1, 2, 3, 4, 5, 6, 7]) == 3


def test_smallest_change_even_length():
    assert smallest_change([1, 2, 3, 4, 5, 6]) == 3


def test_smallest_change_three_elements():
    assert smallest_change([1, 2, 1]) == 0


def test_smallest_change_three_elements_not_palindrome():
    assert smallest_change([1, 2, 3]) == 1


def test_smallest_change_four_elements():
    assert smallest_change([1, 2, 2, 1]) == 0


def test_smallest_change_four_elements_not_palindrome():
    assert smallest_change([1, 2, 3, 4]) == 2