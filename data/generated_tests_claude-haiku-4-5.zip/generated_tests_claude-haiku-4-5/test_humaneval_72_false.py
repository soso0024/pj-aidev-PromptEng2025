# Test cases for HumanEval/72
# Generated using Claude API


def will_it_fly(q,w):
    '''
    Write a function that returns True if the object q will fly, and False otherwise.
    The object q will fly if it's balanced (it is a palindromic list) and the sum of its elements is less than or equal the maximum possible weight w.

    Example:
    will_it_fly([1, 2], 5) ➞ False 
    # 1+2 is less than the maximum possible weight, but it's unbalanced.

    will_it_fly([3, 2, 3], 1) ➞ False
    # it's balanced, but 3+2+3 is more than the maximum possible weight.

    will_it_fly([3, 2, 3], 9) ➞ True
    # 3+2+3 is less than the maximum possible weight, and it's balanced.

    will_it_fly([3], 5) ➞ True
    # 3 is less than the maximum possible weight, and it's balanced.
    '''

    if sum(q) > w:
        return False

    i, j = 0, len(q)-1
    while i<j:
        if q[i] != q[j]:
            return False
        i+=1
        j-=1
    return True


# Generated test cases:
import pytest


@pytest.mark.parametrize("q,w,expected", [
    ([1, 2, 3, 2, 1], 10, True),
    ([1, 2, 3, 2, 1], 5, False),
    ([1], 1, True),
    ([1], 0, False),
    ([], 0, True),
    ([], 10, True),
    ([1, 1], 2, True),
    ([1, 1], 1, False),
    ([1, 2, 1], 4, True),
    ([1, 2, 1], 3, False),
    ([5, 5], 10, True),
    ([5, 5], 9, False),
    ([1, 2, 3, 4, 3, 2, 1], 16, True),
    ([1, 2, 3, 4, 3, 2, 1], 15, False),
    ([0, 0, 0], 0, True),
    ([0, 0, 0], 1, True),
    ([1, 0, 1], 2, True),
    ([1, 0, 1], 1, False),
    ([2, 2, 2, 2], 8, True),
    ([2, 2, 2, 2], 7, False),
    ([1, 2, 2, 1], 6, True),
    ([1, 2, 2, 1], 5, False),
    ([1, 2, 3, 2, 1], 11, True),
    ([10], 10, True),
    ([10], 9, False),
    ([1, 1, 1, 1, 1], 5, True),
    ([1, 1, 1, 1, 1], 4, False),
    ([5, 4, 3, 4, 5], 21, True),
    ([5, 4, 3, 4, 5], 20, False),
    ([1, 2, 3, 3, 2, 1], 12, True),
    ([1, 2, 3, 3, 2, 1], 11, False),
    ([0], 0, True),
    ([0], 1, True),
    ([100, 100], 200, True),
    ([100, 100], 199, False),
])
def test_will_it_fly(q, w, expected):
    from solution import will_it_fly
    assert will_it_fly(q, w) == expected


def test_will_it_fly_palindrome_check():
    assert will_it_fly([1, 2, 3, 2, 1], 10) is True
    assert will_it_fly([1, 2, 3, 4, 2, 1], 13) is False


def test_will_it_fly_weight_check():
    assert will_it_fly([1, 2, 3, 2, 1], 9) is True
    assert will_it_fly([1, 2, 3, 2, 1], 10) is True


def test_will_it_fly_empty_list():
    assert will_it_fly([], 0) is True
    assert will_it_fly([], 100) is True


def test_will_it_fly_single_element():
    assert will_it_fly([5], 5) is True
    assert will_it_fly([5], 4) is False


def test_will_it_fly_two_elements():
    assert will_it_fly([1, 1], 2) is True
    assert will_it_fly([1, 2], 3) is False
    assert will_it_fly([1, 2], 2) is False


def test_will_it_fly_all_zeros():
    assert will_it_fly([0, 0, 0, 0], 0) is True
    assert will_it_fly([0, 0, 0, 0], 1) is True


def test_will_it_fly_large_numbers():
    assert will_it_fly([1000, 2000, 2000, 1000], 6000) is True
    assert will_it_fly([1000, 2000, 2000, 1000], 5999) is False


def test_will_it_fly_negative_numbers():
    assert will_it_fly([-1, 0, 0, -1], -2) is True
    assert will_it_fly([-1, 0, 0, -1], -3) is False
    assert will_it_fly([-5, -5], -10) is True


def test_will_it_fly_mixed_signs():
    assert will_it_fly([-1, 2, 2, -1], 2) is True
    assert will_it_fly([-1, 2, 2, -1], 1) is False