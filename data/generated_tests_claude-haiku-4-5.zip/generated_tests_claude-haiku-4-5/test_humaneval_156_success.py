# Test cases for HumanEval/156
# Generated using Claude API


def int_to_mini_roman(number):
    """
    Given a positive integer, obtain its roman numeral equivalent as a string,
    and return it in lowercase.
    Restrictions: 1 <= num <= 1000

    Examples:
    >>> int_to_mini_roman(19) == 'xix'
    >>> int_to_mini_roman(152) == 'clii'
    >>> int_to_mini_roman(426) == 'cdxxvi'
    """

    num = [1, 4, 5, 9, 10, 40, 50, 90,  
           100, 400, 500, 900, 1000] 
    sym = ["I", "IV", "V", "IX", "X", "XL",  
           "L", "XC", "C", "CD", "D", "CM", "M"] 
    i = 12
    res = ''
    while number: 
        div = number // num[i] 
        number %= num[i] 
        while div: 
            res += sym[i] 
            div -= 1
        i -= 1
    return res.lower()


# Generated test cases:
import pytest


def int_to_mini_roman(number):
    num = [1, 4, 5, 9, 10, 40, 50, 90,  
           100, 400, 500, 900, 1000] 
    sym = ["I", "IV", "V", "IX", "X", "XL",  
           "L", "XC", "C", "CD", "D", "CM", "M"] 
    i = 12
    res = ''
    while number: 
        div = number // num[i] 
        number %= num[i] 
        while div: 
            res += sym[i] 
            div -= 1
        i -= 1
    return res.lower()


@pytest.mark.parametrize("number,expected", [
    (1, "i"),
    (2, "ii"),
    (3, "iii"),
    (4, "iv"),
    (5, "v"),
    (6, "vi"),
    (7, "vii"),
    (8, "viii"),
    (9, "ix"),
    (10, "x"),
    (11, "xi"),
    (14, "xiv"),
    (19, "xix"),
    (27, "xxvii"),
    (40, "xl"),
    (44, "xliv"),
    (49, "xlix"),
    (50, "l"),
    (90, "xc"),
    (99, "xcix"),
    (100, "c"),
    (400, "cd"),
    (444, "cdxliv"),
    (500, "d"),
    (900, "cm"),
    (999, "cmxcix"),
    (1000, "m"),
    (1994, "mcmxciv"),
    (2023, "mmxxiii"),
    (3999, "mmmcmxcix"),
])
def test_int_to_mini_roman_valid_numbers(number, expected):
    assert int_to_mini_roman(number) == expected


def test_int_to_mini_roman_single_digit():
    assert int_to_mini_roman(1) == "i"
    assert int_to_mini_roman(5) == "v"
    assert int_to_mini_roman(9) == "ix"


def test_int_to_mini_roman_double_digit():
    assert int_to_mini_roman(10) == "x"
    assert int_to_mini_roman(50) == "l"
    assert int_to_mini_roman(99) == "xcix"


def test_int_to_mini_roman_triple_digit():
    assert int_to_mini_roman(100) == "c"
    assert int_to_mini_roman(500) == "d"
    assert int_to_mini_roman(999) == "cmxcix"


def test_int_to_mini_roman_four_digit():
    assert int_to_mini_roman(1000) == "m"
    assert int_to_mini_roman(3999) == "mmmcmxcix"


def test_int_to_mini_roman_subtractive_cases():
    assert int_to_mini_roman(4) == "iv"
    assert int_to_mini_roman(9) == "ix"
    assert int_to_mini_roman(40) == "xl"
    assert int_to_mini_roman(90) == "xc"
    assert int_to_mini_roman(400) == "cd"
    assert int_to_mini_roman(900) == "cm"


def test_int_to_mini_roman_additive_cases():
    assert int_to_mini_roman(2) == "ii"
    assert int_to_mini_roman(3) == "iii"
    assert int_to_mini_roman(6) == "vi"
    assert int_to_mini_roman(7) == "vii"
    assert int_to_mini_roman(8) == "viii"


def test_int_to_mini_roman_complex_numbers():
    assert int_to_mini_roman(1984) == "mcmlxxxiv"
    assert int_to_mini_roman(2024) == "mmxxiv"
    assert int_to_mini_roman(1776) == "mdcclxxvi"


def test_int_to_mini_roman_returns_lowercase():
    result = int_to_mini_roman(100)
    assert result == result.lower()
    assert result == "c"


def test_int_to_mini_roman_boundary_values():
    assert int_to_mini_roman(1) == "i"
    assert int_to_mini_roman(3999) == "mmmcmxcix"


def test_int_to_mini_roman_repeated_symbols():
    assert int_to_mini_roman(3) == "iii"
    assert int_to_mini_roman(30) == "xxx"
    assert int_to_mini_roman(300) == "ccc"
    assert int_to_mini_roman(3000) == "mmm"


def test_int_to_mini_roman_mixed_patterns():
    assert int_to_mini_roman(444) == "cdxliv"
    assert int_to_mini_roman(555) == "dlv"
    assert int_to_mini_roman(888) == "dccclxxxviii"
