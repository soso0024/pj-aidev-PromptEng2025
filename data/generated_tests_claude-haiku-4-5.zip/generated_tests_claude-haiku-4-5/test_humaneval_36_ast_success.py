# Test cases for HumanEval/36
# Generated using Claude API



def fizz_buzz(n: int):
    """Return the number of times the digit 7 appears in integers less than n which are divisible by 11 or 13.
    >>> fizz_buzz(50)
    0
    >>> fizz_buzz(78)
    2
    >>> fizz_buzz(79)
    3
    """

    ns = []
    for i in range(n):
        if i % 11 == 0 or i % 13 == 0:
            ns.append(i)
    s = ''.join(list(map(str, ns)))
    ans = 0
    for c in s:
        ans += (c == '7')
    return ans


# Generated test cases:
import pytest


class TestFizzBuzz:
    def test_zero(self):
        from test_humaneval_36_ast import fizz_buzz
        assert fizz_buzz(0) == 0

    def test_one(self):
        assert fizz_buzz(1) == 0

    def test_small_number_no_multiples(self):
        assert fizz_buzz(10) == 0

    def test_includes_zero(self):
        result = fizz_buzz(12)
        assert result == 0

    def test_includes_eleven(self):
        result = fizz_buzz(12)
        assert result == 0

    def test_includes_thirteen(self):
        result = fizz_buzz(14)
        assert result == 0

    def test_includes_twenty_two(self):
        result = fizz_buzz(23)
        assert result == 0

    def test_includes_twenty_six(self):
        result = fizz_buzz(27)
        assert result == 0

    def test_multiple_sevens(self):
        result = fizz_buzz(100)
        assert result >= 0

    def test_range_up_to_77(self):
        result = fizz_buzz(78)
        assert result >= 1

    def test_range_up_to_70(self):
        result = fizz_buzz(71)
        assert result >= 0

    def test_large_number(self):
        result = fizz_buzz(1000)
        assert isinstance(result, int)
        assert result >= 0

    def test_negative_input(self):
        assert fizz_buzz(-1) == 0

    def test_negative_large_input(self):
        assert fizz_buzz(-100) == 0

    def test_specific_case_77(self):
        result = fizz_buzz(78)
        assert result >= 1

    def test_specific_case_70(self):
        result = fizz_buzz(71)
        assert result >= 0

    def test_specific_case_72(self):
        result = fizz_buzz(73)
        assert result >= 0

    def test_specific_case_73(self):
        result = fizz_buzz(74)
        assert result >= 0

    def test_specific_case_78(self):
        result = fizz_buzz(79)
        assert result >= 1

    def test_specific_case_87(self):
        result = fizz_buzz(88)
        assert result >= 1

    def test_specific_case_91(self):
        result = fizz_buzz(92)
        assert result >= 0

    def test_specific_case_143(self):
        result = fizz_buzz(144)
        assert result >= 0

    def test_return_type_is_int(self):
        result = fizz_buzz(50)
        assert isinstance(result, int)

    def test_return_non_negative(self):
        result = fizz_buzz(200)
        assert result >= 0

    def test_multiples_of_11_and_13(self):
        result = fizz_buzz(143)
        assert isinstance(result, int)

    def test_includes_143(self):
        result = fizz_buzz(144)
        assert isinstance(result, int)

    def test_very_large_input(self):
        result = fizz_buzz(10000)
        assert isinstance(result, int)
        assert result >= 0

    def test_boundary_11(self):
        result_before = fizz_buzz(11)
        result_at = fizz_buzz(12)
        assert isinstance(result_before, int)
        assert isinstance(result_at, int)

    def test_boundary_13(self):
        result_before = fizz_buzz(13)
        result_at = fizz_buzz(14)
        assert isinstance(result_before, int)
        assert isinstance(result_at, int)

    def test_boundary_22(self):
        result_before = fizz_buzz(22)
        result_at = fizz_buzz(23)
        assert isinstance(result_before, int)
        assert isinstance(result_at, int)

    def test_boundary_26(self):
        result_before = fizz_buzz(26)
        result_at = fizz_buzz(27)
        assert isinstance(result_before, int)
        assert isinstance(result_at, int)

    def test_sequence_consistency(self):
        result1 = fizz_buzz(50)
        result2 = fizz_buzz(50)
        assert result1 == result2

    def test_monotonic_increase(self):
        result1 = fizz_buzz(50)
        result2 = fizz_buzz(100)
        assert result2 >= result1

    def test_monotonic_increase_large(self):
        result1 = fizz_buzz(100)
        result2 = fizz_buzz(200)
        assert result2 >= result1