# Test cases for HumanEval/160
# Generated using Claude API


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and 
    the second list is a list of integers. Use the two given lists to build the algebric 
    expression and return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + ) 
    Subtraction ( - ) 
    Multiplication ( * ) 
    Floor division ( // ) 
    Exponentiation ( ** ) 

    Example:
    operator['+', '*', '-']
    array = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9

    Note:
        The length of operator list is equal to the length of operand list minus one.
        Operand is a list of of non-negative integers.
        Operator list has at least one operator, and operand list has at least two operands.

    """

    expression = str(operand[0])
    for oprt, oprn in zip(operator, operand[1:]):
        expression+= oprt + str(oprn)
    return eval(expression)


# Generated test cases:
import pytest


def do_algebra(operator, operand):
    expression = str(operand[0])
    for oprt, oprn in zip(operator, operand[1:]):
        expression += oprt + str(oprn)
    return eval(expression)


class TestDoAlgebra:
    
    def test_simple_addition(self):
        assert do_algebra(["+"], [1, 2]) == 3
    
    def test_simple_subtraction(self):
        assert do_algebra(["-"], [5, 2]) == 3
    
    def test_simple_multiplication(self):
        assert do_algebra(["*"], [3, 4]) == 12
    
    def test_simple_division(self):
        assert do_algebra(["/"], [10, 2]) == 5
    
    def test_multiple_operations(self):
        assert do_algebra(["+", "*"], [1, 2, 3]) == 7
    
    def test_multiple_operations_order_of_operations(self):
        assert do_algebra(["+", "+"], [1, 2, 3]) == 6
    
    def test_subtraction_chain(self):
        assert do_algebra(["-", "-"], [10, 3, 2]) == 5
    
    def test_mixed_operations(self):
        assert do_algebra(["+", "-", "*"], [2, 3, 1, 5]) == 0
    
    def test_division_chain(self):
        assert do_algebra(["/", "/"], [100, 2, 5]) == 10
    
    def test_negative_operands(self):
        assert do_algebra(["+"], [-5, 3]) == -2
    
    def test_negative_operands_subtraction(self):
        assert do_algebra(["-"], [-5, -3]) == -2
    
    def test_zero_operand(self):
        assert do_algebra(["+"], [0, 5]) == 5
    
    def test_zero_in_middle(self):
        assert do_algebra(["+", "+"], [1, 0, 2]) == 3
    
    def test_multiplication_by_zero(self):
        assert do_algebra(["*"], [5, 0]) == 0
    
    def test_large_numbers(self):
        assert do_algebra(["+"], [1000000, 2000000]) == 3000000
    
    def test_float_operands(self):
        assert do_algebra(["+"], [1.5, 2.5]) == 4.0
    
    def test_float_division(self):
        result = do_algebra(["/"], [5, 2])
        assert result == 2.5
    
    def test_complex_expression(self):
        assert do_algebra(["+", "*", "-"], [1, 2, 3, 4]) == 3
    
    def test_power_operation(self):
        assert do_algebra(["**"], [2, 3]) == 8
    
    def test_modulo_operation(self):
        assert do_algebra(["%"], [10, 3]) == 1
    
    def test_single_operand_no_operators(self):
        assert do_algebra([], [42]) == 42
    
    def test_expression_with_parentheses_via_eval(self):
        assert do_algebra(["+", "*"], [2, 3, 4]) == 14
    
    def test_negative_result(self):
        assert do_algebra(["-"], [2, 5]) == -3
    
    def test_all_additions(self):
        assert do_algebra(["+", "+", "+"], [1, 1, 1, 1]) == 4
    
    def test_all_multiplications(self):
        assert do_algebra(["*", "*"], [2, 3, 4]) == 24
    
    def test_mixed_positive_negative(self):
        assert do_algebra(["+", "-"], [10, -5, 3]) == 2
    
    def test_division_with_floats(self):
        result = do_algebra(["/"], [7, 2])
        assert abs(result - 3.5) < 0.0001
    
    def test_long_chain_operations(self):
        assert do_algebra(["+", "+", "+", "+"], [1, 1, 1, 1, 1]) == 5
    
    def test_subtraction_resulting_in_zero(self):
        assert do_algebra(["-"], [5, 5]) == 0
    
    def test_multiplication_by_one(self):
        assert do_algebra(["*"], [42, 1]) == 42
    
    def test_division_by_one(self):
        assert do_algebra(["/"], [42, 1]) == 42


@pytest.mark.parametrize("operator,operand,expected", [
    (["+"], [1, 2], 3),
    (["-"], [5, 2], 3),
    (["*"], [3, 4], 12),
    (["/"], [10, 2], 5),
    (["+", "*"], [1, 2, 3], 7),
    (["+", "+"], [1, 2, 3], 6),
    (["-", "-"], [10, 3, 2], 5),
    (["**"], [2, 3], 8),
    (["%"], [10, 3], 1),
    ([], [42], 42),
])
def test_do_algebra_parametrized(operator, operand, expected):
    assert do_algebra(operator, operand) == expected


@pytest.mark.parametrize("operator,operand", [
    (["+"], [-5, 3]),
    (["-"], [-5, -3]),
    (["+"], [0, 5]),
    (["*"], [5, 0]),
    (["+", "+"], [1, 0, 2]),
])
def test_do_algebra_with_special_values(operator, operand):
    result = do_algebra(operator, operand)
    assert isinstance(result, (int, float))