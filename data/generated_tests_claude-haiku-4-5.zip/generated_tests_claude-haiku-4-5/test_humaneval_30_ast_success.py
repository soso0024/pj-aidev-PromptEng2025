# Test cases for HumanEval/30
# Generated using Claude API



def get_positive(l: list):
    """Return only positive numbers in the list.
    >>> get_positive([-1, 2, -4, 5, 6])
    [2, 5, 6]
    >>> get_positive([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    [5, 3, 2, 3, 9, 123, 1]
    """

    return [e for e in l if e > 0]


# Generated test cases:
import pytest


def get_positive(l: list):
    return [e for e in l if e > 0]


class TestGetPositive:
    def test_empty_list(self):
        assert get_positive([]) == []

    def test_all_positive(self):
        assert get_positive([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

    def test_all_negative(self):
        assert get_positive([-1, -2, -3, -4, -5]) == []

    def test_mixed_positive_negative(self):
        assert get_positive([-2, -1, 0, 1, 2]) == [1, 2]

    def test_with_zero(self):
        assert get_positive([0, 0, 0]) == []

    def test_single_positive(self):
        assert get_positive([5]) == [5]

    def test_single_negative(self):
        assert get_positive([-5]) == []

    def test_single_zero(self):
        assert get_positive([0]) == []

    def test_large_positive_numbers(self):
        assert get_positive([1000000, 999999, 1]) == [1000000, 999999, 1]

    def test_large_negative_numbers(self):
        assert get_positive([-1000000, -999999, -1]) == []

    def test_mixed_large_numbers(self):
        assert get_positive([-1000000, 1000000, -1, 1]) == [1000000, 1]

    def test_floats_positive(self):
        assert get_positive([0.1, 0.5, 1.5]) == [0.1, 0.5, 1.5]

    def test_floats_negative(self):
        assert get_positive([-0.1, -0.5, -1.5]) == []

    def test_floats_mixed(self):
        assert get_positive([-0.5, 0.0, 0.5]) == [0.5]

    def test_floats_and_integers_mixed(self):
        assert get_positive([-1, -0.5, 0, 0.5, 1]) == [0.5, 1]

    def test_preserves_order(self):
        assert get_positive([3, 1, 4, 1, 5, 9, 2, 6]) == [3, 1, 4, 1, 5, 9, 2, 6]

    def test_duplicates_preserved(self):
        assert get_positive([1, 1, 2, 2, 3, 3]) == [1, 1, 2, 2, 3, 3]

    def test_very_small_positive(self):
        assert get_positive([0.0001, 0.00001]) == [0.0001, 0.00001]

    def test_very_small_negative(self):
        assert get_positive([-0.0001, -0.00001]) == []

    @pytest.mark.parametrize("input_list,expected", [
        ([1, 2, 3], [1, 2, 3]),
        ([-1, -2, -3], []),
        ([0], []),
        ([1], [1]),
        ([-1], []),
        ([1, -1, 2, -2], [1, 2]),
        ([0, 0, 1, 1], [1, 1]),
    ])
    def test_parametrized_cases(self, input_list, expected):
        assert get_positive(input_list) == expected

    def test_return_type_is_list(self):
        result = get_positive([1, 2, 3])
        assert isinstance(result, list)

    def test_return_type_is_list_empty(self):
        result = get_positive([])
        assert isinstance(result, list)

    def test_original_list_not_modified(self):
        original = [1, -1, 2, -2]
        original_copy = original.copy()
        get_positive(original)
        assert original == original_copy

    def test_negative_zero_behavior(self):
        assert get_positive([-0.0, 0.0]) == []

    def test_scientific_notation_positive(self):
        assert get_positive([1e-5, 1e5]) == [1e-5, 1e5]

    def test_scientific_notation_negative(self):
        assert get_positive([-1e-5, -1e5]) == []

    def test_scientific_notation_mixed(self):
        assert get_positive([-1e5, 1e-5, 1e5]) == [1e-5, 1e5]
