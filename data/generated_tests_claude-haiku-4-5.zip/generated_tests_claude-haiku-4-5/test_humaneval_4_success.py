# Test cases for HumanEval/4
# Generated using Claude API

from typing import List


def mean_absolute_deviation(numbers: List[float]) -> float:
    """ For a given list of input numbers, calculate Mean Absolute Deviation
    around the mean of this dataset.
    Mean Absolute Deviation is the average absolute difference between each
    element and a centerpoint (mean in this case):
    MAD = average | x - x_mean |
    >>> mean_absolute_deviation([1.0, 2.0, 3.0, 4.0])
    1.0
    """

    mean = sum(numbers) / len(numbers)
    return sum(abs(x - mean) for x in numbers) / len(numbers)


# Generated test cases:
import pytest
from typing import List


def mean_absolute_deviation(numbers: List[float]) -> float:
    mean = sum(numbers) / len(numbers)
    return sum(abs(x - mean) for x in numbers) / len(numbers)


class TestMeanAbsoluteDeviation:
    
    def test_single_element(self):
        result = mean_absolute_deviation([5.0])
        assert result == 0.0
    
    def test_two_equal_elements(self):
        result = mean_absolute_deviation([3.0, 3.0])
        assert result == 0.0
    
    def test_two_different_elements(self):
        result = mean_absolute_deviation([1.0, 3.0])
        assert result == 1.0
    
    def test_symmetric_around_mean(self):
        result = mean_absolute_deviation([1.0, 2.0, 3.0])
        assert result == pytest.approx(2.0 / 3.0)
    
    def test_negative_numbers(self):
        result = mean_absolute_deviation([-2.0, -1.0, 0.0, 1.0, 2.0])
        assert result == pytest.approx(1.2)
    
    def test_all_negative_numbers(self):
        result = mean_absolute_deviation([-5.0, -3.0, -1.0])
        assert result == pytest.approx(4.0 / 3.0)
    
    def test_large_numbers(self):
        result = mean_absolute_deviation([1000.0, 2000.0, 3000.0])
        assert result == pytest.approx(666.666666666, rel=1e-5)
    
    def test_small_numbers(self):
        result = mean_absolute_deviation([0.001, 0.002, 0.003])
        assert result == pytest.approx(0.000666666666, rel=1e-5)
    
    def test_mixed_positive_negative(self):
        result = mean_absolute_deviation([-10.0, 0.0, 10.0])
        assert result == pytest.approx(20.0 / 3.0)
    
    def test_zeros(self):
        result = mean_absolute_deviation([0.0, 0.0, 0.0])
        assert result == 0.0
    
    def test_single_zero(self):
        result = mean_absolute_deviation([0.0])
        assert result == 0.0
    
    def test_floats_with_decimals(self):
        result = mean_absolute_deviation([1.5, 2.5, 3.5])
        assert result == pytest.approx(2.0 / 3.0)
    
    def test_large_dataset(self):
        numbers = list(range(1, 101))
        result = mean_absolute_deviation([float(x) for x in numbers])
        assert result == pytest.approx(25.0)
    
    def test_outliers(self):
        result = mean_absolute_deviation([1.0, 2.0, 3.0, 100.0])
        assert result > 0
    
    def test_very_close_numbers(self):
        result = mean_absolute_deviation([1.0, 1.0001, 1.0002])
        assert result == pytest.approx(0.00006666666, rel=1e-5)
    
    @pytest.mark.parametrize("numbers,expected", [
        ([5.0], 0.0),
        ([1.0, 1.0], 0.0),
        ([0.0, 2.0], 1.0),
        ([1.0, 2.0, 3.0, 4.0, 5.0], 1.2),
    ])
    def test_parametrized_cases(self, numbers, expected):
        result = mean_absolute_deviation(numbers)
        assert result == pytest.approx(expected)
    
    def test_empty_list_raises_error(self):
        with pytest.raises(ZeroDivisionError):
            mean_absolute_deviation([])
    
    def test_negative_and_positive_symmetric(self):
        result = mean_absolute_deviation([-5.0, 5.0])
        assert result == 5.0
    
    def test_result_is_non_negative(self):
        result = mean_absolute_deviation([1.0, 2.0, 3.0, 4.0])
        assert result >= 0
