# Test cases for HumanEval/136
# Generated using Claude API


def largest_smallest_integers(lst):
    '''
    Create a function that returns a tuple (a, b), where 'a' is
    the largest of negative integers, and 'b' is the smallest
    of positive integers in a list.
    If there is no negative or positive integers, return them as None.

    Examples:
    largest_smallest_integers([2, 4, 1, 3, 5, 7]) == (None, 1)
    largest_smallest_integers([]) == (None, None)
    largest_smallest_integers([0]) == (None, None)
    '''

    smallest = list(filter(lambda x: x < 0, lst))
    largest = list(filter(lambda x: x > 0, lst))
    return (max(smallest) if smallest else None, min(largest) if largest else None)


# Generated test cases:
import pytest


def largest_smallest_integers(lst):
    smallest = list(filter(lambda x: x < 0, lst))
    largest = list(filter(lambda x: x > 0, lst))
    return (max(smallest) if smallest else None, min(largest) if largest else None)


class TestLargestSmallestIntegers:
    
    def test_example_positive_only(self):
        assert largest_smallest_integers([2, 4, 1, 3, 5, 7]) == (None, 1)
    
    def test_example_empty_list(self):
        assert largest_smallest_integers([]) == (None, None)
    
    def test_example_zero_only(self):
        assert largest_smallest_integers([0]) == (None, None)
    
    def test_negative_only(self):
        assert largest_smallest_integers([-5, -2, -10, -1]) == (-1, None)
    
    def test_positive_only(self):
        assert largest_smallest_integers([1, 2, 3, 4, 5]) == (None, 1)
    
    def test_mixed_positive_negative(self):
        assert largest_smallest_integers([-5, -2, 1, 3, 5]) == (-2, 1)
    
    def test_single_negative(self):
        assert largest_smallest_integers([-5]) == (-5, None)
    
    def test_single_positive(self):
        assert largest_smallest_integers([5]) == (None, 5)
    
    def test_multiple_negatives_one_positive(self):
        assert largest_smallest_integers([-10, -5, -1, 7]) == (-1, 7)
    
    def test_one_negative_multiple_positives(self):
        assert largest_smallest_integers([-3, 1, 2, 3, 4]) == (-3, 1)
    
    def test_with_zeros_and_negatives(self):
        assert largest_smallest_integers([0, -5, -2]) == (-2, None)
    
    def test_with_zeros_and_positives(self):
        assert largest_smallest_integers([0, 1, 2, 3]) == (None, 1)
    
    def test_with_zeros_mixed(self):
        assert largest_smallest_integers([0, -5, 3, 0]) == (-5, 3)
    
    def test_large_negative_numbers(self):
        assert largest_smallest_integers([-1000, -500, -100]) == (-100, None)
    
    def test_large_positive_numbers(self):
        assert largest_smallest_integers([100, 500, 1000]) == (None, 100)
    
    def test_large_mixed_numbers(self):
        assert largest_smallest_integers([-1000, -1, 1, 1000]) == (-1, 1)
    
    def test_duplicate_negatives(self):
        assert largest_smallest_integers([-5, -5, -5]) == (-5, None)
    
    def test_duplicate_positives(self):
        assert largest_smallest_integers([3, 3, 3]) == (None, 3)
    
    def test_duplicate_mixed(self):
        assert largest_smallest_integers([-2, -2, 4, 4]) == (-2, 4)
    
    def test_unsorted_list(self):
        assert largest_smallest_integers([5, -3, 2, -10, 1, -1]) == (-1, 1)
    
    def test_negative_one(self):
        assert largest_smallest_integers([-1]) == (-1, None)
    
    def test_positive_one(self):
        assert largest_smallest_integers([1]) == (None, 1)
    
    def test_zero_with_negative_and_positive(self):
        assert largest_smallest_integers([0, -5, 0, 10, 0]) == (-5, 10)
    
    def test_alternating_signs(self):
        assert largest_smallest_integers([-1, 1, -2, 2, -3, 3]) == (-1, 1)
    
    def test_all_zeros(self):
        assert largest_smallest_integers([0, 0, 0]) == (None, None)


@pytest.mark.parametrize("input_list,expected", [
    ([2, 4, 1, 3, 5, 7], (None, 1)),
    ([], (None, None)),
    ([0], (None, None)),
    ([-5, -2, -10, -1], (-1, None)),
    ([1, 2, 3, 4, 5], (None, 1)),
    ([-5, -2, 1, 3, 5], (-2, 1)),
    ([-5], (-5, None)),
    ([5], (None, 5)),
    ([-10, -5, -1, 7], (-1, 7)),
    ([-3, 1, 2, 3, 4], (-3, 1)),
])
def test_parametrized_cases(input_list, expected):
    assert largest_smallest_integers(input_list) == expected
