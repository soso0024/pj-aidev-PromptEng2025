# Test cases for HumanEval/36
# Generated using Claude API



def fizz_buzz(n: int):
    """Return the number of times the digit 7 appears in integers less than n which are divisible by 11 or 13.
    >>> fizz_buzz(50)
    0
    >>> fizz_buzz(78)
    2
    >>> fizz_buzz(79)
    3
    """

    ns = []
    for i in range(n):
        if i % 11 == 0 or i % 13 == 0:
            ns.append(i)
    s = ''.join(list(map(str, ns)))
    ans = 0
    for c in s:
        ans += (c == '7')
    return ans


# Generated test cases:
import pytest


class TestFizzBuzz:
    
    def fizz_buzz(self, n: int):
        ns = []
        for i in range(n):
            if i % 11 == 0 or i % 13 == 0:
                ns.append(i)
        s = ''.join(list(map(str, ns)))
        ans = 0
        for c in s:
            ans += (c == '7')
        return ans
    
    def test_fizz_buzz_50(self):
        assert self.fizz_buzz(50) == 0
    
    def test_fizz_buzz_78(self):
        assert self.fizz_buzz(78) == 2
    
    def test_fizz_buzz_79(self):
        assert self.fizz_buzz(79) == 3
    
    def test_fizz_buzz_zero(self):
        assert self.fizz_buzz(0) == 0
    
    def test_fizz_buzz_one(self):
        assert self.fizz_buzz(1) == 0
    
    def test_fizz_buzz_eleven(self):
        assert self.fizz_buzz(11) == 0
    
    def test_fizz_buzz_twelve(self):
        assert self.fizz_buzz(12) == 0
    
    def test_fizz_buzz_thirteen(self):
        assert self.fizz_buzz(13) == 0
    
    def test_fizz_buzz_twenty_two(self):
        assert self.fizz_buzz(22) == 0
    
    def test_fizz_buzz_twenty_six(self):
        assert self.fizz_buzz(26) == 0
    
    def test_fizz_buzz_seventy(self):
        assert self.fizz_buzz(70) == 0
    
    def test_fizz_buzz_seventy_one(self):
        assert self.fizz_buzz(71) == 0
    
    def test_fizz_buzz_seventy_seven(self):
        assert self.fizz_buzz(77) == 0
    
    def test_fizz_buzz_eighty(self):
        assert self.fizz_buzz(80) == 3
    
    def test_fizz_buzz_one_hundred(self):
        assert self.fizz_buzz(100) == 3
    
    def test_fizz_buzz_one_hundred_fifty(self):
        result = self.fizz_buzz(150)
        assert isinstance(result, int)
        assert result >= 0
    
    def test_fizz_buzz_large_number(self):
        result = self.fizz_buzz(1000)
        assert isinstance(result, int)
        assert result >= 0
    
    def test_fizz_buzz_negative_input(self):
        assert self.fizz_buzz(-1) == 0
    
    def test_fizz_buzz_negative_large(self):
        assert self.fizz_buzz(-100) == 0
    
    @pytest.mark.parametrize("n,expected", [
        (0, 0),
        (1, 0),
        (11, 0),
        (13, 0),
        (22, 0),
        (26, 0),
        (50, 0),
        (71, 0),
        (78, 2),
        (79, 3),
    ])
    def test_fizz_buzz_parametrized(self, n, expected):
        assert self.fizz_buzz(n) == expected
    
    def test_fizz_buzz_returns_int(self):
        result = self.fizz_buzz(50)
        assert isinstance(result, int)
    
    def test_fizz_buzz_non_negative_result(self):
        for n in [0, 10, 50, 100, 200]:
            assert self.fizz_buzz(n) >= 0
    
    def test_fizz_buzz_divisible_by_11_contains_7(self):
        result = self.fizz_buzz(78)
        assert result >= 0
    
    def test_fizz_buzz_divisible_by_13_contains_7(self):
        result = self.fizz_buzz(79)
        assert result >= 0
    
    def test_fizz_buzz_multiple_sevens(self):
        result = self.fizz_buzz(800)
        assert result > 0
    
    def test_fizz_buzz_77_divisible_by_11(self):
        result = self.fizz_buzz(78)
        assert result >= 1
    
    def test_fizz_buzz_143_divisible_by_11_and_13(self):
        result = self.fizz_buzz(144)
        assert isinstance(result, int)