# Test cases for HumanEval/50
# Generated using Claude API



def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


def decode_shift(s: str):
    """
    takes as input string encoded with encode_shift function. Returns decoded string.
    """

    return "".join([chr(((ord(ch) - 5 - ord("a")) % 26) + ord("a")) for ch in s])


# Generated test cases:
import pytest


def decode_shift(s: str):
    return "".join([chr(((ord(ch) - 5 - ord("a")) % 26) + ord("a")) for ch in s])


class TestDecodeShift:
    
    def test_empty_string(self):
        assert decode_shift("") == ""
    
    def test_single_character_a(self):
        assert decode_shift("a") == "v"
    
    def test_single_character_b(self):
        assert decode_shift("b") == "w"
    
    def test_single_character_z(self):
        assert decode_shift("z") == "u"
    
    def test_simple_word(self):
        assert decode_shift("fghij") == "abcde"
    
    def test_alphabet_shift(self):
        result = decode_shift("abcdefghijklmnopqrstuvwxyz")
        expected = "vwxyzabcdefghijklmnopqrstu"
        assert result == expected
    
    def test_wrap_around_beginning(self):
        assert decode_shift("abc") == "vwx"
    
    def test_wrap_around_end(self):
        assert decode_shift("xyz") == "stu"
    
    def test_repeated_characters(self):
        assert decode_shift("aaaa") == "vvvv"
    
    def test_repeated_characters_z(self):
        assert decode_shift("zzzz") == "uuuu"
    
    def test_all_same_character_middle(self):
        assert decode_shift("mmmmm") == "hhhhh"
    
    def test_long_string(self):
        input_str = "abcdefghijklmnopqrstuvwxyz" * 10
        expected = "vwxyzabcdefghijklmnopqrstu" * 10
        assert decode_shift(input_str) == expected
    
    def test_decode_shift_reversible(self):
        original = "hello"
        encoded = decode_shift(original)
        decoded = decode_shift(encoded)
        assert decoded != original
    
    def test_specific_word_encoding(self):
        assert decode_shift("mjqqt") == "hello"
    
    def test_specific_word_encoding_world(self):
        assert decode_shift("btwqi") == "world"
    
    def test_character_f(self):
        assert decode_shift("f") == "a"
    
    def test_character_e(self):
        assert decode_shift("e") == "z"
    
    def test_character_g(self):
        assert decode_shift("g") == "b"
    
    def test_mixed_case_not_applicable(self):
        result = decode_shift("abc")
        assert isinstance(result, str)
        assert len(result) == 3
    
    def test_decode_shift_consistency(self):
        test_strings = ["a", "z", "abc", "xyz", "hello", "world"]
        for test_str in test_strings:
            result = decode_shift(test_str)
            assert isinstance(result, str)
            assert len(result) == len(test_str)
            assert all(c.isalpha() and c.islower() for c in result)
    
    def test_modulo_operation_correctness(self):
        assert decode_shift("f") == "a"
        assert decode_shift("e") == "z"
        assert decode_shift("d") == "y"
    
    def test_large_input(self):
        large_input = "a" * 1000
        result = decode_shift(large_input)
        assert result == "v" * 1000
    
    def test_all_lowercase_letters_preserved(self):
        for i in range(26):
            char = chr(ord('a') + i)
            result = decode_shift(char)
            assert result.isalpha() and result.islower()
    
    def test_decode_shift_deterministic(self):
        input_str = "thequickbrownfox"
        result1 = decode_shift(input_str)
        result2 = decode_shift(input_str)
        assert result1 == result2
    
    @pytest.mark.parametrize("input_char,expected", [
        ("a", "v"),
        ("b", "w"),
        ("c", "x"),
        ("d", "y"),
        ("e", "z"),
        ("f", "a"),
        ("g", "b"),
        ("z", "u"),
    ])
    def test_individual_characters(self, input_char, expected):
        assert decode_shift(input_char) == expected
    
    @pytest.mark.parametrize("input_str,expected", [
        ("", ""),
        ("a", "v"),
        ("abc", "vwx"),
        ("xyz", "stu"),
        ("fghij", "abcde"),
    ])
    def test_various_inputs(self, input_str, expected):
        assert decode_shift(input_str) == expected