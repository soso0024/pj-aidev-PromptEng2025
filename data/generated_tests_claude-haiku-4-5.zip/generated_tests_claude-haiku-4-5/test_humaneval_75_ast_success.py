# Test cases for HumanEval/75
# Generated using Claude API


def is_multiply_prime(a):
    """Write a function that returns true if the given number is the multiplication of 3 prime numbers
    and false otherwise.
    Knowing that (a) is less then 100. 
    Example:
    is_multiply_prime(30) == True
    30 = 2 * 3 * 5
    """

    def is_prime(n):
        for j in range(2,n):
            if n%j == 0:
                return False
        return True

    for i in range(2,101):
        if not is_prime(i): continue
        for j in range(2,101):
            if not is_prime(j): continue
            for k in range(2,101):
                if not is_prime(k): continue
                if i*j*k == a: return True
    return False


# Generated test cases:
import pytest


class TestIsMultiplyPrime:
    
    @pytest.mark.parametrize("input_val,expected", [
        (8, True),
        (30, True),
        (10, False),
        (1, False),
        (2, False),
        (3, False),
        (4, False),
        (5, False),
        (6, False),
        (7, False),
    ])
    def test_basic_cases(self, input_val, expected):
        from test_humaneval_75_ast import is_multiply_prime
        assert is_multiply_prime(input_val) == expected
    
    def test_product_of_three_primes(self):
        assert is_multiply_prime(2 * 2 * 2) == True
    
    def test_product_of_three_different_primes(self):
        assert is_multiply_prime(2 * 3 * 5) == True
    
    def test_product_of_three_larger_primes(self):
        assert is_multiply_prime(3 * 5 * 7) == True
    
    def test_product_of_three_same_primes(self):
        assert is_multiply_prime(3 * 3 * 3) == True
    
    def test_product_of_three_primes_with_repeats(self):
        assert is_multiply_prime(2 * 2 * 3) == True
    
    def test_product_of_three_primes_with_repeats_2(self):
        assert is_multiply_prime(2 * 3 * 3) == True
    
    def test_product_of_three_primes_with_repeats_3(self):
        assert is_multiply_prime(5 * 5 * 5) == True
    
    def test_not_product_of_three_primes_single_prime(self):
        assert is_multiply_prime(2) == False
    
    def test_not_product_of_three_primes_product_of_two(self):
        assert is_multiply_prime(2 * 3) == False
    
    def test_not_product_of_three_primes_product_of_four(self):
        assert is_multiply_prime(2 * 2 * 2 * 2) == False
    
    def test_not_product_of_three_primes_composite(self):
        assert is_multiply_prime(12) == True
    
    def test_not_product_of_three_primes_composite_2(self):
        assert is_multiply_prime(18) == True
    
    def test_zero(self):
        assert is_multiply_prime(0) == False
    
    def test_negative_number(self):
        assert is_multiply_prime(-8) == False
    
    def test_large_product_within_range(self):
        assert is_multiply_prime(97 * 97 * 97) == True
    
    def test_product_exceeding_max_range(self):
        assert is_multiply_prime(101 * 101 * 101) == False
    
    def test_30_is_multiply_prime(self):
        assert is_multiply_prime(30) == True
    
    def test_8_is_multiply_prime(self):
        assert is_multiply_prime(8) == True
    
    def test_27_is_multiply_prime(self):
        assert is_multiply_prime(27) == True
    
    def test_125_is_multiply_prime(self):
        assert is_multiply_prime(125) == True
    
    def test_100_is_not_multiply_prime(self):
        assert is_multiply_prime(100) == False
    
    def test_50_is_not_multiply_prime(self):
        assert is_multiply_prime(50) == True
    
    def test_product_2_3_5(self):
        assert is_multiply_prime(2 * 3 * 5) == True
    
    def test_product_2_2_5(self):
        assert is_multiply_prime(2 * 2 * 5) == True
    
    def test_product_3_3_5(self):
        assert is_multiply_prime(3 * 3 * 5) == True
    
    def test_product_7_11_13(self):
        assert is_multiply_prime(7 * 11 * 13) == True
    
    def test_product_2_7_11(self):
        assert is_multiply_prime(2 * 7 * 11) == True