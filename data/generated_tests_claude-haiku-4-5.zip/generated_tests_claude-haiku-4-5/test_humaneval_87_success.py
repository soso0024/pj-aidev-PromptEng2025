# Test cases for HumanEval/87
# Generated using Claude API


def get_row(lst, x):
    """
    You are given a 2 dimensional data, as a nested lists,
    which is similar to matrix, however, unlike matrices,
    each row may contain a different number of columns.
    Given lst, and integer x, find integers x in the list,
    and return list of tuples, [(x1, y1), (x2, y2) ...] such that
    each tuple is a coordinate - (row, columns), starting with 0.
    Sort coordinates initially by rows in ascending order.
    Also, sort coordinates of the row by columns in descending order.
    
    Examples:
    get_row([
      [1,2,3,4,5,6],
      [1,2,3,4,1,6],
      [1,2,3,4,5,1]
    ], 1) == [(0, 0), (1, 4), (1, 0), (2, 5), (2, 0)]
    get_row([], 1) == []
    get_row([[], [1], [1, 2, 3]], 3) == [(2, 2)]
    """

    coords = [(i, j) for i in range(len(lst)) for j in range(len(lst[i])) if lst[i][j] == x]
    return sorted(sorted(coords, key=lambda x: x[1], reverse=True), key=lambda x: x[0])


# Generated test cases:
import pytest


class TestGetRow:
    
    def test_single_element_found(self):
        from test_humaneval_87 import get_row
        result = get_row([[1, 2, 3], [4, 5, 6]], 5)
        assert result == [(1, 1)]
    
    def test_multiple_elements_same_row(self):
        result = get_row([[1, 1, 1], [2, 3, 4]], 1)
        assert result == [(0, 2), (0, 1), (0, 0)]
    
    def test_multiple_elements_different_rows(self):
        result = get_row([[1, 2, 3], [4, 1, 6], [1, 8, 9]], 1)
        assert result == [(0, 0), (1, 1), (2, 0)]
    
    def test_element_not_found(self):
        result = get_row([[1, 2, 3], [4, 5, 6]], 10)
        assert result == []
    
    def test_empty_list(self):
        result = get_row([], 1)
        assert result == []
    
    def test_single_row(self):
        result = get_row([[1, 2, 3, 2]], 2)
        assert result == [(0, 3), (0, 1)]
    
    def test_single_column(self):
        result = get_row([[1], [2], [1], [3]], 1)
        assert result == [(0, 0), (2, 0)]
    
    def test_single_element_list(self):
        result = get_row([[5]], 5)
        assert result == [(0, 0)]
    
    def test_single_element_not_found(self):
        result = get_row([[5]], 3)
        assert result == []
    
    def test_all_same_elements(self):
        result = get_row([[7, 7], [7, 7]], 7)
        assert result == [(0, 1), (0, 0), (1, 1), (1, 0)]
    
    def test_sorting_by_row_first(self):
        result = get_row([[1, 2], [3, 1], [1, 4]], 1)
        assert result == [(0, 0), (1, 1), (2, 0)]
    
    def test_sorting_by_column_descending_within_row(self):
        result = get_row([[1, 1, 1]], 1)
        assert result == [(0, 2), (0, 1), (0, 0)]
    
    def test_negative_numbers(self):
        result = get_row([[-1, -2, -3], [-4, -1, -6]], -1)
        assert result == [(0, 0), (1, 1)]
    
    def test_zero_value(self):
        result = get_row([[0, 1, 0], [2, 0, 3]], 0)
        assert result == [(0, 2), (0, 0), (1, 1)]
    
    def test_string_elements(self):
        result = get_row([['a', 'b', 'c'], ['d', 'a', 'f']], 'a')
        assert result == [(0, 0), (1, 1)]
    
    def test_mixed_types(self):
        result = get_row([[1, '1', 2], ['1', 1, 3]], 1)
        assert result == [(0, 0), (1, 1)]
    
    def test_large_grid(self):
        grid = [[i + j for j in range(10)] for i in range(10)]
        result = get_row(grid, 5)
        assert len(result) > 0
        assert all(grid[r][c] == 5 for r, c in result)
    
    def test_ragged_array(self):
        result = get_row([[1, 2], [3, 4, 5], [6]], 4)
        assert result == [(1, 1)]
    
    def test_ragged_array_multiple_matches(self):
        result = get_row([[1, 2, 1], [3, 1], [1, 4, 1]], 1)
        assert result == [(0, 2), (0, 0), (1, 1), (2, 2), (2, 0)]
    
    def test_float_values(self):
        result = get_row([[1.5, 2.5], [1.5, 3.5]], 1.5)
        assert result == [(0, 0), (1, 0)]
    
    def test_none_value(self):
        result = get_row([[None, 1, None], [2, None, 3]], None)
        assert result == [(0, 2), (0, 0), (1, 1)]
    
    def test_boolean_values(self):
        result = get_row([[True, False, True], [False, True]], True)
        assert result == [(0, 2), (0, 0), (1, 1)]


@pytest.mark.parametrize("lst,x,expected", [
    ([[1, 2, 3], [4, 5, 6]], 5, [(1, 1)]),
    ([[1, 1, 1]], 1, [(0, 2), (0, 1), (0, 0)]),
    ([[1, 2], [3, 4]], 10, []),
    ([], 1, []),
    ([[5]], 5, [(0, 0)]),
    ([[-1, -2], [-1, -3]], -1, [(0, 0), (1, 0)]),
])
def test_get_row_parametrized(lst, x, expected):
    assert get_row(lst, x) == expected