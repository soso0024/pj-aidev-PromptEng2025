# Test cases for HumanEval/136
# Generated using Claude API


def largest_smallest_integers(lst):
    '''
    Create a function that returns a tuple (a, b), where 'a' is
    the largest of negative integers, and 'b' is the smallest
    of positive integers in a list.
    If there is no negative or positive integers, return them as None.

    Examples:
    largest_smallest_integers([2, 4, 1, 3, 5, 7]) == (None, 1)
    largest_smallest_integers([]) == (None, None)
    largest_smallest_integers([0]) == (None, None)
    '''

    smallest = list(filter(lambda x: x < 0, lst))
    largest = list(filter(lambda x: x > 0, lst))
    return (max(smallest) if smallest else None, min(largest) if largest else None)


# Generated test cases:
import pytest


def largest_smallest_integers(lst):
    smallest = list(filter(lambda x: x < 0, lst))
    largest = list(filter(lambda x: x > 0, lst))
    return (max(smallest) if smallest else None, min(largest) if largest else None)


class TestLargestSmallestIntegers:
    
    @pytest.mark.parametrize("input_list,expected", [
        ([2, 4, 1, 3, 5, 7], (None, 1)),
        ([], (None, None)),
        ([0], (None, None)),
        ([-1, -2, -3], (-1, None)),
        ([1, 2, 3], (None, 1)),
        ([-5, -2, -10, 3, 7, 1], (-2, 1)),
        ([-1], (-1, None)),
        ([1], (None, 1)),
        ([0, 0, 0], (None, None)),
        ([-5, -1, -10, -3], (-1, None)),
        ([10, 20, 30], (None, 10)),
        ([-100, -50, -1, 1, 50, 100], (-1, 1)),
        ([5, -5, 3, -3, 1, -1], (-1, 1)),
        ([-1000, 1000], (-1000, 1000)),
        ([0, -5, 5], (-5, 5)),
        ([-2, -2, -2], (-2, None)),
        ([2, 2, 2], (None, 2)),
        ([-1, 0, 1], (-1, 1)),
    ])
    def test_largest_smallest_integers(self, input_list, expected):
        assert largest_smallest_integers(input_list) == expected
    
    def test_single_negative(self):
        assert largest_smallest_integers([-5]) == (-5, None)
    
    def test_single_positive(self):
        assert largest_smallest_integers([5]) == (None, 5)
    
    def test_single_zero(self):
        assert largest_smallest_integers([0]) == (None, None)
    
    def test_multiple_negatives_one_positive(self):
        assert largest_smallest_integers([-10, -5, -1, 100]) == (-1, 100)
    
    def test_one_negative_multiple_positives(self):
        assert largest_smallest_integers([-50, 1, 2, 3, 4]) == (-50, 1)
    
    def test_mixed_with_zeros(self):
        assert largest_smallest_integers([0, 0, -5, 10, 0]) == (-5, 10)
    
    def test_large_numbers(self):
        assert largest_smallest_integers([-1000000, 1000000]) == (-1000000, 1000000)
    
    def test_negative_closest_to_zero(self):
        assert largest_smallest_integers([-100, -50, -1]) == (-1, None)
    
    def test_positive_closest_to_zero(self):
        assert largest_smallest_integers([100, 50, 1]) == (None, 1)
    
    def test_equal_magnitude_opposite_signs(self):
        assert largest_smallest_integers([-7, -3, 3, 7]) == (-3, 3)
    
    def test_many_negatives_one_positive(self):
        assert largest_smallest_integers([-1, -2, -3, -4, -5, 10]) == (-1, 10)
    
    def test_many_positives_one_negative(self):
        assert largest_smallest_integers([-10, 1, 2, 3, 4, 5]) == (-10, 1)
