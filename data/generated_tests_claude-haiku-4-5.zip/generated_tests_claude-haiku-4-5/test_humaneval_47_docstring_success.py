# Test cases for HumanEval/47
# Generated using Claude API



def median(l: list):
    """Return median of elements in the list l.
    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """

    l = sorted(l)
    if len(l) % 2 == 1:
        return l[len(l) // 2]
    else:
        return (l[len(l) // 2 - 1] + l[len(l) // 2]) / 2.0


# Generated test cases:
import pytest


def median(l: list):
    l = sorted(l)
    if len(l) % 2 == 1:
        return l[len(l) // 2]
    else:
        return (l[len(l) // 2 - 1] + l[len(l) // 2]) / 2.0


class TestMedian:
    
    def test_median_odd_length_list(self):
        assert median([3, 1, 2, 4, 5]) == 3
    
    def test_median_even_length_list(self):
        assert median([-10, 4, 6, 1000, 10, 20]) == 8.0
    
    def test_median_single_element(self):
        assert median([5]) == 5
    
    def test_median_two_elements(self):
        assert median([1, 2]) == 1.5
    
    def test_median_two_elements_same(self):
        assert median([5, 5]) == 5.0
    
    def test_median_negative_numbers(self):
        assert median([-5, -3, -1]) == -3
    
    def test_median_negative_and_positive(self):
        assert median([-2, -1, 0, 1, 2]) == 0
    
    def test_median_unsorted_list(self):
        assert median([9, 1, 5, 3, 7]) == 5
    
    def test_median_duplicates(self):
        assert median([1, 1, 1, 1, 1]) == 1
    
    def test_median_duplicates_mixed(self):
        assert median([1, 2, 2, 3]) == 2.0
    
    def test_median_large_numbers(self):
        assert median([1000000, 2000000, 3000000]) == 2000000
    
    def test_median_decimal_result(self):
        result = median([1, 2, 3, 4])
        assert result == 2.5
    
    def test_median_negative_decimal_result(self):
        result = median([-4, -3, -2, -1])
        assert result == -2.5
    
    def test_median_mixed_order(self):
        assert median([5, 2, 8, 1, 9]) == 5
    
    def test_median_three_elements(self):
        assert median([1, 2, 3]) == 2
    
    def test_median_four_elements(self):
        assert median([1, 2, 3, 4]) == 2.5
    
    def test_median_zero_in_list(self):
        assert median([0, 1, 2]) == 1
    
    def test_median_all_zeros(self):
        assert median([0, 0, 0]) == 0
    
    def test_median_negative_zero_and_positive(self):
        result = median([-1, 0, 1])
        assert result == 0
    
    def test_median_float_values(self):
        result = median([1.5, 2.5, 3.5])
        assert result == 2.5
    
    @pytest.mark.parametrize("input_list,expected", [
        ([1], 1),
        ([1, 2], 1.5),
        ([1, 2, 3], 2),
        ([1, 2, 3, 4], 2.5),
        ([5, 3, 1, 4, 2], 3),
        ([-5, -3, -1, 0, 1], -1),
    ])
    def test_median_parametrized(self, input_list, expected):
        assert median(input_list) == expected