# Test cases for HumanEval/19
# Generated using Claude API

from typing import List


def sort_numbers(numbers: str) -> str:
    """ Input is a space-delimited string of numberals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight' and 'nine'.
    Return the string with numbers sorted from smallest to largest
    >>> sort_numbers('three one five')
    'one three five'
    """

    value_map = {
        'zero': 0,
        'one': 1,
        'two': 2,
        'three': 3,
        'four': 4,
        'five': 5,
        'six': 6,
        'seven': 7,
        'eight': 8,
        'nine': 9
    }
    return ' '.join(sorted([x for x in numbers.split(' ') if x], key=lambda x: value_map[x]))


# Generated test cases:
import pytest


def sort_numbers(numbers: str) -> str:
    value_map = {
        'zero': 0,
        'one': 1,
        'two': 2,
        'three': 3,
        'four': 4,
        'five': 5,
        'six': 6,
        'seven': 7,
        'eight': 8,
        'nine': 9
    }
    return ' '.join(sorted([x for x in numbers.split(' ') if x], key=lambda x: value_map[x]))


class TestSortNumbers:
    
    def test_basic_sort(self):
        assert sort_numbers("nine three seven one five") == "one three five seven nine"
    
    def test_single_number(self):
        assert sort_numbers("five") == "five"
    
    def test_already_sorted(self):
        assert sort_numbers("zero one two three four") == "zero one two three four"
    
    def test_reverse_sorted(self):
        assert sort_numbers("nine eight seven six five four three two one zero") == "zero one two three four five six seven eight nine"
    
    def test_all_same_number(self):
        assert sort_numbers("five five five") == "five five five"
    
    def test_with_duplicates(self):
        assert sort_numbers("three one three two one") == "one one two three three"
    
    def test_zero_included(self):
        assert sort_numbers("five zero three") == "zero three five"
    
    def test_all_numbers(self):
        assert sort_numbers("zero one two three four five six seven eight nine") == "zero one two three four five six seven eight nine"
    
    def test_random_order(self):
        assert sort_numbers("seven two nine one") == "one two seven nine"
    
    def test_two_numbers(self):
        assert sort_numbers("eight two") == "two eight"
    
    def test_with_extra_spaces(self):
        assert sort_numbers("nine  three") == "three nine"
    
    def test_leading_trailing_spaces(self):
        assert sort_numbers(" five three ") == "three five"
    
    def test_multiple_extra_spaces(self):
        assert sort_numbers("nine   one   five") == "one five nine"
    
    def test_descending_pairs(self):
        assert sort_numbers("nine zero eight one") == "zero one eight nine"
    
    def test_middle_values(self):
        assert sort_numbers("five four six three") == "three four five six"
    
    def test_large_sequence(self):
        result = sort_numbers("nine eight seven six five four three two one zero nine eight seven")
        assert result == "zero one two three four five six seven seven eight eight nine nine"
    
    def test_single_zero(self):
        assert sort_numbers("zero") == "zero"
    
    def test_single_nine(self):
        assert sort_numbers("nine") == "nine"
    
    def test_two_zeros(self):
        assert sort_numbers("zero zero") == "zero zero"
    
    @pytest.mark.parametrize("input_str,expected", [
        ("three one four one five", "one one three four five"),
        ("two seven one eight", "one two seven eight"),
        ("six five four three two one zero", "zero one two three four five six"),
        ("nine nine nine", "nine nine nine"),
        ("zero nine", "zero nine"),
    ])
    def test_parametrized_cases(self, input_str, expected):
        assert sort_numbers(input_str) == expected
