# Test cases for HumanEval/135
# Generated using Claude API


def can_arrange(arr):
    """Create a function which returns the largest index of an element which
    is not greater than or equal to the element immediately preceding it. If
    no such element exists then return -1. The given array will not contain
    duplicate values.

    Examples:
    can_arrange([1,2,4,3,5]) = 3
    can_arrange([1,2,3]) = -1
    """

    ind=-1
    i=1
    while i<len(arr):
      if arr[i]<arr[i-1]:
        ind=i
      i+=1
    return ind


# Generated test cases:
import pytest


@pytest.mark.parametrize("arr,expected", [
    ([1, 2, 4, 3, 5], 3),
    ([1, 2, 3], -1),
    ([5, 4, 3, 2, 1], 4),
    ([1], -1),
    ([], -1),
    ([2, 1], 1),
    ([1, 3, 2, 4], 2),
    ([10, 20, 30, 40, 50], -1),
    ([50, 40, 30, 20, 10], 4),
    ([1, 2, 3, 2, 5], 3),
    ([5, 1, 2, 3, 4], 1),
    ([1, 5, 3, 4, 2], 4),
    ([3, 2, 1], 2),
    ([1, 2, 1, 3], 2),
    ([10, 5, 20, 15, 30], 3),
    ([1, 2, 3, 4, 5, 4], 5),
    ([100, 50, 75, 25], 3),
    ([1, 1000, 2, 3], 2),
    ([-5, -3, -1], -1),
    ([-1, -5, -3], 1),
    ([0, -1], 1),
    ([-10, -20, -15], 1),
    ([1, 2, 3, 3, 4], -1),
])
def test_can_arrange(arr, expected):
    from test_humaneval_135_docstring_ast import can_arrange
    assert can_arrange(arr) == expected


def test_can_arrange_single_element():
    assert can_arrange([42]) == -1


def test_can_arrange_two_elements_ascending():
    assert can_arrange([1, 2]) == -1


def test_can_arrange_two_elements_descending():
    assert can_arrange([2, 1]) == 1


def test_can_arrange_empty_array():
    assert can_arrange([]) == -1


def test_can_arrange_all_ascending():
    assert can_arrange([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == -1


def test_can_arrange_all_descending():
    assert can_arrange([10, 9, 8, 7, 6, 5, 4, 3, 2, 1]) == 9


def test_can_arrange_multiple_violations_returns_largest():
    assert can_arrange([5, 4, 3, 2, 1]) == 4
    assert can_arrange([1, 5, 3, 4, 2]) == 4


def test_can_arrange_violation_at_end():
    assert can_arrange([1, 2, 3, 4, 5, 3]) == 5


def test_can_arrange_violation_at_start():
    assert can_arrange([5, 1, 2, 3, 4]) == 1


def test_can_arrange_negative_numbers():
    assert can_arrange([-5, -3, -1]) == -1
    assert can_arrange([-1, -5, -3]) == 1


def test_can_arrange_mixed_positive_negative():
    assert can_arrange([-10, 0, 10]) == -1
    assert can_arrange([10, 0, -10]) == 2


def test_can_arrange_large_numbers():
    assert can_arrange([1000000, 2000000, 3000000]) == -1
    assert can_arrange([3000000, 2000000, 1000000]) == 2


def test_can_arrange_zero():
    assert can_arrange([0, 1, 2]) == -1
    assert can_arrange([2, 1, 0]) == 2
    assert can_arrange([0, -1]) == 1