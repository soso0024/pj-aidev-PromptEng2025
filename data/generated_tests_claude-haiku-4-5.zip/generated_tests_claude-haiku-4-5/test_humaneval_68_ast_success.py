# Test cases for HumanEval/68
# Generated using Claude API


def pluck(arr):
    """
    "Given an array representing a branch of a tree that has non-negative integer nodes
    your task is to pluck one of the nodes and return it.
    The plucked node should be the node with the smallest even value.
    If multiple nodes with the same smallest even value are found return the node that has smallest index.

    The plucked node should be returned in a list, [ smalest_value, its index ],
    If there are no even values or the given array is empty, return [].

    Example 1:
        Input: [4,2,3]
        Output: [2, 1]
        Explanation: 2 has the smallest even value, and 2 has the smallest index.

    Example 2:
        Input: [1,2,3]
        Output: [2, 1]
        Explanation: 2 has the smallest even value, and 2 has the smallest index. 

    Example 3:
        Input: []
        Output: []
    
    Example 4:
        Input: [5, 0, 3, 0, 4, 2]
        Output: [0, 1]
        Explanation: 0 is the smallest value, but  there are two zeros,
                     so we will choose the first zero, which has the smallest index.

    Constraints:
        * 1 <= nodes.length <= 10000
        * 0 <= node.value
    """

    if(len(arr) == 0): return []
    evens = list(filter(lambda x: x%2 == 0, arr))
    if(evens == []): return []
    return [min(evens), arr.index(min(evens))]


# Generated test cases:
import pytest


def pluck(arr):
    if(len(arr) == 0): return []
    evens = list(filter(lambda x: x%2 == 0, arr))
    if(evens == []): return []
    return [min(evens), arr.index(min(evens))]


class TestPluck:
    def test_empty_array(self):
        assert pluck([]) == []

    def test_no_even_numbers(self):
        assert pluck([1, 3, 5, 7]) == []

    def test_single_even_number(self):
        assert pluck([2]) == [2, 0]

    def test_single_even_at_start(self):
        assert pluck([2, 1, 3, 5]) == [2, 0]

    def test_single_even_at_end(self):
        assert pluck([1, 3, 5, 2]) == [2, 3]

    def test_single_even_in_middle(self):
        assert pluck([1, 3, 2, 5]) == [2, 2]

    def test_multiple_even_numbers(self):
        assert pluck([2, 4, 6, 8]) == [2, 0]

    def test_multiple_evens_min_at_start(self):
        assert pluck([2, 8, 4, 6]) == [2, 0]

    def test_multiple_evens_min_at_end(self):
        assert pluck([8, 4, 6, 2]) == [2, 3]

    def test_multiple_evens_min_in_middle(self):
        assert pluck([8, 2, 6, 4]) == [2, 1]

    def test_mixed_odd_and_even(self):
        assert pluck([1, 2, 3, 4, 5, 6]) == [2, 1]

    def test_negative_even_numbers(self):
        assert pluck([-2, -4, -6]) == [-6, 2]

    def test_negative_and_positive_evens(self):
        assert pluck([-2, 4, -6, 8]) == [-6, 2]

    def test_zero_is_even(self):
        assert pluck([0, 1, 2, 3]) == [0, 0]

    def test_zero_with_other_evens(self):
        assert pluck([2, 4, 0, 6]) == [0, 2]

    def test_large_numbers(self):
        assert pluck([1000, 2000, 3000]) == [1000, 0]

    def test_duplicate_even_numbers(self):
        assert pluck([4, 2, 4, 2]) == [2, 1]

    def test_duplicate_min_even_returns_first_index(self):
        assert pluck([2, 1, 2, 3]) == [2, 0]

    def test_all_same_even_number(self):
        assert pluck([4, 4, 4, 4]) == [4, 0]

    def test_odd_numbers_only(self):
        assert pluck([11, 13, 15, 17]) == []

    def test_single_odd_number(self):
        assert pluck([1]) == []

    def test_alternating_odd_even(self):
        assert pluck([1, 2, 3, 4, 5, 6, 7, 8]) == [2, 1]

    def test_large_array_with_one_even(self):
        result = pluck([1, 3, 5, 7, 9, 11, 13, 2, 15, 17])
        assert result == [2, 7]

    def test_negative_zero(self):
        assert pluck([-0, 1, 2]) == [0, 0]

    def test_mixed_negative_positive_odd_even(self):
        assert pluck([-1, -2, 1, 2, -3, -4]) == [-4, 5]

    @pytest.mark.parametrize("arr,expected", [
        ([2, 4, 6], [2, 0]),
        ([1, 3, 5], []),
        ([10], [10, 0]),
        ([1, 10, 3], [10, 1]),
        ([-2, -4, -6], [-6, 2]),
        ([0], [0, 0]),
        ([1, 0, 3], [0, 1]),
    ])
    def test_parametrized_cases(self, arr, expected):
        assert pluck(arr) == expected
