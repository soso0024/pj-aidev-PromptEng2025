# Test cases for HumanEval/89
# Generated using Claude API


def encrypt(s):
    """Create a function encrypt that takes a string as an argument and
    returns a string encrypted with the alphabet being rotated. 
    The alphabet should be rotated in a manner such that the letters 
    shift down by two multiplied to two places.
    For example:
    encrypt('hi') returns 'lm'
    encrypt('asdfghjkl') returns 'ewhjklnop'
    encrypt('gf') returns 'kj'
    encrypt('et') returns 'ix'
    """

    d = 'abcdefghijklmnopqrstuvwxyz'
    out = ''
    for c in s:
        if c in d:
            out += d[(d.index(c)+2*2) % 26]
        else:
            out += c
    return out


# Generated test cases:
import pytest


def encrypt(s):
    d = 'abcdefghijklmnopqrstuvwxyz'
    out = ''
    for c in s:
        if c in d:
            out += d[(d.index(c)+2*2) % 26]
        else:
            out += c
    return out


@pytest.mark.parametrize("input_str,expected", [
    ("hi", "lm"),
    ("asdfghjkl", "ewhjklnop"),
    ("gf", "kj"),
    ("et", "ix"),
])
def test_encrypt_basic_cases(input_str, expected):
    assert encrypt(input_str) == expected


def test_encrypt_empty_string():
    assert encrypt("") == ""


def test_encrypt_single_character():
    assert encrypt("a") == "e"
    assert encrypt("z") == "d"


def test_encrypt_wrapping_around():
    assert encrypt("xyz") == "bcd"
    assert encrypt("yz") == "cd"


def test_encrypt_with_uppercase():
    assert encrypt("HI") == "HI"
    assert encrypt("A") == "A"


def test_encrypt_with_numbers():
    assert encrypt("123") == "123"
    assert encrypt("a1b2") == "e1f2"


def test_encrypt_with_special_characters():
    assert encrypt("hello!") == "lipps!"
    assert encrypt("a-b") == "e-f"
    assert encrypt("test@123") == "xiwx@123"


def test_encrypt_with_spaces():
    assert encrypt("hello world") == "lipps asvph"
    assert encrypt("a b c") == "e f g"


def test_encrypt_with_mixed_case_and_special():
    assert encrypt("Hello, World!") == "Hipps, Wsvph!"


def test_encrypt_all_lowercase_alphabet():
    result = encrypt("abcdefghijklmnopqrstuvwxyz")
    assert result == "efghijklmnopqrstuvwxyzabcd"


def test_encrypt_repeated_characters():
    assert encrypt("aaa") == "eee"
    assert encrypt("zzz") == "ddd"


def test_encrypt_long_string():
    assert encrypt("thequickbrownfoxjumpsoverthelazydog") == "xliuymgofvsarjsbnyqtwszivxlipedchsk"


def test_encrypt_preserves_non_alphabetic():
    assert encrypt("a!@#$%^&*()b") == "e!@#$%^&*()f"


def test_encrypt_newlines_and_tabs():
    assert encrypt("a\nb\tc") == "e\nf\tg"


def test_encrypt_rotation_is_four():
    assert encrypt("a") == "e"
    assert encrypt("b") == "f"
    assert encrypt("c") == "g"


def test_encrypt_wraparound_boundary():
    assert encrypt("w") == "a"
    assert encrypt("x") == "b"
    assert encrypt("y") == "c"
    assert encrypt("z") == "d"


def test_encrypt_multiple_wraps():
    assert encrypt("vwxyz") == "zabcd"