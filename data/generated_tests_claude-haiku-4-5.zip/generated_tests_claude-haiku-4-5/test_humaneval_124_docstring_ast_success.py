# Test cases for HumanEval/124
# Generated using Claude API


def valid_date(date):
    """You have to write a function which validates a given date string and
    returns True if the date is valid otherwise False.
    The date is valid if all of the following rules are satisfied:
    1. The date string is not empty.
    2. The number of days is not less than 1 or higher than 31 days for months 1,3,5,7,8,10,12. And the number of days is not less than 1 or higher than 30 days for months 4,6,9,11. And, the number of days is not less than 1 or higher than 29 for the month 2.
    3. The months should not be less than 1 or higher than 12.
    4. The date should be in the format: mm-dd-yyyy

    for example: 
    valid_date('03-11-2000') => True

    valid_date('15-01-2012') => False

    valid_date('04-0-2040') => False

    valid_date('06-04-2020') => True

    valid_date('06/04/2020') => False
    """

    try:
        date = date.strip()
        month, day, year = date.split('-')
        month, day, year = int(month), int(day), int(year)
        if month < 1 or month > 12:
            return False
        if month in [1,3,5,7,8,10,12] and day < 1 or day > 31:
            return False
        if month in [4,6,9,11] and day < 1 or day > 30:
            return False
        if month == 2 and day < 1 or day > 29:
            return False
    except:
        return False

    return True


# Generated test cases:
import pytest


class TestValidDate:
    
    @pytest.mark.parametrize("date_input,expected", [
        ("03-11-2000", True),
        ("06-04-2020", True),
        ("01-01-2000", True),
        ("02-29-2020", True),
    ])
    def test_valid_dates(self, date_input, expected):
        from test_humaneval_124_docstring_ast import valid_date
        assert valid_date(date_input) == expected
    
    @pytest.mark.parametrize("date_input,expected", [
        ("15-01-2012", False),
        ("04-0-2040", False),
        ("06/04/2020", False),
        ("13-01-2020", False),
        ("00-01-2020", False),
        ("01-32-2020", False),
        ("02-30-2020", False),
        ("04-31-2020", False),
        ("06-31-2020", False),
        ("09-31-2020", False),
        ("11-31-2020", False),
        ("01-00-2020", False),
        ("02-00-2020", False),
    ])
    def test_invalid_dates(self, date_input, expected):
        assert valid_date(date_input) == expected
    
    @pytest.mark.parametrize("date_input,expected", [
        ("", False),
        ("   ", False),
        ("01-01", False),
        ("01-01-2020-01", False),
        ("01/01/2020", False),
        ("01.01.2020", False),
        ("2020-01-01", False),
        ("01-01-", False),
        ("-01-2020", False),
        ("01--2020", False),
    ])
    def test_invalid_format(self, date_input, expected):
        assert valid_date(date_input) == expected
    
    @pytest.mark.parametrize("date_input,expected", [
        ("abc-def-ghij", False),
        ("01-ab-2020", False),
        ("ab-01-2020", False),
        ("01-01-abcd", False),
        ("!@#-$%-^&*(", False),
    ])
    def test_non_numeric_input(self, date_input, expected):
        assert valid_date(date_input) == expected
    
    @pytest.mark.parametrize("date_input,expected", [
        ("  01-01-2020  ", True),
        ("  03-11-2000  ", True),
        ("\t01-01-2020\t", True),
        ("\n01-01-2020\n", True),
    ])
    def test_whitespace_handling(self, date_input, expected):
        assert valid_date(date_input) == expected
    
    @pytest.mark.parametrize("date_input,expected", [
        ("02-29-2020", True),
        ("02-28-2020", True),
        ("02-01-2020", True),
        ("02-30-2020", False),
        ("02-31-2020", False),
    ])
    def test_february(self, date_input, expected):
        assert valid_date(date_input) == expected
    
    @pytest.mark.parametrize("date_input,expected", [
        ("01-01-1900", True),
        ("06-15-2000", True),
        ("01-01-0001", True),
    ])
    def test_various_years(self, date_input, expected):
        assert valid_date(date_input) == expected
    
    @pytest.mark.parametrize("date_input,expected", [
        (None, False),
    ])
    def test_none_input(self, date_input, expected):
        assert valid_date(date_input) == expected
    
    def test_empty_string(self):
        assert valid_date("") == False
    
    def test_only_spaces(self):
        assert valid_date("   ") == False
    
    def test_valid_date_example_1(self):
        assert valid_date('03-11-2000') == True
    
    def test_invalid_date_example_2(self):
        assert valid_date('15-01-2012') == False
    
    def test_invalid_date_example_3(self):
        assert valid_date('04-0-2040') == False
    
    def test_valid_date_example_4(self):
        assert valid_date('06-04-2020') == True
    
    def test_invalid_format_example_5(self):
        assert valid_date('06/04/2020') == False