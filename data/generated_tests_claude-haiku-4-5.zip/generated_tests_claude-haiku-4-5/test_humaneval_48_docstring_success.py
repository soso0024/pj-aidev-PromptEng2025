# Test cases for HumanEval/48
# Generated using Claude API



def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """

    for i in range(len(text)):
        if text[i] != text[len(text) - 1 - i]:
            return False
    return True


# Generated test cases:
import pytest


def is_palindrome(text: str):
    for i in range(len(text)):
        if text[i] != text[len(text) - 1 - i]:
            return False
    return True


class TestIsPalindrome:
    
    @pytest.mark.parametrize("input_text,expected", [
        ("", True),
        ("a", True),
        ("aba", True),
        ("aaaaa", True),
        ("zbcd", False),
        ("racecar", True),
        ("hello", False),
        ("noon", True),
        ("level", True),
        ("world", False),
        ("12321", True),
        ("12345", False),
        ("a b a", True),
        ("a b c", False),
        ("A", True),
        ("AA", True),
        ("AB", False),
        ("ABA", True),
        ("ABCBA", True),
        ("ABCDE", False),
        ("0", True),
        ("00", True),
        ("01", False),
        ("010", True),
        ("0123210", True),
        ("madam", True),
        ("civic", True),
        ("radar", True),
        ("kayak", True),
        ("rotator", True),
        ("python", False),
        ("ab", False),
        ("ba", False),
        ("aaa", True),
        ("aaaa", True),
        ("abba", True),
        ("abab", False),
        ("abcdefedcba", True),
        ("abcdefghijihgfedcba", True),
        ("the quick brown fox", False),
        ("a man a plan a canal panama", False),
        ("   ", True),
        ("a a a", True),
        ("a b c b a", True),
    ])
    def test_is_palindrome(self, input_text, expected):
        assert is_palindrome(input_text) == expected
    
    def test_empty_string(self):
        assert is_palindrome("") is True
    
    def test_single_character(self):
        assert is_palindrome("a") is True
    
    def test_two_same_characters(self):
        assert is_palindrome("aa") is True
    
    def test_two_different_characters(self):
        assert is_palindrome("ab") is False
    
    def test_odd_length_palindrome(self):
        assert is_palindrome("racecar") is True
    
    def test_even_length_palindrome(self):
        assert is_palindrome("abba") is True
    
    def test_odd_length_non_palindrome(self):
        assert is_palindrome("hello") is False
    
    def test_even_length_non_palindrome(self):
        assert is_palindrome("python") is False
    
    def test_numeric_palindrome(self):
        assert is_palindrome("12321") is True
    
    def test_numeric_non_palindrome(self):
        assert is_palindrome("12345") is False
    
    def test_special_characters_palindrome(self):
        assert is_palindrome("!@!") is True
    
    def test_special_characters_non_palindrome(self):
        assert is_palindrome("!@#") is False
    
    def test_mixed_case_palindrome(self):
        assert is_palindrome("ABA") is True
    
    def test_mixed_case_non_palindrome(self):
        assert is_palindrome("ABc") is False
    
    def test_spaces_palindrome(self):
        assert is_palindrome("a b a") is True
    
    def test_spaces_non_palindrome(self):
        assert is_palindrome("a b c") is False
    
    def test_long_palindrome(self):
        assert is_palindrome("abcdefghijihgfedcba") is True
    
    def test_long_non_palindrome(self):
        assert is_palindrome("abcdefghijklmnopqrst") is False
