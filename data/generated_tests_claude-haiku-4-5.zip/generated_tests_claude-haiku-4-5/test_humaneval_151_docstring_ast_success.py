# Test cases for HumanEval/151
# Generated using Claude API


def double_the_difference(lst):
    '''
    Given a list of numbers, return the sum of squares of the numbers
    in the list that are odd. Ignore numbers that are negative or not integers.
    
    double_the_difference([1, 3, 2, 0]) == 1 + 9 + 0 + 0 = 10
    double_the_difference([-1, -2, 0]) == 0
    double_the_difference([9, -2]) == 81
    double_the_difference([0]) == 0  
   
    If the input list is empty, return 0.
    '''

    return sum([i**2 for i in lst if i > 0 and i%2!=0 and "." not in str(i)])


# Generated test cases:
import pytest


class TestDoubleTheDifference:
    
    def double_the_difference(self, lst):
        return sum([i**2 for i in lst if i > 0 and i%2!=0 and "." not in str(i)])
    
    def test_example_case_1(self):
        assert self.double_the_difference([1, 3, 2, 0]) == 10
    
    def test_example_case_2(self):
        assert self.double_the_difference([-1, -2, 0]) == 0
    
    def test_example_case_3(self):
        assert self.double_the_difference([9, -2]) == 81
    
    def test_example_case_4(self):
        assert self.double_the_difference([0]) == 0
    
    def test_empty_list(self):
        assert self.double_the_difference([]) == 0
    
    def test_single_odd_positive(self):
        assert self.double_the_difference([5]) == 25
    
    def test_single_even_positive(self):
        assert self.double_the_difference([4]) == 0
    
    def test_single_negative(self):
        assert self.double_the_difference([-5]) == 0
    
    def test_all_negative_numbers(self):
        assert self.double_the_difference([-1, -3, -5, -7]) == 0
    
    def test_all_even_numbers(self):
        assert self.double_the_difference([2, 4, 6, 8]) == 0
    
    def test_all_odd_positive_numbers(self):
        assert self.double_the_difference([1, 3, 5, 7]) == 1 + 9 + 25 + 49
    
    def test_mixed_positive_and_negative(self):
        assert self.double_the_difference([1, -1, 3, -3, 5, -5]) == 1 + 9 + 25
    
    def test_mixed_odd_and_even(self):
        assert self.double_the_difference([1, 2, 3, 4, 5]) == 1 + 9 + 25
    
    def test_floats_ignored(self):
        assert self.double_the_difference([1.5, 2.5, 3]) == 9
    
    def test_float_odd_ignored(self):
        assert self.double_the_difference([1.0, 3.0, 5.0]) == 0
    
    def test_large_odd_numbers(self):
        assert self.double_the_difference([11, 13, 15]) == 121 + 169 + 225
    
    def test_zero_in_list(self):
        assert self.double_the_difference([0, 1, 2, 3]) == 1 + 9
    
    def test_negative_zero(self):
        assert self.double_the_difference([-0, 1, 3]) == 1 + 9
    
    def test_very_large_odd_number(self):
        assert self.double_the_difference([999]) == 999 ** 2
    
    def test_mixed_with_floats_and_negatives(self):
        assert self.double_the_difference([-1, 1.5, 3, -2.5, 5, 0]) == 9 + 25
    
    def test_only_floats(self):
        assert self.double_the_difference([1.1, 2.2, 3.3]) == 0
    
    def test_string_representation_check(self):
        assert self.double_the_difference([1, 2.0, 3]) == 1 + 9
    
    @pytest.mark.parametrize("input_list,expected", [
        ([1], 1),
        ([3], 9),
        ([5], 25),
        ([7], 49),
        ([1, 1, 1], 3),
        ([3, 3], 18),
        ([1, 3, 5, 7, 9], 1 + 9 + 25 + 49 + 81),
    ])
    def test_parametrized_odd_cases(self, input_list, expected):
        assert self.double_the_difference(input_list) == expected
    
    @pytest.mark.parametrize("input_list,expected", [
        ([2], 0),
        ([4], 0),
        ([6], 0),
        ([2, 4, 6], 0),
        ([-1], 0),
        ([-3], 0),
        ([-1, -3, -5], 0),
    ])
    def test_parametrized_excluded_cases(self, input_list, expected):
        assert self.double_the_difference(input_list) == expected