# Test cases for HumanEval/76
# Generated using Claude API


def is_simple_power(x, n):
    """Your task is to write a function that returns true if a number x is a simple
    power of n and false in other cases.
    x is a simple power of n if n**int=x
    For example:
    is_simple_power(1, 4) => true
    is_simple_power(2, 2) => true
    is_simple_power(8, 2) => true
    is_simple_power(3, 2) => false
    is_simple_power(3, 1) => false
    is_simple_power(5, 3) => false
    """

    if (n == 1): 
        return (x == 1) 
    power = 1
    while (power < x): 
        power = power * n 
    return (power == x) 


# Generated test cases:
import pytest


def is_simple_power(x, n):
    if (n == 1): 
        return (x == 1) 
    power = 1
    while (power < x): 
        power = power * n 
    return (power == x) 


class TestIsSimplePower:
    
    @pytest.mark.parametrize("x,n,expected", [
        (1, 4, True),
        (2, 2, True),
        (8, 2, True),
        (3, 2, False),
        (3, 1, False),
        (5, 3, False),
    ])
    def test_basic_cases(self, x, n, expected):
        assert is_simple_power(x, n) == expected
    
    @pytest.mark.parametrize("x,n,expected", [
        (1, 1, True),
        (1, 2, True),
        (1, 3, True),
        (1, 100, True),
        (1, 1000, True),
    ])
    def test_x_equals_one(self, x, n, expected):
        assert is_simple_power(x, n) == expected
    
    @pytest.mark.parametrize("x,n,expected", [
        (2, 1, False),
        (5, 1, False),
        (100, 1, False),
        (1000, 1, False),
    ])
    def test_n_equals_one_x_not_one(self, x, n, expected):
        assert is_simple_power(x, n) == expected
    
    @pytest.mark.parametrize("x,n,expected", [
        (2, 2, True),
        (4, 2, True),
        (8, 2, True),
        (16, 2, True),
        (32, 2, True),
        (64, 2, True),
        (128, 2, True),
        (256, 2, True),
        (512, 2, True),
        (1024, 2, True),
    ])
    def test_powers_of_two(self, x, n, expected):
        assert is_simple_power(x, n) == expected
    
    @pytest.mark.parametrize("x,n,expected", [
        (3, 3, True),
        (9, 3, True),
        (27, 3, True),
        (81, 3, True),
        (243, 3, True),
    ])
    def test_powers_of_three(self, x, n, expected):
        assert is_simple_power(x, n) == expected
    
    @pytest.mark.parametrize("x,n,expected", [
        (5, 5, True),
        (25, 5, True),
        (125, 5, True),
        (625, 5, True),
    ])
    def test_powers_of_five(self, x, n, expected):
        assert is_simple_power(x, n) == expected
    
    @pytest.mark.parametrize("x,n,expected", [
        (3, 3, True),
        (4, 3, False),
        (5, 3, False),
        (6, 3, False),
        (7, 3, False),
        (8, 3, False),
    ])
    def test_non_powers(self, x, n, expected):
        assert is_simple_power(x, n) == expected
    
    @pytest.mark.parametrize("x,n,expected", [
        (2, 3, False),
        (3, 4, False),
        (4, 5, False),
        (5, 6, False),
        (6, 7, False),
    ])
    def test_x_less_than_n(self, x, n, expected):
        assert is_simple_power(x, n) == expected
    
    @pytest.mark.parametrize("x,n,expected", [
        (10, 10, True),
        (100, 10, True),
        (1000, 10, True),
        (10000, 10, True),
    ])
    def test_powers_of_ten(self, x, n, expected):
        assert is_simple_power(x, n) == expected
    
    @pytest.mark.parametrize("x,n,expected", [
        (2, 4, False),
        (3, 9, False),
        (4, 16, False),
        (5, 25, False),
    ])
    def test_x_less_than_n_squared(self, x, n, expected):
        assert is_simple_power(x, n) == expected
    
    @pytest.mark.parametrize("x,n,expected", [
        (7, 2, False),
        (15, 2, False),
        (31, 2, False),
        (63, 2, False),
        (127, 2, False),
    ])
    def test_numbers_between_powers(self, x, n, expected):
        assert is_simple_power(x, n) == expected
    
    @pytest.mark.parametrize("x,n,expected", [
        (2, 2, True),
        (4, 2, True),
        (8, 2, True),
        (16, 2, True),
        (32, 2, True),
        (64, 2, True),
        (128, 2, True),
        (256, 2, True),
        (512, 2, True),
        (1024, 2, True),
        (2048, 2, True),
    ])
    def test_large_powers_of_two(self, x, n, expected):
        assert is_simple_power(x, n) == expected
    
    def test_single_case_1_4(self):
        assert is_simple_power(1, 4) == True
    
    def test_single_case_2_2(self):
        assert is_simple_power(2, 2) == True
    
    def test_single_case_8_2(self):
        assert is_simple_power(8, 2) == True
    
    def test_single_case_3_2(self):
        assert is_simple_power(3, 2) == False
    
    def test_single_case_3_1(self):
        assert is_simple_power(3, 1) == False
    
    def test_single_case_5_3(self):
        assert is_simple_power(5, 3) == False
