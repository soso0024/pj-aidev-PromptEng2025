# Test cases for HumanEval/158
# Generated using Claude API


def find_max(words):
    """Write a function that accepts a list of strings.
    The list contains different words. Return the word with maximum number
    of unique characters. If multiple strings have maximum number of unique
    characters, return the one which comes first in lexicographical order.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb" ,"cc"]) == ""aaaaaaa"
    """

    return sorted(words, key = lambda x: (-len(set(x)), x))[0]


# Generated test cases:
import pytest


def find_max(words):
    return sorted(words, key = lambda x: (-len(set(x)), x))[0]


@pytest.mark.parametrize("input_words,expected", [
    (["name", "of", "string"], "string"),
    (["name", "enam", "game"], "enam"),
    (["aaaaaaa", "bb", "cc"], "aaaaaaa"),
    (["a"], "a"),
    (["abc", "def", "ghi"], "abc"),
    (["xyz", "abc", "def"], "abc"),
    (["aaa", "bbb", "ccc"], "aaa"),
    (["abcdef", "ghijkl"], "abcdef"),
    (["z", "y", "x"], "x"),
    (["abcd", "efgh", "ijkl"], "abcd"),
    (["test", "best", "rest"], "best"),
    (["programming", "code", "python"], "programming"),
    (["aa", "bb", "cc", "dd"], "aa"),
    (["unique", "words", "here"], "unique"),
    (["a", "ab", "abc", "abcd"], "abcd"),
    (["dcba", "cbad", "badc"], "badc"),
    (["zzz", "aaa"], "aaa"),
    (["hello", "world"], "world"),
    (["mississippi", "tennessee"], "mississippi"),
    (["abcdefghijklmnopqrstuvwxyz", "bcdefghijklmnopqrstuvwxyz"], "abcdefghijklmnopqrstuvwxyz"),
])
def test_find_max_various_cases(input_words, expected):
    assert find_max(input_words) == expected


def test_find_max_single_word():
    assert find_max(["hello"]) == "hello"


def test_find_max_identical_unique_chars():
    assert find_max(["abc", "def", "ghi"]) == "abc"


def test_find_max_same_word_repeated():
    assert find_max(["test", "test", "test"]) == "test"


def test_find_max_empty_strings_in_list():
    assert find_max(["", "a", "ab"]) == "ab"


def test_find_max_only_empty_string():
    assert find_max([""]) == ""


def test_find_max_mixed_case_sensitivity():
    assert find_max(["ABC", "abc"]) == "ABC"


def test_find_max_special_characters():
    assert find_max(["a!b@c#", "d$e%f"]) == "a!b@c#"


def test_find_max_numbers_as_strings():
    assert find_max(["123", "456", "789"]) == "123"


def test_find_max_whitespace():
    assert find_max(["a b", "cd", "ef"]) == "a b"


def test_find_max_duplicate_chars_in_word():
    assert find_max(["aabbcc", "ddeeff"]) == "aabbcc"


def test_find_max_lexicographical_order_tiebreaker():
    result = find_max(["abc", "def", "ghi"])
    assert result == "abc"


def test_find_max_all_same_unique_count():
    result = find_max(["ab", "cd", "ef", "gh"])
    assert result == "ab"


def test_find_max_long_words():
    assert find_max(["abcdefghijklmnopqrstuvwxyz", "zyxwvutsrqponmlkjihgfedcba"]) == "abcdefghijklmnopqrstuvwxyz"


def test_find_max_unicode_characters():
    assert find_max(["café", "naïve", "résumé"]) == "naïve"


def test_find_max_repeated_patterns():
    assert find_max(["ababab", "cdcdcd", "efefef"]) == "ababab"


def test_find_max_single_char_words():
    assert find_max(["a", "b", "c", "d"]) == "a"


def test_find_max_two_words_different_unique():
    assert find_max(["aaa", "abcdef"]) == "abcdef"


def test_find_max_two_words_same_unique():
    assert find_max(["abc", "def"]) == "abc"