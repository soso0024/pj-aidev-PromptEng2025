# Test cases for HumanEval/91
# Generated using Claude API


def is_bored(S):
    """
    You'll be given a string of words, and your task is to count the number
    of boredoms. A boredom is a sentence that starts with the word "I".
    Sentences are delimited by '.', '?' or '!'.
   
    For example:
    >>> is_bored("Hello world")
    0
    >>> is_bored("The sky is blue. The sun is shining. I love this weather")
    1
    """

    import re
    sentences = re.split(r'[.?!]\s*', S)
    return sum(sentence[0:2] == 'I ' for sentence in sentences)


# Generated test cases:
import pytest
import re


def is_bored(S):
    sentences = re.split(r'[.?!]\s*', S)
    return sum(sentence[0:2] == 'I ' for sentence in sentences)


class TestIsBored:
    def test_empty_string(self):
        assert is_bored("") == 0

    def test_no_sentences(self):
        assert is_bored("Hello world") == 0

    def test_single_boredom(self):
        assert is_bored("The sky is blue. The sun is shining. I love this weather") == 1

    def test_multiple_boredoms(self):
        assert is_bored("I am bored. I am tired. I want to sleep.") == 3

    def test_i_at_start_no_space(self):
        assert is_bored("Iamhere. I am here.") == 1

    def test_i_in_middle(self):
        assert is_bored("Hello I am here") == 0

    def test_lowercase_i(self):
        assert is_bored("i am bored. I am tired.") == 1

    def test_question_mark_delimiter(self):
        assert is_bored("Are you bored? I am bored.") == 1

    def test_exclamation_mark_delimiter(self):
        assert is_bored("This is fun! I hate it!") == 1

    def test_mixed_delimiters(self):
        assert is_bored("Hello. I am here? I am tired! I am done.") == 3

    def test_multiple_spaces_after_delimiter(self):
        assert is_bored("Hello.  I am here") == 1

    def test_no_space_after_delimiter(self):
        assert is_bored("Hello.I am here") == 1

    def test_i_only(self):
        assert is_bored("I") == 0

    def test_i_with_space_only(self):
        assert is_bored("I ") == 1

    def test_sentence_with_only_i_space(self):
        assert is_bored("I . I .") == 2

    def test_consecutive_delimiters(self):
        assert is_bored("Hello.. I am here") == 1

    def test_trailing_delimiter(self):
        assert is_bored("I am bored.") == 1

    def test_leading_delimiter(self):
        assert is_bored(". I am here") == 1

    def test_only_delimiters(self):
        assert is_bored("...") == 0

    def test_complex_sentence(self):
        assert is_bored("Wow, that is amazing! I think Python is great. I love coding!") == 2

    def test_word_starting_with_i(self):
        assert is_bored("It is a beautiful day. I love it.") == 1

    def test_multiple_i_sentences(self):
        assert is_bored("I went to the store. I bought milk. I came home.") == 3

    def test_no_i_sentences(self):
        assert is_bored("The weather is nice. The sun is bright. Everything is good.") == 0

    def test_single_word_sentence_i(self):
        assert is_bored("I. I. I.") == 0

    def test_whitespace_variations(self):
        assert is_bored("Hello.   I am here?  I am tired!   I am done.") == 3

    def test_mixed_case_i(self):
        assert is_bored("I am here. i am tired. I am done.") == 2

    @pytest.mark.parametrize("input_str,expected", [
        ("I am bored.", 1),
        ("I am bored. I am tired.", 2),
        ("Hello world", 0),
        ("The sky is blue. The sun is shining. I love this weather", 1),
        ("I? I! I.", 0),
        ("", 0),
        ("I ", 1),
        ("I", 0),
    ])
    def test_parametrized_cases(self, input_str, expected):
        assert is_bored(input_str) == expected