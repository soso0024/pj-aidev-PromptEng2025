# Test cases for HumanEval/125
# Generated using Claude API


def split_words(txt):
    '''
    Given a string of words, return a list of words split on whitespace, if no whitespaces exists in the text you
    should split on commas ',' if no commas exists you should return the number of lower-case letters with odd order in the
    alphabet, ord('a') = 0, ord('b') = 1, ... ord('z') = 25
    Examples
    split_words("Hello world!") ➞ ["Hello", "world!"]
    split_words("Hello,world!") ➞ ["Hello", "world!"]
    split_words("abcdef") == 3 
    '''

    if " " in txt:
        return txt.split()
    elif "," in txt:
        return txt.replace(',',' ').split()
    else:
        return len([i for i in txt if i.islower() and ord(i)%2 == 0])


# Generated test cases:
import pytest


def split_words(txt):
    if " " in txt:
        return txt.split()
    elif "," in txt:
        return txt.replace(',',' ').split()
    else:
        return len([i for i in txt if i.islower() and ord(i)%2 == 0])


class TestSplitWords:
    
    @pytest.mark.parametrize("input_txt,expected", [
        ("hello world", ["hello", "world"]),
        ("one two three", ["one", "two", "three"]),
        ("a b c", ["a", "b", "c"]),
    ])
    def test_split_by_space(self, input_txt, expected):
        assert split_words(input_txt) == expected
    
    @pytest.mark.parametrize("input_txt,expected", [
        ("hello,world", ["hello", "world"]),
        ("one,two,three", ["one", "two", "three"]),
        ("a,b,c", ["a", "b", "c"]),
        ("hello,world,test", ["hello", "world", "test"]),
    ])
    def test_split_by_comma(self, input_txt, expected):
        assert split_words(input_txt) == expected
    
    @pytest.mark.parametrize("input_txt,expected", [
        ("a", 0),
        ("b", 1),
        ("c", 0),
        ("d", 1),
        ("e", 0),
        ("f", 1),
        ("abc", 1),
        ("abcdef", 3),
        ("aeiou", 0),
        ("bcdfg", 3),
    ])
    def test_count_lowercase_even_ord(self, input_txt, expected):
        assert split_words(input_txt) == expected
    
    def test_space_takes_precedence_over_comma(self):
        result = split_words("hello, world test")
        assert result == ["hello,", "world", "test"]
    
    def test_empty_string(self):
        assert split_words("") == 0
    
    def test_single_word_no_space_no_comma(self):
        result = split_words("hello")
        assert isinstance(result, int)
    
    def test_multiple_spaces(self):
        result = split_words("hello  world")
        assert "hello" in result and "world" in result
    
    def test_multiple_commas(self):
        result = split_words("a,b,c,d")
        assert result == ["a", "b", "c", "d"]
    
    def test_comma_with_spaces_after_split(self):
        result = split_words("hello,world,test")
        assert result == ["hello", "world", "test"]
    
    @pytest.mark.parametrize("input_txt,expected", [
        ("z", 1),
        ("y", 0),
        ("x", 1),
        ("w", 0),
        ("v", 1),
        ("u", 0),
        ("t", 1),
        ("s", 0),
        ("r", 1),
        ("q", 0),
        ("p", 1),
        ("o", 0),
        ("n", 1),
        ("m", 0),
        ("l", 1),
        ("k", 0),
        ("j", 1),
        ("i", 0),
        ("h", 1),
        ("g", 0),
    ])
    def test_all_lowercase_letters_ord_check(self, input_txt, expected):
        assert split_words(input_txt) == expected
    
    def test_uppercase_letters_not_counted(self):
        result = split_words("ABC")
        assert result == 0
    
    def test_mixed_case_only_lowercase_counted(self):
        result = split_words("AaBbCc")
        assert result == 1
    
    def test_numbers_not_counted(self):
        result = split_words("123abc")
        assert result == 1
    
    def test_special_characters_not_counted(self):
        result = split_words("!@#abc")
        assert result == 1
    
    def test_space_at_beginning(self):
        result = split_words(" hello world")
        assert "" in result or "hello" in result
    
    def test_space_at_end(self):
        result = split_words("hello world ")
        assert "hello" in result and "world" in result
    
    def test_comma_at_beginning(self):
        result = split_words(",hello,world")
        assert "" in result or "hello" in result
    
    def test_comma_at_end(self):
        result = split_words("hello,world,")
        assert "hello" in result and "world" in result