# Test cases for HumanEval/71
# Generated using Claude API


def triangle_area(a, b, c):
    '''
    Given the lengths of the three sides of a triangle. Return the area of
    the triangle rounded to 2 decimal points if the three sides form a valid triangle. 
    Otherwise return -1
    Three sides make a valid triangle when the sum of any two sides is greater 
    than the third side.
    Example:
    triangle_area(3, 4, 5) == 6.00
    triangle_area(1, 2, 10) == -1
    '''

    if a + b <= c or a + c <= b or b + c <= a:
        return -1 
    s = (a + b + c)/2    
    area = (s * (s - a) * (s - b) * (s - c)) ** 0.5
    area = round(area, 2)
    return area


# Generated test cases:
import pytest


class TestTriangleArea:
    
    def triangle_area(self, a, b, c):
        if a + b <= c or a + c <= b or b + c <= a:
            return -1 
        s = (a + b + c)/2    
        area = (s * (s - a) * (s - b) * (s - c)) ** 0.5
        area = round(area, 2)
        return area
    
    @pytest.mark.parametrize("a,b,c,expected", [
        (3, 4, 5, 6.0),
        (5, 5, 5, 10.83),
        (6, 8, 10, 24.0),
        (1, 1, 1, 0.43),
        (7, 8, 9, 26.83),
        (10, 10, 10, 43.3),
        (13, 14, 15, 84.0),
    ])
    def test_valid_triangles(self, a, b, c, expected):
        assert self.triangle_area(a, b, c) == expected
    
    @pytest.mark.parametrize("a,b,c", [
        (1, 2, 3),
        (1, 1, 2),
        (1, 2, 4),
        (0, 5, 5),
        (5, 0, 5),
        (5, 5, 0),
        (1, 2, 10),
        (10, 1, 2),
        (2, 10, 1),
    ])
    def test_invalid_triangles(self, a, b, c):
        assert self.triangle_area(a, b, c) == -1
    
    def test_right_triangle(self):
        assert self.triangle_area(3, 4, 5) == 6.0
    
    def test_equilateral_triangle(self):
        assert self.triangle_area(5, 5, 5) == 10.83
    
    def test_isosceles_triangle(self):
        assert self.triangle_area(5, 5, 6) == 12.0
    
    def test_small_triangle(self):
        assert self.triangle_area(0.5, 0.5, 0.5) == 0.11
    
    def test_large_triangle(self):
        assert self.triangle_area(100, 100, 100) == 4330.13
    
    def test_degenerate_triangle_sum_equal(self):
        assert self.triangle_area(1, 2, 3) == -1
    
    def test_degenerate_triangle_one_side_zero(self):
        assert self.triangle_area(0, 5, 5) == -1
    
    def test_degenerate_triangle_negative_sides(self):
        assert self.triangle_area(-3, 4, 5) == -1
    
    def test_almost_degenerate_triangle(self):
        result = self.triangle_area(1, 2, 2.99)
        assert result > 0
    
    def test_float_sides(self):
        result = self.triangle_area(3.5, 4.5, 5.5)
        assert isinstance(result, float)
        assert result > 0
    
    def test_rounding_precision(self):
        result = self.triangle_area(3, 4, 5)
        assert len(str(result).split('.')[-1]) <= 2
    
    def test_scalene_triangle(self):
        assert self.triangle_area(7, 8, 9) == 26.83
    
    def test_very_small_valid_triangle(self):
        result = self.triangle_area(0.1, 0.1, 0.1)
        assert result >= 0
        assert result < 0.01
    
    def test_triangle_with_very_different_sides(self):
        result = self.triangle_area(1, 1, 1.5)
        assert result > 0
    
    def test_all_sides_equal_to_one(self):
        assert self.triangle_area(1, 1, 1) == 0.43
    
    def test_sides_form_valid_triangle_barely(self):
        result = self.triangle_area(1, 2, 2.01)
        assert result > 0
    
    def test_sides_form_invalid_triangle_barely(self):
        assert self.triangle_area(1, 2, 3.01) == -1