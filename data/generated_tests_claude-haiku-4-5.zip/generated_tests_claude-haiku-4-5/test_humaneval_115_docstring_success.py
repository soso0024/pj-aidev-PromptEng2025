# Test cases for HumanEval/115
# Generated using Claude API


def max_fill(grid, capacity):
    import math
    """
    You are given a rectangular grid of wells. Each row represents a single well,
    and each 1 in a row represents a single unit of water.
    Each well has a corresponding bucket that can be used to extract water from it, 
    and all buckets have the same capacity.
    Your task is to use the buckets to empty the wells.
    Output the number of times you need to lower the buckets.

    Example 1:
        Input: 
            grid : [[0,0,1,0], [0,1,0,0], [1,1,1,1]]
            bucket_capacity : 1
        Output: 6

    Example 2:
        Input: 
            grid : [[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]]
            bucket_capacity : 2
        Output: 5
    
    Example 3:
        Input: 
            grid : [[0,0,0], [0,0,0]]
            bucket_capacity : 5
        Output: 0

    Constraints:
        * all wells have the same length
        * 1 <= grid.length <= 10^2
        * 1 <= grid[:,1].length <= 10^2
        * grid[i][j] -> 0 | 1
        * 1 <= capacity <= 10
    """

    return sum([math.ceil(sum(arr)/capacity) for arr in grid])


# Generated test cases:
import pytest
import math


def max_fill(grid, capacity):
    return sum([math.ceil(sum(arr)/capacity) for arr in grid])


class TestMaxFill:
    
    @pytest.mark.parametrize("grid,capacity,expected", [
        ([[0,0,1,0], [0,1,0,0], [1,1,1,1]], 1, 6),
        ([[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]], 2, 5),
        ([[0,0,0], [0,0,0]], 5, 0),
    ])
    def test_provided_examples(self, grid, capacity, expected):
        assert max_fill(grid, capacity) == expected
    
    def test_single_well_single_unit(self):
        grid = [[1]]
        capacity = 1
        assert max_fill(grid, capacity) == 1
    
    def test_single_well_multiple_units(self):
        grid = [[1, 1, 1]]
        capacity = 2
        assert max_fill(grid, capacity) == 2
    
    def test_single_well_empty(self):
        grid = [[0]]
        capacity = 1
        assert max_fill(grid, capacity) == 0
    
    def test_multiple_wells_all_empty(self):
        grid = [[0, 0], [0, 0], [0, 0]]
        capacity = 5
        assert max_fill(grid, capacity) == 0
    
    def test_multiple_wells_all_full(self):
        grid = [[1, 1, 1], [1, 1, 1], [1, 1, 1]]
        capacity = 1
        assert max_fill(grid, capacity) == 9
    
    def test_capacity_larger_than_well(self):
        grid = [[1, 1], [1]]
        capacity = 10
        assert max_fill(grid, capacity) == 2
    
    def test_capacity_equals_well_sum(self):
        grid = [[1, 1, 1], [1, 1, 1]]
        capacity = 3
        assert max_fill(grid, capacity) == 2
    
    def test_mixed_wells(self):
        grid = [[1, 0, 1], [0, 0, 0], [1, 1, 0]]
        capacity = 1
        assert max_fill(grid, capacity) == 4
    
    def test_large_capacity(self):
        grid = [[1, 1, 1, 1, 1], [1, 1, 1, 1, 1]]
        capacity = 10
        assert max_fill(grid, capacity) == 2
    
    def test_single_row_grid(self):
        grid = [[1, 1, 1, 1, 1, 1]]
        capacity = 2
        assert max_fill(grid, capacity) == 3
    
    def test_single_column_grid(self):
        grid = [[1], [1], [1], [1], [1]]
        capacity = 2
        assert max_fill(grid, capacity) == 5
    
    def test_capacity_one(self):
        grid = [[1, 1], [1, 1], [1, 1]]
        capacity = 1
        assert max_fill(grid, capacity) == 6
    
    def test_fractional_division(self):
        grid = [[1, 1, 1], [1, 1]]
        capacity = 2
        assert max_fill(grid, capacity) == 3
    
    def test_all_zeros_large_grid(self):
        grid = [[0] * 10 for _ in range(10)]
        capacity = 5
        assert max_fill(grid, capacity) == 0
    
    def test_alternating_pattern(self):
        grid = [[1, 0, 1, 0], [0, 1, 0, 1]]
        capacity = 1
        assert max_fill(grid, capacity) == 4
    
    def test_capacity_two_with_odd_sum(self):
        grid = [[1, 1, 1]]
        capacity = 2
        assert max_fill(grid, capacity) == 2
    
    def test_multiple_rows_different_sums(self):
        grid = [[1], [1, 1], [1, 1, 1]]
        capacity = 2
        assert max_fill(grid, capacity) == 4
    
    def test_large_well_small_capacity(self):
        grid = [[1] * 20]
        capacity = 3
        assert max_fill(grid, capacity) == 7
    
    def test_many_wells_small_capacity(self):
        grid = [[1, 1] for _ in range(5)]
        capacity = 1
        assert max_fill(grid, capacity) == 10