# Test cases for HumanEval/79
# Generated using Claude API


def decimal_to_binary(decimal):
    """You will be given a number in decimal form and your task is to convert it to
    binary format. The function should return a string, with each character representing a binary
    number. Each character in the string will be '0' or '1'.

    There will be an extra couple of characters 'db' at the beginning and at the end of the string.
    The extra characters are there to help with the format.

    Examples:
    decimal_to_binary(15)   # returns "db1111db"
    decimal_to_binary(32)   # returns "db100000db"
    """

    return "db" + bin(decimal)[2:] + "db"


# Generated test cases:
import pytest


def decimal_to_binary(decimal):
    return "db" + bin(decimal)[2:] + "db"


class TestDecimalToBinary:
    
    def test_zero(self):
        assert decimal_to_binary(0) == "db0db"
    
    def test_one(self):
        assert decimal_to_binary(1) == "db1db"
    
    def test_two(self):
        assert decimal_to_binary(2) == "db10db"
    
    def test_example_15(self):
        assert decimal_to_binary(15) == "db1111db"
    
    def test_example_32(self):
        assert decimal_to_binary(32) == "db100000db"
    
    def test_small_number(self):
        assert decimal_to_binary(3) == "db11db"
    
    def test_small_number_4(self):
        assert decimal_to_binary(4) == "db100db"
    
    def test_small_number_7(self):
        assert decimal_to_binary(7) == "db111db"
    
    def test_small_number_8(self):
        assert decimal_to_binary(8) == "db1000db"
    
    def test_medium_number_100(self):
        assert decimal_to_binary(100) == "db1100100db"
    
    def test_medium_number_255(self):
        assert decimal_to_binary(255) == "db11111111db"
    
    def test_medium_number_256(self):
        assert decimal_to_binary(256) == "db100000000db"
    
    def test_large_number_1000(self):
        assert decimal_to_binary(1000) == "db1111101000db"
    
    def test_large_number_65536(self):
        assert decimal_to_binary(65536) == "db10000000000000000db"
    
    def test_power_of_two_16(self):
        assert decimal_to_binary(16) == "db10000db"
    
    def test_power_of_two_64(self):
        assert decimal_to_binary(64) == "db1000000db"
    
    def test_power_of_two_128(self):
        assert decimal_to_binary(128) == "db10000000db"
    
    def test_power_of_two_512(self):
        assert decimal_to_binary(512) == "db1000000000db"
    
    def test_all_ones_binary_31(self):
        assert decimal_to_binary(31) == "db11111db"
    
    def test_all_ones_binary_63(self):
        assert decimal_to_binary(63) == "db111111db"
    
    def test_all_ones_binary_127(self):
        assert decimal_to_binary(127) == "db1111111db"
    
    def test_return_type_is_string(self):
        result = decimal_to_binary(5)
        assert isinstance(result, str)
    
    def test_return_starts_with_db(self):
        result = decimal_to_binary(10)
        assert result.startswith("db")
    
    def test_return_ends_with_db(self):
        result = decimal_to_binary(10)
        assert result.endswith("db")
    
    def test_contains_only_valid_characters(self):
        result = decimal_to_binary(42)
        for char in result:
            assert char in "db01"
    
    def test_binary_content_is_valid(self):
        result = decimal_to_binary(42)
        binary_part = result[2:-2]
        for char in binary_part:
            assert char in "01"
    
    def test_very_large_number(self):
        result = decimal_to_binary(1000000)
        assert result.startswith("db")
        assert result.endswith("db")
        binary_part = result[2:-2]
        assert int(binary_part, 2) == 1000000


@pytest.mark.parametrize("decimal,expected", [
    (0, "db0db"),
    (1, "db1db"),
    (2, "db10db"),
    (3, "db11db"),
    (4, "db100db"),
    (5, "db101db"),
    (6, "db110db"),
    (7, "db111db"),
    (8, "db1000db"),
    (9, "db1001db"),
    (10, "db1010db"),
    (15, "db1111db"),
    (16, "db10000db"),
    (31, "db11111db"),
    (32, "db100000db"),
    (63, "db111111db"),
    (64, "db1000000db"),
    (100, "db1100100db"),
    (127, "db1111111db"),
    (128, "db10000000db"),
    (255, "db11111111db"),
    (256, "db100000000db"),
    (512, "db1000000000db"),
    (1000, "db1111101000db"),
    (65536, "db10000000000000000db"),
])
def test_decimal_to_binary_parametrized(decimal, expected):
    assert decimal_to_binary(decimal) == expected
