# Test cases for HumanEval/149
# Generated using Claude API


def sorted_list_sum(lst):
    """Write a function that accepts a list of strings as a parameter,
    deletes the strings that have odd lengths from it,
    and returns the resulted list with a sorted order,
    The list is always a list of strings and never an array of numbers,
    and it may contain duplicates.
    The order of the list should be ascending by length of each word, and you
    should return the list sorted by that rule.
    If two words have the same length, sort the list alphabetically.
    The function should return a list of strings in sorted order.
    You may assume that all words will have the same length.
    For example:
    assert list_sort(["aa", "a", "aaa"]) => ["aa"]
    assert list_sort(["ab", "a", "aaa", "cd"]) => ["ab", "cd"]
    """

    lst.sort()
    new_lst = []
    for i in lst:
        if len(i)%2 == 0:
            new_lst.append(i)
    return sorted(new_lst, key=len)


# Generated test cases:
import pytest


class TestSortedListSum:
    
    def sorted_list_sum(self, lst):
        lst.sort()
        new_lst = []
        for i in lst:
            if len(i)%2 == 0:
                new_lst.append(i)
        return sorted(new_lst, key=len)
    
    def test_empty_list(self):
        assert self.sorted_list_sum([]) == []
    
    def test_single_even_length_string(self):
        assert self.sorted_list_sum(["aa"]) == ["aa"]
    
    def test_single_odd_length_string(self):
        assert self.sorted_list_sum(["a"]) == []
    
    def test_all_odd_lengths(self):
        assert self.sorted_list_sum(["a", "aaa", "bbbbb"]) == []
    
    def test_all_even_lengths(self):
        assert self.sorted_list_sum(["aa", "bb", "cc"]) == ["aa", "bb", "cc"]
    
    def test_mixed_odd_and_even(self):
        assert self.sorted_list_sum(["aa", "a", "aaa"]) == ["aa"]
    
    def test_mixed_odd_and_even_multiple_even(self):
        assert self.sorted_list_sum(["ab", "a", "aaa", "cd"]) == ["ab", "cd"]
    
    def test_sorting_by_length(self):
        assert self.sorted_list_sum(["abcd", "ab", "abcdef"]) == ["ab", "abcd", "abcdef"]
    
    def test_alphabetical_sorting_same_length(self):
        assert self.sorted_list_sum(["zz", "aa", "bb"]) == ["aa", "bb", "zz"]
    
    def test_duplicates(self):
        assert self.sorted_list_sum(["aa", "aa", "bb"]) == ["aa", "aa", "bb"]
    
    def test_duplicates_with_odd_lengths(self):
        assert self.sorted_list_sum(["a", "aa", "a", "bb"]) == ["aa", "bb"]
    
    def test_length_priority_over_alphabetical(self):
        assert self.sorted_list_sum(["zz", "aaaa"]) == ["zz", "aaaa"]
    
    def test_complex_mixed_case(self):
        result = self.sorted_list_sum(["Hello", "world", "ab", "cd", "a", "xyz"])
        assert result == ["ab", "cd"]
    
    def test_single_character_strings_all_odd(self):
        assert self.sorted_list_sum(["a", "b", "c"]) == []
    
    def test_two_character_strings_all_even(self):
        assert self.sorted_list_sum(["ab", "cd", "ef"]) == ["ab", "cd", "ef"]
    
    def test_very_long_even_strings(self):
        assert self.sorted_list_sum(["a" * 100, "b" * 100]) == ["a" * 100, "b" * 100]
    
    def test_very_long_odd_strings(self):
        assert self.sorted_list_sum(["a" * 101, "b" * 101]) == []
    
    def test_mixed_very_long_strings(self):
        result = self.sorted_list_sum(["a" * 100, "b" * 101, "c" * 100])
        assert result == ["a" * 100, "c" * 100]
    
    def test_case_sensitivity(self):
        result = self.sorted_list_sum(["Aa", "aa", "AA"])
        assert result == ["AA", "Aa", "aa"]
    
    def test_special_characters_even_length(self):
        result = self.sorted_list_sum(["!!", "@@", "##"])
        assert result == ["!!", "##", "@@"]
    
    def test_numbers_as_strings_even_length(self):
        result = self.sorted_list_sum(["11", "22", "33"])
        assert result == ["11", "22", "33"]
    
    def test_numbers_as_strings_odd_length(self):
        result = self.sorted_list_sum(["1", "22", "333"])
        assert result == ["22"]
    
    def test_whitespace_strings(self):
        result = self.sorted_list_sum(["  ", "    "])
        assert result == ["  ", "    "]
    
    def test_mixed_with_whitespace(self):
        result = self.sorted_list_sum([" ", "  ", "   "])
        assert result == ["  "]
    
    def test_unsorted_input_becomes_sorted(self):
        result = self.sorted_list_sum(["zz", "aa", "bb"])
        assert result == ["aa", "bb", "zz"]
    
    def test_large_list_even_lengths(self):
        input_list = ["aa", "bb", "cc", "dd", "ee", "ff", "gg", "hh"]
        result = self.sorted_list_sum(input_list)
        assert result == ["aa", "bb", "cc", "dd", "ee", "ff", "gg", "hh"]
    
    def test_large_list_mixed(self):
        input_list = ["a", "aa", "b", "bb", "c", "cc", "d", "dd"]
        result = self.sorted_list_sum(input_list)
        assert result == ["aa", "bb", "cc", "dd"]