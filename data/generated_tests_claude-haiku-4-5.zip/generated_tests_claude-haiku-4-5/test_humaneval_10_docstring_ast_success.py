# Test cases for HumanEval/10
# Generated using Claude API



def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """ Find the shortest palindrome that begins with a supplied string.
    Algorithm idea is simple:
    - Find the longest postfix of supplied string that is a palindrome.
    - Append to the end of the string reverse of a string prefix that comes before the palindromic suffix.
    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    """

    if not string:
        return ''

    beginning_of_suffix = 0

    while not is_palindrome(string[beginning_of_suffix:]):
        beginning_of_suffix += 1

    return string + string[:beginning_of_suffix][::-1]


# Generated test cases:
import pytest


def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """ Find the shortest palindrome that begins with a supplied string.
    Algorithm idea is simple:
    - Find the longest postfix of supplied string that is a palindrome.
    - Append to the end of the string reverse of a string prefix that comes before the palindromic suffix.
    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    """
    if not string:
        return ''

    beginning_of_suffix = 0

    while not is_palindrome(string[beginning_of_suffix:]):
        beginning_of_suffix += 1

    return string + string[:beginning_of_suffix][::-1]


class TestIsPalindrome:
    def test_empty_string(self):
        assert is_palindrome('') is True

    def test_single_character(self):
        assert is_palindrome('a') is True

    def test_two_same_characters(self):
        assert is_palindrome('aa') is True

    def test_two_different_characters(self):
        assert is_palindrome('ab') is False

    def test_palindrome_odd_length(self):
        assert is_palindrome('racecar') is True

    def test_palindrome_even_length(self):
        assert is_palindrome('abba') is True

    def test_not_palindrome(self):
        assert is_palindrome('hello') is False

    def test_palindrome_with_spaces(self):
        assert is_palindrome('a b a') is True

    def test_palindrome_with_numbers(self):
        assert is_palindrome('12321') is True

    def test_not_palindrome_with_numbers(self):
        assert is_palindrome('12345') is False


class TestMakePalindrome:
    def test_empty_string(self):
        assert make_palindrome('') == ''

    def test_single_character(self):
        assert make_palindrome('a') == 'a'

    def test_already_palindrome(self):
        assert make_palindrome('aba') == 'aba'

    def test_already_palindrome_even(self):
        assert make_palindrome('abba') == 'abba'

    def test_cat_example(self):
        assert make_palindrome('cat') == 'catac'

    def test_cata_example(self):
        assert make_palindrome('cata') == 'catac'

    def test_two_characters_different(self):
        assert make_palindrome('ab') == 'aba'

    def test_two_characters_same(self):
        assert make_palindrome('aa') == 'aa'

    def test_abc(self):
        result = make_palindrome('abc')
        assert is_palindrome(result)
        assert result.startswith('abc')

    def test_abcd(self):
        result = make_palindrome('abcd')
        assert is_palindrome(result)
        assert result.startswith('abcd')

    def test_result_is_palindrome(self):
        test_strings = ['a', 'ab', 'abc', 'abcd', 'hello', 'world', 'test']
        for s in test_strings:
            result = make_palindrome(s)
            assert is_palindrome(result), f"Result '{result}' is not a palindrome"

    def test_result_starts_with_input(self):
        test_strings = ['a', 'ab', 'abc', 'abcd', 'hello', 'world', 'test']
        for s in test_strings:
            result = make_palindrome(s)
            assert result.startswith(s), f"Result '{result}' does not start with '{s}'"

    def test_result_is_shortest(self):
        result = make_palindrome('cat')
        assert len(result) == 5
        assert result == 'catac'

    def test_result_is_shortest_cata(self):
        result = make_palindrome('cata')
        assert len(result) == 5
        assert result == 'catac'

    def test_long_string(self):
        result = make_palindrome('abcdefg')
        assert is_palindrome(result)
        assert result.startswith('abcdefg')

    def test_string_with_repeated_characters(self):
        result = make_palindrome('aaa')
        assert result == 'aaa'
        assert is_palindrome(result)

    def test_string_with_repeated_pattern(self):
        result = make_palindrome('abab')
        assert is_palindrome(result)
        assert result.startswith('abab')

    def test_numeric_string(self):
        result = make_palindrome('123')
        assert is_palindrome(result)
        assert result.startswith('123')

    def test_mixed_alphanumeric(self):
        result = make_palindrome('a1b2')
        assert is_palindrome(result)
        assert result.startswith('a1b2')

    @pytest.mark.parametrize("input_str,expected", [
        ('', ''),
        ('a', 'a'),
        ('ab', 'aba'),
        ('abc', 'abcba'),
        ('cat', 'catac'),
        ('cata', 'catac'),
        ('racecar', 'racecar'),
        ('abba', 'abba'),
    ])
    def test_parametrized_cases(self, input_str, expected):
        assert make_palindrome(input_str) == expected
