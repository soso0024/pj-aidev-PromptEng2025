# Test cases for HumanEval/32
# Generated using Claude API

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


def find_zero(xs: list):
    """ xs are coefficients of a polynomial.
    find_zero find x such that poly(x) = 0.
    find_zero returns only only zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.
    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0
    """

    begin, end = -1., 1.
    while poly(xs, begin) * poly(xs, end) > 0:
        begin *= 2.0
        end *= 2.0
    while end - begin > 1e-10:
        center = (begin + end) / 2.0
        if poly(xs, center) * poly(xs, begin) > 0:
            begin = center
        else:
            end = center
    return begin


# Generated test cases:
import pytest


def poly(xs, x):
    """Helper function to evaluate polynomial"""
    result = 0
    for i, coeff in enumerate(xs):
        result += coeff * (x ** i)
    return result


def find_zero(xs: list):
    begin, end = -1., 1.
    while poly(xs, begin) * poly(xs, end) > 0:
        begin *= 2.0
        end *= 2.0
    while end - begin > 1e-10:
        center = (begin + end) / 2.0
        if poly(xs, center) * poly(xs, begin) > 0:
            begin = center
        else:
            end = center
    return begin


class TestFindZero:
    
    def test_simple_linear_equation(self):
        """Test finding zero of simple linear equation: x - 1 = 0"""
        xs = [-1, 1]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-6
    
    def test_quadratic_equation(self):
        """Test finding zero of quadratic: x^2 - 4 = 0"""
        xs = [-4, 0, 1]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-6
    
    def test_cubic_equation(self):
        """Test finding zero of cubic: x^3 - 1 = 0"""
        xs = [-1, 0, 0, 1]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-6
    
    def test_negative_root(self):
        """Test finding negative root: x + 1 = 0"""
        xs = [1, 1]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-6
        assert result < 0
    
    def test_fractional_root(self):
        """Test finding fractional root: 2x - 1 = 0"""
        xs = [-1, 2]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-6
        assert abs(result - 0.5) < 1e-6
    
    def test_higher_degree_polynomial(self):
        """Test finding zero of higher degree polynomial: x^4 - 1 = 0"""
        xs = [-1, 0, 0, 0, 1]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-6
    
    def test_polynomial_with_multiple_coefficients(self):
        """Test: x^2 + 2x - 3 = 0"""
        xs = [-3, 2, 1]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-6
    
    def test_small_coefficients(self):
        """Test with small coefficients: 0.001*x - 0.001 = 0"""
        xs = [-0.001, 0.001]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-6
    
    def test_large_coefficients(self):
        """Test with large coefficients: 1000*x - 1000 = 0"""
        xs = [-1000, 1000]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-6
    
    def test_zero_at_origin(self):
        """Test polynomial with zero at origin: x = 0"""
        xs = [0, 1]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-6
        assert abs(result) < 1e-6
    
    def test_polynomial_x_squared_minus_two(self):
        """Test: x^2 - 2 = 0, root at sqrt(2)"""
        xs = [-2, 0, 1]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-4
        assert 1.4 < result < 1.5
    
    def test_polynomial_with_negative_leading_coefficient(self):
        """Test: -x^2 + 1 = 0"""
        xs = [1, 0, -1]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-6
    
    def test_convergence_precision(self):
        """Test that result converges to required precision"""
        xs = [-1, 1]
        result = find_zero(xs)
        poly_value = poly(xs, result)
        assert abs(poly_value) < 1e-9
    
    def test_polynomial_x_cubed_minus_eight(self):
        """Test: x^3 - 8 = 0, root at x = 2"""
        xs = [-8, 0, 0, 1]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-6
        assert abs(result - 2.0) < 1e-6
    
    def test_polynomial_with_mixed_signs(self):
        """Test: x^2 - x - 2 = 0"""
        xs = [-2, -1, 1]
        result = find_zero(xs)
        assert abs(poly(xs, result)) < 1e-6