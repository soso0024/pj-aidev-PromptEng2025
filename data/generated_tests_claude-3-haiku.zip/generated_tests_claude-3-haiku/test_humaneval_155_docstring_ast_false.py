# Test cases for HumanEval/155
# Generated using Claude API


def even_odd_count(num):
    """Given an integer. return a tuple that has the number of even and odd digits respectively.

     Example:
        even_odd_count(-12) ==> (1, 1)
        even_odd_count(123) ==> (1, 2)
    """

    even_count = 0
    odd_count = 0
    for i in str(abs(num)):
        if int(i)%2==0:
            even_count +=1
        else:
            odd_count +=1
    return (even_count, odd_count)


# Generated test cases:
import pytest

@pytest.mark.parametrize("num,expected", [
    (0, (0, 0)),
    (1, (0, 1)),
    (2, (1, 0)),
    (12, (1, 1)),
    (123, (1, 2)),
    (-12, (1, 1)),
    (-123, (1, 2)),
    (1000, (1, 0)),
    (10001, (2, 3)),
    (100000, (5, 1))
])
def test_even_odd_count(num, expected):
    assert even_odd_count(num) == expected

def test_zero_input():
    assert even_odd_count(0) == (0, 0)

def test_negative_input():
    assert even_odd_count(-12) == (1, 1)

def test_string_input():
    with pytest.raises(TypeError):
        even_odd_count("123")

def test_float_input():
    with pytest.raises(ValueError):
        even_odd_count(12.34)

def even_odd_count(num):
    even_count = 0
    odd_count = 0
    for i in str(abs(int(num))):
        if int(i) % 2 == 0:
            even_count += 1
        else:
            odd_count += 1
    return (even_count, odd_count)