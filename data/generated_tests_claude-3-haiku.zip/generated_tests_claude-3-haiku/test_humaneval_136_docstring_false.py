# Test cases for HumanEval/136
# Generated using Claude API


def largest_smallest_integers(lst):
    '''
    Create a function that returns a tuple (a, b), where 'a' is
    the largest of negative integers, and 'b' is the smallest
    of positive integers in a list.
    If there is no negative or positive integers, return them as None.

    Examples:
    largest_smallest_integers([2, 4, 1, 3, 5, 7]) == (None, 1)
    largest_smallest_integers([]) == (None, None)
    largest_smallest_integers([0]) == (None, None)
    '''

    smallest = list(filter(lambda x: x < 0, lst))
    largest = list(filter(lambda x: x > 0, lst))
    return (max(smallest) if smallest else None, min(largest) if largest else None)


# Generated test cases:
from your_module import largest_smallest_integers
import pytest

@pytest.mark.parametrize("input_list,expected", [
    ([2, 4, 1, 3, 5, 7], (None, 1)),
    ([], (None, None)),
    ([0], (None, None)),
    ([-2, -4, 1, 3, 5, 7], (-2, 1)),
    ([2, 4, -1, 3, 5, -7], (-1, 1)),
    ([-2, -4, -1, -3, -5, -7], (-1, None)),
    ([2, 4, 1, 3, 5, 0], (None, 1))
])
def test_largest_smallest_integers(input_list, expected):
    assert largest_smallest_integers(input_list) == expected

def test_empty_list():
    assert largest_smallest_integers([]) == (None, None)

def test_all_zeros():
    assert largest_smallest_integers([0, 0, 0]) == (None, None)

def test_all_negative():
    assert largest_smallest_integers([-2, -4, -1, -3, -5, -7]) == (-1, None)

def test_all_positive():
    assert largest_smallest_integers([2, 4, 1, 3, 5, 7]) == (None, 1)