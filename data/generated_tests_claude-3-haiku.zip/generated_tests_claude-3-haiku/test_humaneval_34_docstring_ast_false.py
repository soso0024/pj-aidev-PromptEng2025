# Test cases for HumanEval/34
# Generated using Claude API



def unique(l: list):
    """Return sorted unique elements in a list
    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """

    return sorted(list(set(l)))


# Generated test cases:
from collections.abc import Iterable
import pytest

@pytest.mark.parametrize("input_list, expected", [
    ([5, 3, 5, 2, 3, 3, 9, 0, 123], [0, 2, 3, 5, 9, 123]),
    ([], []),
    ([1, 1, 1, 1], [1]),
    ([1, 2, 3, 4, 5], [1, 2, 3, 4, 5]),
    ([1, 2, 3, 4, 5, 1, 2, 3], [1, 2, 3, 4, 5]),
    ([-1, 0, 1, 2, -1], [-1, 0, 1, 2]),
    ([True, False, True, False], [False, True]),
    ([None, None, None], [None]),
    ([1.0, 2.0, 3.0, 1.0], [1.0, 2.0, 3.0]),
])
def test_unique(input_list, expected):
    assert isinstance(input_list, Iterable)
    assert isinstance(expected, list)
    assert sorted(unique(input_list)) == expected

def test_unique_empty_list():
    assert unique([]) == []

def test_unique_single_element_list():
    assert unique([1]) == [1]

def test_unique_duplicate_elements():
    assert unique([1, 1, 1, 2, 2, 3]) == [1, 2, 3]

def test_unique_mixed_types():
    assert sorted(unique([1, 'a', 2.0, True, None])) == [1, 2.0, True, 'a', None]

def test_unique_raises_type_error():
    with pytest.raises(TypeError):
        unique(123)