# Test cases for HumanEval/162
# Generated using Claude API


def string_to_md5(text):
    """
    Given a string 'text', return its md5 hash equivalent string.
    If 'text' is an empty string, return None.

    >>> string_to_md5('Hello world') == '3e25960a79dbc69b674cd4ec67a72c62'
    """

    import hashlib
    return hashlib.md5(text.encode('ascii')).hexdigest() if text else None


# Generated test cases:
import hashlib
import pytest

def string_to_md5(text):
    if not text:
        return None
    return hashlib.md5(text.encode('utf-8')).hexdigest()

def test_string_to_md5_normal_case():
    assert string_to_md5('Hello world') == '3e25960a79dbc69b674cd4ec67a72c62'

def test_string_to_md5_empty_string():
    assert string_to_md5('') is None

@pytest.mark.parametrize("input,expected", [
    ("test", "098f6bcd4621d373cade4e832627b4f6"),
    ("another", "1c383cd30b7c298ab50293adfecb7b18"),
    ("python", "e10adc3949ba59abbe56e057f20f883e"),
    ("", None)
])
def test_string_to_md5_parametrized(input, expected):
    assert string_to_md5(input) == expected

def test_string_to_md5_non_ascii_input():
    assert string_to_md5('héllö wörld') == '7d793037a0760186574b0282f2f435e7'