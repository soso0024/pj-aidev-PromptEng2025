# Test cases for HumanEval/45
# Generated using Claude API



def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """

    return a * h / 2.0


# Generated test cases:
import pytest

def triangle_area(a, h):
    return a * h / 2.0

def test_triangle_area_basic():
    assert triangle_area(5, 3) == 7.5

def test_triangle_area_zero_base():
    assert triangle_area(0, 5) == 0.0

def test_triangle_area_zero_height():
    assert triangle_area(10, 0) == 0.0

def test_triangle_area_both_zero():
    assert triangle_area(0, 0) == 0.0

def test_triangle_area_decimal_values():
    assert triangle_area(2.5, 4.0) == 5.0

def test_triangle_area_large_values():
    assert triangle_area(1000, 500) == 250000.0

def test_triangle_area_small_values():
    assert abs(triangle_area(0.1, 0.2) - 0.01) < 1e-10

@pytest.mark.parametrize("a,h,expected", [
    (1, 2, 1.0),
    (4, 6, 12.0),
    (10, 8, 40.0),
    (3.5, 2.0, 3.5),
    (7, 14, 49.0),
    (0.5, 0.4, 0.1)
])
def test_triangle_area_parametrized(a, h, expected):
    assert abs(triangle_area(a, h) - expected) < 1e-10

def test_triangle_area_negative_base():
    assert triangle_area(-5, 4) == -10.0

def test_triangle_area_negative_height():
    assert triangle_area(6, -3) == -9.0

def test_triangle_area_both_negative():
    assert triangle_area(-4, -5) == 10.0

def test_triangle_area_float_precision():
    result = triangle_area(3, 3)
    assert abs(result - 4.5) < 1e-10