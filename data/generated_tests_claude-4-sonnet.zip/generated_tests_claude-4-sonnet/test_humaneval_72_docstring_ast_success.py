# Test cases for HumanEval/72
# Generated using Claude API


def will_it_fly(q,w):
    '''
    Write a function that returns True if the object q will fly, and False otherwise.
    The object q will fly if it's balanced (it is a palindromic list) and the sum of its elements is less than or equal the maximum possible weight w.

    Example:
    will_it_fly([1, 2], 5) ➞ False 
    # 1+2 is less than the maximum possible weight, but it's unbalanced.

    will_it_fly([3, 2, 3], 1) ➞ False
    # it's balanced, but 3+2+3 is more than the maximum possible weight.

    will_it_fly([3, 2, 3], 9) ➞ True
    # 3+2+3 is less than the maximum possible weight, and it's balanced.

    will_it_fly([3], 5) ➞ True
    # 3 is less than the maximum possible weight, and it's balanced.
    '''

    if sum(q) > w:
        return False

    i, j = 0, len(q)-1
    while i<j:
        if q[i] != q[j]:
            return False
        i+=1
        j-=1
    return True


# Generated test cases:
import pytest

def will_it_fly(q,w):
    if sum(q) > w:
        return False

    i, j = 0, len(q)-1
    while i<j:
        if q[i] != q[j]:
            return False
        i+=1
        j-=1
    return True

@pytest.mark.parametrize("q,w,expected", [
    ([1, 2], 5, False),
    ([3, 2, 3], 1, False),
    ([3, 2, 3], 9, True),
    ([3], 5, True),
    ([], 0, True),
    ([], 10, True),
    ([1], 1, True),
    ([1], 0, False),
    ([1, 1], 2, True),
    ([1, 2], 3, False),
    ([5, 5], 10, True),
    ([5, 5], 9, False),
    ([1, 2, 1], 4, True),
    ([1, 2, 1], 3, False),
    ([1, 2, 3, 2, 1], 9, True),
    ([1, 2, 3, 2, 1], 8, False),
    ([1, 2, 3, 4, 5], 15, False),
    ([5, 4, 3, 4, 5], 21, True),
    ([5, 4, 3, 4, 5], 20, False),
    ([0], 0, True),
    ([0, 0], 0, True),
    ([0, 1, 0], 1, True),
    ([0, 1, 0], 0, False),
    ([-1, -1], -2, True),
    ([-1, -1], -3, False),
    ([-1, 1, -1], -1, True),
    ([-1, 1, -1], -2, False),
    ([10, 20, 30, 20, 10], 90, True),
    ([10, 20, 30, 20, 10], 89, False),
    ([1, 2, 3, 4, 3, 2, 1], 16, True),
    ([1, 2, 3, 4, 3, 2, 1], 15, False)
])
def test_will_it_fly(q, w, expected):
    assert will_it_fly(q, w) == expected

def test_will_it_fly_empty_list():
    assert will_it_fly([], 0) == True
    assert will_it_fly([], 100) == True

def test_will_it_fly_single_element():
    assert will_it_fly([5], 5) == True
    assert will_it_fly([5], 4) == False
    assert will_it_fly([0], 0) == True

def test_will_it_fly_negative_numbers():
    assert will_it_fly([-5, -5], -10) == True
    assert will_it_fly([-5, -5], -11) == False
    assert will_it_fly([-5, 5], 0) == False

def test_will_it_fly_large_palindrome():
    large_palindrome = [1, 2, 3, 4, 5, 4, 3, 2, 1]
    assert will_it_fly(large_palindrome, 25) == True
    assert will_it_fly(large_palindrome, 24) == False

def test_will_it_fly_not_palindrome():
    assert will_it_fly([1, 2, 3], 10) == False
    assert will_it_fly([1, 2, 3, 4], 10) == False