# Test cases for HumanEval/5
# Generated using Claude API

from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """ Insert a number 'delimeter' between every two consecutive elements of input list `numbers'
    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """

    if not numbers:
        return []

    result = []

    for n in numbers[:-1]:
        result.append(n)
        result.append(delimeter)

    result.append(numbers[-1])

    return result


# Generated test cases:
import pytest
from typing import List

def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    if not numbers:
        return []

    result = []

    for n in numbers[:-1]:
        result.append(n)
        result.append(delimeter)

    result.append(numbers[-1])

    return result

def test_empty_list():
    assert intersperse([], 0) == []
    assert intersperse([], 5) == []
    assert intersperse([], -1) == []

def test_single_element():
    assert intersperse([1], 0) == [1]
    assert intersperse([5], 9) == [5]
    assert intersperse([-3], 2) == [-3]

def test_two_elements():
    assert intersperse([1, 2], 0) == [1, 0, 2]
    assert intersperse([5, 10], 99) == [5, 99, 10]
    assert intersperse([-1, -2], 3) == [-1, 3, -2]

def test_multiple_elements():
    assert intersperse([1, 2, 3], 0) == [1, 0, 2, 0, 3]
    assert intersperse([1, 2, 3, 4], 9) == [1, 9, 2, 9, 3, 9, 4]
    assert intersperse([10, 20, 30, 40, 50], 5) == [10, 5, 20, 5, 30, 5, 40, 5, 50]

def test_negative_numbers():
    assert intersperse([-1, -2, -3], -9) == [-1, -9, -2, -9, -3]
    assert intersperse([-5, 0, 5], -1) == [-5, -1, 0, -1, 5]

def test_zero_delimiter():
    assert intersperse([1, 2, 3], 0) == [1, 0, 2, 0, 3]
    assert intersperse([0, 0, 0], 0) == [0, 0, 0, 0, 0]

def test_same_numbers_and_delimiter():
    assert intersperse([5, 5, 5], 5) == [5, 5, 5, 5, 5]
    assert intersperse([1, 1], 1) == [1, 1, 1]

@pytest.mark.parametrize("numbers,delimiter,expected", [
    ([1], 0, [1]),
    ([1, 2], 0, [1, 0, 2]),
    ([1, 2, 3], 0, [1, 0, 2, 0, 3]),
    ([1, 2, 3, 4], 9, [1, 9, 2, 9, 3, 9, 4]),
    ([], 5, []),
    ([100], 200, [100]),
    ([-1, -2], -3, [-1, -3, -2])
])
def test_parametrized_cases(numbers, delimiter, expected):
    assert intersperse(numbers, delimiter) == expected

def test_large_numbers():
    assert intersperse([1000000, 2000000], 999999) == [1000000, 999999, 2000000]
    assert intersperse([1, 2, 3], 1000000) == [1, 1000000, 2, 1000000, 3]

def test_mixed_positive_negative():
    assert intersperse([1, -2, 3, -4], 0) == [1, 0, -2, 0, 3, 0, -4]
    assert intersperse([-1, 2, -3], 5) == [-1, 5, 2, 5, -3]
