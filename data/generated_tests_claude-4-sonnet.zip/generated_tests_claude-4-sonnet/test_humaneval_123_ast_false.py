# Test cases for HumanEval/123
# Generated using Claude API


def get_odd_collatz(n):
    """
    Given a positive integer n, return a sorted list that has the odd numbers in collatz sequence.

    The Collatz conjecture is a conjecture in mathematics that concerns a sequence defined
    as follows: start with any positive integer n. Then each term is obtained from the 
    previous term as follows: if the previous term is even, the next term is one half of 
    the previous term. If the previous term is odd, the next term is 3 times the previous
    term plus 1. The conjecture is that no matter what value of n, the sequence will always reach 1.

    Note: 
        1. Collatz(1) is [1].
        2. returned list sorted in increasing order.

    For example:
    get_odd_collatz(5) returns [1, 5] # The collatz sequence for 5 is [5, 16, 8, 4, 2, 1], so the odd numbers are only 1, and 5.
    """

    if n%2==0:
        odd_collatz = [] 
    else:
        odd_collatz = [n]
    while n > 1:
        if n % 2 == 0:
            n = n/2
        else:
            n = n*3 + 1
            
        if n%2 == 1:
            odd_collatz.append(int(n))

    return sorted(odd_collatz)


# Generated test cases:
import pytest

def get_odd_collatz(n):
    if n%2==0:
        odd_collatz = [] 
    else:
        odd_collatz = [n]
    while n > 1:
        if n % 2 == 0:
            n = n/2
        else:
            n = n*3 + 1
            
        if n%2 == 1:
            odd_collatz.append(int(n))

    return sorted(odd_collatz)

def test_get_odd_collatz_n_equals_1():
    assert get_odd_collatz(1) == [1]

def test_get_odd_collatz_even_number():
    assert get_odd_collatz(2) == [1]
    assert get_odd_collatz(4) == [1]
    assert get_odd_collatz(8) == [1]

def test_get_odd_collatz_odd_number_3():
    result = get_odd_collatz(3)
    assert result == [1, 3, 5]

def test_get_odd_collatz_odd_number_5():
    result = get_odd_collatz(5)
    assert result == [1, 5]

def test_get_odd_collatz_odd_number_7():
    result = get_odd_collatz(7)
    assert result == [1, 5, 7, 11, 13, 17]

def test_get_odd_collatz_even_number_6():
    result = get_odd_collatz(6)
    assert result == [1, 3, 5]

def test_get_odd_collatz_even_number_10():
    result = get_odd_collatz(10)
    assert result == [1, 5]

def test_get_odd_collatz_odd_number_9():
    result = get_odd_collatz(9)
    assert result == [1, 5, 7, 9, 11, 13, 17]

def test_get_odd_collatz_odd_number_11():
    result = get_odd_collatz(11)
    assert result == [1, 5, 11, 13, 17]

def test_get_odd_collatz_even_number_12():
    result = get_odd_collatz(12)
    assert result == [1, 3, 5]

def test_get_odd_collatz_odd_number_13():
    result = get_odd_collatz(13)
    assert result == [1, 5, 13]

def test_get_odd_collatz_odd_number_15():
    result = get_odd_collatz(15)
    assert result == [1, 5, 15, 23, 35, 53]

def test_get_odd_collatz_even_number_16():
    result = get_odd_collatz(16)
    assert result == [1]

def test_get_odd_collatz_large_even():
    result = get_odd_collatz(32)
    assert result == [1]

def test_get_odd_collatz_large_odd():
    result = get_odd_collatz(27)
    expected = [1, 5, 13, 17, 19, 23, 25, 27, 31, 35, 37, 41, 47, 53, 55, 61, 65, 71, 73, 79, 83, 89, 97, 103, 107, 109, 115, 121, 123, 137, 139, 145, 149, 155, 161, 163, 167, 173, 179, 181, 185, 191]
    assert result == expected

@pytest.mark.parametrize("n,expected", [
    (1, [1]),
    (2, [1]),
    (3, [1, 3, 5]),
    (4, [1]),
    (5, [1, 5]),
    (6, [1, 3, 5]),
    (7, [1, 5, 7, 11, 13, 17]),
    (8, [1]),
    (9, [1, 5, 7, 9, 11, 13, 17]),
    (10, [1, 5])
])
def test_get_odd_collatz_parametrized(n, expected):
    assert get_odd_collatz(n) == expected