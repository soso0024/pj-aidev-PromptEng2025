# Test cases for HumanEval/102
# Generated using Claude API


def choose_num(x, y):
    """This function takes two positive numbers x and y and returns the
    biggest even integer number that is in the range [x, y] inclusive. If 
    there's no such number, then the function should return -1.

    For example:
    choose_num(12, 15) = 14
    choose_num(13, 12) = -1
    """

    if x > y:
        return -1
    if y % 2 == 0:
        return y
    if x == y:
        return -1
    return y - 1


# Generated test cases:
import pytest

def choose_num(x, y):
    if x > y:
        return -1
    if y % 2 == 0:
        return y
    if x == y:
        return -1
    return y - 1

@pytest.mark.parametrize("x,y,expected", [
    (1, 2, 2),
    (1, 4, 4),
    (2, 6, 6),
    (0, 8, 8),
    (1, 3, 2),
    (2, 5, 4),
    (3, 7, 6),
    (1, 9, 8),
    (5, 5, -1),
    (3, 3, -1),
    (0, 0, 0),
    (10, 10, 10),
    (5, 3, -1),
    (10, 5, -1),
    (8, 2, -1),
    (100, 50, -1),
    (-1, 1, 0),
    (-5, -2, -2),
    (-3, -1, -2),
    (-10, 0, 0),
    (-2, 2, 2),
    (0, 1, 0),
    (1, 1, -1),
    (2, 2, 2),
    (-1, -1, -1),
    (0, 10, 10),
    (5, 11, 10),
    (10, 20, 20),
    (15, 16, 16),
    (100, 101, 100),
    (99, 100, 100),
    (-100, -99, -100),
    (-50, -48, -48)
])
def test_choose_num(x, y, expected):
    assert choose_num(x, y) == expected

def test_choose_num_edge_cases():
    assert choose_num(0, 1) == 0
    assert choose_num(-1, 0) == 0
    assert choose_num(-2, -1) == -2
    assert choose_num(1000, 1001) == 1000
    assert choose_num(999, 1000) == 1000

def test_choose_num_x_greater_than_y():
    assert choose_num(5, 4) == -1
    assert choose_num(10, 9) == -1
    assert choose_num(1, 0) == -1
    assert choose_num(100, 99) == -1

def test_choose_num_equal_values():
    assert choose_num(1, 1) == -1
    assert choose_num(5, 5) == -1
    assert choose_num(100, 100) == 100
    assert choose_num(-5, -5) == -1

def test_choose_num_y_even():
    assert choose_num(1, 2) == 2
    assert choose_num(5, 10) == 10
    assert choose_num(0, 4) == 4
    assert choose_num(-5, -2) == -2

def test_choose_num_y_odd_x_less_than_y():
    assert choose_num(1, 3) == 2
    assert choose_num(5, 7) == 6
    assert choose_num(0, 9) == 8
    assert choose_num(-5, -3) == -4