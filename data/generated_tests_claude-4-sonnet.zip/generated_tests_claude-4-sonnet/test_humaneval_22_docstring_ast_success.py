# Test cases for HumanEval/22
# Generated using Claude API

from typing import List, Any


def filter_integers(values: List[Any]) -> List[int]:
    """ Filter given list of any python values only for integers
    >>> filter_integers(['a', 3.14, 5])
    [5]
    >>> filter_integers([1, 2, 3, 'abc', {}, []])
    [1, 2, 3]
    """

    return [x for x in values if isinstance(x, int)]


# Generated test cases:
import pytest
from typing import List, Any

def filter_integers(values: List[Any]) -> List[int]:
    return [x for x in values if isinstance(x, int)]

def test_filter_integers_empty_list():
    assert filter_integers([]) == []

def test_filter_integers_only_integers():
    assert filter_integers([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

def test_filter_integers_no_integers():
    assert filter_integers(['a', 'b', 3.14, [], {}]) == []

def test_filter_integers_mixed_types():
    assert filter_integers([1, 'a', 3.14, 5]) == [1, 5]

def test_filter_integers_with_strings():
    assert filter_integers(['hello', 42, 'world', 7]) == [42, 7]

def test_filter_integers_with_floats():
    assert filter_integers([1.5, 2, 3.7, 4]) == [2, 4]

def test_filter_integers_with_booleans():
    assert filter_integers([True, False, 1, 2]) == [True, False, 1, 2]

def test_filter_integers_with_none():
    assert filter_integers([None, 1, None, 2]) == [1, 2]

def test_filter_integers_with_collections():
    assert filter_integers([[], {}, set(), 1, 2]) == [1, 2]

def test_filter_integers_negative_numbers():
    assert filter_integers([-1, -2, 'test', 3]) == [-1, -2, 3]

def test_filter_integers_zero():
    assert filter_integers([0, 'zero', 0.0]) == [0]

def test_filter_integers_large_numbers():
    assert filter_integers([999999999, 'large', 1.0]) == [999999999]

@pytest.mark.parametrize("input_list,expected", [
    (['a', 3.14, 5], [5]),
    ([1, 2, 3, 'abc', {}, []], [1, 2, 3]),
    ([True, 1, False, 2], [True, 1, False, 2]),
    ([1.0, 2.5, 3], [3]),
    (['1', '2', 1, 2], [1, 2])
])
def test_filter_integers_parametrized(input_list, expected):
    assert filter_integers(input_list) == expected