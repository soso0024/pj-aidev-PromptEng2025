# Test cases for HumanEval/51
# Generated using Claude API



def remove_vowels(text):
    """
    remove_vowels is a function that takes string and returns string without vowels.
    >>> remove_vowels('')
    ''
    >>> remove_vowels("abcdef\nghijklm")
    'bcdf\nghjklm'
    >>> remove_vowels('abcdef')
    'bcdf'
    >>> remove_vowels('aaaaa')
    ''
    >>> remove_vowels('aaBAA')
    'B'
    >>> remove_vowels('zbcd')
    'zbcd'
    """

    return "".join([s for s in text if s.lower() not in ["a", "e", "i", "o", "u"]])


# Generated test cases:
import pytest

def remove_vowels(text):
    return "".join([s for s in text if s.lower() not in ["a", "e", "i", "o", "u"]])

@pytest.mark.parametrize("text,expected", [
    ("hello", "hll"),
    ("world", "wrld"),
    ("", ""),
    ("aeiou", ""),
    ("AEIOU", ""),
    ("bcdfg", "bcdfg"),
    ("Hello World", "Hll Wrld"),
    ("Programming", "Prgrmmng"),
    ("12345", "12345"),
    ("!@#$%", "!@#$%"),
    ("a", ""),
    ("A", ""),
    ("b", "b"),
    ("AaEeIiOoUu", ""),
    ("xyz", "xyz"),
    ("The quick brown fox", "Th qck brwn fx"),
    ("aAbBcCdDeE", "bBcCdD"),
    ("   ", "   "),
    ("123aeiou456", "123456"),
    ("MiXeD cAsE", "MXD cs"),
    ("àáâãäåæ", "àáâãäåæ"),
    ("Python is awesome", "Pythn s wsm"),
    ("HELLO WORLD", "HLL WRLD"),
    ("testing123", "tstng123"),
    ("!@#aeiou$%^", "!@#$%^")
])
def test_remove_vowels_parametrized(text, expected):
    assert remove_vowels(text) == expected

def test_remove_vowels_empty_string():
    assert remove_vowels("") == ""

def test_remove_vowels_only_vowels():
    assert remove_vowels("aeiouAEIOU") == ""

def test_remove_vowels_no_vowels():
    assert remove_vowels("bcdfghjklmnpqrstvwxyz") == "bcdfghjklmnpqrstvwxyz"

def test_remove_vowels_mixed_case():
    assert remove_vowels("HeLLo WoRLd") == "HLL WRLd"

def test_remove_vowels_numbers_and_symbols():
    assert remove_vowels("123!@#$%^&*()") == "123!@#$%^&*()"

def test_remove_vowels_whitespace():
    assert remove_vowels("   \t\n") == "   \t\n"

def test_remove_vowels_single_character():
    assert remove_vowels("a") == ""
    assert remove_vowels("b") == "b"

def test_remove_vowels_unicode_vowels():
    assert remove_vowels("café") == "cfé"

def test_remove_vowels_long_string():
    long_text = "This is a very long string with many vowels and consonants mixed together"
    expected = "Ths s  vry lng strng wth mny vwls nd cnsnnts mxd tgthr"
    assert remove_vowels(long_text) == expected