# Test cases for HumanEval/28
# Generated using Claude API

from typing import List


def concatenate(strings: List[str]) -> str:
    """ Concatenate list of strings into a single string
    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """

    return ''.join(strings)


# Generated test cases:
import pytest
from typing import List

def concatenate(strings: List[str]) -> str:
    return ''.join(strings)

def test_concatenate_empty_list():
    assert concatenate([]) == ""

def test_concatenate_single_string():
    assert concatenate(["hello"]) == "hello"

def test_concatenate_multiple_strings():
    assert concatenate(["hello", "world"]) == "helloworld"

def test_concatenate_with_spaces():
    assert concatenate(["hello", " ", "world"]) == "hello world"

def test_concatenate_empty_strings():
    assert concatenate(["", "", ""]) == ""

def test_concatenate_mixed_empty_and_non_empty():
    assert concatenate(["hello", "", "world"]) == "helloworld"

def test_concatenate_special_characters():
    assert concatenate(["!", "@", "#", "$"]) == "!@#$"

def test_concatenate_numbers_as_strings():
    assert concatenate(["1", "2", "3"]) == "123"

def test_concatenate_unicode_strings():
    assert concatenate(["café", "naïve"]) == "cafénaïve"

def test_concatenate_newlines_and_tabs():
    assert concatenate(["line1", "\n", "line2", "\t", "tab"]) == "line1\nline2\ttab"

@pytest.mark.parametrize("input_list,expected", [
    ([], ""),
    (["a"], "a"),
    (["a", "b"], "ab"),
    (["", "test"], "test"),
    (["test", ""], "test"),
    (["hello", " ", "world", "!"], "hello world!"),
    (["1", "2", "3", "4", "5"], "12345")
])
def test_concatenate_parametrized(input_list, expected):
    assert concatenate(input_list) == expected
