# Test cases for HumanEval/82
# Generated using Claude API


def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise
    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """

    l = len(string)
    if l == 0 or l == 1:
        return False
    for i in range(2, l):
        if l % i == 0:
            return False
    return True


# Generated test cases:
import pytest

def prime_length(string):
    l = len(string)
    if l == 0 or l == 1:
        return False
    for i in range(2, l):
        if l % i == 0:
            return False
    return True

def test_prime_length_examples():
    assert prime_length('Hello') == True
    assert prime_length('abcdcba') == True
    assert prime_length('kittens') == True
    assert prime_length('orange') == False

def test_prime_length_empty_string():
    assert prime_length('') == False

def test_prime_length_single_character():
    assert prime_length('a') == False

def test_prime_length_two_characters():
    assert prime_length('ab') == True

def test_prime_length_three_characters():
    assert prime_length('abc') == True

def test_prime_length_four_characters():
    assert prime_length('abcd') == False

def test_prime_length_five_characters():
    assert prime_length('abcde') == True

def test_prime_length_six_characters():
    assert prime_length('abcdef') == False

def test_prime_length_seven_characters():
    assert prime_length('abcdefg') == True

def test_prime_length_eight_characters():
    assert prime_length('abcdefgh') == False

def test_prime_length_nine_characters():
    assert prime_length('abcdefghi') == False

def test_prime_length_ten_characters():
    assert prime_length('abcdefghij') == False

def test_prime_length_eleven_characters():
    assert prime_length('abcdefghijk') == True

def test_prime_length_twelve_characters():
    assert prime_length('abcdefghijkl') == False

def test_prime_length_thirteen_characters():
    assert prime_length('abcdefghijklm') == True

@pytest.mark.parametrize("string,expected", [
    ("", False),
    ("a", False),
    ("ab", True),
    ("abc", True),
    ("abcd", False),
    ("abcde", True),
    ("abcdef", False),
    ("abcdefg", True),
    ("abcdefgh", False),
    ("abcdefghi", False),
    ("abcdefghij", False),
    ("abcdefghijk", True),
    ("abcdefghijkl", False),
    ("abcdefghijklm", True),
    ("abcdefghijklmn", False),
    ("abcdefghijklmno", False),
    ("abcdefghijklmnop", False),
    ("abcdefghijklmnopq", True),
    ("abcdefghijklmnopqr", False),
    ("abcdefghijklmnopqrs", True),
    ("abcdefghijklmnopqrst", False),
    ("abcdefghijklmnopqrstu", False),
    ("abcdefghijklmnopqrstuv", False),
    ("abcdefghijklmnopqrstuvw", True)
])
def test_prime_length_parametrized(string, expected):
    assert prime_length(string) == expected

def test_prime_length_special_characters():
    assert prime_length('!@#') == True
    assert prime_length('!@#$') == False
    assert prime_length('12345') == True

def test_prime_length_whitespace():
    assert prime_length('  ') == True
    assert prime_length('   ') == True
    assert prime_length('    ') == False

def test_prime_length_unicode():
    assert prime_length('αβ') == True
    assert prime_length('αβγ') == True
    assert prime_length('αβγδ') == False
