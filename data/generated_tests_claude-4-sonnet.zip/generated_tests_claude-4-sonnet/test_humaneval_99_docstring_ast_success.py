# Test cases for HumanEval/99
# Generated using Claude API


def closest_integer(value):
    '''
    Create a function that takes a value (string) representing a number
    and returns the closest integer to it. If the number is equidistant
    from two integers, round it away from zero.

    Examples
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15

    Note:
    Rounding away from zero means that if the given number is equidistant
    from two integers, the one you should return is the one that is the
    farthest from zero. For example closest_integer("14.5") should
    return 15 and closest_integer("-14.5") should return -15.
    '''

    from math import floor, ceil

    if value.count('.') == 1:
        # remove trailing zeros
        while (value[-1] == '0'):
            value = value[:-1]

    num = float(value)
    if value[-2:] == '.5':
        if num > 0:
            res = ceil(num)
        else:
            res = floor(num)
    elif len(value) > 0:
        res = int(round(num))
    else:
        res = 0

    return res



# Generated test cases:
import pytest

def closest_integer(value):
    from math import floor, ceil

    if value.count('.') == 1:
        # remove trailing zeros
        while (value[-1] == '0'):
            value = value[:-1]

    num = float(value)
    if value[-2:] == '.5':
        if num > 0:
            res = ceil(num)
        else:
            res = floor(num)
    elif len(value) > 0:
        res = int(round(num))
    else:
        res = 0

    return res

@pytest.mark.parametrize("value,expected", [
    ("10", 10),
    ("15.3", 15),
    ("14.5", 15),
    ("-14.5", -15),
    ("0", 0),
    ("0.0", 0),
    ("1.5", 2),
    ("-1.5", -2),
    ("2.5", 3),
    ("-2.5", -3),
    ("0.5", 1),
    ("-0.5", -1),
    ("10.4", 10),
    ("10.6", 11),
    ("-10.4", -10),
    ("-10.6", -11),
    ("100", 100),
    ("-100", -100),
    ("3.14159", 3),
    ("-3.14159", -3),
    ("2.71828", 3),
    ("-2.71828", -3),
])
def test_closest_integer_basic_cases(value, expected):
    assert closest_integer(value) == expected

@pytest.mark.parametrize("value,expected", [
    ("10.50", 11),
    ("-10.50", -11),
    ("0.50", 1),
    ("-0.50", -1),
    ("1.500", 2),
    ("-1.500", -2),
    ("100.5000", 101),
    ("-100.5000", -101),
])
def test_closest_integer_trailing_zeros(value, expected):
    assert closest_integer(value) == expected

@pytest.mark.parametrize("value,expected", [
    ("0.1", 0),
    ("0.9", 1),
    ("-0.1", 0),
    ("-0.9", -1),
    ("0.49", 0),
    ("0.51", 1),
    ("-0.49", 0),
    ("-0.51", -1),
])
def test_closest_integer_small_decimals(value, expected):
    assert closest_integer(value) == expected

@pytest.mark.parametrize("value,expected", [
    ("999.5", 1000),
    ("-999.5", -1000),
    ("1000.5", 1001),
    ("-1000.5", -1001),
])
def test_closest_integer_large_numbers(value, expected):
    assert closest_integer(value) == expected

@pytest.mark.parametrize("value,expected", [
    ("1", 1),
    ("5", 5),
    ("-1", -1),
    ("-5", -5),
    ("0", 0),
])
def test_closest_integer_integers(value, expected):
    assert closest_integer(value) == expected

@pytest.mark.parametrize("value,expected", [
    ("1.0", 1),
    ("5.0", 5),
    ("-1.0", -1),
    ("-5.0", -5),
    ("0.0", 0),
])
def test_closest_integer_whole_number_decimals(value, expected):
    assert closest_integer(value) == expected