# Test cases for HumanEval/112
# Generated using Claude API


def reverse_delete(s,c):
    """Task
    We are given two strings s and c, you have to deleted all the characters in s that are equal to any character in c
    then check if the result string is palindrome.
    A string is called palindrome if it reads the same backward as forward.
    You should return a tuple containing the result string and True/False for the check.
    Example
    For s = "abcde", c = "ae", the result should be ('bcd',False)
    For s = "abcdef", c = "b"  the result should be ('acdef',False)
    For s = "abcdedcba", c = "ab", the result should be ('cdedc',True)
    """

    s = ''.join([char for char in s if char not in c])
    return (s,s[::-1] == s)


# Generated test cases:
import pytest

def reverse_delete(s,c):
    s = ''.join([char for char in s if char not in c])
    return (s,s[::-1] == s)

def test_basic_functionality():
    result = reverse_delete("abcde", "ae")
    assert result == ("bcd", False)

def test_palindrome_result():
    result = reverse_delete("abcdef", "bdef")
    assert result == ("ac", False)

def test_single_char_palindrome():
    result = reverse_delete("abcde", "bcde")
    assert result == ("a", True)

def test_empty_result():
    result = reverse_delete("abc", "abc")
    assert result == ("", True)

def test_no_deletion():
    result = reverse_delete("abcde", "xyz")
    assert result == ("abcde", False)

def test_empty_string():
    result = reverse_delete("", "abc")
    assert result == ("", True)

def test_empty_chars_to_delete():
    result = reverse_delete("abcde", "")
    assert result == ("abcde", False)

def test_both_empty():
    result = reverse_delete("", "")
    assert result == ("", True)

def test_palindrome_input():
    result = reverse_delete("racecar", "")
    assert result == ("racecar", True)

def test_palindrome_after_deletion():
    result = reverse_delete("abccba", "")
    assert result == ("abccba", True)

def test_single_character():
    result = reverse_delete("a", "")
    assert result == ("a", True)

def test_single_character_deleted():
    result = reverse_delete("a", "a")
    assert result == ("", True)

def test_repeated_characters():
    result = reverse_delete("aaabbbccc", "b")
    assert result == ("aaaccc", False)

def test_all_same_character():
    result = reverse_delete("aaaa", "")
    assert result == ("aaaa", True)

def test_all_same_character_deleted():
    result = reverse_delete("aaaa", "a")
    assert result == ("", True)

@pytest.mark.parametrize("s,c,expected", [
    ("hello", "l", ("heo", False)),
    ("madam", "", ("madam", True)),
    ("python", "pyn", ("tho", False)),
    ("abba", "a", ("bb", True)),
    ("xyz", "xyz", ("", True)),
    ("a", "b", ("a", True)),
    ("ab", "a", ("b", True)),
    ("ba", "a", ("b", True)),
    ("aba", "b", ("aa", True)),
    ("abcba", "c", ("abba", True))
])
def test_parametrized_cases(s, c, expected):
    assert reverse_delete(s, c) == expected

def test_special_characters():
    result = reverse_delete("a!b@c#", "!@#")
    assert result == ("abc", False)

def test_numbers_as_strings():
    result = reverse_delete("12321", "2")
    assert result == ("131", True)

def test_whitespace():
    result = reverse_delete("a b c", " ")
    assert result == ("abc", False)

def test_whitespace_palindrome():
    result = reverse_delete("a b a", " ")
    assert result == ("aba", True)