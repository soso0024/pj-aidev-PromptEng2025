# Test cases for HumanEval/133
# Generated using Claude API



def sum_squares(lst):
    """You are given a list of numbers.
    You need to return the sum of squared numbers in the given list,
    round each element in the list to the upper int(Ceiling) first.
    Examples:
    For lst = [1,2,3] the output should be 14
    For lst = [1,4,9] the output should be 98
    For lst = [1,3,5,7] the output should be 84
    For lst = [1.4,4.2,0] the output should be 29
    For lst = [-2.4,1,1] the output should be 6
    

    """

    import math
    squared = 0
    for i in lst:
        squared += math.ceil(i)**2
    return squared


# Generated test cases:
import pytest
import math

def sum_squares(lst):
    squared = 0
    for i in lst:
        squared += math.ceil(i)**2
    return squared

@pytest.mark.parametrize("lst,expected", [
    ([1, 2, 3], 14),
    ([1, 4, 9], 98),
    ([1, 3, 5, 7], 84),
    ([1.4, 4.2, 0], 29),
    ([-2.4, 1, 1], 6),
    ([], 0),
    ([0], 0),
    ([0, 0, 0], 0),
    ([1], 1),
    ([-1], 1),
    ([1.1], 4),
    ([1.9], 4),
    ([2.0], 4),
    ([2.1], 9),
    ([-1.1], 1),
    ([-1.9], 1),
    ([-2.0], 4),
    ([-2.1], 4),
    ([0.1], 1),
    ([0.9], 1),
    ([-0.1], 0),
    ([-0.9], 0),
    ([5.7, -3.2, 0, 1.1], 49),
    ([10.5, -5.5, 2.2], 155),
    ([-10.1, -5.9, -1.1], 126),
    ([100.1], 10201),
    ([-100.1], 10000)
])
def test_sum_squares(lst, expected):
    assert sum_squares(lst) == expected

def test_sum_squares_empty_list():
    assert sum_squares([]) == 0

def test_sum_squares_single_positive():
    assert sum_squares([3.7]) == 16

def test_sum_squares_single_negative():
    assert sum_squares([-3.7]) == 9

def test_sum_squares_all_zeros():
    assert sum_squares([0, 0.0, -0.0]) == 0

def test_sum_squares_mixed_types():
    assert sum_squares([1, 2.5, 3]) == 19

def test_sum_squares_large_numbers():
    assert sum_squares([999.9, 1000.1]) == 2002001

def test_sum_squares_very_small_positive():
    assert sum_squares([0.001, 0.999]) == 2

def test_sum_squares_very_small_negative():
    assert sum_squares([-0.001, -0.999]) == 0