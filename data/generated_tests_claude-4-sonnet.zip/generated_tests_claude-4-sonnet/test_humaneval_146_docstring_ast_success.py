# Test cases for HumanEval/146
# Generated using Claude API


def specialFilter(nums):
    """Write a function that takes an array of numbers as input and returns 
    the number of elements in the array that are greater than 10 and both 
    first and last digits of a number are odd (1, 3, 5, 7, 9).
    For example:
    specialFilter([15, -73, 14, -15]) => 1 
    specialFilter([33, -2, -3, 45, 21, 109]) => 2
    """

    
    count = 0
    for num in nums:
        if num > 10:
            odd_digits = (1, 3, 5, 7, 9)
            number_as_string = str(num)
            if int(number_as_string[0]) in odd_digits and int(number_as_string[-1]) in odd_digits:
                count += 1
        
    return count 


# Generated test cases:
import pytest

def specialFilter(nums):
    count = 0
    for num in nums:
        if num > 10:
            odd_digits = (1, 3, 5, 7, 9)
            number_as_string = str(num)
            if int(number_as_string[0]) in odd_digits and int(number_as_string[-1]) in odd_digits:
                count += 1
    return count

def test_empty_list():
    assert specialFilter([]) == 0

def test_single_element_valid():
    assert specialFilter([15]) == 1

def test_single_element_invalid_less_than_10():
    assert specialFilter([5]) == 0

def test_single_element_invalid_even_first_digit():
    assert specialFilter([25]) == 0

def test_single_element_invalid_even_last_digit():
    assert specialFilter([12]) == 0

def test_single_element_invalid_both_even():
    assert specialFilter([24]) == 0

def test_example_case_1():
    assert specialFilter([15, -73, 14, -15]) == 1

def test_example_case_2():
    assert specialFilter([33, -2, -3, 45, 21, 109]) == 2

def test_all_valid_numbers():
    assert specialFilter([11, 13, 15, 17, 19, 31, 33, 35, 37, 39]) == 10

def test_all_invalid_numbers():
    assert specialFilter([12, 14, 16, 18, 20, 22, 24, 26, 28]) == 0

def test_numbers_less_than_or_equal_to_10():
    assert specialFilter([1, 3, 5, 7, 9, 10, -5, 0]) == 0

def test_negative_numbers():
    assert specialFilter([-15, -73, -11, -99]) == 0

def test_large_numbers():
    assert specialFilter([111, 333, 555, 777, 999]) == 5

def test_mixed_valid_invalid():
    assert specialFilter([11, 12, 13, 14, 15, 16, 17, 18, 19]) == 5

def test_numbers_with_even_first_digit():
    assert specialFilter([211, 413, 615, 817]) == 0

def test_numbers_with_even_last_digit():
    assert specialFilter([112, 314, 516, 718]) == 0

def test_three_digit_numbers():
    assert specialFilter([135, 357, 579, 791, 913]) == 5

def test_four_digit_numbers():
    assert specialFilter([1357, 3579, 5791, 7913, 9135]) == 5

def test_mixed_digit_lengths():
    assert specialFilter([11, 135, 1357, 13579]) == 4

@pytest.mark.parametrize("nums,expected", [
    ([15, -73, 14, -15], 1),
    ([33, -2, -3, 45, 21, 109], 2),
    ([11, 22, 33, 44, 55], 3),
    ([13, 31, 17, 71, 19, 91], 6),
    ([12, 21, 34, 43, 56, 65], 0),
    ([100, 200, 300, 400, 500], 0),
    ([101, 303, 505, 707, 909], 5)
])
def test_parametrized_cases(nums, expected):
    assert specialFilter(nums) == expected

def test_boundary_values():
    assert specialFilter([10, 11]) == 1

def test_zero_and_negative():
    assert specialFilter([0, -1, -10, -11]) == 0

def test_single_digit_odd_numbers():
    assert specialFilter([1, 3, 5, 7, 9]) == 0

def test_very_large_numbers():
    assert specialFilter([1111111, 3333333, 5555555, 7777777, 9999999]) == 5