# Test cases for HumanEval/31
# Generated using Claude API



def is_prime(n):
    """Return true if a given number is prime, and false otherwise.
    >>> is_prime(6)
    False
    >>> is_prime(101)
    True
    >>> is_prime(11)
    True
    >>> is_prime(13441)
    True
    >>> is_prime(61)
    True
    >>> is_prime(4)
    False
    >>> is_prime(1)
    False
    """

    if n < 2:
        return False
    for k in range(2, n - 1):
        if n % k == 0:
            return False
    return True


# Generated test cases:
import pytest

def is_prime(n):
    if n < 2:
        return False
    for k in range(2, n - 1):
        if n % k == 0:
            return False
    return True

class TestIsPrime:
    
    def test_docstring_examples(self):
        assert is_prime(6) == False
        assert is_prime(101) == True
        assert is_prime(11) == True
        assert is_prime(13441) == True
        assert is_prime(61) == True
        assert is_prime(4) == False
        assert is_prime(1) == False
    
    @pytest.mark.parametrize("n,expected", [
        (0, False),
        (1, False),
        (-1, False),
        (-5, False),
        (-10, False)
    ])
    def test_numbers_less_than_2(self, n, expected):
        assert is_prime(n) == expected
    
    @pytest.mark.parametrize("n,expected", [
        (2, True),
        (3, True),
        (5, True),
        (7, True),
        (11, True),
        (13, True),
        (17, True),
        (19, True),
        (23, True),
        (29, True),
        (31, True),
        (37, True),
        (41, True),
        (43, True),
        (47, True)
    ])
    def test_small_primes(self, n, expected):
        assert is_prime(n) == expected
    
    @pytest.mark.parametrize("n,expected", [
        (4, False),
        (6, False),
        (8, False),
        (9, False),
        (10, False),
        (12, False),
        (14, False),
        (15, False),
        (16, False),
        (18, False),
        (20, False),
        (21, False),
        (22, False),
        (24, False),
        (25, False)
    ])
    def test_small_composites(self, n, expected):
        assert is_prime(n) == expected
    
    @pytest.mark.parametrize("n,expected", [
        (53, True),
        (59, True),
        (61, True),
        (67, True),
        (71, True),
        (73, True),
        (79, True),
        (83, True),
        (89, True),
        (97, True)
    ])
    def test_medium_primes(self, n, expected):
        assert is_prime(n) == expected
    
    @pytest.mark.parametrize("n,expected", [
        (49, False),
        (51, False),
        (55, False),
        (57, False),
        (63, False),
        (65, False),
        (69, False),
        (75, False),
        (77, False),
        (81, False),
        (85, False),
        (87, False),
        (91, False),
        (93, False),
        (95, False)
    ])
    def test_medium_composites(self, n, expected):
        assert is_prime(n) == expected
    
    @pytest.mark.parametrize("n,expected", [
        (100, False),
        (121, False),
        (144, False),
        (169, False),
        (196, False),
        (225, False)
    ])
    def test_perfect_squares(self, n, expected):
        assert is_prime(n) == expected
    
    def test_edge_case_2(self):
        assert is_prime(2) == True
    
    def test_edge_case_3(self):
        assert is_prime(3) == True
