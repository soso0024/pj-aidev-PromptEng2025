# Test cases for HumanEval/64
# Generated using Claude API


FIX = """
Add more test cases.
"""

def vowels_count(s):
    """Write a function vowels_count which takes a string representing
    a word as input and returns the number of vowels in the string.
    Vowels in this case are 'a', 'e', 'i', 'o', 'u'. Here, 'y' is also a
    vowel, but only when it is at the end of the given word.

    Example:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    """

    vowels = "aeiouAEIOU"
    n_vowels = sum(c in vowels for c in s)
    if s[-1] == 'y' or s[-1] == 'Y':
        n_vowels += 1
    return n_vowels


# Generated test cases:
import pytest

def vowels_count(s):
    vowels = "aeiouAEIOU"
    n_vowels = sum(c in vowels for c in s)
    if s and (s[-1] == 'y' or s[-1] == 'Y'):
        n_vowels += 1
    return n_vowels

@pytest.mark.parametrize("input_str,expected", [
    ("abcde", 2),
    ("ACEDY", 3),
    ("", 0),
    ("y", 1),
    ("Y", 1),
    ("bcdfg", 0),
    ("aeiou", 5),
    ("AEIOU", 5),
    ("AeIoU", 5),
    ("happy", 2),
    ("HAPPY", 2),
    ("rhythm", 0),
    ("RHYTHM", 0),
    ("fly", 1),
    ("FLY", 1),
    ("sky", 1),
    ("SKY", 1),
    ("gym", 0),
    ("GYM", 0),
    ("a", 1),
    ("A", 1),
    ("b", 0),
    ("B", 0),
    ("xyz", 0),
    ("XYZ", 0),
    ("beauty", 4),
    ("BEAUTY", 4),
    ("quickly", 3),
    ("QUICKLY", 3),
    ("programming", 3),
    ("PROGRAMMING", 3),
    ("university", 5),
    ("UNIVERSITY", 5),
    ("aeiouaeiou", 10),
    ("AEIOUAEIOU", 10),
    ("bcdfghjklmnpqrstvwxz", 0),
    ("BCDFGHJKLMNPQRSTVWXZ", 0),
    ("yyyyyyy", 1),
    ("YYYYYYY", 1),
    ("ayeyiyoyuy", 6),
    ("AYEYIYOYUY", 6),
    ("123456789", 0),
    ("a1e2i3o4u5", 5),
    ("A1E2I3O4U5", 5),
    ("hello world", 3),
    ("HELLO WORLD", 3),
    ("python", 1),
    ("PYTHON", 1),
    ("mystery", 2),
    ("MYSTERY", 2),
])
def test_vowels_count(input_str, expected):
    assert vowels_count(input_str) == expected

def test_vowels_count_empty_string():
    assert vowels_count("") == 0

def test_vowels_count_single_vowel():
    assert vowels_count("a") == 1
    assert vowels_count("e") == 1
    assert vowels_count("i") == 1
    assert vowels_count("o") == 1
    assert vowels_count("u") == 1

def test_vowels_count_single_consonant():
    assert vowels_count("b") == 0
    assert vowels_count("c") == 0
    assert vowels_count("d") == 0

def test_vowels_count_y_at_end():
    assert vowels_count("happy") == 2
    assert vowels_count("cry") == 1
    assert vowels_count("fly") == 1

def test_vowels_count_y_not_at_end():
    assert vowels_count("yes") == 1
    assert vowels_count("yellow") == 2
    assert vowels_count("gym") == 0

def test_vowels_count_mixed_case():
    assert vowels_count("HeLLo") == 2
    assert vowels_count("WoRLd") == 1
    assert vowels_count("PyThOn") == 1