# Test cases for HumanEval/11
# Generated using Claude API

from typing import List


def string_xor(a: str, b: str) -> str:
    """ Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.
    >>> string_xor('010', '110')
    '100'
    """

    def xor(i, j):
        if i == j:
            return '0'
        else:
            return '1'

    return ''.join(xor(x, y) for x, y in zip(a, b))


# Generated test cases:
import pytest
from typing import List

def string_xor(a: str, b: str) -> str:
    def xor(i, j):
        if i == j:
            return '0'
        else:
            return '1'
    return ''.join(xor(x, y) for x, y in zip(a, b))

def test_string_xor_basic():
    assert string_xor('010', '110') == '100'

def test_string_xor_same_strings():
    assert string_xor('101', '101') == '000'
    assert string_xor('000', '000') == '000'
    assert string_xor('111', '111') == '000'

def test_string_xor_opposite_strings():
    assert string_xor('101', '010') == '111'
    assert string_xor('000', '111') == '111'
    assert string_xor('111', '000') == '111'

def test_string_xor_single_bit():
    assert string_xor('0', '0') == '0'
    assert string_xor('0', '1') == '1'
    assert string_xor('1', '0') == '1'
    assert string_xor('1', '1') == '0'

def test_string_xor_empty_strings():
    assert string_xor('', '') == ''

def test_string_xor_long_strings():
    a = '10101010101010101010'
    b = '01010101010101010101'
    expected = '11111111111111111111'
    assert string_xor(a, b) == expected

def test_string_xor_all_zeros():
    assert string_xor('0000', '0000') == '0000'

def test_string_xor_all_ones():
    assert string_xor('1111', '1111') == '0000'

def test_string_xor_mixed_patterns():
    assert string_xor('1010', '0101') == '1111'
    assert string_xor('1100', '1010') == '0110'
    assert string_xor('0011', '0110') == '0101'

@pytest.mark.parametrize("a,b,expected", [
    ('0', '0', '0'),
    ('0', '1', '1'),
    ('1', '0', '1'),
    ('1', '1', '0'),
    ('00', '00', '00'),
    ('01', '10', '11'),
    ('11', '01', '10'),
    ('101010', '010101', '111111'),
    ('110011', '101010', '011001'),
    ('1111', '0000', '1111'),
    ('0000', '1111', '1111')
])
def test_string_xor_parametrized(a, b, expected):
    assert string_xor(a, b) == expected
