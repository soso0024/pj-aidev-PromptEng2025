# Test cases for HumanEval/29
# Generated using Claude API

from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    """ Filter an input list of strings only for ones that start with a given prefix.
    >>> filter_by_prefix([], 'a')
    []
    >>> filter_by_prefix(['abc', 'bcd', 'cde', 'array'], 'a')
    ['abc', 'array']
    """

    return [x for x in strings if x.startswith(prefix)]


# Generated test cases:
import pytest
from typing import List

def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    return [x for x in strings if x.startswith(prefix)]

def test_filter_by_prefix_empty_list():
    assert filter_by_prefix([], "abc") == []

def test_filter_by_prefix_empty_prefix():
    strings = ["hello", "world", "test"]
    assert filter_by_prefix(strings, "") == ["hello", "world", "test"]

def test_filter_by_prefix_no_matches():
    strings = ["hello", "world", "test"]
    assert filter_by_prefix(strings, "xyz") == []

def test_filter_by_prefix_all_matches():
    strings = ["abc123", "abcdef", "abc"]
    assert filter_by_prefix(strings, "abc") == ["abc123", "abcdef", "abc"]

def test_filter_by_prefix_partial_matches():
    strings = ["apple", "application", "banana", "app", "orange"]
    assert filter_by_prefix(strings, "app") == ["apple", "application", "app"]

def test_filter_by_prefix_case_sensitive():
    strings = ["Hello", "hello", "HELLO", "world"]
    assert filter_by_prefix(strings, "hello") == ["hello"]

def test_filter_by_prefix_single_character():
    strings = ["a", "ab", "abc", "b", "ba"]
    assert filter_by_prefix(strings, "a") == ["a", "ab", "abc"]

def test_filter_by_prefix_exact_match():
    strings = ["test", "testing", "tester", "other"]
    assert filter_by_prefix(strings, "test") == ["test", "testing", "tester"]

def test_filter_by_prefix_longer_prefix_than_strings():
    strings = ["a", "ab", "abc"]
    assert filter_by_prefix(strings, "abcdef") == []

def test_filter_by_prefix_special_characters():
    strings = ["@test", "@testing", "#test", "test@"]
    assert filter_by_prefix(strings, "@") == ["@test", "@testing"]

def test_filter_by_prefix_numbers():
    strings = ["123abc", "123def", "456ghi", "123"]
    assert filter_by_prefix(strings, "123") == ["123abc", "123def", "123"]

def test_filter_by_prefix_whitespace():
    strings = [" hello", " world", "hello ", "test"]
    assert filter_by_prefix(strings, " ") == [" hello", " world"]

def test_filter_by_prefix_unicode():
    strings = ["café", "cafeteria", "car", "café123"]
    assert filter_by_prefix(strings, "café") == ["café", "café123"]

@pytest.mark.parametrize("strings,prefix,expected", [
    (["test", "testing", "other"], "test", ["test", "testing"]),
    (["", "a", "ab"], "", ["", "a", "ab"]),
    (["hello"], "hello", ["hello"]),
    (["hello"], "hello world", []),
    (["a", "b", "c"], "d", [])
])
def test_filter_by_prefix_parametrized(strings, prefix, expected):
    assert filter_by_prefix(strings, prefix) == expected
