# Test cases for HumanEval/118
# Generated using Claude API


def get_closest_vowel(word):
    """You are given a word. Your task is to find the closest vowel that stands between 
    two consonants from the right side of the word (case sensitive).
    
    Vowels in the beginning and ending doesn't count. Return empty string if you didn't
    find any vowel met the above condition. 

    You may assume that the given string contains English letter only.

    Example:
    get_closest_vowel("yogurt") ==> "u"
    get_closest_vowel("FULL") ==> "U"
    get_closest_vowel("quick") ==> ""
    get_closest_vowel("ab") ==> ""
    """

    if len(word) < 3:
        return ""

    vowels = {"a", "e", "i", "o", "u", "A", "E", 'O', 'U', 'I'}
    for i in range(len(word)-2, 0, -1):
        if word[i] in vowels:
            if (word[i+1] not in vowels) and (word[i-1] not in vowels):
                return word[i]
    return ""


# Generated test cases:
import pytest

def get_closest_vowel(word):
    if len(word) < 3:
        return ""

    vowels = {"a", "e", "i", "o", "u", "A", "E", 'O', 'U', 'I'}
    for i in range(len(word)-2, 0, -1):
        if word[i] in vowels:
            if (word[i+1] not in vowels) and (word[i-1] not in vowels):
                return word[i]
    return ""

@pytest.mark.parametrize("word,expected", [
    ("", ""),
    ("a", ""),
    ("ab", ""),
    ("abc", ""),
    ("bac", "a"),
    ("cat", "a"),
    ("dog", "o"),
    ("hello", "e"),
    ("world", "o"),
    ("python", "o"),
    ("beautiful", "u"),
    ("programming", "i"),
    ("test", "e"),
    ("example", "a"),
    ("computer", "e"),
    ("keyboard", "e"),
    ("mouse", ""),
    ("screen", ""),
    ("window", "o"),
    ("application", "a"),
    ("HELLO", "E"),
    ("WORLD", "O"),
    ("PYTHON", "O"),
    ("BEAUTIFUL", "U"),
    ("PROGRAMMING", "I"),
    ("TEST", "E"),
    ("EXAMPLE", "A"),
    ("COMPUTER", "E"),
    ("KEYBOARD", "E"),
    ("MOUSE", ""),
    ("SCREEN", ""),
    ("WINDOW", "O"),
    ("APPLICATION", "A"),
    ("MiXeD", "e"),
    ("CaSe", "a"),
    ("tEsT", "E"),
    ("aaa", ""),
    ("eee", ""),
    ("iii", ""),
    ("ooo", ""),
    ("uuu", ""),
    ("AAA", ""),
    ("EEE", ""),
    ("III", ""),
    ("OOO", ""),
    ("UUU", ""),
    ("aei", ""),
    ("aou", ""),
    ("eiu", ""),
    ("bcdfg", ""),
    ("xyz", ""),
    ("qwrty", ""),
    ("bcdfghjklmnpqrstvwxyz", ""),
    ("bcd", ""),
    ("fgh", ""),
    ("jkl", ""),
    ("mnp", ""),
    ("qrs", ""),
    ("tvw", ""),
    ("xyz", ""),
    ("bat", "a"),
    ("bet", "e"),
    ("bit", "i"),
    ("bot", "o"),
    ("but", "u"),
    ("BAT", "A"),
    ("BET", "E"),
    ("BIT", "I"),
    ("BOT", "O"),
    ("BUT", "U"),
    ("table", "a"),
    ("stable", "a"),
    ("enable", "a"),
    ("disable", "a"),
    ("trouble", ""),
    ("double", ""),
    ("bubble", "u"),
    ("rubble", "u"),
    ("pebble", "e"),
    ("babble", "a"),
    ("gabble", "a"),
    ("rabble", "a"),
    ("dabble", "a"),
    ("hobble", "o"),
    ("gobble", "o"),
    ("wobble", "o"),
    ("cobble", "o"),
    ("bobble", "o"),
    ("nibble", "i"),
    ("dibble", "i"),
    ("gibble", "i"),
    ("ribble", "i"),
    ("tibble", "i"),
    ("hubble", "u"),
    ("rubble", "u"),
    ("bubble", "u"),
    ("dubble", "u"),
    ("gubble", "u"),
    ("ebble", ""),
    ("abble", ""),
    ("ibble", ""),
    ("obble", ""),
    ("ubble", ""),
    ("consonant", "a"),
    ("strength", "e"),
    ("through", ""),
    ("thought", ""),
    ("brought", ""),
    ("caught", ""),
    ("taught", ""),
    ("daughter", "e"),
    ("laughter", "e"),
    ("slaughter", "e"),
    ("naughty", ""),
    ("aughty", ""),
    ("aughty", ""),
    ("ghty", ""),
    ("hty", ""),
    ("ty", ""),
    ("y", ""),
    ("rhythm", ""),
    ("gym", ""),
    ("fly", ""),
    ("try", ""),
    ("cry", ""),
    ("dry", ""),
    ("fry", ""),
    ("pry", ""),
    ("shy", ""),
    ("sky", ""),
    ("spy", ""),
    ("sly", ""),
    ("why", ""),
    ("buy", "u"),
    ("guy", "u"),
    ("bay", "a"),
    ("day", "a"),
    ("hay", "a"),
    ("jay", "a"),
    ("kay", "a"),
    ("lay", "a"),
    ("may", "a"),
    ("nay", "a"),
    ("pay", "a"),
    ("ray", "a"),
    ("say", "a"),
    ("way", "a"),
    ("boy", "o"),
    ("coy", "o"),
    ("joy", "o"),
    ("roy", "o"),
    ("soy", "o"),
    ("toy", "o"),
])
def test_get_closest_vowel(word, expected):
    assert get_closest_vowel(word) == expected

def test_empty_string():
    assert get_closest_vowel("") == ""

def test_single_character():
    assert get_closest_vowel("a") == ""
    assert get_closest_vowel("b") == ""
    assert get_closest_vowel("z") == ""

def test_two_characters():
    assert get_closest_vowel("ab") == ""
    assert get_closest_vowel("ba") == ""
    assert get_closest_vowel("ae") == ""
    assert get_closest_vowel("ea") == ""

def test_three_characters_no_vowel():
    assert get_closest_vowel("bcd") == ""
    assert get_closest_vowel("xyz") == ""

def test_three_characters_all_vowels():
    assert get_closest_vowel("aei") == ""
    assert get_closest_vowel("aou") == ""

def test_vowel_between_consonants():
    assert get_closest_vowel("bat") == "a"
    assert get_closest_vowel("bet") == "e"
    assert get_closest_vowel("bit") == "i"
    assert get_closest_vowel("bot") == "o"
    assert get_closest_vowel("but") == "u"

def test_multiple_valid_vowels():
    assert get_closest_vowel("table") == "a"
    assert get_closest_vowel("stable") == "a"

def test_case_sensitivity():
    assert get_closest_vowel("BAT") == "A"
    assert get_closest_vowel("BET") == "E"
    assert get_closest_vowel("BIT") == "I"
    assert get_closest_vowel("BOT") == "O"
    assert get_closest_vowel("BUT") == "U"

def test_mixed_case():
    assert get_closest_vowel("MiXeD") == "e"
    assert get_closest_vowel("CaSe") == "a"

def test_long_words():
    assert get_closest_vowel("programming") == "i"
    assert get_closest_vowel("application") == "a"
    assert get_closest_vowel("beautiful") == "u"