# Test cases for HumanEval/117
# Generated using Claude API


def select_words(s, n):
    """Given a string s and a natural number n, you have been tasked to implement 
    a function that returns a list of all words from string s that contain exactly 
    n consonants, in order these words appear in the string s.
    If the string s is empty then the function should return an empty list.
    Note: you may assume the input string contains only letters and spaces.
    Examples:
    select_words("Mary had a little lamb", 4) ==> ["little"]
    select_words("Mary had a little lamb", 3) ==> ["Mary", "lamb"]
    select_words("simple white space", 2) ==> []
    select_words("Hello world", 4) ==> ["world"]
    select_words("Uncle sam", 3) ==> ["Uncle"]
    """

    result = []
    for word in s.split():
        n_consonants = 0
        for i in range(0, len(word)):
            if word[i].lower() not in ["a","e","i","o","u"]:
                n_consonants += 1 
        if n_consonants == n:
            result.append(word)
    return result



# Generated test cases:
import pytest

def select_words(s, n):
    result = []
    for word in s.split():
        n_consonants = 0
        for i in range(0, len(word)):
            if word[i].lower() not in ["a","e","i","o","u"]:
                n_consonants += 1 
        if n_consonants == n:
            result.append(word)
    return result

@pytest.mark.parametrize("s,n,expected", [
    ("Mary had a little lamb", 4, ["little"]),
    ("Mary had a little lamb", 3, ["Mary", "lamb"]),
    ("simple white space", 2, []),
    ("Hello world", 4, ["world"]),
    ("Uncle sam", 3, ["Uncle"]),
    ("", 0, []),
    ("", 1, []),
    ("", 5, []),
    ("a", 0, ["a"]),
    ("a", 1, []),
    ("b", 1, ["b"]),
    ("b", 0, []),
    ("aeiou", 0, ["aeiou"]),
    ("bcdfg", 5, ["bcdfg"]),
    ("AEIOU", 0, ["AEIOU"]),
    ("BCDFG", 5, ["BCDFG"]),
    ("AeIoU", 0, ["AeIoU"]),
    ("BcDfG", 5, ["BcDfG"]),
    ("a e i o u", 0, ["a", "e", "i", "o", "u"]),
    ("b c d f g", 1, ["b", "c", "d", "f", "g"]),
    ("hello", 3, ["hello"]),
    ("hello", 2, []),
    ("hello", 0, []),
    ("programming", 7, ["programming"]),
    ("programming", 6, []),
    ("test case", 2, ["case"]),
    ("test case", 3, ["test"]),
    ("xyz abc def", 3, ["xyz"]),
    ("aaa bbb ccc", 3, ["bbb", "ccc"]),
    ("single", 4, ["single"]),
    ("multiple words here", 1, []),
    ("multiple words here", 2, ["here"]),
    ("multiple words here", 4, ["words"]),
    ("   ", 0, []),
    ("a   b", 0, ["a"]),
    ("a   b", 1, ["b"]),
    ("Python is great", 3, ["great"]),
    ("Python is great", 2, []),
    ("Python is great", 4, []),
    ("consonants vowels", 7, ["consonants"]),
    ("consonants vowels", 4, ["vowels"]),
    ("z", 1, ["z"]),
    ("zz", 2, ["zz"]),
    ("zzz", 3, ["zzz"]),
    ("testing one two three", 1, ["one"]),
    ("testing one two three", 2, ["two"]),
    ("testing one two three", 4, []),
    ("testing one two three", 3, ["three"]),
])
def test_select_words(s, n, expected):
    assert select_words(s, n) == expected

def test_empty_string():
    assert select_words("", 0) == []
    assert select_words("", 10) == []

def test_single_vowel():
    assert select_words("a", 0) == ["a"]
    assert select_words("e", 0) == ["e"]
    assert select_words("i", 0) == ["i"]
    assert select_words("o", 0) == ["o"]
    assert select_words("u", 0) == ["u"]

def test_single_consonant():
    assert select_words("b", 1) == ["b"]
    assert select_words("z", 1) == ["z"]
    assert select_words("m", 1) == ["m"]

def test_case_insensitive():
    assert select_words("A", 0) == ["A"]
    assert select_words("B", 1) == ["B"]
    assert select_words("Hello", 3) == ["Hello"]
    assert select_words("HELLO", 3) == ["HELLO"]

def test_zero_consonants():
    assert select_words("a e i o u", 0) == ["a", "e", "i", "o", "u"]
    assert select_words("aeiou", 0) == ["aeiou"]

def test_large_n():
    assert select_words("hello world", 100) == []
    assert select_words("test", 50) == []