# Test cases for HumanEval/48
# Generated using Claude API



def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """

    for i in range(len(text)):
        if text[i] != text[len(text) - 1 - i]:
            return False
    return True


# Generated test cases:
import pytest

def is_palindrome(text: str):
    for i in range(len(text)):
        if text[i] != text[len(text) - 1 - i]:
            return False
    return True

@pytest.mark.parametrize("text,expected", [
    ("", True),
    ("a", True),
    ("aa", True),
    ("aba", True),
    ("abba", True),
    ("racecar", True),
    ("madam", True),
    ("A man a plan a canal Panama", False),
    ("race a car", False),
    ("ab", False),
    ("abc", False),
    ("abcd", False),
    ("hello", False),
    ("12321", True),
    ("12345", False),
    ("1", True),
    ("121", True),
    ("123", False),
    ("AbA", True),
    ("AaA", True),
    ("aAa", True),
    ("Aa", False),
    ("aA", False),
    ("   ", True),
    ("a a", True),
    (" a ", True),
    ("!@#@!", True),
    ("!@#$%", False),
    ("abcdefghijklmnopqrstuvwxyzzyxwvutsrqponmlkjihgfedcba", True),
    ("abcdefghijklmnopqrstuvwxyzayxwvutsrqponmlkjihgfedcba", False)
])
def test_is_palindrome(text, expected):
    assert is_palindrome(text) == expected

def test_is_palindrome_empty_string():
    assert is_palindrome("") == True

def test_is_palindrome_single_character():
    assert is_palindrome("x") == True

def test_is_palindrome_case_sensitive():
    assert is_palindrome("Aa") == False
    assert is_palindrome("AaA") == True

def test_is_palindrome_with_spaces():
    assert is_palindrome("a a") == True
    assert is_palindrome(" ") == True

def test_is_palindrome_numeric_strings():
    assert is_palindrome("12321") == True
    assert is_palindrome("12345") == False

def test_is_palindrome_special_characters():
    assert is_palindrome("!@#@!") == True
    assert is_palindrome("!@#$!") == False