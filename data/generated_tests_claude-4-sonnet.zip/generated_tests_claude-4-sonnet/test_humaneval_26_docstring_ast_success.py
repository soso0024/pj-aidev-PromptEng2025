# Test cases for HumanEval/26
# Generated using Claude API

from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    """ From a list of integers, remove all elements that occur more than once.
    Keep order of elements left the same as in the input.
    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """

    import collections
    c = collections.Counter(numbers)
    return [n for n in numbers if c[n] <= 1]


# Generated test cases:
import pytest
from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    import collections
    c = collections.Counter(numbers)
    return [n for n in numbers if c[n] <= 1]


def test_remove_duplicates_basic():
    assert remove_duplicates([1, 2, 3, 2, 4]) == [1, 3, 4]


def test_remove_duplicates_empty_list():
    assert remove_duplicates([]) == []


def test_remove_duplicates_single_element():
    assert remove_duplicates([5]) == [5]


def test_remove_duplicates_no_duplicates():
    assert remove_duplicates([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]


def test_remove_duplicates_all_duplicates():
    assert remove_duplicates([1, 1, 2, 2, 3, 3]) == []


def test_remove_duplicates_multiple_duplicates():
    assert remove_duplicates([1, 2, 1, 3, 2, 4, 1]) == [3, 4]


def test_remove_duplicates_preserve_order():
    assert remove_duplicates([5, 1, 3, 1, 2, 3, 4]) == [5, 2, 4]


def test_remove_duplicates_negative_numbers():
    assert remove_duplicates([-1, -2, -1, 0, -2]) == [0]


def test_remove_duplicates_mixed_positive_negative():
    assert remove_duplicates([-1, 1, -1, 2, 1, 3]) == [2, 3]


def test_remove_duplicates_zeros():
    assert remove_duplicates([0, 0, 1, 2]) == [1, 2]


def test_remove_duplicates_large_numbers():
    assert remove_duplicates([1000000, 999999, 1000000, 888888]) == [999999, 888888]


def test_remove_duplicates_three_occurrences():
    assert remove_duplicates([1, 2, 1, 3, 1, 4]) == [2, 3, 4]


def test_remove_duplicates_consecutive_duplicates():
    assert remove_duplicates([1, 1, 2, 3, 3, 4]) == [2, 4]


@pytest.mark.parametrize("input_list,expected", [
    ([1, 2, 3, 2, 4], [1, 3, 4]),
    ([], []),
    ([1], [1]),
    ([1, 1], []),
    ([1, 2, 3], [1, 2, 3]),
    ([5, 5, 5, 5], []),
    ([1, 2, 1, 2, 3], [3])
])
def test_remove_duplicates_parametrized(input_list, expected):
    assert remove_duplicates(input_list) == expected
