# Test cases for HumanEval/10
# Generated using Claude API



def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """ Find the shortest palindrome that begins with a supplied string.
    Algorithm idea is simple:
    - Find the longest postfix of supplied string that is a palindrome.
    - Append to the end of the string reverse of a string prefix that comes before the palindromic suffix.
    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    """

    if not string:
        return ''

    beginning_of_suffix = 0

    while not is_palindrome(string[beginning_of_suffix:]):
        beginning_of_suffix += 1

    return string + string[:beginning_of_suffix][::-1]


# Generated test cases:
import pytest

def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]

def make_palindrome(string: str) -> str:
    """ Find the shortest palindrome that begins with a supplied string.
    Algorithm idea is simple:
    - Find the longest postfix of supplied string that is a palindrome.
    - Append to the end of the string reverse of a string prefix that comes before the palindromic suffix.
    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    """
    if not string:
        return ''

    beginning_of_suffix = 0

    while not is_palindrome(string[beginning_of_suffix:]):
        beginning_of_suffix += 1

    return string + string[:beginning_of_suffix][::-1]

class TestIsPalindrome:
    def test_empty_string(self):
        assert is_palindrome("") == True
    
    def test_single_character(self):
        assert is_palindrome("a") == True
    
    def test_two_character_palindrome(self):
        assert is_palindrome("aa") == True
    
    def test_two_character_not_palindrome(self):
        assert is_palindrome("ab") == False
    
    def test_odd_length_palindrome(self):
        assert is_palindrome("racecar") == True
    
    def test_even_length_palindrome(self):
        assert is_palindrome("abba") == True
    
    def test_not_palindrome(self):
        assert is_palindrome("hello") == False
    
    def test_case_sensitive(self):
        assert is_palindrome("Aa") == False
    
    def test_with_spaces(self):
        assert is_palindrome("a a") == True
    
    def test_with_numbers(self):
        assert is_palindrome("12321") == True
    
    def test_with_special_characters(self):
        assert is_palindrome("!@#@!") == True

class TestMakePalindrome:
    def test_empty_string(self):
        assert make_palindrome("") == ""
    
    def test_single_character(self):
        assert make_palindrome("a") == "a"
    
    def test_already_palindrome_single(self):
        assert make_palindrome("a") == "a"
    
    def test_already_palindrome_multiple(self):
        assert make_palindrome("aba") == "aba"
    
    def test_already_palindrome_even(self):
        assert make_palindrome("abba") == "abba"
    
    def test_cat_example(self):
        assert make_palindrome("cat") == "catac"
    
    def test_cata_example(self):
        assert make_palindrome("cata") == "catac"
    
    def test_two_characters(self):
        assert make_palindrome("ab") == "aba"
    
    def test_three_characters_no_palindrome_suffix(self):
        assert make_palindrome("abc") == "abcba"
    
    def test_with_repeated_characters(self):
        assert make_palindrome("aab") == "aabaa"
    
    def test_long_string(self):
        assert make_palindrome("abcdef") == "abcdefedcba"
    
    def test_string_ending_with_palindrome(self):
        assert make_palindrome("xyzaa") == "xyzaazyx"
    
    def test_string_with_middle_palindrome(self):
        assert make_palindrome("ababa") == "ababa"
    
    def test_numbers(self):
        assert make_palindrome("123") == "12321"
    
    def test_mixed_characters(self):
        assert make_palindrome("a1b") == "a1b1a"
    
    @pytest.mark.parametrize("input_str,expected", [
        ("", ""),
        ("a", "a"),
        ("ab", "aba"),
        ("abc", "abcba"),
        ("cat", "catac"),
        ("cata", "catac"),
        ("racecar", "racecar"),
        ("abba", "abba"),
        ("x", "x"),
        ("xy", "xyx"),
        ("xyz", "xyzyx")
    ])
    def test_parametrized_cases(self, input_str, expected):
        assert make_palindrome(input_str) == expected
    
    def test_result_is_palindrome(self):
        test_cases = ["", "a", "ab", "abc", "cat", "hello", "world", "test123"]
        for test_case in test_cases:
            result = make_palindrome(test_case)
            assert is_palindrome(result), f"Result '{result}' for input '{test_case}' is not a palindrome"
    
    def test_result_starts_with_input(self):
        test_cases = ["", "a", "ab", "abc", "cat", "hello", "world", "test123"]
        for test_case in test_cases:
            result = make_palindrome(test_case)
            assert result.startswith(test_case), f"Result '{result}' does not start with input '{test_case}'"
