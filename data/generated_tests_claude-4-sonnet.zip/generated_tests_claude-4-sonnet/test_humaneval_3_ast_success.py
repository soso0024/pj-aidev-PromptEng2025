# Test cases for HumanEval/3
# Generated using Claude API

from typing import List


def below_zero(operations: List[int]) -> bool:
    """ You're given a list of deposit and withdrawal operations on a bank account that starts with
    zero balance. Your task is to detect if at any point the balance of account fallls below zero, and
    at that point function should return True. Otherwise it should return False.
    >>> below_zero([1, 2, 3])
    False
    >>> below_zero([1, 2, -4, 5])
    True
    """

    balance = 0

    for op in operations:
        balance += op
        if balance < 0:
            return True

    return False


# Generated test cases:
import pytest
from typing import List

def below_zero(operations: List[int]) -> bool:
    balance = 0

    for op in operations:
        balance += op
        if balance < 0:
            return True

    return False

def test_empty_list():
    assert below_zero([]) == False

def test_single_positive():
    assert below_zero([5]) == False

def test_single_negative():
    assert below_zero([-5]) == True

def test_single_zero():
    assert below_zero([0]) == False

def test_never_goes_below_zero():
    assert below_zero([1, 2, 3, 4, 5]) == False

def test_goes_below_zero_immediately():
    assert below_zero([-1]) == True

def test_goes_below_zero_after_operations():
    assert below_zero([5, -3, -4]) == True

def test_reaches_zero_but_not_below():
    assert below_zero([5, -5]) == False

def test_goes_below_then_recovers():
    assert below_zero([10, -15, 20]) == True

def test_multiple_zeros():
    assert below_zero([0, 0, 0]) == False

def test_alternating_positive_negative_never_below():
    assert below_zero([1, -1, 2, -2, 3, -3]) == False

def test_alternating_positive_negative_goes_below():
    assert below_zero([1, -2, 3, -4]) == True

def test_large_positive_then_negative():
    assert below_zero([1000, -1001]) == True

def test_large_numbers_never_below():
    assert below_zero([1000, -500, -499]) == False

@pytest.mark.parametrize("operations,expected", [
    ([1, 2, 3], False),
    ([-1, -2, -3], True),
    ([10, -5, -3, -1], False),
    ([5, -2, -2, -1], False),
    ([0, 1, -1, 0], False),
    ([2, -3, 2], True),
    ([100, -50, -49], False),
    ([100, -50, -51], True)
])
def test_parametrized_cases(operations, expected):
    assert below_zero(operations) == expected