# Test cases for HumanEval/57
# Generated using Claude API



def monotonic(l: list):
    """Return True is list elements are monotonically increasing or decreasing.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """

    if l == sorted(l) or l == sorted(l, reverse=True):
        return True
    return False


# Generated test cases:
import pytest

def monotonic(l: list):
    if l == sorted(l) or l == sorted(l, reverse=True):
        return True
    return False

def test_monotonic_empty_list():
    assert monotonic([]) == True

def test_monotonic_single_element():
    assert monotonic([5]) == True

def test_monotonic_two_elements_ascending():
    assert monotonic([1, 2]) == True

def test_monotonic_two_elements_descending():
    assert monotonic([2, 1]) == True

def test_monotonic_two_elements_equal():
    assert monotonic([1, 1]) == True

def test_monotonic_ascending_sequence():
    assert monotonic([1, 2, 3, 4, 5]) == True

def test_monotonic_descending_sequence():
    assert monotonic([5, 4, 3, 2, 1]) == True

def test_monotonic_all_equal():
    assert monotonic([3, 3, 3, 3]) == True

def test_monotonic_non_monotonic():
    assert monotonic([1, 3, 2]) == False

def test_monotonic_up_then_down():
    assert monotonic([1, 2, 3, 2, 1]) == False

def test_monotonic_down_then_up():
    assert monotonic([3, 2, 1, 2, 3]) == False

def test_monotonic_mixed_pattern():
    assert monotonic([1, 5, 2, 8, 3]) == False

def test_monotonic_ascending_with_duplicates():
    assert monotonic([1, 1, 2, 2, 3, 3]) == True

def test_monotonic_descending_with_duplicates():
    assert monotonic([3, 3, 2, 2, 1, 1]) == True

def test_monotonic_negative_numbers_ascending():
    assert monotonic([-5, -3, -1, 0, 2]) == True

def test_monotonic_negative_numbers_descending():
    assert monotonic([2, 0, -1, -3, -5]) == True

def test_monotonic_negative_numbers_mixed():
    assert monotonic([-1, -5, -2]) == False

def test_monotonic_floats_ascending():
    assert monotonic([1.1, 2.2, 3.3]) == True

def test_monotonic_floats_descending():
    assert monotonic([3.3, 2.2, 1.1]) == True

def test_monotonic_floats_mixed():
    assert monotonic([1.1, 3.3, 2.2]) == False

@pytest.mark.parametrize("input_list,expected", [
    ([], True),
    ([1], True),
    ([1, 2], True),
    ([2, 1], True),
    ([1, 1], True),
    ([1, 2, 3], True),
    ([3, 2, 1], True),
    ([1, 3, 2], False),
    ([1, 2, 2, 3], True),
    ([3, 2, 2, 1], True),
    ([1, 2, 1, 3], False),
    ([0, 0, 0], True),
    ([-1, 0, 1], True),
    ([1, 0, -1], True),
    ([1, -1, 0], False)
])
def test_monotonic_parametrized(input_list, expected):
    assert monotonic(input_list) == expected
