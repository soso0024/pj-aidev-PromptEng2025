# Test cases for HumanEval/7
# Generated using Claude API

from typing import List


def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """ Filter an input list of strings only for ones that contain given substring
    >>> filter_by_substring([], 'a')
    []
    >>> filter_by_substring(['abc', 'bacd', 'cde', 'array'], 'a')
    ['abc', 'bacd', 'array']
    """

    return [x for x in strings if substring in x]


# Generated test cases:
import pytest
from typing import List

def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    return [x for x in strings if substring in x]

def test_empty_list():
    assert filter_by_substring([], 'a') == []

def test_empty_substring():
    assert filter_by_substring(['abc', 'def', 'ghi'], '') == ['abc', 'def', 'ghi']

def test_no_matches():
    assert filter_by_substring(['abc', 'def', 'ghi'], 'xyz') == []

def test_all_matches():
    assert filter_by_substring(['abc', 'bac', 'cab'], 'a') == ['abc', 'bac', 'cab']

def test_partial_matches():
    assert filter_by_substring(['abc', 'bacd', 'cde', 'array'], 'a') == ['abc', 'bacd', 'array']

def test_case_sensitive():
    assert filter_by_substring(['ABC', 'abc', 'Abc'], 'a') == ['abc']

def test_single_character_strings():
    assert filter_by_substring(['a', 'b', 'c'], 'a') == ['a']

def test_substring_longer_than_strings():
    assert filter_by_substring(['a', 'ab', 'abc'], 'abcd') == []

def test_exact_matches():
    assert filter_by_substring(['hello', 'world', 'hello'], 'hello') == ['hello', 'hello']

def test_substring_at_beginning():
    assert filter_by_substring(['prefix_test', 'test_suffix', 'middle_test_middle'], 'prefix') == ['prefix_test']

def test_substring_at_end():
    assert filter_by_substring(['test_suffix', 'prefix_test', 'middle_test_middle'], 'suffix') == ['test_suffix']

def test_substring_in_middle():
    assert filter_by_substring(['prefix_middle_suffix', 'other'], 'middle') == ['prefix_middle_suffix']

def test_special_characters():
    assert filter_by_substring(['hello@world', 'test#123', 'normal'], '@') == ['hello@world']

def test_numbers_in_strings():
    assert filter_by_substring(['abc123', 'def456', 'ghi'], '123') == ['abc123']

def test_whitespace_substring():
    assert filter_by_substring(['hello world', 'helloworld', 'test space'], ' ') == ['hello world', 'test space']

def test_repeated_substring():
    assert filter_by_substring(['abcabc', 'defdef', 'ghighi'], 'abc') == ['abcabc']

@pytest.mark.parametrize("strings,substring,expected", [
    ([], 'test', []),
    (['a', 'b', 'c'], '', ['a', 'b', 'c']),
    (['hello', 'world'], 'o', ['hello', 'world']),
    (['python', 'java', 'javascript'], 'java', ['java', 'javascript']),
    (['ABC', 'abc', 'AbC'], 'A', ['ABC', 'AbC'])
])
def test_parametrized_cases(strings, substring, expected):
    assert filter_by_substring(strings, substring) == expected
