# Test cases for HumanEval/98
# Generated using Claude API


def count_upper(s):
    """
    Given a string s, count the number of uppercase vowels in even indices.
    
    For example:
    count_upper('aBCdEf') returns 1
    count_upper('abcdefg') returns 0
    count_upper('dBBE') returns 0
    """

    count = 0
    for i in range(0,len(s),2):
        if s[i] in "AEIOU":
            count += 1
    return count


# Generated test cases:
import pytest

def count_upper(s):
    count = 0
    for i in range(0,len(s),2):
        if s[i] in "AEIOU":
            count += 1
    return count

@pytest.mark.parametrize("input_str,expected", [
    ("aBCdEf", 1),
    ("abcdefg", 0),
    ("dBBE", 0),
    ("", 0),
    ("A", 1),
    ("a", 0),
    ("AE", 1),
    ("aE", 0),
    ("AEIOU", 3),
    ("aeiou", 0),
    ("AeIoU", 3),
    ("aEiOu", 0),
    ("ABCDEFGHIJKLMNOPQRSTUVWXYZ", 5),
    ("abcdefghijklmnopqrstuvwxyz", 0),
    ("AxExIxOxU", 5),
    ("xAxExIxOxU", 0),
    ("UOIEAuoiea", 3),
    ("uOiEaUoIeA", 0),
    ("123A456E789I", 0),
    ("1A3E5I7O9U", 0),
    ("!@#A$%^E&*(I", 0),
    ("B", 0),
    ("b", 0),
    ("AA", 1),
    ("AAA", 2),
    ("AAAA", 2),
    ("AAAAA", 3),
    ("bcdfg", 0),
    ("BCDFG", 0),
    ("AaBbCcDdEe", 2),
    ("aAbBcCdDeE", 0)
])
def test_count_upper_parametrized(input_str, expected):
    assert count_upper(input_str) == expected

def test_count_upper_empty_string():
    assert count_upper("") == 0

def test_count_upper_single_uppercase_vowel():
    assert count_upper("A") == 1
    assert count_upper("E") == 1
    assert count_upper("I") == 1
    assert count_upper("O") == 1
    assert count_upper("U") == 1

def test_count_upper_single_lowercase_vowel():
    assert count_upper("a") == 0
    assert count_upper("e") == 0
    assert count_upper("i") == 0
    assert count_upper("o") == 0
    assert count_upper("u") == 0

def test_count_upper_single_consonant():
    assert count_upper("B") == 0
    assert count_upper("b") == 0

def test_count_upper_only_uppercase_vowels():
    assert count_upper("AEIOU") == 3
    assert count_upper("UOIEA") == 3

def test_count_upper_only_lowercase_vowels():
    assert count_upper("aeiou") == 0
    assert count_upper("uoiea") == 0

def test_count_upper_mixed_case_vowels():
    assert count_upper("AeIoU") == 3
    assert count_upper("aEiOu") == 0

def test_count_upper_with_numbers():
    assert count_upper("1A3E5I") == 0
    assert count_upper("A1E3I5") == 3

def test_count_upper_with_special_characters():
    assert count_upper("!A#E%I") == 0
    assert count_upper("A!E#I%") == 3

def test_count_upper_long_string():
    long_str = "A" + "x" * 100 + "E" + "y" * 100 + "I"
    assert count_upper(long_str) == 2