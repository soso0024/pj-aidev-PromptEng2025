# Test cases for HumanEval/161
# Generated using Claude API


def solve(s):
    """You are given a string s.
    if s[i] is a letter, reverse its case from lower to upper or vise versa, 
    otherwise keep it as it is.
    If the string contains no letters, reverse the string.
    The function should return the resulted string.
    Examples
    solve("1234") = "4321"
    solve("ab") = "AB"
    solve("#a@C") = "#A@c"
    """

    flg = 0
    idx = 0
    new_str = list(s)
    for i in s:
        if i.isalpha():
            new_str[idx] = i.swapcase()
            flg = 1
        idx += 1
    s = ""
    for i in new_str:
        s += i
    if flg == 0:
        return s[len(s)::-1]
    return s


# Generated test cases:
import pytest

def solve(s):
    flg = 0
    idx = 0
    new_str = list(s)
    for i in s:
        if i.isalpha():
            new_str[idx] = i.swapcase()
            flg = 1
        idx += 1
    s = ""
    for i in new_str:
        s += i
    if flg == 0:
        return s[len(s)::-1]
    return s

@pytest.mark.parametrize("input_str,expected", [
    ("hello", "HELLO"),
    ("HELLO", "hello"),
    ("HeLLo", "hEllO"),
    ("123", "321"),
    ("", ""),
    ("!@#$%", "%$#@!"),
    ("abc123", "ABC123"),
    ("123abc", "123ABC"),
    ("a1b2c3", "A1B2C3"),
    ("Hello World!", "hELLO wORLD!"),
    ("123!@#", "#@!321"),
    ("a", "A"),
    ("A", "a"),
    ("1", "1"),
    ("!@#abc!@#", "!@#ABC!@#"),
    ("   ", "   "),
    ("a b c", "A B C"),
    ("ABC123XYZ", "abc123xyz"),
    ("12345", "54321"),
    ("!@#$", "$#@!"),
    ("aB1cD2", "Ab1Cd2"),
    ("NoLetters123", "nOlETTERS123"),
    ("OnlyNumbers456789", "oNLYnUMBERS456789"),
    ("MixedCase!@#123", "mIXEDcASE!@#123")
])
def test_solve(input_str, expected):
    assert solve(input_str) == expected

def test_solve_empty_string():
    assert solve("") == ""

def test_solve_only_numbers():
    assert solve("12345") == "54321"

def test_solve_only_symbols():
    assert solve("!@#$%^&*()") == ")(*&^%$#@!"

def test_solve_single_letter():
    assert solve("a") == "A"
    assert solve("Z") == "z"

def test_solve_mixed_content():
    result = solve("Test123!@#")
    expected = "tEST123!@#"
    assert result == expected

def test_solve_whitespace_only():
    assert solve("   ") == "   "

def test_solve_whitespace_with_letters():
    assert solve("a b c") == "A B C"
