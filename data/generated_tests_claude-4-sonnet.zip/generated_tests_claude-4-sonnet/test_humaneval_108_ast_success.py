# Test cases for HumanEval/108
# Generated using Claude API


def count_nums(arr):
    """
    Write a function count_nums which takes an array of integers and returns
    the number of elements which has a sum of digits > 0.
    If a number is negative, then its first signed digit will be negative:
    e.g. -123 has signed digits -1, 2, and 3.
    >>> count_nums([]) == 0
    >>> count_nums([-1, 11, -11]) == 1
    >>> count_nums([1, 1, 2]) == 3
    """

    def digits_sum(n):
        neg = 1
        if n < 0: n, neg = -1 * n, -1 
        n = [int(i) for i in str(n)]
        n[0] = n[0] * neg
        return sum(n)
    return len(list(filter(lambda x: x > 0, [digits_sum(i) for i in arr])))


# Generated test cases:
import pytest

def count_nums(arr):
    def digits_sum(n):
        neg = 1
        if n < 0: n, neg = -1 * n, -1 
        n = [int(i) for i in str(n)]
        n[0] = n[0] * neg
        return sum(n)
    return len(list(filter(lambda x: x > 0, [digits_sum(i) for i in arr])))

@pytest.mark.parametrize("arr,expected", [
    ([], 0),
    ([1, 2, 3], 3),
    ([-1, -2, -3], 0),
    ([0], 0),
    ([12, 34, 56], 3),
    ([-12, -34, -56], 3),
    ([1, -2, 3, -4], 2),
    ([10, 20, 30], 3),
    ([-10, -20, -30], 0),
    ([123, -456, 789], 3),
    ([0, 0, 0], 0),
    ([1, 0, -1], 1),
    ([999, -999], 2),
    ([100, -100], 1),
    ([5, -5], 1),
    ([11, -11], 1),
    ([19, -19], 2),
    ([20, -20], 1),
    ([21, -21], 1),
    ([99, -99], 1),
    ([101, -101], 1),
    ([1000, -1000], 1),
    ([1001, -1001], 1),
    ([9999, -9999], 2),
    ([10000, -10000], 1),
    ([12345], 1),
    ([-12345], 1),
    ([54321], 1),
    ([-54321], 1),
    ([1, 2, 3, 4, 5, 6, 7, 8, 9], 9),
    ([-1, -2, -3, -4, -5, -6, -7, -8, -9], 0),
    ([10, -1, 2, -3, 4, -5], 3),
    ([91, -82, 73, -64, 55], 3),
    ([18, -27, 36, -45], 4),
    ([17, -26, 35, -44], 3),
    ([1234567890], 1),
    ([-1234567890], 1),
    ([987654321], 1),
    ([-987654321], 1)
])
def test_count_nums_parametrized(arr, expected):
    assert count_nums(arr) == expected

def test_count_nums_empty_list():
    assert count_nums([]) == 0

def test_count_nums_single_positive():
    assert count_nums([5]) == 1

def test_count_nums_single_negative():
    assert count_nums([-5]) == 0

def test_count_nums_single_zero():
    assert count_nums([0]) == 0

def test_count_nums_all_positive():
    assert count_nums([1, 2, 3, 4, 5]) == 5

def test_count_nums_all_negative():
    assert count_nums([-1, -2, -3, -4, -5]) == 0

def test_count_nums_mixed():
    assert count_nums([1, -2, 3, -4, 5]) == 3

def test_count_nums_large_numbers():
    assert count_nums([123456789, -987654321]) == 2

def test_count_nums_edge_case_negative_with_positive_digit_sum():
    assert count_nums([-12]) == 1

def test_count_nums_edge_case_positive_with_large_first_digit():
    assert count_nums([91]) == 1