# Test cases for HumanEval/150
# Generated using Claude API


def x_or_y(n, x, y):
    """A simple program which should return the value of x if n is 
    a prime number and should return the value of y otherwise.

    Examples:
    for x_or_y(7, 34, 12) == 34
    for x_or_y(15, 8, 5) == 5
    
    """

    if n == 1:
        return y
    for i in range(2, n):
        if n % i == 0:
            return y
            break
    else:
        return x


# Generated test cases:
import pytest

def x_or_y(n, x, y):
    if n == 1:
        return y
    for i in range(2, n):
        if n % i == 0:
            return y
            break
    else:
        return x

def test_x_or_y_prime_numbers():
    assert x_or_y(2, 10, 20) == 10
    assert x_or_y(3, 10, 20) == 10
    assert x_or_y(5, 10, 20) == 10
    assert x_or_y(7, 34, 12) == 34
    assert x_or_y(11, 100, 200) == 100
    assert x_or_y(13, 'x', 'y') == 'x'
    assert x_or_y(17, True, False) == True
    assert x_or_y(19, [1, 2], [3, 4]) == [1, 2]

def test_x_or_y_composite_numbers():
    assert x_or_y(4, 10, 20) == 20
    assert x_or_y(6, 10, 20) == 20
    assert x_or_y(8, 10, 20) == 20
    assert x_or_y(9, 10, 20) == 20
    assert x_or_y(10, 10, 20) == 20
    assert x_or_y(12, 10, 20) == 20
    assert x_or_y(14, 10, 20) == 20
    assert x_or_y(15, 8, 5) == 5
    assert x_or_y(16, 'x', 'y') == 'y'
    assert x_or_y(18, True, False) == False

def test_x_or_y_edge_case_one():
    assert x_or_y(1, 10, 20) == 20
    assert x_or_y(1, 'x', 'y') == 'y'
    assert x_or_y(1, True, False) == False
    assert x_or_y(1, [1, 2], [3, 4]) == [3, 4]

def test_x_or_y_edge_case_two():
    assert x_or_y(2, 10, 20) == 10
    assert x_or_y(2, 'x', 'y') == 'x'
    assert x_or_y(2, True, False) == True

def test_x_or_y_large_primes():
    assert x_or_y(23, 100, 200) == 100
    assert x_or_y(29, 100, 200) == 100
    assert x_or_y(31, 100, 200) == 100

def test_x_or_y_large_composites():
    assert x_or_y(20, 100, 200) == 200
    assert x_or_y(21, 100, 200) == 200
    assert x_or_y(22, 100, 200) == 200
    assert x_or_y(24, 100, 200) == 200
    assert x_or_y(25, 100, 200) == 200

@pytest.mark.parametrize("n,x,y,expected", [
    (2, 1, 0, 1),
    (3, 1, 0, 1),
    (4, 1, 0, 0),
    (5, 1, 0, 1),
    (6, 1, 0, 0),
    (7, 1, 0, 1),
    (8, 1, 0, 0),
    (9, 1, 0, 0),
    (10, 1, 0, 0),
    (11, 1, 0, 1),
])
def test_x_or_y_parametrized(n, x, y, expected):
    assert x_or_y(n, x, y) == expected

def test_x_or_y_different_types():
    assert x_or_y(7, "prime", "composite") == "prime"
    assert x_or_y(8, "prime", "composite") == "composite"
    assert x_or_y(7, 3.14, 2.71) == 3.14
    assert x_or_y(8, 3.14, 2.71) == 2.71
    assert x_or_y(7, None, "not prime") == None
    assert x_or_y(8, "prime", None) == None
