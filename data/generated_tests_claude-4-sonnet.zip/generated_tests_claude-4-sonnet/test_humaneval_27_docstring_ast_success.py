# Test cases for HumanEval/27
# Generated using Claude API



def flip_case(string: str) -> str:
    """ For a given string, flip lowercase characters to uppercase and uppercase to lowercase.
    >>> flip_case('Hello')
    'hELLO'
    """

    return string.swapcase()


# Generated test cases:
import pytest

def flip_case(string: str) -> str:
    return string.swapcase()

def test_flip_case_basic():
    assert flip_case('Hello') == 'hELLO'

def test_flip_case_empty_string():
    assert flip_case('') == ''

def test_flip_case_all_lowercase():
    assert flip_case('hello') == 'HELLO'

def test_flip_case_all_uppercase():
    assert flip_case('HELLO') == 'hello'

def test_flip_case_mixed_case():
    assert flip_case('HeLLo WoRLd') == 'hEllO wOrlD'

def test_flip_case_numbers():
    assert flip_case('Hello123') == 'hELLO123'

def test_flip_case_special_characters():
    assert flip_case('Hello!@#$%') == 'hELLO!@#$%'

def test_flip_case_spaces():
    assert flip_case('Hello World') == 'hELLO wORLD'

def test_flip_case_single_character():
    assert flip_case('a') == 'A'
    assert flip_case('Z') == 'z'

def test_flip_case_only_numbers():
    assert flip_case('12345') == '12345'

def test_flip_case_only_special_chars():
    assert flip_case('!@#$%^&*()') == '!@#$%^&*()'

def test_flip_case_unicode():
    assert flip_case('café') == 'CAFÉ'
    assert flip_case('CAFÉ') == 'café'

@pytest.mark.parametrize("input_str,expected", [
    ("", ""),
    ("a", "A"),
    ("Z", "z"),
    ("Hello", "hELLO"),
    ("WORLD", "world"),
    ("PyThOn", "pYtHoN"),
    ("123", "123"),
    ("Hello123World", "hELLO123wORLD"),
    ("!@#", "!@#"),
    ("Test Case", "tEST cASE"),
    ("MiXeD cAsE 123!", "mIxEd CaSe 123!")
])
def test_flip_case_parametrized(input_str, expected):
    assert flip_case(input_str) == expected