# Test cases for HumanEval/18
# Generated using Claude API



def how_many_times(string: str, substring: str) -> int:
    """ Find how many times a given substring can be found in the original string. Count overlaping cases.
    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """

    times = 0

    for i in range(len(string) - len(substring) + 1):
        if string[i:i+len(substring)] == substring:
            times += 1

    return times


# Generated test cases:
import pytest

def how_many_times(string: str, substring: str) -> int:
    times = 0
    for i in range(len(string) - len(substring) + 1):
        if string[i:i+len(substring)] == substring:
            times += 1
    return times

class TestHowManyTimes:
    
    def test_empty_string(self):
        assert how_many_times('', 'a') == 0
        assert how_many_times('', '') == 1
    
    def test_empty_substring(self):
        assert how_many_times('hello', '') == 6
        assert how_many_times('abc', '') == 4
    
    def test_single_character_matches(self):
        assert how_many_times('aaa', 'a') == 3
        assert how_many_times('ababa', 'a') == 3
        assert how_many_times('hello', 'l') == 2
    
    def test_overlapping_matches(self):
        assert how_many_times('aaaa', 'aa') == 3
        assert how_many_times('aaaaaa', 'aa') == 5
        assert how_many_times('abababab', 'abab') == 3
    
    def test_no_matches(self):
        assert how_many_times('hello', 'x') == 0
        assert how_many_times('abc', 'xyz') == 0
        assert how_many_times('test', 'testing') == 0
    
    def test_exact_match(self):
        assert how_many_times('hello', 'hello') == 1
        assert how_many_times('test', 'test') == 1
    
    def test_substring_longer_than_string(self):
        assert how_many_times('hi', 'hello') == 0
        assert how_many_times('a', 'abc') == 0
    
    def test_repeated_patterns(self):
        assert how_many_times('abcabcabc', 'abc') == 3
        assert how_many_times('121212', '12') == 3
        assert how_many_times('nanana', 'na') == 3
    
    def test_case_sensitive(self):
        assert how_many_times('Hello', 'hello') == 0
        assert how_many_times('ABC', 'abc') == 0
        assert how_many_times('AaAa', 'Aa') == 2
    
    def test_special_characters(self):
        assert how_many_times('a.b.c.d', '.') == 3
        assert how_many_times('!!!!!', '!!') == 4
        assert how_many_times('a b a b', ' ') == 3
    
    @pytest.mark.parametrize("string,substring,expected", [
        ('', 'a', 0),
        ('aaa', 'a', 3),
        ('aaaa', 'aa', 3),
        ('abcdef', 'cd', 1),
        ('ababab', 'ab', 3),
        ('xyzxyzxyz', 'xyz', 3),
        ('hello world', 'o', 2),
        ('programming', 'mm', 1),
        ('banana', 'ana', 2),
        ('mississippi', 'issi', 2)
    ])
    def test_parametrized_cases(self, string, substring, expected):
        assert how_many_times(string, substring) == expected
