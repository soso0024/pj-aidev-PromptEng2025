# Test cases for HumanEval/2
# Generated using Claude API



def truncate_number(number: float) -> float:
    """ Given a positive floating point number, it can be decomposed into
    and integer part (largest integer smaller than given number) and decimals
    (leftover part always smaller than 1).

    Return the decimal part of the number.
    >>> truncate_number(3.5)
    0.5
    """

    return number % 1.0


# Generated test cases:
import pytest

def truncate_number(number: float) -> float:
    return number % 1.0

def test_positive_decimal():
    assert truncate_number(3.5) == 0.5

def test_negative_decimal():
    result = truncate_number(-2.7)
    assert abs(result - 0.3) < 1e-10

def test_zero():
    assert truncate_number(0.0) == 0.0

def test_positive_integer():
    assert truncate_number(5.0) == 0.0

def test_negative_integer():
    assert truncate_number(-3.0) == 0.0

def test_small_positive_decimal():
    assert truncate_number(0.123) == 0.123

def test_small_negative_decimal():
    result = truncate_number(-0.456)
    assert abs(result - 0.544) < 1e-10

def test_large_positive_number():
    result = truncate_number(1234.789)
    assert abs(result - 0.789) < 1e-10

def test_large_negative_number():
    result = truncate_number(-9876.321)
    assert abs(result - 0.679) < 1e-10

def test_very_small_positive():
    assert truncate_number(0.000001) == 0.000001

def test_very_small_negative():
    result = truncate_number(-0.000001)
    assert abs(result - 0.999999) < 1e-6

@pytest.mark.parametrize("input_val,expected", [
    (1.5, 0.5),
    (2.8, 0.8),
    (10.0, 0.0),
    (0.9, 0.9),
    (-1.3, 0.7),
    (-5.0, 0.0)
])
def test_parametrized_cases(input_val, expected):
    result = truncate_number(input_val)
    assert abs(result - expected) < 1e-10

def test_fractional_part_precision():
    result = truncate_number(123.456789)
    assert abs(result - 0.456789) < 1e-10

def test_negative_fractional_precision():
    result = truncate_number(-456.789123)
    assert abs(result - 0.210877) < 1e-6