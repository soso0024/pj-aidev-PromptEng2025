# Test cases for HumanEval/107
# Generated using Claude API


def even_odd_palindrome(n):
    """
    Given a positive integer n, return a tuple that has the number of even and odd
    integer palindromes that fall within the range(1, n), inclusive.

    Example 1:

        Input: 3
        Output: (1, 2)
        Explanation:
        Integer palindrome are 1, 2, 3. one of them is even, and two of them are odd.

    Example 2:

        Input: 12
        Output: (4, 6)
        Explanation:
        Integer palindrome are 1, 2, 3, 4, 5, 6, 7, 8, 9, 11. four of them are even, and 6 of them are odd.

    Note:
        1. 1 <= n <= 10^3
        2. returned tuple has the number of even and odd integer palindromes respectively.
    """

    def is_palindrome(n):
        return str(n) == str(n)[::-1]

    even_palindrome_count = 0
    odd_palindrome_count = 0

    for i in range(1, n+1):
        if i%2 == 1 and is_palindrome(i):
                odd_palindrome_count += 1
        elif i%2 == 0 and is_palindrome(i):
            even_palindrome_count += 1
    return (even_palindrome_count, odd_palindrome_count)


# Generated test cases:
import pytest

def even_odd_palindrome(n):
    def is_palindrome(n):
        return str(n) == str(n)[::-1]

    even_palindrome_count = 0
    odd_palindrome_count = 0

    for i in range(1, n+1):
        if i%2 == 1 and is_palindrome(i):
                odd_palindrome_count += 1
        elif i%2 == 0 and is_palindrome(i):
            even_palindrome_count += 1
    return (even_palindrome_count, odd_palindrome_count)

@pytest.mark.parametrize("n,expected", [
    (1, (0, 1)),
    (2, (1, 1)),
    (3, (1, 2)),
    (4, (2, 2)),
    (5, (2, 3)),
    (6, (3, 3)),
    (7, (3, 4)),
    (8, (4, 4)),
    (9, (4, 5)),
    (10, (4, 5)),
    (11, (4, 6)),
    (12, (4, 6)),
    (15, (4, 6)),
    (20, (4, 6)),
    (22, (5, 6)),
    (33, (5, 7)),
    (50, (6, 7)),
    (99, (8, 10)),
    (100, (8, 10)),
    (101, (8, 11)),
    (111, (8, 12)),
    (121, (8, 13)),
    (131, (8, 14)),
    (141, (8, 15)),
    (151, (8, 16)),
    (161, (8, 17)),
    (171, (8, 18)),
    (181, (8, 19)),
    (191, (8, 20)),
    (200, (8, 20)),
    (212, (10, 20)),
    (222, (11, 20)),
    (313, (18, 22)),
    (414, (20, 30)),
    (515, (28, 32)),
    (616, (30, 40)),
    (717, (38, 42)),
    (818, (40, 50)),
    (919, (48, 52)),
    (1000, (48, 60)),
    (1001, (48, 61)),
    (1111, (48, 62)),
    (1221, (48, 63)),
    (1331, (48, 64)),
    (1441, (48, 65)),
    (1551, (48, 66)),
    (1661, (48, 67)),
    (1771, (48, 68)),
    (1881, (48, 69)),
    (1991, (48, 70)),
    (2002, (49, 70)),
    (2112, (50, 70)),
    (2222, (51, 70)),
    (3333, (58, 74)),
    (4444, (63, 80)),
    (5555, (68, 86)),
    (6666, (75, 90)),
    (7777, (78, 98)),
    (8888, (87, 100)),
    (9999, (88, 110)),
    (10000, (88, 110))
])
def test_even_odd_palindrome_parametrized(n, expected):
    assert even_odd_palindrome(n) == expected

def test_edge_case_zero():
    assert even_odd_palindrome(0) == (0, 0)

def test_single_digit_numbers():
    assert even_odd_palindrome(1) == (0, 1)
    assert even_odd_palindrome(2) == (1, 1)
    assert even_odd_palindrome(3) == (1, 2)
    assert even_odd_palindrome(4) == (2, 2)
    assert even_odd_palindrome(5) == (2, 3)
    assert even_odd_palindrome(6) == (3, 3)
    assert even_odd_palindrome(7) == (3, 4)
    assert even_odd_palindrome(8) == (4, 4)
    assert even_odd_palindrome(9) == (4, 5)

def test_two_digit_palindromes():
    assert even_odd_palindrome(11) == (4, 6)
    assert even_odd_palindrome(22) == (5, 6)
    assert even_odd_palindrome(33) == (5, 7)
    assert even_odd_palindrome(44) == (6, 7)
    assert even_odd_palindrome(55) == (6, 8)
    assert even_odd_palindrome(66) == (7, 8)
    assert even_odd_palindrome(77) == (7, 9)
    assert even_odd_palindrome(88) == (8, 9)
    assert even_odd_palindrome(99) == (8, 10)

def test_three_digit_palindromes():
    assert even_odd_palindrome(101) == (8, 11)
    assert even_odd_palindrome(111) == (8, 12)
    assert even_odd_palindrome(121) == (8, 13)
    assert even_odd_palindrome(131) == (8, 14)
    assert even_odd_palindrome(141) == (8, 15)
    assert even_odd_palindrome(151) == (8, 16)

def test_large_numbers():
    result = even_odd_palindrome(1000)
    assert isinstance(result, tuple)
    assert len(result) == 2
    assert all(isinstance(x, int) for x in result)
    assert all(x >= 0 for x in result)

def test_return_type():
    result = even_odd_palindrome(10)
    assert isinstance(result, tuple)
    assert len(result) == 2
    assert isinstance(result[0], int)
    assert isinstance(result[1], int)

def test_non_negative_counts():
    for n in [0, 1, 5, 10, 50, 100]:
        even_count, odd_count = even_odd_palindrome(n)
        assert even_count >= 0
        assert odd_count >= 0

def test_count_consistency():
    for n in range(1, 21):
        even_count, odd_count = even_odd_palindrome(n)
        assert even_count + odd_count <= n