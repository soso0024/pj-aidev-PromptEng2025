# Test cases for HumanEval/42
# Generated using Claude API



def incr_list(l: list):
    """Return list with elements incremented by 1.
    >>> incr_list([1, 2, 3])
    [2, 3, 4]
    >>> incr_list([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [6, 4, 6, 3, 4, 4, 10, 1, 124]
    """

    return [(e + 1) for e in l]


# Generated test cases:
import pytest

def incr_list(l: list):
    return [(e + 1) for e in l]

def test_incr_list_empty():
    assert incr_list([]) == []

def test_incr_list_single_element():
    assert incr_list([5]) == [6]

def test_incr_list_positive_numbers():
    assert incr_list([1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]

def test_incr_list_negative_numbers():
    assert incr_list([-5, -3, -1]) == [-4, -2, 0]

def test_incr_list_mixed_numbers():
    assert incr_list([-2, 0, 3, -1, 5]) == [-1, 1, 4, 0, 6]

def test_incr_list_zero():
    assert incr_list([0]) == [1]

def test_incr_list_large_numbers():
    assert incr_list([999, 1000, 10000]) == [1000, 1001, 10001]

def test_incr_list_floats():
    result = incr_list([1.5, 2.7, -3.2])
    expected = [2.5, 3.7, -2.2]
    assert len(result) == len(expected)
    for r, e in zip(result, expected):
        assert abs(r - e) < 1e-10

@pytest.mark.parametrize("input_list,expected", [
    ([1], [2]),
    ([0, 0, 0], [1, 1, 1]),
    ([-10, -5, 0, 5, 10], [-9, -4, 1, 6, 11]),
    ([100], [101])
])
def test_incr_list_parametrized(input_list, expected):
    assert incr_list(input_list) == expected

def test_incr_list_with_non_numeric_raises_error():
    with pytest.raises(TypeError):
        incr_list(['a', 'b', 'c'])

def test_incr_list_with_mixed_types_raises_error():
    with pytest.raises(TypeError):
        incr_list([1, 'a', 3])

def test_incr_list_with_none_raises_error():
    with pytest.raises(TypeError):
        incr_list([1, None, 3])

def test_incr_list_original_list_unchanged():
    original = [1, 2, 3]
    result = incr_list(original)
    assert original == [1, 2, 3]
    assert result == [2, 3, 4]
    assert original is not result
